import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Hide the Next.js dev-tools indicator (the floating "N" badge).
  devIndicators: false,
};

export default nextConfig;
