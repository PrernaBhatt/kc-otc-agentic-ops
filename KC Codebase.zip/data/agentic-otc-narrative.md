# Agentic Order to Cash — Narrative

Across industries, the universal challenge is the same: orders, invoices and payments move through disconnected systems. Every mismatch between what a customer expects and what our systems say turns into a hold, a delay or a deduction, and teams spend their time chasing exceptions instead of getting paid.

## Dashboard

[Open the Dashboard.] The dashboard shows order to cash in the measures finance runs on. 94.2% of orders flow straight through, DSO is 38 days, invoice-to-cash is 33 days against a 30-day target, and 97.6% of invoices are right first time. [Click the Invoice-to-Cash and Right-first-time tiles to open each breakdown.] No invoice was reissued this period.

[Open Accounts.] Every customer has one owner. Agents carry 96% of the work, 1,236 of 1,284 items; the owner sees only the 48 that need a decision.

## Order Management — SO-710260 Costco

[Open Order Management → select SO-710260 → click Process.] Costco's retail operations team bulk-uploaded purchase order PO-CWC-40218: 1,200 cases of training pants and 1,240 cases of baby diapers, $340,000.

[Press Enter.] PO Intake closes and Validation opens: customer, bill-to, duplicate SO, ship-to and Net 30 terms all pass. [Press Enter.] MOQ clears on both lines. [Press Enter.] Credit is $1.16 million against a $2 million limit, approved. [Press Enter.] The Inventory Allocation Agent reserves the full quantity at the Ontario DC.

[Press Enter to open Confirmation.] Costco trades by EDI, so the confirmation goes out as an EDI 855. [Review the matched SAP order against the 855 segments, then click Continue.] The 997 comes back from Costco.

[Press Enter to open Logistics handoff.] Logistics hands off; the agent reads carrier, appointment and proof of delivery in one step. Blue Line Freight, APPT-C114-58213, POD on August 29. These are read only, outside GBS scope.

[The run completes.] Four minutes, no touches. The invoice-to-cash clock shows INV-710260 created at POD on August 29, Net 30, cash expected September 28.

## Order Management — SO-710249 Target

[Select SO-710249 → click Process.] Target's buyer emailed PO-TGG-8843 for $220,740. [Press Enter through customer, duplicate and MOQ checks.]

The Pricing Agent compares every line to contract CTR-TGG-2026 and finds all four above contract, $740 in total. [The order pauses here.] The gap is above the $250 perfect-invoice tolerance, and billing at the PO price would only turn into a $740 deduction later.

[Click "Sign & bill at contract", sign as Jim Novak under SOX 1.4.1.] The SAP order reprices to $220,000 and the gap is recorded as DISC-2049. [Press Enter through Allocation and Confirmation.] [Review the reply on the buyer's own email thread, then send.] Target is told the order bills at contract price and asked to update its price file. [Press Enter to open Logistics handoff.] The agent reads the TMS facts and the run closes.

## Billing — SO-710269 Costco short-pay

[Open Billing → select SO-710269 → start the run.] Short-pay: Costco paid $1,105,000 against invoice $1,293,000, $188,000 short. The agent opens a dispute case in FSCM; the original invoice stays as issued because September is closed.

[Press Enter to open Root cause.] Four causes are checked against SAP, PricerX, Vistex and the vendor agreement. Price and promotion are K-C right, $95,000 and $55,000. Freight above the Costco cap and California tax are Costco right, $28,000 and $10,000.

[Press Enter to open Settlement.] The agent drafts a $150,000 charge-back and a $38,000 credit note. [Open Sign-off → sign under SOX 1.4.3 and 1.4.4; L. Chen co-signs as Controller above the $50,000 limit.] [Press Enter to open Post in FSCM.] The credit note posts against the original invoice; the charge-back stays with Collections.

[Press Enter to open Fix upstream.] Each cause goes back to its owner in Pricing and Master data, so the next invoice is right first time. [Press Enter to open Notify Costco.] The agent drafts the response to Costco with the backup for both amounts.

## Deductions — Trade, then Non-trade

[Open Deductions → Trade.] Walmart withheld $180,000 against a back-to-school promotion claim. [Press Enter through Events and Fund Budget.] The referenced fund has only $140,000 left. [Press Enter to open Allocation.] The agent recommends $140,000 from family care and $40,000 from baby care. [Sign under SOX 1.7.2.] [Press Enter through Retailer Response and Settlement.]

[Switch to Non-trade → open batch NT-2026-W44.] 312 claims, $486,400, run as one batch. [Press Enter.] 204 valid claims credit $198,400, 96 invalid claims charge back $251,600, and 12 exceptions worth $36,400 go to their account owners. [Sign the batch, then press Enter to post.]

## Accounts

[Open Accounts → select Costco.] The two escalations the billing run just raised sit with Marcus Hale: the price file and promotion end date for Pricing, and lane freight above the Costco cap for Transportation. [Select Woolworths.] ESC-2611 has been open 47 days against a 30-day SLA and auto-escalated on day 31.

## Audit trail

[Open Audit trail → filter control 1.4.x.] Every gate signed today is here with its control, signer and evidence. [Click Export PDF.]

## Closing

The value of this solution is not just automating steps. Every order, invoice and claim is tied to the contract, promotion, freight and fund evidence behind it, each decision is signed by its owner against a SOX control, and the root cause goes back upstream so the same gap does not recur.

Thank you for watching.
