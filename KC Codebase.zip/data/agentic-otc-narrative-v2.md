# Agentic Order to Cash — Recording Narrative (v2)

Reflects the six changes from the K-C / Kenvue Q&A. Click-through steps are in [brackets]. In every guided run, one Enter = one step.

---

## Opening

**This is Agentic Order to Cash.**

Orders, invoices and payments move through disconnected systems. Every mismatch between what the customer expects and what our systems say becomes a hold or a deduction. The way to fix it is to get the price right before the invoice, and to settle what still slips through against the original invoice, with the evidence attached.

## Dashboard

[Open Dashboard.]

The dashboard is the OM Command Center. OTIF is split into available, shipped and delivered, so you can see where orders drop out: 96.8%, 93.4%, then 89.6%. Next to it are perfect order, order validation accuracy and order-to-invoice cycle time. [Hover the KPI cards to show the breakdowns.]

Below that, OTIF at risk is predictive. It flags the shipments that will miss their window before or after they leave the DC. Further down, invoice-to-cash still drives free cash flow and DSO.

## Accounts: one owner per customer

[Click Accounts in the left nav.]

Work is organised by customer, not by process module. Every account has one owner, following the North America model. Walmart belongs to Rachel Ortiz, Costco to Marcus Hale and Target to Jim Novak. Agents do the volume behind each owner: on Walmart, agents handle 398 items and Rachel handles 14.

When the cause sits outside finance, the owner raises a tracked escalation to the commercial or supply-chain team, and the tracker shows its status from Raised through Acknowledged and Actioned to Closed. [Open Woolworths.] This is the Australia pattern: trade claim age is climbing because commercial teams prioritise revenue. Mia Kelly's escalation to Key Account AU makes that visible and keeps it from being lost.

## Order Management: SO-710260, Costco, touchless

[Open Order Management → select SO-710260 → click Process.]

Costco sends purchase order PO-CWC-40218 by EDI: 1,200 cases of training pants and 1,240 cases of baby diapers, $340,000 in total.

[Enter] The Order Intake Agent builds the sales order. [Enter] It reads and validates the order: customer, bill-to, no duplicate, ship-to and Net 30 terms. [Enter] Pricing matches the contract on both lines. [Enter] Minimum order quantity clears. [Enter] Credit: $1.16 million of exposure against a $2 million limit. [Enter] Regulatory checks pass. [Enter] Inventory is allocated in full at the Ontario DC.

[Enter] Customer confirmation goes out as an EDI 855, and Costco's 997 comes back. [Review the 855 modal, then click Continue.]

[Enter] Appointment. TMS owns the route, load and carrier, so the agent reads the plan: Blue Line Freight, pickup Friday 16:00, arriving Saturday morning. It checks the Costco receiving calendar, books Sat 06:00–08:00 inside the OTIF window and blocks the calendar. Order management is already about 99% automated, so we keep this short and move on to where the cash is.

## Order Management: SO-710249, Target, price exception

[Select SO-710249 → click Process.]

Target's buyer emails PO-TGG-8843. [Enter through Intake and Read & validate.]

The Pricing Agent compares every line with contract CTR-TGG-2026. All four lines are above contract, $740 in total, which is over the $250 per-order tolerance. The order goes on hold before an invoice exists. The likely driver is that Target's discrepancy window expired on August 10 and the buyer's price file is one revision behind.

Under the perfect-invoice rule, the agent recommends billing at the K-C contract price, notifying the buyer and recording the discrepancy. If we billed at the PO price, Target would simply deduct the $740 after the invoice.

[Click "Sign & bill at contract".] Jim Novak, the Target owner, signs. The sign-off carries SOX control 1.4.1: price exceptions are approved before the invoice is created. [Sign and confirm.] The order is billed at contract, $220,000, and the buyer is asked to update to the CTR-TGG-2026 price file. [Enter through the remaining steps.]

## Shipments: OTIF at risk

[Open Order Management → Shipments.]

Seven shipments are predicted to miss or nearly miss their OTIF window, four before shipment and three in transit. Three need action; the rest are watched by the agents.

### SHP-58201, Walmart: no slot inside the window

[Open SHP-58201.] [Enter] The agent reads the TMS plan: Monday arrival at RDC 6094. [Enter] Walmart's scheduling portal is full up to the must-arrive-by date. [Enter] So it drafts a request to Kelly Brooks, the Walmart buyer. [Send.] [Enter] The DC opens door 31 on Tuesday, 22:00–23:00, inside the window, and the calendar is blocked. [Enter] The slot no longer matches the TMS plan, so the agent pushes the replan RP-58201 back to TMS, with no change in rate.

### SHP-58207, Kroger: premium freight

[Back to Shipments → open SHP-58207.] [Enter] The carrier rejected the tender, and the TMS replan arrives a day after the appointment. [Enter] The agent compares three options: keep the plan and take the fine, a team-driver expedite, or ship short from Atlanta. [Enter] It drafts premium freight plan PFP-58207: $1,740 over base against a $2,964 fine. [Enter] Priya Raman, Transportation Manager, approves it under SOX 1.2.1, within her $2,500 limit. [Sign and confirm.] [Enter] The new tender goes to TMS.

### MR-58212, milk run: track and trace

[Back to Shipments → open MR-58212.] [Enter] One truck, three stops: Target, Kroger and Costco. It left the Ontario DC at 08:05, 1 h 45 min late. FourKites gives a predicted ETA for the first stop only, so the agent predicts the other two from drive and unload times. [Enter] On the current order, all three stops miss their windows. [Enter] It compares three stop orders and recommends Kroger, Costco, then Target: one miss instead of three. [Enter] Priya approves under SOX 1.2.2. [Sign and confirm.] [Enter] The new order goes to Blue Line Freight, and Target is asked for a 12:00–13:00 slot before the truck arrives. [Send.]

## Billing: SO-710269, Costco short-pay settled as an FSCM dispute

[Open Billing → open dispute case DC-710269.]

Costco's invoice INV-710269 has already posted, and that period closed on October 6. Costco paid $188,000 short. We do not reissue the invoice. Tax rules prevent reversing an invoice from a closed month, so the difference is settled as a dispute against the original invoice.

[Enter] The Cash Application Agent reads Costco's EDI 820 remittance and opens the dispute case in FSCM.

[Enter] The Dispute Investigation Agent checks four causes against the systems of record. K-C is right on two of them:
- **Price, $95,000:** PricerX approved $31 on August 29, and the EDI 832 was acknowledged. Costco paid $28.625 from an old item file.
- **Promotion, $55,000:** the Q2 Volume Growth Rebate ended on June 30, and this order delivered on September 18.

Costco is right on the other two:
- **Freight, $28,000:** the vendor agreement caps freight at $15,000 per load, but SAP billed the actual $43,000.
- **Tax, $10,000:** Costco's California resale certificate is valid, but SAP still classes the ship-to as taxable.

[Enter] So the agent drafts a $38,000 credit note for the causes Costco is right on, and a $150,000 charge-back with backup for the ones K-C is right on.

[Enter] Marcus Hale signs, and the Controller, L. Chen, co-signs because the amounts are above his delegated limit. The sign-off is tagged SOX 1.4.3 for credit notes and 1.4.4 for charge-backs. [Sign and confirm.]

[Enter] The FSCM Posting Agent posts both items against INV-710269. The original invoice stays untouched.

[Enter] The step that prevents the next deduction is fixing the cause upstream. Price and promotion go to Pricing as tasks in PricerX and Vistex. Freight and tax go to Master Data as SAP MDG change requests, under SOX 1.4.2.

[Enter] Costco receives the dispute response with the backup attached.

## Deductions: trade by value, non-trade by volume

[Open Deductions.]

Deductions are split into two lanes. Trade carries the value: around $2.4 billion of promotion spend. Non-trade carries the volume: about three-quarters of all claims by count.

### Trade: Walmart fund allocation

[Stay on the Trade tab → open the Walmart claim.]

Walmart withheld $180,000 against a back-to-school promotion. The claim is valid, so the question is which fund pays it. [Enter] Two events ran over the same dates: a family-care feature and a baby-care display. [Enter] The family-care fund has only $140,000 left after an earlier claim. [Enter] The agent recommends $140,000 from family care and $40,000 from baby care. [Sign the reallocation.] The reclass is above $25,000, so it is signed under SOX 1.7.2. Proof of performance is attached under 1.7.3, because auditors are particular about it. [Enter through the retailer response and settlement.]

### Non-trade: weekly batch NT-2026-W44

[Click the Non-trade tab → open batch NT-2026-W44.]

One week of low-value claims: 312 claims, $486,400, from Walmart, Kroger, Target and Costco.

[Enter] Captured from EDI 820 and the retailer portals. [Enter] Classified by reason code into shortage, damage, pricing, compliance and freight. [Enter] Each claim is checked against its evidence. 204 are valid and become credit memos, 96 are invalid and become charge-backs, and 12 go to account owners as disputes. One of them is a Walmart OTIF fine: Walmart moved the appointment after our truck was booked, and the signed POD shows we arrived on the original slot. So it is charged back.

[Enter] Dana Whitfield signs the policy for the batch under SOX 1.4.5, with Rachel Ortiz co-signing for Walmart. [Sign.] [Enter] The batch posts in FSCM. The 86 valid shortages at one DC become a supply-chain signal, ESC-2631, the Ontario DC shortage cluster, so the cause gets fixed rather than credited every week.

## Audit trail

[Click Audit trail in the left nav.]

Every approval shown today carries its SOX control reference: fulfilment in the 1.2 family, billing in 1.4 and trade promotion in 1.7, with the signer, the evidence and the time. [Click "Export audit trail" → choose the format → export.] The whole trail exports in one go, ready for the auditors.

## Closing

This is not automation of the steps we have today. Prices are right before the invoice. What still slips through is settled against the original invoice, with evidence. Every cause goes back to whoever can fix it. And one owner per customer, with agents behind them, has every decision signed against the control it belongs to.

Thank you for watching.
