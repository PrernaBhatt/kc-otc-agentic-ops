# Agentic Order to Cash — Short Narrative (7 changes)

Click-through steps are in [brackets]. In every guided run, one Enter = one step. Gates stop and wait for a signature.

---

## Opening

[Open Dashboard.]

**This is Agentic Order to Cash, updated with the changes from our Q&A.** The dashboard is now the **OM Command Center**. The top row shows OTIF split into available, shipped and delivered (96.8%, 93.4% and 89.6%), perfect order at 85.6%, order validation accuracy at 99.1% and order-to-invoice at 6.4 days. [Hover each bar to show the breakdowns.]

Below it, **OTIF at risk** predicts which shipments will miss their window: 7 today, 3 need action. We come back to those at the end. **Invoice-to-Cash**, at 33 days against a 30-day target, and **Right-first-time invoices**, at 97.6%, sit in the row below.

## Change 1 · One owner per customer (new page: Accounts)

[Click Accounts in the left nav.]

Work is now organised by customer, not by module. Six accounts, six owners, and agents handle 96% of the work behind them. On Walmart, for example, agents handle 398 items and Rachel Ortiz handles 14. [Click Walmart.] The rail shows the owner's delegated limits, the agents working for her, and her open work by module.

[Click Woolworths.] This is the Australia example. Escalation ESC-2611 to Key Account AU covers 14 trade claims, $418,500, and it's 47 days old against a 30-day SLA, so it's flagged overdue. The status chain shows how far it has got. [Click Nudge.] Nothing gets lost, and the owner signs every gate from here on.

## Change 2 · Target is billed at the contract price

[Open Order Management → select SO-710249 → click Process → Enter through Intake and Read & validate.]

All four lines are above contract CTR-TGG-2026, $740 in total. The card now shows the policy: the gap is over the $250 tolerance, so we bill at the K-C price. If we billed at the PO price, Target would deduct the $740 after the invoice. The old "10 of 12 cases" precedent is gone.

[Click "Sign & bill at contract" → sign → Confirm.] Jim Novak, the Target owner, signs under SOX 1.4.1. The order is repriced to $220,000 and discrepancy DISC-2049 is recorded. [Enter through the rest of the run.] The buyer's confirmation asks them to update the price file, and the cause goes to Revenue Management as ESC-2625.

## Change 3 · The Costco touchless flow is shorter

[Select SO-710260 → click Process → press Enter through the run.]

The order runs touchless: intake, validation, pricing, minimum order, credit, regulatory, allocation and the EDI 855 confirmation. The last step is now **Appointment**. TMS has already planned the load on Blue Line Freight for Saturday morning, so the agent books a Costco slot inside the OTIF window, Sat 06:00–08:00, and blocks the calendar. [Final Enter.] The run ends on the invoice-to-cash clock: INV-710260 is created at proof of delivery, with cash expected on September 28.

## Change 4 · Billing doesn't reissue the invoice; it raises an FSCM dispute

[Open Billing → open dispute case DC-710269.]

INV-710269 was issued at the K-C price, $1,293,000. Costco paid $188,000 short, and the period is closed. The invoice stays locked and is never reissued.

[Enter] The agent reads Costco's EDI 820 and opens the FSCM dispute case. [Enter] It checks four causes against the systems of record. K-C is right on price, $95,000, and on the expired promotion, $55,000. Costco is right on freight, $28,000, and tax, $10,000. [Enter] That gives a $150,000 charge-back and a $38,000 credit note. [Enter → Sign → Confirm.] Marcus Hale signs. The Controller, L. Chen, co-signs because the charge-back is above his limit. Both are tagged SOX 1.4.3 and 1.4.4. [Enter] Both post in FSCM against the original invoice. [Enter] The new step is **Fix upstream**: price and promotion go to Pricing, freight and tax go to Master data as MDG change requests, and both are escalated. [Enter] Costco gets the response with backup attached.

## Change 5 · Deductions are split into trade (value) and non-trade (volume)

[Open Deductions.]

Two lanes now. Trade carries the value, with $2.4 billion of promotion spend, and each case is investigated and signed individually. Non-trade carries the volume, about three-quarters of all claims, so it runs in batches.

[Click the Non-trade tab → open batch NT-2026-W44.]

One week: 312 claims, $486,400. [Enter] The agent captures them from EDI 820 and the retailer portals. [Enter] It classifies them by reason code. [Enter] It validates each claim against its evidence. 204 become credit memos, 96 become charge-backs, and 12 go to account owners, including a $9,800 Walmart OTIF fine where Walmart moved the appointment. [Enter → Sign.] The batch policy is signed once under SOX 1.4.5. [Enter] It posts in FSCM, and the Ontario DC shortage cluster goes to supply chain as ESC-2631.

## Change 6 · Every approval carries its SOX control (new page: Audit trail)

[Click Audit trail in the left nav.]

Every gate we've just signed is here, along with the older ones: the Walmart fund reclass under 1.7.2, promotion proof under 1.7.3, and the rebate and duplicate checks. Billing controls are 1.4.x and trade promotion is 1.7.x. Each entry shows the signer, the evidence and the time. [Click a row to open the rail.] [Click "Export audit trail" → choose PDF · A4 or CSV → Export.] The trail exports for the auditors in one step.

## Change 7 · Shipments: appointments, OTIF at risk, track and trace (new page)

[Open Order Management → Shipments.]

This is the OTIF at risk board from the dashboard, split before and after shipment. Each row shows the predicted ETA against its OTIF window.

[Open SHP-58201 · Walmart.] No slot is left at RDC 6094 before the must-arrive-by date. [Enter] The agent drafts the request to Kelly Brooks, the Walmart buyer. [Send.] [Enter] The DC opens door 31 for Tue 22:00–23:00, inside the window, and the calendar is blocked. [Enter] That slot doesn't match the TMS plan, so the agent pushes TMS to replan the load, RP-58201, with no rate change.

[Back to Shipments → open SHP-58207 · Kroger.] The carrier rejected the tender, and the TMS replan arrives a day late. [Enter] The agent compares three options. [Enter] It drafts premium freight plan PFP-58207: a Summit Logistics team driver, $1,740 over base, against a $2,964 fine. [Enter → Sign.] Priya Raman, Transportation Manager, approves it under SOX 1.2.1, inside her $2,500 limit. [Enter] The tender goes back to TMS.

[Back to Shipments → open MR-58212 · milk run.] The truck left the Ontario DC at 08:05, 1 h 45 min late. [Enter] FourKites predicts stop 1 only, so the agent predicts the other two, and all three stops miss their windows. [Enter] It compares three stop orders and recommends Kroger, Costco, then Target, which leaves one miss instead of three. [Enter → Sign.] Priya approves under SOX 1.2.2. [Enter → Send.] The new order goes to the carrier, and Target is asked for a 12:00–13:00 slot before the truck arrives, so the load isn't rejected.

## Closing

Prices are right before the invoice. Shipments that will miss their window are caught before the customer sees it. Short-pays settle against the original invoice. Causes go back upstream, every customer has one owner, and every decision is signed against its control.

Thank you for watching.
