import mammoth from 'mammoth';
const result = await mammoth.extractRawText({ path: 'data/Agentic-OTC-Narrative92-fabd2a.docx' });
console.log(result.value);
