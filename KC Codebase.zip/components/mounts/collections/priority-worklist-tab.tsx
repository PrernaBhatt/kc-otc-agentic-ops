"use client";

import { Fragment, useMemo, useState } from "react";
import { ArrowRight, CalendarCheck, Phone, Scale } from "lucide-react";

import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { customers } from "@/lib/data";
import { TODAY } from "@/lib/data/clock";
import { escalationRules } from "@/lib/data/collections";
import { buildAgingReportDoc, buildInvoiceDoc } from "@/lib/docs";
import {
  cashForecast30d,
  collectionsWorklist,
  formatMoney,
  type WorklistEntry,
} from "@/lib/selectors";
import { useOtcStore } from "@/lib/store";

/** Date helper: default promise date is one week from the demo date. */
function addDays(iso: string, days: number): string {
  const date = new Date(iso + "T00:00:00Z");
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}

/** Customer risk band from the account's churn-risk score (same source the AI
 *  ranking uses): High ≥ 0.20, Medium ≥ 0.12, else Low. */
function riskTier(score: number): "High" | "Medium" | "Low" {
  if (score >= 0.2) return "High";
  if (score >= 0.12) return "Medium";
  return "Low";
}

function churnFor(customerId: string): number {
  return (
    customers.find((c) => c.customerId === customerId)?.churnRiskScore ?? 0.15
  );
}

function RiskBadge({ score }: { score: number }) {
  const tier = riskTier(score);
  const cls =
    tier === "High"
      ? "bg-red-100 text-red-700 border-red-200"
      : tier === "Medium"
        ? "bg-[var(--warning)] text-[var(--warning-foreground)] border-transparent"
        : "bg-green-100 text-green-700 border-green-200";
  return (
    <Badge variant="outline" className={`whitespace-nowrap ${cls}`}>
      {tier}
    </Badge>
  );
}

function FlagBadge({ flag }: { flag?: string }) {
  if (!flag) {
    return <span className="text-xs text-muted-foreground">None</span>;
  }
  if (flag === "Promise to pay") {
    return (
      <Badge
        variant="outline"
        className="border-[var(--success)] text-[var(--success)]"
      >
        Promise to pay
      </Badge>
    );
  }
  if (flag === "Disputed") {
    return <Badge variant="destructive">Disputed</Badge>;
  }
  return (
    <Badge className="bg-[var(--warning)] text-[var(--warning-foreground)]">
      {flag}
    </Badge>
  );
}

export function PriorityWorklistTab() {
  const {
    allInvoices,
    ptps,
    deductionCases,
    capturePtp,
    runReturnStage,
    runOrderId,
    requestReturn,
  } = useOtcStore();

  // During a guided run at Collections, the run order sits at the top of the
  // worklist — settled early, so it just needs closing before returning.
  const runInvoice =
    runReturnStage === "collections"
      ? allInvoices.find((i) => i.orderId === runOrderId)
      : undefined;

  const worklist = useMemo(
    () => collectionsWorklist(allInvoices, ptps, deductionCases),
    [allInvoices, ptps, deductionCases]
  );
  const pastDueTotal = worklist.reduce(
    (sum, entry) => sum + entry.invoice.amount,
    0
  );
  const expectedCash = cashForecast30d(allInvoices, ptps);
  const honoredCount = ptps.filter((p) => p.status === "Honored").length;
  const promisesKeptPct =
    ptps.length > 0 ? Math.round((100 * honoredCount) / ptps.length) : 0;

  const topUnflaggedId = worklist.find((entry) => !entry.flag)?.invoice
    .invoiceId;

  const [captureFor, setCaptureFor] = useState<string | null>(null);
  const [promiseDate, setPromiseDate] = useState("");
  const [promiseAmount, setPromiseAmount] = useState("");
  const [escalatedIds, setEscalatedIds] = useState<Set<string>>(new Set());

  const openCaptureForm = (entry: WorklistEntry) => {
    setCaptureFor(entry.invoice.invoiceId);
    setPromiseDate(addDays(TODAY, 7));
    setPromiseAmount(String(entry.invoice.amount));
    // The form opens under a wide, horizontally scrolled table; bring it into
    // view so the click visibly does something.
    requestAnimationFrame(() => {
      const field = document.getElementById(`ptp-date-${entry.invoice.invoiceId}`);
      field?.scrollIntoView({ block: "center", inline: "start", behavior: "smooth" });
      field?.focus({ preventScroll: true });
    });
  };

  const submitPromise = (entry: WorklistEntry) => {
    const amount = Number(promiseAmount);
    capturePtp({
      ptpId: `PTP-${String(ptps.length + 1).padStart(3, "0")}`,
      customerId: entry.invoice.customerId,
      customerName: entry.invoice.customerName,
      invoiceId: entry.invoice.invoiceId,
      amount:
        Number.isFinite(amount) && amount > 0 ? amount : entry.invoice.amount,
      promisedDate: promiseDate || addDays(TODAY, 7),
      status: "Open",
      capturedOn: TODAY,
    });
    setCaptureFor(null);
  };

  const escalateToLegal = (invoiceId: string) => {
    setEscalatedIds((prev) => new Set(prev).add(invoiceId));
  };

  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-3 gap-4">
        <Card className="flex h-full flex-col">
          <CardContent>
            <div className="text-sm text-muted-foreground">
              Past-due balance
            </div>
            <div className="text-2xl font-bold text-foreground mt-1">
              {formatMoney(pastDueTotal)}
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              {worklist.length} overdue invoices on the worklist
            </div>
          </CardContent>
        </Card>
        <Card className="flex h-full flex-col">
          <CardContent>
            <div className="text-sm text-muted-foreground">
              Expected cash next 30 days
            </div>
            <div className="text-2xl font-bold text-foreground mt-1">
              {formatMoney(expectedCash)}
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              Open promises plus invoices likely to pay on time
            </div>
          </CardContent>
        </Card>
        <Card className="flex h-full flex-col">
          <CardContent>
            <div className="text-sm text-muted-foreground">Promises kept</div>
            <div className="text-2xl font-bold text-foreground mt-1">
              {promisesKeptPct}%
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              {honoredCount} of {ptps.length} promises to pay honored
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between gap-4">
            <div>
              <CardTitle className="text-lg">Priority worklist</CardTitle>
              <p className="text-sm text-muted-foreground mt-1">
                AI ranks who to contact first by amount, lateness, and customer
                risk. Every action below is your call.
              </p>
            </div>
            <SourceDocTrigger
              doc={buildAgingReportDoc(allInvoices)}
              label="View aging report"
            />
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>#</TableHead>
                <TableHead>Invoice</TableHead>
                <TableHead>Customer</TableHead>
                <TableHead>Customer risk</TableHead>
                <TableHead className="text-right">Amount</TableHead>
                <TableHead className="text-right">Days late</TableHead>
                <TableHead>Flag</TableHead>
                <TableHead>Recommended next action</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {runInvoice && (
                <TableRow className="bg-primary/5 hover:bg-primary/5">
                  <TableCell className="font-medium">★</TableCell>
                  <TableCell className="font-mono font-medium">
                    {runInvoice.invoiceId}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {runInvoice.customerName}
                      <Badge
                        variant="outline"
                        className="border-primary/40 text-primary text-xs whitespace-nowrap"
                      >
                        Guided run
                      </Badge>
                    </div>
                  </TableCell>
                  <TableCell>
                    <RiskBadge score={churnFor(runInvoice.customerId)} />
                  </TableCell>
                  <TableCell className="text-right font-medium">
                    {formatMoney(runInvoice.amount)}
                  </TableCell>
                  <TableCell className="text-right">—</TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className="border-[var(--success)] text-[var(--success)]"
                    >
                      Settled
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="max-w-[240px] whitespace-normal text-sm leading-snug text-muted-foreground">
                      Paid early — nothing outstanding to collect
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      size="sm"
                      className="whitespace-nowrap"
                      onClick={requestReturn}
                    >
                      <CalendarCheck className="h-4 w-4" />
                      Close &amp; return
                    </Button>
                  </TableCell>
                </TableRow>
              )}
              {worklist.map((entry, index) => {
                const invoiceId = entry.invoice.invoiceId;
                const isEscalated = escalatedIds.has(invoiceId);
                return (
                  <Fragment key={invoiceId}>
                    <TableRow>
                      <TableCell className="font-medium">{index + 1}</TableCell>
                      <TableCell className="font-mono font-medium">
                        {invoiceId}
                      </TableCell>
                      <TableCell>{entry.invoice.customerName}</TableCell>
                      <TableCell>
                        <RiskBadge score={entry.riskScore} />
                      </TableCell>
                      <TableCell className="text-right font-medium">
                        {formatMoney(entry.invoice.amount)}
                      </TableCell>
                      <TableCell className="text-right">
                        {entry.daysLate}
                      </TableCell>
                      <TableCell>
                        <FlagBadge flag={entry.flag} />
                      </TableCell>
                      <TableCell>
                        <div className="max-w-[240px] whitespace-normal text-sm leading-snug text-muted-foreground">
                          {entry.nextAction}
                        </div>
                      </TableCell>
                      <TableCell className="text-right align-top">
                        <div className="flex items-center justify-end gap-2 whitespace-nowrap">
                          {invoiceId === topUnflaggedId && !entry.flag && (
                            <Button
                              size="sm"
                              onClick={() => openCaptureForm(entry)}
                            >
                              <Phone className="h-4 w-4" />
                              Call &amp; capture promise
                            </Button>
                          )}
                          {entry.flag === "Disputed" &&
                            (isEscalated ? (
                              <Badge
                                variant="outline"
                                className="border-[var(--warning)] text-[var(--warning)]"
                              >
                                Escalated
                              </Badge>
                            ) : (
                              <Button
                                size="sm"
                                variant="outline"
                                className="whitespace-nowrap"
                                onClick={() => escalateToLegal(invoiceId)}
                              >
                                <Scale className="h-4 w-4" />
                                Escalate
                              </Button>
                            ))}
                          <SourceDocTrigger
                            doc={buildInvoiceDoc(entry.invoice)}
                            label="View invoice"
                            variant="ghost"
                          />
                        </div>
                      </TableCell>
                    </TableRow>
                    {captureFor === invoiceId && (
                      <TableRow className="bg-primary/5 hover:bg-primary/5">
                        <TableCell colSpan={9}>
                          <div className="flex flex-wrap items-end gap-4 py-1">
                            <div className="text-sm font-medium text-foreground">
                              Capture the customer&apos;s promise to pay
                            </div>
                            <div>
                              <Label
                                htmlFor={`ptp-date-${invoiceId}`}
                                className="text-xs text-muted-foreground"
                              >
                                Promised payment date
                              </Label>
                              <Input
                                id={`ptp-date-${invoiceId}`}
                                type="date"
                                value={promiseDate}
                                onChange={(e) => setPromiseDate(e.target.value)}
                                className="mt-1 w-44"
                              />
                            </div>
                            <div>
                              <Label
                                htmlFor={`ptp-amount-${invoiceId}`}
                                className="text-xs text-muted-foreground"
                              >
                                Promised amount
                              </Label>
                              <Input
                                id={`ptp-amount-${invoiceId}`}
                                type="number"
                                value={promiseAmount}
                                onChange={(e) =>
                                  setPromiseAmount(e.target.value)
                                }
                                className="mt-1 w-44"
                              />
                            </div>
                            <Button
                              size="sm"
                              onClick={() => submitPromise(entry)}
                            >
                              <CalendarCheck className="h-4 w-4" />
                              Save promise to pay
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => setCaptureFor(null)}
                            >
                              Cancel
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </Fragment>
                );
              })}
            </TableBody>
          </Table>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Escalation rules</CardTitle>
          <p className="text-sm text-muted-foreground">
            When a balance crosses one of these lines, AI flags it and routes
            it to the right decision maker.
          </p>
        </CardHeader>
        <CardContent className="space-y-3">
          {escalationRules.map((rule) => (
            <div
              key={rule.id}
              className="flex items-center justify-between gap-4 p-3 bg-muted/50 rounded-lg"
            >
              <span className="text-sm text-foreground">{rule.trigger}</span>
              <div className="flex items-center gap-2 shrink-0">
                <ArrowRight className="h-4 w-4 text-muted-foreground" />
                <Badge variant="outline">{rule.escalateTo}</Badge>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
