"use client";

import { Grid3x3 } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CountUp } from "@/components/ui/count-up";
import {
  arDistribution,
  formatMoney,
  formatMoneyCompact,
} from "@/lib/selectors";
import { useOtcStore } from "@/lib/store";

/**
 * Where the receivables sit (be-creative): open AR cross-tabbed by business
 * unit (rows) and geography (columns). Each cell is heat-shaded by size, so the
 * concentration jumps out — Personal Care in EMEA carries the most. Row and column
 * totals and the grand total all reconcile to open receivables. Cells fade in
 * with a stagger on mount.
 */
export function ArDistributionMatrix() {
  const { allInvoices } = useOtcStore();
  const dist = arDistribution(allInvoices);

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center gap-2">
          <Grid3x3 className="h-4 w-4 text-primary" />
          Where the receivables sit
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Open balances by business unit and geography — the concentration the
          reserve has to cover
        </p>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full border-separate border-spacing-1 text-sm">
            <thead>
              <tr>
                <th className="p-1 text-left text-xs font-medium text-muted-foreground">
                  Business unit
                </th>
                {dist.regions.map((region) => (
                  <th
                    key={region}
                    className="p-1 text-right text-xs font-medium text-muted-foreground whitespace-nowrap"
                  >
                    {region}
                  </th>
                ))}
                <th className="p-1 text-right text-xs font-semibold text-foreground whitespace-nowrap">
                  Unit total
                </th>
              </tr>
            </thead>
            <tbody>
              {dist.units.map((unit, ui) => (
                <tr key={unit}>
                  <td className="p-1 pr-3 font-medium text-foreground whitespace-nowrap">
                    {unit}
                  </td>
                  {dist.regions.map((region, ri) => {
                    const value = dist.matrix[ui][ri];
                    const intensity = value / dist.maxCell;
                    return (
                      <td key={region} className="p-0.5">
                        <div
                          className="animate-enter rounded-md px-2 py-2 text-right font-medium tabular-nums"
                          style={{
                            animationDelay: `${(ui * dist.regions.length + ri) * 45}ms`,
                            backgroundColor:
                              value === 0
                                ? "transparent"
                                : `color-mix(in srgb, var(--primary) ${Math.round(
                                    12 + intensity * 60
                                  )}%, transparent)`,
                            color:
                              intensity > 0.55
                                ? "var(--primary-foreground)"
                                : "var(--foreground)",
                          }}
                        >
                          {value === 0 ? (
                            <span className="text-muted-foreground/40">—</span>
                          ) : (
                            formatMoneyCompact(value)
                          )}
                        </div>
                      </td>
                    );
                  })}
                  <td className="p-1 text-right font-semibold text-foreground tabular-nums whitespace-nowrap">
                    {formatMoneyCompact(dist.unitTotals[ui])}
                  </td>
                </tr>
              ))}
              <tr>
                <td className="p-1 pr-3 text-xs font-semibold text-muted-foreground">
                  Geography total
                </td>
                {dist.regionTotals.map((rt, ri) => (
                  <td
                    key={ri}
                    className="p-1 text-right font-semibold text-foreground tabular-nums whitespace-nowrap"
                  >
                    {formatMoneyCompact(rt)}
                  </td>
                ))}
                <td className="p-1 text-right font-bold text-primary tabular-nums whitespace-nowrap">
                  <CountUp
                    value={dist.total}
                    durationMs={900}
                    format={(n) => formatMoneyCompact(n)}
                  />
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <p className="mt-3 text-xs text-muted-foreground">
          Grand total {formatMoney(dist.total)} — the same open receivables the
          aging table below reserves against, sliced two ways instead of by age.
        </p>
      </CardContent>
    </Card>
  );
}
