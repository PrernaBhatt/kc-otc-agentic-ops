"use client";

import { useMemo, useState } from "react";
import { CircleCheck, ShieldCheck, User } from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import { ArDistributionMatrix } from "@/components/mounts/collections/ar-distribution-matrix";
import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  specificReserves,
  writeOffControllerLimit,
} from "@/lib/data/provisions";
import { buildProvisionDoc } from "@/lib/docs";
import {
  agingRows,
  bucketSummaries,
  formatMoney,
  provisionSummary,
} from "@/lib/selectors";
import { useOtcStore } from "@/lib/store";

function signedMoney(value: number): string {
  return value < 0 ? `-${formatMoney(Math.abs(value))}` : formatMoney(value);
}

export function ProvisionTab() {
  const { allInvoices, provisionStatus, provisionApprover, approveProvision } =
    useOtcStore();

  const summary = useMemo(() => provisionSummary(allInvoices), [allInvoices]);
  const buckets = useMemo(() => bucketSummaries(allInvoices), [allInvoices]);
  const openInvoiceIds = useMemo(
    () => new Set(agingRows(allInvoices).map((r) => r.invoice.invoiceId)),
    [allInvoices]
  );
  const activeSpecifics = specificReserves.filter((s) =>
    openInvoiceIds.has(s.invoiceId)
  );

  const [writeOffSentIds, setWriteOffSentIds] = useState<Set<string>>(
    new Set()
  );
  const sendWriteOffRecommendation = (invoiceId: string) => {
    setWriteOffSentIds((prev) => new Set(prev).add(invoiceId));
  };

  const topUp = summary.topUp;
  const releaseAmount = Math.abs(topUp);
  const isApproved = provisionStatus === "Approved";

  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-3 gap-4">
        <Card className="flex h-full flex-col">
          <CardContent>
            <div className="text-sm text-muted-foreground">
              Reserve required
            </div>
            <div className="text-2xl font-bold text-foreground mt-1">
              {formatMoney(summary.requiredAllowance)}
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              Age-based reserves plus balances reserved in full
            </div>
          </CardContent>
        </Card>
        <Card className="flex h-full flex-col">
          <CardContent>
            <div className="text-sm text-muted-foreground">
              Reserve on books
            </div>
            <div className="text-2xl font-bold text-foreground mt-1">
              {formatMoney(summary.existingAllowance)}
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              Allowance balance before this month&apos;s review
            </div>
          </CardContent>
        </Card>
        <Card className="flex h-full flex-col">
          <CardContent>
            <div className="text-sm text-muted-foreground">
              Adjustment to record
            </div>
            <div className="text-2xl font-bold text-foreground mt-1">
              {signedMoney(topUp)}
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              {topUp >= 0
                ? "Top-up needed to reach the required reserve"
                : "The reserve can be partly released this month"}
            </div>
          </CardContent>
        </Card>
      </div>

      <ArDistributionMatrix />

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between gap-4">
            <div>
              <CardTitle className="text-lg">
                Aging and loss rates
              </CardTitle>
              <p className="text-sm text-muted-foreground mt-1">
                Each age group carries an expected loss rate. Disputed balances
                are reserved in full instead.
              </p>
            </div>
            <SourceDocTrigger
              doc={buildProvisionDoc(allInvoices)}
              label="View calculation sheet"
            />
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Age group</TableHead>
                <TableHead className="text-right">Balance</TableHead>
                <TableHead className="text-right">Loss rate</TableHead>
                <TableHead className="text-right">Reserve</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {buckets.map((bucket) => (
                <TableRow key={bucket.bucket}>
                  <TableCell className="font-medium">{bucket.bucket}</TableCell>
                  <TableCell className="text-right">
                    {formatMoney(bucket.balance)}
                  </TableCell>
                  <TableCell className="text-right">
                    {Math.round(bucket.lossRate * 100)}%
                  </TableCell>
                  <TableCell className="text-right font-medium">
                    {formatMoney(bucket.rateReserve)}
                  </TableCell>
                </TableRow>
              ))}
              {activeSpecifics.map((reserve) => (
                <TableRow
                  key={reserve.invoiceId}
                  className="bg-amber-50 hover:bg-amber-50 border-l-4 border-l-amber-500"
                >
                  <TableCell className="font-medium">
                    Specific reserve — {reserve.invoiceId} (
                    {reserve.customerName})
                    <div className="text-xs text-muted-foreground font-normal mt-0.5">
                      {reserve.reason}
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    {formatMoney(reserve.amount)}
                  </TableCell>
                  <TableCell className="text-right">Reserved in full</TableCell>
                  <TableCell className="text-right font-medium">
                    {formatMoney(reserve.amount)}
                  </TableCell>
                </TableRow>
              ))}
              <TableRow className="font-semibold">
                <TableCell>Required reserve</TableCell>
                <TableCell className="text-right" />
                <TableCell className="text-right" />
                <TableCell className="text-right">
                  {formatMoney(summary.requiredAllowance)}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-4">
        <Card className="flex h-full flex-col">
          <CardHeader>
            <CardTitle className="text-lg">Record the adjustment</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-1 flex-col space-y-3">
            <div className="p-3 bg-muted/50 rounded-lg space-y-2">
              {topUp >= 0 ? (
                <>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">
                      Increase bad debt expense by
                    </span>
                    <span className="font-medium text-foreground">
                      {formatMoney(topUp)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">
                      Increase the reserve by
                    </span>
                    <span className="font-medium text-foreground">
                      {formatMoney(topUp)}
                    </span>
                  </div>
                </>
              ) : (
                <>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">
                      Release from the reserve
                    </span>
                    <span className="font-medium text-foreground">
                      {formatMoney(releaseAmount)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">
                      Reduce bad debt expense by
                    </span>
                    <span className="font-medium text-foreground">
                      {formatMoney(releaseAmount)}
                    </span>
                  </div>
                </>
              )}
            </div>
            {isApproved ? (
              <div className="flex items-center gap-2 text-sm text-[var(--success)]">
                <CircleCheck className="h-4 w-4" />
                Recorded after approval — audit copy retained
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">
                Nothing is recorded until the Controller approves — bad debt approval is a retained decision.
              </p>
            )}
            <div className="mt-auto pt-2">
              <SourceDocTrigger
                doc={buildProvisionDoc(allInvoices)}
                label="View calculation sheet"
                variant="ghost"
              />
            </div>
          </CardContent>
        </Card>

        <Card className="flex h-full flex-col">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <AgentIcon type="orchestrator" size="sm" className="text-primary" />
              Controller approval
            </CardTitle>
          </CardHeader>
          <CardContent className="flex flex-1 flex-col space-y-3">
            <p className="text-sm text-muted-foreground">
              AI prepared this month&apos;s provision. Controller approval
              required before anything is recorded.
            </p>
            <div className="flex items-center justify-between gap-4 p-3 bg-muted/50 rounded-lg">
              <div className="flex items-center gap-2">
                <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                  <User className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <div className="text-sm font-medium text-foreground">
                    {provisionApprover}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Controller
                  </div>
                </div>
              </div>
              {isApproved ? (
                <Badge
                  variant="outline"
                  className="border-[var(--success)] text-[var(--success)]"
                >
                  Approved
                </Badge>
              ) : (
                <Badge className="bg-[var(--warning)] text-[var(--warning-foreground)]">
                  Awaiting approval
                </Badge>
              )}
            </div>
            <div className="mt-auto pt-2">
              <Button
                className="w-full"
                onClick={approveProvision}
                disabled={isApproved}
              >
                <ShieldCheck className="h-4 w-4" />
                {isApproved ? "Approved" : "Approve as Controller"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Write-off authority</CardTitle>
          <p className="text-sm text-muted-foreground">
            Write-offs against the reserve need Controller approval up to{" "}
            {formatMoney(writeOffControllerLimit)} and CFO approval above that.
          </p>
        </CardHeader>
        <CardContent className="space-y-3">
          {activeSpecifics.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              No write-off candidates right now.
            </p>
          ) : (
            activeSpecifics.map((reserve) => (
              <div
                key={reserve.invoiceId}
                className="flex flex-wrap items-center justify-between gap-4 p-3 border rounded-lg"
              >
                <div>
                  <div className="text-sm font-medium text-foreground">
                    {reserve.invoiceId} — {reserve.customerName} ·{" "}
                    {formatMoney(reserve.amount)}
                  </div>
                  <div className="text-xs text-muted-foreground mt-0.5">
                    {activeSpecifics.length === 1
                      ? "AI flags this disputed balance as the only current write-off candidate."
                      : "AI flags this disputed balance as a write-off candidate."}
                    {reserve.amount > writeOffControllerLimit &&
                      " Above the Controller limit, so CFO approval is also required."}
                  </div>
                </div>
                {writeOffSentIds.has(reserve.invoiceId) ? (
                  <Badge
                    variant="outline"
                    className="border-[var(--success)] text-[var(--success)]"
                  >
                    Recommendation sent to Controller
                  </Badge>
                ) : (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => sendWriteOffRecommendation(reserve.invoiceId)}
                  >
                    Recommend write-off
                  </Button>
                )}
              </div>
            ))
          )}
        </CardContent>
      </Card>
    </div>
  );
}
