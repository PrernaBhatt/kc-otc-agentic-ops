"use client";

import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { CalendarClock, CheckCircle2, CreditCard, Split, X } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TODAY } from "@/lib/data/clock";
import type { Invoice } from "@/lib/data/types";
import { formatMoney } from "@/lib/selectors";
import { useOtcStore } from "@/lib/store";

function addDays(iso: string, n: number): string {
  const d = new Date(iso + "T00:00:00Z");
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}
function longDate(iso: string): string {
  return new Date(iso + "T00:00:00Z").toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    timeZone: "UTC",
  });
}

function Modal({
  title,
  onClose,
  children,
}: {
  title: string;
  onClose: () => void;
  children: React.ReactNode;
}) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  if (!mounted) return null;
  return createPortal(
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-6"
      onClick={onClose}
    >
      <div
        className="w-full max-w-sm rounded-xl border bg-card shadow-2xl animate-modal-in"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b px-5 py-3">
          <span className="text-sm font-semibold">{title}</span>
          <button
            type="button"
            onClick={onClose}
            className="text-muted-foreground/70 hover:text-foreground"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="px-5 py-4">{children}</div>
      </div>
    </div>,
    document.body
  );
}

/**
 * The real actions behind the dunning nudge: record an early payment (marks the
 * invoice paid everywhere), set up a split plan (captured as promises to pay),
 * or log a promise to pay for a date. Each shows its payload and confirmation —
 * no placeholder buttons.
 */
export function NudgeActions({ invoice }: { invoice?: Invoice }) {
  const { markInvoicePaid, capturePtp } = useOtcStore();
  const [modal, setModal] = useState<null | "pay" | "split">(null);
  const [outcome, setOutcome] = useState<null | "paid" | "split" | "promise">(
    null
  );
  const [promiseOpen, setPromiseOpen] = useState(false);
  const [promiseDate, setPromiseDate] = useState(addDays(TODAY, 14));

  if (!invoice) return null;
  const amount = invoice.amount;
  const per = Math.round(amount / 3);
  const installments = [
    { n: 1, amount: per, date: addDays(TODAY, 30) },
    { n: 2, amount: per, date: addDays(TODAY, 60) },
    { n: 3, amount: amount - per * 2, date: addDays(TODAY, 90) },
  ];

  const recordPay = () => {
    markInvoicePaid(invoice.invoiceId);
    setOutcome("paid");
    setModal(null);
  };
  const recordSplit = () => {
    installments.forEach((inst, i) =>
      capturePtp({
        ptpId: `PTP-SPL-${invoice.invoiceId}-${i}`,
        customerId: invoice.customerId,
        customerName: invoice.customerName,
        invoiceId: invoice.invoiceId,
        amount: inst.amount,
        promisedDate: inst.date,
        status: "Open",
        capturedOn: TODAY,
      })
    );
    setOutcome("split");
    setModal(null);
  };
  const recordPromise = () => {
    capturePtp({
      ptpId: `PTP-${invoice.invoiceId}-${promiseDate}`,
      customerId: invoice.customerId,
      customerName: invoice.customerName,
      invoiceId: invoice.invoiceId,
      amount,
      promisedDate: promiseDate,
      status: "Open",
      capturedOn: TODAY,
    });
    setOutcome("promise");
    setPromiseOpen(false);
  };

  if (outcome) {
    const msg =
      outcome === "paid"
        ? `Payment of ${formatMoney(amount)} recorded — ${invoice.invoiceId} paid early.`
        : outcome === "split"
          ? "Split plan set — three installments captured as promises to pay."
          : `Promise to pay recorded for ${longDate(promiseDate)}.`;
    return (
      <div className="flex items-start gap-2 rounded-lg border border-[var(--success)]/30 bg-[var(--success)]/5 p-3 text-sm text-[var(--success)] animate-enter">
        <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
        <span>
          {msg}{" "}
          <span className="text-muted-foreground">
            Reflected across the worklist, cash forecast and aging.
          </span>
        </span>
      </div>
    );
  }

  return (
    <>
      <div className="flex gap-2">
        <Button className="flex-1 whitespace-nowrap" onClick={() => setModal("pay")}>
          <CreditCard className="h-4 w-4 mr-1" />
          Pay Now
        </Button>
        <Button
          variant="outline"
          className="flex-1 whitespace-nowrap bg-transparent"
          onClick={() => setModal("split")}
        >
          <Split className="h-4 w-4 mr-1" />
          Request Split Plan
        </Button>
      </div>

      <div className="rounded-lg border p-3">
        <label className="flex cursor-pointer items-center gap-2">
          <input
            type="checkbox"
            checked={promiseOpen}
            onChange={(e) => setPromiseOpen(e.target.checked)}
            className="rounded border-border"
          />
          <span className="text-sm font-medium text-foreground">
            Capture Promise to Pay
          </span>
        </label>
        {!promiseOpen && (
          <div className="mt-1 pl-6 text-xs text-muted-foreground">
            Record the customer&apos;s commitment to pay by a specific date
          </div>
        )}
        {promiseOpen && (
          <div className="mt-3 flex flex-wrap items-end gap-2 pl-6">
            <div>
              <div className="mb-1 text-xs text-muted-foreground">
                Promised date
              </div>
              <input
                type="date"
                value={promiseDate}
                onChange={(e) => setPromiseDate(e.target.value)}
                className="rounded-md border bg-background px-2 py-1 text-sm"
              />
            </div>
            <Button size="sm" onClick={recordPromise} className="whitespace-nowrap">
              <CalendarClock className="h-4 w-4 mr-1" />
              Record promise
            </Button>
          </div>
        )}
      </div>

      {modal === "pay" && (
        <Modal title="Record early payment" onClose={() => setModal(null)}>
          <div className="space-y-3">
            <div className="rounded-lg bg-muted/50 p-3 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Invoice</span>
                <span className="font-mono font-medium">{invoice.invoiceId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Customer</span>
                <span className="font-medium">{invoice.customerName}</span>
              </div>
              <div className="mt-1 flex justify-between border-t pt-1">
                <span className="text-muted-foreground">Amount</span>
                <span className="font-bold">{formatMoney(amount)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Method</span>
                <span className="font-medium">Bank transfer</span>
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              Recording the payment clears {invoice.invoiceId} from open
              receivables and updates the forecast and aging.
            </p>
            <div className="flex justify-end gap-2">
              <Button
                variant="ghost"
                onClick={() => setModal(null)}
                className="whitespace-nowrap"
              >
                Cancel
              </Button>
              <Button onClick={recordPay} className="whitespace-nowrap">
                <CheckCircle2 className="h-4 w-4 mr-1" />
                Record payment
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {modal === "split" && (
        <Modal title="Set up a split payment plan" onClose={() => setModal(null)}>
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Spread {formatMoney(amount)} on {invoice.invoiceId} across three
              monthly installments:
            </p>
            <div className="space-y-1.5">
              {installments.map((inst) => (
                <div
                  key={inst.n}
                  className="flex items-center justify-between rounded-md border px-3 py-2 text-sm"
                >
                  <span className="flex items-center gap-2">
                    <Badge variant="outline" className="text-xs">
                      #{inst.n}
                    </Badge>
                    {longDate(inst.date)}
                  </span>
                  <span className="font-semibold">{formatMoney(inst.amount)}</span>
                </div>
              ))}
            </div>
            <div className="flex justify-end gap-2">
              <Button
                variant="ghost"
                onClick={() => setModal(null)}
                className="whitespace-nowrap"
              >
                Cancel
              </Button>
              <Button onClick={recordSplit} className="whitespace-nowrap">
                <CheckCircle2 className="h-4 w-4 mr-1" />
                Set up plan
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </>
  );
}
