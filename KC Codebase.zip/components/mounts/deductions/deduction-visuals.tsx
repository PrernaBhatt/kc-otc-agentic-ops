"use client";

import { useEffect, useState } from "react";
import { ArrowDown, CircleCheck, Sparkles, TriangleAlert, X } from "lucide-react";

import { CountUp } from "@/components/ui/count-up";
import { formatUsd } from "@/lib/chargeback-selectors";
import type {
  ClaimRecoilLink,
  ClassificationStep,
  RecoveryOption,
  ShortPayPosition,
} from "@/lib/deduction-selectors";
import { cn } from "@/lib/utils";

function useMounted(delayMs = 60) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    const id = setTimeout(() => setMounted(true), delayMs);
    return () => clearTimeout(id);
  }, [delayMs]);
  return mounted;
}

/**
 * The short payment.
 *
 * The bar is the invoice. The filled part is what arrived. The notch is what
 * did not — and the notch is labelled with the exact amount we rejected on the
 * chargeback claim. The two being the same is the entire finding, so they are
 * put on the same line rather than in two separate cards.
 */
export function PaymentShortfallBar({
  position,
  matchedClaimAmount,
  matchesExactly,
}: {
  position: ShortPayPosition;
  matchedClaimAmount: number;
  matchesExactly: boolean;
}) {
  const mounted = useMounted();
  const paidPct = position.invoiced === 0 ? 0 : (position.paid / position.invoiced) * 100;

  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-3 flex items-baseline justify-between gap-3">
        <h4 className="text-sm font-semibold">Payment against invoice</h4>
        <span className="text-xs text-muted-foreground whitespace-nowrap">
          {position.remittance?.remittanceId} · {position.remittance?.receivedDate}
        </span>
      </div>

      <div className="flex h-14 w-full overflow-hidden rounded-lg border-2">
        <div
          className="flex items-center justify-center bg-[var(--success)]/25 transition-all duration-700 ease-out motion-reduce:transition-none"
          style={{ width: mounted ? `${paidPct}%` : "0%" }}
        >
          <span className="px-1 text-center text-sm font-semibold text-green-800 tabular-nums">
            {formatUsd(position.paid)} paid
          </span>
        </div>
        <div
          className="flex flex-1 items-center justify-center transition-all duration-500 ease-out motion-reduce:transition-none"
          style={{
            opacity: mounted ? 1 : 0,
            transitionDelay: "600ms",
            backgroundImage:
              "repeating-linear-gradient(45deg, rgba(220,38,38,0.20) 0 6px, transparent 6px 12px)",
          }}
        >
          <span className="px-1 text-center text-sm font-semibold text-red-700 tabular-nums">
            {formatUsd(position.withheld)} withheld
          </span>
        </div>
      </div>

      <p className="mt-2 text-xs text-muted-foreground">
        Invoice {formatUsd(position.invoiced)} less {formatUsd(position.withheld)}{" "}
        withheld equals {formatUsd(position.paid)} paid.{" "}
        {position.reconciles ? "Reconciles." : "Does not reconcile."}
      </p>

      {matchesExactly && (
        <div
          className="mt-3 flex items-center gap-2 rounded-lg border-2 border-red-300 bg-red-50 px-3 py-2 transition-opacity duration-500 motion-reduce:transition-none"
          style={{ opacity: mounted ? 1 : 0, transitionDelay: "1000ms" }}
        >
          <TriangleAlert className="h-4 w-4 shrink-0 text-red-600" />
          <p className="text-xs text-red-800">
            Amount withheld:{" "}
            <strong className="tabular-nums">{formatUsd(matchedClaimAmount)}</strong>{" "}
            — identical to the amount rejected on the chargeback claim.
          </p>
        </div>
      )}

      {position.remittance && (
        <p className="mt-3 rounded border-l-2 border-muted-foreground/40 bg-muted/30 px-3 py-2 text-xs italic text-muted-foreground">
          &ldquo;{position.remittance.customerNote}&rdquo; — remittance note
        </p>
      )}
    </div>
  );
}

/**
 * How the AI reached its reading.
 *
 * A reason code with a confidence percentage explains nothing. The candidates
 * that were eliminated, and why each one failed, are the explanation — so they
 * are shown falling away one at a time until one is left standing.
 */
export function ReasonCodeFunnel({
  steps,
  confidence,
}: {
  steps: ClassificationStep[];
  confidence: number;
}) {
  const mounted = useMounted();

  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-3 flex items-start justify-between gap-4">
        <div>
          <h4 className="text-sm font-semibold">Deduction classification</h4>
          <p className="mt-0.5 text-xs text-muted-foreground">
            Candidate reasons, and the evidence that ruled each one out.
          </p>
        </div>
        <div className="shrink-0 text-right">
          <div className="text-2xl font-bold leading-none tabular-nums">
            <CountUp
              value={confidence * 100}
              format={(n) => `${Math.round(n)}%`}
              durationMs={1200}
            />
          </div>
          <div className="text-xs text-muted-foreground">confidence</div>
        </div>
      </div>

      <div className="space-y-2">
        {steps.map((step, i) => (
          <div
            key={step.label}
            className={cn(
              "flex items-start gap-3 rounded-lg border px-3 py-2 transition-all duration-400 ease-out motion-reduce:transition-none",
              step.eliminated
                ? "border-dashed bg-muted/30 opacity-60"
                : "border-[var(--success)]/50 bg-[var(--success)]/5"
            )}
            style={{
              opacity: mounted ? (step.eliminated ? 0.6 : 1) : 0,
              transform: mounted ? "translateX(0)" : "translateX(-10px)",
              transitionDelay: `${i * 160}ms`,
            }}
          >
            <span
              className={cn(
                "mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full",
                step.eliminated
                  ? "bg-muted-foreground/30 text-white"
                  : "bg-[var(--success)] text-white"
              )}
            >
              {step.eliminated ? (
                <X className="h-2.5 w-2.5" />
              ) : (
                <CircleCheck className="h-3 w-3" />
              )}
            </span>
            <div className="min-w-0">
              <p
                className={cn(
                  "text-xs font-medium",
                  step.eliminated && "line-through"
                )}
              >
                {step.label}
              </p>
              <p className="text-xs text-muted-foreground">{step.why}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/**
 * Where the deduction came from.
 *
 * The claim was submitted, we rejected it, and the money was taken anyway.
 * Drawn as a chain that doubles back, because the point is that this is not a
 * new dispute — it is the old one arriving by another route.
 */
export function ChargebackRecoilTrace({
  link,
  claimId,
  customerName,
}: {
  link: ClaimRecoilLink;
  claimId: string;
  customerName: string;
}) {
  const mounted = useMounted();

  const nodes = [
    {
      key: "submitted",
      label: `Claim ${claimId} submitted`,
      value: formatUsd(link.claimAmount),
      tone: "neutral" as const,
    },
    {
      key: "rejected",
      label: `Rejected ${link.rejectionDate}`,
      value: formatUsd(link.rejectedAmount),
      tone: "reject" as const,
    },
    {
      key: "taken",
      label: `Taken by deduction ${link.daysToDeduction} days later`,
      value: formatUsd(link.deductionAmount),
      tone: "taken" as const,
    },
  ];

  return (
    <div className="rounded-xl border bg-card p-4">
      <h4 className="text-sm font-semibold">Source of the deduction</h4>

      <div className="mt-4 space-y-2">
        {nodes.map((n, i) => (
          <div key={n.key}>
            <div
              className={cn(
                "flex items-center justify-between gap-3 rounded-lg border px-3 py-2.5 transition-all duration-400 ease-out motion-reduce:transition-none",
                n.tone === "reject" && "border-red-200 bg-red-50",
                n.tone === "taken" && "border-amber-200 bg-amber-50"
              )}
              style={{
                opacity: mounted ? 1 : 0,
                transform: mounted ? "translateY(0)" : "translateY(8px)",
                transitionDelay: `${i * 200}ms`,
              }}
            >
              <span className="text-xs font-medium">{n.label}</span>
              <span className="shrink-0 text-sm font-bold tabular-nums">
                {n.value}
              </span>
            </div>
            {i < nodes.length - 1 && (
              <div className="flex justify-center py-0.5">
                <ArrowDown className="h-3.5 w-3.5 text-muted-foreground" />
              </div>
            )}
          </div>
        ))}
      </div>

      <div
        className={cn(
          "mt-3 flex items-center gap-2 rounded-lg px-3 py-2 transition-opacity duration-500 motion-reduce:transition-none",
          link.matchesExactly
            ? "bg-red-50 text-red-800"
            : "bg-amber-50 text-amber-800"
        )}
        style={{ opacity: mounted ? 1 : 0, transitionDelay: "700ms" }}
      >
        <CircleCheck className="h-4 w-4 shrink-0" />
        <p className="text-xs">
          {link.matchesExactly
            ? `Same wholesaler and the same amount, ${link.daysToDeduction} days after the rejection.`
            : "The amounts differ. Review before issuing correspondence."}
          {link.noteNamesTheClaim
            ? ` ${customerName}'s remittance note names the claim.`
            : " The remittance advice carries no claim reference."}
        </p>
      </div>
    </div>
  );
}

/**
 * The recovery options, ranked.
 *
 * Two axes matter and they pull against each other: how much comes back, and
 * what it costs the relationship. Showing both together is the decision; a
 * list of five buttons is not.
 */
export function RecoveryLadder({
  options,
  chosen,
  pending,
  onChoose,
  disabled,
}: {
  options: RecoveryOption[];
  chosen?: string;
  /** Selected but not yet confirmed — its consequences are on screen. */
  pending?: string;
  onChoose: (label: string) => void;
  disabled?: boolean;
}) {
  const max = Math.max(...options.map((o) => o.expectedRecovery), 1);

  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-3">
        <h4 className="text-sm font-semibold">Recovery options</h4>
        <p className="mt-0.5 text-xs text-muted-foreground">
          Ranked by expected recovery against relationship cost. Selecting one
          shows what it commits to; nothing is recorded until you confirm.
        </p>
      </div>

      <div className="space-y-2">
        {[...options]
          .sort((a, b) => b.expectedRecovery - a.expectedRecovery)
          .map((o) => {
            const picked = chosen === o.label;
            const awaiting = !chosen && pending === o.label;
            return (
              <button
                key={o.label}
                type="button"
                disabled={disabled || Boolean(chosen)}
                onClick={() => onChoose(o.label)}
                className={cn(
                  "w-full rounded-lg border p-3 text-left transition-all",
                  picked && "border-[var(--success)] bg-[var(--success)]/5",
                  awaiting && "border-primary ring-1 ring-primary/40",
                  !chosen && !disabled && "hover:ring-1 hover:ring-primary/40",
                  (disabled || (chosen && !picked)) && "opacity-55"
                )}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="flex items-center gap-1.5 text-sm font-medium">
                    {o.label}
                    {o.recommended && (
                      <span className="inline-flex items-center gap-1 whitespace-nowrap rounded bg-primary/10 px-1.5 py-0.5 text-xs font-medium text-primary">
                        <Sparkles className="h-3 w-3" />
                        AI recommended
                      </span>
                    )}
                    {picked && (
                      <span className="whitespace-nowrap rounded bg-[var(--success)]/15 px-1.5 py-0.5 text-xs font-medium text-[var(--success)]">
                        Chosen by you
                      </span>
                    )}
                    {awaiting && (
                      <span className="whitespace-nowrap rounded bg-primary/10 px-1.5 py-0.5 text-xs font-medium text-primary">
                        Awaiting your confirmation
                      </span>
                    )}
                  </span>
                  <span className="shrink-0 text-sm font-semibold tabular-nums">
                    {formatUsd(o.expectedRecovery)}
                  </span>
                </div>
                <div className="mt-1.5 flex items-center gap-2">
                  <div className="h-1.5 flex-1 overflow-hidden rounded bg-muted">
                    <div
                      className="h-full bg-[var(--success)]/50"
                      style={{ width: `${(o.expectedRecovery / max) * 100}%` }}
                    />
                  </div>
                  <span
                    className={cn(
                      "whitespace-nowrap rounded px-1.5 py-0.5 text-xs",
                      o.relationshipCost === "High" &&
                        "bg-red-50 text-red-700",
                      o.relationshipCost === "Medium" &&
                        "bg-amber-50 text-amber-700",
                      o.relationshipCost === "Low" &&
                        "bg-muted text-muted-foreground"
                    )}
                  >
                    {o.relationshipCost} relationship cost
                  </span>
                </div>
                <p className="mt-1 text-xs text-muted-foreground">{o.note}</p>
              </button>
            );
          })}
      </div>
    </div>
  );
}
