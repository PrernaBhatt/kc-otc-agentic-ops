"use client";

import { formatUsd } from "@/lib/chargeback-selectors";
import { cn } from "@/lib/utils";

/**
 * What a deduction does to gross-to-net — which is not the same as what the
 * customer took.
 *
 * Both deduction flows end here and the pair is the argument. One short pay is
 * part valid and part already credited; the other is invalid to the last
 * dollar. The AI decides the split each time, and only the valid part becomes
 * a cost. Booking a deduction because it arrived is exactly the leakage these
 * cases exist to stop.
 *
 * Shared rather than duplicated, so the two endings cannot drift into saying
 * the same thing two different ways.
 */
export interface GtnImpactLine {
  lineNumber: number;
  glAccount: string;
  plainName: string;
  debit?: number;
  credit?: number;
}

export function GtnImpactPanel({
  shortPay,
  gtnImpact,
  recoveryRequired,
  basis,
  lines,
  caseRef,
  claimRef,
}: {
  shortPay: number;
  gtnImpact: number;
  recoveryRequired: number;
  basis: string;
  lines: GtnImpactLine[];
  caseRef: string;
  claimRef?: string;
}) {
  const gtnPct = shortPay === 0 ? 0 : (gtnImpact / shortPay) * 100;

  return (
    <div className="space-y-3">
      {/* The split, on one bar, so the proportion lands before the figures */}
      <div className="rounded-xl border bg-card p-4">
        <div className="mb-3 flex items-baseline justify-between gap-3">
          <h4 className="text-sm font-semibold">
            Treatment of the {formatUsd(shortPay)} withheld
          </h4>
          <span className="whitespace-nowrap text-xs text-muted-foreground">
            Gross-to-net against recovery
          </span>
        </div>
        <div className="flex h-10 w-full overflow-hidden rounded-lg border-2">
          {gtnImpact > 0 && (
            <div
              className="flex items-center justify-center bg-[var(--success)]/25"
              style={{ width: `${gtnPct}%` }}
            >
              <span className="whitespace-nowrap px-2 text-xs font-semibold text-green-800 tabular-nums">
                {formatUsd(gtnImpact)}
              </span>
            </div>
          )}
          {recoveryRequired > 0 && (
            <div className="flex flex-1 items-center justify-center bg-amber-400/30">
              <span className="whitespace-nowrap px-2 text-xs font-semibold text-amber-800 tabular-nums">
                {formatUsd(recoveryRequired)}
              </span>
            </div>
          )}
        </div>

        {/* Each card takes the width of its own segment, so the amber card
            begins exactly where the amber begins in the bar above. In an even
            grid the two were unmoored from what they describe. */}
        {/* A side worth nothing gets no card. Sizing them by amount collapsed
            a zero side to a sliver whose text stacked one letter per line, and
            the bar above already shows that the whole amount is on one side. */}
        <div className="mt-3 flex flex-col gap-3 sm:flex-row">
          {gtnImpact > 0 && (
            <div
              style={{ flex: `${gtnImpact} 1 0%` }}
              className="min-w-0 rounded-lg border-2 border-[var(--success)]/40 bg-[var(--success)]/5 p-3"
            >
              <p className="text-xs text-muted-foreground">
                Recognised as gross-to-net cost
              </p>
              <p className="text-2xl font-bold tabular-nums text-[var(--success)]">
                {formatUsd(gtnImpact)}
              </p>
              <p className="mt-1 text-xs text-muted-foreground">
                Drawn against the chargeback reserve.
              </p>
            </div>
          )}
          {recoveryRequired > 0 && (
            <div
              style={{ flex: `${recoveryRequired} 1 0%` }}
              className="min-w-0 rounded-lg border-2 border-amber-300 bg-amber-50 p-3"
            >
              <p className="text-xs text-muted-foreground">
                Remains a collectible receivable
              </p>
              <p className="text-2xl font-bold tabular-nums text-amber-700">
                {formatUsd(recoveryRequired)}
              </p>
              <p className="mt-1 text-xs text-muted-foreground">
                {gtnImpact > 0
                  ? "No gross-to-net impact. Recovery required."
                  : "No part of it is a gross-to-net cost. Recovery required."}
              </p>
            </div>
          )}
        </div>

        <p className="mt-3 border-t pt-3 text-xs text-muted-foreground">
          {basis}
        </p>
      </div>

      {/* The entry, when one arises */}
      <div className="rounded-xl border-2 border-[var(--success)]/40 bg-[var(--success)]/5 p-4">
        {lines.length > 0 ? (
          <>
            <p className="mb-2 text-sm font-semibold">
              Settlement entry for the accepted {formatUsd(gtnImpact)}
            </p>
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b text-left text-muted-foreground">
                  <th className="pb-1 font-medium">Account</th>
                  <th className="pb-1 text-right font-medium">Debit</th>
                  <th className="pb-1 text-right font-medium">Credit</th>
                </tr>
              </thead>
              <tbody>
                {lines.map((l) => (
                  <tr key={l.lineNumber} className="border-b last:border-0">
                    <td className="py-1.5 pr-2">
                      <span className="block leading-tight">{l.plainName}</span>
                      <span className="block font-mono text-muted-foreground">
                        {l.glAccount}
                      </span>
                    </td>
                    <td className="py-1.5 text-right tabular-nums">
                      {l.debit ? formatUsd(l.debit) : "—"}
                    </td>
                    <td className="py-1.5 text-right tabular-nums">
                      {l.credit ? formatUsd(l.credit) : "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </>
        ) : (
          <>
            <p className="text-sm font-semibold">No accounting entry arises</p>
            <p className="mt-1 text-sm text-muted-foreground">
              No part of the amount withheld is a chargeback obligation, so no
              entry is required. The decision keeps{" "}
              <strong className="text-foreground">
                {formatUsd(recoveryRequired)}
              </strong>{" "}
              out of contra revenue.
            </p>
          </>
        )}
        <p className="mt-2 text-xs text-muted-foreground">
          Originating case {caseRef}
          {claimRef ? ` · claim ${claimRef}` : ""}
        </p>
      </div>
    </div>
  );
}
