"use client";

import {
  AiStepReasoning,
  RevealWhen,
} from "@/components/mounts/order-management/step-reasoning";

/**
 * The agent reasons its way to the decision on screen, line by line, and only
 * then does the decision panel (numbers + approve buttons) appear.
 */
export function AgentDecision({
  stepKey,
  lines,
  children,
}: {
  stepKey: string;
  lines: string[];
  children: React.ReactNode;
}) {
  return (
    <AiStepReasoning stepKey={stepKey} lines={lines}>
      {(phase) => <RevealWhen when={phase >= lines.length}>{children}</RevealWhen>}
    </AiStepReasoning>
  );
}
