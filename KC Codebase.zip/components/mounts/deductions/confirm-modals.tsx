"use client";

import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { CheckCircle2, Sparkles, TriangleAlert, X } from "lucide-react";

import { Button } from "@/components/ui/button";
import { formatUsd } from "@/lib/chargeback-selectors";
import type { DeductionCase } from "@/lib/data/deductions";
import {
  claimMatchSignals,
  recoveryImpact,
  type ClassificationStep,
} from "@/lib/deduction-selectors";
import { cn } from "@/lib/utils";

/**
 * The two gates on the Deductions run.
 *
 * A ranked list a person clicks straight through is not a decision, it is a
 * menu. Both gates therefore open the same shell: what the AI concluded, what
 * confirming commits to, what the alternative would have meant, and only then
 * a button. Nothing reaches the store until that button is pressed.
 */

/* ------------------------------------------------------------------ *
 * Shared shell
 * ------------------------------------------------------------------ */

function ConfirmShell({
  title,
  subtitle,
  confirmLabel,
  onConfirm,
  onCancel,
  children,
}: {
  title: string;
  subtitle: string;
  confirmLabel: string;
  onConfirm: () => void;
  onCancel: () => void;
  children: React.ReactNode;
}) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  // Esc closes without deciding. A gate you cannot back out of is a trap.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onCancel();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onCancel]);

  if (!mounted) return null;

  return createPortal(
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-6 text-left backdrop-blur-sm"
      onClick={onCancel}
    >
      <div
        className="max-h-[88vh] w-full max-w-xl overflow-y-auto rounded-xl border bg-card shadow-2xl animate-modal-in"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3 border-b px-5 py-3">
          <div>
            <div className="text-sm font-semibold">{title}</div>
            <div className="text-xs text-muted-foreground">{subtitle}</div>
          </div>
          <Button variant="ghost" size="icon" onClick={onCancel}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div className="space-y-4 px-5 py-5">{children}</div>

        <div className="flex items-center justify-end gap-2 border-t bg-muted/20 px-5 py-3">
          <Button variant="ghost" onClick={onCancel} className="whitespace-nowrap">
            Cancel
          </Button>
          <Button onClick={onConfirm} className="whitespace-nowrap">
            <CheckCircle2 className="h-4 w-4" />
            {confirmLabel}
          </Button>
        </div>
      </div>
    </div>,
    document.body
  );
}

/** An AI line, in the house idiom. */
function AiNote({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-start gap-2 rounded-lg border border-primary/20 bg-primary/5 p-3 text-sm">
      <Sparkles className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
      <span className="text-muted-foreground">{children}</span>
    </div>
  );
}

/** A label/value row, values flush right so they scan as a column. */
function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <tr className="border-b last:border-0">
      <td className="w-[11rem] py-2 pr-4 align-top text-xs text-muted-foreground">
        {label}
      </td>
      <td className="py-2 align-top text-sm">{value}</td>
    </tr>
  );
}

/* ------------------------------------------------------------------ *
 * Gate 1 — the classification
 * ------------------------------------------------------------------ */

export function ClassificationConfirmModal({
  deduction,
  steps,
  onConfirm,
  onCancel,
}: {
  deduction: DeductionCase;
  steps: ClassificationStep[];
  onConfirm: () => void;
  onCancel: () => void;
}) {
  const ruledOut = steps.filter((s) => s.eliminated);
  const signals = claimMatchSignals(deduction);

  return (
    <ConfirmShell
      title="Confirm the classification"
      subtitle={`${deduction.deductionId} · ${deduction.customerName} · ${formatUsd(
        deduction.amount
      )} withheld`}
      confirmLabel={`Confirm — ${deduction.reasonCode.toLowerCase()}`}
      onConfirm={onConfirm}
      onCancel={onCancel}
    >
      <div className="rounded-lg border-2 border-primary/30 bg-primary/5 px-4 py-3">
        <div className="flex items-center justify-between gap-3">
          <div>
            <div className="text-xs text-muted-foreground">
              Classification proposed
            </div>
            <div className="text-lg font-semibold">{deduction.reasonCode}</div>
          </div>
          <div className="shrink-0 text-right">
            <div className="text-xl font-bold tabular-nums">
              {Math.round(deduction.reasonConfidence * 100)}%
            </div>
            <div className="text-xs text-muted-foreground">confidence</div>
          </div>
        </div>
      </div>

      <div>
        <h5 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          Ruled out
        </h5>
        <ul className="space-y-1">
          {ruledOut.map((s) => (
            <li key={s.label} className="flex items-start gap-2 text-xs">
              <X className="mt-0.5 h-3 w-3 shrink-0 text-muted-foreground" />
              <span>
                <span className="font-medium line-through">{s.label}</span>{" "}
                <span className="text-muted-foreground">{s.why}</span>
              </span>
            </li>
          ))}
        </ul>
      </div>

      <div>
        <h5 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          How the claim was identified
        </h5>
        <ul className="space-y-1.5">
          {signals.map((s) => (
            <li
              key={s.label}
              className="flex items-start gap-2 rounded border bg-muted/20 px-2.5 py-1.5 text-xs"
            >
              <CheckCircle2
                className={cn(
                  "mt-0.5 h-3.5 w-3.5 shrink-0",
                  s.holds ? "text-[var(--success)]" : "text-muted-foreground"
                )}
              />
              <span>
                <span className="font-medium">{s.label}. </span>
                <span className="text-muted-foreground">{s.finding}</span>
              </span>
            </li>
          ))}
        </ul>
      </div>

      {/* The what-if: both branches stated, so confirming is a choice. */}
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="rounded-lg border-2 border-amber-200 bg-amber-50/60 p-3">
          <div className="text-xs font-semibold text-amber-900">
            Confirming this classification
          </div>
          <p className="mt-1 text-xs text-amber-900/80">
            Routes the case to {deduction.routedTo} and pursues{" "}
            {formatUsd(deduction.amount)} as an amount still owed.
          </p>
        </div>
        <div className="rounded-lg border p-3">
          <div className="text-xs font-semibold">If the deduction were valid</div>
          <p className="mt-1 text-xs text-muted-foreground">
            The case would be accepted and closed, and{" "}
            {formatUsd(deduction.amount)} would be conceded permanently.
          </p>
        </div>
      </div>

      <AiNote>
        The classification rests on evidence, not on the customer&rsquo;s
        remittance note, which gives no claim reference. Cancel to leave the
        case open for manual review.
      </AiNote>
    </ConfirmShell>
  );
}

/* ------------------------------------------------------------------ *
 * Gate 2 — the recovery action
 * ------------------------------------------------------------------ */

export function RecoveryImpactModal({
  deduction,
  option,
  onConfirm,
  onCancel,
}: {
  deduction: DeductionCase;
  option: string;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  const impact = recoveryImpact(deduction, option);
  if (!impact) return null;

  const shortfall = impact.deltaVsRecommended < 0;

  return (
    <ConfirmShell
      title="Confirm the recovery action"
      subtitle={`${deduction.deductionId} · ${deduction.customerName} · ${formatUsd(
        deduction.amount
      )} withheld`}
      confirmLabel={`Confirm — ${impact.option.toLowerCase()}`}
      onConfirm={onConfirm}
      onCancel={onCancel}
    >
      <div className="flex items-center gap-2">
        <span className="text-lg font-semibold">{impact.option}</span>
        {impact.recommended && (
          <span className="inline-flex items-center gap-1 whitespace-nowrap rounded bg-primary/10 px-1.5 py-0.5 text-xs font-medium text-primary">
            <Sparkles className="h-3 w-3" />
            AI recommended
          </span>
        )}
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="rounded-lg border border-[var(--success)]/30 bg-[var(--success)]/5 p-3">
          <div className="text-xs text-muted-foreground">Recovered</div>
          <div className="text-xl font-bold tabular-nums text-[var(--success)]">
            {formatUsd(impact.recovered)}
          </div>
        </div>
        <div
          className={cn(
            "rounded-lg border p-3",
            impact.conceded > 0
              ? "border-red-300 bg-red-50"
              : "border-muted bg-muted/20"
          )}
        >
          <div className="text-xs text-muted-foreground">Conceded</div>
          <div
            className={cn(
              "text-xl font-bold tabular-nums",
              impact.conceded > 0 ? "text-red-600" : "text-muted-foreground"
            )}
          >
            {formatUsd(impact.conceded)}
          </div>
        </div>
      </div>

      {shortfall && (
        <div className="flex items-start gap-2 rounded-lg border-2 border-red-300 bg-red-50 p-3">
          <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0 text-red-600" />
          <p className="text-xs text-red-800">
            {impact.recommendedOption}, the recommended action, collects{" "}
            <strong className="tabular-nums">
              {formatUsd(Math.abs(impact.deltaVsRecommended))}
            </strong>{" "}
            more.
          </p>
        </div>
      )}

      <table className="w-full">
        <tbody>
          <DetailRow
            label="Amount still owed"
            value={formatUsd(impact.receivableAfter)}
          />
          <DetailRow label="Accounting treatment" value={impact.accounting} />
          <DetailRow label="Approval required" value={impact.approval} />
          <DetailRow
            label="Relationship cost"
            value={`${impact.relationshipCost}`}
          />
        </tbody>
      </table>

      <AiNote>{impact.aiView}</AiNote>
    </ConfirmShell>
  );
}
