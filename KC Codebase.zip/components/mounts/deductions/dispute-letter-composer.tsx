"use client";

import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import {
  CircleCheck,
  Mail,
  Paperclip,
  Send,
  Sparkles,
  SquarePen,
  X,
} from "lucide-react";

import {
  SourceDocTrigger,
  type SourceDoc,
} from "@/components/modals/source-doc-preview";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { EMAIL_DRAFT_MS, useTypewriter } from "@/lib/hooks/use-typewriter";

/**
 * The dispute letter: drafted by the AI, edited by a person, sent only on a
 * person's click. Renders as a centered popup — same email-agent surface
 * used everywhere in the demo an agent proposes outbound correspondence —
 * with a compact summary row behind it so the letter's status is visible
 * even while the popup is closed.
 *
 * The component takes the rendered envelope and body rather than a case, so
 * both deduction flows use the same one. Each caller renders its own letter
 * from its own records — the numbers in the body, in the textarea and in the
 * attached document are the same string in every case.
 */
export interface LetterAttachment {
  doc: SourceDoc;
  label: string;
}

export function DisputeLetterComposer({
  letterKey,
  from,
  to,
  subject,
  body,
  attachments,
  sent,
  sentDate,
  sentNote,
  canSend,
  blockedNote,
  onSend,
  onDraftDone,
  closePopup,
}: {
  /** Fires once the AI has finished typing the draft. */
  onDraftDone?: () => void;
  /** Closes the popup when it turns true, e.g. before a run-complete modal. */
  closePopup?: boolean;
  /** Keys the typewriter, so a different letter retypes. */
  letterKey: string;
  from: string;
  to: string;
  subject: string;
  body: string;
  attachments: LetterAttachment[];
  sent: boolean;
  sentDate?: string;
  /** What to say once it has gone. */
  sentNote: string;
  canSend: boolean;
  /** Why the send button is disabled, when it is. */
  blockedNote?: string;
  onSend: () => void;
}) {
  const [open, setOpen] = useState(!sent);
  const [editing, setEditing] = useState(false);
  const [edited, setEdited] = useState<string | null>(null);
  const shown = edited ?? body;

  useEffect(() => {
    if (closePopup) setOpen(false);
  }, [closePopup]);

  // The window shows "Sent" briefly, then steps aside so the run's next stage
  // and its finale are never stacked under a letter that has already gone.
  const wasSent = useRef(sent);
  useEffect(() => {
    if (sent === wasSent.current) return;
    wasSent.current = sent;
    if (!sent) return;
    const t = setTimeout(() => setOpen(false), 1200);
    return () => clearTimeout(t);
  }, [sent]);

  return (
    <div className="rounded-xl border bg-card">
      <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3">
        <span className="flex items-center gap-2 text-sm font-medium">
          <Mail className="h-4 w-4 shrink-0 text-muted-foreground" />
          {subject}
        </span>
        <div className="flex items-center gap-2">
          {sent ? (
            <Badge className="whitespace-nowrap bg-[var(--success)] text-white">
              <CircleCheck className="h-3 w-3" />
              {sentDate ? `Sent ${sentDate}` : "Sent"}
            </Badge>
          ) : (
            <Badge
              variant="outline"
              className="whitespace-nowrap border-amber-300 bg-amber-50 text-amber-800"
            >
              Not yet issued
            </Badge>
          )}
          <Button
            size="sm"
            variant={sent ? "outline" : "default"}
            onClick={() => setOpen(true)}
          >
            {sent ? "View sent email" : "Review draft"}
          </Button>
        </div>
      </div>

      {open && (
        <LetterPopup
          letterKey={letterKey}
          from={from}
          to={to}
          subject={subject}
          body={shown}
          attachments={attachments}
          sent={sent}
          sentDate={sentDate}
          sentNote={sentNote}
          canSend={canSend}
          blockedNote={blockedNote}
          editing={editing}
          onToggleEdit={() => setEditing((v) => !v)}
          onEditChange={setEdited}
          onSend={onSend}
          onDraftDone={onDraftDone}
          onClose={() => {
            setOpen(false);
            if (!sent) onDraftDone?.();
          }}
        />
      )}
    </div>
  );
}

function LetterPopup({
  letterKey,
  from,
  to,
  subject,
  body,
  attachments,
  sent,
  sentDate,
  sentNote,
  canSend,
  blockedNote,
  editing,
  onToggleEdit,
  onEditChange,
  onSend,
  onDraftDone,
  onClose,
}: {
  onDraftDone?: () => void;
  letterKey: string;
  from: string;
  to: string;
  subject: string;
  body: string;
  attachments: LetterAttachment[];
  sent: boolean;
  sentDate?: string;
  sentNote: string;
  canSend: boolean;
  blockedNote?: string;
  editing: boolean;
  onToggleEdit: () => void;
  onEditChange: (value: string) => void;
  onSend: () => void;
  onClose: () => void;
}) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const { visible, done } = useTypewriter(sent ? "" : body, EMAIL_DRAFT_MS);
  const streamed = sent ? body : visible;

  useEffect(() => {
    if (done && !sent) onDraftDone?.();
  }, [done, sent, onDraftDone]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.stopPropagation();
        onClose();
      }
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [onClose]);

  if (!mounted) return null;

  return createPortal(
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4"
      onClick={onClose}
    >
      <div
        className="flex max-h-[85vh] w-full max-w-lg flex-col overflow-hidden rounded-xl border bg-card shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3 border-b p-4">
          <div className="flex items-start gap-3">
            <span className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-lg bg-orange-500/15">
              <Sparkles className="h-4.5 w-4.5 text-orange-500" />
            </span>
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                Email agent · {sent ? "sent" : "draft"}
              </p>
              <h3 className="text-base font-semibold">
                {sent ? "Sent" : !done ? "Drafting…" : "Ready to send"}
              </h3>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-md p-1 text-muted-foreground hover:bg-muted"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="flex-1 space-y-3 overflow-y-auto p-4">
          <div className="space-y-2 rounded-lg bg-muted/40 px-3 py-2.5 text-sm">
            <EnvelopeRow label="From" value={from} />
            <EnvelopeRow label="To" value={to} />
            <EnvelopeRow label="Subject" value={subject} />
          </div>

          {editing ? (
            <Textarea
              value={body}
              onChange={(e) => onEditChange(e.target.value)}
              rows={16}
              className="text-sm leading-relaxed"
            />
          ) : (
            <div className="rounded-md border bg-background p-3.5 text-sm leading-relaxed">
              <p className="whitespace-pre-wrap text-foreground">
                {streamed}
                {!sent && !done && (
                  <span className="ml-0.5 inline-block h-3.5 w-[2px] -translate-y-0.5 align-middle bg-primary animate-caret-blink" />
                )}
              </p>
            </div>
          )}

          {attachments.length > 0 && (done || sent) && (
            <div className="space-y-1.5 rounded-md border bg-muted/30 px-3 py-2.5">
              <p className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                <Paperclip className="h-3.5 w-3.5 shrink-0" />
                Attached evidence
              </p>
              <div className="flex flex-wrap gap-2">
                {attachments.map((a) => (
                  <SourceDocTrigger
                    key={a.label}
                    doc={a.doc}
                    label={a.label}
                    variant="outline"
                  />
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2 border-t p-4">
          {sent ? (
            <p className="flex items-center gap-2 text-sm">
              <CircleCheck className="h-4 w-4 shrink-0 text-[var(--success)]" />
              {sentNote}
            </p>
          ) : (
            <>
              <Button variant="outline" size="sm" onClick={onClose}>
                Close
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={onToggleEdit}
                disabled={!done}
              >
                <SquarePen className="h-4 w-4" />
                {editing ? "Finish editing" : "Edit draft"}
              </Button>
              <Button
                size="sm"
                disabled={!canSend || !done}
                onClick={onSend}
              >
                <Send className="h-4 w-4" />
                Approve and send
              </Button>
              <span className="w-full text-xs text-muted-foreground">
                {canSend
                  ? "Drafted for review. It is issued only on your approval."
                  : (blockedNote ?? "Not ready to send.")}
              </span>
            </>
          )}
        </div>
      </div>
    </div>,
    document.body
  );
}

function EnvelopeRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-baseline gap-2">
      <span className="w-16 flex-shrink-0 text-xs text-muted-foreground">
        {label}
      </span>
      <span className="min-w-0 font-medium">{value}</span>
    </div>
  );
}
