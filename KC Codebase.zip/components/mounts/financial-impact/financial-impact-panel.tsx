"use client";

import { useState } from "react";
import { createPortal } from "react-dom";
import { CircleCheck, Lock, ShieldCheck, TriangleAlert, X } from "lucide-react";

import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CountUp } from "@/components/ui/count-up";
import {
  distributorName,
  formatUsd,
} from "@/lib/chargeback-selectors";
import { findClaim } from "@/lib/data/chargebacks";
import {
  buildJournalEntryDoc,
  buildLedgerMovementDoc,
} from "@/lib/docs-chargebacks";
import { PROGRAMME_SCOPE } from "@/lib/data/gross-to-net";
import {
  journalApprovers,
  journalPostingSecondApproverThreshold,
  postingControls,
  reversalReasonCodes,
} from "@/lib/data/journal-entries";
import {
  beamTiltDegrees,
  journalEntryTotals,
  ledgerMovements,
  ledgerScaleMax,
  claimAccountingImpact,
  claimSettlementEntry,
  contractReserve,
  type ClaimAccountingImpact,
} from "@/lib/journal-selectors";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

import {
  JournalEntryBalanceBeam,
  LedgerAccountLadder,
} from "./financial-visuals";

/**
 * What the chargeback decisions do to the books.
 *
 * Opened from the Chargebacks page once validation is done. The posting is the
 * one irreversible act in this demo, so it is gated three ways: the entry has
 * to balance, a person has to have opened the evidence, and a person has to
 * click. None of those is decoration — each is read from live state.
 */
export function FinancialImpactPanel({
  claimId,
  onClose,
}: {
  claimId: string;
  onClose: () => void;
}) {
  const {
    claimDecisions,
    postedJournalEntries,
    reversalRequests,
    postReserveAdjustment,
    requestEntryReversal,
  } = useOtcStore();

  const [evidenceOpened, setEvidenceOpened] = useState(false);
  const [reversalOpen, setReversalOpen] = useState(false);

  // Every figure on this panel belongs to the claim that opened it. A
  // programme-level reserve top-up has nothing to do with one settlement and
  // was the first thing a controller challenged.
  const decision = claimDecisions.find((d) => d.claimId === claimId);
  const claim = findClaim(claimId);
  const impact = claimAccountingImpact(
    claimId,
    decision?.approvedAmount ?? 0,
    decision?.rejectedAmount ?? 0
  );
  const entry = claimSettlementEntry(
    claimId,
    decision?.approvedAmount ?? 0,
    distributorName(claim?.distributorId ?? ""),
    decision?.creditNoteId ?? "—"
  );
  const totals = journalEntryTotals(entry);
  // The provision set aside for THESE units is what the entry draws down.
  // The programme-level opening balance describes a different population.
  // Only the provision has an opening balance that belongs to this claim.
  // The wholesaler's total receivable is a different population, and showing
  // it against a zero opening would close negative.
  const movements = ledgerMovements(entry, {
    "229150": impact?.provided ?? 0,
  }).filter((m) => m.account === "229150");
  const posted = postedJournalEntries.includes(entry.entryId);
  const reversal = reversalRequests.find((r) => r.entryId === entry.entryId);
  const agrees = (impact?.approved ?? 0) === totals.debitTotal;
  const canPost = totals.balanced && evidenceOpened && !posted;

  if (!impact) return null;

  return createPortal(
    <div className="fixed inset-0 z-[60] flex items-start justify-center overflow-y-auto bg-black/50 p-6">
      <div className="animate-modal-in w-full max-w-4xl rounded-xl border bg-background shadow-xl">
        <div className="flex items-start justify-between gap-4 border-b p-5">
          <div>
            <h3 className="text-lg font-semibold">Financial impact</h3>
            <p className="text-sm text-muted-foreground">
              What settling {claimId} does to the books. Every figure here
              comes from this claim.
              {impact.approved > 0 && " The posting needs approval."}
            </p>
            <p className="mt-1 text-xs text-muted-foreground">{PROGRAMME_SCOPE}</p>
          </div>
          <Button variant="ghost" size="sm" onClick={onClose} aria-label="Close">
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div className="space-y-5 p-5">
          <ProvisionOutcome impact={impact} />

          {impact.approved === 0 ? (
            <NoPostingArises amount={impact.neverProvided} />
          ) : (
            <>

          {/* The shortfall and the entry are the same subtraction, so saying
              they agree tells the reader nothing they can act on. The check
              still earns its place as a guard: silent when it holds, loud
              when it does not. */}
          {!agrees && (
            <p className="flex items-center gap-2 rounded-lg bg-amber-50 px-3 py-2 text-xs font-medium text-amber-800">
              <TriangleAlert className="h-3.5 w-3.5 shrink-0" />
              The entry does not match the amount approved. Do not post.
            </p>
          )}

          <JournalEntryBalanceBeam
            entry={entry}
            totals={totals}
            tiltDegrees={beamTiltDegrees(totals)}
            posted={posted}
          />

          {/* The gate */}
          <div
            className={cn(
              "rounded-xl border-2 p-4",
              posted
                ? "border-[var(--success)]/40 bg-[var(--success)]/5"
                : "border-amber-200 bg-amber-50/60"
            )}
          >
            <div className="mb-3 flex flex-wrap items-center gap-2">
              {posted ? (
                <Badge className="whitespace-nowrap bg-[var(--success)] text-white">
                  <CircleCheck className="h-3 w-3" />
                  Posted with your approval
                </Badge>
              ) : (
                <Badge
                  variant="outline"
                  className="whitespace-nowrap border-amber-300 bg-amber-100 text-amber-800"
                >
                  Awaiting your approval
                </Badge>
              )}
              <span className="text-xs text-muted-foreground">
                Prepared by {journalApprovers.preparedBy.name},{" "}
                {journalApprovers.preparedBy.role}. Anything above{" "}
                {formatUsd(journalPostingSecondApproverThreshold)} also needs{" "}
                {journalApprovers.approvedBy.role} approval.
              </span>
            </div>

            {posted ? (
              <div className="space-y-1 text-sm">
                <p className="font-medium">
                  Document {entry.documentNumber} · posted{" "}
                  {entry.postingDate} · {entry.currency}
                </p>
                <p className="text-xs text-muted-foreground">
                  Approved by {journalApprovers.approvedBy.name},{" "}
                  {journalApprovers.approvedBy.role}. The evidence pack is
                  linked to the document.
                </p>
              </div>
            ) : (
              <>
                <div className="mb-3 flex flex-wrap gap-2">
                  <SourceDocTrigger
                    doc={buildJournalEntryDoc(entry, false)}
                    label="Review the entry and its evidence"
                  />
                  {!evidenceOpened && (
                    <Button
                      variant="outline"
                      size="sm"
                      className={cn(
                        "whitespace-nowrap text-xs",
                        // It is the step that unlocks posting, and as a ghost
                        // button it read as a caption rather than a control.
                        "border-[var(--info)]/50 bg-[var(--info)]/10",
                        "text-[var(--info)] hover:bg-[var(--info)]/20"
                      )}
                      onClick={() => setEvidenceOpened(true)}
                    >
                      I have reviewed it
                    </Button>
                  )}
                </div>
                <Button
                  className="whitespace-nowrap"
                  disabled={!canPost}
                  onClick={() => postReserveAdjustment(entry.entryId)}
                >
                  <Lock className="h-4 w-4" />
                  Approve and post {formatUsd(totals.debitTotal)}
                </Button>
                {!canPost && (
                  <p className="mt-2 text-xs text-muted-foreground">
                    {!totals.balanced
                      ? "The entry does not balance — it cannot be posted."
                      : "Review the entry first, then confirm, to enable posting."}
                  </p>
                )}
              </>
            )}
          </div>

          <LedgerAccountLadder
            entry={entry}
            reserve={contractReserve(claimId, impact.approved)}
            movements={movements}
            scaleMax={ledgerScaleMax(movements)}
            revealed={posted}
          />

          {posted && (
            <>
              <div className="rounded-xl border bg-card p-4">
                <h4 className="mb-3 text-sm font-semibold">
                  What stopped this from going wrong
                </h4>
                <div className="space-y-2">
                  {postingControls.map((c) => (
                    <div key={c.id} className="flex items-start gap-2">
                      <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-[var(--success)]" />
                      <div className="min-w-0">
                        <p className="text-xs font-medium">{c.label}</p>
                        <p className="text-xs text-muted-foreground">
                          {c.detail}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-3 flex flex-wrap gap-2 border-t pt-3">
                  <SourceDocTrigger
                    doc={buildLedgerMovementDoc(entry, movements)}
                    label="View the account movement"
                  />
                  <SourceDocTrigger
                    doc={buildJournalEntryDoc(entry, true)}
                    label="View the posted entry"
                  />
                  {!reversal && (
                    <Button
                      variant="outline"
                      size="sm"
                      className="whitespace-nowrap"
                      onClick={() => setReversalOpen(true)}
                    >
                      Request a reversal
                    </Button>
                  )}
                </div>
                {reversal && (
                  <p className="mt-3 rounded border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">
                    Reversal requested — {reversal.reasonCode}. Waiting for{" "}
                    {journalApprovers.preparedBy.role} approval. Nothing has
                    been reversed.
                  </p>
                )}
              </div>

              {reversalOpen && (
                <ReversalRequestForm
                  onCancel={() => setReversalOpen(false)}
                  onSubmit={(reasonCode, note) => {
                    requestEntryReversal(entry.entryId, reasonCode, note);
                    setReversalOpen(false);
                  }}
                />
              )}
            </>
          )}
            </>
          )}
        </div>
      </div>
    </div>,
    document.body
  );
}

/**
 * A claim rejected in full produces no credit note, so there is nothing to
 * post. Rendering a $0 entry under the heading "settle by credit note" was
 * worse than rendering nothing: it invited approval of a document that does
 * not exist.
 */
function NoPostingArises({ amount }: { amount: number }) {
  return (
    <div className="rounded-xl border-2 border-[var(--success)]/40 bg-[var(--success)]/5 p-4">
      <div className="flex items-start gap-2">
        <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-[var(--success)]" />
        <div>
          <h4 className="text-sm font-semibold">No accounting entry arises</h4>
          <p className="mt-1 text-sm text-muted-foreground">
            Nothing was approved, so no credit note is raised and there is
            nothing to post. The effect of the decision is what did not happen:{" "}
            <strong className="text-foreground">{formatUsd(amount)}</strong>{" "}
            stayed out of contra revenue.
          </p>
          <p className="mt-2 text-xs text-muted-foreground">
            The amount is now disputed with the wholesaler. It is carried and
            pursued on the Deductions page, which is where it moves next.
          </p>
        </div>
      </div>
    </div>
  );
}

function ReversalRequestForm({
  onCancel,
  onSubmit,
}: {
  onCancel: () => void;
  onSubmit: (reasonCode: string, note: string) => void;
}) {
  const [reasonCode, setReasonCode] = useState(reversalReasonCodes[0]);
  const [note, setNote] = useState("");

  return (
    <div className="rounded-xl border border-amber-200 bg-amber-50/60 p-4">
      <h4 className="text-sm font-semibold">Request a reversal</h4>
      <p className="mt-0.5 text-xs text-muted-foreground">
        A reversal needs a reason and an approval. This raises the request — it
        does not reverse anything.
      </p>
      <div className="mt-3 space-y-2">
        <select
          value={reasonCode}
          onChange={(e) => setReasonCode(e.target.value)}
          className="w-full rounded-md border bg-background px-3 py-2 text-sm"
        >
          {reversalReasonCodes.map((r) => (
            <option key={r} value={r}>
              {r}
            </option>
          ))}
        </select>
        <textarea
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="Why is this being reversed?"
          rows={2}
          className="w-full rounded-md border bg-background px-3 py-2 text-sm"
        />
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        <Button
          size="sm"
          className="whitespace-nowrap"
          disabled={note.trim().length === 0}
          onClick={() => onSubmit(reasonCode, note.trim())}
        >
          Submit the request
        </Button>
        <Button
          size="sm"
          variant="ghost"
          className="whitespace-nowrap"
          onClick={onCancel}
        >
          Cancel
        </Button>
      </div>
    </div>
  );
}

/**
 * Provision against decision.
 *
 * The question a controller asks first is whether the estimate held. Two bars
 * on one scale answer it: what was set aside when the units were invoiced, and
 * what the decision actually approved. The rejected value is drawn apart from
 * them because it never had a provision behind it - which is the reason
 * rejecting it protects revenue rather than merely avoiding a payment.
 */
function ProvisionOutcome({ impact }: { impact: ClaimAccountingImpact }) {
  const scale = Math.max(impact.provided, impact.approved, impact.neverProvided, 1);
  const pct = (n: number) => `${(n / scale) * 100}%`;
  const held = impact.varianceToProvision === 0;

  const bars = [
    {
      label: "Set aside when these units were invoiced",
      value: impact.provided,
      className: "bg-muted-foreground/30",
    },
    {
      label: "Approved on this claim",
      value: impact.approved,
      className: "bg-[var(--success)]/50",
    },
    {
      label: "Rejected — no provision behind it",
      value: impact.neverProvided,
      className: "bg-amber-400/60",
    },
  ];

  return (
    <div className="rounded-xl border bg-card p-4">
      <h4 className="mb-3 text-sm font-semibold">
        The decision against the provision
      </h4>
      <div className="space-y-2.5">
        {bars.map((b) => (
          <div key={b.label}>
            <div className="flex items-baseline justify-between gap-3">
              <span className="text-xs text-muted-foreground">{b.label}</span>
              <span className="shrink-0 text-sm font-semibold tabular-nums">
                {formatUsd(b.value)}
              </span>
            </div>
            <div className="mt-1 h-2.5 overflow-hidden rounded bg-muted">
              <div
                className={cn("h-full transition-all duration-700", b.className)}
                style={{ width: pct(b.value) }}
              />
            </div>
          </div>
        ))}
      </div>
      <p className="mt-3 border-t pt-3 text-xs text-muted-foreground">
        {held
          ? `The decision lands on the provision: variance ${formatUsd(0)}. Paying the claim in full would have charged ${formatUsd(impact.neverProvided)} to revenue with nothing set aside against it.`
          : `The decision is ${formatUsd(Math.abs(impact.varianceToProvision))} ${impact.varianceToProvision > 0 ? "above" : "below"} the provision.`}
      </p>
    </div>
  );
}
