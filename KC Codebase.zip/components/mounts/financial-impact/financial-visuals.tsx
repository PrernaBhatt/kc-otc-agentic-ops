"use client";

import { useEffect, useState } from "react";
import { ArrowRight, CircleCheck, TriangleAlert } from "lucide-react";

import { CountUp } from "@/components/ui/count-up";
import { formatUsd } from "@/lib/chargeback-selectors";
import type { JournalEntry } from "@/lib/data/journal-entries";
import type {
  JournalEntryTotals,
  LedgerMovement,
  ContractReserve,
  ReservePosition,
} from "@/lib/journal-selectors";
import { cn } from "@/lib/utils";

function useMounted(delayMs = 60) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    const id = setTimeout(() => setMounted(true), delayMs);
    return () => clearTimeout(id);
  }, [delayMs]);
  return mounted;
}

/**
 * Millions are right for a programme-scale balance and wrong for one claim:
 * a $600,000 entry rendered "$0.6M" reads as a rounding of something bigger.
 * Below a million, print the figure.
 */
function millions(value: number) {
  if (Math.abs(value) < 1_000_000) {
    return `$${Math.round(value).toLocaleString("en-US")}`;
  }
  return `$${(value / 1_000_000).toFixed(1)}M`;
}

/**
 * The reserve, and how far short it is.
 *
 * The track is what the AI says is needed. The solid fill is what is actually
 * on the books. The hatched remainder is the shortfall — you see the gap
 * before you read a number. The marker at the requirement is a BAND, not a
 * line, and how tight that band is is the reserve's accuracy.
 */
export function ReserveTruingDial({ position }: { position: ReservePosition }) {
  const mounted = useMounted();
  const coverage = position.coveragePercent * 100;
  // A tighter band means a more reliable estimate; 98.4% accurate reads as a
  // 1.6% wide band around the requirement.
  const bandWidth = Math.max(0.8, 100 - position.accuracyPercent);

  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-1 flex items-start justify-between gap-4">
        <div>
          <h4 className="text-sm font-semibold">
            Reserve position
          </h4>
          <p className="mt-0.5 text-xs text-muted-foreground">
            Amounts expected to be credited back to wholesalers on claims not yet settled.
          </p>
        </div>
        <div className="shrink-0 text-right">
          <div className="text-2xl font-bold leading-none text-amber-600 tabular-nums">
            <CountUp value={position.variance} format={millions} durationMs={1300} />
          </div>
          <div className="text-xs text-muted-foreground">shortfall</div>
        </div>
      </div>

      <div className="relative mt-8 h-12">
        <div className="absolute inset-x-0 top-2 h-8 overflow-hidden rounded-lg border-2 border-slate-300 bg-slate-50">
          <div
            className="h-full bg-[var(--info)]/25 transition-all duration-700 ease-out motion-reduce:transition-none"
            style={{ width: mounted ? `${coverage}%` : "0%" }}
          />
          <div
            className="absolute inset-y-0 transition-all duration-500 ease-out motion-reduce:transition-none"
            style={{
              left: `${coverage}%`,
              right: 0,
              opacity: mounted ? 1 : 0,
              transitionDelay: "600ms",
              backgroundImage:
                "repeating-linear-gradient(45deg, rgba(217,165,20,0.30) 0 6px, transparent 6px 12px)",
            }}
          />
        </div>

        {/* Where the requirement sits, and how confident we are about it */}
        <div
          className="absolute top-0 h-12 rounded bg-foreground/70 transition-opacity duration-500 motion-reduce:transition-none"
          style={{
            left: `calc(100% - ${bandWidth}%)`,
            width: `${bandWidth}%`,
            opacity: mounted ? 1 : 0,
            transitionDelay: "900ms",
          }}
          title={`Requirement, ${position.accuracyPercent}% accurate last period`}
        />
      </div>

      <div className="mt-3 grid gap-3 sm:grid-cols-3">
        {[
          { label: "Booked", value: position.booked, tone: "info" },
          { label: "Shortfall", value: position.variance, tone: "warn" },
          { label: "Required", value: position.projected, tone: "plain" },
        ].map((f) => (
          <div key={f.label} className="flex h-full flex-col rounded-lg border p-2.5">
            <span className="text-xs text-muted-foreground">{f.label}</span>
            <span
              className={cn(
                "mt-auto pt-1 text-lg font-bold tabular-nums",
                f.tone === "info" && "text-[var(--info)]",
                f.tone === "warn" && "text-amber-600"
              )}
            >
              {millions(f.value)}
            </span>
          </div>
        ))}
      </div>

      <p className="mt-3 border-t pt-2 text-xs text-muted-foreground">
        <span className="rounded bg-muted/60 px-1.5 py-0.5 font-mono">
          {position.basis}
        </span>{" "}
        — {position.basisGloss}. Last period this estimate fell within{" "}
        {(100 - position.accuracyPercent).toFixed(1)}% of the amount actually
        claimed.
      </p>
    </div>
  );
}

/**
 * The entry, drawn as a balance beam.
 *
 * An accountant checks one thing first: does it balance. The beam mounts
 * tilted with only the debit loaded, the credit drops onto the other arm, and
 * it settles level. The tilt is COMPUTED from the totals — an entry that does
 * not balance stays visibly crooked rather than quietly rendering level.
 */
export function JournalEntryBalanceBeam({
  entry,
  totals,
  tiltDegrees,
  posted,
}: {
  entry: JournalEntry;
  totals: JournalEntryTotals;
  tiltDegrees: number;
  posted: boolean;
}) {
  const [loaded, setLoaded] = useState(false);
  useEffect(() => {
    const id = setTimeout(() => setLoaded(true), 400);
    return () => clearTimeout(id);
  }, []);

  const debitLine = entry.lines.find((l) => l.debit);
  const creditLine = entry.lines.find((l) => l.credit);
  const tilt = loaded ? tiltDegrees : 8;

  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <h4 className="text-sm font-semibold">{entry.headline}</h4>
        {posted && (
          <span className="whitespace-nowrap rounded bg-[var(--success)]/10 px-2 py-0.5 text-xs font-medium text-[var(--success)]">
            Posted · document {entry.documentNumber}
          </span>
        )}
      </div>

      {/* The system's own header, in its own words */}
      <div className="mb-4 rounded bg-muted/40 px-2.5 py-1.5">
        <p className="font-mono text-xs text-muted-foreground">
          Company code {entry.companyCode} · Ledger {entry.ledger} · Period{" "}
          {entry.postingPeriod} · Document type {entry.documentType}
        </p>
        <p className="mt-0.5 text-xs text-muted-foreground">
          {/* The gloss already begins with its own article. */}
          In order: {entry.companyCodeGloss}, {entry.ledgerGloss}, the month
          being closed, and the entry type — {entry.documentTypeGloss}.
        </p>
      </div>

      <div className="relative flex h-32 items-end justify-center">
        <div
          className="absolute bottom-8 w-full transition-transform duration-700 ease-out motion-reduce:transition-none"
          style={{ transform: `rotate(${tilt}deg)`, transformOrigin: "center" }}
        >
          <div className="relative h-1.5 rounded-full bg-slate-400" />
          <div className="absolute -top-14 left-[8%] w-[34%]">
            <div
              className="rounded-md border-2 border-[var(--info)]/50 bg-[var(--info)]/15 px-2 py-2 text-center"
              style={{ transform: `rotate(${-tilt}deg)` }}
            >
              <p className="text-xs font-medium">Debit</p>
              <p className="text-sm font-bold tabular-nums">
                {millions(totals.debitTotal)}
              </p>
            </div>
          </div>
          <div
            className="absolute -top-14 right-[8%] w-[34%] transition-all duration-500 ease-out motion-reduce:transition-none"
            style={{
              opacity: loaded ? 1 : 0,
              transform: `translateY(${loaded ? 0 : -24}px)`,
            }}
          >
            <div
              className="rounded-md border-2 border-amber-400/60 bg-amber-100/60 px-2 py-2 text-center"
              style={{ transform: `rotate(${-tilt}deg)` }}
            >
              <p className="text-xs font-medium">Credit</p>
              <p className="text-sm font-bold tabular-nums">
                {millions(totals.creditTotal)}
              </p>
            </div>
          </div>
        </div>
        {/* Fulcrum */}
        <div
          className="absolute bottom-0 h-8 w-0 border-x-[18px] border-b-[32px] border-x-transparent border-b-slate-300"
          aria-hidden
        />
      </div>

      <div className="mt-2 flex justify-center">
        <span
          className={cn(
            "inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-3 py-1 text-xs font-medium transition-opacity duration-500",
            totals.balanced
              ? "bg-[var(--success)]/10 text-[var(--success)]"
              : "bg-amber-50 text-amber-700",
            loaded ? "opacity-100" : "opacity-0"
          )}
        >
          {totals.balanced ? (
            <CircleCheck className="h-3.5 w-3.5" />
          ) : (
            <TriangleAlert className="h-3.5 w-3.5" />
          )}
          {totals.balanced
            ? `Balanced — difference ${formatUsd(0)}`
            : `Out of balance by ${formatUsd(Math.abs(totals.difference))}`}
        </span>
      </div>

      <table className="mt-4 w-full text-xs">
        <thead>
          <tr className="border-b text-left text-muted-foreground">
            <th className="pb-1.5 font-medium">Line</th>
            <th className="pb-1.5 font-medium">Account</th>
            <th className="pb-1.5 text-right font-medium">Debit</th>
            <th className="pb-1.5 text-right font-medium">Credit</th>
          </tr>
        </thead>
        <tbody>
          {[debitLine, creditLine].filter(Boolean).map((l) => (
            <tr key={l!.lineNumber} className="border-b last:border-0">
              <td className="py-1.5">{l!.lineNumber}</td>
              <td className="py-1.5">
                <span className="font-medium">{l!.plainName}</span>
                <span className="ml-1.5 font-mono text-muted-foreground">
                  {l!.glAccount}
                </span>
              </td>
              <td className="py-1.5 text-right tabular-nums">
                {l!.debit ? formatUsd(l!.debit) : "—"}
              </td>
              <td className="py-1.5 text-right tabular-nums">
                {l!.credit ? formatUsd(l!.credit) : "—"}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/**
 * Where the money lands.
 *
 * Two accounts side by side. The opening balance is already there; the posting
 * grows out of the end of it, in opposite directions, and the closing figure
 * counts up. Same amount, two accounts — that is double-entry made visible.
 */
/**
 * The entry, then the ledger it moved — with the posting travelling between
 * them.
 *
 * This is the payoff of the whole flow: a claim checked, decided by a person,
 * and landing in the books. The two cards are named for what they are, and the
 * connector animates once on posting, so a client watching sees the entry
 * reach the ledger rather than reading two static panels and joining them up.
 */
export function LedgerAccountLadder({
  movements,
  scaleMax,
  revealed,
  entry,
  reserve,
}: {
  movements: LedgerMovement[];
  scaleMax: number;
  revealed: boolean;
  entry: JournalEntry;
  reserve: ContractReserve | null;
}) {
  const pct = (v: number) => (v / scaleMax) * 100;
  const [arrived, setArrived] = useState(false);

  // The pulse runs once, when the entry posts, and never again.
  useEffect(() => {
    if (!revealed) return;
    const id = setTimeout(() => setArrived(true), 900);
    return () => clearTimeout(id);
  }, [revealed]);

  return (
    <div
      className={cn(
        "rounded-xl border-2 border-[var(--success)]/40 bg-[var(--success)]/5 p-4",
        !revealed && "opacity-60"
      )}
    >
      <div className="mb-4 flex items-baseline justify-between gap-3">
        <h4 className="text-sm font-semibold">
          What this decision does to the books
        </h4>
        <span className="whitespace-nowrap text-xs text-muted-foreground">
          {revealed ? `Posted · document ${entry.documentNumber}` : "Projected"}
        </span>
      </div>

      <div className="flex flex-col items-stretch gap-3 lg:flex-row">
        {/* JE */}
        <div className="min-w-0 flex-1 rounded-lg border bg-card p-3">
          <span className="inline-block whitespace-nowrap rounded bg-[var(--info)]/15 px-1.5 py-0.5 text-xs font-semibold text-[var(--info)]">
            Journal entry
          </span>
          <p className="mt-2 text-sm font-medium leading-snug">
            {entry.headline}
          </p>
          <dl className="mt-2 grid grid-cols-2 gap-x-4 gap-y-1 text-xs sm:grid-cols-4">
            {[
              { k: "Company", v: entry.companyCode },
              { k: "Ledger", v: entry.ledger },
              { k: "Period", v: entry.postingPeriod },
              { k: "Type", v: entry.documentType },
            ].map((f) => (
              <div key={f.k}>
                <dt className="text-muted-foreground">{f.k}</dt>
                <dd className="font-mono">{f.v}</dd>
              </div>
            ))}
          </dl>
          <table className="mt-3 w-full text-xs">
            <thead>
              <tr className="border-b text-left text-muted-foreground">
                <th className="pb-1 font-medium">Account</th>
                <th className="pb-1 text-right font-medium">Debit</th>
                <th className="pb-1 text-right font-medium">Credit</th>
              </tr>
            </thead>
            <tbody>
              {entry.lines.map((l) => (
                <tr key={l.lineNumber} className="border-b last:border-0">
                  <td className="py-1.5 pr-2">
                    <span className="block leading-tight">{l.plainName}</span>
                    <span className="block font-mono text-muted-foreground">
                      {l.glAccount}
                    </span>
                  </td>
                  <td className="py-1.5 text-right tabular-nums">
                    {l.debit ? millions(l.debit) : "—"}
                  </td>
                  <td className="py-1.5 text-right tabular-nums">
                    {l.credit ? millions(l.credit) : "—"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <p className="mt-2 text-xs text-muted-foreground">
            {entry.postingDate} · {entry.currency}
          </p>
        </div>

        {/* The posting travelling from one to the other */}
        <div className="flex shrink-0 items-center justify-center lg:w-16">
          <div className="relative h-6 w-full lg:h-24 lg:w-6">
            <div className="absolute inset-x-0 top-1/2 h-0.5 -translate-y-1/2 bg-[var(--success)]/30 lg:inset-y-0 lg:left-1/2 lg:top-0 lg:h-full lg:w-0.5 lg:-translate-x-1/2 lg:translate-y-0" />
            <ArrowRight
              className={cn(
                "absolute left-1/2 top-1/2 h-5 w-5 -translate-x-1/2 -translate-y-1/2",
                "text-[var(--success)] transition-all duration-700 ease-out",
                "motion-reduce:transition-none lg:rotate-90",
                revealed ? "opacity-100" : "opacity-30"
              )}
              style={{
                transform: arrived
                  ? undefined
                  : "translate(-50%, -50%) scale(0.8)",
              }}
            />
          </div>
        </div>

        {/* GL */}
        <div className="min-w-0 flex-1 rounded-lg border bg-card p-3">
          <div className="mb-2 flex items-center gap-2">
            <span className="whitespace-nowrap rounded bg-[var(--success)]/15 px-1.5 py-0.5 text-xs font-semibold text-[var(--success)]">
              General ledger
            </span>
            <span className="truncate text-xs text-muted-foreground">
              {revealed ? "Balances after the entry" : "Balances before the entry"}
            </span>
          </div>
          <div className="mt-3 space-y-4">
            {movements.map((m, i) => (
              <div key={m.account}>
                <p className="text-sm font-medium leading-tight">
                  {m.plainName}
                </p>
                <p className="font-mono text-xs text-muted-foreground">
                  {m.account} — {m.accountName}
                </p>
                {/* The account is a programme reserve, not a pot that exists
                    for one claim, so the bar is the year's provision with the
                    prior settlements already drawn from it. This entry takes
                    its slice and a remainder is left, which is what a ledger
                    account actually looks like. */}
                {reserve && (
                  <div className="mt-3">
                    <div className="flex items-baseline justify-between gap-2">
                      <span className="text-xs text-muted-foreground">
                        Set aside for this contract
                      </span>
                      <span className="text-xs tabular-nums text-muted-foreground">
                        {millions(reserve.provision)}
                      </span>
                    </div>
                    <div className="mt-1.5 flex h-3 w-full overflow-hidden rounded bg-muted">
                      <div
                        className="h-full bg-slate-400/60"
                        style={{
                          width: `${(reserve.alreadyDrawn / reserve.provision) * 100}%`,
                        }}
                      />
                      <div
                        className="h-full bg-amber-500 transition-all duration-1000 ease-out motion-reduce:transition-none"
                        style={{
                          width: arrived
                            ? `${(reserve.thisEntry / reserve.provision) * 100}%`
                            : "0%",
                          transitionDelay: `${150 + i * 150}ms`,
                        }}
                      />
                    </div>
                    <dl className="mt-2 grid grid-cols-3 gap-2 border-t pt-2 text-xs">
                      <div>
                        <dt className="text-muted-foreground">Already drawn</dt>
                        <dd className="tabular-nums">
                          {millions(reserve.alreadyDrawn)}
                        </dd>
                      </div>
                      <div>
                        <dt className="text-muted-foreground">This entry</dt>
                        <dd
                          className={cn(
                            "tabular-nums transition-opacity duration-500",
                            arrived ? "opacity-100 text-amber-700" : "opacity-40"
                          )}
                        >
                          {millions(reserve.thisEntry)}
                        </dd>
                      </div>
                      <div>
                        <dt className="text-muted-foreground">Remaining</dt>
                        <dd className="font-semibold tabular-nums">
                          {arrived ? (
                            <CountUp
                              value={reserve.remaining}
                              format={millions}
                              durationMs={1100}
                            />
                          ) : (
                            millions(reserve.remaining + reserve.thisEntry)
                          )}
                        </dd>
                      </div>
                    </dl>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function Rung({
  label,
  width,
  tone,
  value,
  show,
  delayMs = 0,
}: {
  label: string;
  width: number;
  tone: "opening" | "credit" | "debit";
  value: string;
  show: boolean;
  delayMs?: number;
}) {
  return (
    <div>
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs text-muted-foreground">{label}</span>
        <span
          className={cn(
            "text-xs tabular-nums transition-opacity duration-300",
            show ? "opacity-100" : "opacity-0"
          )}
        >
          {value}
        </span>
      </div>
      <div className="mt-0.5 h-2.5 overflow-hidden rounded bg-muted">
        <div
          className={cn(
            "h-full transition-all duration-600 ease-out motion-reduce:transition-none",
            tone === "opening" && "bg-slate-400",
            tone === "credit" && "bg-[var(--success)]",
            tone === "debit" && "bg-amber-500"
          )}
          style={{ width: `${width}%`, transitionDelay: `${delayMs}ms` }}
        />
      </div>
    </div>
  );
}
