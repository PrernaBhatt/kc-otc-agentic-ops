"use client";

import { useState } from "react";
import {
  ArrowRight,
  CircleCheck,
  Package,
  Sparkles,
  TriangleAlert,
  User,
} from "lucide-react";

import { Spinner } from "@/components/agents/spinner";
import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { findInboundPo } from "@/lib/data/pipeline-orders";
import {
  REGULATED_ORDER_ID,
  recallNotices,
  regulatoryDecisionOptions,
  regulatoryGuardrails,
  regulatoryReviews,
  type RegulatoryDecisionOption,
} from "@/lib/data/regulatory";
import { buildInboundPoDoc, buildRecallNoticeDoc } from "@/lib/docs";
import { formatMoney } from "@/lib/selectors";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

function optionTypeBadgeClass(type: RegulatoryDecisionOption["type"]) {
  switch (type) {
    case "Balanced":
      return "bg-[var(--info)] text-white";
    case "Conservative":
      return "bg-[var(--warning)] text-[var(--warning-foreground)]";
    default:
      return "bg-muted text-muted-foreground";
  }
}

/**
 * Quality Hold HITL card for the regulated order (SO-710262). Rendered below
 * the credit hold cards in Review Order Hold, in the same card language:
 * hold banner, order line summary, AI decision panel, human approval.
 */
export function RegulatoryHoldCard({
  onBackToExceptions,
}: {
  onBackToExceptions?: () => void;
}) {
  const { releasedRegulatoryOrders, releaseRegulatoryHold } = useOtcStore();
  const [selectedOptionId, setSelectedOptionId] = useState<string | null>(null);
  const [chosenOptionId, setChosenOptionId] = useState<string | null>(null);
  const [isApproving, setIsApproving] = useState(false);

  const po = findInboundPo(REGULATED_ORDER_ID);
  const review = regulatoryReviews.find(
    (r) => r.orderId === REGULATED_ORDER_ID
  );
  if (!po || !review) return null;

  const released = releasedRegulatoryOrders.has(REGULATED_ORDER_ID);
  const heldLine = po.lines.find((line) => line.lot === review.affectedLot);
  const orderTotal = po.lines.reduce((sum, line) => sum + line.lineValue, 0);
  const chosenOption = regulatoryDecisionOptions.find(
    (option) => option.id === chosenOptionId
  );
  const lotSubstituted = released && chosenOptionId === "substitute-lot";

  const handleApprove = async () => {
    if (!selectedOptionId) return;
    setIsApproving(true);
    await new Promise((resolve) => setTimeout(resolve, 1500));
    releaseRegulatoryHold(REGULATED_ORDER_ID, selectedOptionId);
    setChosenOptionId(selectedOptionId);
    setIsApproving(false);
  };

  return (
    <div className="space-y-6">
      {!released && (
        <Card className="border-primary/50 bg-primary/5">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                <TriangleAlert className="h-5 w-5 text-destructive" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-foreground">
                  Quality Hold Detected
                </div>
                <div className="text-sm text-muted-foreground">
                  Order {po.orderId} is stopped at the regulatory check. AI
                  agents have curated decision options.
                </div>
              </div>
              <Badge className="bg-primary text-primary-foreground gap-1 flex-shrink-0">
                <Spinner size="sm" />
                Action Required
              </Badge>
            </div>
          </CardContent>
        </Card>
      )}
      {released && (
        <Card className="border-[var(--success)]/50 bg-[var(--success)]/5">
          <CardContent className="p-4">
            <div
              className={cn(
                "flex items-center gap-3",
                onBackToExceptions && "mb-4"
              )}
            >
              <div className="h-10 w-10 rounded-full bg-[var(--success)]/10 flex items-center justify-center flex-shrink-0">
                <CircleCheck className="h-5 w-5 text-[var(--success)]" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-foreground">
                  Quality Hold Resolved
                </div>
                <div className="text-sm text-muted-foreground">
                  {chosenOption
                    ? `Decision approved: ${chosenOption.name}. The order moves on from the regulatory check.`
                    : "Decision approved by the Quality & Compliance Manager. The order moves on from the regulatory check."}
                </div>
              </div>
              <Badge className="bg-[var(--success)] text-white flex-shrink-0">
                Resolved
              </Badge>
            </div>
            {onBackToExceptions && (
              <Button
                onClick={onBackToExceptions}
                className="w-full whitespace-nowrap bg-[var(--success)] hover:bg-[var(--success)]/90"
                size="lg"
              >
                Return to Exceptions
                <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            )}
          </CardContent>
        </Card>
      )}
      <Card
        className={cn("transition-all", !released && "border-primary/50")}
      >
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <CardTitle className="text-base font-semibold">
                  {po.orderId}
                </CardTitle>
                {released ? (
                  <Badge className="bg-[var(--success)] text-white">
                    <CircleCheck className="h-3 w-3 mr-1" />
                    Released
                  </Badge>
                ) : (
                  <Badge className="bg-primary text-primary-foreground">
                    <TriangleAlert className="h-3 w-3 mr-1" />
                    Hold
                  </Badge>
                )}
                <Badge
                  variant="outline"
                  className="border-[var(--info)] text-[var(--info)]"
                >
                  Regulated Products
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground">{po.customerName}</p>
            </div>
            <div className="text-right">
              <div className="text-lg font-bold text-foreground">
                {formatMoney(orderTotal)}
              </div>
              <div className="text-xs text-muted-foreground">
                Received {po.receivedAt}
              </div>
            </div>
          </div>
          {!released && (
            <div className="flex items-center gap-2 mt-2 p-2 bg-primary/10 rounded-md">
              <TriangleAlert className="h-4 w-4 text-destructive" />
              <span className="text-sm text-destructive font-medium">
                Hold Reason: Quality Hold — lot {review.affectedLot} is under
                quality review
              </span>
            </div>
          )}
        </CardHeader>
        <CardContent className="pt-0">
          <div className="border-t pt-3">
            <div className="text-sm font-medium mb-2 text-foreground">
              Line Items ({po.lines.length})
            </div>
            <div className="space-y-2">
              {po.lines.map((line) => {
                const isHeldLine =
                  line.lot === review.affectedLot && !released;
                const displayLot =
                  line.lot === review.affectedLot && lotSubstituted
                    ? review.substituteLot
                    : line.lot;
                return (
                  <div
                    key={line.lineId}
                    className={cn(
                      "flex items-center justify-between p-2 rounded-md text-sm",
                      isHeldLine ? "bg-[var(--warning)]/10" : "bg-muted/50"
                    )}
                  >
                    <div className="flex items-center gap-3">
                      <span className="font-mono text-xs text-muted-foreground">
                        {line.sku}
                      </span>
                      <span className="text-foreground">
                        {line.productName}
                      </span>
                      {displayLot && (
                        <Badge
                          variant="outline"
                          className={cn(
                            "text-xs",
                            isHeldLine &&
                              "border-[var(--warning)] text-[var(--warning-foreground)] bg-[var(--warning)]/10",
                            line.lot === review.affectedLot &&
                              lotSubstituted &&
                              "border-[var(--success)] text-[var(--success)]"
                          )}
                        >
                          {isHeldLine
                            ? `Lot ${displayLot} — quality hold`
                            : line.lot === review.affectedLot && lotSubstituted
                              ? `Lot ${displayLot} — substituted`
                              : `Lot ${displayLot}`}
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="text-muted-foreground">
                        Qty: {line.qty}
                      </span>
                      <span className="font-medium text-foreground">
                        {formatMoney(line.lineValue)}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2 mt-4">
            <SourceDocTrigger
              doc={buildRecallNoticeDoc(recallNotices[0])}
              label="View quality hold notice"
            />
            <SourceDocTrigger
              doc={buildInboundPoDoc(po, "regulatory")}
              label="View purchase order"
            />
          </div>
        </CardContent>
      </Card>
      {!released && (
        <Card className="border-primary/20 bg-card">
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-primary" />
                <CardTitle className="text-lg">AI Decision Options</CardTitle>
              </div>
              <Badge variant="outline" className="text-primary border-primary">
                Quality Review
              </Badge>
            </div>
            <CardDescription>
              Select an option to resolve the quality hold on order {po.orderId}
              . Human approval required.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-3 gap-4 p-4 bg-muted/50 rounded-lg">
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 text-muted-foreground text-sm mb-1">
                  <TriangleAlert className="h-4 w-4" />
                  Held Lot
                </div>
                <div className="text-lg font-bold text-foreground">
                  {review.affectedLot}
                </div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 text-muted-foreground text-sm mb-1">
                  <CircleCheck className="h-4 w-4" />
                  Cleared Substitute
                </div>
                <div className="text-lg font-bold text-foreground">
                  {review.substituteLot}
                </div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 text-muted-foreground text-sm mb-1">
                  <Package className="h-4 w-4" />
                  Units Affected
                </div>
                <div className="text-lg font-bold text-foreground">
                  {heldLine ? heldLine.qty : 0}
                </div>
              </div>
            </div>
            <div className="space-y-3">
              {regulatoryDecisionOptions.map((option) => (
                <div
                  key={option.id}
                  className={cn(
                    "p-4 border rounded-lg cursor-pointer transition-all",
                    selectedOptionId === option.id
                      ? "border-primary bg-primary/5 ring-2 ring-primary/20"
                      : "border-border hover:border-primary/50"
                  )}
                  onClick={() => setSelectedOptionId(option.id)}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="pr-4">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <span className="font-semibold text-foreground">
                          {option.name}
                        </span>
                        <Badge className={optionTypeBadgeClass(option.type)}>
                          {option.type}
                        </Badge>
                        {option.recommended && (
                          <Badge
                            variant="outline"
                            className="border-[var(--success)] text-[var(--success)]"
                          >
                            AI Recommended
                          </Badge>
                        )}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-muted-foreground">
                        Confidence
                      </div>
                      <div className="text-lg font-bold text-foreground">
                        {Math.round(100 * option.confidence)}%
                      </div>
                    </div>
                  </div>
                  <ul className="space-y-1">
                    {option.conditions.map((condition) => (
                      <li
                        key={condition}
                        className="flex items-start gap-2 text-sm text-muted-foreground"
                      >
                        <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-primary/60 flex-shrink-0" />
                        {condition}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
            <div className="p-3 bg-[var(--success)]/10 rounded-lg">
              <div className="flex items-center gap-2 text-sm font-medium text-[var(--success)] mb-2">
                <CircleCheck className="h-4 w-4" />
                Guardrails Applied
              </div>
              <div className="flex flex-wrap gap-2">
                {regulatoryGuardrails.map((guardrail) => (
                  <Badge
                    key={guardrail}
                    variant="secondary"
                    className="bg-[var(--success)]/20 text-[var(--success)]"
                  >
                    {guardrail}
                  </Badge>
                ))}
              </div>
            </div>
            <Button
              className="w-full whitespace-nowrap"
              size="lg"
              disabled={!selectedOptionId || isApproving}
              onClick={handleApprove}
            >
              {isApproving ? (
                <>Processing Approval...</>
              ) : (
                <>
                  <User className="h-4 w-4 mr-2" />
                  Approve as Quality &amp; Compliance Manager
                  <ArrowRight className="h-4 w-4 ml-2" />
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
