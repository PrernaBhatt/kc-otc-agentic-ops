"use client";

import { Button } from "@/components/ui/button";
import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { AgentIcon } from "@/components/agents/agent-icon";
import {
  buildBillingReportDoc,
  buildContractDoc,
  buildInboundPoDoc,
  buildInvoiceDoc,
  buildPodDoc,
} from "@/lib/docs";
import {
  TODAY,
  allShipments,
  findInboundPo,
  findShipmentByOrder,
  orders,
  revRecContracts,
  standardPaymentTerms,
} from "@/lib/data";
import type { Invoice } from "@/lib/data/types";
import { formatMoney } from "@/lib/selectors";
import { useOtcStore } from "@/lib/store";
import {
  CalendarCheck,
  CircleCheck,
  Clock,
  Mail,
  Receipt,
} from "lucide-react";

/* ------------------------------------------------------------------ */
/* Shared helpers                                                      */
/* ------------------------------------------------------------------ */

function addDays(iso: string, days: number): string {
  const d = new Date(iso + "T00:00:00Z");
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

function formatShortDate(isoDate: string): string {
  return new Date(isoDate + "T00:00:00Z").toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    timeZone: "UTC",
  });
}

/**
 * The delivered-but-not-yet-invoiced picture the Capture stage reads. Rows are
 * derived live: delivered shipments joined to their orders, with "invoiced"
 * reflecting the store (a real invoice exists, or the order was billed in this
 * session) — so issuing an invoice anywhere updates this list and its report.
 */
function eligibleBillingRows(
  allInvoices: Invoice[],
  billedOrderIds: Set<string>
) {
  return allShipments
    .filter((s) => s.status === "Delivered")
    .flatMap((s) => {
      const order = orders.find((o) => o.orderId === s.orderId);
      if (!order) return [];
      return [
        {
          orderId: order.orderId,
          customerName: order.customerName,
          deliveredDate: s.deliveredDate ?? s.promisedDate,
          amount: order.totalValue,
          invoiced:
            allInvoices.some((inv) => inv.orderId === order.orderId) ||
            billedOrderIds.has(order.orderId),
        },
      ];
    });
}

/** Draft invoice the human is asked to approve — real amounts, not yet issued. */
function buildDraftInvoice(orderId: string): Invoice | null {
  const order = orders.find((o) => o.orderId === orderId);
  if (!order) return null;
  return {
    invoiceId: "Draft",
    orderId: order.orderId,
    customerId: order.customerId,
    customerName: order.customerName,
    invoiceDate: TODAY,
    dueDate: addDays(TODAY, 30),
    amount: order.totalValue,
    status: "Pending",
  };
}

function PanelShell({
  caption,
  children,
}: {
  caption: string;
  children: React.ReactNode;
}) {
  return (
    <div className="mt-3 rounded-lg border bg-muted/20 p-4 space-y-3 animate-in fade-in slide-in-from-top-1 duration-200">
      <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
        {caption}
      </p>
      {children}
    </div>
  );
}

function CheckLine({ text, done = true }: { text: string; done?: boolean }) {
  return (
    <div className="flex items-center gap-2 text-sm">
      {done ? (
        <CircleCheck className="w-4 h-4 shrink-0 text-green-600" />
      ) : (
        <Clock className="w-4 h-4 shrink-0 text-amber-600" />
      )}
      <span className={done ? "text-foreground" : "text-amber-700"}>
        {text}
      </span>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Stage panels                                                        */
/* ------------------------------------------------------------------ */

function CapturePanel({ orderId }: { orderId: string }) {
  const { allInvoices, billedOrderIds } = useOtcStore();
  const rows = eligibleBillingRows(allInvoices, billedOrderIds);
  return (
    <PanelShell caption="Capture — how this order entered the billing pipeline">
      <p className="text-sm text-muted-foreground">
        AI watches deliveries and lists every delivered order that has no
        invoice yet — this order is on that list, which is what starts its
        billing run.
      </p>
      <div className="rounded-md border bg-background">
        <div className="grid grid-cols-[1fr_1.4fr_auto_auto] gap-x-4 border-b px-3 py-2 text-xs font-medium text-muted-foreground">
          <span>Order</span>
          <span>Customer</span>
          <span className="text-right">Amount</span>
          <span className="text-right">Invoice status</span>
        </div>
        {rows.map((row) => (
          <div
            key={row.orderId}
            className={[
              "grid grid-cols-[1fr_1.4fr_auto_auto] items-center gap-x-4 border-b px-3 py-2 text-sm last:border-b-0",
              row.orderId === orderId ? "bg-primary/5 font-medium" : "",
            ].join(" ")}
          >
            <span className="font-mono">{row.orderId}</span>
            <span className="truncate">{row.customerName}</span>
            <span className="text-right">{formatMoney(row.amount)}</span>
            <span
              className={[
                "justify-self-end rounded-full border px-2 py-0.5 text-xs whitespace-nowrap",
                row.invoiced
                  ? "bg-green-50 text-green-700 border-green-300"
                  : "bg-amber-50 text-amber-700 border-amber-300",
              ].join(" ")}
            >
              {row.invoiced ? "Invoiced" : "Pending invoice"}
            </span>
          </div>
        ))}
      </div>
      <SourceDocTrigger
        doc={buildBillingReportDoc(rows)}
        label="View eligible billing report"
      />
    </PanelShell>
  );
}

function DeliveryValidationPanel({ orderId }: { orderId: string }) {
  const shipment = findShipmentByOrder(orderId);
  if (!shipment) return null;
  return (
    <PanelShell caption="Delivery validation — the goods really arrived">
      <div className="space-y-1.5">
        {shipment.milestones.map((m) => (
          <CheckLine
            key={m.id}
            text={`${m.label} — ${m.timestamp}`}
            done={m.done}
          />
        ))}
      </div>
      {shipment.podSignedBy && (
        <p className="text-sm text-muted-foreground">
          Received and signed by{" "}
          <span className="font-medium text-foreground">
            {shipment.podSignedBy}
          </span>{" "}
          on {shipment.deliveredDate}. The signed record is what clears this
          order for invoicing.
        </p>
      )}
      <SourceDocTrigger
        doc={buildPodDoc(shipment)}
        label="View signed delivery record"
      />
    </PanelShell>
  );
}

function PoValidationPanel({ orderId }: { orderId: string }) {
  const po = findInboundPo(orderId);
  const order = orders.find((o) => o.orderId === orderId);
  if (!po || !order) return null;
  const poTotal = po.lines.reduce((s, l) => s + l.lineValue, 0);
  return (
    <PanelShell caption="Purchase order validation — customer order vs our order">
      <div className="rounded-md border bg-background">
        <div className="grid grid-cols-[1.4fr_1fr_1fr_auto] gap-x-4 border-b px-3 py-2 text-xs font-medium text-muted-foreground">
          <span>Product</span>
          <span className="text-right">Purchase order</span>
          <span className="text-right">Sales order</span>
          <span className="text-right">Check</span>
        </div>
        {po.lines.map((pl) => {
          const ol = order.lineItems.find((l) => l.sku === pl.sku);
          const match =
            !!ol && ol.qty === pl.qty && ol.lineValue === pl.lineValue;
          return (
            <div
              key={pl.lineId}
              className="grid grid-cols-[1.4fr_1fr_1fr_auto] items-center gap-x-4 border-b px-3 py-2 text-sm"
            >
              <span className="truncate">{pl.productName}</span>
              <span className="text-right">
                {pl.qty.toLocaleString()} units · {formatMoney(pl.lineValue)}
              </span>
              <span className="text-right">
                {ol
                  ? `${ol.qty.toLocaleString()} units · ${formatMoney(ol.lineValue)}`
                  : "Not found"}
              </span>
              <span
                className={[
                  "justify-self-end rounded-full border px-2 py-0.5 text-xs whitespace-nowrap",
                  match
                    ? "bg-green-50 text-green-700 border-green-300"
                    : "bg-amber-50 text-amber-700 border-amber-300",
                ].join(" ")}
              >
                {match ? "Pass" : "Review"}
              </span>
            </div>
          );
        })}
        <div className="grid grid-cols-[1.4fr_1fr_1fr_auto] items-center gap-x-4 px-3 py-2 text-sm font-medium">
          <span>Total</span>
          <span className="text-right">{formatMoney(poTotal)}</span>
          <span className="text-right">{formatMoney(order.totalValue)}</span>
          <span
            className={[
              "justify-self-end rounded-full border px-2 py-0.5 text-xs whitespace-nowrap",
              poTotal === order.totalValue
                ? "bg-green-50 text-green-700 border-green-300"
                : "bg-amber-50 text-amber-700 border-amber-300",
            ].join(" ")}
          >
            {poTotal === order.totalValue ? "Pass" : "Review"}
          </span>
        </div>
      </div>
      <SourceDocTrigger
        doc={buildInboundPoDoc(po, "extraction")}
        label="View customer purchase order"
      />
    </PanelShell>
  );
}

function ContractValidationPanel({ orderId }: { orderId: string }) {
  const order = orders.find((o) => o.orderId === orderId);
  if (!order) return null;
  const contract = revRecContracts.find(
    (c) => c.customerId === order.customerId
  );
  return (
    <PanelShell caption="Contract validation — the terms this invoice must follow">
      {contract ? (
        <>
          <div className="grid gap-3 text-sm sm:grid-cols-3">
            <div>
              <p className="text-xs text-muted-foreground">Agreement</p>
              <p className="font-mono font-medium">{contract.contractId}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Payment terms</p>
              <p className="font-medium">{contract.paymentTerms}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Volume rebate</p>
              <p className="font-medium">
                {contract.rebatePercent > 0
                  ? `${contract.rebatePercent}% set aside on every recognized sale`
                  : "No volume rebate"}
              </p>
            </div>
          </div>
          <p className="text-sm text-muted-foreground">{contract.notes}</p>
          <SourceDocTrigger
            doc={buildContractDoc(contract)}
            label="View contract summary"
          />
        </>
      ) : (
        <>
          <CheckLine
            text={`Standard terms apply — ${standardPaymentTerms} payment, prices from the agreed list, no volume rebate.`}
          />
          <p className="text-sm text-muted-foreground">
            {order.customerName} has no master agreement on file, so the
            invoice follows our standard terms. Every line on this order
            passed the price and tax checks.
          </p>
        </>
      )}
    </PanelShell>
  );
}

function DocumentCheckPanel({ orderId }: { orderId: string }) {
  const po = findInboundPo(orderId);
  const shipment = findShipmentByOrder(orderId);
  const order = orders.find((o) => o.orderId === orderId);
  if (!order) return null;
  const contract = revRecContracts.find(
    (c) => c.customerId === order.customerId
  );
  return (
    <PanelShell caption="Document check — everything needed to bill is on file">
      <div className="space-y-1.5">
        <CheckLine
          text={`Purchase order${po ? ` ${po.poNumber}` : ""} — on file`}
        />
        <CheckLine
          text={`Delivery record ${shipment ? shipment.shipmentId : ""}${
            shipment?.podSignedBy ? `, signed by ${shipment.podSignedBy}` : ""
          } — on file`}
        />
        <CheckLine
          text={`Contract terms ${
            contract ? contract.contractId : `(standard ${standardPaymentTerms} terms)`
          } — on file`}
        />
      </div>
      <p className="text-sm text-muted-foreground">
        Nothing is missing for this order, so the draft invoice can be prepared
        for your approval.
      </p>
    </PanelShell>
  );
}

/**
 * Billing Generation — the human-in-the-loop step. AI prepares the draft
 * invoice from the validated documents; nothing is issued until a person
 * clicks "Approve & issue invoice", which calls the store's issueInvoice so
 * the real invoice appears in Transactions and the month-end billing
 * completeness check moves with it.
 */
function BillingGenerationPanel({
  orderId,
  isCurrentStage,
}: {
  orderId: string;
  isCurrentStage?: boolean;
}) {
  const { allInvoices, issueInvoice } = useOtcStore();
  const order = orders.find((o) => o.orderId === orderId);
  const po = findInboundPo(orderId);
  if (!order) return null;
  const issued = allInvoices.find((inv) => inv.orderId === orderId);
  const draft = buildDraftInvoice(orderId);
  const terms = po?.paymentTerms ?? standardPaymentTerms;

  if (issued) {
    return (
      <PanelShell caption="Billing generation — issued with your approval">
        <div className="flex items-start gap-3 rounded-lg border border-green-300 bg-green-50 p-3">
          <CircleCheck className="mt-0.5 w-5 h-5 shrink-0 text-green-600" />
          <div className="text-sm text-green-800">
            <p className="font-semibold">
              Invoice {issued.invoiceId} issued — approved by you
            </p>
            <p>
              {formatMoney(issued.amount)} to {issued.customerName}, dated{" "}
              {issued.invoiceDate}, due {formatShortDate(issued.dueDate)}. It
              now appears under Transactions → Invoices and counts toward the
              month-end billing completeness check.
            </p>
          </div>
        </div>
        <SourceDocTrigger
          doc={buildInvoiceDoc(issued)}
          label={`View invoice ${issued.invoiceId}`}
        />
      </PanelShell>
    );
  }

  if (!draft) return null;
  return (
    <PanelShell caption="Billing generation — waiting for your approval">
      <div className="flex items-start gap-3">
        <AgentIcon type="invoice" size="md" className="shrink-0 text-primary" />
        <div className="text-sm">
          <p className="font-semibold text-foreground">
            AI drafted this invoice from the tie-out
          </p>
          <p className="text-muted-foreground">
            The purchase order, sales order, and signed delivery record all
            agree, so the draft simply carries those numbers forward. Nothing
            is sent until you approve.
          </p>
        </div>
      </div>
      <div className="grid gap-3 rounded-md border bg-background p-3 text-sm sm:grid-cols-3">
        <div>
          <p className="text-xs text-muted-foreground">Invoice amount</p>
          <p className="font-semibold">{formatMoney(draft.amount)}</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground">Payment terms</p>
          <p className="font-medium">{terms}</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground">Due date</p>
          <p className="font-medium">{formatShortDate(draft.dueDate)}</p>
        </div>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <SourceDocTrigger
          doc={buildInvoiceDoc(draft, {
            highlight: true,
            note: "Draft — not yet issued. The highlighted amount is what goes out once you approve.",
          })}
          label="View draft invoice"
        />
        {isCurrentStage ? (
          <Button
            className="whitespace-nowrap"
            onClick={() => issueInvoice(orderId)}
          >
            <Receipt className="w-4 h-4 mr-2" />
            Approve &amp; issue invoice
          </Button>
        ) : (
          <span className="text-xs text-muted-foreground">
            The pipeline pauses at this step for your approval when the run
            reaches it.
          </span>
        )}
      </div>
    </PanelShell>
  );
}

function InvoiceDeliveryPanel({ orderId }: { orderId: string }) {
  const { allInvoices } = useOtcStore();
  const issued = allInvoices.find((inv) => inv.orderId === orderId);
  return (
    <PanelShell caption="Invoice delivery — how it reaches the customer">
      <div className="flex items-center gap-2 text-sm">
        <Mail className="w-4 h-4 shrink-0 text-primary" />
        <span>Sent by email with the signed delivery record attached.</span>
      </div>
      {issued ? (
        <SourceDocTrigger
          doc={buildInvoiceDoc(issued)}
          label={`View invoice ${issued.invoiceId}`}
        />
      ) : (
        <p className="text-xs text-muted-foreground">
          The issued invoice is attached here once you approve it at the
          Billing Generation step.
        </p>
      )}
    </PanelShell>
  );
}

function CompletedPanel({ orderId }: { orderId: string }) {
  const { allInvoices } = useOtcStore();
  const issued = allInvoices.find((inv) => inv.orderId === orderId);
  return (
    <PanelShell caption="Completed — where this order shows up next">
      <div className="flex items-center gap-2 text-sm">
        <CalendarCheck className="w-4 h-4 shrink-0 text-primary" />
        <span className="font-medium text-primary">
          Counted in the month-end billing completeness check on the Dashboard.
        </span>
      </div>
      {issued && (
        <p className="text-sm text-muted-foreground">
          Invoice {issued.invoiceId} for {formatMoney(issued.amount)} is now in
          Transactions → Invoices and starts aging from its{" "}
          {formatShortDate(issued.dueDate)} due date.
        </p>
      )}
    </PanelShell>
  );
}

/* ------------------------------------------------------------------ */
/* Entry point                                                         */
/* ------------------------------------------------------------------ */

/**
 * One panel per billing pipeline stage. Opened by clicking a stage chip on a
 * billing card (one panel at a time), and embedded in the processing run at
 * the Billing Generation stage, where the run pauses for human approval.
 */
export function BillingStagePanel({
  stageId,
  orderId,
  isCurrentStage,
}: {
  stageId: string;
  orderId: string;
  isCurrentStage?: boolean;
}) {
  switch (stageId) {
    case "capture":
      return <CapturePanel orderId={orderId} />;
    case "delivery_validation":
      return <DeliveryValidationPanel orderId={orderId} />;
    case "po_validation":
      return <PoValidationPanel orderId={orderId} />;
    case "contract_validation":
      return <ContractValidationPanel orderId={orderId} />;
    case "document_check":
      return <DocumentCheckPanel orderId={orderId} />;
    case "billing_generation":
      return (
        <BillingGenerationPanel
          orderId={orderId}
          isCurrentStage={isCurrentStage}
        />
      );
    case "invoice_delivery":
      return <InvoiceDeliveryPanel orderId={orderId} />;
    case "completed":
      return <CompletedPanel orderId={orderId} />;
    default:
      return null;
  }
}
