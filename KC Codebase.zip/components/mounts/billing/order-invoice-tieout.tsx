"use client";

import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import {
  buildClaimDoc,
  buildInvoiceDoc,
  buildPodDoc,
  buildSalesOrderDoc,
} from "@/lib/docs";
import { findShipmentByOrder, orders } from "@/lib/data";
import { useTypewriter } from "@/lib/hooks/use-typewriter";
import { formatMoney } from "@/lib/selectors";
import { useOtcStore } from "@/lib/store";
import {
  ChevronDown,
  CircleCheck,
  Receipt,
  Sparkles,
  TriangleAlert,
} from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * The AI's read of the mismatch, revealed character by character when the row
 * opens (mounts on expand, so it retypes each time) — a plain-language summary
 * of why the invoice fell short of the order and what happens to the gap.
 */
function AiDamageAnalysis({ text }: { text: string }) {
  const { visible, done } = useTypewriter(text, 12);
  return (
    <div className="rounded-md border border-amber-300 bg-amber-50 p-3">
      <div className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold text-amber-800">
        <Sparkles className="h-3.5 w-3.5" />
        AI analysis
      </div>
      <p className="whitespace-pre-wrap text-sm leading-relaxed text-amber-800">
        {visible}
        {!done && (
          <span className="ml-0.5 inline-block h-3.5 w-[2px] -mb-0.5 bg-amber-700 animate-caret-blink" />
        )}
      </p>
    </div>
  );
}

const TIEOUT_ORDER_ID = "SO-710248";
const MISMATCH_ORDER_ID = "SO-710247";
/** Customer PO numbers are seeded (only inbound pipeline POs live in lib/data). */
const SEED_CLEAN_PO = { poNumber: "PO-HPB-9104", poDate: "2026-08-13" };
const SEED_MISMATCH_PO = { poNumber: "PO-VKB-1098", poDate: "2026-08-13" };

/** One compact document line inside an expanded tie-out. */
function DocLine({
  label,
  reference,
  qty,
  amount,
  ok,
  note,
}: {
  label: string;
  reference: string;
  qty: number;
  amount: number;
  ok: boolean;
  note?: string;
}) {
  return (
    <div
      className={cn(
        "flex items-center justify-between gap-3 rounded-md border px-3 py-2 text-sm",
        ok ? "border-green-200 bg-green-50/50" : "border-amber-300 bg-amber-50/50"
      )}
    >
      <div className="min-w-0">
        <div className="flex items-center gap-2">
          {ok ? (
            <CircleCheck className="h-4 w-4 shrink-0 text-green-600" />
          ) : (
            <TriangleAlert className="h-4 w-4 shrink-0 text-amber-600" />
          )}
          <span className="text-xs uppercase tracking-wide text-muted-foreground">
            {label}
          </span>
          <span className="font-mono text-xs font-semibold">{reference}</span>
        </div>
        {note && <p className="mt-0.5 pl-6 text-xs text-amber-800">{note}</p>}
      </div>
      <div className="shrink-0 text-right">
        <div className="text-xs text-muted-foreground">
          {qty.toLocaleString()} units
        </div>
        <div className="font-medium">{formatMoney(amount)}</div>
      </div>
    </div>
  );
}

/** Collapsed summary row + click-to-expand detail for one tie-out case. */
function TieoutRow({
  open,
  onToggle,
  orderRef,
  statusOk,
  statusText,
  summary,
  tail,
  action,
  children,
}: {
  open: boolean;
  onToggle: () => void;
  orderRef: string;
  statusOk: boolean;
  statusText: string;
  summary: string;
  tail: React.ReactNode;
  action?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <Card className="overflow-hidden py-0 gap-0">
      <div
        role="button"
        tabIndex={0}
        onClick={onToggle}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            onToggle();
          }
        }}
        className="flex w-full flex-wrap items-center gap-x-3 gap-y-2 px-4 py-3 text-left cursor-pointer"
      >
        <span className="font-mono text-sm font-semibold shrink-0">
          {orderRef}
        </span>
        <Badge
          variant="outline"
          className={cn(
            "whitespace-nowrap",
            statusOk
              ? "border-green-300 bg-green-50 text-green-700"
              : "border-amber-300 bg-amber-50 text-amber-700"
          )}
        >
          {statusOk ? (
            <CircleCheck className="h-3 w-3" />
          ) : (
            <TriangleAlert className="h-3 w-3" />
          )}
          {statusText}
        </Badge>
        <span className="text-sm text-muted-foreground truncate flex-1 min-w-32">
          {summary}
        </span>
        {tail}
        {action}
        <ChevronDown
          className={cn(
            "h-4 w-4 text-muted-foreground shrink-0 transition-transform",
            open && "rotate-180"
          )}
        />
      </div>
      {open && <div className="border-t px-4 py-3 space-y-3">{children}</div>}
    </Card>
  );
}

export function OrderInvoiceTieout() {
  const { billedOrderIds, issueInvoice, allInvoices, deductionCases } =
    useOtcStore();
  const [openRow, setOpenRow] = useState<string | null>(null);

  // ---- Clean case: SO-710248 ----
  const cleanOrder = orders.find((o) => o.orderId === TIEOUT_ORDER_ID);
  const cleanShipment = findShipmentByOrder(TIEOUT_ORDER_ID);
  const cleanInvoice = allInvoices.find((i) => i.orderId === TIEOUT_ORDER_ID);
  const cleanBilled =
    !!cleanInvoice || billedOrderIds.has(TIEOUT_ORDER_ID);
  const cleanQty =
    cleanOrder?.lineItems.reduce((s, l) => s + l.qty, 0) ?? 0;
  const cleanAmount = cleanOrder?.totalValue ?? 0;

  // ---- Mismatch case: SO-710247 ----
  const mismOrder = orders.find((o) => o.orderId === MISMATCH_ORDER_ID);
  const mismShipment = findShipmentByOrder(MISMATCH_ORDER_ID);
  const mismDeduction = mismShipment
    ? deductionCases.find((d) =>
        d.evidence.some((ev) => ev.label.includes(mismShipment.shipmentId))
      )
    : undefined;
  const mismInvoice = mismDeduction
    ? allInvoices.find((i) => i.invoiceId === mismDeduction.invoiceId)
    : undefined;
  const mismQty = mismOrder?.lineItems.reduce((s, l) => s + l.qty, 0) ?? 0;
  const mismAmount = mismOrder?.totalValue ?? 0;
  return (
    <div className="space-y-3">
      <div>
        <h2 className="text-lg font-bold text-foreground">
          Order-to-Invoice Tie-Out
        </h2>
        <p className="text-sm text-muted-foreground">
          The purchase order, sales order, delivery record and invoice must
          agree before an invoice goes out
        </p>
      </div>

      {/* Clean case */}
      {cleanOrder && cleanShipment && (
        <TieoutRow
          open={openRow === "clean"}
          onToggle={() => setOpenRow((p) => (p === "clean" ? null : "clean"))}
          orderRef={cleanOrder.orderId}
          statusOk
          statusText="Documents agree"
          summary={`${cleanQty.toLocaleString()} units · ${formatMoney(cleanAmount)}`}
          tail={
            <Badge
              variant="outline"
              className={cn(
                "whitespace-nowrap shrink-0",
                cleanBilled
                  ? "border-green-300 bg-green-50 text-green-700"
                  : "border-amber-300 bg-amber-50 text-amber-700"
              )}
            >
              {cleanBilled && cleanInvoice ? cleanInvoice.invoiceId : "Invoice pending"}
            </Badge>
          }
          action={
            !cleanBilled ? (
              <Button
                size="sm"
                className="whitespace-nowrap shrink-0"
                onClick={(e) => {
                  e.stopPropagation();
                  issueInvoice(TIEOUT_ORDER_ID);
                }}
              >
                <Receipt className="h-3.5 w-3.5" />
                Generate invoice
              </Button>
            ) : undefined
          }
        >
          <div className="space-y-2">
            <DocLine label="Purchase order" reference={SEED_CLEAN_PO.poNumber} qty={cleanQty} amount={cleanAmount} ok />
            <DocLine label="Sales order" reference={cleanOrder.orderId} qty={cleanQty} amount={cleanAmount} ok />
            <DocLine label="Delivery record" reference={cleanShipment.shipmentId} qty={cleanQty} amount={cleanAmount} ok note="Delivered and signed" />
            {cleanBilled && cleanInvoice ? (
              <DocLine label="Invoice" reference={cleanInvoice.invoiceId} qty={cleanQty} amount={cleanInvoice.amount} ok />
            ) : (
              <DocLine label="Invoice" reference="Ready to issue" qty={cleanQty} amount={cleanAmount} ok note="Same quantity and value as the order, sales order and delivery — cleared to issue on your approval" />
            )}
          </div>
          <div className="flex flex-wrap items-center gap-2 pt-1">
            <span className="text-xs text-muted-foreground">
              {cleanBilled
                ? "Invoiced — counted in the month-end billing completeness check."
                : "Prices, tax and delivery all check out. Nothing is sent until you approve."}
            </span>
            <div className="ml-auto flex gap-2">
              <SourceDocTrigger doc={buildPodDoc(cleanShipment)} label="View delivery record" variant="ghost" />
              <SourceDocTrigger doc={buildSalesOrderDoc(cleanOrder)} label="View sales order" variant="ghost" />
            </div>
          </div>
        </TieoutRow>
      )}

      {/* Mismatch case */}
      {mismOrder && mismShipment && mismDeduction && mismInvoice && (
        <TieoutRow
          open={openRow === "mismatch"}
          onToggle={() => setOpenRow((p) => (p === "mismatch" ? null : "mismatch"))}
          orderRef={mismOrder.orderId}
          statusOk={false}
          statusText="Mismatch"
          summary={`${formatMoney(mismAmount)} order vs ${formatMoney(mismInvoice.amount)} invoiced`}
          tail={
            <Badge
              variant="outline"
              className="whitespace-nowrap shrink-0 border-amber-300 bg-amber-50 text-amber-700"
            >
              Write-Off
            </Badge>
          }
        >
          <div className="space-y-2">
            <DocLine label="Purchase order" reference={SEED_MISMATCH_PO.poNumber} qty={mismQty} amount={mismAmount} ok />
            <DocLine label="Sales order" reference={mismOrder.orderId} qty={mismQty} amount={mismAmount} ok />
            <DocLine label="Delivery record" reference={mismShipment.shipmentId} qty={mismQty} amount={mismAmount} ok note={`Arrived ${mismShipment.delayDays} days late — damage reported on arrival`} />
            <DocLine label="Invoice" reference={mismInvoice.invoiceId} qty={mismQty} amount={mismInvoice.amount} ok={false} note="Invoiced below the order value after the damage claim" />
          </div>
          <AiDamageAnalysis
            text={`The goods arrived late and damaged, so the invoice went below the order value — that ${formatMoney(
              mismAmount - mismInvoice.amount
            )} shortfall will be written-off.`}
          />
          <div className="flex flex-wrap items-center gap-2 pt-1">
            <div className="ml-auto flex gap-2">
              <SourceDocTrigger doc={buildPodDoc(mismShipment)} label="View delivery record" variant="ghost" />
              <SourceDocTrigger doc={buildInvoiceDoc(mismInvoice)} label={`View invoice ${mismInvoice.invoiceId}`} variant="ghost" />
              <SourceDocTrigger doc={buildClaimDoc(mismDeduction)} label="View customer claim" variant="ghost" />
            </div>
          </div>
        </TieoutRow>
      )}
    </div>
  );
}
