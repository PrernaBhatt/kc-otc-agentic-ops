"use client";

import { ArrowRight, Info, Scale } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CountUp } from "@/components/ui/count-up";
import { VARIABLE_CONSIDERATION_CONSTRAINT } from "@/lib/data/revrec";
import { formatMoney, type ContraRevenueLine } from "@/lib/selectors";

/**
 * Transaction price after variable consideration (be-creative). The recognized
 * price steps down to net revenue through four broken-out set-asides — rebate,
 * promotions, loyalty and returns — instead of one generic "contra-revenue"
 * line. Each set-aside gets a mini-bar scaled to the largest so the relative
 * sizes read at a glance; bars grow on mount. The constraint note explains why
 * the total is capped.
 */
export function VariableConsiderationPanel({
  grossRecognized,
  contra,
  contraTotal,
  netRevenue,
}: {
  grossRecognized: number;
  contra: ContraRevenueLine[];
  contraTotal: number;
  netRevenue: number;
}) {
  const maxContra = Math.max(1, ...contra.map((c) => c.amount));
  const setAsidePct = Math.round((contraTotal / grossRecognized) * 100);

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center gap-2">
          <Scale className="h-4 w-4 text-primary" />
          Transaction price after variable consideration
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          What the recognized price becomes once expected rebates, promotions
          and returns are held back
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Gross → Net headline */}
        <div className="flex flex-wrap items-center gap-3 rounded-lg border bg-muted/30 p-4">
          <div>
            <div className="text-xs text-muted-foreground">
              Recognized price
            </div>
            <div className="text-xl font-bold text-foreground">
              {formatMoney(grossRecognized)}
            </div>
          </div>
          <ArrowRight className="h-5 w-5 text-muted-foreground" />
          <div>
            <div className="text-xs text-muted-foreground">
              Less set-asides ({setAsidePct}%)
            </div>
            <div className="text-xl font-bold text-amber-700">
              −
              <CountUp
                value={contraTotal}
                durationMs={700}
                format={(n) => formatMoney(Math.round(n))}
              />
            </div>
          </div>
          <ArrowRight className="h-5 w-5 text-muted-foreground" />
          <div className="ml-auto text-right">
            <div className="text-xs text-muted-foreground">Net revenue</div>
            <div className="text-2xl font-bold text-[var(--success)]">
              <CountUp
                value={netRevenue}
                durationMs={900}
                format={(n) => formatMoney(Math.round(n))}
              />
            </div>
          </div>
        </div>

        {/* Broken-out set-asides */}
        <div className="space-y-2">
          <div className="text-xs font-medium text-muted-foreground">
            Set aside from revenue — each broken out, not lumped together
          </div>
          {contra.map((line, i) => (
            <div key={line.key} className="flex items-center gap-3">
              <div className="w-40 shrink-0 text-sm text-foreground">
                {line.label}
                <div className="text-[11px] text-muted-foreground">
                  {Math.round(line.rate * 1000) / 10}% of recognized
                </div>
              </div>
              <div className="h-6 flex-1 min-w-0 rounded bg-muted/40 overflow-hidden">
                <div
                  className="h-full rounded bg-amber-400/60 transition-all duration-700 ease-out"
                  style={{
                    width: `${(line.amount / maxContra) * 100}%`,
                    transitionDelay: `${i * 90}ms`,
                  }}
                />
              </div>
              <div className="w-20 shrink-0 text-right text-sm font-semibold text-foreground tabular-nums">
                {formatMoney(line.amount)}
              </div>
            </div>
          ))}
        </div>

        {/* Constraint note */}
        <div className="flex items-start gap-2 rounded-lg border border-primary/20 bg-primary/5 p-3">
          <Info className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
          <div className="text-sm text-muted-foreground">
            <Badge
              variant="outline"
              className="mr-2 border-primary/40 text-primary"
            >
              Variable consideration
            </Badge>
            {VARIABLE_CONSIDERATION_CONSTRAINT}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
