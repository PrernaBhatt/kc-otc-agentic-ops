"use client";

import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { AgentIcon } from "@/components/agents/agent-icon";
import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { VariableConsiderationPanel } from "@/components/mounts/billing/variable-consideration-panel";
import { buildContractDoc, buildRevRecScheduleDoc } from "@/lib/docs";
import { findShipmentByOrder, revRecContracts } from "@/lib/data";
import { formatMoney, revRecSummary } from "@/lib/selectors";
import { useOtcStore } from "@/lib/store";
import { CircleCheck, ClipboardCheck, Clock, Percent } from "lucide-react";

/** The obligation the month-end cut-off check watches: undelivered product revenue promised before month end. */
const CUTOFF_OBLIGATION_ID = "OBL-002";

function formatShortDate(isoDate: string): string {
  return new Date(isoDate + "T00:00:00Z").toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    timeZone: "UTC",
  });
}

/**
 * E5 — Revenue Recognition tab. Reads obligations from the store and the
 * contracts from lib/data; all money figures come from revRecSummary so
 * they always agree with the recognition schedule document.
 */
export function RevenueRecognitionTab() {
  const { obligations } = useOtcStore();
  const [cutoffReviewed, setCutoffReviewed] = useState(false);

  const summary = revRecSummary(obligations);
  const totalUnderContract = summary.recognized + summary.deferred;
  const cutoff = obligations.find((o) => o.id === CUTOFF_OBLIGATION_ID);
  const cutoffShipment = cutoff
    ? findShipmentByOrder(cutoff.orderId)
    : undefined;
  const promisedLabel = cutoffShipment
    ? formatShortDate(cutoffShipment.promisedDate)
    : "";

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-bold text-foreground">
          Revenue Recognition
        </h2>
        <p className="text-sm text-muted-foreground">
          When each dollar under contract counts as revenue — recognized on
          delivery, deferred until then
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardContent>
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-[var(--success)]/10">
                <CircleCheck className="w-6 h-6 text-[var(--success)]" />
              </div>
              <div>
                <div className="text-2xl font-bold">
                  {formatMoney(summary.recognized)}
                </div>
                <div className="text-xs text-muted-foreground">
                  Recognized this period
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent>
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-500/10">
                <Clock className="w-6 h-6 text-amber-600" />
              </div>
              <div>
                <div className="text-2xl font-bold">
                  {formatMoney(summary.deferred)}
                </div>
                <div className="text-xs text-muted-foreground">Deferred</div>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent>
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <Percent className="w-6 h-6 text-primary" />
              </div>
              <div>
                <div className="text-2xl font-bold">
                  {formatMoney(summary.contraTotal)}
                </div>
                <div className="text-xs text-muted-foreground">
                  Set aside from revenue
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-4">
        <div>
          <h3 className="font-semibold text-foreground">Contracts</h3>
          <p className="text-sm text-muted-foreground">
            The agreement terms that decide when revenue is recognized and what
            is set aside
          </p>
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          {revRecContracts.map((contract) => (
            <Card
              key={contract.contractId}
              className="flex h-full flex-col gap-4 p-6"
            >
              <div className="flex items-center justify-between">
                <span className="font-mono text-sm text-muted-foreground">
                  {contract.contractId}
                </span>
                <Badge
                  variant="outline"
                  className={
                    contract.rebatePercent > 0
                      ? "bg-blue-50 text-blue-700 border-blue-300"
                      : "bg-gray-50 text-gray-600 border-gray-300"
                  }
                >
                  {contract.rebatePercent > 0
                    ? `${contract.rebatePercent}% volume rebate`
                    : "No volume rebate"}
                </Badge>
              </div>
              <div className="font-semibold text-foreground">
                {contract.customerName}
              </div>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-xs text-muted-foreground">Payment terms</p>
                  <p className="font-medium">{contract.paymentTerms}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">
                    Delivery terms
                  </p>
                  <p className="font-medium">{contract.deliveryTerms}</p>
                </div>
              </div>
              <p className="text-sm text-muted-foreground">{contract.notes}</p>
              <div className="mt-auto pt-1">
                <SourceDocTrigger
                  doc={buildContractDoc(contract)}
                  label="View contract summary"
                />
              </div>
            </Card>
          ))}
        </div>
      </div>

      <VariableConsiderationPanel
        grossRecognized={summary.recognized}
        contra={summary.contra}
        contraTotal={summary.contraTotal}
        netRevenue={summary.netRevenue}
      />

      <div className="space-y-4">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h3 className="font-semibold text-foreground">Obligations</h3>
            <p className="text-sm text-muted-foreground">
              Each promise made to a customer, its share of the contract price,
              and when it becomes revenue
            </p>
          </div>
          <SourceDocTrigger
            doc={buildRevRecScheduleDoc(obligations)}
            label="View recognition schedule"
          />
        </div>
        <Card>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Order</TableHead>
                  <TableHead>What was promised</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                  <TableHead>Recognized when</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Evidence</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {obligations.map((obligation) => (
                  <TableRow key={obligation.id}>
                    <TableCell className="font-mono font-medium">
                      {obligation.orderId}
                    </TableCell>
                    <TableCell>{obligation.description}</TableCell>
                    <TableCell className="text-right font-semibold">
                      {formatMoney(obligation.allocatedAmount)}
                    </TableCell>
                    <TableCell>{obligation.trigger}</TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={
                          obligation.status === "Recognized"
                            ? "bg-green-50 text-green-700 border-green-300"
                            : "bg-amber-50 text-amber-700 border-amber-300"
                        }
                      >
                        {obligation.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {obligation.evidence}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <p className="mt-4 text-sm text-muted-foreground">
              Total under contract this period:{" "}
              <span className="font-semibold text-foreground">
                {formatMoney(totalUnderContract)}
              </span>{" "}
              — every dollar is either recognized or deferred, and the
              recognition schedule explains which and why.
            </p>
          </CardContent>
        </Card>
      </div>

      {cutoff && cutoffShipment && (
        <Card className="gap-4 border-amber-300 p-6">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-amber-600" />
              <h3 className="font-semibold text-foreground">Cut-off watch</h3>
            </div>
            <Badge
              variant="outline"
              className="bg-amber-50 text-amber-700 border-amber-300"
            >
              Month-end check
            </Badge>
          </div>
          <p className="text-sm text-foreground">
            One {formatMoney(cutoff.allocatedAmount)} delivery is promised for{" "}
            {promisedLabel} — if it slips past month end it must stay deferred.
          </p>
          <p className="text-sm text-muted-foreground">
            Order {cutoff.orderId} ({cutoff.description}) is on shipment{" "}
            {cutoffShipment.shipmentId}, currently in{" "}
            {cutoffShipment.status.toLowerCase()}. Revenue is only recognized
            once the signed delivery confirmation arrives.
          </p>
          <div className="flex flex-col gap-3 rounded-lg border bg-gradient-to-br from-white via-gray-50 to-white p-4 md:flex-row md:items-center">
            <AgentIcon
              type="orchestrator"
              size="md"
              className="shrink-0 text-primary"
            />
            <div className="flex-1 text-sm">
              <p className="font-semibold text-foreground">
                AI recommends keeping this amount deferred
              </p>
              <p className="text-muted-foreground">
                If delivery is confirmed by {promisedLabel} as promised, it is
                recognized this period; if it slips past month end, it stays
                deferred and the period-end close checklist flags it.
              </p>
            </div>
            {cutoffReviewed ? (
              <Badge
                variant="outline"
                className="bg-green-50 text-green-700 border-green-300"
              >
                <CircleCheck className="w-3 h-3" />
                Reviewed by you — kept deferred
              </Badge>
            ) : (
              <Button
                variant="outline"
                className="whitespace-nowrap"
                onClick={() => setCutoffReviewed(true)}
              >
                <ClipboardCheck className="w-4 h-4 mr-2" />
                Reviewed — keep deferred
              </Button>
            )}
          </div>
        </Card>
      )}
    </div>
  );
}
