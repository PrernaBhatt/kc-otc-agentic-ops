"use client";

import type { ReactNode } from "react";
import { Bot, PenLine, ShieldCheck, ScrollText, UserRound } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { CountUp } from "@/components/ui/count-up";
import { Tip } from "@/components/shared/floating-tip";
import type { AuditKpis } from "@/lib/audit-selectors";
import { cn } from "@/lib/utils";

function KpiCard({
  icon,
  label,
  value,
  chip,
  footnote,
  delay,
  children,
}: {
  icon: ReactNode;
  label: string;
  value: ReactNode;
  chip?: ReactNode;
  footnote: string;
  delay: number;
  children: ReactNode;
}) {
  return (
    <Card className="h-full gap-0 bg-card py-0" style={{ animationDelay: `${delay}ms` }}>
      <CardContent className="flex flex-1 flex-col gap-3 p-4">
        <div className="flex items-center justify-between gap-2">
          <span className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
            {icon}
            {label}
          </span>
          {chip}
        </div>
        <div className="text-2xl font-bold tabular-nums text-foreground">{value}</div>
        <div className="mt-auto flex flex-col gap-1.5">
          {children}
          <p className="text-[11px] text-muted-foreground">{footnote}</p>
        </div>
      </CardContent>
    </Card>
  );
}

export function AuditKpiRow({ kpis }: { kpis: AuditKpis }) {
  const maxWeek = Math.max(1, ...kpis.weeks.map((w) => w.count));
  const actorTotal = Math.max(1, kpis.people + kpis.agents);
  const maxSigner = Math.max(1, ...kpis.signers.map((s) => s.count));

  return (
    <div className="grid items-stretch gap-4 sm:grid-cols-2 xl:grid-cols-4">
      <KpiCard
        delay={0}
        icon={<ScrollText className="h-3.5 w-3.5" aria-hidden />}
        label="Entries"
        value={<CountUp value={kpis.total} />}
        footnote="Per week, last 8 weeks"
      >
        <div className="flex h-10 items-end gap-1" role="img" aria-label="Entries per week">
          {kpis.weeks.map((w, i) => (
            <Tip
              key={w.label}
              content={{ title: w.label, value: `${w.count} entries` }}
              className="flex h-full flex-1 items-end"
            >
              <span
                className="grow-y block w-full rounded-sm bg-primary/70 transition-colors hover:bg-primary"
                style={{
                  height: `${Math.max(6, (w.count / maxWeek) * 100)}%`,
                  animationDelay: `${i * 50}ms`,
                }}
              />
            </Tip>
          ))}
        </div>
      </KpiCard>

      <KpiCard
        delay={60}
        icon={<UserRound className="h-3.5 w-3.5" aria-hidden />}
        label="People · agents"
        value={
          <span>
            <CountUp value={kpis.people} />
            <span className="text-base font-medium text-muted-foreground"> · </span>
            <CountUp value={kpis.agents} />
          </span>
        }
        footnote="Agents act, people decide at gates"
      >
        <div className="flex h-3 w-full overflow-hidden rounded-full bg-muted">
          <Tip
            content={{ title: "People", value: `${kpis.people} decisions`, swatch: "var(--primary)" }}
            className="grow-x block h-full bg-primary transition-opacity hover:opacity-80"
            style={{ width: `${(kpis.people / actorTotal) * 100}%` }}
          />
          <Tip
            content={{ title: "Agents", value: `${kpis.agents} steps`, swatch: "var(--accent)" }}
            className="grow-x block h-full bg-[var(--accent)]/45 transition-opacity hover:opacity-80"
            style={{ width: `${(kpis.agents / actorTotal) * 100}%`, animationDelay: "120ms" }}
          />
        </div>
        <div className="flex justify-between text-[11px] text-muted-foreground">
          <span className="flex items-center gap-1">
            <UserRound className="h-3 w-3" aria-hidden /> People
          </span>
          <span className="flex items-center gap-1">
            Agents <Bot className="h-3 w-3" aria-hidden />
          </span>
        </div>
      </KpiCard>

      <KpiCard
        delay={120}
        icon={<ShieldCheck className="h-3.5 w-3.5" aria-hidden />}
        label="Controls evidenced"
        value={
          <span>
            <CountUp value={kpis.evidenced} />
            <span className="text-base font-medium text-muted-foreground"> / {kpis.controls.length}</span>
          </span>
        }
        footnote="SOX 1.2 Fulfilment · 1.4 Billing · 1.7 Trade"
      >
        <div className="grid grid-cols-12 gap-1">
          {kpis.controls.map((c, i) => (
            <Tip
              key={c.ref}
              content={{ title: `SOX ${c.ref}`, value: `${c.count} entries`, note: c.name }}
              className={cn(
                "step-pop block h-5 rounded-sm transition-opacity hover:opacity-80",
                c.count > 0 ? "bg-primary" : "bg-muted"
              )}
              style={{ animationDelay: `${i * 40}ms` }}
            />
          ))}
        </div>
        <div className="flex justify-between font-mono text-[10px] text-muted-foreground">
          <span>1.4.1</span>
          <span>1.7.5</span>
        </div>
      </KpiCard>

      <KpiCard
        delay={180}
        icon={<PenLine className="h-3.5 w-3.5" aria-hidden />}
        label="Signed decisions"
        value={<CountUp value={kpis.signed} />}
        chip={
          <Badge
            variant="outline"
            className={cn(
              "text-[11px]",
              kpis.unsigned === 0
                ? "border-green-300 bg-green-50 text-green-700"
                : "border-amber-300 bg-amber-50 text-amber-800"
            )}
          >
            {kpis.unsigned} unsigned
          </Badge>
        }
        footnote="By signer"
      >
        <div className="flex flex-col gap-1">
          {kpis.signers.slice(0, 3).map((s, i) => (
            <Tip
              key={s.name}
              content={{ title: s.name, value: `${s.count} signed` }}
              className="flex items-center gap-2 text-[11px]"
            >
              <span className="w-20 shrink-0 truncate text-muted-foreground">{s.name}</span>
              <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-muted">
                <span
                  className="grow-x block h-full rounded-full bg-primary"
                  style={{ width: `${(s.count / maxSigner) * 100}%`, animationDelay: `${i * 80}ms` }}
                />
              </span>
              <span className="w-4 text-right tabular-nums text-foreground">{s.count}</span>
            </Tip>
          ))}
        </div>
      </KpiCard>
    </div>
  );
}
