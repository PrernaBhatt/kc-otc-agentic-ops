"use client";

import { ArrowUpRight, Bot, Check, Flag, PenLine, UserRound, X } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ControlTag } from "@/components/shared/control-tag";
import { OwnerChip } from "@/components/shared/owner-chip";
import { SystemBadge } from "@/components/shared/system-badge";
import type { ViewId } from "@/components/layout/sidebar";
import { formatAuditTime, type AuditEntry } from "@/lib/audit";
import { evidenceChecks } from "@/lib/audit-selectors";
import { findControl } from "@/lib/data/sox-controls";
import { formatUsd } from "@/lib/format";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const MODULE_VIEW: Record<string, ViewId> = {
  Billing: "billing",
  Deductions: "deductions",
  Orders: "orders",
  Chargebacks: "chargebacks",
  Collections: "collections",
  "Cash application": "cash-application",
};

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-3 text-xs">
      <span className="shrink-0 text-muted-foreground">{label}</span>
      <span className="min-w-0 text-right text-foreground">{children}</span>
    </div>
  );
}

export function AuditRail({
  entry,
  all,
  onClose,
}: {
  entry: AuditEntry;
  all: AuditEntry[];
  onClose: () => void;
}) {
  const { requestNav } = useOtcStore();
  const groups = evidenceChecks(entry, all);
  const view = MODULE_VIEW[entry.module];
  let tick = 0;

  return (
    <Card
      key={entry.entryId}
      className="animate-slide-in-right sticky top-4 flex max-h-[calc(100vh-2rem)] flex-col gap-0 overflow-hidden bg-card p-0"
      aria-label={`Audit entry ${entry.entryId}`}
    >
      <div className="flex items-start justify-between gap-2 border-b px-4 py-3">
        <div className="flex min-w-0 flex-col gap-0.5">
          <span className="font-mono text-[11px] text-muted-foreground">
            {entry.entryId} · {formatAuditTime(entry.at)}
          </span>
          <h3 className="text-sm font-semibold text-foreground">{entry.caseId}</h3>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="rounded-md p-1 text-muted-foreground hover:bg-muted hover:text-foreground"
          aria-label="Close entry"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      <div className="flex flex-col gap-4 overflow-y-auto px-4 py-3">
        <section className="flex flex-col gap-2">
          <p className="text-sm text-foreground text-pretty">{entry.action}</p>
          <Row label="Actor">
            <span className="inline-flex items-center gap-1.5">
              {entry.actor.kind === "agent" ? (
                <Bot className="h-3.5 w-3.5 text-[var(--accent)]" aria-hidden />
              ) : (
                <UserRound className="h-3.5 w-3.5 text-primary" aria-hidden />
              )}
              {entry.actor.name}
            </span>
          </Row>
          <Row label="Role">{entry.actor.role}</Row>
          <Row label="Account">
            <OwnerChip account={entry.accountId} variant="compact" />
          </Row>
          {entry.decision && <Row label="Decision">{entry.decision}</Row>}
          {entry.amountUsd !== undefined && (
            <Row label="Amount">
              <span className="font-semibold tabular-nums">{formatUsd(entry.amountUsd)}</span>
            </Row>
          )}
          <Row label="System">
            <SystemBadge name={entry.system} />
          </Row>
        </section>

        {groups.length > 0 ? (
          groups.map((g) => {
            const control = findControl(g.ref);
            return (
              <section key={g.ref} className="flex flex-col gap-2 rounded-lg border p-3" data-control-ref={g.ref}>
                <div className="flex items-start justify-between gap-2">
                  <span className="text-xs font-medium text-foreground text-pretty">{control?.name}</span>
                  <ControlTag controlRef={g.ref} />
                </div>
                <ul className="flex flex-col gap-1.5">
                  {g.checks.map((c) => {
                    const delay = tick++ * 90;
                    return (
                      <li
                        key={c.required}
                        className="animate-enter-fade flex items-start justify-between gap-2 text-xs"
                        style={{ animationDelay: `${delay}ms` }}
                      >
                        <span className="flex min-w-0 flex-col">
                          <span className="text-foreground">{c.required}</span>
                          <span className="truncate text-[11px] text-muted-foreground">
                            {c.matched ?? "Not attached on this case"}
                          </span>
                        </span>
                        <span
                          className={cn(
                            "inline-flex shrink-0 items-center gap-1 rounded-full border px-1.5 py-0.5 text-[10px] font-semibold",
                            c.status === "pass"
                              ? "border-green-300 bg-green-50 text-green-700"
                              : "border-amber-300 bg-amber-50 text-amber-800"
                          )}
                        >
                          {c.status === "pass" ? (
                            <Check className="h-3 w-3" aria-hidden />
                          ) : (
                            <Flag className="h-3 w-3" aria-hidden />
                          )}
                          {c.status === "pass" ? "Pass" : "Flag"}
                        </span>
                      </li>
                    );
                  })}
                </ul>
              </section>
            );
          })
        ) : (
          <p className="rounded-lg border border-dashed px-3 py-2 text-xs text-muted-foreground">
            Agent step with no control attached; the gate on this case carries the control.
          </p>
        )}

        {entry.evidence.length > 0 && (
          <section className="flex flex-col gap-1.5">
            <h4 className="text-[11px] font-medium text-muted-foreground">Attached to this entry</h4>
            <ul className="flex flex-wrap gap-1.5">
              {entry.evidence.map((ev) => (
                <li key={ev} className="rounded-md border bg-muted/40 px-2 py-0.5 text-[11px] text-foreground">
                  {ev}
                </li>
              ))}
            </ul>
          </section>
        )}

        {entry.signature && (
          <section className="flex flex-col gap-2 rounded-lg border border-green-200 bg-green-50/40 p-3" data-signed="true">
            <span className="flex items-center gap-1.5 text-xs font-medium text-green-800">
              <PenLine className="h-3.5 w-3.5" aria-hidden /> Signed {entry.signature.method}
            </span>
            {entry.signature.image ? (
              // eslint-disable-next-line @next/next/no-img-element -- signature captured as a data URL
              <img src={entry.signature.image} alt={`Signature of ${entry.signature.signer}`} className="h-12 w-auto self-start" />
            ) : (
              <span className="font-serif text-xl italic text-foreground">
                {entry.signature.typed ?? entry.signature.signer}
              </span>
            )}
            <Row label="Signer">
              {entry.signature.signer} · {entry.signature.role}
            </Row>
            <Row label="Signed at">{formatAuditTime(entry.signature.signedAt)}</Row>
            <Row label="Hash">
              <span className="font-mono">#{entry.signature.hash}</span>
            </Row>
          </section>
        )}
      </div>

      {view && (
        <div className="mt-auto border-t px-4 py-3">
          <Button
            variant="outline"
            size="sm"
            className="w-full"
            onClick={() => requestNav({ view, caseId: entry.caseId, accountId: entry.accountId })}
          >
            Open {entry.module.toLowerCase()} <ArrowUpRight className="h-3.5 w-3.5" />
          </Button>
        </div>
      )}
    </Card>
  );
}
