"use client";

import { useEffect, useState } from "react";
import { Bot, ChevronLeft, ChevronRight, PenLine, Search, UserRound, X } from "lucide-react";

import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ControlTag } from "@/components/shared/control-tag";
import { formatAuditTime, type AuditEntry } from "@/lib/audit";
import { EMPTY_AUDIT_FILTER, type AuditFilter } from "@/lib/audit-selectors";
import { accountOwners, findAccount } from "@/lib/data/account-owners";
import { soxControls } from "@/lib/data/sox-controls";
import { formatUsd } from "@/lib/format";
import { cn } from "@/lib/utils";

const PAGE_SIZE = 12;

function FilterSelect({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
}) {
  return (
    <label className="flex flex-col gap-1">
      <span className="text-[11px] font-medium text-muted-foreground">{label}</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className={cn(
          "h-8 rounded-md border bg-background px-2 text-xs text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
          value !== "all" && "border-primary/50 text-primary"
        )}
      >
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </label>
  );
}

export function AuditFilterBar({
  filter,
  onChange,
  modules,
}: {
  filter: AuditFilter;
  onChange: (f: AuditFilter) => void;
  modules: string[];
}) {
  const set = <K extends keyof AuditFilter>(key: K, value: AuditFilter[K]) =>
    onChange({ ...filter, [key]: value });
  const controls = soxControls.filter((c) => filter.family === "all" || c.family === filter.family);
  const active = JSON.stringify(filter) !== JSON.stringify(EMPTY_AUDIT_FILTER);

  return (
    <Card className="flex-row flex-wrap items-end gap-3 bg-card p-3">
      <FilterSelect
        label="Family"
        value={filter.family}
        onChange={(v) =>
          onChange({ ...filter, family: v as AuditFilter["family"], controlRef: "all" })
        }
        options={[
          { value: "all", label: "All families" },
          { value: "1.2 Order fulfilment", label: "1.2 Fulfilment" },
          { value: "1.4 Billing", label: "1.4 Billing" },
          { value: "1.7 Trade promotion", label: "1.7 Trade" },
        ]}
      />
      <FilterSelect
        label="Control"
        value={filter.controlRef}
        onChange={(v) => set("controlRef", v)}
        options={[
          { value: "all", label: "All controls" },
          ...controls.map((c) => ({ value: c.ref, label: `SOX ${c.ref}` })),
        ]}
      />
      <FilterSelect
        label="Account"
        value={filter.accountId}
        onChange={(v) => set("accountId", v)}
        options={[
          { value: "all", label: "All accounts" },
          ...accountOwners.map((a) => ({ value: a.accountId, label: a.shortName })),
        ]}
      />
      <FilterSelect
        label="Actor"
        value={filter.actor}
        onChange={(v) => set("actor", v as AuditFilter["actor"])}
        options={[
          { value: "all", label: "People and agents" },
          { value: "person", label: "People" },
          { value: "agent", label: "Agents" },
        ]}
      />
      <FilterSelect
        label="Module"
        value={filter.module}
        onChange={(v) => set("module", v)}
        options={[{ value: "all", label: "All modules" }, ...modules.map((m) => ({ value: m, label: m }))]}
      />
      <FilterSelect
        label="Period"
        value={filter.since}
        onChange={(v) => set("since", v as AuditFilter["since"])}
        options={[
          { value: "all", label: "All dates" },
          { value: "7", label: "Last 7 days" },
          { value: "30", label: "Last 30 days" },
        ]}
      />
      <label className="flex min-w-48 flex-1 flex-col gap-1">
        <span className="text-[11px] font-medium text-muted-foreground">Search</span>
        <span className="relative">
          <Search className="pointer-events-none absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={filter.query}
            onChange={(e) => set("query", e.target.value)}
            placeholder="Case, action, evidence"
            className="h-8 pl-7 text-xs"
          />
        </span>
      </label>
      {active && (
        <button
          type="button"
          onClick={() => onChange(EMPTY_AUDIT_FILTER)}
          className="flex h-8 items-center gap-1 rounded-md px-2 text-xs text-muted-foreground hover:bg-muted hover:text-foreground"
        >
          <X className="h-3.5 w-3.5" /> Clear
        </button>
      )}
    </Card>
  );
}

export function AuditTable({
  entries,
  selectedId,
  onSelect,
  freshIds,
}: {
  entries: AuditEntry[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  freshIds: Set<string>;
}) {
  const [page, setPage] = useState(0);
  const pages = Math.max(1, Math.ceil(entries.length / PAGE_SIZE));
  useEffect(() => {
    if (page >= pages) setPage(0);
  }, [page, pages]);
  const rows = entries.slice(page * PAGE_SIZE, page * PAGE_SIZE + PAGE_SIZE);

  return (
    <Card className="flex min-w-0 flex-col overflow-hidden bg-card p-0">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[760px] text-sm">
          <thead>
            <tr className="border-b bg-muted/40 text-left text-xs text-muted-foreground">
              <th className="px-3 py-2 font-medium">Time</th>
              <th className="px-3 py-2 font-medium">Case</th>
              <th className="px-3 py-2 font-medium">Account</th>
              <th className="px-3 py-2 font-medium">Actor</th>
              <th className="px-3 py-2 font-medium">Action</th>
              <th className="px-3 py-2 font-medium">Control</th>
              <th className="px-3 py-2 text-right font-medium">Amount</th>
              <th className="px-3 py-2 text-center font-medium">Signed</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && (
              <tr>
                <td colSpan={8} className="px-3 py-10 text-center text-sm text-muted-foreground">
                  No entries match these filters.
                </td>
              </tr>
            )}
            {rows.map((e, i) => {
              const selected = e.entryId === selectedId;
              const fresh = freshIds.has(e.entryId);
              return (
                <tr
                  key={e.entryId}
                  data-audit-entry={e.entryId}
                  data-control-ref={e.controlRefs.join(" ") || undefined}
                  data-signed={e.signature ? "true" : undefined}
                  onClick={() => onSelect(e.entryId)}
                  className={cn(
                    "animate-enter-fade cursor-pointer border-b last:border-0 transition-colors hover:bg-muted/40",
                    selected && "bg-primary/5 hover:bg-primary/10",
                    fresh && "bg-sky-50/70"
                  )}
                  style={{ animationDelay: page === 0 ? `${Math.min(i, 10) * 30}ms` : undefined }}
                >
                  <td className="whitespace-nowrap px-3 py-2 font-mono text-[11px] text-muted-foreground">
                    {formatAuditTime(e.at)}
                  </td>
                  <td className="whitespace-nowrap px-3 py-2">
                    <button
                      type="button"
                      onClick={(ev) => {
                        ev.stopPropagation();
                        onSelect(e.entryId);
                      }}
                      className="text-xs font-semibold text-foreground hover:text-primary"
                    >
                      {e.caseId}
                    </button>
                  </td>
                  <td className="whitespace-nowrap px-3 py-2 text-xs">
                    {findAccount(e.accountId)?.shortName ?? e.accountId}
                  </td>
                  <td className="whitespace-nowrap px-3 py-2 text-xs">
                    <span className="flex items-center gap-1.5">
                      {e.actor.kind === "agent" ? (
                        <Bot className="h-3.5 w-3.5 text-[var(--accent)]" aria-label="Agent" />
                      ) : (
                        <UserRound className="h-3.5 w-3.5 text-primary" aria-label="Person" />
                      )}
                      <span className="max-w-36 truncate">{e.actor.name}</span>
                    </span>
                  </td>
                  <td className="px-3 py-2 text-xs text-foreground">
                    <span className="line-clamp-2">{e.action}</span>
                  </td>
                  <td className="px-3 py-2">
                    <span className="flex flex-wrap gap-1">
                      {e.controlRefs.length === 0 ? (
                        <span className="text-xs text-muted-foreground">—</span>
                      ) : (
                        e.controlRefs.map((r) => <ControlTag key={r} controlRef={r} interactive={false} />)
                      )}
                    </span>
                  </td>
                  <td className="whitespace-nowrap px-3 py-2 text-right text-xs tabular-nums">
                    {e.amountUsd !== undefined ? formatUsd(e.amountUsd) : "—"}
                  </td>
                  <td className="px-3 py-2 text-center">
                    {e.signature ? (
                      <span className={cn("inline-flex", fresh && "step-pop")}>
                        <PenLine className="h-3.5 w-3.5 text-[var(--success)]" aria-label={`Signed by ${e.signature.signer}`} />
                      </span>
                    ) : (
                      <span className="text-xs text-muted-foreground">—</span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <div className="flex items-center justify-between border-t px-3 py-2 text-xs text-muted-foreground">
        <span className="tabular-nums">
          {entries.length === 0
            ? "0 entries"
            : `${page * PAGE_SIZE + 1}–${Math.min(entries.length, (page + 1) * PAGE_SIZE)} of ${entries.length}`}
        </span>
        <span className="flex items-center gap-1">
          <button
            type="button"
            disabled={page === 0}
            onClick={() => setPage((p) => p - 1)}
            className="rounded-md p-1 hover:bg-muted disabled:opacity-40"
            aria-label="Previous page"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          <span className="tabular-nums">
            {page + 1} / {pages}
          </span>
          <button
            type="button"
            disabled={page >= pages - 1}
            onClick={() => setPage((p) => p + 1)}
            className="rounded-md p-1 hover:bg-muted disabled:opacity-40"
            aria-label="Next page"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
        </span>
      </div>
    </Card>
  );
}
