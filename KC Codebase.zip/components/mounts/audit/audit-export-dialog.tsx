"use client";

import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { Download, FileSpreadsheet, FileText, X } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import type { AuditEntry } from "@/lib/audit";
import {
  auditExportFilename,
  exportAudit,
  type AuditExportFormat,
} from "@/lib/audit-export";
import { CONTROLLER } from "@/lib/data/account-owners";
import { cn } from "@/lib/utils";

export interface AuditExportScope {
  id: string;
  label: string;
  slug: string;
  entries: AuditEntry[];
}

export function AuditExportDialog({
  scopes,
  defaultScopeId,
  onClose,
}: {
  scopes: AuditExportScope[];
  defaultScopeId?: string;
  onClose: () => void;
}) {
  const [mounted, setMounted] = useState(false);
  const [scopeId, setScopeId] = useState(defaultScopeId ?? scopes[0]?.id);
  const [format, setFormat] = useState<AuditExportFormat>("pdf");
  const [busy, setBusy] = useState(false);
  useEffect(() => setMounted(true), []);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  if (!mounted) return null;
  const scope = scopes.find((s) => s.id === scopeId) ?? scopes[0];

  const run = async () => {
    if (!scope) return;
    setBusy(true);
    try {
      const { count, filename } = await exportAudit(scope.entries, {
        scopeLabel: scope.label,
        scopeSlug: scope.slug,
        format,
        exportedBy: CONTROLLER.name,
      });
      toast.success(`Exported ${count} entries`, { description: filename });
      onClose();
    } finally {
      setBusy(false);
    }
  };

  return createPortal(
    <div
      className="animate-enter-fade fixed inset-0 z-[60] flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
      onClick={onClose}
      onKeyDownCapture={(e) => e.key === "Enter" && e.stopPropagation()}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="audit-export-title"
        onClick={(e) => e.stopPropagation()}
        className="animate-modal-in flex w-full max-w-md flex-col gap-4 rounded-xl border bg-background p-5 shadow-2xl"
      >
        <div className="flex items-center justify-between">
          <h2 id="audit-export-title" className="text-base font-semibold text-foreground">
            Export audit trail
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="rounded-md p-1 text-muted-foreground hover:bg-muted hover:text-foreground"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <fieldset className="flex flex-col gap-2">
          <legend className="mb-1 text-xs font-medium text-muted-foreground">Scope</legend>
          {scopes.map((s) => (
            <label
              key={s.id}
              className={cn(
                "flex cursor-pointer items-center justify-between gap-3 rounded-lg border px-3 py-2 text-sm",
                scopeId === s.id ? "border-primary bg-primary/5" : "hover:bg-muted/40"
              )}
            >
              <span className="flex items-center gap-2">
                <input
                  type="radio"
                  name="audit-scope"
                  checked={scopeId === s.id}
                  onChange={() => setScopeId(s.id)}
                  className="accent-[var(--primary)]"
                />
                {s.label}
              </span>
              <span className="text-xs tabular-nums text-muted-foreground">{s.entries.length} entries</span>
            </label>
          ))}
        </fieldset>

        <fieldset className="flex flex-col gap-2">
          <legend className="mb-1 text-xs font-medium text-muted-foreground">Format</legend>
          <div className="grid grid-cols-2 gap-2">
            {(
              [
                ["pdf", "PDF · A4", FileText],
                ["csv", "CSV", FileSpreadsheet],
              ] as const
            ).map(([id, label, Icon]) => (
              <button
                key={id}
                type="button"
                aria-pressed={format === id}
                data-export-format={id}
                onClick={() => setFormat(id)}
                className={cn(
                  "flex items-center justify-center gap-2 rounded-lg border px-3 py-2 text-sm",
                  format === id ? "border-primary bg-primary/5 text-primary" : "hover:bg-muted/40"
                )}
              >
                <Icon className="h-4 w-4" /> {label}
              </button>
            ))}
          </div>
        </fieldset>

        <div className="rounded-md bg-muted/50 px-3 py-2 font-mono text-[11px] text-muted-foreground">
          {scope ? auditExportFilename(scope.slug, format) : ""}
        </div>

        <div className="flex justify-end gap-2">
          <Button variant="outline" size="sm" onClick={onClose}>
            Cancel
          </Button>
          <Button size="sm" onClick={run} disabled={busy || !scope || scope.entries.length === 0} data-export-count={scope?.entries.length}>
            <Download className="h-4 w-4" /> Export
          </Button>
        </div>
      </div>
    </div>,
    document.body
  );
}
