"use client";

import type { LucideIcon } from "lucide-react";

import { StageRail, type StageDotState } from "@/components/mounts/order-management/stage-rail";

export type RailStatus = "waiting" | "running" | "passed" | "needsReview";

export interface RailStage {
  id: string;
  label: string;
  icon: LucideIcon;
}

const DOT: Record<RailStatus, StageDotState> = {
  passed: "done",
  running: "active",
  needsReview: "pause",
  waiting: "pending",
};

/**
 * Stage rail for a staged run: a connected node per stage. The live stage
 * breathes, a stage waiting on a person holds amber, and a finished stage
 * pops its check.
 */
export function StageProgressRail({
  stages,
  statuses,
  openStageId,
  onStageClick,
}: {
  stages: readonly RailStage[];
  statuses: Record<string, RailStatus>;
  openStageId?: string | null;
  onStageClick?: (stageId: string) => void;
}) {
  return (
    <div className="rounded-xl border bg-card px-4 py-5">
      <StageRail
        chips={stages.map((stage) => {
          const status = statuses[stage.id] ?? "waiting";
          return {
            id: stage.id,
            label: stage.label,
            dot: DOT[status],
            clickable: status !== "waiting",
          };
        })}
        openStageId={openStageId}
        onChipClick={onStageClick}
      />
    </div>
  );
}
