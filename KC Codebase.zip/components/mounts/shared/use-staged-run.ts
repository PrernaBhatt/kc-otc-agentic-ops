"use client";

import { useCallback, useEffect, useRef, useState } from "react";

import type { RailStatus } from "@/components/mounts/shared/stage-progress-rail";

/**
 * The stage engine behind the dispute and batch runs. One stage is live at a
 * time; a stage reports `ready` once its write has finished filling, then
 * Enter (or Continue) passes it and starts the next. Gate stages hold amber
 * until `passGate` is called from a signed sign-off.
 */
export function useStagedRun<Id extends string>({
  order,
  gates,
  holds = [],
  onStart,
}: {
  order: readonly Id[];
  gates: readonly Id[];
  /** Running stages that only a person's action (e.g. Send) can pass. */
  holds?: readonly Id[];
  onStart?: (id: Id) => void;
}) {
  const [statuses, setStatuses] = useState<Record<string, RailStatus>>(() =>
    Object.fromEntries(order.map((id) => [id, "waiting" as RailStatus]))
  );
  const [active, setActive] = useState<Id | null>(null);
  const [open, setOpen] = useState<Set<string>>(new Set());
  const [ready, setReady] = useState<Set<string>>(new Set());
  const [complete, setComplete] = useState(false);
  const startedRef = useRef<Set<string>>(new Set());
  const onStartRef = useRef(onStart);
  onStartRef.current = onStart;

  const start = useCallback(
    (id: Id) => {
      if (startedRef.current.has(id)) return;
      startedRef.current.add(id);
      setStatuses((p) => ({ ...p, [id]: gates.includes(id) ? "needsReview" : "running" }));
      setActive(id);
      setOpen(new Set([id]));
      onStartRef.current?.(id);
    },
    [gates]
  );

  const passAndNext = useCallback(
    (id: Id) => {
      setStatuses((p) => ({ ...p, [id]: "passed" }));
      const next = order[order.indexOf(id) + 1];
      if (next) start(next);
      else setComplete(true);
    },
    [order, start]
  );

  const markReady = useCallback((id: Id) => {
    setReady((prev) => (prev.has(id) ? prev : new Set(prev).add(id)));
  }, []);

  const advance = useCallback(() => {
    if (!active || gates.includes(active) || holds.includes(active)) return;
    if (statuses[active] !== "running") return;
    passAndNext(active);
  }, [active, gates, holds, statuses, passAndNext]);

  /** Passes a running hold stage (one that waits on a person's action, not Enter). */
  const passHold = useCallback(
    (id: Id) => {
      if (statuses[id] !== "running") return;
      passAndNext(id);
    },
    [statuses, passAndNext]
  );

  const passGate = useCallback(
    (id: Id) => {
      if (statuses[id] !== "needsReview") return;
      passAndNext(id);
    },
    [statuses, passAndNext]
  );

  const toggle = useCallback((id: string) => {
    setOpen((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const focus = useCallback((id: string) => setOpen(new Set([id])), []);

  const advanceRef = useRef(advance);
  advanceRef.current = advance;
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key !== "Enter" || e.repeat) return;
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || tag === "BUTTON") return;
      e.preventDefault();
      advanceRef.current();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  const canAdvance =
    !!active && !gates.includes(active) && !holds.includes(active) && statuses[active] === "running";

  return {
    statuses,
    active,
    open,
    ready,
    complete,
    start,
    markReady,
    advance,
    passGate,
    passHold,
    toggle,
    focus,
    canAdvance,
  };
}
