"use client";

import { useEffect, useRef } from "react";
import { Clock, PenLine } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ControlTag } from "@/components/shared/control-tag";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

/** The run's slice of the audit trail: every agent step and signed gate for this case. */
export function RunAgentLog({ caseId, title = "Agent log" }: { caseId: string; title?: string }) {
  const { auditLog } = useOtcStore();
  const entries = auditLog.filter((e) => e.caseId === caseId);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (ref.current) ref.current.scrollTop = ref.current.scrollHeight;
  }, [entries.length]);

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <Clock className="h-4 w-4 text-muted-foreground" />
          <CardTitle className="text-sm">{title}</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div ref={ref} className="flex max-h-[520px] flex-col gap-3 overflow-y-auto pr-1">
          {entries.map((e) => (
            <div
              key={e.entryId}
              data-audit-entry={e.entryId}
              className={cn(
                "animate-enter-fade border-l-2 pl-3",
                e.actor.kind === "person" ? "border-amber-400" : "border-primary/40"
              )}
            >
              <div className="flex items-center justify-between gap-2 text-[11px] text-muted-foreground">
                <span>{e.at.slice(11, 19)}</span>
                <span className="truncate">{e.actor.name}</span>
              </div>
              <div
                className={cn(
                  "text-xs leading-snug",
                  e.actor.kind === "person" ? "font-medium text-foreground" : "text-foreground"
                )}
              >
                {e.action}
              </div>
              {(e.controlRefs.length > 0 || e.signature) && (
                <div className="mt-1 flex flex-wrap items-center gap-1">
                  {e.controlRefs.map((r) => (
                    <ControlTag key={r} controlRef={r} />
                  ))}
                  {e.signature && (
                    <span className="inline-flex items-center gap-1 text-[10px] text-[var(--success)]" data-signed="true">
                      <PenLine className="h-3 w-3" /> Signed
                    </span>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
