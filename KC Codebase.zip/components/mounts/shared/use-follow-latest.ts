"use client";

import { useEffect } from "react";

function scrollParent(el: HTMLElement): HTMLElement | null {
  let node = el.parentElement;
  while (node) {
    const overflowY = getComputedStyle(node).overflowY;
    if ((overflowY === "auto" || overflowY === "scroll") && node.scrollHeight > node.clientHeight) {
      return node;
    }
    node = node.parentElement;
  }
  return null;
}

/**
 * Keeps a run's newest step in the middle of the screen — when it appears and
 * every time it grows. A short step is centred; a step taller than the view
 * keeps its newest (bottom) content near the middle. A manual scroll pauses
 * the follow briefly so it never fights the reader.
 */
export function useFollowLatest(getEl: () => HTMLElement | null, key: unknown) {
  useEffect(() => {
    const el = getEl();
    if (!el) return;
    let timer: ReturnType<typeof setTimeout> | undefined;
    let userScrolledAt = 0;
    const markUserScroll = () => {
      userScrolledAt = Date.now();
    };

    const follow = () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        if (Date.now() - userScrolledAt < 1200) return;
        const parent = scrollParent(el);
        const view = parent
          ? parent.getBoundingClientRect()
          : { top: 0, height: window.innerHeight };
        const box = el.getBoundingClientRect();
        const delta =
          box.height <= view.height * 0.8
            ? box.top + box.height / 2 - (view.top + view.height / 2)
            : box.bottom - (view.top + view.height * 0.72);
        if (Math.abs(delta) < 12) return;
        (parent ?? window).scrollBy({ top: delta, behavior: "smooth" });
      }, 180);
    };

    follow();
    const observer = new ResizeObserver(follow);
    observer.observe(el);
    window.addEventListener("wheel", markUserScroll, { passive: true });
    window.addEventListener("touchmove", markUserScroll, { passive: true });
    return () => {
      clearTimeout(timer);
      observer.disconnect();
      window.removeEventListener("wheel", markUserScroll);
      window.removeEventListener("touchmove", markUserScroll);
    };
    // getEl reads refs that are current after commit; the key decides when to re-bind.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);
}
