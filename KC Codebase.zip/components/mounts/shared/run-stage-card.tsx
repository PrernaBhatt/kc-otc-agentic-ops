"use client";

import { forwardRef, type ReactNode } from "react";
import { ChevronDown } from "lucide-react";

import { Spinner } from "@/components/agents/spinner";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import type { RailStatus } from "@/components/mounts/shared/stage-progress-rail";
import { StepNode } from "@/components/mounts/shared/step-node";
import { cn } from "@/lib/utils";

export interface RunStageMeta {
  id: string;
  label: string;
  heading: string;
  summary: string;
  agent: string;
}

/** One stage of a staged run: collapsible header and the stage body. Enter advances once ready. */
export const RunStageCard = forwardRef<
  HTMLDivElement,
  {
    stage: RunStageMeta;
    status: RailStatus;
    open: boolean;
    ready: boolean;
    canContinue?: boolean;
    onToggle: () => void;
    onContinue?: () => void;
    headerExtra?: ReactNode;
    children: ReactNode;
  }
>(function RunStageCard(
  { stage, status, open, ready, onToggle, headerExtra, children },
  ref
) {
  return (
    <Card ref={ref} className="gap-0 overflow-hidden py-0" data-stage={stage.id}>
      <div className={cn("relative flex w-full items-center justify-between gap-3 px-4", open ? "py-3" : "py-1.5")}>
        <button
          type="button"
          onClick={onToggle}
          aria-expanded={open}
          aria-label={`${stage.label}: ${status === "passed" ? stage.summary : stage.agent}`}
          className="absolute inset-0 cursor-pointer rounded-t-xl focus-visible:outline-2 focus-visible:outline-ring"
        />
        <div className="pointer-events-none relative flex min-w-0 items-center gap-3">
          <StepNode
            size={open ? "md" : "xs"}
            state={status === "passed" ? "done" : status === "needsReview" ? "pause" : "active"}
          />
          {open ? (
            <div className="min-w-0">
              <div className="truncate text-sm font-semibold text-foreground">{stage.heading}</div>
              <div className="truncate text-xs text-muted-foreground">{stage.agent}</div>
            </div>
          ) : (
            <div className="flex min-w-0 items-baseline gap-3">
              <span className="shrink-0 text-sm font-semibold text-foreground">{stage.label}</span>
              <span className="truncate text-xs text-muted-foreground">
                {status === "passed" ? stage.summary : stage.agent}
              </span>
            </div>
          )}
        </div>
        <div className="pointer-events-none relative flex shrink-0 items-center gap-2">
          {headerExtra && <span className="pointer-events-auto">{headerExtra}</span>}
          {status === "running" && !ready && (
            <Badge variant="outline" className="border-blue-300 bg-blue-50 text-blue-700">
              <Spinner size="sm" className="mr-1" /> Working
            </Badge>
          )}
          {status === "needsReview" && (
            <Badge variant="outline" className="border-amber-300 bg-amber-50 text-amber-700">
              Awaiting sign-off
            </Badge>
          )}
          <ChevronDown
            className={cn("h-4 w-4 shrink-0 text-muted-foreground transition-transform", open && "rotate-180")}
          />
        </div>
      </div>
      {open && (
        <CardContent className="flex flex-col gap-3 px-4 pb-4 pt-0">
          {children}
        </CardContent>
      )}
    </Card>
  );
});
