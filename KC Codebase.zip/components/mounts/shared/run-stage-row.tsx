"use client";

import { useEffect, useState, type ReactNode } from "react";
import { ChevronDown } from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { StepNode } from "@/components/mounts/shared/step-node";
import { cn } from "@/lib/utils";

export type RunStageStatus = "waiting" | "running" | "passed" | "needsReview";

/** Card class for a stage card that uses {@link RunStageRow} as its header. */
export const RUN_STAGE_CARD_CLASS = "overflow-hidden py-0 gap-0 bg-card animate-enter";
/** Body class for the expanded content under a {@link RunStageRow}. */
export const RUN_STAGE_BODY_CLASS = "space-y-4 border-t px-4 py-4";

/**
 * The Order Management step header: a compact row when collapsed (small node
 * + label + one-line summary) that grows to its normal size when opened.
 */
export function RunStageRow({
  label,
  status,
  expanded,
  onToggle,
  summary,
}: {
  label: ReactNode;
  status: RunStageStatus;
  expanded: boolean;
  onToggle: () => void;
  summary?: ReactNode;
}) {
  const done = status === "passed";
  const review = status === "needsReview";
  const running = status === "running";
  return (
    <button
      type="button"
      aria-expanded={expanded}
      onClick={onToggle}
      className={cn(
        "flex w-full cursor-pointer items-center gap-2.5 px-4 text-left",
        expanded ? "py-2.5" : "py-1"
      )}
    >
      <StepNode
        size={expanded ? "sm" : "xs"}
        state={done ? "done" : review ? "pause" : running ? "active" : "pending"}
      />
      <span className="shrink-0 text-sm font-semibold text-foreground">{label}</span>
      {!expanded && (
        <span className="truncate text-xs text-muted-foreground">
          {done ? summary : running ? "In progress" : ""}
        </span>
      )}
      {(running || review) && (
        <Badge
          variant="outline"
          className={cn(
            "ml-auto shrink-0 text-xs",
            review
              ? "border-amber-300 bg-amber-50 text-amber-800"
              : "border-[var(--info)]/40 bg-[var(--info)]/5 text-[var(--info)]"
          )}
        >
          {review ? "Waiting on you" : "Current step"}
        </Badge>
      )}
      <ChevronDown
        className={cn(
          "h-4 w-4 shrink-0 text-muted-foreground transition-transform",
          running || review ? "" : "ml-auto",
          expanded && "rotate-180"
        )}
      />
    </button>
  );
}

export interface AuditEntry {
  id: string;
  agent: string;
  agentType: string;
  message: ReactNode;
  tone?: "info" | "attention" | "success";
}

/** The Order Management "AI Agent Audit Trail" side card. */
export function AgentAuditTrail({ entries }: { entries: AuditEntry[] }) {
  const [times, setTimes] = useState<Record<string, number>>({});
  const ids = entries.map((e) => e.id).join("|");

  useEffect(() => {
    setTimes((prev) => {
      const missing = entries.filter((e) => prev[e.id] === undefined);
      if (missing.length === 0) return prev;
      const next = { ...prev };
      const now = Date.now();
      for (const e of missing) next[e.id] = now;
      return next;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ids]);

  return (
    <Card className="h-fit">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm">AI Agent Audit Trail</CardTitle>
        <CardDescription className="text-xs">Real-time agent reasoning log</CardDescription>
      </CardHeader>
      <CardContent className="p-3">
        <div className="flex max-h-[600px] flex-col gap-3 overflow-y-auto">
          {entries.length === 0 && (
            <p className="text-xs italic text-muted-foreground">
              Waiting for processing to begin...
            </p>
          )}
          {entries.map((log) => (
            <div key={log.id} className="flex gap-2 text-xs">
              <div className="mt-0.5 shrink-0">
                <AgentIcon type={log.agentType} size="sm" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1.5">
                  <span className="font-medium text-foreground">{log.agent}</span>
                  {times[log.id] !== undefined && (
                    <span className="text-muted-foreground">
                      {new Date(times[log.id]).toLocaleTimeString()}
                    </span>
                  )}
                </div>
                <div
                  className={cn(
                    "mt-0.5",
                    log.tone === "attention"
                      ? "text-amber-600"
                      : log.tone === "info"
                        ? "text-muted-foreground"
                        : "text-[var(--success)]"
                  )}
                >
                  {log.message}
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
