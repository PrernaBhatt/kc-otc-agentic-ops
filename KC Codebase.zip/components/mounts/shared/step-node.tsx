"use client";

import { Check } from "lucide-react";

import { cn } from "@/lib/utils";

export type StepState = "done" | "active" | "pause" | "pending";

const SIZES = {
  xs: { box: "h-4 w-4", dot: "h-1.5 w-1.5", icon: "h-2.5 w-2.5", halo: "[--halo:3px]" },
  sm: { box: "h-6 w-6", dot: "h-2 w-2", icon: "h-3.5 w-3.5", halo: "[--halo:5px]" },
  md: { box: "h-8 w-8", dot: "h-2.5 w-2.5", icon: "h-4 w-4", halo: "[--halo:7px]" },
} as const;

/**
 * One step's status mark, shared by every rail and check list: the live step
 * holds a steady breathing halo, a finished step pops and draws its check, and
 * a step waiting on a person holds an amber halo.
 */
export function StepNode({
  state,
  size = "sm",
  label,
  className,
}: {
  state: StepState;
  size?: keyof typeof SIZES;
  /** Accessible name; omit when a visible label sits next to the node. */
  label?: string;
  className?: string;
}) {
  const s = SIZES[size];
  return (
    <span
      role={label ? "img" : undefined}
      aria-label={label}
      aria-hidden={label ? undefined : true}
      className={cn(
        "relative inline-flex shrink-0 items-center justify-center rounded-full transition-colors duration-300",
        s.box,
        s.halo,
        state === "done" && "step-pop bg-[var(--success)] text-[var(--success-foreground)]",
        state === "active" && "step-halo bg-[var(--info)]",
        state === "pause" && "step-halo step-halo-amber bg-amber-500",
        state === "pending" && "border-2 border-border bg-card",
        className
      )}
    >
      {state === "done" && (
        <Check key="done" className={cn("step-check", s.icon)} strokeWidth={3} />
      )}
      {(state === "active" || state === "pause") && (
        <span className={cn("rounded-full bg-card", s.dot)} />
      )}
    </span>
  );
}
