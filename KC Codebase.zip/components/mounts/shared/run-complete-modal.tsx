"use client";

import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { ArrowRight, CheckCircle2, Download } from "lucide-react";

import { AuditExportDialog } from "@/components/mounts/audit/audit-export-dialog";
import { useOtcStore } from "@/lib/store";

import {
  SourceDocTrigger,
  type SourceDoc,
} from "@/components/modals/source-doc-preview";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export interface RunCompleteStat {
  label: string;
  value: string;
  tone?: "success" | "danger";
}

/**
 * What a completed run resolved.
 *
 * Lifted from the Order Management finale, which takes a whole order and
 * hardcodes its copy. This one is domain-neutral so both the chargeback and
 * the deduction run can end on the same ceremony.
 */
export function RunCompleteModal({
  eyebrow,
  title,
  narrative,
  stats,
  docs = [],
  primaryLabel,
  onPrimary,
  secondaryLabel,
  onSecondary,
  exportCaseId,
}: {
  /** When set, offers "Export audit" scoped to this case. */
  exportCaseId?: string;
  eyebrow: string;
  title: string;
  narrative: string;
  stats: RunCompleteStat[];
  docs?: { doc: SourceDoc; label: string }[];
  primaryLabel: string;
  onPrimary: () => void;
  secondaryLabel: string;
  onSecondary: () => void;
}) {
  const [mounted, setMounted] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);
  const { auditLog } = useOtcStore();
  useEffect(() => setMounted(true), []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && !exportOpen) onSecondary();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onSecondary, exportOpen]);

  if (!mounted) return null;

  return createPortal(
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-6 backdrop-blur-sm"
      onClick={onSecondary}
    >
      <div
        className="animate-modal-in w-full max-w-lg rounded-2xl border bg-card p-7 text-center shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-[var(--success)]/15">
          <CheckCircle2 className="h-9 w-9 text-[var(--success)]" />
        </div>
        <div className="text-xs font-semibold uppercase tracking-wide text-[var(--success)]">
          {eyebrow}
        </div>
        <h3 className="mt-1 text-xl font-bold text-foreground">{title}</h3>

        <div
          className={cn(
            "mt-5 grid gap-2",
            stats.length === 4 ? "grid-cols-2" : "grid-cols-3"
          )}
        >
          {stats.map((s) => (
            <div key={s.label} className="rounded-lg bg-muted/50 p-3">
              <div
                className={cn(
                  "text-base font-bold text-foreground",
                  s.tone === "success" && "text-[var(--success)]",
                  s.tone === "danger" && "text-red-600"
                )}
              >
                {s.value}
              </div>
              <div className="text-[11px] text-muted-foreground">{s.label}</div>
            </div>
          ))}
        </div>

        <p className="mt-4 text-sm text-muted-foreground">{narrative}</p>

        {docs.length > 0 && (
          <div className="mt-4 space-y-2 text-left">
            <div className="text-xs font-medium text-muted-foreground">
              Documents produced by this run
            </div>
            {docs.map((d) => (
              <SourceDocTrigger
                key={d.label}
                doc={d.doc}
                label={d.label}
                className="w-full justify-start"
              />
            ))}
          </div>
        )}

        <div className="mt-6 flex items-center justify-center gap-2">
          <Button
            variant="ghost"
            onClick={onSecondary}
            className="whitespace-nowrap"
          >
            {secondaryLabel}
          </Button>
          {exportCaseId && (
            <Button variant="outline" onClick={() => setExportOpen(true)} className="whitespace-nowrap">
              <Download className="h-4 w-4" />
              Export audit
            </Button>
          )}
          <Button onClick={onPrimary} className="whitespace-nowrap">
            {primaryLabel}
            <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
        {exportOpen && exportCaseId && (
          <AuditExportDialog
            scopes={[
              {
                id: "case",
                label: `This case · ${exportCaseId}`,
                slug: exportCaseId,
                entries: auditLog.filter((e) => e.caseId === exportCaseId),
              },
              { id: "all", label: "All entries", slug: "all", entries: auditLog },
            ]}
            onClose={() => setExportOpen(false)}
          />
        )}
      </div>
    </div>,
    document.body
  );
}
