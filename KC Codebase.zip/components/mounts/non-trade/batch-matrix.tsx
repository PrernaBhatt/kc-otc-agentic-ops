"use client";

import { useEffect, useRef, useState } from "react";

import { CountUp } from "@/components/ui/count-up";
import { TickList } from "@/components/shared/tick-list";
import { NON_TRADE_BATCH, type CountValue, type NonTradeOutcome } from "@/lib/data/non-trade-batch";
import { formatUsd } from "@/lib/format";
import { batchTotals } from "@/lib/non-trade-selectors";
import { cn } from "@/lib/utils";

const played = new Set<string>();
const OUTCOMES: { key: NonTradeOutcome; label: string; tone: string }[] = [
  { key: "valid", label: "Valid · credit", tone: "text-[var(--success)]" },
  { key: "invalid", label: "Invalid · charge-back", tone: "text-primary" },
  { key: "exception", label: "Exception · owner", tone: "text-amber-700" },
];
const EVIDENCE = [
  { id: "pod", label: "Signed POD and receiving docs", system: "SAP TM" },
  { id: "carrier", label: "Carrier claims and BOL exceptions", system: "SAP TM" },
  { id: "asn", label: "ASN timestamps", system: "SAP S/4HANA" },
  { id: "manual", label: "Retailer compliance manuals", system: "SharePoint" },
  { id: "price", label: "Contract prices and tolerance", system: "PricerX" },
];

function Cell({
  v,
  show,
  tone,
  strong,
  cellId,
}: {
  v: CountValue;
  show: boolean;
  tone?: string;
  strong?: boolean;
  cellId?: string;
}) {
  if (!show) return <td className="px-2 py-1.5" />;
  return (
    <td className="px-2 py-1.5 text-right tabular-nums" data-matrix-cell={cellId}>
      <span className={cn("block text-xs", strong ? "font-semibold text-foreground" : tone ?? "text-foreground")}>
        <CountUp value={v.count} durationMs={500} />
      </span>
      <span className="block text-[10px] text-muted-foreground">
        <CountUp value={v.usd} durationMs={500} format={formatUsd} />
      </span>
    </td>
  );
}

/** S3: evidence sources tick in, then the category × outcome matrix counts up cell by cell. */
export function BatchMatrix({ onDone }: { onDone: () => void }) {
  const b = NON_TRADE_BATCH;
  const key = `${b.batchId}:validate`;
  const cells = b.categories.length * OUTCOMES.length;
  const [readDone, setReadDone] = useState(played.has(key));
  const [shown, setShown] = useState(played.has(key) ? cells + 1 : 0);
  const doneRef = useRef(onDone);
  doneRef.current = onDone;

  useEffect(() => {
    if (!readDone) return;
    if (shown > cells) {
      played.add(key);
      doneRef.current();
      return;
    }
    const t = setTimeout(() => setShown((n) => n + 1), shown === cells ? 400 : 110);
    return () => clearTimeout(t);
  }, [readDone, shown, cells, key]);

  const totalsShown = shown > cells;

  return (
    <div className="flex flex-col gap-3">
      <section className="rounded-lg border">
        <header className="border-b bg-muted/30 px-3 py-2 text-xs font-semibold text-foreground">
          Evidence checked per claim
        </header>
        <TickList className="px-3" playKey={`${key}:read`} stepMs={340} onDone={() => setReadDone(true)} items={EVIDENCE} />
      </section>
      <section className="overflow-x-auto rounded-lg border" data-batch={b.batchId} data-batch-total={batchTotals.total.usd}>
        <table className="w-full min-w-[520px] text-sm">
          <thead>
            <tr className="border-b bg-muted/30 text-xs text-muted-foreground">
              <th className="px-2 py-2 text-left font-medium">Category</th>
              {OUTCOMES.map((o) => (
                <th key={o.key} className="px-2 py-2 text-right font-medium">
                  {o.label}
                </th>
              ))}
              <th className="px-2 py-2 text-right font-medium">Total</th>
            </tr>
          </thead>
          <tbody>
            {b.categories.map((row, r) => (
              <tr key={row.key} className="border-b">
                <td className="px-2 py-1.5 text-xs font-medium text-foreground">{row.label}</td>
                {OUTCOMES.map((o, c) => (
                  <Cell
                    key={o.key}
                    v={row[o.key]}
                    tone={o.tone}
                    cellId={`${row.key}:${o.key}`}
                    show={shown > r * OUTCOMES.length + c}
                  />
                ))}
                <Cell v={row.total} strong show={totalsShown} />
              </tr>
            ))}
            <tr className="bg-muted/30">
              <td className="px-2 py-1.5 text-xs font-semibold text-foreground">Total</td>
              {OUTCOMES.map((o) => (
                <Cell key={o.key} v={batchTotals[o.key]} strong show={totalsShown} />
              ))}
              <Cell v={batchTotals.total} strong show={totalsShown} />
            </tr>
          </tbody>
        </table>
      </section>
    </div>
  );
}
