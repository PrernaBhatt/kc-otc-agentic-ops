"use client";

import { useState } from "react";

import { FillFields } from "@/components/shared/fill-fields";
import { TickList } from "@/components/shared/tick-list";
import { NON_TRADE_BATCH } from "@/lib/data/non-trade-batch";
import { formatUsd } from "@/lib/format";
import { batchTotals } from "@/lib/non-trade-selectors";

/** S1: deduction lines read per customer (left), batch header typed in (right). */
export function BatchCapture({ onDone }: { onDone: () => void }) {
  const b = NON_TRADE_BATCH;
  const [readDone, setReadDone] = useState(false);

  return (
    <div className="grid items-stretch gap-3 md:grid-cols-2">
      <section className="flex h-full flex-col rounded-lg border">
        <header className="border-b bg-muted/30 px-3 py-2 text-xs font-semibold text-foreground">
          Deduction lines · week {b.week}
        </header>
        <TickList
          className="px-3"
          playKey={`${b.batchId}:capture:read`}
          stepMs={460}
          onDone={() => setReadDone(true)}
          items={b.sources.map((s) => ({
            id: s.accountId,
            label: s.customer,
            detail: s.channel,
            system: s.channel.startsWith("EDI") ? "EDI 820" : "SAP FSCM",
            trailing: (
              <span className="text-right text-xs tabular-nums text-foreground">
                {s.claims} claims · {formatUsd(s.usd)}
              </span>
            ),
          }))}
        />
      </section>
      <section className="flex h-full flex-col rounded-lg border">
        <header className="border-b bg-muted/30 px-3 py-2 text-xs font-semibold text-foreground">
          SAP FSCM · batch header
        </header>
        <FillFields
          className="px-3 py-2"
          play={readDone}
          playKey={`${b.batchId}:capture:write`}
          onDone={onDone}
          fields={[
            { label: "Batch", value: b.batchId, mono: true },
            { label: "Claims", value: String(batchTotals.total.count), align: "right" },
            { label: "Value", value: formatUsd(batchTotals.total.usd), align: "right" },
            { label: "Customers", value: b.sources.map((s) => s.customer).join(", ") },
            { label: "Lane", value: "Non-trade · judged by policy", strong: true },
          ]}
        />
      </section>
    </div>
  );
}
