"use client";

import { useEffect, useMemo, useState } from "react";
import { ArrowUpRight, Check, ChevronLeft, ChevronRight, Flag, PenLine, Search, X } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ControlTag } from "@/components/shared/control-tag";
import { GateSignoffModal } from "@/components/shared/gate-signoff-modal";
import { OwnerChip } from "@/components/shared/owner-chip";
import { SystemMark } from "@/components/shared/system-badge";
import { NON_TRADE_BATCH, type NonTradeCategory } from "@/lib/data/non-trade-batch";
import { formatUsd } from "@/lib/format";
import { categoryLabel, splitOutClaim } from "@/lib/non-trade-selectors";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const PAGE_SIZE = 8;

export interface SplitOutRow {
  id: string;
  accountId: string;
  customer: string;
  category: NonTradeCategory | "run";
  title: string;
  amount: number;
  ageDays?: number;
  status: string;
  /** Rows backed by a full run open it instead of the rail decision. */
  runCase?: boolean;
  traceNote?: string;
}

export function SplitOutList({ rows, onOpenCase }: { rows: SplitOutRow[]; onOpenCase: (id: string) => void }) {
  const [category, setCategory] = useState<string>("all");
  const [customer, setCustomer] = useState<string>("all");
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(0);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const customers = useMemo(() => [...new Set(rows.map((r) => r.customer))].sort(), [rows]);
  const filtered = rows.filter((r) => {
    if (category !== "all" && r.category !== category) return false;
    if (customer !== "all" && r.customer !== customer) return false;
    const q = query.trim().toLowerCase();
    return !q || `${r.id} ${r.title} ${r.customer}`.toLowerCase().includes(q);
  });
  const pages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  useEffect(() => {
    if (page >= pages) setPage(0);
  }, [page, pages]);
  const shown = filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);
  const selected = rows.find((r) => r.id === selectedId) ?? null;

  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <h3 className="text-sm font-semibold text-foreground">Split out for a person</h3>
        <div className="flex flex-wrap items-center gap-2">
          <select
            aria-label="Category"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="h-8 rounded-md border bg-background px-2 text-xs"
          >
            <option value="all">All categories</option>
            {NON_TRADE_BATCH.categories.map((c) => (
              <option key={c.key} value={c.key}>
                {c.label}
              </option>
            ))}
            <option value="run">Case runs</option>
          </select>
          <select
            aria-label="Customer"
            value={customer}
            onChange={(e) => setCustomer(e.target.value)}
            className="h-8 rounded-md border bg-background px-2 text-xs"
          >
            <option value="all">All customers</option>
            {customers.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
          <span className="relative">
            <Search className="pointer-events-none absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search claims"
              aria-label="Search claims"
              className="h-8 w-44 pl-7 text-xs"
            />
          </span>
        </div>
      </div>

      <div className="grid items-start gap-4 lg:grid-cols-[minmax(0,1fr)_380px]">
        <Card className="flex min-w-0 flex-col overflow-hidden bg-card p-0">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] text-sm">
              <thead>
                <tr className="border-b bg-muted/40 text-left text-xs text-muted-foreground">
                  <th className="px-3 py-2 font-medium">Claim</th>
                  <th className="px-3 py-2 font-medium">Owner</th>
                  <th className="px-3 py-2 font-medium">Category</th>
                  <th className="px-3 py-2 text-right font-medium">Amount</th>
                  <th className="px-3 py-2 text-right font-medium">Age</th>
                  <th className="px-3 py-2 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {shown.length === 0 && (
                  <tr>
                    <td colSpan={6} className="px-3 py-8 text-center text-sm text-muted-foreground">
                      No claims match these filters.
                    </td>
                  </tr>
                )}
                {shown.map((r, i) => (
                  <tr
                    key={r.id}
                    data-deduction-class="non-trade"
                    onClick={() => setSelectedId(r.id)}
                    className={cn(
                      "animate-enter-fade cursor-pointer border-b last:border-0 transition-colors hover:bg-muted/40",
                      r.id === selectedId && "bg-primary/5"
                    )}
                    style={{ animationDelay: `${i * 35}ms` }}
                  >
                    <td className="px-3 py-2">
                      <span className="block text-xs font-semibold text-foreground">{r.title}</span>
                      <span className="block font-mono text-[11px] text-muted-foreground">{r.id}</span>
                    </td>
                    <td className="px-3 py-2">
                      <OwnerChip account={r.accountId} variant="compact" />
                    </td>
                    <td className="px-3 py-2 text-xs">
                      {r.category === "run" ? "Case run" : categoryLabel(r.category)}
                      {r.traceNote && (
                        <span className="mt-0.5 block text-[10px] text-muted-foreground">{r.traceNote}</span>
                      )}
                    </td>
                    <td className="px-3 py-2 text-right text-xs tabular-nums">{formatUsd(r.amount)}</td>
                    <td className="px-3 py-2 text-right text-xs tabular-nums text-muted-foreground">
                      {r.ageDays !== undefined ? `${r.ageDays} d` : "—"}
                    </td>
                    <td className="px-3 py-2">
                      <Badge
                        variant="outline"
                        className={cn(
                          "whitespace-nowrap text-[11px]",
                          r.status === "Open"
                            ? "border-amber-300 bg-amber-50 text-amber-800"
                            : "border-green-300 bg-green-50 text-green-700"
                        )}
                      >
                        {r.status}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="flex items-center justify-between border-t px-3 py-2 text-xs text-muted-foreground">
            <span className="tabular-nums">{filtered.length} claims</span>
            <span className="flex items-center gap-1">
              <button
                type="button"
                disabled={page === 0}
                onClick={() => setPage((p) => p - 1)}
                className="rounded-md p-1 hover:bg-muted disabled:opacity-40"
                aria-label="Previous page"
              >
                <ChevronLeft className="h-4 w-4" />
              </button>
              <span className="tabular-nums">
                {page + 1} / {pages}
              </span>
              <button
                type="button"
                disabled={page >= pages - 1}
                onClick={() => setPage((p) => p + 1)}
                className="rounded-md p-1 hover:bg-muted disabled:opacity-40"
                aria-label="Next page"
              >
                <ChevronRight className="h-4 w-4" />
              </button>
            </span>
          </div>
        </Card>

        {selected ? (
          <SplitOutRail row={selected} onClose={() => setSelectedId(null)} onOpenCase={onOpenCase} />
        ) : (
          <div className="hidden rounded-xl border border-dashed p-6 text-center text-sm text-muted-foreground lg:block">
            Select a claim to see the evidence and decide.
          </div>
        )}
      </div>
    </div>
  );
}

function SplitOutRail({
  row,
  onClose,
  onOpenCase,
}: {
  row: SplitOutRow;
  onClose: () => void;
  onOpenCase: (id: string) => void;
}) {
  const { resolvedSplitOuts, resolveSplitOut } = useOtcStore();
  const [signFor, setSignFor] = useState<"credit" | "charge-back" | null>(null);
  const claim = row.runCase ? undefined : splitOutClaim(row.id);
  const category = claim ? NON_TRADE_BATCH.categories.find((c) => c.key === claim.category) : undefined;
  const outcome = resolvedSplitOuts[row.id];

  return (
    <Card key={row.id} className="animate-slide-in-right sticky top-4 flex max-h-[calc(100vh-2rem)] flex-col gap-0 overflow-hidden bg-card p-0">
      <div className="flex items-start justify-between gap-2 border-b px-4 py-3">
        <div className="flex min-w-0 flex-col gap-0.5">
          <span className="font-mono text-[11px] text-muted-foreground">{row.id}</span>
          <h3 className="text-sm font-semibold text-foreground text-pretty">{row.title}</h3>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="rounded-md p-1 text-muted-foreground hover:bg-muted hover:text-foreground"
          aria-label="Close claim"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      <div className="flex flex-col gap-4 overflow-y-auto px-4 py-3">
        <div className="flex flex-wrap items-center gap-2">
          <OwnerChip account={row.accountId} />
          <span className="text-sm font-semibold tabular-nums text-foreground">{formatUsd(row.amount)}</span>
          {claim && <ControlTag controlRef={claim.controlRef} />}
        </div>

        {row.runCase ? (
          <>
            <p className="text-sm text-muted-foreground text-pretty">{row.traceNote ?? "Worked as a full case run."}</p>
            <Button size="sm" onClick={() => onOpenCase(row.id)}>
              Open case <ArrowUpRight className="h-3.5 w-3.5" />
            </Button>
          </>
        ) : claim ? (
          <>
            {claim.detail ? (
              <>
                <p className="text-sm text-foreground text-pretty">{claim.detail.finding}</p>
                <ul className="flex flex-col gap-2">
                  {claim.detail.evidence.map((ev, i) => (
                    <li
                      key={ev.label}
                      className="animate-enter-fade flex items-start gap-2 rounded-md border px-2.5 py-2 text-xs"
                      style={{ animationDelay: `${i * 110}ms` }}
                    >
                      <SystemMark name={ev.system} className="mt-0.5 h-4 w-4 shrink-0" />
                      <span className="flex min-w-0 flex-col">
                        <span className="font-medium text-foreground">{ev.label}</span>
                        <span className="text-muted-foreground">{ev.detail}</span>
                      </span>
                      <span className="ml-auto inline-flex shrink-0 items-center gap-1 rounded-full border border-green-300 bg-green-50 px-1.5 py-0.5 text-[10px] font-semibold text-green-700">
                        <Check className="h-3 w-3" aria-hidden /> Pass
                      </span>
                    </li>
                  ))}
                </ul>
                <p className="rounded-md bg-primary/5 px-3 py-2 text-xs text-foreground text-pretty">{claim.detail.rationale}</p>
              </>
            ) : (
              <div className="flex flex-col gap-2 text-xs">
                <p className="text-sm text-foreground text-pretty">
                  {category?.label} claim outside the {NON_TRADE_BATCH.policyRef} rule. Checked against {category?.evidence.toLowerCase()}.
                </p>
                <span className="inline-flex items-center gap-1 self-start rounded-full border border-amber-300 bg-amber-50 px-1.5 py-0.5 text-[10px] font-semibold text-amber-800">
                  <Flag className="h-3 w-3" aria-hidden /> Rule did not decide
                </span>
              </div>
            )}

            {outcome ? (
              <p className="flex items-center gap-1.5 rounded-md border border-green-200 bg-green-50/50 px-3 py-2 text-xs text-green-800">
                <PenLine className="h-3.5 w-3.5" aria-hidden />
                Signed · {outcome === "credit" ? "accepted as credit" : "charged back"}
              </p>
            ) : (
              <div className="flex flex-col gap-2">
                <span className="text-xs text-muted-foreground">
                  Agent recommends {claim.recommendation === "credit" ? "accepting as credit" : "a charge-back"}.
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <Button
                    size="sm"
                    variant={claim.recommendation === "credit" ? "default" : "outline"}
                    onClick={() => setSignFor("credit")}
                  >
                    Accept as credit
                  </Button>
                  <Button
                    size="sm"
                    variant={claim.recommendation === "charge-back" ? "default" : "outline"}
                    onClick={() => setSignFor("charge-back")}
                  >
                    Charge back
                  </Button>
                </div>
              </div>
            )}

            {signFor && (
              <GateSignoffModal
                open
                onClose={() => setSignFor(null)}
                gateId={`${claim.id}:G1`}
                title={signFor === "credit" ? "Accept the claim as credit" : "Charge back the claim"}
                documentNo={`${claim.id} · decision`}
                caseId={claim.id}
                accountId={claim.accountId}
                module="Deductions"
                system="SAP FSCM"
                controls={[signFor === "credit" ? "1.4.3" : "1.4.4"]}
                evidence={
                  claim.detail
                    ? claim.detail.evidence.map((ev) => ({ id: ev.label, label: ev.label, detail: ev.detail, system: ev.system }))
                    : [{ id: "cat", label: `${category?.label} evidence · ${category?.evidence}`, system: "SAP FSCM" }]
                }
                lines={[{ label: signFor === "credit" ? "Credit memo" : "Charge-back", amountUsd: claim.usd, kind: signFor }]}
                attestation={`I ${signFor === "credit" ? "accept" : "charge back"} ${formatUsd(claim.usd)} on ${claim.id} (${claim.customer}, ${claim.reasonCode}).`}
                confirmLabel="Confirm decision"
                action={`${signFor === "credit" ? "Accepted as credit" : "Charged back"} ${claim.reasonCode} ${formatUsd(claim.usd)}`}
                decision={signFor === "credit" ? "Credit" : "Charge-back"}
                onSigned={() => {
                  resolveSplitOut(claim.id, signFor);
                  setSignFor(null);
                }}
              />
            )}
          </>
        ) : null}
      </div>
    </Card>
  );
}
