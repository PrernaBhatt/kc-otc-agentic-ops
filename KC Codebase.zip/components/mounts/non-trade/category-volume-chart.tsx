"use client";

import { useEffect, useRef, useState } from "react";

import { Tip } from "@/components/shared/floating-tip";
import { TickList } from "@/components/shared/tick-list";
import { NON_TRADE_BATCH } from "@/lib/data/non-trade-batch";
import { formatUsd } from "@/lib/format";

const played = new Set<string>();

/** S2: reason-code rules read (left), claim volume per category grows in order (right). */
export function CategoryVolumeChart({ onDone }: { onDone: () => void }) {
  const b = NON_TRADE_BATCH;
  const key = `${b.batchId}:classify`;
  const [readDone, setReadDone] = useState(played.has(key));
  const max = Math.max(...b.categories.map((c) => c.total.count));
  const doneRef = useRef(onDone);
  doneRef.current = onDone;

  useEffect(() => {
    if (!readDone) return;
    if (played.has(key)) {
      doneRef.current();
      return;
    }
    const t = setTimeout(() => {
      played.add(key);
      doneRef.current();
    }, b.categories.length * 160 + 700);
    return () => clearTimeout(t);
  }, [readDone, key, b.categories.length]);

  return (
    <div className="grid items-stretch gap-3 md:grid-cols-[minmax(0,1fr)_minmax(0,1.2fr)]">
      <section className="flex h-full flex-col rounded-lg border">
        <header className="border-b bg-muted/30 px-3 py-2 text-xs font-semibold text-foreground">
          Reason code rules · {b.policyRef}
        </header>
        <TickList
          className="px-3"
          playKey={`${key}:read`}
          stepMs={380}
          onDone={() => setReadDone(true)}
          items={b.categories.map((c) => ({ id: c.key, label: c.label, detail: c.rule, system: "SAP FSCM" }))}
        />
      </section>
      <section className="flex h-full flex-col rounded-lg border">
        <header className="border-b bg-muted/30 px-3 py-2 text-xs font-semibold text-foreground">
          Claims by category
        </header>
        <div className="flex flex-1 items-end gap-3 px-4 pb-3 pt-4" role="img" aria-label="Claims by category">
          {b.categories.map((c, i) => (
            <div key={c.key} className="flex h-44 flex-1 flex-col items-center justify-end gap-1.5">
              {readDone && (
                <>
                  <span className="animate-enter-fade text-xs font-semibold tabular-nums text-foreground" style={{ animationDelay: `${i * 160 + 400}ms` }}>
                    {c.total.count}
                  </span>
                  <Tip
                    content={{ title: c.label, value: `${c.total.count} claims · ${formatUsd(c.total.usd)}`, note: c.rule }}
                    className="grow-y block w-full max-w-12 rounded-t-md bg-primary/75 transition-colors hover:bg-primary"
                    style={{ height: `${(c.total.count / max) * 100}%`, animationDelay: `${i * 160}ms` }}
                  />
                </>
              )}
              <span className="text-[11px] text-muted-foreground">{c.label}</span>
              <span className="text-[10px] tabular-nums text-muted-foreground">{readDone ? formatUsd(c.total.usd) : "\u00a0"}</span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
