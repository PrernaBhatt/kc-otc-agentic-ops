"use client";

import { ArrowUpRight, ShieldCheck } from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { PersonAvatar } from "@/components/shared/owner-chip";
import { EscalationTracker, TradeClaimAgeTrend } from "@/components/mounts/accounts/escalation-tracker";
import type { OpenWorkItem } from "@/lib/account-selectors";
import { accountAgents } from "@/lib/data/account-work";
import { CONTROLLER, findPerson, type AccountOwnerRecord } from "@/lib/data/account-owners";
import type { Escalation } from "@/lib/data/escalations";
import { formatUsd } from "@/lib/format";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="flex flex-col gap-2">
      <h4 className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">{title}</h4>
      {children}
    </section>
  );
}

export function AccountRail({
  account,
  work,
  escalations,
}: {
  account: AccountOwnerRecord;
  work: OpenWorkItem[];
  escalations: Escalation[];
}) {
  const { requestNav } = useOtcStore();
  const agents = accountAgents[account.accountId] ?? [];
  const backup = findPerson(account.backupOwnerId);
  const maxItems = Math.max(1, ...agents.map((a) => a.itemsThisWeek));

  return (
    <Card
      key={account.accountId}
      className="animate-slide-in-right sticky top-4 flex max-h-[calc(100vh-2rem)] flex-col gap-0 overflow-hidden bg-card p-0"
      aria-label={`${account.accountName} detail`}
    >
      <div className="flex items-center gap-3 border-b px-4 py-3">
        <PersonAvatar person={account.owner} size="md" />
        <div className="min-w-0">
          <h3 className="text-sm font-semibold text-foreground">{account.owner.name}</h3>
          <p className="text-[11px] text-muted-foreground">
            {account.shortName} owner · {account.region}
          </p>
        </div>
      </div>

      <div className="flex flex-col gap-5 overflow-y-auto px-4 py-3">
        <Section title="Owner">
          <dl className="grid grid-cols-2 gap-x-3 gap-y-1.5 text-xs">
            <dt className="text-muted-foreground">Backup</dt>
            <dd className="text-right text-foreground">{backup?.name ?? "—"}</dd>
            <dt className="text-muted-foreground">Credit note limit</dt>
            <dd className="text-right tabular-nums text-foreground">{formatUsd(account.delegatedLimits.creditNoteUsd)}</dd>
            <dt className="text-muted-foreground">Charge-back limit</dt>
            <dd className="text-right tabular-nums text-foreground">{formatUsd(account.delegatedLimits.chargeBackUsd)}</dd>
            <dt className="text-muted-foreground">Above limit</dt>
            <dd className="text-right text-foreground">{CONTROLLER.name} co-signs</dd>
          </dl>
        </Section>

        <Section title={`Agents behind ${account.owner.name.split(" ")[0]}`}>
          <ul className="flex flex-col gap-1.5">
            {agents.map((a, i) => (
              <li
                key={a.name}
                className="animate-enter-fade flex items-center gap-2.5 rounded-md border px-2.5 py-2"
                style={{ animationDelay: `${i * 60}ms` }}
              >
                <AgentIcon type={a.glyph} size="sm" className="shrink-0 text-primary" />
                <span className="flex min-w-0 flex-1 flex-col">
                  <span className="truncate text-xs font-medium text-foreground">{a.name}</span>
                  <span className="truncate text-[11px] text-muted-foreground">{a.doing}</span>
                  <span className="mt-1 h-1 overflow-hidden rounded-full bg-muted">
                    <span
                      className="grow-x block h-full rounded-full bg-primary/70"
                      style={{ width: `${(a.itemsThisWeek / maxItems) * 100}%`, animationDelay: `${i * 60}ms` }}
                    />
                  </span>
                </span>
                <span className="flex shrink-0 flex-col items-end">
                  <span className="text-xs font-semibold tabular-nums text-foreground">{a.itemsThisWeek}</span>
                  <span className="font-mono text-[10px] text-muted-foreground">{a.lastActionAt}</span>
                </span>
              </li>
            ))}
          </ul>
        </Section>

        <Section title="Open work by module">
          <ul className="flex flex-col divide-y rounded-md border">
            {work.map((w) => (
              <li key={w.key}>
                <button
                  type="button"
                  disabled={w.count === 0}
                  onClick={() =>
                    requestNav({ view: w.view, accountId: account.accountId, lane: w.lane, caseId: w.caseId })
                  }
                  className={cn(
                    "flex w-full items-center gap-2 px-2.5 py-2 text-left text-xs transition-colors",
                    w.count > 0 ? "hover:bg-muted/40" : "cursor-default text-muted-foreground"
                  )}
                >
                  <span className="flex-1">{w.label}</span>
                  <span className="tabular-nums">{w.count}</span>
                  <span className="w-20 text-right tabular-nums text-foreground">{w.count > 0 ? formatUsd(w.usd) : "—"}</span>
                  <ArrowUpRight className={cn("h-3.5 w-3.5 shrink-0", w.count === 0 && "opacity-0")} aria-hidden />
                </button>
              </li>
            ))}
          </ul>
        </Section>

        <Section title={`Escalations (${escalations.filter((e) => e.status !== "Closed").length} open)`}>
          {escalations.length === 0 ? (
            <p className="text-xs text-muted-foreground">No escalations on this account.</p>
          ) : (
            escalations.map((e) => (
              <EscalationTracker key={e.id} escalation={e} ownerName={account.owner.name} accountId={account.accountId} />
            ))
          )}
          {account.tradeClaimAgeTrend && <TradeClaimAgeTrend points={account.tradeClaimAgeTrend} />}
        </Section>
      </div>

      <div className="mt-auto border-t px-4 py-3">
        <Button
          variant="outline"
          size="sm"
          className="w-full"
          onClick={() => requestNav({ view: "audit", audit: { accountId: account.accountId } })}
        >
          <ShieldCheck className="h-3.5 w-3.5" /> Audit for this account
        </Button>
      </div>
    </Card>
  );
}
