"use client";

import { BellRing, CalendarClock, TrendingUp } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { ApprovalChain } from "@/components/shared/approval-chain";
import { escalationChainNodes } from "@/components/shared/escalation-row";
import { Tip } from "@/components/shared/floating-tip";
import type { Escalation } from "@/lib/data/escalations";
import { escalationAgeDays, isEscalationOverdue } from "@/lib/escalation-selectors";
import { formatUsd } from "@/lib/format";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

export function EscalationTracker({
  escalation: e,
  ownerName,
  accountId,
}: {
  escalation: Escalation;
  ownerName: string;
  accountId: string;
}) {
  const { nudgeEscalation, appendAudit, freshEscalations } = useOtcStore();
  const age = escalationAgeDays(e);
  const overdue = isEscalationOverdue(e);
  const pct = Math.min(100, (age / e.slaDays) * 100);
  const fresh = freshEscalations.includes(e.id);

  const nudge = () => {
    nudgeEscalation(e.id, ownerName);
    appendAudit({
      caseId: e.sourceCaseId,
      accountId,
      module: e.sourceModule,
      actor: { kind: "person", name: ownerName, role: "Customer account owner" },
      action: `Nudged ${e.team} · ${e.unit} on ${e.id}`,
      controlRefs: [],
      amountUsd: e.amountUsd ?? undefined,
      evidence: [e.id],
      system: "ServiceNow",
    });
    toast.success(`Nudge sent to ${e.unit}`, { description: e.id });
  };

  return (
    <div
      data-escalation-id={e.id}
      data-escalation-status={e.status}
      data-overdue={overdue ? "true" : undefined}
      className={cn("flex flex-col gap-2.5 rounded-lg border p-3", fresh && "step-halo [--halo:4px]", overdue && "border-red-200")}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-muted-foreground">
            <span className="font-mono">{e.id}</span>
            <span aria-hidden>·</span>
            <span className="font-medium text-foreground">
              {e.team} · {e.unit}
            </span>
          </div>
          <div className="mt-0.5 text-sm font-medium text-foreground text-pretty">{e.subject}</div>
        </div>
        <div className="flex shrink-0 flex-col items-end gap-1">
          <span className="text-sm font-semibold tabular-nums text-foreground">{formatUsd(e.amountUsd ?? 0)}</span>
          <span
            className={cn(
              "rounded-full px-2 py-0.5 text-[10px] font-medium",
              overdue ? "bg-red-50 text-red-700" : "bg-muted text-muted-foreground"
            )}
          >
            {overdue ? "Overdue" : e.status}
          </span>
        </div>
      </div>

      <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
        <CalendarClock className="h-3.5 w-3.5 shrink-0" aria-hidden />
        <span className="shrink-0 tabular-nums">
          Raised {e.raisedOn.slice(5)} · day {age} / SLA {e.slaDays}
        </span>
        <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-muted">
          <span
            className={cn("grow-x block h-full rounded-full", overdue ? "bg-red-500" : "bg-primary")}
            style={{ width: `${Math.max(pct, 3)}%` }}
          />
        </span>
      </div>

      <ApprovalChain nodes={escalationChainNodes(e)} size="sm" />

      {e.nudges.length > 0 && (
        <ul className="flex flex-col gap-1 border-t pt-2">
          {e.nudges.map((n, i) => (
            <li
              key={`${n.at}-${i}`}
              className="animate-enter-fade flex items-start gap-2 text-[11px]"
              style={{ animationDelay: `${i * 80}ms` }}
            >
              <BellRing
                className={cn("mt-0.5 h-3 w-3 shrink-0", n.kind === "auto-escalated" ? "text-red-600" : "text-muted-foreground")}
                aria-hidden
              />
              <span className="font-mono text-muted-foreground">{n.at.slice(5)}</span>
              <span className="text-foreground">{n.note}</span>
            </li>
          ))}
        </ul>
      )}

      {e.status !== "Closed" && (
        <Button size="sm" variant="outline" className="self-start" onClick={nudge}>
          <BellRing className="h-3.5 w-3.5" /> Nudge
        </Button>
      )}
    </div>
  );
}

export function TradeClaimAgeTrend({ points }: { points: { month: string; days: number }[] }) {
  const max = Math.max(...points.map((p) => p.days));
  const w = 220;
  const h = 48;
  const step = w / Math.max(1, points.length - 1);
  const xy = points.map((p, i) => [i * step, h - (p.days / max) * (h - 8) - 4] as const);
  const d = xy.map(([x, y], i) => `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`).join(" ");

  return (
    <div className="flex flex-col gap-1.5 rounded-lg border p-3">
      <span className="flex items-center gap-1.5 text-xs font-medium text-foreground">
        <TrendingUp className="h-3.5 w-3.5 text-red-600" aria-hidden /> Average trade claim age
      </span>
      <div className="relative">
        <svg viewBox={`0 0 ${w} ${h}`} className="h-12 w-full overflow-visible" role="img" aria-label="Average trade claim age by month">
          <path d={d} fill="none" stroke="var(--primary)" strokeWidth={2} className="grow-x" />
        </svg>
        <div className="absolute inset-0 flex justify-between">
          {points.map((p) => (
            <Tip
              key={p.month}
              content={{ title: p.month, value: `${p.days} days` }}
              className="block h-full w-6"
              label={`${p.month} ${p.days} days`}
              focusable
            />
          ))}
        </div>
      </div>
      <div className="flex justify-between text-[10px] tabular-nums text-muted-foreground">
        {points.map((p) => (
          <span key={p.month}>
            {p.month} {p.days}d
          </span>
        ))}
      </div>
    </div>
  );
}
