"use client";

import { useEffect, useState } from "react";
import { ChevronLeft, ChevronRight, Search } from "lucide-react";

import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { PersonAvatar } from "@/components/shared/owner-chip";
import { REGIONS, type AccountRow } from "@/lib/account-selectors";
import { formatUsd } from "@/lib/format";
import { cn } from "@/lib/utils";

const PAGE_SIZE = 10;

function Count({ n, label }: { n: number; label: string }) {
  return (
    <span
      className={cn(
        "inline-flex min-w-7 flex-col items-center rounded-md px-1 py-0.5",
        n > 0 ? "bg-primary/5 text-foreground" : "text-muted-foreground"
      )}
      title={`${n} ${label}`}
    >
      <span className="text-xs font-semibold tabular-nums">{n}</span>
      <span className="text-[9px] uppercase tracking-wide text-muted-foreground">{label}</span>
    </span>
  );
}

export function AccountList({
  rows,
  selectedId,
  onSelect,
}: {
  rows: AccountRow[];
  selectedId: string | null;
  onSelect: (id: string) => void;
}) {
  const [region, setRegion] = useState("all");
  const [overdueOnly, setOverdueOnly] = useState(false);
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(0);

  const filtered = rows.filter((r) => {
    if (region !== "all" && r.region !== region) return false;
    if (overdueOnly && r.overdueEscalations === 0) return false;
    const q = query.trim().toLowerCase();
    return !q || `${r.name} ${r.ownerName} ${r.accountId}`.toLowerCase().includes(q);
  });
  const pages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  useEffect(() => {
    if (page >= pages) setPage(0);
  }, [page, pages]);
  const shown = filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);

  return (
    <Card className="flex min-w-0 flex-col overflow-hidden bg-card p-0">
      <div className="flex flex-wrap items-center gap-2 border-b px-3 py-2">
        <select
          aria-label="Region"
          value={region}
          onChange={(e) => setRegion(e.target.value)}
          className="h-8 rounded-md border bg-background px-2 text-xs"
        >
          <option value="all">All regions</option>
          {REGIONS.map((r) => (
            <option key={r} value={r}>
              {r}
            </option>
          ))}
        </select>
        <button
          type="button"
          aria-pressed={overdueOnly}
          onClick={() => setOverdueOnly((v) => !v)}
          className={cn(
            "h-8 rounded-md border px-2.5 text-xs transition-colors",
            overdueOnly ? "border-red-300 bg-red-50 text-red-700" : "hover:bg-muted"
          )}
        >
          Overdue escalation
        </button>
        <span className="relative ml-auto">
          <Search className="pointer-events-none absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Account or owner"
            aria-label="Search accounts"
            className="h-8 w-44 pl-7 text-xs"
          />
        </span>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[720px] text-sm">
          <thead>
            <tr className="border-b bg-muted/40 text-left text-xs text-muted-foreground">
              <th className="px-3 py-2 font-medium">Account</th>
              <th className="px-3 py-2 font-medium">Owner</th>
              <th className="px-3 py-2 text-center font-medium">Open work</th>
              <th className="px-3 py-2 text-right font-medium">At risk</th>
              <th className="px-3 py-2 font-medium">Escalations</th>
              <th className="px-3 py-2 text-right font-medium">Oldest</th>
              <th className="px-3 py-2 text-right font-medium">Agents</th>
            </tr>
          </thead>
          <tbody>
            {shown.length === 0 && (
              <tr>
                <td colSpan={7} className="px-3 py-8 text-center text-sm text-muted-foreground">
                  No accounts match these filters.
                </td>
              </tr>
            )}
            {shown.map((r, i) => (
              <tr
                key={r.accountId}
                data-account={r.accountId}
                data-owner={r.ownerName}
                onClick={() => onSelect(r.accountId)}
                className={cn(
                  "animate-enter-fade cursor-pointer border-b last:border-0 transition-colors hover:bg-muted/40",
                  r.accountId === selectedId && "bg-primary/5 hover:bg-primary/10"
                )}
                style={{ animationDelay: `${i * 40}ms` }}
              >
                <td className="px-3 py-2">
                  <span className="block text-sm font-semibold text-foreground">{r.name}</span>
                  <span className="block text-[11px] text-muted-foreground">{r.region}</span>
                </td>
                <td className="px-3 py-2">
                  <span className="flex items-center gap-2 text-xs text-foreground">
                    <PersonAvatar person={{ initials: r.ownerInitials, name: r.ownerName }} size="xs" />
                    {r.ownerName}
                  </span>
                </td>
                <td className="px-3 py-2">
                  <span className="flex justify-center gap-1">
                    <Count n={r.orders} label="Ord" />
                    <Count n={r.billing} label="Bill" />
                    <Count n={r.deductions} label="Ded" />
                  </span>
                </td>
                <td className="px-3 py-2 text-right text-xs font-semibold tabular-nums text-foreground">
                  {formatUsd(r.atRiskUsd)}
                </td>
                <td className="px-3 py-2">
                  {r.openEscalations === 0 ? (
                    <span className="text-xs text-muted-foreground">None</span>
                  ) : (
                    <span
                      data-overdue={r.overdueEscalations > 0 ? "true" : undefined}
                      className={cn(
                        "inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-medium",
                        r.overdueEscalations > 0 ? "bg-red-50 text-red-700" : "bg-muted text-foreground"
                      )}
                    >
                      {r.openEscalations} open
                      {r.overdueEscalations > 0 && ` · ${r.overdueEscalations} overdue`}
                    </span>
                  )}
                </td>
                <td className="px-3 py-2 text-right text-xs tabular-nums text-muted-foreground">{r.oldestDays} d</td>
                <td className="px-3 py-2 text-right text-xs tabular-nums text-foreground">{r.agentsActive}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="flex items-center justify-between border-t px-3 py-2 text-xs text-muted-foreground">
        <span className="tabular-nums">{filtered.length} accounts</span>
        <span className="flex items-center gap-1">
          <button
            type="button"
            disabled={page === 0}
            onClick={() => setPage((p) => p - 1)}
            className="rounded-md p-1 hover:bg-muted disabled:opacity-40"
            aria-label="Previous page"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          <span className="tabular-nums">
            {page + 1} / {pages}
          </span>
          <button
            type="button"
            disabled={page >= pages - 1}
            onClick={() => setPage((p) => p + 1)}
            className="rounded-md p-1 hover:bg-muted disabled:opacity-40"
            aria-label="Next page"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
        </span>
      </div>
    </Card>
  );
}
