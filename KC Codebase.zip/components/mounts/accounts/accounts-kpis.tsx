"use client";

import type { ReactNode } from "react";
import { Bot, Clock, Megaphone, UsersRound } from "lucide-react";

import { Card, CardContent } from "@/components/ui/card";
import { CountUp } from "@/components/ui/count-up";
import { Tip } from "@/components/shared/floating-tip";
import { agentShare, regionCounts, workloadTotals } from "@/lib/account-selectors";
import { accountOwners } from "@/lib/data/account-owners";
import type { Escalation } from "@/lib/data/escalations";
import { AGE_BUCKETS, ageBucket } from "@/lib/escalation-selectors";
import { cn } from "@/lib/utils";

const REGION_SHADES = ["bg-primary", "bg-primary/55", "bg-primary/25"];

function KpiCard({
  icon,
  label,
  value,
  footnote,
  delay,
  children,
}: {
  icon: ReactNode;
  label: string;
  value: ReactNode;
  footnote: string;
  delay: number;
  children: ReactNode;
}) {
  return (
    <Card className="flex h-full flex-col bg-card" style={{ animationDelay: `${delay}ms` }}>
      <CardContent className="flex flex-1 flex-col gap-3 p-4">
        <span className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
          {icon}
          {label}
        </span>
        <div className="text-2xl font-bold tabular-nums text-foreground">{value}</div>
        <div className="mt-auto flex flex-col gap-1.5">
          {children}
          <p className="text-[11px] text-muted-foreground">{footnote}</p>
        </div>
      </CardContent>
    </Card>
  );
}

export function AccountsKpis({ escalations }: { escalations: Escalation[] }) {
  const regions = regionCounts();
  const total = accountOwners.length;
  const open = escalations.filter((e) => e.status !== "Closed");
  const commercial = open.filter((e) => e.team === "Commercial").length;
  const supply = open.length - commercial;
  const buckets = AGE_BUCKETS.map((b) => ({ bucket: b, count: open.filter((e) => ageBucket(e) === b).length }));
  const maxBucket = Math.max(1, ...buckets.map((b) => b.count));

  return (
    <div className="grid items-stretch gap-4 sm:grid-cols-2 xl:grid-cols-4">
      <KpiCard
        delay={0}
        icon={<UsersRound className="h-3.5 w-3.5" aria-hidden />}
        label="Owner coverage"
        value={
          <span>
            <CountUp value={total} />
            <span className="text-base font-medium text-muted-foreground"> / {total} accounts</span>
          </span>
        }
        footnote={regions.map((r) => `${r.region === "North America" ? "NA" : r.region} ${r.count}`).join(" · ")}
      >
        <div className="flex h-3 w-full gap-0.5 overflow-hidden rounded-full">
          {regions.map((r, i) => (
            <Tip
              key={r.region}
              content={{ title: r.region, value: `${r.count} account${r.count === 1 ? "" : "s"} · 1 owner each` }}
              className={cn("grow-x block h-full transition-opacity hover:opacity-80", REGION_SHADES[i])}
              style={{ width: `${(r.count / total) * 100}%`, animationDelay: `${i * 80}ms` }}
            />
          ))}
        </div>
      </KpiCard>

      <KpiCard
        delay={60}
        icon={<Bot className="h-3.5 w-3.5" aria-hidden />}
        label="Handled by agents"
        value={
          <span>
            <CountUp value={agentShare} />%
          </span>
        }
        footnote={`${workloadTotals.agents.toLocaleString()} of ${workloadTotals.items.toLocaleString()} items this week`}
      >
        <div className="flex flex-col gap-1">
          {accountOwners.map((a, i) => {
            const items = a.workload.agents + a.workload.owner;
            return (
              <Tip
                key={a.accountId}
                content={{ title: a.shortName, value: `${a.workload.agents} by agents · ${a.workload.owner} by ${a.owner.name}` }}
                className="flex h-1.5 w-full overflow-hidden rounded-full bg-muted"
              >
                <span
                  className="grow-x block h-full bg-primary"
                  style={{ width: `${(a.workload.agents / items) * 100}%`, animationDelay: `${i * 50}ms` }}
                />
                <span className="block h-full flex-1 bg-amber-400" />
              </Tip>
            );
          })}
        </div>
      </KpiCard>

      <KpiCard
        delay={120}
        icon={<Megaphone className="h-3.5 w-3.5" aria-hidden />}
        label="Open escalations"
        value={<CountUp value={open.length} />}
        footnote={`Commercial ${commercial} · Supply chain ${supply}`}
      >
        <div className="flex h-3 w-full gap-0.5 overflow-hidden rounded-full bg-muted">
          {commercial > 0 && (
            <Tip
              content={{ title: "Commercial", value: `${commercial} open` }}
              className="grow-x block h-full bg-primary transition-opacity hover:opacity-80"
              style={{ width: `${(commercial / Math.max(1, open.length)) * 100}%` }}
            />
          )}
          {supply > 0 && (
            <Tip
              content={{ title: "Supply chain", value: `${supply} open` }}
              className="grow-x block h-full bg-[var(--accent)]/50 transition-opacity hover:opacity-80"
              style={{ width: `${(supply / Math.max(1, open.length)) * 100}%`, animationDelay: "100ms" }}
            />
          )}
        </div>
      </KpiCard>

      <KpiCard
        delay={180}
        icon={<Clock className="h-3.5 w-3.5" aria-hidden />}
        label="Escalation age"
        value={
          <span>
            <CountUp value={buckets[2].count} />
            <span className="text-base font-medium text-muted-foreground"> past 30 days</span>
          </span>
        }
        footnote="Days open · SLA up to 30"
      >
        <div className="relative flex h-12 items-end gap-2">
          {buckets.map((b, i) => (
            <div key={b.bucket} className="flex h-full flex-1 flex-col items-center justify-end gap-0.5">
              <Tip
                content={{ title: `${b.bucket} days`, value: `${b.count} escalation${b.count === 1 ? "" : "s"}` }}
                className={cn(
                  "grow-y block w-full rounded-t-sm transition-opacity hover:opacity-80",
                  b.bucket === "31+" ? "bg-red-500" : "bg-primary/70"
                )}
                style={{ height: `${Math.max(8, (b.count / maxBucket) * 80)}%`, animationDelay: `${i * 90}ms` }}
              />
            </div>
          ))}
          <span
            className="pointer-events-none absolute inset-y-0 left-2/3 border-l border-dashed border-red-400"
            aria-hidden
          />
        </div>
        <div className="flex text-[10px] text-muted-foreground">
          {buckets.map((b) => (
            <span key={b.bucket} className="flex-1 text-center tabular-nums">
              {b.bucket}
            </span>
          ))}
        </div>
      </KpiCard>
    </div>
  );
}
