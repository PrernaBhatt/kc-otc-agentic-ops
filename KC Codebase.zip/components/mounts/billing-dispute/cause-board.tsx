"use client";

import { useEffect, useState } from "react";

import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { ControlTag } from "@/components/shared/control-tag";
import { SystemMark } from "@/components/shared/system-badge";
import { TickList } from "@/components/shared/tick-list";
import type { BillingDisputeFigures } from "@/lib/billing-dispute-selectors";
import { buildCauseEvidenceDoc } from "@/lib/docs-billing-dispute";
import { formatUsd } from "@/lib/format";
import { cn } from "@/lib/utils";

const played = new Set<string>();

/** Once the verdict lands, the wrong side is struck through in red and the right side turns green. */
export function sideTone(decided: boolean, right: boolean) {
  if (!decided) return "text-foreground";
  return right
    ? "font-medium text-emerald-600 transition-colors"
    : "text-red-600 line-through transition-colors";
}

export function VerdictChip({ verdict, customer }: { verdict: "kc" | "customer"; customer: string }) {
  return (
    <span
      className={cn(
        "step-pop inline-flex whitespace-nowrap rounded-full px-2 py-0.5 text-[11px] font-medium",
        verdict === "kc"
          ? "bg-primary/10 text-primary"
          : "bg-amber-50 text-amber-700 ring-1 ring-amber-200"
      )}
    >
      {verdict === "kc" ? "K-C right" : `${customer} right`}
    </span>
  );
}

/**
 * S2: the agent queries each system that owns a piece of the price, then the
 * four causes land as facts. The verdict is the only judgment, so only the
 * verdict chips reveal one by one.
 */
export function CauseBoard({
  figures,
  onDone,
}: {
  figures: BillingDisputeFigures;
  onDone: () => void;
}) {
  const c = figures.case;
  const key = `${c.caseId}:cause`;
  const [queried, setQueried] = useState(played.has(key));
  const [verdicts, setVerdicts] = useState(played.has(key) ? figures.causes.length : 0);

  useEffect(() => {
    if (!queried) return;
    if (verdicts >= figures.causes.length) {
      played.add(key);
      onDone();
      return;
    }
    const t = setTimeout(() => setVerdicts((v) => v + 1), 650);
    return () => clearTimeout(t);
  }, [queried, verdicts, figures.causes.length, key, onDone]);

  if (!queried) {
    return (
      <TickList
        playKey={`${key}:query`}
        stepMs={480}
        onDone={() => setQueried(true)}
        items={[
          { id: "sap", system: "SAP S/4HANA", label: "SAP PR00 condition and invoice", detail: `${c.invoiceId} · ${c.sapFreightCondition}` },
          { id: "pricerx", system: "PricerX", label: `PricerX ${c.pricerXNoteRef}`, detail: `Approved ${c.pricerXApprovedOn} · ${c.priceCatalogRef}` },
          { id: "vistex", system: "Vistex", label: `Vistex ${c.promotionRef}`, detail: c.promotionWindow },
          { id: "tm", system: "SAP TM", label: "SAP TM freight settlement", detail: c.vendorAgreementRef },
          { id: "vertex", system: "Vertex", label: "Vertex tax determination", detail: `Certificate ${c.exemptionCertificate}` },
        ]}
      />
    );
  }

  return (
    <div className="overflow-hidden rounded-lg border">
      <table className="w-full border-collapse text-sm">
        <thead>
          <tr className="border-b bg-muted/30 text-left text-[11px] text-muted-foreground">
            <th className="px-3 py-2 font-medium">Cause</th>
            <th className="px-3 py-2 font-medium">K-C billed</th>
            <th className="px-3 py-2 font-medium">Costco paid</th>
            <th className="px-3 py-2 text-right font-medium">Amount</th>
            <th className="px-3 py-2 font-medium">Finding</th>
            <th className="px-3 py-2 font-medium" />
          </tr>
        </thead>
        <tbody>
          {figures.causes.map((x, i) => (
            <tr
              key={x.key}
              data-cause={x.key}
              data-verdict={i < verdicts ? x.verdict : undefined}
              className="animate-enter-fade border-b align-top last:border-b-0"
            >
              <td className="px-3 py-2.5">
                <div className="flex items-center gap-1.5 font-medium text-foreground">
                  {x.systems.map((s) => (
                    <SystemMark key={s} name={s} />
                  ))}
                  {x.label}
                </div>
                <div className="mt-0.5 font-mono text-[10px] text-muted-foreground">ADX {x.reasonCode}</div>
              </td>
              <td className={cn("px-3 py-2.5 text-xs", sideTone(i < verdicts, x.verdict === "kc"))}>{x.kcSide}</td>
              <td className={cn("px-3 py-2.5 text-xs", sideTone(i < verdicts, x.verdict === "customer"))}>
                {x.customerSide}
              </td>
              <td className="px-3 py-2.5 text-right text-xs font-semibold tabular-nums text-foreground">
                {formatUsd(x.amount)}
              </td>
              <td className="px-3 py-2.5">
                <div className="flex min-h-5 flex-wrap items-center gap-1">
                  {i < verdicts ? (
                    <VerdictChip verdict={x.verdict} customer="Costco" />
                  ) : (
                    <span className="h-5 w-16 animate-pulse rounded-full bg-muted" aria-hidden />
                  )}
                  {x.controlRef && i < verdicts && <ControlTag controlRef={x.controlRef} />}
                </div>
                {i < verdicts && (
                  <p className="animate-enter-fade mt-1 max-w-64 text-[11px] leading-relaxed text-muted-foreground">
                    {x.finding}
                  </p>
                )}
              </td>
              <td className="px-3 py-2.5 text-right">
                <SourceDocTrigger
                  doc={buildCauseEvidenceDoc(c.caseId, x.key)}
                  label="Evidence"
                  className="h-6 px-1.5 text-[11px]"
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
