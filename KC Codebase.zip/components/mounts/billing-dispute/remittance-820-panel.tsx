"use client";

import { useState } from "react";

import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { FillFields } from "@/components/shared/fill-fields";
import { SystemMark } from "@/components/shared/system-badge";
import { TickList } from "@/components/shared/tick-list";
import type { BillingDisputeFigures } from "@/lib/billing-dispute-selectors";
import { findAccount } from "@/lib/data/account-owners";
import { buildDisputeCaseDoc, buildInvoiceDoc, buildRemittanceDoc } from "@/lib/docs-billing-dispute";
import { formatUsd } from "@/lib/format";

/**
 * S1: the agent reads Costco's 820 line by line (left), then opens the FSCM
 * dispute case on the original invoice, its fields typing in (right).
 */
export function Remittance820Panel({
  figures,
  onDone,
}: {
  figures: BillingDisputeFigures;
  onDone: () => void;
}) {
  const c = figures.case;
  const [readDone, setReadDone] = useState(false);
  const owner = findAccount(c.accountId)?.owner.name ?? "";
  const key = `${c.caseId}:capture`;

  return (
    <div className="grid items-stretch gap-3 md:grid-cols-2">
      <section className="flex h-full flex-col rounded-lg border">
        <header className="flex items-center justify-between gap-2 border-b bg-muted/30 px-3 py-2">
          <span className="text-xs font-semibold text-foreground">EDI 820 · {c.remittanceId}</span>
          <SourceDocTrigger doc={buildRemittanceDoc(c.caseId)} label="Open" className="h-6 px-1.5 text-[11px]" />
        </header>
        <TickList
          className="px-3"
          playKey={`${key}:read`}
          stepMs={420}
          onDone={() => setReadDone(true)}
          items={[
            {
              id: "bpr",
              label: <span className="font-mono text-xs">BPR · {formatUsd(figures.paid)}</span>,
              detail: `${c.paymentRef} · ${c.remittanceDate}`,
            },
            {
              id: "rmr",
              label: <span className="font-mono text-xs">RMR · {c.invoiceId}</span>,
              detail: `Billed ${formatUsd(figures.invoiceTotal)} · open item in SAP`,
              trailing: (
                <SourceDocTrigger doc={buildInvoiceDoc(c.caseId)} label="Invoice" className="h-6 px-1.5 text-[11px]" />
              ),
            },
            ...figures.causes.map((x) => ({
              id: x.key,
              label: (
                <span className="flex items-center gap-2">
                  <span className="font-mono text-xs">ADX {x.reasonCode}</span>
                  <span className="text-xs text-muted-foreground">{x.reasonText}</span>
                </span>
              ),
              trailing: (
                <span className="text-xs font-semibold tabular-nums text-red-600">−{formatUsd(x.amount)}</span>
              ),
            })),
          ]}
        />
      </section>

      <section
        className="flex h-full flex-col rounded-lg border"
        data-dispute-case={c.caseId}
      >
        <header className="flex items-center justify-between gap-2 border-b bg-muted/30 px-3 py-2">
          <span className="flex items-center gap-1.5 text-xs font-semibold text-foreground">
            <SystemMark name="SAP FSCM" /> Dispute case
          </span>
          {readDone && (
            <SourceDocTrigger doc={buildDisputeCaseDoc(c.caseId)} label="Open" className="h-6 px-1.5 text-[11px]" />
          )}
        </header>
        <FillFields
          className="px-3 py-2"
          play={readDone}
          playKey={`${key}:write`}
          onDone={onDone}
          fields={[
            { label: "Case", value: c.caseId, mono: true },
            { label: "Customer", value: c.customerName },
            { label: "Original invoice", value: c.invoiceId, mono: true },
            { label: "Disputed", value: formatUsd(figures.shortPaid), align: "right", strong: true },
            { label: "Reason codes", value: figures.causes.map((x) => x.reasonCode).join(" · ") },
            { label: "Coordinator", value: owner },
            { label: "Residual item", value: `${formatUsd(figures.shortPaid)} on ${c.invoiceId}`, align: "right" },
          ]}
          stamp={
            <span className="rounded-full border border-blue-300 bg-blue-50 px-2 py-0.5 text-[11px] font-medium text-blue-700">
              Status · New
            </span>
          }
        />
      </section>
    </div>
  );
}
