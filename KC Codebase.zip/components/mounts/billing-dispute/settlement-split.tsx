"use client";

import { useEffect, useState } from "react";
import { CircleCheck } from "lucide-react";

import { Spinner } from "@/components/agents/spinner";
import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { FillFields } from "@/components/shared/fill-fields";
import { Tip } from "@/components/shared/floating-tip";
import type { BillingDisputeFigures } from "@/lib/billing-dispute-selectors";
import { buildChargeBackDoc, buildCreditMemoDoc } from "@/lib/docs-billing-dispute";
import { formatUsd } from "@/lib/format";
import { cn } from "@/lib/utils";

const STAGE_ROW_MS = 700;
const staged = new Set<string>();

/**
 * S3: each cause is staged in FSCM one row at a time (the wrong value struck
 * through, the settled value beside it), then the short-pay splits into the
 * charge-back and the credit note, and both documents fill.
 */
export function SettlementSplit({
  figures,
  onDone,
}: {
  figures: BillingDisputeFigures;
  onDone: () => void;
}) {
  const c = figures.case;
  const key = `${c.caseId}:settle`;
  const [rows, setRows] = useState(staged.has(key) ? figures.causes.length : 0);
  const [chbDone, setChbDone] = useState(false);
  const allStaged = rows >= figures.causes.length;
  const chbShare = (figures.chargeBack / figures.shortPaid) * 100;
  const kc = figures.causes.filter((x) => x.verdict === "kc");
  const cust = figures.causes.filter((x) => x.verdict === "customer");

  useEffect(() => {
    if (allStaged) {
      staged.add(key);
      return;
    }
    const t = setTimeout(() => setRows((r) => r + 1), STAGE_ROW_MS);
    return () => clearTimeout(t);
  }, [allStaged, rows, key]);

  return (
    <div
      className="flex flex-col gap-3"
      data-settlement-credit={figures.credit}
      data-settlement-chargeback={figures.chargeBack}
    >
      <div className="overflow-hidden rounded-lg border">
        <div className="flex items-center justify-between gap-2 border-b bg-muted/30 px-4 py-2.5">
          <div className="flex items-center gap-2">
            {/* eslint-disable-next-line @next/next/no-img-element -- brand mark, not an optimizable asset */}
            <img src="/icons/sap.svg" alt="SAP" className="h-4 w-4" />
            <span className="text-xs font-semibold text-foreground">
              Proposed settlement · {c.caseId} on {c.invoiceId}
            </span>
          </div>
          <span className="text-[11px] text-muted-foreground">
            {allStaged ? "Draft staged · not posted" : "Staging causes in FSCM…"}
          </span>
        </div>
        <table className="w-full border-collapse text-sm">
          <thead>
            <tr className="border-b text-left text-[11px] text-muted-foreground">
              <th className="px-3 py-2 font-medium">Cause</th>
              <th className="px-3 py-2 font-medium">Disputed</th>
              <th className="px-3 py-2 font-medium">Settled at</th>
              <th className="px-3 py-2 text-right font-medium">Outcome</th>
              <th className="px-3 py-2 font-medium">
                <span className="sr-only">Status</span>
              </th>
            </tr>
          </thead>
          <tbody>
            {figures.causes.map((x, i) => {
              const isStaged = i < rows;
              const isStaging = i === rows;
              const kcRight = x.verdict === "kc";
              return (
                <tr
                  key={x.key}
                  data-settle-row={x.key}
                  className={cn(
                    "border-t transition-colors duration-500 first:border-t-0",
                    isStaging && "bg-primary/5",
                    !isStaged && !isStaging && "opacity-40"
                  )}
                >
                  <td className="px-3 py-2.5 align-middle">
                    <div className="font-mono text-[11px] text-muted-foreground">ADX {x.reasonCode}</div>
                    <div className="text-foreground">{x.label}</div>
                  </td>
                  <td className="px-3 py-2.5 align-middle tabular-nums text-red-600 line-through">
                    {kcRight ? x.customerSide : x.kcSide}
                  </td>
                  <td className="px-3 py-2.5 align-middle font-medium tabular-nums text-emerald-600">
                    {kcRight ? x.kcSide : x.customerSide}
                  </td>
                  <td className="whitespace-nowrap px-3 py-2.5 text-right align-middle font-semibold tabular-nums text-foreground">
                    {formatUsd(x.amount)}
                    <div
                      className={cn(
                        "text-[10px] font-medium uppercase tracking-wide",
                        kcRight ? "text-primary" : "text-amber-700"
                      )}
                    >
                      {kcRight ? "Charge-back" : "Credit note"}
                    </div>
                  </td>
                  <td className="w-8 px-3 py-2.5 align-middle">
                    {isStaged ? (
                      <CircleCheck
                        className="h-4 w-4 text-[var(--success)] animate-in zoom-in-50 duration-300"
                        aria-label="Staged"
                      />
                    ) : isStaging ? (
                      <Spinner size="sm" className="text-primary" />
                    ) : null}
                  </td>
                </tr>
              );
            })}
          </tbody>
          <tfoot>
            <tr className="border-t bg-muted/30">
              <td colSpan={3} className="px-3 py-2.5 text-xs font-semibold text-foreground">
                Short-pay settled · invoice {c.invoiceId} stands as issued
              </td>
              <td className="whitespace-nowrap px-3 py-2.5 text-right font-semibold tabular-nums text-foreground">
                {formatUsd(figures.shortPaid)}
              </td>
              <td />
            </tr>
          </tfoot>
        </table>
      </div>

      {allStaged && (
        <>
          <div className="animate-enter flex flex-col gap-1.5">
            <div className="flex items-baseline justify-between text-xs">
              <span className="text-muted-foreground">Short-paid on {c.invoiceId}</span>
              <span className="font-semibold tabular-nums text-foreground">{formatUsd(figures.shortPaid)}</span>
            </div>
            <div className="grow-x flex h-3 w-full overflow-hidden rounded-full bg-muted">
              <Tip
                className="h-full bg-primary"
                style={{ width: `${chbShare}%` }}
                content={{ title: "Charge-back · K-C right", value: formatUsd(figures.chargeBack), note: kc.map((x) => x.label).join(" + ") }}
              />
              <Tip
                className="h-full bg-amber-400"
                style={{ width: `${100 - chbShare}%` }}
                content={{ title: "Credit note · Costco right", value: formatUsd(figures.credit), note: cust.map((x) => x.label).join(" + ") }}
              />
            </div>
            <div className="flex justify-between text-[11px] text-muted-foreground">
              <span>Charge-back {formatUsd(figures.chargeBack)}</span>
              <span>Credit note {formatUsd(figures.credit)}</span>
            </div>
          </div>

          <div className="animate-enter grid items-stretch gap-3 md:grid-cols-2">
            <section className="flex h-full flex-col rounded-lg border">
              <header className="flex items-center justify-between gap-2 border-b bg-muted/30 px-3 py-2">
                <span className="text-xs font-semibold text-foreground">Charge-back notice</span>
                {chbDone && <SourceDocTrigger doc={buildChargeBackDoc(c.caseId)} label="Open ↗" className="h-6 px-1.5 text-[11px]" />}
              </header>
              <FillFields
                className="px-3 py-2"
                playKey={`${key}:chb`}
                onDone={() => setChbDone(true)}
                fields={[
                  { label: "Document", value: c.chargeBackId, mono: true },
                  ...kc.map((x) => ({ label: `${x.label} · ADX ${x.reasonCode}`, value: formatUsd(x.amount), align: "right" as const })),
                  { label: "Due from Costco", value: formatUsd(figures.chargeBack), align: "right", strong: true },
                  { label: "Backup", value: "PricerX note, Vistex end date, POD" },
                ]}
              />
            </section>
            <section className="flex h-full flex-col rounded-lg border">
              <header className="flex items-center justify-between gap-2 border-b bg-muted/30 px-3 py-2">
                <span className="text-xs font-semibold text-foreground">Credit memo request</span>
                <SourceDocTrigger doc={buildCreditMemoDoc(c.caseId)} label="Open ↗" className="h-6 px-1.5 text-[11px]" />
              </header>
              <FillFields
                className="px-3 py-2"
                play={chbDone}
                playKey={`${key}:cmr`}
                onDone={onDone}
                fields={[
                  { label: "Document", value: c.creditMemoRequestId, mono: true },
                  ...cust.map((x) => ({ label: `${x.label} · ADX ${x.reasonCode}`, value: formatUsd(x.amount), align: "right" as const })),
                  { label: "Credit to Costco", value: formatUsd(figures.credit), align: "right", strong: true },
                  { label: "Reference", value: c.invoiceId, mono: true },
                ]}
              />
            </section>
          </div>
        </>
      )}
    </div>
  );
}
