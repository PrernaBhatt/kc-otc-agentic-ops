"use client";

import { useEffect, useRef, useState } from "react";
import { CircleCheck, Lock, Send } from "lucide-react";

import { Spinner } from "@/components/agents/spinner";
import { cn } from "@/lib/utils";

export interface PostingCheck {
  label: string;
  detail: string;
}

const CHECK_MS = 650;
const passedRuns = new Set<string>();

/**
 * Runs every pre-posting check one at a time. FSCM posting stays locked
 * until the last one passes.
 */
export function PostingChecks({
  playKey,
  checks,
  title,
  lockedLabel,
  lockedDetail,
  passedLabel,
  passedDetail,
  amount,
  onAllPassed,
}: {
  playKey: string;
  checks: PostingCheck[];
  title: string;
  lockedLabel: string;
  lockedDetail: string;
  passedLabel: string;
  passedDetail: string;
  amount: string;
  onAllPassed: () => void;
}) {
  const [passed, setPassed] = useState(passedRuns.has(playKey) ? checks.length : 0);
  const onDoneRef = useRef(onAllPassed);
  onDoneRef.current = onAllPassed;
  const allPassed = passed >= checks.length;

  useEffect(() => {
    if (allPassed) {
      passedRuns.add(playKey);
      const t = setTimeout(() => onDoneRef.current(), 400);
      return () => clearTimeout(t);
    }
    const t = setTimeout(() => setPassed((p) => p + 1), CHECK_MS);
    return () => clearTimeout(t);
  }, [allPassed, passed, playKey]);

  return (
    <div className="flex flex-col gap-3">
      <div className="overflow-hidden rounded-lg border">
        <div className="flex items-center justify-between border-b bg-muted/30 px-4 py-2.5">
          <span className="text-xs font-semibold text-foreground">{title}</span>
          <span className="text-[11px] tabular-nums text-muted-foreground">
            {Math.min(passed, checks.length)} / {checks.length} passed
          </span>
        </div>
        <ul className="px-4">
          {checks.map((check, i) => {
            const done = i < passed;
            const running = i === passed;
            return (
              <li
                key={check.label}
                className={cn(
                  "flex items-start gap-2.5 border-t py-2.5 transition-opacity duration-300 first:border-t-0",
                  !done && !running && "opacity-40"
                )}
              >
                <span className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center">
                  {done ? (
                    <CircleCheck className="h-4 w-4 text-[var(--success)] animate-in zoom-in-50 duration-300" />
                  ) : running ? (
                    <Spinner size="sm" className="text-primary" />
                  ) : (
                    <span className="h-2 w-2 rounded-full bg-muted-foreground/40" />
                  )}
                </span>
                <div className="min-w-0">
                  <div className="text-sm font-medium text-foreground">{check.label}</div>
                  <div className="text-xs text-muted-foreground">{check.detail}</div>
                </div>
              </li>
            );
          })}
        </ul>
      </div>

      <div
        className={cn(
          "flex items-center justify-between gap-3 rounded-lg border px-4 py-3 transition-colors duration-500",
          allPassed ? "border-[var(--success)]/40 bg-[var(--success)]/10" : "border-dashed text-muted-foreground"
        )}
      >
        <div className="flex items-center gap-2.5">
          {allPassed ? <Send className="h-4 w-4 text-[var(--success)]" /> : <Lock className="h-4 w-4" />}
          <div>
            <div className={cn("text-sm font-semibold", allPassed && "text-foreground")}>
              {allPassed ? passedLabel : lockedLabel}
            </div>
            <div className="text-xs text-muted-foreground">{allPassed ? passedDetail : lockedDetail}</div>
          </div>
        </div>
        <span className="text-sm font-semibold tabular-nums text-foreground">{amount}</span>
      </div>
    </div>
  );
}
