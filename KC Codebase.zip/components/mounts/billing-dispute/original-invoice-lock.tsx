"use client";

import { Lock } from "lucide-react";

import { Tip } from "@/components/shared/floating-tip";
import { formatUsd } from "@/lib/format";

/** The original invoice stays as issued: its period is closed for tax. */
export function OriginalInvoiceLock({
  invoiceId,
  amount,
  periodClosedOn,
}: {
  invoiceId: string;
  amount: number;
  periodClosedOn: string;
}) {
  return (
    <Tip
      className="animate-enter-fade inline-flex items-center gap-2 self-start rounded-full border bg-muted/40 px-3 py-1 text-xs text-foreground"
      content={{
        title: "Closed-period rule",
        note: `September closed ${periodClosedOn}. Once a deduction exists the invoice is never reissued; the difference settles on the dispute case.`,
      }}
    >
      <span data-invoice-reissued="false" className="inline-flex items-center gap-2">
        <Lock className="h-3.5 w-3.5 text-muted-foreground" aria-hidden />
        <span className="font-mono">{invoiceId}</span>
        <span className="text-muted-foreground">· Sep period closed · not reissued ·</span>
        <span className="font-semibold tabular-nums">{formatUsd(amount)}</span>
      </span>
    </Tip>
  );
}
