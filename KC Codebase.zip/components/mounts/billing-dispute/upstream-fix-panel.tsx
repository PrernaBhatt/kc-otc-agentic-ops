"use client";

import { CircleCheck } from "lucide-react";
import { useEffect, useState } from "react";

import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { ControlTag } from "@/components/shared/control-tag";
import { EscalationRow } from "@/components/shared/escalation-row";
import { FillFields } from "@/components/shared/fill-fields";
import { SystemMark } from "@/components/shared/system-badge";
import type { BillingDisputeFigures } from "@/lib/billing-dispute-selectors";
import { buildUpstreamDoc } from "@/lib/docs-billing-dispute";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

/**
 * S5: each cause goes back to the team that owns it. Pricing gets tasks,
 * Master data gets MDG change requests, and two tracked escalations go to
 * Commercial and Supply chain.
 */
export function UpstreamFixPanel({
  figures,
  onDone,
}: {
  figures: BillingDisputeFigures;
  onDone: () => void;
}) {
  const c = figures.case;
  const { escalations } = useOtcStore();
  const [filled, setFilled] = useState(0);
  const key = `${c.caseId}:upstream`;
  const groups = (["Pricing", "Master data"] as const).map((team) => ({
    team,
    fixes: c.upstream.filter((u) => u.team === team),
  }));
  const order = groups.flatMap((g) => g.fixes.map((f) => f.id));
  const allFilled = filled >= order.length;
  const raised = escalations.filter((e) => (c.escalationIds as string[]).includes(e.id));

  useEffect(() => {
    if (allFilled) onDone();
  }, [allFilled, onDone]);

  return (
    <div className="flex flex-col gap-3">
      <div className="animate-enter overflow-hidden rounded-lg border">
        <table className="w-full border-collapse">
          <thead>
            <tr className="border-b bg-muted/30 text-left text-[11px] text-muted-foreground">
              <th className="px-3 py-2 font-medium">Cause</th>
              <th className="px-3 py-2 font-medium">Original</th>
              <th className="px-3 py-2 font-medium">Corrected</th>
              <th className="px-3 py-2 font-medium">Owner</th>
            </tr>
          </thead>
          <tbody>
            {order.map((id, idx) => {
              const fix = c.upstream.find((u) => u.id === id)!;
              const cause = figures.causes.find((x) => x.key === fix.cause)!;
              const done = idx < filled;
              return (
                <tr key={id} data-change={id} className="border-t first:border-t-0">
                  <td className="px-3 py-2.5 text-sm text-foreground">{cause.label}</td>
                  <td
                    className={cn(
                      "px-3 py-2.5 text-sm tabular-nums transition-colors",
                      done ? "text-red-600 line-through" : "text-foreground"
                    )}
                  >
                    {fix.from}
                  </td>
                  <td className="px-3 py-2.5 text-sm font-medium tabular-nums text-emerald-600">
                    {done ? (
                      <span className="animate-enter-fade">{fix.to}</span>
                    ) : (
                      <span className="inline-block h-4 w-20 animate-pulse rounded bg-muted align-middle" aria-hidden />
                    )}
                  </td>
                  <td className="px-3 py-2.5">
                    <div className="flex min-h-7 flex-wrap items-center gap-2">
                      <SourceDocTrigger doc={buildUpstreamDoc(c.caseId, fix.id)} label={fix.id} className="h-6 px-1.5 text-[11px]" />
                      {done && (
                        <span className="step-pop inline-flex items-center gap-1.5 rounded-full border border-[var(--success)]/30 bg-[var(--success)]/10 px-2.5 py-1 text-[11px] font-medium text-[var(--success)]">
                          <CircleCheck className="h-3.5 w-3.5" aria-hidden />
                          Routed to {fix.team}
                        </span>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="grid items-stretch gap-3 md:grid-cols-2">
        {groups.map((g) => (
          <section key={g.team} className="flex h-full flex-col gap-2">
            <h4 className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">{g.team}</h4>
            {g.fixes.map((fix) => {
              const idx = order.indexOf(fix.id);
              if (idx > filled) return null;
              const cause = figures.causes.find((x) => x.key === fix.cause)!;
              return (
                <article
                  key={fix.id}
                  data-upstream={fix.id}
                  className="animate-enter flex flex-col rounded-lg border"
                >
                  <header className="flex items-center justify-between gap-2 border-b bg-muted/30 px-3 py-2">
                    <span className="flex min-w-0 items-center gap-1.5 text-xs font-semibold text-foreground">
                      <SystemMark name={fix.system} />
                      <span className="font-mono">{fix.id}</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <ControlTag controlRef={fix.controlRef} />
                      <SourceDocTrigger doc={buildUpstreamDoc(c.caseId, fix.id)} label="Open ↗" className="h-6 px-1.5 text-[11px]" />
                    </span>
                  </header>
                  <FillFields
                    className="px-3 py-2"
                    playKey={`${key}:${fix.id}`}
                    onDone={() => setFilled((n) => Math.max(n, idx + 1))}
                    fields={[
                      { label: "Cause", value: cause.label },
                      { label: "Change", value: fix.change },
                      { label: "Assigned to", value: fix.assignee },
                      { label: "Status", value: fix.status },
                    ]}
                  />
                </article>
              );
            })}
          </section>
        ))}
      </div>

      {allFilled && (
        <section className="flex flex-col gap-2">
          <h4 className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
            Escalations · tracked on Accounts
          </h4>
          <div className="grid items-stretch gap-2 md:grid-cols-2">
            {raised.map((e) => (
              <EscalationRow key={e.id} escalation={e} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
