"use client";

import { useMemo, useState } from "react";
import {
  CircleCheck,
  Clock,
  Inbox,
  Mail,
  MessageSquare,
  Phone,
  Send,
  Sparkles,
  SquarePen,
  Timer,
} from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import {
  SourceDocTrigger,
  type SourceDoc,
} from "@/components/modals/source-doc-preview";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import {
  onTimeResponseRatePercent,
  orders,
  revRecContracts,
  shipments,
} from "@/lib/data";
import type { CustomerQuery } from "@/lib/data/queries";
import type { DeductionCase } from "@/lib/data/deductions";
import type { Invoice } from "@/lib/data/types";
import {
  buildAgingReportDoc,
  buildClaimDoc,
  buildContractDoc,
  buildInvoiceDoc,
  buildPodDoc,
  buildSalesOrderDoc,
} from "@/lib/docs";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const CHANNEL_ICONS = {
  Email: Mail,
  Portal: MessageSquare,
  Phone: Phone,
} as const;

function confidencePercent(value: number): string {
  return `${Math.round(value * 100)}%`;
}

function countdownLabel(hours: number): string {
  return `${hours % 1 === 0 ? hours : hours.toFixed(1)} h left`;
}

/**
 * Match a query to the source document its drafted reply is grounded in.
 * References are parsed from the customer's own message, so the trigger
 * always opens the record the AI actually read.
 */
function sourceDocForQuery(
  query: CustomerQuery,
  allInvoices: Invoice[],
  deductionCases: DeductionCase[]
): { label: string; doc: SourceDoc } | null {
  const text = `${query.subject} ${query.body}`;
  const orderRef = text.match(/SO-\d+/)?.[0];
  const invoiceRef = text.match(/INV-\d+/)?.[0];
  const claimRef = text.match(/CLM-\d+/)?.[0];

  if (invoiceRef) {
    const invoice = allInvoices.find((i) => i.invoiceId === invoiceRef);
    if (invoice) {
      return {
        label: `View invoice ${invoiceRef}`,
        doc: buildInvoiceDoc(invoice),
      };
    }
  }
  if (claimRef) {
    const relatedCase = deductionCases.find(
      (d) =>
        d.sourceReference.includes(claimRef) ||
        d.evidence.some((e) => e.label.includes(claimRef))
    );
    if (relatedCase) {
      return { label: "View claim file", doc: buildClaimDoc(relatedCase) };
    }
  }
  if (query.scope === "Shipment tracking" && orderRef) {
    const shipment = shipments.find((s) => s.orderId === orderRef);
    if (shipment) {
      return { label: "View delivery record", doc: buildPodDoc(shipment) };
    }
  }
  if (query.scope === "Order status" && orderRef) {
    const order = orders.find((o) => o.orderId === orderRef);
    if (order) {
      return { label: "View sales order", doc: buildSalesOrderDoc(order) };
    }
  }
  if (query.scope === "Pricing query") {
    const contract = revRecContracts.find(
      (c) => c.customerId === query.customerId
    );
    if (contract) {
      return { label: "View contract summary", doc: buildContractDoc(contract) };
    }
  }
  if (query.scope === "Credit inquiry") {
    return {
      label: "View open balances",
      doc: buildAgingReportDoc(allInvoices),
    };
  }
  return null;
}

function StatusBadge({ status }: { status: CustomerQuery["status"] }) {
  if (status === "Sent") {
    return (
      <Badge className="bg-[var(--success)] text-white text-xs whitespace-nowrap">
        Sent
      </Badge>
    );
  }
  if (status === "Draft ready") {
    return (
      <Badge
        variant="outline"
        className="text-primary border-primary/30 text-xs whitespace-nowrap"
      >
        Draft ready
      </Badge>
    );
  }
  return (
    <Badge variant="outline" className="text-xs whitespace-nowrap">
      New
    </Badge>
  );
}

export function QueryHub() {
  const {
    queries,
    allInvoices,
    deductionCases,
    sendQueryReply,
    runReturnStage,
    runOrderId,
    requestReturn,
  } = useOtcStore();
  const [selectedId, setSelectedId] = useState(queries[0]?.queryId ?? "");

  // During a guided run at the Customer Service Hub, the run order's question
  // sits at the top of the incoming list to be approved in place, then return.
  const runInvoice =
    runReturnStage === "service_hub"
      ? allInvoices.find((i) => i.orderId === runOrderId)
      : undefined;
  const [isEditing, setIsEditing] = useState(false);
  const [editedDrafts, setEditedDrafts] = useState<Record<string, string>>({});

  const selected = queries.find((q) => q.queryId === selectedId) ?? queries[0];

  const openCount = queries.filter((q) => q.status !== "Sent").length;
  const answeredToday = queries.filter((q) => q.status === "Sent").length;
  const scopes = useMemo(
    () => Array.from(new Set(queries.map((q) => q.scope))),
    [queries]
  );

  const selectedDoc = selected
    ? sourceDocForQuery(selected, allInvoices, deductionCases)
    : null;
  const draftText = selected
    ? (editedDrafts[selected.queryId] ?? selected.draftReply)
    : "";

  const handleSelect = (queryId: string) => {
    setSelectedId(queryId);
    setIsEditing(false);
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-4">
        <Card className="bg-card shadow-sm h-full">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/10">
              <Inbox className="h-5 w-5 text-primary" />
            </div>
            <div>
              <div className="text-2xl font-bold text-foreground">
                {openCount}
              </div>
              <div className="text-xs text-muted-foreground">Open queries</div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card shadow-sm h-full">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-[var(--success)]/10">
              <CircleCheck className="h-5 w-5 text-[var(--success)]" />
            </div>
            <div>
              <div className="text-2xl font-bold text-foreground">
                {answeredToday}
              </div>
              <div className="text-xs text-muted-foreground">
                Answered today
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card shadow-sm h-full">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-[var(--info)]/10">
              <Timer className="h-5 w-5 text-[var(--info)]" />
            </div>
            <div>
              <div className="text-2xl font-bold text-foreground">
                {onTimeResponseRatePercent}%
              </div>
              <div className="text-xs text-muted-foreground">
                On-time responses this month
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex flex-wrap items-center gap-1.5">
        <span className="text-xs text-muted-foreground mr-1">
          Raised in ServiceNow. The AI sorts every question into one of these topics:
        </span>
        {scopes.map((scope) => (
          <Badge key={scope} variant="outline" className="text-xs">
            {scope}
          </Badge>
        ))}
      </div>

      <div className="grid lg:grid-cols-5 gap-4">
        <Card className="lg:col-span-2 flex flex-col overflow-hidden">
          <div className="px-4 py-3 border-b bg-muted/20">
            <span className="text-sm font-semibold">Incoming queries</span>
          </div>
          <div className="flex-1 overflow-y-auto p-3 space-y-2">
            {runInvoice && (
              <button
                onClick={requestReturn}
                className="w-full text-left rounded-lg border border-primary/40 bg-primary/5 p-3 ring-1 ring-primary/20 transition-all"
              >
                <div className="flex items-start justify-between gap-2">
                  <span className="text-sm font-medium leading-snug">
                    Invoice question for {runOrderId}
                  </span>
                  <Badge
                    variant="outline"
                    className="text-primary border-primary/30 text-xs whitespace-nowrap gap-1"
                  >
                    <Sparkles className="h-3 w-3" />
                    Guided run
                  </Badge>
                </div>
                <div className="text-xs text-muted-foreground mt-1">
                  {runInvoice.customerName} · Owner: Billing Team
                </div>
                <div className="flex flex-wrap items-center gap-1.5 mt-2">
                  <Badge variant="outline" className="text-xs gap-1">
                    <MessageSquare className="h-3 w-3" />
                    Portal
                  </Badge>
                  <Badge
                    variant="outline"
                    className="text-xs text-primary border-primary/30"
                  >
                    Billing query — 97% confident
                  </Badge>
                  <span className="ml-auto inline-flex items-center gap-1 text-xs font-medium text-primary whitespace-nowrap">
                    <Send className="h-3 w-3" />
                    Approve reply &amp; return
                  </span>
                </div>
              </button>
            )}
            {queries.map((query) => {
              const ChannelIcon = CHANNEL_ICONS[query.channel];
              const isSelected = selected?.queryId === query.queryId;
              const urgent =
                query.status !== "Sent" && query.hoursRemaining < 2;
              return (
                <button
                  key={query.queryId}
                  onClick={() => handleSelect(query.queryId)}
                  className={cn(
                    "w-full text-left rounded-lg border p-3 transition-all",
                    isSelected
                      ? "bg-primary/5 ring-1 ring-primary/20 border-primary/30"
                      : "hover:bg-muted/50"
                  )}
                >
                  <div className="flex items-start justify-between gap-2">
                    <span className="text-sm font-medium leading-snug">
                      {query.subject}
                    </span>
                    <StatusBadge status={query.status} />
                  </div>
                  <div className="text-xs text-muted-foreground mt-1">
                    {query.customerName} · Owner: {query.owner}
                  </div>
                  <div className="flex flex-wrap items-center gap-1.5 mt-2">
                    <Badge variant="outline" className="text-xs gap-1">
                      <ChannelIcon className="h-3 w-3" />
                      {query.channel}
                    </Badge>
                    <Badge
                      variant="outline"
                      className="text-xs text-primary border-primary/30"
                    >
                      {query.scope} —{" "}
                      {confidencePercent(query.scopeConfidence)} confident
                    </Badge>
                    <span
                      className={cn(
                        "ml-auto flex items-center gap-1 text-xs whitespace-nowrap",
                        urgent
                          ? "text-[var(--warning)] font-medium"
                          : "text-muted-foreground"
                      )}
                    >
                      <Clock className="h-3 w-3" />
                      {countdownLabel(query.hoursRemaining)}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </Card>

        <Card className="lg:col-span-3 flex flex-col overflow-hidden">
          {selected ? (
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="text-base font-semibold">
                    {selected.subject}
                  </h3>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {selected.queryId} · {selected.customerName} · Received via{" "}
                    {selected.channel.toLowerCase()} on {selected.receivedAt}
                  </p>
                </div>
                <StatusBadge status={selected.status} />
              </div>

              <div className="rounded-lg bg-muted/50 p-3">
                <div className="text-xs font-medium text-muted-foreground mb-1">
                  Customer&apos;s message
                </div>
                <p className="text-sm text-foreground">{selected.body}</p>
              </div>

              <div className="rounded-lg border bg-card shadow-sm p-3 space-y-2">
                <div className="flex items-center gap-2">
                  <AgentIcon
                    type="orchestrator"
                    size="sm"
                    className="text-primary"
                  />
                  <span className="text-sm font-semibold">
                    How the AI read this question
                  </span>
                  <Badge
                    variant="outline"
                    className="text-primary border-primary/30 text-xs gap-1"
                  >
                    <Sparkles className="h-3 w-3" />
                    {confidencePercent(selected.scopeConfidence)} confident
                  </Badge>
                </div>
                <div className="grid sm:grid-cols-3 gap-3">
                  <div>
                    <div className="text-xs text-muted-foreground">
                      Question type
                    </div>
                    <div className="text-sm font-medium">{selected.scope}</div>
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground">
                      Routed to
                    </div>
                    <div className="text-sm font-medium">{selected.owner}</div>
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground">
                      Response target
                    </div>
                    <div className="text-sm font-medium">
                      Reply within {selected.responseTargetHours} hours
                    </div>
                  </div>
                </div>
                {selectedDoc && (
                  <SourceDocTrigger
                    doc={selectedDoc.doc}
                    label={selectedDoc.label}
                  />
                )}
              </div>

              <div className="rounded-lg border border-primary/20 p-3 space-y-2">
                <div className="text-xs font-medium text-muted-foreground">
                  {selected.status === "Sent"
                    ? "Reply sent to the customer"
                    : "AI-drafted reply — waiting for your approval"}
                </div>
                {isEditing && selected.status !== "Sent" ? (
                  <Textarea
                    value={draftText}
                    onChange={(e) =>
                      setEditedDrafts((prev) => ({
                        ...prev,
                        [selected.queryId]: e.target.value,
                      }))
                    }
                    className="min-h-[110px] text-sm"
                  />
                ) : (
                  <p className="text-sm text-foreground whitespace-pre-wrap">
                    {draftText}
                  </p>
                )}
              </div>

              {selected.status === "Sent" ? (
                <div className="flex items-center gap-2 text-sm text-[var(--success)]">
                  <CircleCheck className="h-4 w-4" />
                  Reply sent — the customer has been answered and the queue
                  updated.
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Button
                    className="whitespace-nowrap"
                    onClick={() => {
                      setIsEditing(false);
                      sendQueryReply(selected.queryId);
                    }}
                  >
                    <Send className="h-4 w-4 mr-2" />
                    Approve &amp; send reply
                  </Button>
                  <Button
                    variant="outline"
                    className="whitespace-nowrap"
                    onClick={() => setIsEditing((prev) => !prev)}
                  >
                    <SquarePen className="h-4 w-4 mr-2" />
                    {isEditing ? "Done editing" : "Edit draft"}
                  </Button>
                </div>
              )}
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center text-sm text-muted-foreground p-6">
              Select a query on the left to review it.
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
