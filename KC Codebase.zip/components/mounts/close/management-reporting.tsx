"use client";

import { useEffect, useState } from "react";
import { ArrowDownRight, TrendingUp, Wallet } from "lucide-react";

import { CountUp } from "@/components/ui/count-up";
import { formatMoney } from "@/lib/selectors";

/**
 * The two management-reporting figures the close publishes beyond DSO and cash
 * forecast (be-creative): a Collection Effectiveness ring — how much of what
 * was collectible actually came in — and a working-capital insight that turns
 * the DSO improvement into freed cash. Both animate on mount.
 */
export function ManagementReporting({
  cei,
  dso,
  dsoDelta,
  openAR,
}: {
  cei: number;
  dso: number;
  dsoDelta: number;
  openAR: number;
}) {
  const dailySales = openAR / dso;
  // Rounded to the nearest thousand — it's an "about" figure, not a ledger entry.
  const freedCash = Math.round((dailySales * Math.abs(dsoDelta)) / 1000) * 1000;

  // Ring geometry.
  const r = 34;
  const circumference = 2 * Math.PI * r;
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    const reduce =
      typeof window !== "undefined" &&
      window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    const id = setTimeout(() => setProgress(reduce ? cei : cei), 80);
    return () => clearTimeout(id);
  }, [cei]);
  const offset = circumference * (1 - progress / 100);

  return (
    <div className="mt-2 grid gap-3 sm:grid-cols-2">
      {/* Collection Effectiveness ring */}
      <div className="animate-enter flex items-center gap-4 rounded-lg border bg-card p-4">
        <div className="relative h-24 w-24 shrink-0">
          <svg className="h-24 w-24 -rotate-90" viewBox="0 0 80 80">
            <circle
              cx="40"
              cy="40"
              r={r}
              fill="none"
              stroke="var(--muted)"
              strokeWidth="7"
            />
            <circle
              cx="40"
              cy="40"
              r={r}
              fill="none"
              stroke="var(--success)"
              strokeWidth="7"
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={offset}
              style={{ transition: "stroke-dashoffset 1s ease-out" }}
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <CountUp
              value={cei}
              durationMs={1000}
              decimals={1}
              format={(n) => `${n.toFixed(1)}%`}
              className="text-lg font-bold text-foreground"
            />
          </div>
        </div>
        <div className="min-w-0">
          <div className="flex items-center gap-1.5 text-sm font-semibold text-foreground">
            <TrendingUp className="h-4 w-4 text-[var(--success)]" />
            Collection effectiveness
          </div>
          <p className="mt-1 text-xs text-muted-foreground">
            Of everything that was collectible this period, this share was
            actually collected.
          </p>
        </div>
      </div>

      {/* Working-capital insight */}
      <div className="animate-enter flex flex-col gap-3 rounded-lg border bg-card p-4">
        <div className="flex items-center gap-1.5 text-sm font-semibold text-foreground">
          <Wallet className="h-4 w-4 text-primary" />
          Working capital
        </div>
        <div className="flex items-end justify-between gap-3">
          <div>
            <div className="text-xs text-muted-foreground">
              Tied up in receivables
            </div>
            <CountUp
              value={openAR}
              durationMs={900}
              format={(n) => formatMoney(Math.round(n))}
              className="text-xl font-bold text-foreground"
            />
          </div>
          <div className="text-right">
            <div className="text-xs text-muted-foreground">
              Days sales outstanding
            </div>
            <div className="flex items-center justify-end gap-1.5">
              <span className="text-xl font-bold text-foreground">{dso}</span>
              <span className="inline-flex items-center gap-0.5 rounded bg-[var(--success)]/10 px-1.5 py-0.5 text-xs font-medium text-[var(--success)]">
                <ArrowDownRight className="h-3 w-3" />
                {Math.abs(dsoDelta)} days
              </span>
            </div>
          </div>
        </div>
        <div className="rounded-md bg-[var(--success)]/5 px-3 py-2 text-xs text-muted-foreground">
          A {Math.abs(dsoDelta)}-day drop in days sales outstanding freed about{" "}
          <span className="font-semibold text-foreground">
            {formatMoney(freedCash)}
          </span>{" "}
          of cash this month.
        </div>
      </div>
    </div>
  );
}
