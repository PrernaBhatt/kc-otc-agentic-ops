"use client";

import { useState, type ReactNode } from "react";
import { ArrowRight, CalendarCheck, ChevronDown } from "lucide-react";

import type { ViewId } from "@/components/layout/sidebar";
import {
  SourceDocTrigger,
  type SourceDoc,
} from "@/components/modals/source-doc-preview";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ManagementReporting } from "@/components/mounts/close/management-reporting";
import { kpis, orders, shipments } from "@/lib/data";
import {
  buildAgingReportDoc,
  buildProvisionDoc,
  buildRevRecScheduleDoc,
} from "@/lib/docs";
import {
  cashForecast30d,
  formatMoney,
  openDeductions,
  openReceivablesTotal,
  shippedNotInvoiced,
  unappliedCashTotal,
} from "@/lib/selectors";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

type TaskStatus = "done" | "attention";

interface CloseTask {
  id: number;
  title: string;
  status: TaskStatus;
  detail: string;
  goTo: { view: ViewId; label: string };
  docTrigger?: ReactNode;
  extra?: ReactNode;
}

/**
 * Period-end close checklist. Every status below is DERIVED from the store
 * and selectors, so approving a payment match, resolving a deduction,
 * approving the provision, or generating an invoice elsewhere in the app
 * flips the matching row live.
 */
export function CloseChecklist({
  onNavigate,
  defaultExpanded = true,
}: {
  onNavigate: (view: ViewId, orderId?: string) => void;
  defaultExpanded?: boolean;
}) {
  const store = useOtcStore();
  const [expanded, setExpanded] = useState(defaultExpanded);
  const [expandedTaskId, setExpandedTaskId] = useState<number | null>(null);

  // Task 1 — billing completeness: every delivered order has an invoice.
  const deliveredOrderIds = new Set(
    shipments.filter((s) => s.status === "Delivered").map((s) => s.orderId)
  );
  const awaitingInvoice = shippedNotInvoiced(
    orders,
    store.allInvoices,
    store.billedOrderIds,
    deliveredOrderIds
  );
  const billingDone = awaitingInvoice.length === 0;

  // Task 2 — cash application: unapplied receipts. The payment with no
  // invoice reference cannot be matched yet, so once it is the only one
  // left the task counts as on track.
  const unappliedReceipts = store.receipts.filter(
    (r) => r.status !== "Applied"
  );
  const unappliedAmount = unappliedCashTotal(store.receipts);
  const onlyUnidentifiedLeft =
    unappliedReceipts.length > 0 &&
    unappliedReceipts.every((r) => r.matchType === "No match yet");
  const cashDone = unappliedReceipts.length === 0 || onlyUnidentifiedLeft;

  // Task 3 — subledger vs general ledger (always in balance in this demo).
  const subledgerTotal = openReceivablesTotal(store.allInvoices);

  // Task 4 — open deduction and dispute cases.
  const openCases = openDeductions(store.deductionCases);
  const deductionsDone = openCases.length === 0;

  // Task 5 — bad debt reserve approval.
  const provisionDone = store.provisionStatus === "Approved";

  // Task 6 — revenue cut-off: deliveries still owed near month end.
  const deferredDeliveries = store.obligations.filter(
    (o) => o.status === "Deferred" && o.trigger === "On delivery"
  );

  // Task 7 — locked only when the open items above are cleared.
  const readyToLock = billingDone && cashDone && deductionsDone && provisionDone;

  // Task 8 — management reporting figures (same sources as the KPI tiles).
  const expectedCash = cashForecast30d(store.allInvoices, store.ptps);

  const tasks: CloseTask[] = [
    {
      id: 1,
      title: "Everything delivered is invoiced",
      status: billingDone ? "done" : "attention",
      detail: billingDone
        ? "All delivered orders invoiced"
        : `${awaitingInvoice.length} delivered order${
            awaitingInvoice.length === 1 ? "" : "s"
          } awaiting invoice — generate it in Billing`,
      goTo: { view: "billing", label: "Go to Billing" },
    },
    {
      id: 2,
      title: "Cash received is applied",
      status: cashDone ? "done" : "attention",
      detail:
        unappliedReceipts.length === 0
          ? "All payments applied — no unapplied cash"
          : onlyUnidentifiedLeft
            ? "In progress — one payment awaiting customer details"
            : `${formatMoney(
                unappliedAmount
              )} received but not yet applied — approve the proposed matches`,
      goTo: { view: "transactions", label: "Go to Cash Application" },
    },
    {
      id: 3,
      title: "Receivables ledger matches the general ledger",
      status: "done",
      detail: `Balances match at ${formatMoney(
        subledgerTotal
      )} — no difference to investigate`,
      goTo: { view: "transactions", label: "Go to Transactions" },
      docTrigger: (
        <SourceDocTrigger
          doc={buildAgingReportDoc(store.allInvoices)}
          label="View aging report"
        />
      ),
    },
    {
      id: 4,
      title: "Deductions and disputes reviewed",
      status: deductionsDone ? "done" : "attention",
      detail: deductionsDone
        ? "All deduction and dispute cases resolved"
        : `${openCases.length} open case${
            openCases.length === 1 ? "" : "s"
          } to review — decide each one in Exceptions`,
      goTo: { view: "exceptions", label: "Go to Exceptions" },
    },
    {
      id: 5,
      title: "Bad debt reserve finalized",
      status: provisionDone ? "done" : "attention",
      detail: provisionDone
        ? `Approved by ${store.provisionApprover}, Controller`
        : `Awaiting approval from ${store.provisionApprover}, Controller`,
      goTo: { view: "collections", label: "Go to Collections" },
      docTrigger: (
        <SourceDocTrigger
          doc={buildProvisionDoc(store.allInvoices)}
          label="View calculation"
        />
      ),
    },
    {
      id: 6,
      title: "Revenue cut-off confirmed",
      status: "done",
      detail: `${deferredDeliveries.length} delivery near month end — reviewed in Billing`,
      goTo: { view: "billing", label: "Go to Billing" },
      docTrigger: (
        <SourceDocTrigger
          doc={buildRevRecScheduleDoc(store.obligations)}
          label="View schedule"
        />
      ),
    },
    {
      id: 7,
      title: "Approvals complete and books locked",
      status: readyToLock ? "done" : "attention",
      detail: readyToLock
        ? "All approvals in place — books ready to lock"
        : "Waiting on open items above",
      goTo: { view: "exceptions", label: "Go to Exceptions" },
    },
    {
      id: 8,
      title: "Management reporting published",
      status: "done",
      detail: `Days sales outstanding ${kpis.dsoValue} days · Collection effectiveness ${
        kpis.collectionEffectiveness
      }% · ${formatMoney(expectedCash)} expected in the next 30 days`,
      goTo: { view: "collections", label: "Go to Collections" },
      extra: (
        <ManagementReporting
          cei={kpis.collectionEffectiveness}
          dso={kpis.dsoValue}
          dsoDelta={kpis.dsoDelta}
          openAR={subledgerTotal}
        />
      ),
    },
  ];

  const readyCount = tasks.filter((t) => t.status === "done").length;

  return (
    <Card className="bg-card shadow-sm">
      <CardHeader className="pb-2">
        <button
          className="w-full flex items-center justify-between gap-2 text-left"
          onClick={() => setExpanded((prev) => !prev)}
        >
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <CalendarCheck className="h-4 w-4 text-primary" />
            Period-End Close — July · reconciled in K-Recon / Cadency
            <Badge variant="outline" className="gap-1 text-xs font-normal">
              {readyCount}/{tasks.length} ready
            </Badge>
          </CardTitle>
          <ChevronDown
            className={cn(
              "h-4 w-4 text-muted-foreground transition-transform",
              expanded && "rotate-180"
            )}
          />
        </button>
      </CardHeader>
      {expanded && (
        <CardContent className="space-y-2">
          {tasks.map((task) => {
            const taskOpen = expandedTaskId === task.id;
            return (
              <div key={task.id} className="rounded-lg border">
                <div
                  role="button"
                  tabIndex={0}
                  className="w-full flex items-center gap-3 p-3 text-left cursor-pointer"
                  onClick={() =>
                    setExpandedTaskId((prev) =>
                      prev === task.id ? null : task.id
                    )
                  }
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") {
                      e.preventDefault();
                      setExpandedTaskId((prev) =>
                        prev === task.id ? null : task.id
                      );
                    }
                  }}
                >
                  <span
                    className={cn(
                      "h-2.5 w-2.5 rounded-full shrink-0",
                      task.status === "done"
                        ? "bg-[var(--success)]"
                        : "bg-[var(--warning)]"
                    )}
                  />
                  <span className="flex-1 min-w-0 text-sm font-medium text-foreground truncate">
                    {task.title}
                  </span>
                  <span className="flex items-center gap-2 shrink-0">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="whitespace-nowrap text-primary"
                      onClick={(e) => {
                        e.stopPropagation();
                        onNavigate(task.goTo.view);
                      }}
                    >
                      {task.goTo.label}
                      <ArrowRight className="h-4 w-4 ml-1" />
                    </Button>
                    <ChevronDown
                      className={cn(
                        "h-4 w-4 text-muted-foreground transition-transform",
                        taskOpen && "rotate-180"
                      )}
                    />
                  </span>
                </div>
                {taskOpen && (
                  <div className="px-3 pb-3 pl-9 bg-muted/30 rounded-b-lg pt-2">
                    <div
                      className={cn(
                        "text-sm",
                        task.status === "attention"
                          ? "text-[var(--warning)]"
                          : "text-muted-foreground"
                      )}
                    >
                      {task.detail}
                    </div>
                    {task.docTrigger && (
                      <div className="mt-2">{task.docTrigger}</div>
                    )}
                    {task.extra}
                  </div>
                )}
              </div>
            );
          })}
        </CardContent>
      )}
    </Card>
  );
}
