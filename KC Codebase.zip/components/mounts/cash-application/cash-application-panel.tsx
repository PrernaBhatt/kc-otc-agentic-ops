"use client";

import { useState } from "react";
import {
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Landmark,
  Percent,
  Search,
  Wallet,
} from "lucide-react";

import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AUTO_MATCH_CONFIDENCE_THRESHOLD,
  type BankReceipt,
} from "@/lib/data/receipts";
import { TODAY } from "@/lib/data/clock";
import { buildBankStatementDoc, buildRemittanceDoc } from "@/lib/docs";
import { formatMoney, unappliedCashTotal } from "@/lib/selectors";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

function receiptStatusBadgeClass(status: BankReceipt["status"]) {
  switch (status) {
    case "Applied":
      return "bg-[var(--success)] text-white";
    case "Match Proposed":
      return "bg-[var(--info)] text-white";
    case "Unidentified":
      return "bg-[var(--warning)] text-[var(--warning-foreground)]";
    default:
      return "bg-muted text-muted-foreground";
  }
}

function ConfidenceBadge({ confidence }: { confidence: number }) {
  const high = confidence >= AUTO_MATCH_CONFIDENCE_THRESHOLD;
  return (
    <Badge
      variant="outline"
      className={cn(
        "whitespace-nowrap",
        high
          ? "border-[var(--success)]/40 text-[var(--success)] bg-[var(--success)]/10"
          : "border-[var(--warning)]/50 text-[var(--warning-foreground)] bg-[var(--warning)]/10"
      )}
    >
      {Math.round(confidence * 100)}% confidence
    </Badge>
  );
}

/** One-line AI proposal summary shown in the table row. */
function proposalSummary(receipt: BankReceipt): string {
  if (!receipt.proposedInvoiceId) {
    return "No match yet";
  }
  return receipt.status === "Applied"
    ? `Applied to ${receipt.proposedInvoiceId}`
    : `AI recommends ${receipt.proposedInvoiceId}`;
}

/** Human-in-the-loop choices for a payment with no invoice reference. */
function UnidentifiedActions() {
  const [decision, setDecision] = useState<"none" | "contacted" | "queued">(
    "none"
  );
  if (decision === "contacted") {
    return (
      <Badge className="bg-[var(--info)]/10 text-[var(--info)] border-[var(--info)]/30 whitespace-nowrap">
        Customer contacted — reply expected in 1 day
      </Badge>
    );
  }
  if (decision === "queued") {
    return (
      <Badge className="bg-muted text-muted-foreground whitespace-nowrap">
        Kept in exception queue
      </Badge>
    );
  }
  return (
    <div className="flex items-center gap-2">
      <Button
        variant="outline"
        size="sm"
        className="whitespace-nowrap"
        onClick={() => setDecision("contacted")}
      >
        Ask customer for details
      </Button>
      <Button
        variant="ghost"
        size="sm"
        className="whitespace-nowrap"
        onClick={() => setDecision("queued")}
      >
        Keep in exception queue
      </Button>
    </div>
  );
}

/** Expanded detail block under a receipt row — opens/closes on row click. */
function ReceiptDetail({ receipt }: { receipt: BankReceipt }) {
  return (
    <div className="flex flex-wrap items-center gap-x-6 gap-y-3 py-1">
      <div className="flex items-center gap-2">
        <span className="text-sm text-muted-foreground">Match type</span>
        <span className="text-sm font-medium">{receipt.matchType}</span>
        {receipt.matchConfidence !== undefined && (
          <ConfidenceBadge confidence={receipt.matchConfidence} />
        )}
      </div>
      {receipt.remittanceNote && (
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Customer note</span>
          <span className="text-sm font-medium">{receipt.remittanceNote}</span>
        </div>
      )}
      {receipt.shortPayAmount !== undefined &&
        receipt.deductionId !== undefined && (
          <Badge className="bg-amber-100 text-amber-800 border-amber-300 whitespace-nowrap">
            {receipt.status === "Applied"
              ? `Remaining ${formatMoney(receipt.shortPayAmount)} tracked as deduction case ${receipt.deductionId}`
              : `Short paid ${formatMoney(receipt.shortPayAmount)} — deduction case ${receipt.deductionId}`}
          </Badge>
        )}
      <div className="flex items-center gap-2">
        <SourceDocTrigger
          doc={buildRemittanceDoc(receipt)}
          label="View remittance"
        />
        {receipt.status === "Unidentified" && <UnidentifiedActions />}
      </div>
    </div>
  );
}

export function CashApplicationPanel() {
  const {
    receipts,
    applyReceipt,
    runReturnStage,
    runOrderId,
    allInvoices,
    requestReturn,
  } = useOtcStore();
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedId, setExpandedId] = useState<string | null>(null);

  // During a guided run at Cash Application, the run order's payment appears as
  // the top row of the table so it can be applied in place, then return.
  const runInvoice =
    runReturnStage === "cash_application"
      ? allInvoices.find((i) => i.orderId === runOrderId)
      : undefined;

  const receivedTotal = receipts.reduce((sum, r) => sum + r.amount, 0);
  const stillToApply = unappliedCashTotal(receipts);
  const appliedTotal = receipts
    .filter((r) => r.status === "Applied")
    .reduce((sum, r) => sum + r.amount, 0);
  const autoMatchRate =
    receipts.length > 0
      ? Math.round(
          (receipts.filter(
            (r) => (r.matchConfidence ?? 0) >= AUTO_MATCH_CONFIDENCE_THRESHOLD
          ).length /
            receipts.length) *
            100
        )
      : 0;

  const query = searchQuery.trim().toLowerCase();
  const visibleReceipts = query
    ? receipts.filter((r) =>
        [
          r.receiptId,
          r.payerName,
          r.remittanceReference ?? "",
          r.proposedInvoiceId ?? "",
          String(r.amount),
          r.status,
        ]
          .join(" ")
          .toLowerCase()
          .includes(query)
      )
    : receipts;

  const toggleRow = (receiptId: string) =>
    setExpandedId((prev) => (prev === receiptId ? null : receiptId));

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-3 gap-4">
        <Card className="bg-card flex h-full flex-col">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-[var(--info)]/10">
                <Landmark className="h-4 w-4 text-[var(--info)]" />
              </div>
              <div>
                <div className="text-2xl font-bold">
                  {formatMoney(receivedTotal)}
                </div>
                <div className="text-xs text-muted-foreground">
                  Received today
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card flex h-full flex-col">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-[var(--warning)]/10">
                <Wallet className="h-4 w-4 text-[var(--warning)]" />
              </div>
              <div>
                <div className="text-2xl font-bold">
                  {formatMoney(stillToApply)}
                </div>
                <div className="text-xs text-muted-foreground">
                  Still to apply
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card flex h-full flex-col">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-[var(--success)]/10">
                <Percent className="h-4 w-4 text-[var(--success)]" />
              </div>
              <div>
                <div className="text-2xl font-bold">{autoMatchRate}%</div>
                <div className="text-xs text-muted-foreground">
                  Auto-match rate in IREC / HighRadius
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent>
          <div className="flex gap-4 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search receipts..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <SourceDocTrigger
              doc={buildBankStatementDoc(receipts)}
              label="View bank statement file"
              size="default"
            />
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Payer</TableHead>
                <TableHead>Reference</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>AI Match Proposal</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {runInvoice && (
                <TableRow className="bg-primary/5 hover:bg-primary/5">
                  <TableCell>{TODAY}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {runInvoice.customerName}
                      <Badge
                        variant="outline"
                        className="border-primary/40 text-primary text-xs whitespace-nowrap"
                      >
                        Guided run
                      </Badge>
                    </div>
                  </TableCell>
                  <TableCell className="font-mono">
                    {runInvoice.invoiceId}
                  </TableCell>
                  <TableCell className="font-medium">
                    {formatMoney(runInvoice.amount)}
                  </TableCell>
                  <TableCell className="text-sm">
                    AI recommends {runInvoice.invoiceId} · exact match, 98%
                  </TableCell>
                  <TableCell>
                    <Badge className="bg-[var(--info)] text-white">
                      Match Proposed
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      size="sm"
                      className="whitespace-nowrap"
                      onClick={requestReturn}
                    >
                      <Check className="h-4 w-4 mr-1" />
                      Apply match
                    </Button>
                  </TableCell>
                </TableRow>
              )}
              {visibleReceipts.map((receipt) => {
                const expanded = expandedId === receipt.receiptId;
                return [
                  <TableRow
                    key={receipt.receiptId}
                    className="cursor-pointer"
                    onClick={() => toggleRow(receipt.receiptId)}
                  >
                    <TableCell>{receipt.receivedDate}</TableCell>
                    <TableCell>{receipt.payerName}</TableCell>
                    <TableCell
                      className={cn(
                        receipt.remittanceReference
                          ? "font-mono"
                          : "text-muted-foreground"
                      )}
                    >
                      {receipt.remittanceReference ?? "No invoice reference"}
                    </TableCell>
                    <TableCell className="font-medium">
                      {formatMoney(receipt.amount)}
                    </TableCell>
                    <TableCell className="text-sm">
                      {proposalSummary(receipt)}
                    </TableCell>
                    <TableCell>
                      <Badge
                        className={receiptStatusBadgeClass(receipt.status)}
                      >
                        {receipt.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        {receipt.status === "Match Proposed" && (
                          <Button
                            variant="outline"
                            size="sm"
                            className="whitespace-nowrap"
                            onClick={(e) => {
                              e.stopPropagation();
                              applyReceipt(receipt.receiptId);
                            }}
                          >
                            <Check className="h-4 w-4 mr-1" />
                            Apply match
                          </Button>
                        )}
                        {expanded ? (
                          <ChevronUp className="h-4 w-4 text-muted-foreground shrink-0" />
                        ) : (
                          <ChevronDown className="h-4 w-4 text-muted-foreground shrink-0" />
                        )}
                      </div>
                    </TableCell>
                  </TableRow>,
                  expanded ? (
                    <TableRow
                      key={`${receipt.receiptId}-detail`}
                      className="bg-muted/30 hover:bg-muted/30"
                    >
                      <TableCell colSpan={7}>
                        <ReceiptDetail receipt={receipt} />
                      </TableCell>
                    </TableRow>
                  ) : null,
                ];
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="py-3">
          <div className="flex items-center gap-2 text-sm">
            <CheckCircle2 className="h-4 w-4 text-[var(--success)] shrink-0" />
            <span className="text-muted-foreground">
              Bank statement total{" "}
              <span className="font-medium text-foreground">
                {formatMoney(receivedTotal)}
              </span>{" "}
              = applied{" "}
              <span className="font-medium text-foreground">
                {formatMoney(appliedTotal)}
              </span>{" "}
              + still to apply{" "}
              <span className="font-medium text-foreground">
                {formatMoney(stillToApply)}
              </span>
            </span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
