"use client";

import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { CheckCircle2, RotateCcw, Sparkles, X } from "lucide-react";

import { Button } from "@/components/ui/button";
import { CountUp } from "@/components/ui/count-up";
import type { DeductionCase } from "@/lib/data/deductions";
import { formatMoney } from "@/lib/selectors";

/**
 * Split-resolution dial (be-creative): the $8,200 claim is one bar, split into
 * the supported portion (credit memo, green) and the unsupported portion
 * (rebill to recover, amber). The AI anchors the split where the agreement
 * supports it; the human slides to adjust and confirms. The two amounts always
 * add back to the full claim — nothing is recorded until the human clicks.
 */
export function DeductionSplitModal({
  deduction,
  onConfirm,
  onClose,
}: {
  deduction: DeductionCase;
  onConfirm: (resolution: string) => void;
  onClose: () => void;
}) {
  const split = deduction.splitResolution!;
  const total = split.supportedAmount + split.unsupportedAmount;

  const [mounted, setMounted] = useState(false);
  const [grown, setGrown] = useState(false);
  const [rebill, setRebill] = useState(split.unsupportedAmount);

  useEffect(() => {
    setMounted(true);
    // Let the segments grow from the AI anchor on open.
    const id = setTimeout(() => setGrown(true), 60);
    return () => clearTimeout(id);
  }, []);
  if (!mounted) return null;

  const creditMemo = total - rebill;
  const rebillPct = (rebill / total) * 100;
  const atAnchor = rebill === split.unsupportedAmount;

  return createPortal(
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-6 text-left"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg rounded-xl border bg-card shadow-2xl animate-modal-in"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b px-5 py-3">
          <div>
            <div className="text-sm font-semibold">Split resolution</div>
            <div className="text-xs text-muted-foreground">
              {deduction.deductionId} · {deduction.customerName} ·{" "}
              {formatMoney(total)} claim
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div className="space-y-5 px-5 py-5">
          {/* AI anchor note */}
          <div className="flex items-start gap-2 rounded-lg border border-primary/20 bg-primary/5 p-3 text-sm">
            <Sparkles className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
            <span className="text-muted-foreground">
              AI recommends a{" "}
              <span className="font-medium text-foreground">
                {formatMoney(split.supportedAmount)}
              </span>{" "}
              credit memo ({split.supportedLabel.toLowerCase()}) and rebilling{" "}
              <span className="font-medium text-foreground">
                {formatMoney(split.unsupportedAmount)}
              </span>{" "}
              ({split.unsupportedLabel.toLowerCase()}).
            </span>
          </div>

          {/* The split bar */}
          <div>
            <div className="flex h-11 w-full overflow-hidden rounded-lg border">
              <div
                className="flex items-center justify-center bg-[var(--success)]/15 text-[var(--success)] transition-all duration-500 ease-out"
                style={{ width: `${grown ? 100 - rebillPct : 100}%` }}
              >
                <span className="px-2 text-xs font-semibold whitespace-nowrap">
                  Credit memo
                </span>
              </div>
              <div
                className="flex items-center justify-center bg-amber-400/20 text-amber-700 transition-all duration-500 ease-out"
                style={{ width: `${grown ? rebillPct : 0}%` }}
              >
                {rebillPct > 14 && (
                  <span className="px-2 text-xs font-semibold whitespace-nowrap">
                    Rebill
                  </span>
                )}
              </div>
            </div>

            {/* Slider to adjust the split */}
            <input
              type="range"
              min={0}
              max={total}
              step={100}
              value={rebill}
              onChange={(e) => setRebill(Number(e.target.value))}
              aria-label="Amount to rebill the customer"
              className="mt-3 w-full cursor-pointer accent-amber-500"
            />
            <div className="flex items-center justify-between text-[11px] text-muted-foreground">
              <span>Recover nothing</span>
              <button
                type="button"
                onClick={() => setRebill(split.unsupportedAmount)}
                className={`inline-flex items-center gap-1 rounded px-1.5 py-0.5 ${
                  atAnchor
                    ? "text-primary"
                    : "text-muted-foreground hover:text-primary"
                }`}
              >
                <RotateCcw className="h-3 w-3" />
                AI anchor {formatMoney(split.unsupportedAmount)}
              </button>
              <span>Recover all</span>
            </div>
          </div>

          {/* The two live amounts */}
          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-lg border border-[var(--success)]/30 bg-[var(--success)]/5 p-3">
              <div className="text-xs text-muted-foreground">
                Issue credit memo
              </div>
              <CountUp
                value={creditMemo}
                durationMs={400}
                format={(n) => formatMoney(Math.round(n))}
                className="text-xl font-bold text-[var(--success)]"
              />
              <div className="mt-0.5 text-[11px] text-muted-foreground">
                {split.supportedLabel}
              </div>
            </div>
            <div className="rounded-lg border border-amber-300 bg-amber-50 p-3">
              <div className="text-xs text-muted-foreground">
                Rebill the customer
              </div>
              <CountUp
                value={rebill}
                durationMs={400}
                format={(n) => formatMoney(Math.round(n))}
                className="text-xl font-bold text-amber-700"
              />
              <div className="mt-0.5 text-[11px] text-muted-foreground">
                {split.unsupportedLabel}
              </div>
            </div>
          </div>
        </div>

        {/* HITL footer */}
        <div className="flex items-center justify-between gap-3 border-t bg-muted/20 px-5 py-3">
          <span className="text-xs text-muted-foreground">
            Adds back to {formatMoney(total)} — your decision is recorded on
            confirm.
          </span>
          <Button
            onClick={() =>
              onConfirm(
                `Split — credit memo ${formatMoney(
                  creditMemo
                )}, rebill ${formatMoney(rebill)}`
              )
            }
            className="whitespace-nowrap"
          >
            <CheckCircle2 className="h-4 w-4" />
            Confirm split
          </Button>
        </div>
      </div>
    </div>,
    document.body
  );
}
