"use client";

import { ArrowRight, CircleCheck } from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  REGULATED_ORDER_ID,
  qualityHoldException,
} from "@/lib/data/regulatory";
import type { ExceptionRecord } from "@/lib/data/types";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

/**
 * Live Quality Hold exception record: Open while the regulated order
 * (SO-710262) is held, Resolved once its hold is released in Review Order
 * Hold — so counts and badges co-move with the store.
 */
export function useQualityHoldRecord(): ExceptionRecord {
  const { releasedRegulatoryOrders } = useOtcStore();
  return releasedRegulatoryOrders.has(REGULATED_ORDER_ID)
    ? { ...qualityHoldException, status: "Resolved" }
    : qualityHoldException;
}

/** Fifth exception type tile, mirroring the four existing type cards. */
export function QualityHoldTypeCard() {
  const { releasedRegulatoryOrders } = useOtcStore();
  const count = releasedRegulatoryOrders.has(REGULATED_ORDER_ID) ? 0 : 1;
  return (
    <Card className="bg-card">
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <div
            className={cn(
              "p-2 rounded-lg",
              count > 0 ? "bg-primary/10" : "bg-muted"
            )}
          >
            <AgentIcon
              type="validation"
              size="sm"
              className={count > 0 ? "text-destructive" : "text-muted-foreground"}
            />
          </div>
          <div>
            <div className="text-2xl font-bold">{count}</div>
            <div className="text-xs text-muted-foreground">Quality Hold</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

/**
 * Resolve affordance for the Quality Hold exception. The decision itself is
 * made on the Review Order Hold screen, so this routes the user there; once
 * the hold is released it shows the completed state instead.
 */
export function QualityHoldDetailAction({
  onDecide,
}: {
  onDecide: () => void;
}) {
  const { releasedRegulatoryOrders } = useOtcStore();
  const released = releasedRegulatoryOrders.has(REGULATED_ORDER_ID);
  if (released) {
    return (
      <div className="w-full flex items-center justify-center gap-2 py-2 rounded-md bg-[var(--success)]/10 text-[var(--success)] text-sm font-medium">
        <CircleCheck className="h-4 w-4" />
        Resolved in Review Order Hold
      </div>
    );
  }
  return (
    <Button className="w-full whitespace-nowrap" onClick={onDecide}>
      Decide in Review Order Hold
      <ArrowRight className="h-4 w-4 ml-2" />
    </Button>
  );
}
