"use client";

import { useState, type ReactNode } from "react";
import {
  ChevronDown,
  CircleCheck,
  FileText,
  ShieldCheck,
  Sparkles,
  TriangleAlert,
  User,
} from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DeductionSplitModal } from "@/components/mounts/exceptions/deduction-split-modal";
import type { DeductionCase } from "@/lib/data/deductions";
import type { Invoice } from "@/lib/data/types";
import { buildClaimDoc, buildInvoiceDoc } from "@/lib/docs";
import { formatMoney } from "@/lib/selectors";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

function validityBadgeClass(validity: DeductionCase["validity"]) {
  switch (validity) {
    case "Valid":
      return "border-[var(--success)]/50 text-[var(--success)] bg-[var(--success)]/10";
    case "Partially valid":
      return "border-[var(--info)]/50 text-[var(--info)] bg-[var(--info)]/10";
    case "Invalid":
      return "border-primary/50 text-primary bg-primary/10";
    case "Under review":
    default:
      return "border-[var(--warning)]/50 text-[var(--warning-foreground)] bg-[var(--warning)]/10";
  }
}

function statusBadgeClass(status: DeductionCase["status"]) {
  switch (status) {
    case "Resolved":
      return "bg-[var(--success)]/10 text-[var(--success)] border-[var(--success)]/20";
    case "In Progress":
      return "bg-[var(--warning)]/10 text-[var(--warning)] border-[var(--warning)]/20";
    case "Open":
    default:
      return "bg-primary/10 text-primary border-primary/20";
  }
}

/**
 * Prevent-recurrence note per reason code: the AI observes the root cause and
 * proposes an upstream fix — the fix itself remains a human call.
 */
function preventRecurrenceNote(reasonCode: DeductionCase["reasonCode"]) {
  switch (reasonCode) {
    case "Freight damage":
      return "AI flags this carrier lane for a packaging and handling review so damaged-delivery claims stop repeating.";
    case "Promotion allowance":
      return "AI suggests checking allowance claims against the promotion dates when they arrive, so out-of-window claims are caught before they become disputes.";
    case "Pricing":
      return "AI suggests refreshing contract price lists before invoicing so price differences are caught earlier.";
    case "Shortage":
      return "AI suggests a packing scan check before shipping so quantity shortages are caught at the warehouse.";
    case "Tax":
      return "AI suggests confirming customer tax certificates ahead of billing so tax deductions do not recur.";
    case "Compliance chargeback":
      return "AI suggests validating the customer's delivery requirements before shipping to avoid repeat chargebacks.";
    default:
      return "AI reviews resolved cases to propose fixes that stop the same deduction from recurring.";
  }
}

/** Plain-language reason the AI's read of a deduction carries the confidence it does. */
function confidenceReason(d: DeductionCase): string {
  const pct = Math.round(100 * d.reasonConfidence);
  if (d.validity === "Partially valid" && d.splitResolution) {
    return `${pct}% — the customer claims ${formatMoney(
      d.amount
    )}, but only ${formatMoney(
      d.splitResolution.supportedAmount
    )} is supported by the agreement and ${formatMoney(
      d.splitResolution.unsupportedAmount
    )} falls outside the window. Partly-valid, judgment-based claims read less cleanly than a fully documented one, so confidence sits lower.`;
  }
  if (d.reasonCode === "Freight damage") {
    return `${pct}% — the order and the invoice are both on file, so the AI can show the damage allowance was already applied once. It stays short of certainty because the customer may read their own claim differently, and that is a judgment call for a person.`;
  }
  return `${pct}% — how sure the AI is of its read of this claim's reason and root cause, from the documents it matched.`;
}

/** Lightweight hover tooltip (no dependency): dotted-underline trigger, dark bubble below. */
function InfoTip({ label, children }: { label: string; children: ReactNode }) {
  return (
    <span className="relative inline group cursor-help">
      {children}
      <span
        role="tooltip"
        className="pointer-events-none absolute left-1/2 top-full z-50 mt-1.5 w-60 -translate-x-1/2 rounded-md bg-foreground px-2.5 py-2 text-xs font-normal leading-snug text-background opacity-0 shadow-lg transition-opacity duration-150 group-hover:opacity-100"
      >
        {label}
      </span>
    </span>
  );
}

function DeductionCaseCard({
  deduction,
  invoice,
  onResolve,
}: {
  deduction: DeductionCase;
  invoice?: Invoice;
  onResolve: (deductionId: string, resolution: string) => void;
}) {
  const isResolved = deduction.status === "Resolved";
  const [expanded, setExpanded] = useState(false);
  const [splitOpen, setSplitOpen] = useState(false);

  const handleOption = (option: string) => {
    if (option === "Rebill the customer" && deduction.splitResolution) {
      setSplitOpen(true);
      return;
    }
    onResolve(deduction.deductionId, option);
  };
  return (
    <Card
      className={cn(
        "flex h-full flex-col",
        isResolved && "border-[var(--success)]/40 bg-[var(--success)]/5"
      )}
    >
      <CardHeader className="pb-0">
        <button
          type="button"
          onClick={() => setExpanded((prev) => !prev)}
          className="w-full flex items-center gap-3 text-left cursor-pointer"
        >
          <CardTitle className="text-base font-semibold shrink-0">
            {deduction.deductionId}
          </CardTitle>
          <Badge variant="outline" className={statusBadgeClass(deduction.status)}>
            {deduction.status}
          </Badge>
          <span className="text-sm text-muted-foreground truncate flex-1 min-w-0">
            {deduction.customerName} · against {deduction.invoiceId}
          </span>
          <Badge
            variant="outline"
            className="whitespace-nowrap border-primary/40 text-primary bg-primary/5"
          >
            <Sparkles className="h-3 w-3 mr-1" />
            {deduction.reasonCode}
          </Badge>
          <span className="text-base font-bold text-foreground shrink-0">
            {formatMoney(deduction.amount)}
          </span>
          <ChevronDown
            className={cn(
              "h-4 w-4 text-muted-foreground shrink-0 transition-transform",
              expanded && "rotate-180"
            )}
          />
        </button>
      </CardHeader>
      {expanded && (
        <CardContent className="pt-4">
          <div className="grid gap-6 md:grid-cols-2">
            {/* Left: what the AI found */}
            <div className="space-y-4">
              <div className="flex flex-wrap gap-2">
                <InfoTip label={confidenceReason(deduction)}>
                  <Badge
                    variant="outline"
                    className="whitespace-nowrap border-primary/40 text-primary bg-primary/5 decoration-dotted underline-offset-2 [text-decoration-line:underline]"
                  >
                    <Sparkles className="h-3 w-3 mr-1" />
                    {Math.round(100 * deduction.reasonConfidence)}% confident
                  </Badge>
                </InfoTip>
                <Badge
                  variant="outline"
                  className={cn(
                    "whitespace-nowrap",
                    validityBadgeClass(deduction.validity)
                  )}
                >
                  {deduction.validity}
                </Badge>
                <Badge variant="outline" className="whitespace-nowrap gap-1">
                  <User className="h-3 w-3" />
                  Routed to {deduction.routedTo}
                </Badge>
              </div>
              <div className="flex items-start gap-2 text-sm text-muted-foreground">
                <FileText className="h-4 w-4 mt-0.5 shrink-0" />
                {invoice ? (
                  <span className="leading-relaxed">
                    Short payment — paying{" "}
                    <InfoTip
                      label={`What the customer actually pays: the ${formatMoney(
                        invoice.amount
                      )} invoice minus the ${formatMoney(
                        deduction.amount
                      )} they deducted.`}
                    >
                      <span className="font-semibold text-foreground underline decoration-dotted underline-offset-2">
                        {formatMoney(invoice.amount - deduction.amount)}
                      </span>
                    </InfoTip>{" "}
                    against the{" "}
                    <InfoTip
                      label={`The original amount billed on invoice ${deduction.invoiceId}.`}
                    >
                      <span className="font-semibold text-foreground underline decoration-dotted underline-offset-2">
                        {formatMoney(invoice.amount)}
                      </span>
                    </InfoTip>{" "}
                    invoice {deduction.invoiceId} —{" "}
                    <InfoTip
                      label={
                        deduction.source === "Debit memo"
                          ? `The customer deducted ${formatMoney(
                              deduction.amount
                            )} by raising a debit memo, claiming a ${deduction.reasonCode.toLowerCase()}.`
                          : `The customer short-paid by ${formatMoney(
                              deduction.amount
                            )}, tied to a ${deduction.reasonCode.toLowerCase()} claim.`
                      }
                    >
                      <span className="font-semibold text-primary underline decoration-dotted underline-offset-2">
                        {formatMoney(deduction.amount)} deducted
                      </span>
                    </InfoTip>
                    {deduction.source === "Debit memo" &&
                    deduction.sourceReference.match(/DM-\d+/)
                      ? `, raised as debit memo ${
                          deduction.sourceReference.match(/DM-\d+/)![0]
                        }.`
                      : "."}
                  </span>
                ) : (
                  <span>
                    {deduction.source} — {deduction.sourceReference}
                  </span>
                )}
              </div>
              <div>
                <div className="text-xs font-medium text-muted-foreground mb-2">
                  Evidence
                </div>
                <div className="space-y-1.5">
                  {deduction.evidence.map((ev) => (
                    <div
                      key={ev.id}
                      className="flex items-center gap-2 text-sm"
                    >
                      {ev.available ? (
                        <CircleCheck className="h-4 w-4 text-[var(--success)] shrink-0" />
                      ) : (
                        <TriangleAlert className="h-4 w-4 text-[var(--warning)] shrink-0" />
                      )}
                      <span
                        className={
                          ev.available
                            ? "text-foreground"
                            : "text-[var(--warning-foreground)]"
                        }
                      >
                        {ev.label}
                      </span>
                      {!ev.available && (
                        <span className="text-xs text-[var(--warning-foreground)]">
                          — requested
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <div className="text-xs font-medium text-muted-foreground mb-1">
                  Root cause
                </div>
                <p className="text-sm text-muted-foreground">
                  {deduction.rootCauseFinding}
                </p>
              </div>
            </div>

            {/* Right: the AI recommendation and the human decision */}
            <div className="space-y-4">
              <div className="rounded-lg border border-primary/20 bg-primary/5 p-3">
                <div className="flex items-center gap-2 mb-1">
                  <AgentIcon
                    type="orchestrator"
                    size="sm"
                    className="text-primary"
                  />
                  <span className="text-sm font-medium">AI recommendation</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  {deduction.aiRecommendation}
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <SourceDocTrigger
                  doc={buildClaimDoc(deduction)}
                  label={
                    deduction.source === "Short payment"
                      ? "View customer claim"
                      : "View debit memo"
                  }
                />
                {invoice && (
                  <SourceDocTrigger
                    doc={buildInvoiceDoc(invoice)}
                    label={`View invoice ${invoice.invoiceId}`}
                  />
                )}
              </div>
              {isResolved ? (
                <div className="rounded-lg bg-[var(--success)]/10 p-3 flex items-start gap-3">
                  <CircleCheck className="h-5 w-5 text-[var(--success)] shrink-0" />
                  <div className="text-sm">
                    <div className="font-semibold text-foreground">
                      {deduction.resolution ?? "Decision recorded"}
                    </div>
                    <div className="text-muted-foreground">
                      Collection strategy updated — {deduction.invoiceId} now
                      shows &apos;Deduction resolved&apos; in Collections.
                    </div>
                  </div>
                </div>
              ) : (
                <div>
                  <div className="mb-2 flex items-center gap-2">
                    <span className="text-xs font-medium text-muted-foreground">
                      Your decision
                    </span>
                    {deduction.recommendedOptions &&
                      deduction.recommendedOptions.length > 0 && (
                        <span className="inline-flex items-center gap-1 text-[11px] text-primary">
                          <Sparkles className="h-3 w-3" />
                          AI suggests{" "}
                          {deduction.splitResolution
                            ? "a split (both highlighted)"
                            : "the highlighted option"}
                        </span>
                      )}
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    {deduction.resolutionOptions.map((option) => {
                      const recommended =
                        deduction.recommendedOptions?.includes(option);
                      return (
                        <Button
                          key={option}
                          variant="outline"
                          size="sm"
                          className={cn(
                            "whitespace-nowrap",
                            recommended &&
                              "border-primary bg-primary/5 text-primary hover:bg-primary/10"
                          )}
                          onClick={() => handleOption(option)}
                        >
                          {recommended && <Sparkles className="h-3 w-3" />}
                          {option}
                        </Button>
                      );
                    })}
                  </div>
                </div>
              )}
              <div className="flex items-start gap-2 text-xs text-muted-foreground">
                <ShieldCheck className="h-4 w-4 mt-0.5 shrink-0 text-[var(--info)]" />
                <span>
                  <span className="font-medium text-foreground">
                    Prevent recurrence:
                  </span>{" "}
                  {preventRecurrenceNote(deduction.reasonCode)}
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      )}
      {splitOpen && deduction.splitResolution && (
        <DeductionSplitModal
          deduction={deduction}
          onConfirm={(resolution) => {
            onResolve(deduction.deductionId, resolution);
            setSplitOpen(false);
          }}
          onClose={() => setSplitOpen(false)}
        />
      )}
    </Card>
  );
}

/**
 * Payment Deductions & Disputes section: one case card per deduction in the
 * store (DED-001 short payment, DED-002 debit memo). Resolving a case calls
 * the store so every dependent surface updates together.
 */
export function DeductionCasesSection() {
  const {
    deductionCases,
    allInvoices,
    resolveDeduction,
    runReturnStage,
    runOrderId,
    requestReturn,
  } = useOtcStore();
  const awaitingCount = deductionCases.filter(
    (deduction) => deduction.status !== "Resolved"
  ).length;
  // During a guided run at Deductions, the run order's review appears as the
  // top row so it can be cleared in place, then return.
  const runInvoice =
    runReturnStage === "deductions"
      ? allInvoices.find((i) => i.orderId === runOrderId)
      : undefined;
  return (
    <div className="space-y-4 pt-2">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-foreground">
            Payment Deductions &amp; Disputes
          </h2>
          <p className="text-muted-foreground">
            Short payments and customer debit memos investigated by AI — every
            resolution is a human decision
          </p>
        </div>
        <Badge variant="outline" className="text-primary border-primary gap-1">
          <AgentIcon type="validation" size="sm" />
          {awaitingCount} Awaiting Decision
        </Badge>
      </div>
      <div className="space-y-3">
        {runInvoice && (
          <Card className="border-primary/30 bg-primary/5">
            <CardHeader className="pb-0">
              <div className="flex items-center gap-3">
                <CardTitle className="text-base font-semibold shrink-0">
                  {runOrderId}
                </CardTitle>
                <Badge
                  variant="outline"
                  className="border-primary/40 text-primary whitespace-nowrap"
                >
                  <Sparkles className="h-3 w-3 mr-1" />
                  Guided run
                </Badge>
                <span className="text-sm text-muted-foreground truncate flex-1 min-w-0">
                  against {runInvoice.invoiceId} — paid in full, no short-pay and
                  no debit memo
                </span>
                <Badge
                  variant="outline"
                  className="whitespace-nowrap border-[var(--success)]/40 text-[var(--success)]"
                >
                  No deduction
                </Badge>
                <Button
                  size="sm"
                  className="whitespace-nowrap"
                  onClick={requestReturn}
                >
                  <CircleCheck className="h-4 w-4 mr-1" />
                  Confirm clear
                </Button>
              </div>
            </CardHeader>
          </Card>
        )}
        {deductionCases.map((deduction) => (
          <DeductionCaseCard
            key={deduction.deductionId}
            deduction={deduction}
            invoice={allInvoices.find(
              (inv) => inv.invoiceId === deduction.invoiceId
            )}
            onResolve={resolveDeduction}
          />
        ))}
      </div>
    </div>
  );
}
