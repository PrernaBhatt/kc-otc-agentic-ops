"use client";

import { useState } from "react";
import { Check } from "lucide-react";

import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  findStock,
  monthlyAllocationCapUnits,
  stockPositions,
} from "@/lib/data/inventory";
import { buildStockLedgerDoc } from "@/lib/docs";

interface AllocationLine {
  sku: string;
  productName: string;
  qty: number;
}

/**
 * Fulfillment sub-check: available vs reserved stock per line, and the
 * monthly allocation position for allocation-controlled products. The AI
 * proposes the reservation; a human approves it.
 */
export function InventoryAllocationPanel({
  lines,
  orderId,
  autoApproved = false,
}: {
  lines: AllocationLine[];
  orderId: string;
  /** Touchless flow: the Allocation Agent reserves stock without a human step. */
  autoApproved?: boolean;
}) {
  const [approved, setApproved] = useState(false);

  const orderSkus = lines.map((l) => l.sku);
  const covered = lines.every((l) => {
    const stock = findStock(l.sku);
    return stock ? stock.availableUnits >= l.qty : true;
  });

  return (
    <Card className="border-l-4 border-l-[var(--info)]">
      <CardContent className="p-4 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <span className="text-sm font-semibold">Inventory Allocation</span>
          <SourceDocTrigger
            doc={buildStockLedgerDoc(stockPositions, orderSkus, {
              orderId,
              recommendation: covered
                ? "Available stock covers every line on this order — the allocation can be reserved now."
                : "One or more lines exceed available stock — review before reserving.",
            })}
            label="View stock ledger"
          />
        </div>

        <div className="space-y-2">
          {lines.map((line) => {
            const stock = findStock(line.sku);
            const available = stock?.availableUnits ?? line.qty;
            const pct = Math.min(100, Math.round((line.qty / available) * 100));
            const allocation = stock?.allocationUsedUnits;
            return (
              <div key={line.sku} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium truncate">
                    {line.productName}
                  </span>
                  <span className="text-muted-foreground whitespace-nowrap">
                    need {line.qty.toLocaleString()} · {available.toLocaleString()}{" "}
                    available
                  </span>
                </div>
                <div className="h-2 w-full rounded-full bg-muted overflow-hidden">
                  <div
                    className="h-full rounded-full bg-[var(--success)]"
                    style={{ width: `${pct}%` }}
                  />
                </div>
                {allocation !== undefined && (
                  <p className="text-xs text-muted-foreground">
                    Allocation-controlled: {allocation.toLocaleString()} of{" "}
                    {monthlyAllocationCapUnits.toLocaleString()} monthly units
                    used ·{" "}
                    {(monthlyAllocationCapUnits - allocation).toLocaleString()}{" "}
                    still available
                  </p>
                )}
              </div>
            );
          })}
        </div>

        {autoApproved ? (
          <Badge className="bg-[var(--success)] text-white">
            <Check className="h-3 w-3" />
            Stock reserved automatically by the Allocation Agent
          </Badge>
        ) : approved ? (
          <Badge className="bg-[var(--success)] text-white">
            <Check className="h-3 w-3" />
            Allocation approved by you
          </Badge>
        ) : (
          <div className="flex items-center justify-between gap-2">
            <p className="text-xs text-muted-foreground">
              AI recommends reserving stock for all lines.
            </p>
            <Button
              size="sm"
              variant="outline"
              className="whitespace-nowrap"
              onClick={() => setApproved(true)}
            >
              Approve allocation
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
