"use client";

import { useEffect, useState } from "react";
import { Sparkles } from "lucide-react";

import { useTypewriter } from "@/lib/hooks/use-typewriter";
import { cn } from "@/lib/utils";

const GATE_MS = 700;
const TYPE_MS = 7;
const LINE_PAUSE_MS = 550;
/** After the last beat lands, keep the finished card on screen so it can be read. */
const FINAL_HOLD_MS = 1600;
/** Only give up on a step if nobody can see it (user left the detail view). */
const OFF_SCREEN_MS = 2500;
/** Last-resort safety net so a run can never hang forever. */
const MAX_WAIT_MS = 90000;
const POLL_MS = 100;

/** Step playbacks that already finished — reopening them shows the end state at once. */
const played = new Set<string>();
const finishedAt = new Map<string, number>();
const mounted = new Set<string>();
const skipListeners = new Map<string, Set<() => void>>();

/** Presenter pressed Enter: jump this step's reasoning and card to their end state and release the run. */
export function skipStepReasoning(stepKey: string) {
  played.add(stepKey);
  finishedAt.set(stepKey, Date.now() - FINAL_HOLD_MS);
  skipListeners.get(stepKey)?.forEach((jump) => jump());
}

/** A fresh run of an order replays every step's animation instead of showing remembered end states. */
export function resetStepReasoning(prefix: string) {
  for (const key of [...played]) if (key.startsWith(prefix)) played.delete(key);
  for (const key of [...finishedAt.keys()]) if (key.startsWith(prefix)) finishedAt.delete(key);
}

/**
 * Holds the order run on a step until its on-screen reasoning AND card
 * animation have fully played, plus a short hold on the finished state.
 * Polls the playback state instead of relying on callbacks, so remounts,
 * collapses or slow renders can never release a step early.
 */
export function waitForStepReasoning(stepKey: string): Promise<void> {
  return new Promise((resolve) => {
    const startedAt = Date.now();
    let lastSeen = startedAt;
    const tick = () => {
      const now = Date.now();
      const done = finishedAt.get(stepKey);
      if (done !== undefined) {
        const left = done + FINAL_HOLD_MS - now;
        if (left <= 0) resolve();
        else setTimeout(resolve, left);
        return;
      }
      if (mounted.has(stepKey)) lastSeen = now;
      if (now - lastSeen > OFF_SCREEN_MS || now - startedAt > MAX_WAIT_MS) {
        resolve();
        return;
      }
      setTimeout(tick, POLL_MS);
    };
    tick();
  });
}

/**
 * The AI's reasoning for one order step: lines type out one after another and
 * `children(phase)` receives how many lines have finished, so the panel below
 * can change state exactly when the AI says why.
 */
export function AiStepReasoning({
  stepKey,
  playKey = stepKey,
  lines,
  instant = false,
  cardSteps = 0,
  cardStepMs = 420,
  children,
}: {
  /** Card animation beats after the reasoning (row reveals, bar fill…) — the step waits for them too. */
  cardSteps?: number;
  cardStepMs?: number;
  /** `${orderId}:${stepId}` — what the run waits on. */
  stepKey: string;
  /** Distinguishes variants of the same step (e.g. held vs released). */
  playKey?: string;
  lines: string[];
  /** Step already finished before this panel opened — show the end state, don't replay. */
  instant?: boolean;
  children?: (phase: number) => React.ReactNode;
}) {
  const alreadyPlayed = instant || played.has(playKey);
  const total = lines.length + cardSteps;
  const [phase, setPhase] = useState(alreadyPlayed ? total : -1);
  const reasoningDone = phase >= lines.length;
  const finished = phase >= total;

  useEffect(() => {
    if (!reasoningDone || finished) return;
    const id = setTimeout(() => setPhase((p) => p + 1), cardStepMs);
    return () => clearTimeout(id);
  }, [phase, reasoningDone, finished, cardStepMs]);

  useEffect(() => {
    mounted.add(stepKey);
    const jump = () => setPhase(total);
    const listeners = skipListeners.get(stepKey) ?? new Set<() => void>();
    listeners.add(jump);
    skipListeners.set(stepKey, listeners);
    return () => {
      mounted.delete(stepKey);
      listeners.delete(jump);
    };
  }, [stepKey, total]);

  useEffect(() => {
    if (phase !== -1) return;
    const id = setTimeout(() => setPhase(0), GATE_MS);
    return () => clearTimeout(id);
  }, [phase]);

  useEffect(() => {
    if (!finished) return;
    played.add(playKey);
    played.add(stepKey);
    if (!finishedAt.has(stepKey)) finishedAt.set(stepKey, Date.now());
  }, [finished, playKey, stepKey]);

  return (
    <div className="flex flex-col gap-3">
      <div
        className="rounded-lg border bg-card p-4 shadow-sm"
        aria-live="polite"
      >
        <div className="mb-2 flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-[var(--info)]" aria-hidden />
          <span className="text-sm font-semibold text-foreground">AI reasoning</span>
          {!finished && (
            <span className="ml-auto text-xs text-muted-foreground">Thinking…</span>
          )}
        </div>
        {phase === -1 ? (
          <LoaderBars />
        ) : (
          <ul className="flex flex-col gap-1.5 text-sm leading-relaxed text-foreground">
            {lines.slice(0, Math.min(phase + 1, lines.length)).map((line, i) => (
              <li key={i} className="flex gap-2">
                <span
                  className={cn(
                    "mt-2 h-1.5 w-1.5 shrink-0 rounded-full",
                    i < phase || reasoningDone ? "bg-[var(--success)]" : "bg-[var(--info)] animate-agent-pulse"
                  )}
                  aria-hidden
                />
                {i < phase || reasoningDone ? (
                  <span>{line}</span>
                ) : (
                  <TypedLine
                    text={line}
                    onDone={() => setPhase((p) => (p === i ? i + 1 : p))}
                  />
                )}
              </li>
            ))}
          </ul>
        )}
      </div>
      {children?.(Math.max(phase, 0))}
    </div>
  );
}

function TypedLine({ text, onDone }: { text: string; onDone: () => void }) {
  const { visible, done } = useTypewriter(text, TYPE_MS);
  useEffect(() => {
    if (!done) return;
    const id = setTimeout(onDone, LINE_PAUSE_MS);
    return () => clearTimeout(id);
    // onDone is recreated each render; firing once per completion is what matters.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [done]);
  return (
    <span>
      {visible}
      {!done && (
        <span className="ml-0.5 inline-block h-4 w-[2px] align-middle bg-[var(--info)] animate-caret-blink" />
      )}
    </span>
  );
}

function LoaderBars() {
  return (
    <div className="flex flex-col gap-2" aria-label="AI is reasoning">
      {[100, 88, 60].map((width, i) => (
        <div
          key={width}
          className="h-3 rounded bg-muted animate-agent-pulse"
          style={{ width: `${width}%`, animationDelay: `${i * 120}ms` }}
        />
      ))}
    </div>
  );
}

/** Fades a section in once the AI has reached the point that produces it. */
export function RevealWhen({ when, children }: { when: boolean; children: React.ReactNode }) {
  if (!when) return null;
  return <div className="animate-enter">{children}</div>;
}
