"use client";

import { Boxes, CircleCheck, MapPin, PackageCheck, Route, Truck, Warehouse } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckChip } from "@/components/shared/check-chip";
import { FillFields } from "@/components/shared/fill-fields";
import { SystemMark } from "@/components/shared/system-badge";
import { TickList } from "@/components/shared/tick-list";
import { logisticsEvidence, tmsPlanFacts } from "@/components/mounts/order-management/order-evidence";
import { RevealWhen } from "@/components/mounts/order-management/step-reasoning";
import { invoiceToCashFor } from "@/lib/data/invoice-to-cash";
import { cubePct, orderLogistics, TMS_SYSTEM, weightPct } from "@/lib/data/order-logistics";
import { cn } from "@/lib/utils";

const DAY = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
/** "2026-08-28 13:10" → "Fri 08-28 13:10". */
function stamp(s: string) {
  const [d, t] = s.split(" ");
  return `${DAY[new Date(`${d}T00:00:00Z`).getUTCDay()]} ${d.slice(5)} ${t}`;
}

function PanelTitle({
  icon: Icon,
  children,
  aside,
}: {
  icon: React.ComponentType<{ className?: string }>;
  children: React.ReactNode;
  aside?: React.ReactNode;
}) {
  return (
    <CardHeader className="pb-2">
      <CardTitle className="flex items-center gap-2 text-sm">
        <Icon className="h-4 w-4 shrink-0 text-[var(--info)]" />
        <span className="min-w-0">{children}</span>
        {aside && <span className="ml-auto shrink-0">{aside}</span>}
      </CardTitle>
    </CardHeader>
  );
}

function Stamp({ children }: { children: React.ReactNode }) {
  return (
    <span className="step-pop rounded border-2 border-[var(--success)] px-2 py-0.5 text-[11px] font-bold uppercase tracking-widest text-[var(--success)]">
      {children}
    </span>
  );
}

/* ------------------------------------------------------------------ *
 * Shipment planning · the TMS plan the Freight Planning Agent reads
 * ------------------------------------------------------------------ */

export function shipmentPlanReasoning(orderId: string): string[] | null {
  const l = orderLogistics(orderId);
  const ev = logisticsEvidence(orderId);
  if (!l || !ev) return null;
  const carrier = l.tender.carrier.split(" · ")[0];
  return [
    `Reading TMS plan ${l.tmsPlan.loadId} in ${TMS_SYSTEM}; route, load and carrier are planned there.`,
    `Route ${l.routePlan.miles} mi, about ${l.routePlan.driveMin} min. Load ${l.loadPlan.pallets} pallets on ${l.loadPlan.palletPositions} positions: ${cubePct(l.loadPlan)}% cube, ${weightPct(l.loadPlan)}% of max weight.`,
    `${carrier} is the least-cost carrier above the ${ev.serviceFloor}% on-time floor; tender accepted. Expected delivery ${l.tmsPlan.eta}.`,
  ];
}

function RouteStrip({ orderId }: { orderId: string }) {
  const l = orderLogistics(orderId)!;
  return (
    <div className="flex flex-col gap-2 rounded-md border bg-muted/20 p-3">
      <span className="flex items-center gap-1.5 text-xs font-semibold text-foreground">
        <Route className="h-3.5 w-3.5 text-[var(--info)]" aria-hidden /> Route
      </span>
      <div className="flex items-center gap-2 text-[11px]">
        <Warehouse className="h-4 w-4 shrink-0 text-muted-foreground" aria-hidden />
        <span className="relative h-1.5 flex-1 overflow-hidden rounded-full bg-muted">
          <span className="grow-x absolute inset-y-0 left-0 w-full rounded-full bg-[var(--info)]" />
        </span>
        <MapPin className="h-4 w-4 shrink-0 text-[var(--success)]" aria-hidden />
      </div>
      <div className="flex justify-between gap-2 text-[11px] text-muted-foreground">
        <span className="truncate">{l.routePlan.origin.split(" ")[0]}</span>
        <span className="font-medium tabular-nums text-foreground">
          {l.routePlan.miles} mi · {l.routePlan.driveMin} min
        </span>
        <span className="truncate text-right">{l.routePlan.destination.split(",")[0]}</span>
      </div>
    </div>
  );
}

function LoadGrid({ orderId }: { orderId: string }) {
  const p = orderLogistics(orderId)!.loadPlan;
  return (
    <div className="flex flex-col gap-2 rounded-md border bg-muted/20 p-3">
      <span className="flex items-center gap-1.5 text-xs font-semibold text-foreground">
        <Boxes className="h-3.5 w-3.5 text-[var(--info)]" aria-hidden /> Load plan · {p.equipment}
      </span>
      <div
        className="grid gap-0.5"
        style={{ gridTemplateColumns: "repeat(15, minmax(0, 1fr))" }}
        role="img"
        aria-label={`${p.pallets} of ${p.palletPositions} pallet positions used`}
      >
        {Array.from({ length: p.palletPositions }, (_, i) => (
          <span
            key={i}
            className={cn(
              "animate-enter-fade aspect-square rounded-[2px]",
              i < p.pallets ? "bg-[var(--info)]" : "border border-dashed bg-card"
            )}
            style={{ animationDelay: `${i * 18}ms` }}
          />
        ))}
      </div>
      <div className="grid grid-cols-3 gap-2 text-[11px] text-muted-foreground">
        <span>
          Pallets <span className="block font-medium tabular-nums text-foreground">{p.pallets} / {p.palletPositions}</span>
        </span>
        <span>
          Cube <span className="block font-medium tabular-nums text-foreground">{cubePct(p)}%</span>
        </span>
        <span>
          Weight{" "}
          <span className="block font-medium tabular-nums text-foreground">
            {p.weightLb.toLocaleString()} lb · {weightPct(p)}%
          </span>
        </span>
      </div>
    </div>
  );
}

function CarrierTable({ orderId }: { orderId: string }) {
  const ev = logisticsEvidence(orderId)!;
  const l = orderLogistics(orderId)!;
  return (
    <div className="overflow-hidden rounded-md border">
      <div className="flex items-center justify-between gap-2 border-b bg-muted/30 px-3 py-2">
        <span className="flex items-center gap-1.5 text-xs font-semibold text-foreground">
          <Truck className="h-3.5 w-3.5 text-[var(--info)]" aria-hidden /> Carrier selection
        </span>
        <span className="text-[11px] text-muted-foreground">On-time floor {ev.serviceFloor}%</span>
      </div>
      <ul className="divide-y">
        {ev.carriers.map((c, i) => {
          const selected = c.status === "selected";
          return (
            <li
              key={c.scac}
              className={cn(
                "animate-enter flex flex-wrap items-center gap-x-3 gap-y-1 px-3 py-2 text-xs",
                selected && "bg-[var(--success)]/5"
              )}
              style={{ animationDelay: `${i * 90}ms` }}
            >
              <span className="min-w-0 flex-1">
                <span className="font-medium text-foreground">{c.name}</span>{" "}
                <span className="font-mono text-[11px] text-muted-foreground">{c.scac}</span>
              </span>
              <span className="tabular-nums text-muted-foreground">On time {c.onTime}%</span>
              <span className="w-16 text-right font-medium tabular-nums text-foreground">${c.rate.toLocaleString()}</span>
              {selected ? (
                <CheckChip result="pass">Tender accepted {l.tender.acceptedAt.slice(11)}</CheckChip>
              ) : (
                <span className="w-[136px] text-right text-[11px] text-muted-foreground">+${(c.rate - l.tender.rateUsd).toLocaleString()} vs selected</span>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
}

/** Shipment planning: route, load and carrier come from SAP TM; the agent reads them (ticks), it never writes them. */
export function ShipmentPlanPanel({ orderId, phase }: { orderId: string; phase: number }) {
  const facts = tmsPlanFacts(orderId);
  const l = orderLogistics(orderId);
  if (!facts || !l) {
    return (
      <RevealWhen when={phase >= 1}>
        <p className="animate-enter-fade rounded-lg border bg-card px-4 py-3 text-sm leading-relaxed text-muted-foreground">
          Route, load and carrier read from the TMS plan.
        </p>
      </RevealWhen>
    );
  }
  return (
    <div className="flex flex-col gap-3" data-stage="shipment-plan">
      <RevealWhen when={phase >= 1}>
        <Card className="animate-enter gap-0" data-card="tms-plan">
          <PanelTitle
            icon={Route}
            aside={
              <Badge variant="outline" className="gap-1.5 whitespace-nowrap text-xs font-medium text-muted-foreground">
                <SystemMark name={TMS_SYSTEM} />
                <span className="font-mono">{l.tmsPlan.loadId}</span>
              </Badge>
            }
          >
            TMS shipment plan
          </PanelTitle>
          <CardContent className="flex flex-col gap-3">
            <TickList
              playKey={`${orderId}:shipment-plan`}
              items={facts.map((f) => ({ id: f.id, label: f.label, detail: f.value, system: TMS_SYSTEM }))}
            />
            {phase >= 2 && (
              <div className="animate-enter grid gap-3 md:grid-cols-2">
                <RouteStrip orderId={orderId} />
                <LoadGrid orderId={orderId} />
              </div>
            )}
            {phase >= 3 && (
              <div className="animate-enter">
                <CarrierTable orderId={orderId} />
              </div>
            )}
          </CardContent>
        </Card>
      </RevealWhen>
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Track & deliver · A → S → in transit → D, then POD unlocks billing
 * ------------------------------------------------------------------ */

export function deliveryReasoning(orderId: string): string[] | null {
  const l = orderLogistics(orderId);
  const ev = logisticsEvidence(orderId);
  if (!l || !ev) return null;
  const d = l.delivery;
  const slotFrom = ev.appointmentWindow.split(" · ")[1].split("–")[0];
  return [
    `Pickup day. SAP EWM shows ${d.available.detail.split(" picked")[0]} staged at ${d.available.at.slice(11)}: Available is met.`,
    `Gated out ${d.shipped.at.slice(11)} on ${d.shipped.bol}, inside the ${l.tmsPlan.pickup.slice(-5)} pickup: Shipped is met.`,
    `FourKites ping ${d.ping.at.slice(11)} on ${d.ping.position}, ${d.ping.milesLeft} mi out. Predictive ETA ${d.ping.peta}, ahead of the ${slotFrom} slot.`,
    `Arrived ${d.arrived.slice(11)}; POD signed ${d.pod.at.slice(11)}, ${d.pod.received}: Delivered on time and in full. Unlocking billing.`,
  ];
}

interface Milestone {
  key: string;
  label: string;
  at: string;
  detail: string;
  system: string;
  letter?: "A" | "S" | "D";
  icon: React.ComponentType<{ className?: string }>;
}

function milestones(orderId: string): Milestone[] {
  const l = orderLogistics(orderId)!;
  const d = l.delivery;
  return [
    { key: "A", label: "Available", at: d.available.at, detail: d.available.detail, system: "SAP EWM", letter: "A", icon: Warehouse },
    { key: "S", label: "Loaded & shipped", at: d.shipped.at, detail: `${d.shipped.detail} · ${d.shipped.bol}`, system: TMS_SYSTEM, letter: "S", icon: Truck },
    {
      key: "transit",
      label: "In transit",
      at: d.ping.at,
      detail: `${d.ping.position} · ${d.ping.milesLeft} mi to go`,
      system: "FourKites",
      icon: Route,
    },
    { key: "D", label: "Delivered", at: d.arrived, detail: `POD ${d.pod.at.slice(11)} · ${d.pod.received}`, system: TMS_SYSTEM, letter: "D", icon: PackageCheck },
  ];
}

function TransitBar({ orderId }: { orderId: string }) {
  const l = orderLogistics(orderId)!;
  const ev = logisticsEvidence(orderId)!;
  const done = ((l.routePlan.miles - l.delivery.ping.milesLeft) / l.routePlan.miles) * 100;
  const slotFrom = ev.appointmentWindow.split(" · ")[1].split("–")[0];
  return (
    <div className="mt-1.5 flex flex-col gap-1.5">
      <span className="relative block h-1.5 overflow-hidden rounded-full bg-muted">
        <span
          className="grow-x absolute inset-y-0 left-0 rounded-full bg-[var(--info)]"
          style={{ width: `${done}%` }}
        />
      </span>
      <span className="flex flex-wrap items-center gap-1.5">
        <Badge variant="outline" className="gap-1 text-[11px] font-medium">
          <SystemMark name="FourKites" /> PETA {l.delivery.ping.peta}
        </Badge>
        <CheckChip result="pass">Before the {slotFrom} slot</CheckChip>
      </span>
    </div>
  );
}

/**
 * Track & deliver: each OTIF milestone arrives as the AI reaches it (input
 * from EWM, TM and FourKites ticks in), then the POD record types itself in
 * and billing unlocks.
 */
export function DeliveryStagePanel({ orderId, phase }: { orderId: string; phase: number }) {
  const l = orderLogistics(orderId);
  const ev = logisticsEvidence(orderId);
  if (!l || !ev) {
    return (
      <RevealWhen when={phase >= 1}>
        <p className="animate-enter-fade rounded-lg border bg-card px-4 py-3 text-sm leading-relaxed text-muted-foreground">
          Delivered and POD signed; billing unlocked.
        </p>
      </RevealWhen>
    );
  }
  const rows = milestones(orderId);
  const reached = Math.min(phase, rows.length);
  const invoice = invoiceToCashFor(orderId);
  return (
    <div className="flex flex-col gap-3" data-stage="delivery">
      <Card className="animate-enter gap-0" data-card="otif-milestones">
        <PanelTitle
          icon={Truck}
          aside={
            reached >= rows.length ? (
              <CheckChip result="pass">OTIF · A S D met</CheckChip>
            ) : (
              <Badge variant="outline" className="text-xs text-muted-foreground">
                {reached} of {rows.length} milestones
              </Badge>
            )
          }
        >
          {l.tmsPlan.loadId} · {ev.shipTo}
        </PanelTitle>
        <CardContent>
          <ol className="flex flex-col">
            {rows.map((m, i) => {
              const done = i < reached;
              const Icon = m.icon;
              return (
                <li key={m.key} className="relative flex gap-3 pb-3 last:pb-0">
                  {i < rows.length - 1 && (
                    <span
                      className={cn(
                        "absolute left-[13px] top-7 h-[calc(100%-1.5rem)] w-px transition-colors duration-500",
                        i < reached - 1 ? "bg-[var(--success)]" : "bg-border"
                      )}
                      aria-hidden
                    />
                  )}
                  <span
                    className={cn(
                      "relative z-10 flex h-7 w-7 shrink-0 items-center justify-center rounded-full border transition-colors duration-500",
                      done ? "border-[var(--success)] bg-[var(--success)] text-[var(--success-foreground)]" : "bg-card text-muted-foreground"
                    )}
                  >
                    {done ? <CircleCheck className="h-4 w-4" aria-hidden /> : <Icon className="h-3.5 w-3.5" aria-hidden />}
                  </span>
                  <div className={cn("min-w-0 flex-1 transition-opacity duration-500", !done && "opacity-50")}>
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                      <span className="text-sm font-medium text-foreground">{m.label}</span>
                      {done && (
                        <span className="animate-enter-fade text-xs tabular-nums text-muted-foreground">{stamp(m.at)}</span>
                      )}
                      <span className="ml-auto flex items-center gap-2">
                        <SystemMark name={m.system} />
                        {m.letter && done && <Stamp>{m.letter}</Stamp>}
                      </span>
                    </div>
                    {done ? (
                      <p className="animate-enter-fade text-xs leading-relaxed text-muted-foreground">{m.detail}</p>
                    ) : (
                      <p className="text-xs text-muted-foreground">Waiting</p>
                    )}
                    {m.key === "transit" && done && <TransitBar orderId={orderId} />}
                  </div>
                </li>
              );
            })}
          </ol>
        </CardContent>
      </Card>
      {phase > rows.length && (
        <div className="animate-enter flex flex-col gap-2 rounded-md border bg-muted/20 px-3 py-2" data-card="pod-record">
          <span className="flex items-center gap-1.5 text-xs font-semibold text-foreground">
            <SystemMark name={TMS_SYSTEM} /> Proof of delivery
          </span>
          <FillFields
            playKey={`${orderId}:pod-fill`}
            columns={2}
            fields={[
              { label: "Delivered", value: stamp(l.delivery.arrived) },
              { label: "Appointment", value: ev.appointmentId, mono: true },
              { label: "Signed by", value: l.delivery.pod.signer },
              { label: "Received", value: l.delivery.pod.received },
              { label: "Invoice", value: invoice?.invoiceId ?? "Released to billing", mono: !!invoice },
              { label: "Billing", value: "Unlocked", strong: true },
            ]}
            stamp={<Stamp>Delivered OTIF</Stamp>}
          />
        </div>
      )}
    </div>
  );
}
