"use client";

import { useState } from "react";

import { FillFields } from "@/components/shared/fill-fields";
import { pricingHoldCase, pricingHoldTotals } from "@/lib/data/pipeline-orders";
import { formatMoney } from "@/lib/selectors";

/** After the signature: the repriced SAP order, then the discrepancy record, each typing in. */
export function ContractPriceOutputs() {
  const c = pricingHoldCase;
  const t = pricingHoldTotals;
  const [orderDone, setOrderDone] = useState(false);

  return (
    <div
      className="grid items-stretch gap-3 md:grid-cols-2"
      data-billed-total={t.contractTotal}
      data-discrepancy={c.discrepancyRecordId}
    >
      <section className="animate-enter flex h-full flex-col rounded-lg border">
        <header className="border-b bg-muted/30 px-3 py-2 text-xs font-semibold text-foreground">
          SAP order repriced · {c.orderId}
        </header>
        <FillFields
          className="px-3 py-2"
          playKey={`${c.orderId}:repriced`}
          onDone={() => setOrderDone(true)}
          fields={[
            ...c.lines.map((l) => ({
              label: `${l.sku} · ${l.qty} cs`,
              value: `${formatMoney(l.contractPrice)} PR00`,
              align: "right" as const,
            })),
            { label: "Order total", value: formatMoney(t.contractTotal), align: "right", strong: true },
          ]}
        />
      </section>
      <section className="animate-enter flex h-full flex-col rounded-lg border" style={{ animationDelay: "120ms" }}>
        <header className="border-b bg-muted/30 px-3 py-2 text-xs font-semibold text-foreground">
          Discrepancy record {c.discrepancyRecordId}
        </header>
        <FillFields
          className="px-3 py-2"
          play={orderDone}
          playKey={`${c.orderId}:discrepancy`}
          fields={[
            { label: "Customer PO", value: `${c.poNumber} · ${formatMoney(t.poTotal)}`, align: "right" },
            { label: "Contract", value: `${c.contract} · ${formatMoney(t.contractTotal)}`, align: "right" },
            { label: "Gap", value: formatMoney(t.variance), align: "right" },
            { label: "Reason", value: c.discrepancyReason },
            { label: "Control", value: `SOX ${c.controlRef}`, strong: true },
          ]}
        />
      </section>
    </div>
  );
}
