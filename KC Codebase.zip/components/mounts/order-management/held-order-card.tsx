"use client";

import { CalendarX2, CircleCheck, Play } from "lucide-react";

import { OrderThreadStrip, ORDER_THREAD } from "@/components/mounts/order-management/order-thread-strip";
import { OwnerChip } from "@/components/shared/owner-chip";
import { SystemMark } from "@/components/shared/system-badge";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { APPOINTMENT_CASE } from "@/lib/data/shipment-risk";
import { appointmentRun, shortStamp } from "@/lib/shipment-selectors";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

/**
 * The Walmart order whose thread stopped at Appointment: no receiving slot
 * inside the OTIF window. It opens Run A, the appointment-scheduling branch.
 */
export function HeldOrderCard({ onOpen }: { onOpen: () => void }) {
  const { resolvedShipments } = useOtcStore();
  const a = APPOINTMENT_CASE;
  const resolved = !!resolvedShipments[a.caseId];
  const atIdx = ORDER_THREAD.indexOf("Appointment");
  const pct = Math.round(((atIdx + (resolved ? 1 : 0.5)) / ORDER_THREAD.length) * 100);
  return (
    <Card className="transition-shadow hover:shadow-md" data-order={a.orderId}>
      <CardContent className="flex flex-col gap-4 p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="flex flex-col gap-0.5">
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-semibold">{a.orderId}</h3>
              <Badge
                variant="outline"
                className={cn(
                  "text-xs",
                  resolved ? "border-green-200 bg-green-50 text-green-700" : "border-amber-200 bg-amber-50 text-amber-700"
                )}
              >
                {resolved ? "Slot confirmed" : "Appointment hold"}
              </Badge>
            </div>
            <p className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
              {a.customer}
              <OwnerChip account={a.accountId} variant="compact" />
            </p>
            <p className="text-sm font-medium text-foreground">${a.valueUsd.toLocaleString()}</p>
          </div>
          <Button size="sm" onClick={onOpen} variant={resolved ? "outline" : "default"} className="h-8 gap-1.5 whitespace-nowrap text-xs">
            {resolved ? (
              <>
                <CircleCheck className="h-3.5 w-3.5" /> Review
              </>
            ) : (
              <>
                <Play className="h-3.5 w-3.5" /> Resolve
              </>
            )}
          </Button>
        </div>
        <div className="flex flex-col gap-2">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>
              Stage: <span className="font-medium text-foreground">{resolved ? "Track & deliver" : "Appointment"}</span>
            </span>
            <span>
              {atIdx + (resolved ? 2 : 1)} / {ORDER_THREAD.length}
            </span>
          </div>
          <div className="relative h-1.5 overflow-hidden rounded-full bg-muted">
            <div
              className={cn("absolute h-full transition-all duration-500", resolved ? "bg-[var(--success)]" : "bg-amber-500")}
              style={{ width: `${pct}%` }}
            />
          </div>
          <OrderThreadStrip at="Appointment" resolved={resolved} />
        </div>
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 rounded-md border bg-muted/20 px-3 py-2 text-xs">
          <SystemMark name={a.portal} />
          {resolved ? (
            <span className="text-foreground">
              {a.appointment.id} · {a.appointment.label} · TMS replanned, pickup {shortStamp(a.replan.pickup)}
            </span>
          ) : (
            <span className="flex items-center gap-1.5 text-foreground">
              <CalendarX2 className="h-3.5 w-3.5 text-amber-600" aria-hidden />
              No open slot up to MABD {a.otifWindow.mabd.slice(5)}; first open {appointmentRun.firstOpenAfterMabd}
            </span>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
