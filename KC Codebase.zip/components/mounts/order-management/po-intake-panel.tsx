"use client";

import { CircleCheck, Inbox, Loader2, TriangleAlert } from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { findInboundPo, type InboundPo } from "@/lib/data/pipeline-orders";
import { buildInboundPoDoc } from "@/lib/docs";

function channelChipClass(channel: InboundPo["channel"]) {
  switch (channel) {
    case "Customer portal":
      return "bg-blue-50 text-blue-700 border-blue-200";
    case "Electronic order feed":
      return "bg-purple-50 text-purple-700 border-purple-200";
    default:
      return "bg-gray-50 text-gray-600 border-gray-200";
  }
}

function ExtractionCheckChip({ check }: { check: "Pass" | "Attention" }) {
  return check === "Pass" ? (
    <Badge
      variant="outline"
      className="whitespace-nowrap bg-green-100 text-green-700 border-green-200"
    >
      <CircleCheck className="h-3 w-3" /> Pass
    </Badge>
  ) : (
    <Badge
      variant="outline"
      className="whitespace-nowrap bg-amber-50 text-amber-700 border-amber-200"
    >
      <TriangleAlert className="h-3 w-3" /> Attention
    </Badge>
  );
}

/**
 * S1 + S2 — Purchase order intake and AI purchase order understanding.
 * Expands under a pipeline card when the Capture stage (or the "View inbound
 * purchase order" button) is clicked.
 */
export function PoIntakePanel({
  orderId,
  revealed,
}: {
  orderId: string;
  /** Animation beat: row i appears at beat i+1 and passes at beat i+2. Omit to show everything. */
  revealed?: number;
}) {
  const po = findInboundPo(orderId);

  if (!po) {
    return (
      <div className="rounded-lg border bg-muted/30 p-4 text-sm text-muted-foreground animate-in fade-in slide-in-from-top-2 duration-300">
        No inbound purchase order document is on file for this order — it was
        entered directly by the sales team, so there is nothing for the AI to
        read at the Capture stage.
      </div>
    );
  }

  const heldLotOnPo = po.lines.some((line) => line.lot);

  return (
    <div className="rounded-lg border bg-muted/20 p-4 space-y-3 animate-in fade-in slide-in-from-top-2 duration-300">
      <div className="flex flex-wrap items-center gap-2">
        <AgentIcon type="extraction" size="sm" />
        <span className="text-sm font-semibold">
          Inbound purchase order — what the AI read
        </span>
        <Badge
          variant="outline"
          className={["text-xs", channelChipClass(po.channel)].join(" ")}
        >
          <Inbox className="h-3 w-3" /> {po.channel}
        </Badge>
        <span className="text-xs text-muted-foreground ml-auto">
          {po.poNumber} · received {po.receivedAt}
        </span>
      </div>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Field</TableHead>
            <TableHead>Value</TableHead>
            <TableHead className="text-right">Check</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {po.extraction.map((row, i) => {
            const beat = revealed ?? Infinity;
            if (beat < i + 1) return null;
            const checked = beat >= i + 2;
            return (
            <TableRow key={row.field} className="animate-enter">
              <TableCell className="align-top font-medium whitespace-normal">
                {row.field}
              </TableCell>
              <TableCell className="align-top whitespace-normal">
                <div className="flex flex-col gap-0.5">
                  <span>{row.value}</span>
                  {row.note && (
                    <span className="text-xs leading-relaxed text-muted-foreground">
                      {row.note}
                    </span>
                  )}
                </div>
              </TableCell>
              <TableCell className="align-top text-right">
                {checked ? (
                  <span className="inline-flex animate-enter-fade">
                    <ExtractionCheckChip check={row.check} />
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
                    <Loader2 className="h-3 w-3 animate-spin" aria-hidden /> Checking
                  </span>
                )}
              </TableCell>
            </TableRow>
            );
          })}
        </TableBody>
      </Table>
      {(revealed === undefined || revealed > po.extraction.length) && (
      <div className="flex flex-wrap items-center gap-2 pt-1 animate-enter-fade">
        <SourceDocTrigger
          doc={buildInboundPoDoc(po, "extraction")}
          label="View inbound purchase order"
        />
        {heldLotOnPo && (
          <SourceDocTrigger
            doc={buildInboundPoDoc(po, "regulatory")}
            label="View held lot on purchase order"
            className="border-amber-300 text-amber-700 hover:bg-amber-50"
          />
        )}
      </div>
      )}
    </div>
  );
}
