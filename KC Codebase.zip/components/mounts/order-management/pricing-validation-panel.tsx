"use client";

import { useState } from "react";
import { CircleCheck, ThumbsUp } from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  findInboundPo,
  standardPaymentTerms,
  volumeDiscountRate,
} from "@/lib/data/pipeline-orders";
import { buildInboundPoDoc } from "@/lib/docs";
import { formatMoney } from "@/lib/selectors";

/** Structural shape of an order line the tie-out table needs. */
export interface PricingPanelLine {
  orderLineId: string;
  productName: string;
  qty: number;
  unitPrice: number;
  lineValue: number;
}

/**
 * S4 — Pricing & Commercial Validation. Expands under a pipeline card when
 * the Pricing stage is clicked: contract price tie-out per order line,
 * payment terms check, and a human discount-approval decision.
 */
export function PricingValidationPanel({
  orderId,
  totalValue,
  lines,
}: {
  orderId: string;
  totalValue: number;
  lines: PricingPanelLine[];
}) {
  const [discountApproved, setDiscountApproved] = useState(false);
  const po = findInboundPo(orderId);
  const paymentTerms = po?.paymentTerms ?? standardPaymentTerms;
  const discountAmount = volumeDiscountRate * totalValue;
  const discountPercent = Math.round(volumeDiscountRate * 100);

  return (
    <div className="rounded-lg border bg-muted/20 p-4 space-y-3 animate-in fade-in slide-in-from-top-2 duration-300">
      <div className="flex flex-wrap items-center gap-2">
        <AgentIcon type="pricing" size="sm" />
        <span className="text-sm font-semibold">
          Pricing &amp; Commercial Validation
        </span>
        <span className="text-xs text-muted-foreground ml-auto">
          Contract prices checked line by line
        </span>
      </div>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Product</TableHead>
            <TableHead className="text-right">Contract price</TableHead>
            <TableHead className="text-right">Applied price</TableHead>
            <TableHead>Check</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {lines.map((line) => {
            const appliedPrice = line.lineValue / line.qty;
            const matches = appliedPrice === line.unitPrice;
            return (
              <TableRow key={line.orderLineId}>
                <TableCell className="font-medium">
                  {line.productName}
                </TableCell>
                <TableCell className="text-right">
                  {formatMoney(line.unitPrice)}
                </TableCell>
                <TableCell className="text-right">
                  {formatMoney(appliedPrice)}
                </TableCell>
                <TableCell>
                  <Badge
                    variant="outline"
                    className={[
                      "whitespace-nowrap text-xs",
                      matches
                        ? "bg-green-100 text-green-700 border-green-200"
                        : "bg-amber-50 text-amber-700 border-amber-200",
                    ].join(" ")}
                  >
                    {matches ? (
                      <>
                        <CircleCheck className="h-3 w-3" /> Pass
                      </>
                    ) : (
                      "Attention"
                    )}
                  </Badge>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
      <div className="flex items-center justify-between p-2 bg-muted/50 rounded text-sm">
        <span>Payment terms</span>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">
            {paymentTerms} — matches the customer agreement
          </span>
          <CircleCheck className="h-4 w-4 text-[var(--success)]" />
        </div>
      </div>
      <div className="rounded-md border bg-background p-3 flex flex-wrap items-center justify-between gap-3">
        <div className="space-y-1 min-w-0">
          <div className="flex items-center gap-2 text-sm font-medium">
            Discount approval
            {discountApproved ? (
              <Badge className="bg-[var(--success)] text-white text-xs whitespace-nowrap">
                <ThumbsUp className="h-3 w-3" /> Approved by you
              </Badge>
            ) : (
              <Badge
                variant="outline"
                className="bg-amber-50 text-amber-700 border-amber-200 text-xs whitespace-nowrap"
              >
                Awaiting your decision
              </Badge>
            )}
          </div>
          <p className="text-xs text-muted-foreground">
            {`AI recommends approving the standard ${discountPercent}% volume discount of ${formatMoney(discountAmount)} (pricing rule PRC-200) — it matches this customer's agreement.`}
          </p>
        </div>
        {!discountApproved && (
          <Button
            size="sm"
            onClick={() => setDiscountApproved(true)}
            className="whitespace-nowrap gap-1.5 text-xs h-8"
          >
            <ThumbsUp className="h-3.5 w-3.5" /> Approve discount
          </Button>
        )}
      </div>
      {po && (
        <div className="pt-1">
          <SourceDocTrigger
            doc={buildInboundPoDoc(po, "extraction")}
            label="View inbound purchase order"
          />
        </div>
      )}
    </div>
  );
}
