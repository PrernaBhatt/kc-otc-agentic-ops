"use client";

import { Clock } from "lucide-react";

import { invoiceToCashFor } from "@/lib/data/invoice-to-cash";
import { formatMoney } from "@/lib/selectors";

/** Closes the order run on the money: invoice at POD, cash on the terms. */
export function InvoiceToCashClock({ orderId }: { orderId: string }) {
  const c = invoiceToCashFor(orderId);
  if (!c) return null;
  const invoicePct = (c.toInvoiceDays / c.totalDays) * 100;

  return (
    <section
      className="animate-enter rounded-lg border bg-background p-3 text-left"
      data-i2c-days={c.totalDays}
      aria-label="Invoice-to-cash clock"
    >
      <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-foreground">
        <Clock className="h-3.5 w-3.5 text-primary" aria-hidden="true" />
        Invoice-to-cash clock
        <span className="ml-auto font-normal tabular-nums text-muted-foreground">
          {formatMoney(c.amountUsd)}
        </span>
      </div>
      <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
        {`Invoice ${c.invoiceId} created at POD ${c.invoiceDate} · Net ${c.termsDays} · cash expected ${c.dueDate}`}
      </p>

      <div className="mt-3 flex h-2 w-full overflow-hidden rounded-full bg-muted" aria-hidden="true">
        <div className="grow-x h-full bg-muted-foreground/30" style={{ width: `${invoicePct}%` }} />
        <div className="grow-x h-full flex-1 bg-primary" style={{ animationDelay: "500ms" }} />
      </div>
      <div className="mt-1.5 flex text-[11px] tabular-nums text-muted-foreground">
        <span className="shrink-0" style={{ width: `${invoicePct}%` }}>
          <span className="block font-medium text-foreground">PO</span>
          {c.poDate}
        </span>
        <span className="flex flex-1 justify-between gap-2">
          <span>
            <span className="block font-medium text-foreground">{`Invoice · day ${c.toInvoiceDays}`}</span>
            {c.invoiceDate}
          </span>
          <span className="text-right">
            <span className="block font-medium text-primary">{`Due · day ${c.totalDays}`}</span>
            {c.dueDate}
          </span>
        </span>
      </div>
    </section>
  );
}
