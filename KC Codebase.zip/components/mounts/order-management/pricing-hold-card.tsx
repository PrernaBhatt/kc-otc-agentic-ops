"use client";

import { useState } from "react";
import { CircleCheck, Mail, MailCheck, PauseCircle, PenLine, Scale } from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ControlTag } from "@/components/shared/control-tag";
import { GateSignoffModal } from "@/components/shared/gate-signoff-modal";
import { OwnerChip } from "@/components/shared/owner-chip";
import { ContractPriceOutputs } from "@/components/mounts/order-management/contract-price-outputs";
import { PRICE_AGREEMENT_FILE, priceAgreementPages } from "@/components/mounts/order-management/price-agreement-pdf";
import { EmailDraftDialog } from "@/components/shared/email-draft-dialog";
import { pricingHoldCase, pricingHoldTotals } from "@/lib/data/pipeline-orders";
import { formatMoney } from "@/lib/selectors";

/**
 * Scenario 2: line-level contract-price validation found PO prices above
 * Target's agreement. The perfect-invoice rule bills at K-C's contract price;
 * the owner signs, the order is repriced and the gap is recorded.
 */
export function PricingHoldCard({
  awaiting,
  released,
  onRelease,
}: {
  awaiting: boolean;
  released: boolean;
  onRelease: () => void;
}) {
  const c = pricingHoldCase;
  const t = pricingHoldTotals;
  const [signOpen, setSignOpen] = useState(false);
  const [notifyOpen, setNotifyOpen] = useState(false);
  const [notified, setNotified] = useState(false);

  return (
    <Card className={awaiting ? "border-amber-300 shadow-md" : ""} data-price-decision={released ? "contract" : undefined}>
      <CardHeader className="pb-2">
        <CardTitle className="flex flex-wrap items-center gap-2 text-sm">
          <AgentIcon type="pricing" size="sm" /> Contract-price validation
          <ControlTag controlRef={c.controlRef} />
          {awaiting ? (
            <Badge
              variant="outline"
              className="ml-auto whitespace-nowrap border-amber-200 bg-amber-50 text-xs text-amber-700"
            >
              <PauseCircle className="h-3 w-3" /> PO on hold
            </Badge>
          ) : released ? (
            <Badge className="ml-auto whitespace-nowrap bg-[var(--success)] text-xs text-white">
              <CircleCheck className="h-3 w-3" /> Billed at contract
            </Badge>
          ) : null}
        </CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col gap-3 text-sm">
        <div className="rounded-md border border-amber-200 bg-amber-50 p-3 text-xs leading-relaxed text-amber-800">
          <span className="font-semibold">Exception:</span> {c.exception}. {c.poNumber} is on hold; 4 of 4 lines
          are above agreement {c.contract}.
        </div>

        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Product</TableHead>
              <TableHead className="text-right">Qty</TableHead>
              <TableHead className="text-right">Contract</TableHead>
              <TableHead className="text-right">PO price</TableHead>
              <TableHead className="text-right">Variance</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {c.lines.map((l) => (
              <TableRow key={l.sku}>
                <TableCell className="font-medium">{l.productName}</TableCell>
                <TableCell className="text-right tabular-nums">{l.qty.toLocaleString()}</TableCell>
                <TableCell className="text-right tabular-nums">{formatMoney(l.contractPrice)}</TableCell>
                <TableCell className="text-right tabular-nums text-amber-700">{formatMoney(l.poPrice)}</TableCell>
                <TableCell className="text-right font-medium tabular-nums text-amber-700">
                  +{formatMoney(l.variance)}
                </TableCell>
              </TableRow>
            ))}
            <TableRow>
              <TableCell colSpan={4} className="font-semibold">
                Total variance
              </TableCell>
              <TableCell className="text-right font-bold tabular-nums text-amber-700">
                {formatMoney(t.variance)}
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell colSpan={4} className="text-xs text-muted-foreground">
                Policy
              </TableCell>
              <TableCell className="text-right text-xs font-medium text-foreground">
                Gap {formatMoney(t.variance)} {">"} {formatMoney(c.tolerancePerOrderUsd)} tolerance · bill at K-C price
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>

        <div className="grid items-stretch gap-2 md:grid-cols-2">
          <div className="flex h-full flex-col rounded-md bg-muted/50 p-3">
            <div className="text-xs text-muted-foreground">Likely driver</div>
            <div className="font-medium">{c.likelyDriver}</div>
            <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{c.driverDetail}</p>
          </div>
          <div className="flex h-full flex-col rounded-md border border-amber-200 bg-amber-50/60 p-3">
            <div className="flex items-center gap-1.5 text-xs text-amber-800">
              <Scale className="h-3.5 w-3.5" /> If billed at PO price
            </div>
            <div className="font-medium text-foreground">{formatMoney(t.poTotal)} invoiced</div>
            <p className="mt-1 text-xs leading-relaxed text-amber-800">{c.ifBilledAtPo}</p>
          </div>
        </div>

        <div className="flex flex-col gap-2 rounded-md border bg-background p-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              Agent recommendation
            </span>
            <div className="flex flex-col items-end gap-1.5">
              <OwnerChip account={c.accountId} />
              <Button
                size="sm"
                variant="outline"
                onClick={() => setNotifyOpen(true)}
                disabled={notified}
                className="h-7 gap-1.5 whitespace-nowrap text-xs"
              >
                {notified ? <MailCheck className="h-3.5 w-3.5" /> : <Mail className="h-3.5 w-3.5" />}
                {notified ? "Customer notified" : "Notify customer"}
              </Button>
            </div>
          </div>
          <p className="font-medium text-foreground">{c.recommendation}</p>
          {awaiting && (
            <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
              <span className="text-xs text-muted-foreground">{`Awaiting ${c.approver}'s signature.`}</span>
              <Button size="sm" onClick={() => setSignOpen(true)} className="h-8 gap-1.5 whitespace-nowrap text-xs">
                <PenLine className="h-3.5 w-3.5" /> Sign &amp; bill at contract
              </Button>
            </div>
          )}
        </div>

        {released && <ContractPriceOutputs />}
      </CardContent>

      {notifyOpen && (
        <EmailDraftDialog
          to={c.buyer.email}
          toOrg={`${c.buyer.name} · ${c.buyer.role}`}
          subject={`${c.poNumber} billed at K-C contract price ${c.contract}`}
          body={`Hi ${c.buyer.name.split(" ")[0]},\n\nWe are billing ${c.poNumber} at the Kimberly-Clark contract price under agreement ${c.contract}, ${formatMoney(t.contractTotal)}. Four lines on the PO were priced ${formatMoney(t.variance)} above contract. The agreement is attached for reference.\n\nIf you have any concerns, please reach out to us.\n\nThank you,\n${c.approver}\nKimberly-Clark Order Management`}
          attachment={{ name: PRICE_AGREEMENT_FILE, meta: `Price agreement · ${c.contract} · 1 page`, pages: priceAgreementPages() }}
          sentLabel="Customer notified"
          onSend={() => {
            setNotified(true);
            setNotifyOpen(false);
          }}
          onClose={() => setNotifyOpen(false)}
        />
      )}

      <GateSignoffModal
        open={signOpen}
        onClose={() => setSignOpen(false)}
        gateId={`${c.orderId}:G1`}
        title="Bill Target at contract price"
        documentNo={`${c.orderId} · ${c.decisionId}`}
        caseId={c.orderId}
        accountId={c.accountId}
        module="Orders"
        system="SAP S/4HANA"
        controls={[c.controlRef]}
        evidence={[
          { id: "contract", label: `Price agreement ${c.contract}`, system: "PricerX" },
          { id: "po", label: `Customer purchase order ${c.poNumber}`, system: "Outlook" },
          { id: "so", label: `Sales order ${c.orderId}, pricing conditions`, system: "SAP S/4HANA" },
        ]}
        lines={[{ label: "Price gap recorded", amountUsd: t.variance, kind: "other" }]}
        attestation={`I approve billing ${c.poNumber} at contract ${c.contract}, ${formatMoney(t.contractTotal)}, and recording the ${formatMoney(t.variance)} gap as ${c.discrepancyRecordId}.`}
        confirmLabel="Sign & bill at contract"
        action={`Billed ${c.orderId} at contract price ${formatMoney(t.contractTotal)}; recorded ${c.discrepancyRecordId}`}
        decision="Bill at contract"
        form={{
          formNo: "OTC-PR-07",
          formTitle: "Price variance approval",
          documentNo: c.decisionId,
          fields: [
            { label: "Sold-to", value: "Target Corporation" },
            { label: "Customer PO", value: c.poNumber, mono: true },
            { label: "Sales order", value: c.orderId, mono: true },
            { label: "Price agreement", value: c.contract, mono: true },
            { label: "Order value at PO price", value: formatMoney(t.poTotal) },
            { label: "Order value at contract price", value: formatMoney(t.contractTotal) },
            { label: "Tolerance per order", value: formatMoney(c.tolerancePerOrderUsd) },
            { label: "Discrepancy record", value: c.discrepancyRecordId, mono: true },
          ],
          table: {
            columns: [
              { key: "sku", label: "Material", mono: true },
              { key: "name", label: "Description" },
              { key: "qty", label: "Qty (CS)", align: "right" },
              { key: "po", label: "PO price", align: "right" },
              { key: "contract", label: "Contract price", align: "right" },
              { key: "variance", label: "Variance", align: "right" },
            ],
            rows: c.lines.map((l) => ({
              sku: l.sku,
              name: l.productName,
              qty: l.qty.toLocaleString(),
              po: formatMoney(l.poPrice),
              contract: formatMoney(l.contractPrice),
              variance: formatMoney(l.variance),
            })),
            total: { label: "Total variance", value: formatMoney(t.variance) },
          },
          basis: `The total variance of ${formatMoney(t.variance)} exceeds the ${formatMoney(c.tolerancePerOrderUsd)} per-order tolerance. Per K-C pricing policy the order is invoiced at agreement ${c.contract} prices and the buyer is notified to update its price file. Cause: ${c.discrepancyReason.toLowerCase()}.`,
        }}
        onSigned={() => {
          setSignOpen(false);
          onRelease();
        }}
      />
    </Card>
  );
}
