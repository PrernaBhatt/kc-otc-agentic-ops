"use client";

import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { CheckCircle2, Mail, Paperclip, Truck, X } from "lucide-react";

import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { buildPodDoc } from "@/lib/docs";
import type { Order } from "@/lib/data/types";
import { deliveredShipmentFor } from "@/lib/data/shipments";

/**
 * Incoming-email notice that slides in from the corner: "Received proof of
 * delivery from the carrier" with a short preview. Clicking it opens the full
 * email. This precedes the modal so mail arrives, it doesn't just appear.
 */
export function PodEmailNotice({
  order,
  onOpen,
  onDismiss,
}: {
  order: Order;
  onOpen: () => void;
  onDismiss: () => void;
}) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  if (!mounted) return null;

  return createPortal(
    <div className="fixed bottom-6 right-6 z-40 w-80 animate-slide-in-right">
      <div className="relative rounded-xl border bg-card shadow-2xl overflow-hidden">
        <button
          type="button"
          onClick={onOpen}
          className="w-full text-left"
        >
          <div className="flex items-center gap-2 border-b px-4 py-2.5">
            <span className="relative flex h-8 w-8 items-center justify-center rounded-full bg-[var(--info)]/10 text-[var(--info)]">
              <Mail className="h-4 w-4" />
              <span className="absolute -right-0.5 -top-0.5 h-2.5 w-2.5 rounded-full bg-primary animate-agent-pulse" />
            </span>
            <div className="min-w-0">
              <div className="text-sm font-semibold">
                Received proof of delivery
              </div>
              <div className="text-xs text-muted-foreground truncate">
                from the carrier
              </div>
            </div>
          </div>
          <div className="px-4 py-3 space-y-1">
            <div className="text-xs text-muted-foreground">
              Blue Line Freight — Dispatch
            </div>
            <div className="text-sm font-medium truncate">
              Proof of delivery — {order.orderId}
            </div>
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Paperclip className="h-3 w-3 shrink-0" />
              Signed PDF attached
            </div>
          </div>
          <div className="border-t bg-muted/30 px-4 py-2 text-xs font-medium text-primary">
            Open email to review →
          </div>
        </button>
        <button
          type="button"
          onClick={onDismiss}
          className="absolute right-2 top-2 text-muted-foreground/60 hover:text-foreground"
          aria-label="Dismiss"
        >
          <X className="h-3.5 w-3.5" />
        </button>
      </div>
    </div>,
    document.body
  );
}

/** Email meta (From / To / Cc / Subject) and body — shared by every email in the demo. */
export function EmailMessage({
  from,
  to,
  cc,
  subject,
  sentAt,
  children,
}: {
  from: string;
  to: string;
  cc?: string;
  subject: string;
  sentAt?: string;
  children: React.ReactNode;
}) {
  const rows: [string, string, boolean][] = [
    ["From", from, true],
    ["To", to, false],
    ...(cc ? ([["Cc", cc, false]] as [string, string, boolean][]) : []),
    ["Subject", subject, true],
    ...(sentAt ? ([["Sent", sentAt, false]] as [string, string, boolean][]) : []),
  ];
  return (
    <>
      <div className="space-y-1 border-b px-5 py-3 text-sm">
        {rows.map(([label, value, strong]) => (
          <div key={label} className="flex gap-2">
            <span className="w-16 shrink-0 text-muted-foreground">{label}</span>
            <span className={strong ? "font-medium" : undefined}>{value}</span>
          </div>
        ))}
      </div>
      <div className="px-5 py-4 text-sm text-foreground space-y-3">{children}</div>
    </>
  );
}

/**
 * Full incoming proof-of-delivery email (opened from the notice). Read-only
 * evidence — the human confirms the delivery on the POD stage of the order,
 * which is what closes the Order Management workflow and unlocks billing.
 */
export function PodEmailModal({
  order,
  onClose,
}: {
  order: Order;
  onClose: () => void;
}) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  if (!mounted) return null;

  const shipment = deliveredShipmentFor(order.orderId, order.customerName);

  return createPortal(
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-6 text-left"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg rounded-xl border bg-card shadow-2xl animate-modal-in"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Email header */}
        <div className="flex items-center justify-between border-b px-5 py-3">
          <div className="flex items-center gap-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[var(--info)]/10 text-[var(--info)]">
              <Mail className="h-4 w-4" />
            </span>
            <div>
              <div className="text-sm font-semibold">New email — Proof of Delivery</div>
              <div className="text-xs text-muted-foreground">Just arrived</div>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        <EmailMessage
          from="Blue Line Freight — Dispatch"
          to="Order Management Team"
          subject={`Proof of delivery — ${order.orderId} (${order.customerName})`}
        >
          <p>Hello team,</p>
          <p>
            Order {order.orderId} for {order.customerName} was delivered today
            and signed for on arrival. The signed proof of delivery is attached
            for your records — confirm the delivery on the order to unlock
            billing.
          </p>
          <div className="flex items-center gap-2 rounded-md border bg-muted/40 px-3 py-2">
            <Paperclip className="h-4 w-4 text-muted-foreground shrink-0" />
            <span className="text-sm">Proof_of_Delivery_{order.orderId}.pdf</span>
            <Badge
              variant="outline"
              className="ml-auto whitespace-nowrap border-green-300 bg-green-50 text-green-700"
            >
              Signed
            </Badge>
          </div>
          <SourceDocTrigger
            doc={buildPodDoc(shipment)}
            label="Open the proof of delivery"
            className="w-full"
          />
        </EmailMessage>

        {/* The email is evidence only — the human confirms on the POD stage. */}
        <div className="flex items-center justify-between gap-3 border-t bg-muted/20 px-5 py-3">
          <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Truck className="h-3.5 w-3.5" />
            AI matched this email to {order.orderId}
          </span>
          <Button
            variant="outline"
            onClick={onClose}
            className="whitespace-nowrap"
          >
            Close
          </Button>
        </div>
      </div>
    </div>,
    document.body
  );
}
