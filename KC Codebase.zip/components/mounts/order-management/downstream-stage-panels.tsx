"use client";

import {
  ArrowRight,
  CheckCircle2,
  Clock,
  FileText,
  Mail,
  Package,
  Receipt,
  ShieldCheck,
  TriangleAlert,
  Truck,
} from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { TODAY, daysBetween } from "@/lib/data/clock";
import {
  findShipmentByOrder,
  podShipmentFor,
  type Shipment,
} from "@/lib/data/shipments";
import type { Invoice, Order } from "@/lib/data/types";
import { buildInvoiceDoc, buildPodDoc, buildSalesOrderDoc } from "@/lib/docs";
import { formatMoney } from "@/lib/selectors";
import { cn } from "@/lib/utils";

interface StageProps {
  order: Order;
  invoice?: Invoice;
  onAdvance?: () => void;
  nextLabel?: string;
}

function AdvanceBar({
  note,
  onAdvance,
  nextLabel,
}: {
  note: string;
  onAdvance?: () => void;
  nextLabel?: string;
}) {
  return (
    <div className="flex items-center justify-between gap-3 border-t pt-3">
      <span className="text-xs text-muted-foreground">{note}</span>
      {onAdvance && nextLabel && (
        <Button size="sm" className="whitespace-nowrap" onClick={onAdvance}>
          Continue to {nextLabel}
          <ArrowRight className="h-4 w-4" />
        </Button>
      )}
    </div>
  );
}

function PanelHead({
  icon,
  title,
  right,
}: {
  icon: React.ReactNode;
  title: string;
  right?: React.ReactNode;
}) {
  return (
    <div className="flex items-center gap-2">
      {icon}
      <span className="text-sm font-semibold">{title}</span>
      {right && <span className="ml-auto">{right}</span>}
    </div>
  );
}

/** Three-node process ribbon used by several stages. */
function ProcessRibbon({
  steps,
}: {
  steps: { label: string; done: boolean }[];
}) {
  return (
    <div className="flex items-center">
      {steps.map((s, i) => (
        <div key={s.label} className="flex flex-1 items-center">
          <div className="flex flex-col items-center gap-1 text-center">
            <span
              className={cn(
                "flex h-7 w-7 items-center justify-center rounded-full",
                s.done
                  ? "bg-[var(--success)] text-white"
                  : "bg-muted text-muted-foreground"
              )}
            >
              {s.done ? (
                <CheckCircle2 className="h-4 w-4" />
              ) : (
                <Clock className="h-4 w-4" />
              )}
            </span>
            <span className="text-[11px] leading-tight text-muted-foreground">
              {s.label}
            </span>
          </div>
          {i < steps.length - 1 && (
            <div
              className={cn(
                "mx-1 h-0.5 flex-1 rounded-full",
                s.done ? "bg-[var(--success)]" : "bg-border"
              )}
            />
          )}
        </div>
      ))}
    </div>
  );
}

/* ── POD: received → AI validates → billing unlocked ──────────────────
   The closing stage of the Order Management workflow. The agent matches and
   checks the carrier's proof of delivery; the human confirms it here, and that
   confirmation is what unlocks the separate Billing workflow.               */
export function PodStagePanel({
  order,
  confirmed = false,
  onConfirm,
}: StageProps & { confirmed?: boolean; onConfirm?: () => void }) {
  const shipment: Shipment = podShipmentFor(order.orderId, order.customerName);
  return (
    <Card className="animate-enter">
      <CardContent className="p-4 space-y-4">
        <PanelHead
          icon={<Truck className="h-4 w-4 text-[var(--success)]" />}
          title="Proof of delivery"
          right={
            <Badge className="bg-[var(--success)] text-white">
              Delivered &amp; signed
            </Badge>
          }
        />
        <ProcessRibbon
          steps={[
            { label: "POD received", done: true },
            { label: "AI validates", done: true },
            { label: "Billing unlocked", done: confirmed },
          ]}
        />
        <div className="rounded-md border bg-muted/30 p-3 text-sm">
          The AI matched the carrier&apos;s signed proof of delivery to{" "}
          <span className="font-mono font-medium">{order.orderId}</span> and
          checked the delivered quantity against the order. Signed by{" "}
          {shipment.podSignedBy} on {shipment.deliveredDate}.
        </div>
        <SourceDocTrigger
          doc={buildPodDoc(shipment)}
          label="View proof of delivery"
        />
        {confirmed ? (
          /* The last word of the workflow — sized to match the stage heading. */
          <div className="flex items-center gap-2 border-t pt-3">
            <CheckCircle2 className="h-5 w-5 shrink-0 text-[var(--success)]" />
            <span className="text-sm font-semibold text-foreground">
              Delivery validated — billing unlocked
            </span>
          </div>
        ) : (
          <div className="flex items-center justify-between gap-3 border-t pt-3">
            <span className="text-xs text-muted-foreground">
              Your confirmation closes the order and unlocks billing.
            </span>
            <Button
              size="sm"
              className="whitespace-nowrap"
              onClick={onConfirm}
            >
              <CheckCircle2 className="h-4 w-4" />
              Confirm delivery
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/* ── Billing: PO = SO = Shipped = Invoice reconciliation ──────────── */
export function BillingStagePanel({
  order,
  invoice,
  onAdvance,
  nextLabel,
}: StageProps) {
  const qty = order.lineItems.reduce((s, l) => s + l.qty, 0);
  const rows = [
    { label: "Purchase order", ref: `PO-${order.orderId.replace("SO-", "")}`, qty },
    { label: "Sales order", ref: order.orderId, qty },
    { label: "Shipped", ref: "Delivery record", qty },
    { label: "Invoice", ref: invoice?.invoiceId ?? "Draft", qty },
  ];
  const allMatch = true;
  return (
    <Card className="animate-enter">
      <CardContent className="p-4 space-y-4">
        <PanelHead
          icon={<Receipt className="h-4 w-4 text-[var(--info)]" />}
          title="PO–SO–Shipment–Invoice reconciliation"
          right={
            invoice ? (
              <Badge className="bg-[var(--success)] text-white">
                {invoice.invoiceId} issued
              </Badge>
            ) : undefined
          }
        />
        {/* Quantity reconciliation — every document must agree */}
        <div className="space-y-1.5">
          {rows.map((r, i) => (
            <div key={r.label} className="flex items-center gap-2">
              <div className="flex flex-1 items-center justify-between rounded-md border border-green-200 bg-green-50/50 px-3 py-1.5 text-sm">
                <span className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-green-600 shrink-0" />
                  <span className="text-xs uppercase tracking-wide text-muted-foreground">
                    {r.label}
                  </span>
                  <span className="font-mono text-xs font-semibold">{r.ref}</span>
                </span>
                <span className="font-semibold">
                  Qty {r.qty.toLocaleString()}
                </span>
              </div>
              {i < rows.length - 1 && (
                <span className="w-4 text-center text-sm font-bold text-green-600">
                  =
                </span>
              )}
            </div>
          ))}
        </div>
        <div
          className={cn(
            "rounded-md border p-2.5 text-center text-sm font-medium",
            allMatch
              ? "border-[var(--success)]/30 bg-[var(--success)]/5 text-[var(--success)]"
              : "border-amber-300 bg-amber-50 text-amber-700"
          )}
        >
          {allMatch
            ? `All four documents agree at ${qty.toLocaleString()} units · ${formatMoney(order.totalValue)} — invoice ${invoice ? "issued" : "ready to issue"}.`
            : "Mismatch detected — held for review."}
        </div>
        <div className="flex gap-2">
          {invoice && (
            <SourceDocTrigger
              doc={buildInvoiceDoc(invoice)}
              label={`View invoice ${invoice.invoiceId}`}
            />
          )}
          <SourceDocTrigger doc={buildSalesOrderDoc(order)} label="View sales order" />
        </div>
        <AdvanceBar
          note="Documents reconciled — invoice sent."
          onAdvance={onAdvance}
          nextLabel={nextLabel}
        />
      </CardContent>
    </Card>
  );
}

/* ── Customer Service Hub: incoming email → AI triage ─────────────── */
export function ServiceStagePanel({ order, onAdvance, nextLabel }: StageProps) {
  return (
    <Card className="animate-enter">
      <CardContent className="p-4 space-y-4">
        <PanelHead
          icon={<Mail className="h-4 w-4 text-[var(--info)]" />}
          title="Customer query triage"
          right={
            <Badge
              variant="outline"
              className="border-[var(--success)]/40 text-[var(--success)]"
            >
              No open questions
            </Badge>
          }
        />
        <p className="text-sm text-muted-foreground">
          No question is open for {order.orderId}. When one arrives, the Query
          Triage Agent classifies and routes it in seconds — here is how it
          handled a recent example:
        </p>
        {/* Sample incoming email being triaged */}
        <div className="rounded-lg border bg-muted/20 p-3 space-y-3">
          <div className="text-sm">
            <span className="text-xs text-muted-foreground">Email from </span>
            <span className="font-medium">{order.customerName}</span>
            <div className="mt-1 rounded-md bg-background p-2 italic">
              &ldquo;The invoice amount appears incorrect.&rdquo;
            </div>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {[
              { k: "Category", v: "Billing" },
              { k: "Priority", v: "High" },
              { k: "Owner", v: "Billing Team" },
            ].map((c) => (
              <div key={c.k} className="rounded-md bg-background p-2 text-center">
                <div className="text-[11px] text-muted-foreground">{c.k}</div>
                <div className="text-sm font-semibold">{c.v}</div>
              </div>
            ))}
          </div>
          <div className="rounded-md border-l-4 border-l-[var(--info)] bg-[var(--info)]/5 p-2 text-sm">
            <span className="font-medium">Suggested reply: </span>
            The invoice reflects the delivered quantity and your contract price.
            We&apos;ve attached the tie-out showing the order, delivery and
            invoice all agree — happy to walk through any line.
          </div>
        </div>
        <AdvanceBar
          note="AI drafts every reply; a person approves before it sends."
          onAdvance={onAdvance}
          nextLabel={nextLabel}
        />
      </CardContent>
    </Card>
  );
}

/* ── Cash Application: payment arrives → auto-matched to invoice ───── */
export function CashStagePanel({
  order,
  invoice,
  onAdvance,
  nextLabel,
}: StageProps) {
  const issued = invoice?.invoiceDate ?? TODAY;
  const due = invoice?.dueDate ?? TODAY;
  const total = daysBetween(issued, due) || 30;
  const elapsed = Math.max(0, Math.min(total, daysBetween(issued, TODAY)));
  const pct = Math.round((elapsed / total) * 100);
  return (
    <Card className="animate-enter">
      <CardContent className="p-4 space-y-4">
        <PanelHead
          icon={<AgentIcon type="credit" size="sm" />}
          title="Cash application"
          right={
            <Badge
              variant="outline"
              className="border-[var(--warning)]/50 bg-[var(--warning)]/10 text-[var(--warning-foreground)]"
            >
              Awaiting payment
            </Badge>
          }
        />
        {invoice && (
          <>
            <div className="flex items-center justify-between text-sm">
              <span>
                Invoice{" "}
                <span className="font-mono font-semibold">
                  {invoice.invoiceId}
                </span>{" "}
                sent
              </span>
              <span className="font-semibold">{formatMoney(invoice.amount)}</span>
            </div>
            <div className="space-y-1">
              <div className="relative h-2 rounded-full bg-muted overflow-hidden">
                <div
                  className="absolute h-full rounded-full bg-[var(--warning)]"
                  style={{ width: `${pct}%` }}
                />
              </div>
              <div className="flex justify-between text-[11px] text-muted-foreground">
                <span>Issued {issued}</span>
                <span>Due {due}</span>
              </div>
            </div>
          </>
        )}
        {/* How the Cash Application Agent works when payment lands */}
        <div className="rounded-lg border bg-muted/20 p-3 space-y-2">
          <div className="text-xs font-semibold text-muted-foreground">
            When the payment arrives, the Cash Application Agent
          </div>
          {[
            "Reads the daily bank statement file and captures the remittance",
            "Identifies the customer and matches the payment to the open invoice",
            "Posts the matched receipt and clears the invoice — you approve first",
            "Routes short-paid or unidentified receipts to the exception queue",
          ].map((t, i) => (
            <div key={i} className="flex items-start gap-2 text-sm">
              <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-[var(--info)]" />
              {t}
            </div>
          ))}
          <div className="flex items-center gap-2 pt-1">
            <Badge className="bg-[var(--success)] text-white">
              95% auto-matched
            </Badge>
            <span className="text-xs text-muted-foreground">
              this month · exceptions routed for review
            </span>
          </div>
        </div>
        <AdvanceBar
          note="Payment not yet received."
          onAdvance={onAdvance}
          nextLabel={nextLabel}
        />
      </CardContent>
    </Card>
  );
}

/* ── Deductions: short-pay gap → case → credit memo ───────────────── */
export function DeductionsStagePanel({
  order,
  onAdvance,
  nextLabel,
}: StageProps) {
  // Illustrative short-pay example the Deduction Agent would open.
  const invoiceAmt = 100000;
  const paidAmt = 90000;
  const gap = invoiceAmt - paidAmt;
  return (
    <Card className="animate-enter">
      <CardContent className="p-4 space-y-4">
        <PanelHead
          icon={<ShieldCheck className="h-4 w-4 text-[var(--success)]" />}
          title="Deductions &amp; disputes"
          right={
            <Badge
              variant="outline"
              className="border-[var(--success)]/40 text-[var(--success)]"
            >
              None raised
            </Badge>
          }
        />
        <p className="text-sm text-muted-foreground">
          No deduction has been raised on {order.orderId}. If a customer
          short-pays, the Deduction Agent opens and investigates a case
          automatically — for example:
        </p>
        {/* Payment-vs-invoice gap */}
        <div className="rounded-lg border bg-muted/20 p-3 space-y-3">
          <div className="text-sm">
            Customer paid{" "}
            <span className="font-semibold">{formatMoney(paidAmt)}</span> against
            a <span className="font-semibold">{formatMoney(invoiceAmt)}</span>{" "}
            invoice
          </div>
          <div className="relative h-6 rounded-md bg-muted overflow-hidden">
            <div
              className="absolute inset-y-0 left-0 flex items-center bg-[var(--success)]/70 px-2 text-xs font-medium text-white"
              style={{ width: `${(paidAmt / invoiceAmt) * 100}%` }}
            >
              Paid {formatMoney(paidAmt)}
            </div>
            <div className="absolute inset-y-0 right-0 flex items-center bg-amber-400 px-2 text-xs font-medium text-amber-900"
              style={{ width: `${(gap / invoiceAmt) * 100}%` }}
            >
              {formatMoney(gap)}
            </div>
          </div>
          {/* The 4 things the agent does with the gap */}
          <div className="space-y-1.5">
            {[
              { icon: FileText, t: "Creates a deduction case for the $10,000 short pay" },
              { icon: TriangleAlert, t: "Finds a pricing discrepancy as the root cause" },
              { icon: Package, t: "Retrieves the invoice, order and contract as evidence" },
              { icon: Receipt, t: "Recommends a credit memo for a human to approve" },
            ].map(({ icon: Icon, t }, i) => (
              <div key={i} className="flex items-start gap-2 text-sm">
                <Icon className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[var(--info)]" />
                {t}
              </div>
            ))}
          </div>
        </div>
        <AdvanceBar
          note="No disputes to resolve on this order."
          onAdvance={onAdvance}
          nextLabel={nextLabel}
        />
      </CardContent>
    </Card>
  );
}

/* ── Collections: not yet due, countdown ──────────────────────────── */
export function CollectionsStagePanel({ order, invoice }: StageProps) {
  const due = invoice?.dueDate ?? TODAY;
  const daysToDue = daysBetween(TODAY, due);
  return (
    <Card className="animate-enter">
      <CardContent className="p-4 space-y-4">
        <PanelHead
          icon={<Clock className="h-4 w-4 text-[var(--info)]" />}
          title="Collections"
          right={
            <Badge
              variant="outline"
              className="border-[var(--info)]/40 bg-[var(--info)]/10 text-[var(--info)]"
            >
              Not yet due
            </Badge>
          }
        />
        <div className="flex flex-col items-center gap-1 py-2 text-center">
          <div className="text-3xl font-bold text-foreground">
            {daysToDue > 0 ? daysToDue : 0}
          </div>
          <div className="text-sm text-muted-foreground">days until due</div>
        </div>
        <p className="text-sm text-muted-foreground text-center max-w-sm mx-auto">
          {order.orderId} is not overdue, so no collection action is needed yet.
          The Collections Agent will rank it by value, days late and customer
          risk and draft a reminder if it approaches the due date unpaid.
        </p>
        <div className="rounded-md border border-[var(--success)]/30 bg-[var(--success)]/5 p-3 text-center text-sm text-[var(--success)]">
          Order-to-cash complete through billing — the thread continues on its
          own from here.
        </div>
      </CardContent>
    </Card>
  );
}
