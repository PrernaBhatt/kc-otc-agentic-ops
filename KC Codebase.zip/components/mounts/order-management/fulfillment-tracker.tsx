"use client";

import { TriangleAlert } from "lucide-react";

import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  shipments,
  findShipmentByOrder,
  type Shipment,
} from "@/lib/data/shipments";
import { buildPodDoc } from "@/lib/docs";

function statusBadgeClass(status: Shipment["status"]) {
  switch (status) {
    case "Delivered":
      return "bg-green-100 text-green-700 border-green-200";
    case "Delayed":
      return "bg-amber-50 text-amber-700 border-amber-200";
    case "In Transit":
      return "bg-blue-50 text-blue-700 border-blue-200";
    default:
      return "bg-gray-50 text-gray-600 border-gray-200";
  }
}

export function ShipmentCard({ shipment }: { shipment: Shipment }) {
  return (
    <Card className="h-full flex flex-col gap-0 py-0 overflow-hidden hover:shadow-md transition-shadow">
      <CardContent className="p-5 flex-1 flex flex-col gap-4">
        <div className="flex items-start justify-between gap-2">
          <div className="space-y-0.5">
            <h4 className="font-semibold text-sm">{shipment.shipmentId}</h4>
            <p className="text-xs text-muted-foreground">
              {shipment.orderId} · {shipment.customerName}
            </p>
          </div>
          <Badge
            variant="outline"
            className={["text-xs", statusBadgeClass(shipment.status)].join(" ")}
          >
            {shipment.status}
          </Badge>
        </div>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <div className="text-xs text-muted-foreground">Carrier</div>
            <div className="font-medium">{shipment.carrier}</div>
          </div>
          <div>
            <div className="text-xs text-muted-foreground">
              Promised vs actual
            </div>
            <div className="font-medium">
              {shipment.promisedDate} →{" "}
              {shipment.deliveredDate ?? "Not yet delivered"}
            </div>
          </div>
        </div>
        {shipment.status === "Delayed" && (
          <Badge
            variant="outline"
            className="whitespace-normal text-left bg-amber-50 text-amber-700 border-amber-200 text-xs"
          >
            <TriangleAlert className="h-3 w-3 shrink-0" />
            {shipment.delayDays} days late — {shipment.delayReason}
          </Badge>
        )}
        <div className="space-y-1.5">
          {shipment.milestones.map((milestone) => (
            <div key={milestone.id} className="flex items-start gap-2 text-xs">
              {milestone.done ? (
                <span className="mt-0.5 h-2.5 w-2.5 rounded-full bg-[var(--success)] shrink-0" />
              ) : (
                <span className="mt-0.5 h-2.5 w-2.5 rounded-full border-2 border-muted-foreground/40 bg-background shrink-0" />
              )}
              <span
                className={
                  milestone.done
                    ? "text-foreground"
                    : "text-muted-foreground"
                }
              >
                {milestone.label}
              </span>
            </div>
          ))}
        </div>
        <div className="mt-auto pt-1">
          <SourceDocTrigger
            doc={buildPodDoc(shipment)}
            label={
              shipment.status === "Delivered"
                ? "View proof of delivery"
                : "View delivery record"
            }
            className="w-full"
          />
        </div>
      </CardContent>
    </Card>
  );
}

/**
 * Fulfillment stage panel for one order: its shipment tracking card, or a
 * plain placeholder when the order has not been shipped yet.
 */
export function OrderShipmentCard({ orderId }: { orderId: string }) {
  const shipment = findShipmentByOrder(orderId);
  if (!shipment) {
    return (
      <Card className="border-dashed">
        <CardContent className="p-4 text-sm text-muted-foreground">
          Not yet shipped — a shipment is planned once the order is released.
        </CardContent>
      </Card>
    );
  }
  return <ShipmentCard shipment={shipment} />;
}

/**
 * Standalone tracker grid (kept for any full-catalog view). The Order
 * Management page now shows one card per order inside the Fulfillment stage.
 */
export function FulfillmentTracker() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {shipments.map((shipment) => (
        <ShipmentCard key={shipment.shipmentId} shipment={shipment} />
      ))}
    </div>
  );
}
