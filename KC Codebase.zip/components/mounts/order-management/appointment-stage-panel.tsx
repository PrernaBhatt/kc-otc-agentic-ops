"use client";

import { RetailerAppointmentCard } from "@/components/mounts/order-management/order-evidence";
import { RevealWhen } from "@/components/mounts/order-management/step-reasoning";
import { orderLogistics } from "@/lib/data/order-logistics";

/**
 * The Appointment step: Shipment planning already read the TMS plan, so the
 * agent filters the retailer calendar by the customer's OTIF rule, books the
 * first open slot after the ETA and blocks the calendar (types in).
 */
export function AppointmentStagePanel({ orderId, phase }: { orderId: string; phase: number }) {
  if (!orderLogistics(orderId)) {
    return (
      <RevealWhen when={phase >= 1}>
        <p className="animate-enter-fade rounded-lg border bg-card px-4 py-3 text-sm leading-relaxed text-muted-foreground">
          Receiving slot booked against the TMS plan, inside the OTIF window.
        </p>
      </RevealWhen>
    );
  }
  return (
    <div className="flex flex-col gap-3" data-stage="appointment">
      <RevealWhen when={phase >= 1}>
        <RetailerAppointmentCard orderId={orderId} phase={phase} />
      </RevealWhen>
    </div>
  );
}
