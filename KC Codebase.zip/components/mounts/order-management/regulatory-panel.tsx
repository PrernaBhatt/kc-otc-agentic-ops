"use client";

import { CircleCheck, TriangleAlert } from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { findInboundPo } from "@/lib/data/pipeline-orders";
import {
  recallNotices,
  regulatoryReviews,
  type RegulatoryCheckItem,
} from "@/lib/data/regulatory";
import { buildInboundPoDoc, buildRecallNoticeDoc } from "@/lib/docs";
import { useOtcStore } from "@/lib/store";

function resultChipClass(result: RegulatoryCheckItem["result"]) {
  switch (result) {
    case "Pass":
      return "bg-green-100 text-green-700 border-green-200";
    case "Attention":
      return "bg-amber-50 text-amber-700 border-amber-200";
    default:
      return "bg-red-50 text-red-700 border-red-200";
  }
}

/**
 * S3 — Regulatory & Product Checks stage panel. Shows the check rows for the
 * order; when the order sits on a quality-held lot it renders the amber
 * "Quality hold — needs human decision" pause. The release decision itself is
 * made in Review Order Hold; this panel reflects it via the shared store.
 */
/** The four product checks shown for every order (defaults to all-clear). */
const DEFAULT_CHECKS: RegulatoryCheckItem[] = [
  {
    id: "REG-1",
    question: "Is any product under recall?",
    result: "Pass",
    finding: "No line references a recalled or held lot.",
  },
  {
    id: "REG-2",
    question: "Is a quality release available?",
    result: "Pass",
    finding: "Every product has a current quality release on file.",
  },
  {
    id: "REG-3",
    question: "Is any product restricted?",
    result: "Pass",
    finding: "No restricted or license-controlled products on this order.",
  },
  {
    id: "REG-4",
    question: "Is any SKU allocation-controlled?",
    result: "Pass",
    finding: "No allocation-controlled products on this order.",
  },
];

export function RegulatoryPanel({ orderId }: { orderId: string }) {
  const { releasedRegulatoryOrders } = useOtcStore();
  const review = regulatoryReviews.find((r) => r.orderId === orderId);
  const checks = review?.checks ?? DEFAULT_CHECKS;
  const po = findInboundPo(orderId);
  const released = releasedRegulatoryOrders.has(orderId);
  const onHold = review?.overall === "Hold" && !released;

  return (
    <Card className={onHold ? "border-amber-300 shadow-md" : ""}>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm flex items-center gap-2">
          <AgentIcon type="document" size="sm" /> Regulatory &amp; Product
          Checks
          {onHold ? (
            <Badge className="ml-auto bg-amber-100 text-amber-800 border border-amber-300 animate-pulse text-xs whitespace-nowrap">
              Quality hold — needs human decision
            </Badge>
          ) : (
            <Badge className="ml-auto bg-[var(--success)] text-white text-xs">
              Passed
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {checks.map((check) => (
          <div key={check.id} className="p-2 bg-muted/50 rounded text-sm space-y-1">
            <div className="flex items-center justify-between gap-3">
              <span>{check.question}</span>
              <Badge
                variant="outline"
                className={[
                  "whitespace-nowrap text-xs",
                  resultChipClass(
                    released && check.result === "Fail" ? "Pass" : check.result
                  ),
                ].join(" ")}
              >
                {released && check.result === "Fail"
                  ? "Resolved"
                  : check.result}
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground">{check.finding}</p>
          </div>
        ))}
        {review && onHold && (
          <div className="mt-2 rounded-md bg-amber-50 border border-amber-200 p-3 text-xs text-amber-800 space-y-2">
            <div className="flex items-center gap-1.5 font-semibold">
              <TriangleAlert className="h-3.5 w-3.5" /> Quality hold — needs
              human decision
            </div>
            <p>
              The incontinence briefs line sits on lot {review.affectedLot}, which
              Quality Assurance has placed on hold. The pipeline is paused at
              this stage. Decision pending in Review Order Hold.
            </p>
          </div>
        )}
        {review && review.overall === "Hold" && released && (
          <div className="mt-2 rounded-md bg-green-50 border border-green-200 p-3 text-xs text-green-800 space-y-1">
            <div className="flex items-center gap-1.5 font-semibold">
              <CircleCheck className="h-3.5 w-3.5" /> Passed — substitute lot{" "}
              {review.substituteLot}
            </div>
            <p>
              Your release decision in Review Order Hold switched the held line
              to cleared lot {review.substituteLot}. The pipeline can proceed.
            </p>
          </div>
        )}
        <div className="flex flex-wrap items-center gap-2 pt-1">
          {review?.overall === "Hold" && (
            <SourceDocTrigger
              doc={buildRecallNoticeDoc(recallNotices[0])}
              label="View quality hold notice"
              className={
                onHold
                  ? "border-amber-300 text-amber-700 hover:bg-amber-50"
                  : undefined
              }
            />
          )}
          {po && (
            <SourceDocTrigger
              doc={buildInboundPoDoc(
                po,
                review?.overall === "Hold" ? "regulatory" : "extraction"
              )}
              label="View inbound purchase order"
            />
          )}
        </div>
      </CardContent>
    </Card>
  );
}
