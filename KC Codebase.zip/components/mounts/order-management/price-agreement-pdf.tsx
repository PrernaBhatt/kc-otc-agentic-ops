import type { ReactNode } from "react";

import { pricingHoldCase as c, pricingHoldTotals as t } from "@/lib/data/pipeline-orders";
import { formatMoney } from "@/lib/selectors";

/*
 * Print palette of the K-C price agreement. Fixed values on purpose: this is
 * a reproduction of a signed commercial document, not app chrome.
 */
const KC_BLUE = "#003DA5";
const FONT = '"Helvetica Neue", Helvetica, Arial, sans-serif';

export const PRICE_AGREEMENT_FILE = `${c.contract}-price-agreement.pdf`;

function Fields({ rows }: { rows: [string, ReactNode][] }) {
  return (
    <dl className="grid grid-cols-[132px_1fr] gap-x-3 gap-y-1">
      {rows.map(([label, value]) => (
        <div key={label} className="contents">
          <dt className="text-[#5a6170]">{label}</dt>
          <dd className="font-medium">{value}</dd>
        </div>
      ))}
    </dl>
  );
}

function SectionTitle({ children }: { children: ReactNode }) {
  return (
    <h3
      className="mb-2 border-b border-[#d8dce3] pb-1 text-[11px] font-bold uppercase tracking-[0.08em]"
      style={{ color: KC_BLUE }}
    >
      {children}
    </h3>
  );
}

function AgreementPage() {
  return (
    <div className="flex h-full flex-col px-12 pb-8 pt-10 text-[12px] leading-[1.5] text-[#1a1a1a]" style={{ fontFamily: FONT }}>
      <header className="flex items-end justify-between border-b-[3px] pb-3" style={{ borderColor: KC_BLUE }}>
        <div>
          <p className="text-[24px] font-bold tracking-tight" style={{ color: KC_BLUE }}>
            Kimberly-Clark
          </p>
          <p className="text-[11px] text-[#46505e]">North America Commercial · Pricing</p>
        </div>
        <div className="text-right">
          <p className="text-[15px] font-bold">Customer Price Agreement</p>
          <p className="font-mono text-[11px] text-[#46505e]">{c.contract} · Rev. 3</p>
        </div>
      </header>

      <div className="flex flex-col gap-6 pt-5">
        <div className="grid grid-cols-2 gap-8">
          <section>
            <SectionTitle>Parties</SectionTitle>
            <Fields
              rows={[
                ["Supplier", "Kimberly-Clark Corporation"],
                ["Customer", "Target Corporation"],
                ["Customer no.", c.accountId],
                ["Bill-to", "1000 Nicollet Mall, Minneapolis, MN 55403"],
              ]}
            />
          </section>
          <section>
            <SectionTitle>Term</SectionTitle>
            <Fields
              rows={[
                ["Effective", "2026-01-01"],
                ["Expires", "2026-12-31"],
                ["Current revision", "Rev. 3 · effective 2026-07-27"],
                ["Discrepancy window", "Closed 2026-08-10"],
                ["Payment terms", "Net 30"],
              ]}
            />
          </section>
        </div>

        <section>
          <SectionTitle>Schedule A · Contract prices (per case)</SectionTitle>
          <table className="w-full border-collapse text-[11.5px]">
            <thead>
              <tr className="text-left text-[#5a6170]">
                <th className="border-b border-[#d8dce3] py-1.5 font-semibold">Material</th>
                <th className="border-b border-[#d8dce3] py-1.5 font-semibold">Description</th>
                <th className="border-b border-[#d8dce3] py-1.5 text-right font-semibold">Unit</th>
                <th className="border-b border-[#d8dce3] py-1.5 text-right font-semibold">Contract price</th>
              </tr>
            </thead>
            <tbody>
              {c.lines.map((l) => (
                <tr key={l.sku}>
                  <td className="border-b border-[#eef0f3] py-1.5 font-mono">{l.sku}</td>
                  <td className="border-b border-[#eef0f3] py-1.5">{l.productName}</td>
                  <td className="border-b border-[#eef0f3] py-1.5 text-right">CS</td>
                  <td className="border-b border-[#eef0f3] py-1.5 text-right font-semibold tabular-nums">
                    {formatMoney(l.contractPrice)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>

        <section>
          <SectionTitle>Pricing terms</SectionTitle>
          <ol className="flex list-decimal flex-col gap-1.5 pl-5">
            <li>Orders are invoiced at the Schedule A price in effect on the order date.</li>
            <li>
              Where a purchase order price differs from Schedule A by more than {formatMoney(c.tolerancePerOrderUsd)} per
              order, Kimberly-Clark invoices at the Schedule A price and notifies the customer.
            </li>
            <li>Price disputes must be raised within the discrepancy window that follows each revision.</li>
            <li>Deductions taken against Schedule A prices are not valid without a Kimberly-Clark credit memo.</li>
          </ol>
        </section>

        <section className="rounded-sm px-3 py-2 text-[11px]" style={{ backgroundColor: "#e8eef9", color: KC_BLUE }}>
          Applied to {c.poNumber} · {c.orderId}: {formatMoney(t.contractTotal)} at Schedule A prices.
        </section>

        <div className="grid grid-cols-2 gap-8 pt-2">
          {[
            ["For Kimberly-Clark", "Commercial Pricing Lead"],
            ["For Target Corporation", "VP Merchandising, Household Essentials"],
          ].map(([party, title]) => (
            <div key={party} className="flex flex-col gap-1">
              <span className="text-[#5a6170]">{party}</span>
              <span className="border-b border-[#1a1a1a] pb-1 text-[14px] italic">Signed on file</span>
              <span className="text-[11px] text-[#5a6170]">{title} · 2025-12-12</span>
            </div>
          ))}
        </div>
      </div>

      <footer className="mt-auto flex justify-between border-t border-[#d8dce3] pt-2 text-[10px] text-[#5a6170]">
        <span>Kimberly-Clark Corporation · Confidential</span>
        <span>Page 1 of 1</span>
      </footer>
    </div>
  );
}

export function priceAgreementPages(): ReactNode[] {
  return [<AgreementPage key="p1" />];
}
