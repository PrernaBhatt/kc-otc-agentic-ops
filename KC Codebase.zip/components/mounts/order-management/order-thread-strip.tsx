"use client";

import { cn } from "@/lib/utils";

/** The touchless order thread every key-account order walks, in run order. */
export const ORDER_THREAD = [
  "PO Intake",
  "Validation",
  "MOQ",
  "Credit",
  "Allocation",
  "Confirmation",
  "Shipment plan",
  "Appointment",
  "Track & deliver",
] as const;

export type ThreadStep = (typeof ORDER_THREAD)[number];

/**
 * One chip per thread step: green before `at`, amber at `at` while held,
 * green at `at` once resolved, grey after.
 */
export function OrderThreadStrip({
  at,
  resolved,
  className,
}: {
  at: ThreadStep;
  resolved: boolean;
  className?: string;
}) {
  const atIdx = ORDER_THREAD.indexOf(at);
  return (
    <ol className={cn("flex flex-wrap gap-1.5", className)} aria-label="Order thread">
      {ORDER_THREAD.map((step, i) => {
        const state = i < atIdx || (i === atIdx && resolved) ? "done" : i === atIdx ? "held" : "pending";
        return (
          <li
            key={step}
            className={cn(
              "animate-enter flex items-center gap-1.5 whitespace-nowrap rounded-full border px-2.5 py-1 text-xs font-medium",
              state === "done" && "border-green-200 bg-green-50 text-green-700",
              state === "held" && "border-amber-200 bg-amber-50 text-amber-700",
              state === "pending" && "border-border bg-muted/40 text-muted-foreground"
            )}
            style={{ animationDelay: `${i * 30}ms` }}
          >
            <span
              className={cn(
                "h-1.5 w-1.5 shrink-0 rounded-full",
                state === "done" && "bg-[var(--success)]",
                state === "held" && "animate-pulse bg-amber-500",
                state === "pending" && "bg-muted-foreground/40"
              )}
              aria-hidden
            />
            {step}
            {state === "held" && <span className="sr-only"> (on hold)</span>}
          </li>
        );
      })}
    </ol>
  );
}
