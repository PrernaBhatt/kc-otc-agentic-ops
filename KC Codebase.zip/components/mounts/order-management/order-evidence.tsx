"use client";

import { useEffect, useRef, useState } from "react";
import { Spinner } from "@/components/agents/spinner";
import { StepNode } from "@/components/mounts/shared/step-node";
import { createPortal } from "react-dom";
import {
  CalendarClock,
  CircleCheck,
  FileCheck2,
  FileCode2,
  Loader2,
  Mail,
  MapPin,
  Route,
  Warehouse,
  X,
} from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { EmailMessage } from "@/components/mounts/order-management/pod-email-modal";
import { CheckChip } from "@/components/shared/check-chip";
import { FillFields } from "@/components/shared/fill-fields";
import { SystemMark } from "@/components/shared/system-badge";
import { TickList } from "@/components/shared/tick-list";
import { cubePct, insideOtifWindow, orderLogistics, otifVerdict, TMS_SYSTEM } from "@/lib/data/order-logistics";
import { findInboundPo, pricingHoldCase } from "@/lib/data/pipeline-orders";
import { buildAppointmentConfirmationDoc } from "@/lib/docs-logistics";
import { EMAIL_DRAFT_MS } from "@/lib/hooks/use-typewriter";
import { cn } from "@/lib/utils";

interface CarrierQuote {
  name: string;
  scac: string;
  equipment: string;
  rate: number;
  transit: string;
  onTime: number;
  pickup: string;
  status: "selected" | "eligible" | "excluded";
  note: string;
}

interface DockDay {
  date: string;
  slots: { time: string; state: "full" | "open" | "selected" }[];
}

interface StatusStep {
  status: string;
  detail: string;
  at: string;
  by: "auto" | string;
}

interface OrderEvidence {
  /** Confirmation goes back on the channel the customer trades on. */
  channel: "edi" | "email";
  buyer: string;
  buyerEmail: string;
  customerShort: string;
  shipTo: { name: string; lines: string[]; masterId: string; receiving: string };
  billTo: string;
  terms: { po: string; agreement: string; contract: string };
  sourceDc: string;
  allocationRules: { rule: string; outcome: string }[];
  alternativeDcs: { dc: string; reason: string }[];
  lane: string;
  load: string;
  serviceFloor: number;
  carriers: CarrierQuote[];
  portal: string;
  dock: string;
  dockDays: DockDay[];
  appointmentId: string;
  appointmentWindow: string;
  /** Proof of delivery time as logged in TMS by logistics. */
  podAt: string;
  confirmedAt: string;
  ediDate: string;
  ediTime: string;
  ediControl: string;
  ediPartner: string;
  steps: StatusStep[];
}

const EVIDENCE: Record<string, OrderEvidence> = {
  "SO-710260": {
    channel: "edi",
    buyer: "Dana Whitfield",
    buyerEmail: "Buyer — Baby & Paper, Costco Wholesale",
    customerShort: "Costco",
    shipTo: {
      name: "Costco Depot #C-114",
      lines: ["14001 Valley Blvd", "City of Industry, CA 91746", "United States"],
      masterId: "ST-CWC-C114",
      receiving: "Appointment required · Mon–Sat 05:00–15:00",
    },
    billTo: "Costco Wholesale Corp. · 999 Lake Dr, Issaquah, WA 98027",
    terms: { po: "Net 30", agreement: "Net 30", contract: "CTR-CWC-2026" },
    sourceDc: "DC-ONT · Ontario, CA",
    allocationRules: [
      { rule: "Customer priority tier", outcome: "Tier 1 key account — allocated ahead of open backorders" },
      { rule: "Nearest DC with full line coverage", outcome: "DC-ONT covers both lines in full — no split shipment" },
      { rule: "FEFO lot selection", outcome: "Earliest-expiry lots picked · all lots > 18 months shelf life" },
      { rule: "Safety stock protected", outcome: "DC-ONT stays above safety stock after this reservation" },
    ],
    alternativeDcs: [
      { dc: "DC-RNO · Reno, NV", reason: "Full coverage, 470 mi further — +$1,120 freight" },
      { dc: "DC-DAL · Dallas, TX", reason: "Short 340 cases on Training Pants — would split" },
    ],
    lane: "DC-ONT Ontario, CA → Costco Depot #C-114, City of Industry, CA · 24 mi",
    load: "26 pallets · 18,400 lb · 53' dry van",
    serviceFloor: 95,
    carriers: [
      { name: "Blue Line Freight", scac: "BLFT", equipment: "FTL · 53' dry van", rate: 1840, transit: "Same day", onTime: 97, pickup: "2026-08-28 16:00", status: "selected", note: "Least-cost carrier that meets the service floor and the delivery window — tendered and accepted" },
      { name: "Pacific Coast Carriers", scac: "PCCR", equipment: "FTL · 53' dry van", rate: 2010, transit: "Same day", onTime: 96, pickup: "2026-08-28 15:00", status: "eligible", note: "Meets service floor · +$170 vs selected" },
      { name: "Summit Logistics", scac: "SMLG", equipment: "FTL · 53' dry van", rate: 2150, transit: "Next day", onTime: 98, pickup: "2026-08-28 12:00", status: "eligible", note: "Meets service floor · +$310 vs selected" },
    ],
    portal: "Costco receiving appointment portal",
    dock: "Receiving dock 4",
    dockDays: [
      { date: "Fri 2026-08-28", slots: [{ time: "06:00", state: "full" }, { time: "08:00", state: "full" }, { time: "10:00", state: "full" }, { time: "12:00", state: "open" }, { time: "14:00", state: "full" }] },
      { date: "Sat 2026-08-29", slots: [{ time: "06:00", state: "selected" }, { time: "08:00", state: "open" }, { time: "10:00", state: "full" }, { time: "12:00", state: "open" }, { time: "14:00", state: "full" }] },
    ],
    appointmentId: "APPT-C114-58213",
    appointmentWindow: "Sat 2026-08-29 · 06:00–08:00",
    podAt: "2026-08-29 07:42",
    confirmedAt: "2026-08-20 06:34",
    ediDate: "20260820",
    ediTime: "0634",
    ediControl: "000004218",
    ediPartner: "COSTCO",
    steps: [
      { status: "Received", detail: "PO-CWC-40218 bulk-uploaded and queued", at: "06:30", by: "auto" },
      { status: "Validated", detail: "Customer, duplicate SO, MOQ, ship-to and terms passed", at: "06:31", by: "auto" },
      { status: "Credit approved", detail: "Exposure within the $2.0M limit", at: "06:31", by: "auto" },
      { status: "Allocated", detail: "Stock reserved at DC-ONT", at: "06:32", by: "auto" },
      { status: "Customer confirmed", detail: "EDI 855 sent to Costco · 997 functional acknowledgment received", at: "06:34", by: "auto" },
    ],
  },
  "SO-710249": {
    channel: "email",
    buyer: "Marcus Lee",
    buyerEmail: "marcus.lee@target.com",
    customerShort: "Target",
    shipTo: {
      name: "Target Distribution Center T-0553",
      lines: ["14750 Miller Ave", "Fontana, CA 92336", "United States"],
      masterId: "ST-TGT-0553",
      receiving: "Appointment required · daily 04:00–20:00",
    },
    billTo: "Target Corporation · 1000 Nicollet Mall, Minneapolis, MN 55403",
    terms: { po: "Net 30", agreement: "Net 30", contract: "CTR-TGG-2026" },
    sourceDc: "DC-ONT · Ontario, CA",
    allocationRules: [
      { rule: "Customer priority tier", outcome: "Tier 1 key account — allocated ahead of open backorders" },
      { rule: "Nearest DC with full line coverage", outcome: "DC-ONT covers all 4 lines in full — no split shipment" },
      { rule: "FEFO lot selection", outcome: "Earliest-expiry lots picked · all lots > 18 months shelf life" },
      { rule: "Safety stock protected", outcome: "DC-ONT stays above safety stock after this reservation" },
    ],
    alternativeDcs: [
      { dc: "DC-RNO · Reno, NV", reason: "Full coverage, 480 mi further — +$1,060 freight" },
      { dc: "DC-DAL · Dallas, TX", reason: "Short 120 cases on Paper Towels — would split" },
    ],
    lane: "DC-ONT Ontario, CA → Target DC T-0553, Fontana, CA · 13 mi",
    load: "22 pallets · 15,900 lb · 53' dry van",
    serviceFloor: 95,
    carriers: [
      { name: "Blue Line Freight", scac: "BLFT", equipment: "FTL · 53' dry van", rate: 1460, transit: "Same day", onTime: 97, pickup: "2026-08-28 07:45", status: "selected", note: "Least-cost carrier that meets the service floor and the delivery window — tendered and accepted" },
      { name: "Pacific Coast Carriers", scac: "PCCR", equipment: "FTL · 53' dry van", rate: 1580, transit: "Same day", onTime: 96, pickup: "2026-08-28 07:00", status: "eligible", note: "Meets service floor · +$120 vs selected" },
      { name: "Summit Logistics", scac: "SMLG", equipment: "FTL · 53' dry van", rate: 1690, transit: "Next day", onTime: 98, pickup: "2026-08-27 14:00", status: "eligible", note: "Meets service floor · +$230 vs selected" },
    ],
    portal: "Target vendor appointment portal",
    dock: "Inbound door 12",
    dockDays: [
      { date: "Thu 2026-08-27", slots: [{ time: "06:00", state: "full" }, { time: "09:00", state: "full" }, { time: "12:00", state: "open" }, { time: "15:00", state: "full" }, { time: "18:00", state: "open" }] },
      { date: "Fri 2026-08-28", slots: [{ time: "06:00", state: "full" }, { time: "09:00", state: "selected" }, { time: "12:00", state: "open" }, { time: "15:00", state: "full" }, { time: "18:00", state: "open" }] },
    ],
    appointmentId: "APPT-T0553-77410",
    appointmentWindow: "Fri 2026-08-28 · 09:00–11:00",
    podAt: "2026-08-28 09:46",
    confirmedAt: "2026-08-14 10:45",
    ediDate: "20260814",
    ediTime: "1045",
    ediControl: "000003849",
    ediPartner: "TARGET",
    steps: [
      { status: "Received", detail: "PO-TGG-8843 received by email and queued", at: "10:20", by: "auto" },
      { status: "Validated", detail: "Customer, duplicate SO, ship-to and terms passed", at: "10:21", by: "auto" },
      { status: "On hold — pricing", detail: `4 lines above contract · variance $${pricingHoldCase.totalVariance}`, at: "10:22", by: "auto" },
      { status: "Hold released", detail: `Billed at contract ${pricingHoldCase.contract} · ${pricingHoldCase.decisionId}`, at: "10:41", by: pricingHoldCase.approver },
      { status: "MOQ & credit passed", detail: "Minimum order met on every line · exposure within limit", at: "10:41", by: "auto" },
      { status: "Regulatory cleared", detail: "No held lots, allocation limits or license findings", at: "10:42", by: "auto" },
      { status: "Allocated", detail: "Stock reserved at DC-ONT", at: "10:43", by: "auto" },
      { status: "Customer confirmed", detail: "Confirmation email sent as a reply on the buyer's PO thread", at: "10:45", by: "auto" },
    ],
  },
};

export function hasOrderEvidence(orderId: string) {
  return orderId in EVIDENCE;
}

/** The carrier quotes, slot and receiving facts the logistics stages render. */
export function logisticsEvidence(orderId: string) {
  const e = EVIDENCE[orderId];
  if (!e) return null;
  return {
    carriers: e.carriers,
    serviceFloor: e.serviceFloor,
    customerShort: e.customerShort,
    shipTo: e.shipTo.name,
    dock: e.dock,
    appointmentId: e.appointmentId,
    appointmentWindow: e.appointmentWindow,
    podAt: e.podAt,
  };
}

/** What the run produced, for the completion summary. */
export function evidenceArtifacts(orderId: string) {
  const e = EVIDENCE[orderId];
  if (!e) return [];
  const carrier = e.carriers.find((c) => c.status === "selected");
  const l = orderLogistics(orderId);
  return [
    e.channel === "edi"
      ? { label: "EDI 855 acknowledgment", detail: `Sent to ${e.customerShort} · 997 received · #${e.ediControl}` }
      : { label: "Confirmation email", detail: `Reply sent to ${e.buyer}, ${e.customerShort}` },
    { label: "Appointment booked", detail: `${e.appointmentId} · ${e.appointmentWindow} · ${carrier?.name}` },
    ...(l
      ? [{ label: "Delivered on time, in full", detail: `POD ${l.delivery.pod.at.slice(5)} · ${l.delivery.pod.received}` }]
      : []),
  ];
}

/** The four TMS plan facts the Appointment Scheduling Agent reads. TMS owns them. */
export function tmsPlanFacts(orderId: string) {
  const plan = orderLogistics(orderId)?.tmsPlan;
  if (!plan) return null;
  return [
    { id: "route", label: "Route", value: plan.route },
    { id: "load", label: "Load", value: `${plan.load} · ${plan.loadId}` },
    { id: "carrier", label: "Carrier", value: `${plan.carrier} · pickup ${plan.pickup}` },
    { id: "eta", label: "Expected delivery", value: plan.eta },
  ];
}

/**
 * Agent-log lines for the fulfillment and confirmation steps, written from the
 * same evidence the allocation, TMS, appointment cards and confirmation dialog
 * render, so the audit trail and the screen never disagree.
 */
export function evidenceLogs(orderId: string, opts: { humanTouchpoints: number }) {
  const e = EVIDENCE[orderId];
  if (!e) return null;
  const po = findInboundPo(orderId);
  const dc = e.sourceDc.split(" · ")[0];
  const selected = e.carriers.find((c) => c.status === "selected");
  const lineCount = po?.lines.length ?? 0;
  const poTotal = Math.round(po?.lines.reduce((sum, l) => sum + l.lineValue, 0) ?? 0);
  const touch =
    opts.humanTouchpoints === 0
      ? "0 manual touchpoints."
      : `${opts.humanTouchpoints} human decision (pricing hold).`;
  const ruledOut = e.alternativeDcs
    .map((d) => {
      const short = d.reason.includes("+$")
        ? d.reason.split(" — ")[1]
        : d.reason.split(" on ")[0].toLowerCase();
      return `${d.dc.split(" · ")[0]} (${short})`;
    })
    .join(", ");
  const l = orderLogistics(orderId);
  return {
    allocation: `Reserved ${lineCount} lines at ${dc}: Tier 1, full coverage, FEFO, safety stock kept. Ruled out ${ruledOut}.`,
    shipmentPlan: l
      ? `Read TMS plan ${l.tmsPlan.loadId}: ${l.routePlan.miles} mi, ${l.loadPlan.pallets} pallets (${cubePct(l.loadPlan)}% cube), ${selected?.name} tender accepted, ETA ${l.tmsPlan.eta}.`
      : "Read the TMS plan: route, load and carrier.",
    appointment: `Booked ${e.appointmentId} ${e.appointmentWindow} against ETA ${l?.tmsPlan.eta}; inside the ${e.customerShort} OTIF rule.`,
    delivery: l
      ? `A ${l.delivery.available.at.slice(11)} · S ${l.delivery.shipped.at.slice(11)} · D ${l.delivery.arrived.slice(11)}; POD signed ${l.delivery.pod.at.slice(11)}, ${l.delivery.pod.received}. Billing unlocked.`
      : "Delivered and POD signed; billing unlocked.",
    confirmation:
      e.channel === "edi"
        ? `Validated ${lineCount} PO1 lines; sent EDI 855 #${e.ediControl} to ${e.customerShort}; received 997. ${touch}`
        : `Drafted reply from ${orderId}: ${lineCount} lines, ${usd(poTotal)}; sent to ${e.buyer} on ${po?.poNumber}. ${touch}`,
  };
}

function usd(n: number) {
  return `$${n.toLocaleString()}`;
}

function SectionTitle({
  icon: Icon,
  children,
  aside,
}: {
  icon: React.ComponentType<{ className?: string }>;
  children: React.ReactNode;
  aside?: React.ReactNode;
}) {
  return (
    <CardHeader className="pb-2">
      <CardTitle className="flex items-center gap-2 text-sm">
        <Icon className="h-4 w-4 shrink-0 text-[var(--info)]" />
        <span className="min-w-0">{children}</span>
        {aside && <span className="ml-auto shrink-0">{aside}</span>}
      </CardTitle>
    </CardHeader>
  );
}

function AutoBadge({ children = "Automated" }: { children?: React.ReactNode }) {
  return (
    <Badge
      variant="outline"
      className="whitespace-nowrap border-[var(--success)]/40 text-xs font-medium text-[var(--success)]"
    >
      {children}
    </Badge>
  );
}

/** Ship-to address and payment terms checked against customer master and agreement. */
export const SHIP_TO_ROW_COUNT = 5;

export function ShipToTermsCard({
  orderId,
  revealed,
}: {
  orderId: string;
  /** Animation beat: row i appears at beat i+1 and passes at beat i+2. Omit to show everything. */
  revealed?: number;
}) {
  const e = EVIDENCE[orderId];
  const po = findInboundPo(orderId);
  if (!e || !po) return null;
  const rows = [
    { label: "Ship-to on PO", value: `${e.shipTo.name} · ${e.shipTo.lines[0]}, ${e.shipTo.lines[1]}`, check: `Matches customer master ${e.shipTo.masterId}` },
    { label: "Address", value: "Street, city and ZIP verified · geocoded", check: "Deliverable address" },
    { label: "Receiving rules", value: e.shipTo.receiving, check: "Appointment booked at fulfillment" },
    { label: "Bill-to", value: e.billTo, check: "Matches customer master" },
    { label: "Payment terms", value: `PO ${e.terms.po} · agreement ${e.terms.agreement}`, check: `Match �� ${e.terms.contract}` },
  ];
  return (
    <Card>
      <SectionTitle
        icon={MapPin}
        aside={(revealed ?? Infinity) > rows.length ? <AutoBadge>Validated</AutoBadge> : undefined}
      >
        Shipping address &amp; payment terms
      </SectionTitle>
      <CardContent>
        <ul className="flex flex-col divide-y rounded-md border">
          {rows.map((r, i) => {
            const beat = revealed ?? Infinity;
            if (beat < i + 1) return null;
            const checked = beat >= i + 2;
            return (
              <li key={r.label} className="flex items-start gap-3 px-3 py-2.5 animate-enter">
                <div className="flex min-w-0 flex-1 flex-col gap-0.5">
                  <span className="text-xs text-muted-foreground">{r.label}</span>
                  <span className="text-sm leading-relaxed">{r.value}</span>
                  {checked ? (
                    <span className="text-xs text-[var(--success)] animate-enter-fade">{r.check}</span>
                  ) : (
                    <span className="text-xs text-muted-foreground">Verifying…</span>
                  )}
                </div>
                {checked ? (
                  <CircleCheck className="mt-0.5 h-4 w-4 shrink-0 text-[var(--success)] animate-enter-fade" aria-label="Passed" />
                ) : (
                  <Loader2 className="mt-0.5 h-4 w-4 shrink-0 animate-spin text-muted-foreground" aria-label="Checking" />
                )}
              </li>
            );
          })}
        </ul>
      </CardContent>
    </Card>
  );
}

/** Which allocation rules fired and why the source DC was chosen. */
export function AllocationLogicCard({ orderId }: { orderId: string }) {
  const e = EVIDENCE[orderId];
  if (!e) return null;
  return (
    <Card>
      <SectionTitle icon={Warehouse} aside={<AutoBadge>Source {e.sourceDc.split(" · ")[0]}</AutoBadge>}>
        Allocation logic applied
      </SectionTitle>
      <CardContent className="flex flex-col gap-3">
        <ol className="flex flex-col divide-y rounded-md border">
          {e.allocationRules.map((r, i) => (
            <li key={r.rule} className="flex items-start gap-3 px-3 py-2.5 text-sm">
              <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[var(--info)]/10 text-xs font-semibold text-[var(--info)]">
                {i + 1}
              </span>
              <div className="flex min-w-0 flex-col gap-0.5">
                <span className="font-medium">{r.rule}</span>
                <span className="text-xs leading-relaxed text-muted-foreground">{r.outcome}</span>
              </div>
            </li>
          ))}
        </ol>
        <div className="flex flex-col gap-1.5">
          <span className="text-xs font-medium text-muted-foreground">Other DCs considered — not used</span>
          {e.alternativeDcs.map((d) => (
            <div key={d.dc} className="flex flex-col gap-0.5 rounded-md bg-muted/50 px-3 py-2 text-xs">
              <span className="font-medium">{d.dc}</span>
              <span className="text-muted-foreground">{d.reason}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

/** What the AI says while it books the retailer dock against the TMS plan. */
export function appointmentReasoning(orderId: string): string[] | null {
  const e = EVIDENCE[orderId];
  const l = orderLogistics(orderId);
  if (!e || !l) return null;
  const [day, time] = e.appointmentWindow.split(" · ");
  return [
    `Expected delivery per the TMS plan is ${l.tmsPlan.eta}. ${l.otifPolicy.rule}.`,
    `Checking the ${e.customerShort} receiving calendar; an open slot on any other day is an OTIF miss…`,
    `${day.split(" ")[0]} ${time.split("–")[0]} is open, after the ETA and inside the window. Booking it and blocking the calendar.`,
  ];
}

/** What the AI says while it chooses a source DC. */
export function allocationReasoning(orderId: string): string[] | null {
  const e = EVIDENCE[orderId];
  if (!e) return null;
  const dcs = [e.sourceDc, ...e.alternativeDcs.map((d) => d.dc)].map((d) => d.split(" · ")[0]);
  return [
    `Checking available-to-promise at ${dcs.join(", ")}…`,
    `${e.alternativeDcs.map((d) => `${d.dc.split(" · ")[0]}: ${d.reason.toLowerCase()}`).join("; ")} — ruling them out.`,
    `Reserving at ${dcs[0]}: Tier 1 priority, full line coverage, FEFO lots, safety stock kept.`,
  ];
}

/** The TMS shipment plan the Appointment Scheduling Agent reads. TMS owns it; the agent only reads. */
export function TmsPlanCard({ orderId, onDone }: { orderId: string; onDone?: () => void }) {
  const facts = tmsPlanFacts(orderId);
  const l = orderLogistics(orderId);
  if (!facts || !l) return null;
  return (
    <Card className="animate-enter" data-card="tms-plan">
      <SectionTitle
        icon={Route}
        aside={
          <Badge variant="outline" className="gap-1.5 whitespace-nowrap text-xs font-medium text-muted-foreground">
            <SystemMark name={TMS_SYSTEM} />
            <span className="font-mono">{l.tmsPlan.loadId}</span>
          </Badge>
        }
      >
        TMS shipment plan
      </SectionTitle>
      <CardContent>
        <TickList
          playKey={`${orderId}:tms-plan`}
          onDone={onDone}
          items={facts.map((f) => ({ id: f.id, label: f.label, detail: f.value, system: TMS_SYSTEM }))}
        />
      </CardContent>
    </Card>
  );
}

/**
 * Retailer receiving calendar with the OTIF window laid over it: slots outside
 * the window fade, booked-by-others grey out, and the agent books the first
 * open slot inside the window. The booking then types into the record.
 */
export function RetailerAppointmentCard({
  orderId,
  phase = Infinity,
}: {
  orderId: string;
  /** Reasoning lines finished: <2 slots unknown, 2 booked-by-others shown, 3 booked. */
  phase?: number;
}) {
  const e = EVIDENCE[orderId];
  const l = orderLogistics(orderId);
  const po = findInboundPo(orderId);
  if (!e || !l) return null;
  const w = l.otifWindow;
  const checked = phase >= 2;
  const booked = phase >= 3;
  const slotState = (s: DockDay["slots"][number]) =>
    s.state === "selected" ? (booked ? "selected" : "open") : checked ? s.state : "unknown";
  const doc = buildAppointmentConfirmationDoc({
    orderId,
    appointmentId: e.appointmentId,
    portal: e.portal,
    shipTo: e.shipTo.name,
    dock: e.dock,
    window: e.appointmentWindow,
    otifWindow: w.label,
    carrier: l.tmsPlan.carrier,
    loadId: l.tmsPlan.loadId,
    poNumber: po?.poNumber ?? "",
  });
  return (
    <Card className="animate-enter" data-card="appointment">
      <SectionTitle
        icon={CalendarClock}
        aside={
          booked ? (
            <CheckChip result="pass">Inside OTIF window</CheckChip>
          ) : (
            <Badge variant="outline" className="gap-1.5 text-muted-foreground">
              <Spinner size="sm" /> {checked ? "Choosing slot" : "Checking calendar"}
            </Badge>
          )
        }
      >
        Retailer delivery appointment
      </SectionTitle>
      <CardContent className="flex flex-col gap-3">
        <div className="flex flex-col gap-1 text-xs text-muted-foreground">
          <span className="flex items-center gap-1.5 text-sm font-medium text-foreground">
            <SystemMark name={e.portal} />
            {e.shipTo.name} · {e.dock}
          </span>
          <span>
            {l.otifPolicy.rule} · TMS ETA <span className="font-medium text-foreground">{l.tmsPlan.eta}</span>
          </span>
        </div>
        <div className="flex flex-col divide-y rounded-md border">
          {e.dockDays.map((day) => {
            const verdict = otifVerdict(l, day.date);
            const dayInWindow = verdict === "inside";
            return (
              <div
                key={day.date}
                className={cn(
                  "flex flex-col gap-2 px-3 py-2.5 transition-colors duration-500",
                  dayInWindow && checked && "bg-[var(--success)]/5"
                )}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-medium">{day.date}</span>
                  {checked && (
                    <span
                      className={cn(
                        "animate-enter-fade rounded px-1.5 py-0.5 text-[11px] font-medium",
                        dayInWindow ? "text-[var(--success)]" : "bg-amber-50 text-amber-700"
                      )}
                    >
                      {dayInWindow
                        ? `Inside OTIF · ${w.from}–${w.to}`
                        : verdict === "early"
                          ? "Early · OTIF miss"
                          : "Late · OTIF miss"}
                    </span>
                  )}
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {day.slots.map((s) => {
                    const state = slotState(s);
                    const inside = insideOtifWindow(w, day.date, s.time);
                    return (
                      <span
                        key={s.time}
                        className={cn(
                          "rounded-md border px-2.5 py-1 text-xs tabular-nums transition-all duration-500",
                          state === "unknown" && "border-dashed bg-card text-muted-foreground",
                          state === "full" && "border-transparent bg-muted text-muted-foreground line-through",
                          state === "open" && "bg-card",
                          state === "selected" &&
                            "border-[var(--success)] bg-[var(--success)] font-semibold text-[var(--success-foreground)]",
                          checked && !inside && state !== "selected" && "opacity-40"
                        )}
                      >
                        {s.time}
                        <span className="sr-only">
                          {state === "unknown"
                            ? " checking"
                            : state === "full"
                              ? " booked"
                              : state === "open"
                                ? inside
                                  ? " available"
                                  : " available, outside the OTIF window"
                                : " booked for this order"}
                        </span>
                      </span>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
        <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
          <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm bg-muted" /> Booked by others</span>
          <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm border bg-card" /> Open</span>
          <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm border bg-card opacity-40" /> OTIF miss</span>
          <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm bg-[var(--success)]" /> Booked for this order</span>
        </div>
        {booked && (
          <div className="animate-enter flex flex-col gap-2 rounded-md border bg-muted/20 px-3 py-2">
            <div className="flex items-center justify-between gap-2">
              <span className="flex items-center gap-1.5 text-xs font-semibold text-foreground">
                <SystemMark name={e.portal} /> {e.portal}
              </span>
              <SourceDocTrigger doc={doc} label="Confirmation" variant="ghost" className="h-7 px-2 text-xs" />
            </div>
            <FillFields
              playKey={`${orderId}:appointment-fill`}
              columns={2}
              fields={[
                { label: "Appointment", value: e.appointmentId, mono: true },
                { label: "Dock", value: e.dock },
                { label: "Window", value: e.appointmentWindow },
                { label: "PO", value: po?.poNumber ?? "", mono: true },
                { label: "Carrier", value: l.tmsPlan.carrier },
                { label: "Calendar", value: "Blocked", strong: true },
              ]}
              stamp={
                <span className="rounded border-2 border-[var(--success)] px-2 py-0.5 text-[11px] font-bold uppercase tracking-widest text-[var(--success)]">
                  Booked
                </span>
              }
            />
          </div>
        )}
      </CardContent>
    </Card>
  );
}

type CheckState = "pending" | "active" | "done";

function useScrollWhen<T extends HTMLElement>(when: boolean) {
  const ref = useRef<T>(null);
  useEffect(() => {
    if (when) ref.current?.scrollIntoView({ block: "nearest", behavior: "smooth" });
  }, [when]);
  return ref;
}

/** A row of the outbound document (EDI segment or email line) being checked. */
function DocRow({ state, children }: { state: CheckState; children: React.ReactNode }) {
  const ref = useScrollWhen<HTMLDivElement>(state === "active");
  return (
    <div
      ref={ref}
      className={cn(
        "flex items-start gap-3 rounded-md px-3 py-2 transition-colors duration-300",
        state === "pending" && "text-muted-foreground",
        state === "active" && "bg-[var(--info)]/10 ring-1 ring-[var(--info)]/40",
        state === "done" && "bg-[var(--success)]/10"
      )}
    >
      <div className="min-w-0 flex-1">{children}</div>
      <StepNode
        state={state === "done" ? "done" : state === "active" ? "active" : "pending"}
        size="xs"
        className="mt-0.5"
      />
    </div>
  );
}

interface MatchContent {
  title: React.ReactNode;
  detail: React.ReactNode;
}

/** The sales-order counterpart that appears once its document row has been checked. */
function MatchRow({
  state,
  match,
  matchingLabel,
}: {
  state: "matching" | "done";
  match: MatchContent;
  matchingLabel: string;
}) {
  const ref = useScrollWhen<HTMLDivElement>(true);
  if (state === "matching") {
    return (
      <div
        ref={ref}
        className="flex items-center gap-3 rounded-md border border-dashed border-[var(--info)]/40 bg-[var(--info)]/5 px-3 py-3 text-xs text-[var(--info)] animate-modal-in"
      >
        <Spinner size="sm" className="shrink-0" />
        <span>{matchingLabel}</span>
        <span className="ml-auto flex flex-col gap-1.5" aria-hidden="true">
          <span className="h-1.5 w-24 animate-pulse rounded-full bg-[var(--info)]/20" />
          <span className="h-1.5 w-16 animate-pulse rounded-full bg-[var(--info)]/20" />
        </span>
      </div>
    );
  }
  return (
    <div
      ref={ref}
      className="flex items-start gap-3 rounded-md border bg-card px-3 py-2 animate-modal-in"
    >
      <CircleCheck className="mt-0.5 h-4 w-4 shrink-0 text-[var(--success)]" aria-hidden="true" />
      <div className="flex min-w-0 flex-1 flex-col gap-0.5">
        <span className="text-sm font-medium">{match.title}</span>
        <span className="text-xs leading-relaxed text-muted-foreground">{match.detail}</span>
      </div>
    </div>
  );
}

interface ConfirmPair {
  key: string;
  doc?: React.ReactNode;
  match: MatchContent;
}

/** A run of the AI-drafted email; `src` ties it to the sales-order row it was written from. */
interface EmailSeg {
  text: string;
  src?: string;
}

const STEP_MS = 520;
const STREAM_MS = EMAIL_DRAFT_MS;
const STREAM_CHARS = 1;

/**
 * Centered dialog for the Communication Agent's customer confirmation, sent on
 * the channel the PO arrived on: an EDI 855 for EDI trading partners, a reply
 * email for emailed POs. Every document row is checked first; only then does
 * its sales-order counterpart appear on the other side.
 */
export function CustomerConfirmationDialog({
  orderId,
  customerName,
  onClose,
}: {
  orderId: string;
  customerName: string;
  onClose: () => void;
}) {
  const e = EVIDENCE[orderId];
  const po = findInboundPo(orderId);
  const [mounted, setMounted] = useState(false);
  const [step, setStep] = useState(0);
  const [chars, setChars] = useState(0);
  const [sent, setSent] = useState(false);

  const lines = po?.lines ?? [];
  const isEdi = e?.channel === "edi";
  // EDI: BAK + one PO1/ACK per line + DTM + CTT + SE/GE/IEA + 997.
  // Email: header + one per SO line + total, ship-to, requested delivery.
  const pairCount = lines.length + (isEdi ? 5 : 4);
  const total = pairCount * 2;
  const selected = e?.carriers.find((c) => c.status === "selected");
  const atContractPrice = orderId === pricingHoldCase.orderId;
  const contractUnit = (sku: string) => pricingHoldCase.lines.find((p) => p.sku === sku)?.contractPrice;
  const unitFor = (l: (typeof lines)[number]) => (atContractPrice ? contractUnit(l.sku) ?? l.unitPrice : l.unitPrice);
  const valueFor = (l: (typeof lines)[number]) =>
    atContractPrice && contractUnit(l.sku) !== undefined ? l.qty * (contractUnit(l.sku) as number) : l.lineValue;
  const orderTotal = Math.round(lines.reduce((s, l) => s + valueFor(l), 0) * 100) / 100;
  const shortName = customerName.replace(/\.$/, "");

  const emailSegs: EmailSeg[] =
    !isEdi && e && po
      ? [
          { text: `Hi ${e.buyer.split(" ")[0]},\n\n` },
          {
            src: "header",
            text: `Thank you for purchase order ${po.poNumber}. We have accepted it in full as sales order ${orderId} for ${shortName}${atContractPrice ? `, at your contract prices ${pricingHoldCase.contract}` : ""}. Delivery is booked as below.\n\n`,
          },
          ...lines.map((l) => ({
            src: l.lineId,
            text: `${l.productName} · ${l.sku} · ${l.qty.toLocaleString()} cs · ${usd(valueFor(l))}\n`,
          })),
          { src: "total", text: `\nOrder total · ${e.terms.po}: ${usd(orderTotal)}\n\n` },
          ...(atContractPrice ? [{ text: `${pricingHoldCase.buyerNote}\n\n` }] : []),
          { src: "ship", text: `Ship to: ${e.shipTo.name}, ${e.shipTo.lines[1]}\n` },
          { src: "deliv", text: `Requested delivery: ${po.requestedDelivery}. We will confirm the receiving appointment once it is booked.\n\n` },
          { text: "Reply to this email if anything needs to change.\n\nCustomer Service — Order Management" },
        ]
      : [];
  const emailLen = emailSegs.reduce((n, s) => n + s.text.length, 0);

  useEffect(() => {
    setMounted(true);
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (isEdi) {
      if (reduced) {
        setStep(total);
        return;
      }
      const id = window.setInterval(() => {
        setStep((s) => {
          if (s >= total) {
            window.clearInterval(id);
            return s;
          }
          return s + 1;
        });
      }, STEP_MS);
      return () => window.clearInterval(id);
    }
    if (reduced) {
      setChars(emailLen);
      setSent(true);
      return;
    }
    const id = window.setInterval(() => {
      setChars((c) => {
        if (c >= emailLen) {
          window.clearInterval(id);
          return c;
        }
        return Math.min(emailLen, c + STREAM_CHARS);
      });
    }, STREAM_MS);
    return () => window.clearInterval(id);
  }, [isEdi, total, emailLen]);

  useEffect(() => {
    if (isEdi || emailLen === 0 || chars < emailLen) return;
    const t = window.setTimeout(() => setSent(true), 900);
    return () => window.clearTimeout(t);
  }, [isEdi, chars, emailLen]);

  useEffect(() => {
    const onKey = (ev: KeyboardEvent) => ev.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  if (!mounted || !e || !po) return null;

  const drafted = chars >= emailLen;
  const complete = isEdi ? step >= total : sent;
  const deliv = po.requestedDelivery.replaceAll("-", "");
  const ctrl = Number(e.ediControl);

  const srcStart: Record<string, number> = {};
  const srcEnd: Record<string, number> = {};
  let offset = 0;
  for (const s of emailSegs) {
    if (s.src) {
      srcStart[s.src] ??= offset;
      srcEnd[s.src] = offset + s.text.length;
    }
    offset += s.text.length;
  }
  const emailRowState = (key: string): CheckState =>
    chars >= srcEnd[key] ? "done" : chars >= srcStart[key] ? "active" : "pending";
  const written = Object.keys(srcEnd).filter((k) => chars >= srcEnd[k]).length;

  const soLine = (l: (typeof lines)[number], i: number): MatchContent => ({
    title: l.productName,
    detail: (
      <>
        SO line {(i + 1) * 10} · {l.sku} · {l.qty.toLocaleString()} cs × ${unitFor(l).toFixed(2)} ={" "}
        <span className="font-medium text-foreground tabular-nums">{usd(valueFor(l))}</span>
        {atContractPrice && ` · contract ${pricingHoldCase.contract} per ${pricingHoldCase.decisionId}`}
      </>
    ),
  });

  const pairs: ConfirmPair[] = isEdi
    ? [
        {
          key: "bak",
          doc: <Segments seg={[`BAK*00*AD*${po.poNumber}*${e.ediDate}****${orderId}~`]} label="Beginning segment · accepted, no changes (AD)" />,
          match: { title: `${po.poNumber} → ${orderId}`, detail: `${customerName.replace(/\.$/, "")} · accepted in full, no changes` },
        },
        ...lines.map((l, i) => ({
          key: l.lineId,
          doc: (
            <Segments
              seg={[
                `PO1*${i + 1}*${l.qty}*CA*${l.unitPrice.toFixed(2)}**VN*${l.sku}~`,
                `ACK*IA*${l.qty}*CA*068*${deliv}~`,
              ]}
              label={`Line item ${i + 1} · accepted (IA)`}
            />
          ),
          match: soLine(l, i),
        })),
        {
          key: "dtm",
          doc: <Segments seg={[`DTM*068*${deliv}~`]} label="Scheduled delivery date" />,
          match: { title: `Requested delivery ${po.requestedDelivery}`, detail: `${e.shipTo.name} · appointment follows` },
        },
        {
          key: "ctt",
          doc: <Segments seg={[`CTT*${lines.length}~`]} label="Transaction totals" />,
          match: {
            title: <span className="tabular-nums">Order total {usd(orderTotal)}</span>,
            detail: `${lines.length} of ${lines.length} lines acknowledged · ${e.terms.po}`,
          },
        },
        {
          key: "se",
          doc: <Segments seg={[`SE*${lines.length * 2 + 6}*0001~`, `GE*1*${ctrl}~`, `IEA*1*${e.ediControl}~`]} label="Envelope closed · transmitted over AS2" />,
          match: { title: `Sent to ${e.customerShort} over AS2`, detail: `Interchange control #${e.ediControl}` },
        },
        {
          key: "997",
          doc: <Segments seg={[`997 · AK1*PR*${ctrl}~`, `AK9*A*1*1*1~`]} label={`Functional acknowledgment from ${e.customerShort}`} />,
          match: { title: `997 received from ${e.customerShort}`, detail: "Accepted — status set to Customer confirmed" },
        },
      ]
    : [
        {
          key: "header",
          match: { title: `${po.poNumber} → ${orderId}`, detail: `${shortName} · accepted in full, no changes` },
        },
        ...lines.map((l, i) => ({ key: l.lineId, match: soLine(l, i) })),
        {
          key: "total",
          match: {
            title: <span className="tabular-nums">Net value {usd(orderTotal)}</span>,
            detail: `Equals ${po.poNumber} total · payment terms ${e.terms.agreement}`,
          },
        },
        {
          key: "ship",
          match: { title: e.shipTo.name, detail: `Ship-to ${e.shipTo.masterId} on the sales order` },
        },
        {
          key: "deliv",
          match: { title: `Requested delivery ${po.requestedDelivery}`, detail: "Receiving appointment follows in the Appointment step" },
        },
      ];

  const docState = (i: number): CheckState => (step > i * 2 ? "done" : step === i * 2 ? "active" : "pending");
  const current = Math.min(pairCount, Math.floor(step / 2) + 1);

  const statusText = complete
    ? isEdi
      ? `855 acknowledged by ${e.customerShort} — status set to Customer confirmed on the Sales Order Dashboard`
      : `Reply sent to ${e.buyer} — status set to Customer confirmed on the Sales Order Dashboard`
    : isEdi
      ? `Validating EDI 855 segment ${current} of ${pairCount} against ${orderId}`
      : drafted
        ? `Sending reply to ${e.buyer} on the ${po.poNumber} thread…`
        : `AI drafting the confirmation from ${orderId} — ${written} of ${pairCount} sections written`;

  const sourcePanel = (
    <section
      aria-label={`SAP sales order ${orderId}`}
      className="flex min-w-0 flex-col overflow-hidden rounded-lg border bg-card md:min-h-0"
    >
      <div className="flex items-center gap-2 border-b px-4 py-2 text-xs font-medium text-muted-foreground">
        <FileCheck2 className="h-3.5 w-3.5" /> SAP sales order {orderId}
        <span className={cn("ml-auto whitespace-nowrap", drafted ? "text-[var(--success)]" : "text-[var(--info)]")}>
          {written} of {pairCount} written
        </span>
      </div>
      <div className="flex flex-col gap-1 p-3 md:min-h-0 md:flex-1 md:overflow-y-auto">
        {pairs.map((p) => (
          <DocRow key={p.key} state={emailRowState(p.key)}>
            <div className="flex min-w-0 flex-col gap-0.5">
              <span className="text-sm font-medium">{p.match.title}</span>
              <span className="text-xs leading-relaxed text-muted-foreground">{p.match.detail}</span>
            </div>
          </DocRow>
        ))}
      </div>
    </section>
  );

  let cursor = 0;
  const streamedBody = emailSegs.map((s, i) => {
    const start = cursor;
    cursor += s.text.length;
    const visible = s.text.slice(0, Math.max(0, chars - start));
    if (!visible) return null;
    const streaming = chars > start && chars < cursor;
    return (
      <span key={i} className={cn("transition-colors duration-500", streaming && s.src && "bg-[var(--info)]/10")}>
        {visible}
      </span>
    );
  });

  const matchPanel = (
    <section
      aria-label={`SAP sales order ${orderId}`}
      className="flex min-w-0 flex-col overflow-hidden rounded-lg border bg-card md:min-h-0"
    >
      <div className="flex items-center gap-2 border-b px-4 py-2 text-xs font-medium text-muted-foreground">
        <FileCheck2 className="h-3.5 w-3.5" /> SAP sales order {orderId}
        <span className={cn("ml-auto whitespace-nowrap", complete ? "text-[var(--success)]" : "text-[var(--info)]")}>
          {complete ? `${pairCount} of ${pairCount} matched` : `${Math.floor(step / 2)} of ${pairCount} matched`}
        </span>
      </div>
      <div className="flex flex-col gap-2 p-3 md:min-h-0 md:flex-1 md:overflow-y-auto" aria-live="polite">
        {step === 0 && (
          <p className="rounded-md border border-dashed px-3 py-6 text-center text-xs leading-relaxed text-muted-foreground">
            {isEdi
              ? "Sales order lines appear here as each 855 segment is validated."
              : "Sales order lines appear here as the AI checks each line of the email."}
          </p>
        )}
        {pairs.map((p, i) => {
          if (step < i * 2) return null;
          const matched = step > i * 2;
          // EDI: the counterpart only appears after its segment's check completes.
          if (!matched && isEdi) return null;
          return (
            <MatchRow
              key={p.key}
              state={matched ? "done" : "matching"}
              match={p.match}
              matchingLabel={`AI matching to ${orderId}…`}
            />
          );
        })}
      </div>
    </section>
  );

  const docPanel = isEdi ? (
    <section
      aria-label="EDI 855 purchase order acknowledgment"
      className="flex min-w-0 flex-col overflow-hidden rounded-lg border bg-card md:min-h-0"
    >
      <div className="flex items-center gap-2 border-b px-4 py-2 text-xs font-medium text-muted-foreground">
        <FileCode2 className="h-3.5 w-3.5" /> EDI 855 · PO Acknowledgment
        <span className={cn("ml-auto whitespace-nowrap", complete ? "text-[var(--success)]" : "text-[var(--info)]")}>
          {complete ? "997 received" : "Validating…"}
        </span>
      </div>
      <div className="flex flex-col gap-1 p-3 md:min-h-0 md:flex-1 md:overflow-y-auto">
        <pre className="overflow-x-auto px-3 pb-1 font-mono text-xs leading-5 text-muted-foreground">
          {`ISA*00*…*ZZ*SUPPLIERUS*ZZ*${e.ediPartner}*${e.ediDate.slice(2)}*${e.ediTime}*U*00401*${e.ediControl}~\nGS*PR*SUPPLIERUS*${e.ediPartner}*${e.ediDate}*${e.ediTime}*${ctrl}*X*004010~\nST*855*0001~`}
        </pre>
        {pairs.map((p, i) => (
          <DocRow key={p.key} state={docState(i)}>
            {p.doc}
          </DocRow>
        ))}
      </div>
    </section>
  ) : (
    <section aria-label="Confirmation email" className="flex min-w-0 flex-col overflow-hidden rounded-lg border bg-card md:min-h-0">
      <div className="flex items-center gap-2 border-b px-5 py-2 text-xs font-medium text-muted-foreground">
        <Mail className="h-3.5 w-3.5" /> Reply on {po.poNumber} thread
        <span className={cn("ml-auto whitespace-nowrap", complete ? "text-[var(--success)]" : "text-[var(--info)]")}>
          {complete ? `Sent ${e.confirmedAt.slice(11)}` : drafted ? "Sending…" : "AI drafting…"}
        </span>
      </div>
      <div className="md:min-h-0 md:flex-1 md:overflow-y-auto">
        <EmailMessage
          from="Customer Service — Order Management"
          to={`${e.buyer} (${e.buyerEmail})`}
          cc="Transportation Planning"
          subject={`RE: ${po.poNumber} — order confirmation, our ${orderId}`}
          sentAt={e.confirmedAt}
        >
          <p className="sr-only">{emailSegs.map((s) => s.text).join("")}</p>
          <p className="whitespace-pre-wrap text-sm leading-relaxed" aria-hidden="true">
            {streamedBody}
            {!drafted && (
              <span className="ml-0.5 inline-block h-4 w-1.5 translate-y-0.5 animate-pulse rounded-sm bg-[var(--info)]" />
            )}
          </p>
        </EmailMessage>
      </div>
    </section>
  );

  return createPortal(
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/60 p-4 text-left backdrop-blur-sm md:p-6"
      onClick={onClose}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="confirm-dialog-title"
        className="flex max-h-[90vh] w-full max-w-5xl flex-col overflow-hidden rounded-xl border bg-card shadow-2xl animate-modal-in"
        onClick={(ev) => ev.stopPropagation()}
      >
        <div className="flex items-center justify-between gap-3 border-b px-5 py-3">
          <div className="flex min-w-0 items-center gap-3">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[var(--info)]/10 text-[var(--info)]">
              {isEdi ? <FileCode2 className="h-4 w-4" /> : <Mail className="h-4 w-4" />}
            </span>
            <div className="flex min-w-0 flex-col">
              <h2 id="confirm-dialog-title" className="text-sm font-semibold text-balance">
                Communication Agent — {isEdi ? "EDI 855" : "confirmation email"} to {e.customerShort}
              </h2>
              <span className="text-xs text-muted-foreground">
                {orderId} · {po.poNumber} ·{" "}
                {isEdi
                  ? `${e.customerShort} trades by EDI, so the acknowledgment goes back as an 855`
                  : "PO arrived by email, so the confirmation goes back as a reply on the same thread"}
              </span>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose} aria-label="Close">
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div className="grid min-h-0 flex-1 grid-cols-1 gap-4 overflow-y-auto bg-muted/30 p-4 md:grid-cols-2 md:grid-rows-1 md:overflow-hidden">
          {isEdi ? (
            <>
              {matchPanel}
              {docPanel}
            </>
          ) : (
            <>
              {docPanel}
              {sourcePanel}
            </>
          )}
        </div>

        <div className="flex flex-col gap-3 border-t px-5 py-3 md:flex-row md:items-center md:justify-between">
          <span
            className={cn("flex min-w-0 items-center gap-1.5 text-xs", complete ? "text-[var(--success)]" : "text-muted-foreground")}
            aria-live="polite"
          >
            {complete ? <CircleCheck className="h-4 w-4 shrink-0" /> : <Spinner size="sm" className="shrink-0" />}
            {statusText}
          </span>
          <div className="flex items-center gap-3">
            <div className="h-1.5 w-28 overflow-hidden rounded-full bg-muted" aria-hidden="true">
              <div
                className="h-full rounded-full bg-[var(--success)] transition-all duration-300"
                style={{ width: `${Math.min(100, (isEdi ? step / total : chars / Math.max(1, emailLen)) * 100)}%` }}
              />
            </div>
            <Button onClick={onClose} variant={complete ? "default" : "outline"} className="whitespace-nowrap">
              {complete ? "Continue" : "Skip"}
            </Button>
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
}

function Segments({ seg, label }: { seg: string[]; label: string }) {
  return (
    <div className="flex flex-col gap-0.5">
      {seg.map((s) => (
        <code key={s} className="break-all font-mono text-xs">
          {s}
        </code>
      ))}
      <span className="text-xs text-muted-foreground">{label}</span>
    </div>
  );
}

/** Compact line in the flow once the customer has been confirmed; reopens the dialog. */
export function CustomerConfirmationRow({ orderId, customerName }: { orderId: string; customerName: string }) {
  const e = EVIDENCE[orderId];
  const [open, setOpen] = useState(false);
  if (!e) return null;
  const isEdi = e.channel === "edi";
  return (
    <Card>
      <CardContent className="flex flex-col gap-3 p-4 md:flex-row md:items-center">
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[var(--success)]/10 text-[var(--success)]">
          {isEdi ? <FileCode2 className="h-4 w-4" /> : <Mail className="h-4 w-4" />}
        </span>
        <div className="flex min-w-0 flex-1 flex-col gap-0.5">
          <span className="text-sm font-semibold">Order confirmed to {e.customerShort}</span>
          <span className="text-xs leading-relaxed text-muted-foreground">
            {isEdi
              ? `EDI 855 sent · 997 received · #${e.ediControl} · ${e.confirmedAt}`
              : `Reply sent to ${e.buyer} on the ${findInboundPo(orderId)?.poNumber ?? "PO"} thread · ${e.confirmedAt}`}
          </span>
        </div>
        <Button variant="outline" size="sm" onClick={() => setOpen(true)} className="gap-1.5 whitespace-nowrap">
          {isEdi ? <FileCode2 className="h-3.5 w-3.5" /> : <Mail className="h-3.5 w-3.5" />}
          {isEdi ? "View EDI 855" : "View email"}
        </Button>
      </CardContent>
      {open && (
        <CustomerConfirmationDialog orderId={orderId} customerName={customerName} onClose={() => setOpen(false)} />
      )}
    </Card>
  );
}

/**
 * Fulfillment-stage evidence, in run order: allocation, the TMS plan the
 * agent read and the appointment it booked; then confirmation and status.
 */
export function FulfillmentEvidence({
  orderId,
  customerName,
  confirmed,
}: {
  orderId: string;
  customerName: string;
  confirmed: boolean;
}) {
  if (!hasOrderEvidence(orderId)) return null;
  return (
    <>
      <AllocationLogicCard orderId={orderId} />
      <TmsPlanCard orderId={orderId} />
      <RetailerAppointmentCard orderId={orderId} />
      {confirmed && (
        <>
          <CustomerConfirmationRow orderId={orderId} customerName={customerName} />
          <OrderStatusTimeline orderId={orderId} />
        </>
      )}
    </>
  );
}

/** Status history as written to the Sales Order Dashboard. */
export function OrderStatusTimeline({ orderId }: { orderId: string }) {
  const e = EVIDENCE[orderId];
  if (!e) return null;
  const manual = e.steps.filter((s) => s.by !== "auto").length;
  return (
    <Card>
      <SectionTitle
        icon={CalendarClock}
        aside={<AutoBadge>{manual === 0 ? "0 manual touchpoints" : `${manual} human decision`}</AutoBadge>}
      >
        Order status — Sales Order Dashboard
      </SectionTitle>
      <CardContent>
        <ol className="flex flex-col">
          {e.steps.map((s, i) => {
            const last = i === e.steps.length - 1;
            const human = s.by !== "auto";
            return (
              <li key={s.status} className="flex gap-3">
                <div className="flex flex-col items-center">
                  <span className={cn("mt-1.5 h-2.5 w-2.5 rounded-full", human ? "bg-primary" : "bg-[var(--success)]")} />
                  {!last && <span className="w-px flex-1 bg-border" />}
                </div>
                <div className={cn("flex min-w-0 flex-1 items-start justify-between gap-3", !last && "pb-3")}>
                  <div className="flex min-w-0 flex-col">
                    <span className="text-sm font-medium">{s.status}</span>
                    <span className="text-xs leading-relaxed text-muted-foreground">{s.detail}</span>
                  </div>
                  <div className="flex shrink-0 flex-col items-end">
                    <span className="text-xs tabular-nums">{s.at}</span>
                    <span className={cn("text-xs", human ? "text-primary" : "text-muted-foreground")}>
                      {human ? s.by : "Auto"}
                    </span>
                  </div>
                </div>
              </li>
            );
          })}
        </ol>
      </CardContent>
    </Card>
  );
}
