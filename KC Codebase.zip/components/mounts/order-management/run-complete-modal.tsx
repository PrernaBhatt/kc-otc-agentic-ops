"use client";

import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { ArrowRight, CheckCircle2, PartyPopper } from "lucide-react";

import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { evidenceArtifacts } from "@/components/mounts/order-management/order-evidence";
import { InvoiceToCashClock } from "@/components/mounts/order-management/invoice-to-cash-clock";
import { Button } from "@/components/ui/button";
import type { Order } from "@/lib/data/types";
import {
  findInboundPo,
  isPricingHoldOrder,
  pricingHoldCase,
  pricingHoldTotals,
} from "@/lib/data/pipeline-orders";
import { podShipmentFor } from "@/lib/data/shipments";
import { buildPodDoc, buildSalesOrderDoc } from "@/lib/docs";
import { formatMoney } from "@/lib/selectors";

/**
 * The finale (be-creative): once every stage is green, this modal closes the
 * Order Management thread — stages cleared, value delivered, status, and the
 * documents the run produced. Styled like the lien-automation ceremony.
 */
export function RunCompleteModal({
  order,
  stageCount,
  onBackToPipeline,
  onStay,
}: {
  order: Order;
  stageCount: number;
  onBackToPipeline: () => void;
  onStay: () => void;
}) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  if (!mounted) return null;

  const shipment = podShipmentFor(order.orderId, order.customerName);
  const pricingHold = isPricingHoldOrder(order.orderId);
  const touchless =
    pricingHold ||
    findInboundPo(order.orderId)?.channel === "Sales Order Dashboard";
  const stats = pricingHold
    ? [
        { value: "4 / 4", label: "price mismatches caught" },
        { value: `$${pricingHoldCase.totalVariance}`, label: "variance identified" },
        { value: "< 5 min", label: "hold resolved" },
        { value: "Contract", label: `billed, signed by ${pricingHoldCase.approver}` },
      ]
    : touchless
    ? [
        { value: "0", label: "manual touchpoints" },
        { value: "60%", label: "faster order cycle" },
        { value: ">99%", label: "order accuracy" },
        { value: "Straight-through", label: "touchless processing" },
      ]
    : [
        { value: `${stageCount} / ${stageCount}`, label: "stages cleared" },
        { value: formatMoney(order.totalValue), label: "delivered" },
        { value: "Billing unlocked", label: "status" },
      ];

  return createPortal(
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-6"
      onClick={onStay}
    >
      <div
        className="max-h-full w-full max-w-lg overflow-y-auto rounded-2xl border bg-card p-6 shadow-2xl animate-modal-in text-center"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-[var(--success)]/15">
          <CheckCircle2 className="h-7 w-7 text-[var(--success)]" />
        </div>
        <div className="flex items-center justify-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-[var(--success)]">
          <PartyPopper className="h-3.5 w-3.5" />
          Order Management complete
        </div>
        <h3 className="mt-1 text-xl font-bold text-foreground">
          {order.orderId}
          {pricingHold
            ? " · pricing hold resolved, order confirmed"
            : touchless
              ? " · confirmed, fully touchless"
              : " · delivered & ready to bill"}
        </h3>

        <div className={`mt-5 grid gap-2 ${touchless ? "grid-cols-2" : "grid-cols-3"}`}>
          {stats.map((s) => (
            <div key={s.label} className="rounded-lg bg-muted/50 p-3">
              <div className="text-base font-bold text-foreground">
                {s.value}
              </div>
              <div className="text-[11px] text-muted-foreground">{s.label}</div>
            </div>
          ))}
        </div>

        <p className="mt-4 text-sm text-muted-foreground">
          {pricingHold
            ? `Contract-price validation held the PO on 4 lines above agreement. ${pricingHoldCase.approver} signed billing at contract ${pricingHoldCase.contract}, ${formatMoney(pricingHoldTotals.contractTotal)}, with the ${formatMoney(pricingHoldTotals.variance)} gap recorded as ${pricingHoldCase.discrepancyRecordId}.`
            : touchless
            ? "0 touches from PO to delivered on time and in full. The invoice was created at the signed POD."
            : "Every stage produced a document and a person approved each decision — the thread ran clean from purchase order to signed proof of delivery. Billing takes it from here."}
        </p>

        <div className="mt-4">
          <InvoiceToCashClock orderId={order.orderId} />
        </div>

        <div className="mt-4 space-y-2 text-left">
          <div className="text-xs font-medium text-muted-foreground">
            Documents this run produced
          </div>
          <SourceDocTrigger
            doc={buildSalesOrderDoc(order)}
            label={`Sales order ${order.orderId}`}
            className="w-full justify-start"
          />
          {evidenceArtifacts(order.orderId).map((a) => (
            <div
              key={a.label}
              className="flex items-center gap-2 rounded-md border px-3 py-1.5 text-sm"
              title={a.detail}
            >
              <CheckCircle2 className="h-4 w-4 shrink-0 text-[var(--success)]" />
              <span className="shrink-0 whitespace-nowrap font-medium">{a.label}</span>
              <span className="ml-auto min-w-0 truncate text-xs text-muted-foreground">
                {a.detail}
              </span>
            </div>
          ))}
          {!touchless && (
            <SourceDocTrigger
              doc={buildPodDoc(shipment)}
              label={`Proof of delivery ${shipment.shipmentId}`}
              className="w-full justify-start"
            />
          )}
        </div>

        <div className="mt-5 flex items-center justify-center gap-2">
          <Button variant="ghost" onClick={onStay} className="whitespace-nowrap">
            Stay on this order
          </Button>
          <Button onClick={onBackToPipeline} className="whitespace-nowrap">
            Back to pipeline
            <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>,
    document.body
  );
}
