"use client";

import { StepNode } from "@/components/mounts/shared/step-node";
import { cn } from "@/lib/utils";

export type StageDotState = "done" | "active" | "pause" | "pending";

export interface StageRailChip {
  id: string;
  label: string;
  dot: StageDotState;
  /** Tiny live status caption under the label. */
  caption?: string;
  captionTone?: "positive" | "attention" | "muted";
  clickable?: boolean;
  /** Plain-language tooltip with the full status wording. */
  title?: string;
}

const DEFAULT_CAPTION: Record<StageDotState, string> = {
  done: "Done",
  active: "In progress",
  pause: "Awaiting decision",
  pending: "",
};

/**
 * Connected step rail: a node per step joined by a line that turns green as
 * each step completes. The live step breathes; a completed step pops its check.
 * `compact` drops the captions for tight spaces such as pipeline cards.
 */
export function StageRail({
  chips,
  openStageId,
  onChipClick,
  compact = false,
}: {
  chips: StageRailChip[];
  openStageId?: string | null;
  onChipClick?: (stageId: string) => void;
  compact?: boolean;
}) {
  // Half the node plus a little breathing room, so the connector stops short of each node.
  const inset = compact ? 16 : 22;
  return (
    <ol className="flex items-start">
      {chips.map((chip, index) => {
        const clickable = !!chip.clickable && !!onChipClick;
        const isOpen = openStageId === chip.id;
        const reached = chip.dot !== "pending";
        const caption = chip.caption ?? DEFAULT_CAPTION[chip.dot];
        const content = (
          <>
            <StepNode state={chip.dot} size={compact ? "sm" : "md"} />
            <span
              className={cn(
                "text-center text-xs leading-tight text-balance",
                reached ? "font-semibold text-foreground" : "font-medium text-muted-foreground",
                isOpen && !compact && "underline decoration-[var(--info)]/50 decoration-2 underline-offset-4"
              )}
            >
              {chip.label}
            </span>
            {!compact && (
              <span
                className={cn(
                  "min-h-4 text-center text-xs leading-tight",
                  chip.dot === "active" && "text-[var(--info)]",
                  chip.dot === "pause" && "text-amber-700",
                  chip.dot === "done" &&
                    (chip.captionTone === "attention" ? "text-amber-700" : "text-muted-foreground"),
                  chip.dot === "pending" && "text-muted-foreground"
                )}
              >
                {caption}
              </span>
            )}
          </>
        );
        return (
          <li key={chip.id} className="relative flex min-w-0 flex-1 flex-col items-center">
            {index < chips.length - 1 && (
              <span
                aria-hidden
                className={cn(
                  "absolute h-0.5 rounded-full transition-colors duration-500",
                  compact ? "top-[11px]" : "top-[15px]",
                  chip.dot === "done" ? "bg-[var(--success)]" : "bg-border"
                )}
                style={{ left: `calc(50% + ${inset}px)`, right: `calc(-50% + ${inset}px)` }}
              />
            )}
            {clickable ? (
              <button
                type="button"
                title={chip.title}
                onClick={() => onChipClick?.(chip.id)}
                className="flex flex-col items-center gap-1.5 rounded-md px-1 outline-none focus-visible:ring-2 focus-visible:ring-ring cursor-pointer"
              >
                {content}
              </button>
            ) : (
              <div title={chip.title} className="flex flex-col items-center gap-1.5 px-1">
                {content}
              </div>
            )}
          </li>
        );
      })}
    </ol>
  );
}
