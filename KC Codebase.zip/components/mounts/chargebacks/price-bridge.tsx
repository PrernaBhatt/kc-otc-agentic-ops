"use client";

import { useEffect, useState } from "react";
import { CircleCheck, FileX2 } from "lucide-react";

import { CountUp } from "@/components/ui/count-up";
import {
  formatUnitPrice,
  formatUsd,
  type PriceLadderRung,
} from "@/lib/chargeback-selectors";
import { cn } from "@/lib/utils";

export interface PriceBridgeProps {
  rungs: PriceLadderRung[];
  supportedUnits: number;
  moneyAtSupportedVolume: number;
  pctBelowApproved: number;
  walkNote: string;
}

/**
 * The price bridge.
 *
 * List price steps down twice to reach the price the wholesaler claimed. One
 * step has a signed price record behind it and one does not, and the one that
 * does not is the only hollow, hatched bar on the screen. That contrast is the
 * whole argument - a table of four prices cannot say which drop is legitimate.
 */
export function PriceBridge({
  rungs,
  supportedUnits,
  moneyAtSupportedVolume,
  pctBelowApproved,
  walkNote,
}: PriceBridgeProps) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    const id = requestAnimationFrame(() => setMounted(true));
    return () => cancelAnimationFrame(id);
  }, []);

  // Three columns, all grounded, all coloured by what the money does: red is
  // the share the wholesaler reclaims, green the share the project pays. No
  // grey - a neutral bar said nothing about either.
  const ceiling = Math.max(...rungs.map((r) => Math.abs(r.value)), 1);
  const pct = (value: number) => (Math.abs(value) / ceiling) * 100;
  const columns = rungs.map((rung, index) => ({
    rung,
    index,
    height: pct(rung.value),
  }));

  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-1 flex items-baseline justify-between gap-3">
        <h4 className="text-sm font-semibold">
          Approved price against the claimed price
        </h4>
        <span className="text-xs text-muted-foreground whitespace-nowrap">
          per unit
        </span>
      </div>

      <div className="relative mt-4 flex h-52 items-end gap-2">
        {columns.map(({ rung, index, height }) => (
          <div
            key={rung.key}
            className="relative flex h-full flex-1 flex-col justify-end"
          >
            <div
              className={cn(
                "absolute inset-x-0 overflow-hidden rounded-md border transition-all duration-500 ease-out motion-reduce:transition-none",
                // The adjustment is the TOP slice of the price invoiced, so it
                // hangs from the top and lines up with the red band beside it.
                rung.fill === "reclaimed" ? "top-0" : "bottom-0"
              )}
              style={{
                height: mounted ? `${height}%` : "0%",
                transitionDelay: `${index * 180}ms`,
                borderColor:
                  rung.fill === "project"
                    ? "rgba(22,163,74,0.5)"
                    : "rgba(220,38,38,0.5)",
              }}
            >
              {rung.fill === "split" ? (
                <>
                  <div
                    className="w-full bg-red-500/25"
                    style={{ height: `${(rung.reclaimedShare ?? 0) * 100}%` }}
                  />
                  <div
                    className="w-full bg-[var(--success)]/25"
                    style={{
                      height: `${(1 - (rung.reclaimedShare ?? 0)) * 100}%`,
                    }}
                  />
                </>
              ) : (
                <div
                  className={cn(
                    "h-full w-full",
                    rung.fill === "project"
                      ? "bg-[var(--success)]/25"
                      : "bg-red-500/25"
                  )}
                />
              )}
            </div>
            {/* Outside the bar: the bar clips its own overflow. */}
            <span
              className={cn(
                "pointer-events-none absolute inset-x-0 text-center text-xs font-semibold",
                rung.fill === "reclaimed" ? "top-0 -mt-5" : "",
                rung.fill === "project" && "text-[var(--success)]",
                rung.fill === "reclaimed" && "text-red-600",
                rung.fill === "split" && "text-foreground"
              )}
              style={
                rung.fill === "reclaimed"
                  ? undefined
                  : { bottom: `calc(${height}% + 4px)` }
              }
            >
              {formatUnitPrice(Math.abs(rung.value))}
            </span>
          </div>
        ))}
      </div>

      <div className="mt-2 flex gap-2">
        {rungs.map((rung) => (
          <div key={rung.key} className="min-w-0 flex-1">
            <p className="text-xs font-medium leading-tight">{rung.label}</p>
            {rung.evidence ? (
              <span className="mt-1 inline-flex items-center gap-1 rounded bg-muted/60 px-1.5 py-0.5 text-xs text-muted-foreground">
                <CircleCheck className="h-3 w-3 shrink-0 text-[var(--success)]" />
                <span className="truncate">{rung.evidence.ref}</span>
              </span>
            ) : rung.kind === "unsupportedStep" ? (
              <span className="mt-1 inline-flex items-center gap-1 rounded bg-red-50 px-1.5 py-0.5 text-xs text-red-600">
                <FileX2 className="h-3 w-3 shrink-0" />
                <span className="line-through">No price record</span>
              </span>
            ) : null}
          </div>
        ))}
      </div>

      <div className="mt-4 border-t pt-3">
        {pctBelowApproved === 0 ? (
          <p className="flex items-center gap-2 text-sm">
            <CircleCheck className="h-4 w-4 shrink-0 text-[var(--success)]" />
            <span>
              The claimed price is the contracted price. Nothing is reclaimed
              beyond the{" "}
              <span className="font-semibold tabular-nums">
                {formatUnitPrice(
                  Math.abs(
                    rungs.find((r) => r.fill === "reclaimed")?.value ?? 0
                  )
                )}
              </span>{" "}
              adjustment we approved.
            </span>
          </p>
        ) : (
          <p className="text-sm">
            <span className="font-semibold text-red-600">
              {Math.round(pctBelowApproved * 100)}% below the approved price
            </span>
            <span className="text-muted-foreground">
              {" "}
              · applied to {supportedUnits.toLocaleString("en-US")} supportable
              units ={" "}
            </span>
            <span className="font-semibold tabular-nums">
              <CountUp value={moneyAtSupportedVolume} format={formatUsd} />
            </span>
          </p>
        )}
      </div>
      {pctBelowApproved > 0 && (
        <p className="mt-2 text-xs text-muted-foreground">{walkNote}</p>
      )}
    </div>
  );
}
