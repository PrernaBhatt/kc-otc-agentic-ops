"use client";

import { useState } from "react";
import { CircleCheck, Lock, ThumbsUp, TriangleAlert } from "lucide-react";

import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  allocationCeiling,
  claimLineMath,
  claimPeriodUnits,
  claimRiskScore,
  distributorName,
  duplicateComparison,
  formatUnitPrice,
  formatUsd,
  priceLadder,
  recommendedSettlement,
  duplicateScreen,
  rosterCheck,
  stageNarration,
  UNSUPPORTED_WALK_NOTE,
} from "@/lib/chargeback-selectors";
import { findClaim } from "@/lib/data/chargebacks";
import { findClaimPeriod } from "@/lib/data/contract-pricing";
import { findEndCustomer } from "@/lib/data/distributors";
import {
  agreementTriggerLabel,
  chargebackAgreementChain,
} from "@/lib/data/channel-agreements";
import {
  buildChargebackClaimDoc,
  buildAgreementDoc,
  buildChargebackSettlementDoc,
  buildClaimPeriodActivityDoc,
  buildClaimSubmissionDoc,
  buildContractPriceListDoc,
  buildContractRosterDoc,
  buildSettledClaimDoc,
} from "@/lib/docs-chargebacks";
import { useOtcStore } from "@/lib/store";

import { AiStageNarration } from "./ai-stage-narration";
import { ClaimDecisionSplitter, RiskWeightStack } from "./decision-visuals";
import { DuplicateScreenBoard } from "./duplicate-screen-board";
import { PriceBridge } from "./price-bridge";
import {
  FieldTable,
  RosterTable,
  SettlementTable,
} from "./stage-tables";
import { VolumeGapColumn } from "./volume-gap-column";

/**
 * One panel per validation stage.
 *
 * Panels take scalars and re-derive everything themselves. None of them
 * advances the run: the view owns the stage machine, and the one panel with a
 * decision on it calls a store action, which the view observes.
 */
export function ClaimStagePanel({
  stageId,
  claimId,
  isCurrentStage,
  onJumpToStage,
}: {
  stageId: string;
  claimId: string;
  isCurrentStage?: boolean;
  onJumpToStage?: (stageId: string) => void;
}) {
  const claim = findClaim(claimId);
  if (!claim) return null;

  const narration = stageNarration(claimId, stageId);

  return (
    <div className="space-y-4">
      {narration && <AiStageNarration key={stageId} text={narration} />}
      <StageBody
        stageId={stageId}
        claimId={claimId}
        isCurrentStage={isCurrentStage}
        onJumpToStage={onJumpToStage}
      />
    </div>
  );
}

function StageBody({
  stageId,
  claimId,
  isCurrentStage,
  onJumpToStage,
}: {
  stageId: string;
  claimId: string;
  isCurrentStage?: boolean;
  onJumpToStage?: (stageId: string) => void;
}) {
  switch (stageId) {
    case "claim_intake":
      return <ClaimIntakePanel claimId={claimId} />;
    case "customer_check":
      return <CustomerCheckPanel claimId={claimId} />;
    case "price_check":
      return <PriceCheckPanel claimId={claimId} />;
    case "duplicate_check":
      return <DuplicateCheckPanel claimId={claimId} />;
    case "volume_check":
      return <VolumeCheckPanel claimId={claimId} />;
    case "decision":
      return (
        <DecisionPanel
          claimId={claimId}
          isCurrentStage={isCurrentStage}
          onJumpToStage={onJumpToStage}
        />
      );
    case "settlement":
      return <SettlementPanel claimId={claimId} />;
    default:
      return null;
  }
}

function DocRow({ children }: { children: React.ReactNode }) {
  return <div className="flex flex-wrap gap-2">{children}</div>;
}

/* ---------------------------------------------------------------- */

function ClaimIntakePanel({ claimId }: { claimId: string }) {
  const claim = findClaim(claimId)!;
  const line = claim.lines[0];
  const math = claimLineMath(claimId);
  const period = findClaimPeriod(claim.periodId);
  const endCustomer = findEndCustomer(line.endCustomerId);
  if (!math) return null;

  return (
    <div className="space-y-4">
      <FieldTable
        title="Claim as submitted"
        caption={`Submitted ${claim.submittedDate}`}
        rows={[
          { label: "Claim", value: claim.claimId },
          { label: "Wholesaler", value: distributorName(claim.distributorId) },
          { label: "End customer", value: endCustomer?.name ?? "—" },
          { label: "Product", value: `${line.productName} · ${line.sku}` },
          { label: "Claim window", value: period?.label ?? "—" },
          { label: "Contract cited", value: line.citedContractId },
          {
            label: "Units claimed",
            value: line.claimedUnits.toLocaleString("en-US"),
            aiNote: "Stated by the wholesaler. To be traced to invoices and deliveries.",
          },
          {
            label: "Price invoiced to the wholesaler",
            value: formatUnitPrice(math.listPrice),
            aiNote: "From the distribution agreement with this wholesaler.",
          },
          {
            label: "Contract price stated on the claim",
            value: formatUnitPrice(math.claimedContractPrice),
            aiNote: "Stated by the wholesaler. To be matched to an approved price record.",
          },
          {
            // A reviewer who skips the two rows above reads this as OUR rate.
            // The row has to carry, on its own, whose figure it is and that
            // it has not been tested yet.
            label: "Difference claimed back, per unit",
            value: formatUnitPrice(math.claimedAdjustment),
            aiNote:
              "What the wholesaler is asking for, on their own stated price. Not yet tested against the approved price record.",
          },
          {
            label: "Total claimed",
            value: formatUsd(math.claimedAmount),
            aiNote: `${line.claimedUnits.toLocaleString("en-US")} units at the rate above, as claimed. Nothing on this page has been verified yet.`,
          },
          { label: "Routed to", value: claim.routing },
        ]}
        emphasise={["Total claimed"]}
      />

      <p className="text-xs text-muted-foreground">
        Chargeback claims settle by credit note against trade receivables, not
        against the customer&apos;s credit line, so a claim may exceed the
        credit limit shown on other pages.
      </p>

      <DocRow>
        {/* The file they actually sent comes first: every figure above is a
            sum over its lines, so a reader who wants the origin of a number
            opens this rather than taking the panel on trust. */}
        <SourceDocTrigger
          doc={buildClaimSubmissionDoc(claimId)}
          label="Open the file the wholesaler sent"
        />
        <SourceDocTrigger
          doc={buildChargebackClaimDoc(claimId)}
          label="View the claim as filed"
        />
      </DocRow>

      {/* The three contracts, in chain order. A reader cannot judge the claim
          without all three: what the wholesaler paid us, what the project
          paid them, and whether we ever agreed to that project price. */}
      <div>
        <p className="mb-2 text-xs font-medium text-muted-foreground">
          The agreements this claim rests on
        </p>
        <DocRow>
          {chargebackAgreementChain(line.sku).map((a) => (
            <SourceDocTrigger
              key={a.agreementId}
              doc={buildAgreementDoc(a.agreementId)}
              label={agreementTriggerLabel(a)}
            />
          ))}
        </DocRow>
      </div>
    </div>
  );
}

function CustomerCheckPanel({ claimId }: { claimId: string }) {
  const check = rosterCheck(claimId);

  const rows = check.members.map((m) => ({
    project: m.endCustomer.name,
    detail: `${m.endCustomer.city}, ${m.endCustomer.state}`,
    since: m.effectiveFrom,
    onRoster: true,
    note:
      check.siblingOnRoster?.endCustomerId === m.endCustomer.endCustomerId
        ? "Same owner group as the project on the claim"
        : undefined,
  }));

  if (check.claimedEndCustomer && !check.onCitedRoster) {
    rows.push({
      project: check.claimedEndCustomer.name,
      detail: `${check.claimedEndCustomer.city}, ${check.claimedEndCustomer.state}`,
      since: "—",
      onRoster: false,
      note: "The project this claim is made for",
    });
  }

  return (
    <div className="space-y-4">
      <RosterTable
        title={check.citedRoster?.label ?? "Contract roster"}
        caption={check.citedRoster?.contractId}
        rows={rows}
        footer={
          // "instead" only reads when the project is NOT on the cited
          // roster. It is, so the footer states the entitlement rather than
          // an alternative to it.
          check.homePriceRecord
            ? check.onCitedRoster
              ? `${check.claimedEndCustomer?.name} is entitled to ${formatUnitPrice(check.homePriceRecord.contractPrice)} per unit under this contract, in force from ${check.homePriceRecord.effectiveFrom}.`
              : `${check.claimedEndCustomer?.name} is covered by ${check.homeRoster?.contractId} instead, at an approved price of ${formatUnitPrice(check.homePriceRecord.contractPrice)} per unit, in force from ${check.homePriceRecord.effectiveFrom}.`
            : undefined
        }
      />
      <DocRow>
        <SourceDocTrigger
          doc={buildContractRosterDoc(claimId)}
          label="View the roster"
        />
      </DocRow>
    </div>
  );
}

function PriceCheckPanel({ claimId }: { claimId: string }) {
  const math = claimLineMath(claimId);
  if (!math) return null;

  return (
    <div className="space-y-4">
      <PriceBridge
        rungs={priceLadder(claimId)}
        supportedUnits={math.supportedUnits}
        moneyAtSupportedVolume={math.priceComponent}
        pctBelowApproved={math.pctBelowApproved}
        walkNote={UNSUPPORTED_WALK_NOTE}
      />
      <DocRow>
        <SourceDocTrigger
          doc={buildContractPriceListDoc(claimId)}
          label="View the price records"
        />
      </DocRow>
    </div>
  );
}

function DuplicateCheckPanel({ claimId }: { claimId: string }) {
  const screen = duplicateScreen(claimId);
  if (!screen) return null;

  return (
    <div className="space-y-4">
      <DuplicateScreenBoard screen={screen} />
      <DocRow>
        <SourceDocTrigger
          doc={buildSettledClaimDoc(claimId)}
          label="View the settled claims"
        />
      </DocRow>
    </div>
  );
}

function VolumeCheckPanel({ claimId }: { claimId: string }) {
  const math = claimLineMath(claimId);
  const units = claimPeriodUnits(claimId);
  if (!math) return null;

  return (
    <div className="space-y-4">
      <VolumeGapColumn
        claimedUnits={math.claimedUnits}
        supportedRows={units.inPeriodRows}
        excludedRows={units.excludedRows}
        supportedUnits={units.supportedUnits}
        ceiling={allocationCeiling(claimId)}
      />
      <DocRow>
        <SourceDocTrigger
          doc={buildClaimPeriodActivityDoc(claimId)}
          label="View the invoice and delivery history"
        />
        {/* The same eight lines the reader met at intake, now carrying a
            verdict — which is where the 8,000 stops being a subtraction and
            becomes three named resale lines. */}
        <SourceDocTrigger
          doc={buildClaimSubmissionDoc(claimId, { matched: true })}
          label="Trace the claim lines to shipment records"
        />
      </DocRow>
    </div>
  );
}

/* ---------------------------------------------------------------- *
 * The human gate
 * ---------------------------------------------------------------- */

function DecisionPanel({
  claimId,
  isCurrentStage,
  onJumpToStage,
}: {
  claimId: string;
  isCurrentStage?: boolean;
  onJumpToStage?: (stageId: string) => void;
}) {
  const { claimDecisions, recordClaimDecision } = useOtcStore();
  const [blockPayment, setBlockPayment] = useState(true);
  const [confirmFull, setConfirmFull] = useState(false);

  const math = claimLineMath(claimId);
  const settlement = recommendedSettlement(claimId);
  const risk = claimRiskScore(claimId);
  const decision = claimDecisions.find((d) => d.claimId === claimId);
  if (!math || !settlement) return null;

  const decide = (
    outcome: "Approved" | "Approved in part" | "Rejected",
    approvedAmount: number,
    rejectedAmount: number
  ) =>
    recordClaimDecision({
      claimId,
      outcome,
      approvedAmount,
      rejectedAmount,
      priceRejectAmount:
        outcome === "Approved in part" ? settlement.priceComponent : 0,
      quantityRejectAmount:
        outcome === "Approved in part" ? settlement.quantityComponent : 0,
      paymentBlockPlaced: outcome === "Approved" ? false : blockPayment,
    });

  // A confirmed duplicate is rejected outright. Neither the weighted findings
  // nor the settlement split has anything to say about a claim already paid.
  if (risk.vetoed) {
    return (
      <VetoedDecisionPanel
        claimId={claimId}
        claimedTotal={settlement.claimedTotal}
        vetoReason={risk.vetoReason}
        isCurrentStage={isCurrentStage}
        decision={decision}
        onReject={() => decide("Rejected", 0, settlement.claimedTotal)}
      />
    );
  }

  return (
    <div className="space-y-4">
      <RiskWeightStack
        dimensions={risk.dimensions}
        score={risk.score}
        weightsSum={risk.weightsSum}
        confidencePercent={risk.confidencePercent}
        onDimensionClick={onJumpToStage}
      />

      <ClaimDecisionSplitter
        claimedTotal={settlement.claimedTotal}
        approveAmount={settlement.approveAmount}
        priceRejectAmount={settlement.priceComponent}
        quantityRejectAmount={settlement.quantityComponent}
        supportedUnits={math.supportedUnits}
        approvedPrice={math.approvedContractPrice}
        unitsException={math.unitsException}
        unsupportedRateDelta={math.unsupportedRateDelta}
      />

      <div className="rounded-xl border-2 border-amber-200 bg-amber-50/60 p-4">
        <div className="mb-2 flex flex-wrap items-center gap-2">
          {decision ? (
            <Badge className="whitespace-nowrap bg-[var(--success)] text-white">
              <ThumbsUp className="h-3 w-3" />
              Decided by you
            </Badge>
          ) : (
            <Badge
              variant="outline"
              className="whitespace-nowrap border-amber-300 bg-amber-100 text-amber-800"
            >
              Awaiting your decision
            </Badge>
          )}
          <span className="text-xs text-muted-foreground">
            Nothing settles until you click. The AI has not moved any money.
          </span>
        </div>

        {decision ? (
          <p className="flex items-center gap-2 text-sm font-medium">
            <CircleCheck className="h-4 w-4 shrink-0 text-[var(--success)]" />
            {decision.outcome} — {formatUsd(decision.approvedAmount)} approved,{" "}
            {formatUsd(decision.rejectedAmount)} rejected. Credit note{" "}
            {decision.creditNoteId}.
          </p>
        ) : (
          <>
            {settlement.rejectAmount > 0 && (
              <label className="mb-3 flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={blockPayment}
                  onChange={(e) => setBlockPayment(e.target.checked)}
                  className="h-4 w-4 accent-amber-600"
                />
                <Lock className="h-3.5 w-3.5 text-muted-foreground" />
                Hold payment on the rejected{" "}
                {formatUsd(settlement.rejectAmount)} until the wholesaler
                responds
              </label>
            )}

            <div className="flex flex-wrap gap-2">
              {/* A fully supportable claim has nothing to split, so it gets one
                  approve action rather than a partial with "reject $0". */}
              {settlement.rejectAmount > 0 ? (
                <>
                  <Button
                    className="whitespace-nowrap"
                    disabled={!isCurrentStage}
                    onClick={() =>
                      decide(
                        "Approved in part",
                        settlement.approveAmount,
                        settlement.rejectAmount
                      )
                    }
                  >
                    {/* "Approve $0" is not an action. When nothing is
                        supportable the recommendation IS a full rejection, and
                        the separate reject button below would repeat it. */}
                    {settlement.approveAmount === 0
                      ? `Reject in full — ${formatUsd(settlement.rejectAmount)}`
                      : `Approve ${formatUsd(settlement.approveAmount)} · reject ${formatUsd(settlement.rejectAmount)}`}
                  </Button>
                  <Button
                    variant="outline"
                    className="whitespace-nowrap"
                    disabled={!isCurrentStage}
                    onClick={() =>
                      confirmFull
                        ? decide("Approved", settlement.claimedTotal, 0)
                        : setConfirmFull(true)
                    }
                  >
                    {confirmFull
                      ? "Confirm — approve the full claim"
                      : "Approve the full claim"}
                  </Button>
                </>
              ) : (
                <Button
                  className="whitespace-nowrap"
                  disabled={!isCurrentStage}
                  onClick={() => decide("Approved", settlement.claimedTotal, 0)}
                >
                  Approve {formatUsd(settlement.claimedTotal)} in full
                </Button>
              )}
              {settlement.approveAmount > 0 && (
                <Button
                  variant="ghost"
                  className="whitespace-nowrap"
                  disabled={!isCurrentStage}
                  onClick={() => decide("Rejected", 0, settlement.claimedTotal)}
                >
                  Reject in full
                </Button>
              )}
            </div>

            {confirmFull && (
              <div className="mt-3 rounded-lg border border-red-200 bg-red-50 px-3 py-2.5">
                <p className="text-xs text-red-800">
                  Approving in full pays{" "}
                  {formatUsd(settlement.quantityComponent)} for units with no
                  invoice or delivery record and{" "}
                  {formatUsd(settlement.priceComponent)} at a price with no
                  approved record. Click again to confirm.
                </p>
              </div>
            )}
          </>
        )}

        {!isCurrentStage && !decision && (
          <p className="mt-2 text-xs text-muted-foreground">
            The run pauses here for your decision when it reaches this step.
          </p>
        )}
      </div>
    </div>
  );
}

/** The gate for a claim that has already been settled under another number. */
function VetoedDecisionPanel({
  claimId,
  claimedTotal,
  vetoReason,
  isCurrentStage,
  decision,
  onReject,
}: {
  claimId: string;
  claimedTotal: number;
  vetoReason?: string;
  isCurrentStage?: boolean;
  decision?: { outcome: string; rejectedAmount: number; creditNoteId: string };
  onReject: () => void;
}) {
  // The vetoed-claim path shares the screen board: it renders the "already
  // settled" state from the same data rather than needing a second component.
  const screen = duplicateScreen(claimId);

  return (
    <div className="space-y-4">
      {screen && <DuplicateScreenBoard screen={screen} />}

      <div className="rounded-xl border-2 border-amber-200 bg-amber-50/60 p-4">
        <div className="mb-2 flex flex-wrap items-center gap-2">
          {decision ? (
            <Badge className="whitespace-nowrap bg-[var(--success)] text-white">
              <ThumbsUp className="h-3 w-3" />
              Decided
            </Badge>
          ) : (
            <Badge
              variant="outline"
              className="whitespace-nowrap border-amber-300 bg-amber-100 text-amber-800"
            >
              Awaiting your decision
            </Badge>
          )}
          <span className="text-xs text-muted-foreground">{vetoReason}</span>
        </div>

        {decision ? (
          <p className="flex items-center gap-2 text-sm font-medium">
            <CircleCheck className="h-4 w-4 shrink-0 text-[var(--success)]" />
            Rejected in full — {formatUsd(decision.rejectedAmount)}.
          </p>
        ) : (
          <Button
            className="whitespace-nowrap"
            disabled={!isCurrentStage}
            onClick={onReject}
          >
            Reject in full — {formatUsd(claimedTotal)} already settled
          </Button>
        )}
      </div>
    </div>
  );
}

function SettlementPanel({ claimId }: { claimId: string }) {
  const { claimDecisions } = useOtcStore();
  const decision = claimDecisions.find((d) => d.claimId === claimId);
  const claim = findClaim(claimId)!;

  if (!decision) {
    return (
      <p className="text-sm text-muted-foreground">
        Nothing has settled yet. This step fills in once a decision is made.
      </p>
    );
  }

  const wholesaler = distributorName(claim.distributorId);
  const math = claimLineMath(claimId);

  return (
    <div className="space-y-4">
      <SettlementTable
        claimedTotal={formatUsd(
          decision.approvedAmount + decision.rejectedAmount
        )}
        rows={[
          {
            line: "Credit note issued",
            basis: `${decision.creditNoteId} to ${wholesaler}`,
            amount: formatUsd(decision.approvedAmount),
            tone: "success",
          },
          {
            line: "Rejected · no delivery record",
            basis: `${(math?.unitsException ?? 0).toLocaleString("en-US")} units with no invoice or delivery`,
            amount: formatUsd(decision.quantityRejectAmount),
            tone: "danger",
          },
          {
            line: "Rejected · price not approved",
            basis: `${formatUnitPrice(math?.unsupportedRateDelta ?? 0)} per unit below the approved price`,
            amount: formatUsd(decision.priceRejectAmount),
            tone: "danger",
          },
          {
            line: "Payment hold",
            basis: decision.paymentBlockPlaced
              ? "Released when the wholesaler responds"
              : "Not placed",
            amount: decision.paymentBlockPlaced
              ? formatUsd(decision.rejectedAmount)
              : "—",
          },
        ]}
        postingLines={[
          {
            side: "Dr",
            account: "Chargeback settlements",
            amount: formatUsd(decision.approvedAmount),
          },
          {
            side: "Cr",
            account: `Trade receivables — ${wholesaler}`,
            amount: formatUsd(decision.approvedAmount),
          },
        ]}
        footer="Balanced. The credit note offsets the receivable in full."
      />
      <DocRow>
        <SourceDocTrigger
          doc={buildChargebackSettlementDoc(
            claimId,
            decision.creditNoteId,
            decision.decidedAt
          )}
          label="View the settlement"
        />
      </DocRow>
    </div>
  );
}
