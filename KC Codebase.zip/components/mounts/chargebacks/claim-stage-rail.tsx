"use client";

import { Fragment } from "react";

import { cn } from "@/lib/utils";

/**
 * The claim validation rail.
 *
 * Forked from components/mounts/order-management/stage-rail.tsx rather than
 * shared: that one hardcodes a five-per-row split for the ten-stage order
 * flow, and this flow has eight stages. The dot states, colours and connector
 * are identical on purpose, so a stage means the same thing on both pages.
 */

export type StageDotState = "done" | "active" | "pause" | "pending";

export interface StageRailChip {
  id: string;
  label: string;
  dot: StageDotState;
  caption?: string;
  captionTone?: "positive" | "attention" | "muted";
  clickable?: boolean;
  title?: string;
}

function chipClass(dot: StageDotState, isOpen: boolean, clickable: boolean) {
  return cn(
    "flex-1 min-w-0 rounded-md border px-2 py-1.5 text-left transition-all",
    dot === "done" && "bg-green-100 text-green-700 border-green-200",
    dot === "active" && "bg-blue-100 text-blue-700 border-blue-200",
    dot === "pause" && "bg-amber-100 text-amber-700 border-amber-200",
    dot === "pending" && "bg-gray-100 text-gray-500 border-gray-200",
    clickable && "cursor-pointer hover:ring-1 hover:ring-primary/40",
    isOpen && "ring-1 ring-primary/60"
  );
}

function StatusDot({ dot }: { dot: StageDotState }) {
  return (
    <span
      className={cn(
        "h-2 w-2 rounded-full shrink-0",
        dot === "done" && "bg-[var(--success)]",
        dot === "active" && "bg-[var(--info)] animate-pulse",
        dot === "pause" && "bg-amber-500 animate-pulse",
        dot === "pending" && "bg-gray-300"
      )}
    />
  );
}

function Connector({ done }: { done: boolean }) {
  return (
    <div className="flex items-center shrink-0 px-0.5" aria-hidden>
      <div
        className={cn(
          "h-0.5 w-2 rounded-full",
          done ? "bg-[var(--success)]" : "bg-border"
        )}
      />
    </div>
  );
}

function ChipContent({ chip }: { chip: StageRailChip }) {
  return (
    <>
      <span className="flex items-center gap-1.5">
        <StatusDot dot={chip.dot} />
        <span className="truncate text-xs font-medium">{chip.label}</span>
      </span>
      <span
        className={cn(
          "block truncate text-xs mt-0.5 min-h-4 font-normal",
          chip.captionTone === "positive" && "text-green-700",
          chip.captionTone === "attention" && "text-amber-700",
          (chip.captionTone === "muted" || !chip.captionTone) &&
            "text-muted-foreground"
        )}
      >
        {chip.caption ?? " "}
      </span>
    </>
  );
}

function chunk<T>(items: T[], size: number): T[][] {
  const rows: T[][] = [];
  for (let i = 0; i < items.length; i += size) {
    rows.push(items.slice(i, i + size));
  }
  return rows;
}

export function ClaimStageRail({
  chips,
  openStageId,
  onChipClick,
  rowSize = 4,
}: {
  chips: StageRailChip[];
  openStageId?: string | null;
  onChipClick?: (stageId: string) => void;
  rowSize?: number;
}) {
  const rows = chunk(chips, rowSize);
  return (
    <div className="space-y-1.5">
      {rows.map((row, rowIndex) => (
        <div key={rowIndex} className="flex items-stretch">
          {row.map((chip, index) => {
            const clickable = !!chip.clickable && !!onChipClick;
            const isOpen = openStageId === chip.id;
            return (
              <Fragment key={chip.id}>
                {clickable ? (
                  <button
                    type="button"
                    title={chip.title}
                    onClick={() => onChipClick?.(chip.id)}
                    className={chipClass(chip.dot, isOpen, true)}
                  >
                    <ChipContent chip={chip} />
                  </button>
                ) : (
                  <div
                    title={chip.title}
                    className={chipClass(chip.dot, isOpen, false)}
                  >
                    <ChipContent chip={chip} />
                  </div>
                )}
                {index < row.length - 1 && (
                  <Connector done={chip.dot === "done"} />
                )}
              </Fragment>
            );
          })}
        </div>
      ))}
    </div>
  );
}
