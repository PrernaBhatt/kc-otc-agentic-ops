"use client";

import { CircleCheck, Sparkles, TriangleAlert } from "lucide-react";

import { cn } from "@/lib/utils";

/**
 * Plain tables for the stages whose evidence is a list of facts.
 *
 * Only the stages that carry a genuine argument keep a purpose-built visual —
 * the price bridge, the volume column, the weighted findings and the
 * settlement split. Everything else reads better as a table.
 */

export interface FieldRow {
  label: string;
  value: string;
  tone?: "default" | "danger" | "success";
  note?: string;
  /**
   * What the AI flagged about this figure. A row carrying one is tinted amber,
   * so the figures still to be tested stand apart from the ones already
   * established.
   */
  aiNote?: string;
}

/** A field list: what it is, what it says, and what the AI flagged about it. */
export function FieldTable({
  title,
  caption,
  rows,
  emphasise,
}: {
  title: string;
  caption?: string;
  rows: FieldRow[];
  /** Labels rendered in bold with a top rule, for a total line. */
  emphasise?: string[];
}) {
  const hasNotes = rows.some((r) => r.aiNote);

  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-3 flex items-baseline justify-between gap-3">
        <h4 className="text-sm font-semibold">{title}</h4>
        {caption && (
          <span className="whitespace-nowrap text-xs text-muted-foreground">
            {caption}
          </span>
        )}
      </div>
      <table className="w-full text-sm">
        <tbody>
          {rows.map((row) => {
            const strong = emphasise?.includes(row.label);
            return (
              <tr
                key={row.label}
                className={cn(
                  "border-b last:border-0",
                  strong && "border-t-2 border-b-0",
                  row.aiNote && "bg-amber-50/70"
                )}
              >
                <td
                  className={cn(
                    "py-2 pr-4 align-top text-muted-foreground",
                    strong && "font-semibold text-foreground"
                  )}
                >
                  {row.label}
                  {row.note && (
                    <span className="block text-xs text-muted-foreground">
                      {row.note}
                    </span>
                  )}
                </td>
                {/* The note sits between the label and the figure so the
                    figures stay flush right, where a reader scans for them. */}
                {hasNotes && (
                  <td className="w-[17rem] py-2 pr-4 align-top">
                    {row.aiNote && (
                      <span className="inline-flex items-start gap-1.5 rounded-md border border-amber-200 bg-amber-100/60 px-2 py-1 text-xs leading-snug text-amber-900">
                        <Sparkles className="mt-0.5 h-3 w-3 shrink-0" />
                        {row.aiNote}
                      </span>
                    )}
                  </td>
                )}
                <td
                  className={cn(
                    "py-2 text-right align-top tabular-nums",
                    strong && "font-semibold",
                    row.tone === "danger" && "font-medium text-red-600",
                    row.tone === "success" && "font-medium text-[var(--success)]"
                  )}
                >
                  {row.value}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export interface RosterRow {
  project: string;
  detail: string;
  since: string;
  onRoster: boolean;
  note?: string;
}

/** The projects a contract covers, with the claimed project in context. */
export function RosterTable({
  title,
  caption,
  rows,
  footer,
}: {
  title: string;
  caption?: string;
  rows: RosterRow[];
  footer?: string;
}) {
  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-3 flex items-baseline justify-between gap-3">
        <h4 className="text-sm font-semibold">{title}</h4>
        {caption && (
          <span className="whitespace-nowrap text-xs text-muted-foreground">
            {caption}
          </span>
        )}
      </div>
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b text-left text-xs text-muted-foreground">
            <th className="pb-2 font-medium">Project</th>
            <th className="pb-2 font-medium">Location</th>
            <th className="pb-2 font-medium">On the roster since</th>
            <th className="pb-2 text-right font-medium">Status</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr
              key={row.project}
              className={cn(
                "border-b last:border-0",
                !row.onRoster && "bg-red-50/60"
              )}
            >
              <td className="py-2 pr-3 align-top font-medium">
                {row.project}
                {row.note && (
                  <span className="block text-xs font-normal text-muted-foreground">
                    {row.note}
                  </span>
                )}
              </td>
              <td className="py-2 pr-3 align-top text-muted-foreground">
                {row.detail}
              </td>
              <td className="py-2 pr-3 align-top text-muted-foreground">
                {row.since}
              </td>
              <td className="py-2 text-right align-top">
                {row.onRoster ? (
                  <span className="inline-flex items-center gap-1 whitespace-nowrap text-xs text-[var(--success)]">
                    <CircleCheck className="h-3.5 w-3.5" />
                    Covered
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 whitespace-nowrap text-xs font-medium text-red-700">
                    <TriangleAlert className="h-3.5 w-3.5" />
                    Not on this roster
                  </span>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {footer && (
        <p className="mt-3 border-t pt-3 text-xs text-muted-foreground">
          {footer}
        </p>
      )}
    </div>
  );
}

export interface SettlementRow {
  line: string;
  basis: string;
  amount: string;
  tone?: "default" | "danger" | "success";
}

/** What the decision produced, line by line. */
export function SettlementTable({
  rows,
  claimedTotal,
  postingLines,
  footer,
}: {
  rows: SettlementRow[];
  claimedTotal: string;
  postingLines: { account: string; amount: string; side: "Dr" | "Cr" }[];
  footer: string;
}) {
  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-3 flex items-baseline justify-between gap-3">
        <h4 className="text-sm font-semibold">Settlement recorded</h4>
        <span className="whitespace-nowrap text-xs text-muted-foreground">
          {claimedTotal} claimed
        </span>
      </div>
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b text-left text-xs text-muted-foreground">
            <th className="pb-2 font-medium">Line</th>
            <th className="pb-2 font-medium">Basis</th>
            <th className="pb-2 text-right font-medium">Amount</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.line} className="border-b last:border-0">
              <td className="py-2 pr-3 align-top font-medium">{row.line}</td>
              <td className="py-2 pr-3 align-top text-muted-foreground">
                {row.basis}
              </td>
              <td
                className={cn(
                  "py-2 text-right align-top tabular-nums",
                  row.tone === "danger" && "text-red-600",
                  row.tone === "success" && "text-[var(--success)]"
                )}
              >
                {row.amount}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <table className="mt-4 w-full border-t pt-3 text-xs">
        <tbody>
          {postingLines.map((l) => (
            <tr key={`${l.side}-${l.account}`}>
              <td className="py-1 pr-2 font-mono text-muted-foreground">
                {l.side}
              </td>
              <td className="py-1 pr-3">{l.account}</td>
              <td className="py-1 text-right tabular-nums">{l.amount}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="mt-2 text-xs text-muted-foreground">{footer}</p>
    </div>
  );
}
