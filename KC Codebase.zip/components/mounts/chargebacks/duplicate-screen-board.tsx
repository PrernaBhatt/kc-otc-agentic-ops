"use client";

import { useEffect, useState } from "react";
import { Check, Fingerprint, X } from "lucide-react";

import type { DuplicateScreen } from "@/lib/chargeback-selectors";
import { cn } from "@/lib/utils";

/**
 * Duplicate screening, as a field-by-field comparison.
 *
 * A wholesaler supplying a project claims every quarter, so the parties
 * repeating is what an honest relationship looks like — flagging it would flag
 * every honest claim. The table therefore reads down rather than across: the
 * three fields that MUST match are ticked, and the four that must not are
 * crossed. The crosses are the finding.
 */
export function DuplicateScreenBoard({ screen }: { screen: DuplicateScreen }) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    const id = setTimeout(() => setMounted(true), 60);
    return () => clearTimeout(id);
  }, []);

  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-3 flex items-baseline justify-between gap-3">
        <h4 className="text-sm font-semibold">
          This claim against every claim already settled for the same parties
        </h4>
        <span className="whitespace-nowrap text-xs text-muted-foreground">
          {screen.priorCount} already settled
        </span>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full table-fixed text-sm">
          <thead>
            <tr className="border-b text-left text-xs text-muted-foreground">
              <th className="w-[9rem] pb-2 pr-4 font-medium">Field</th>
              {screen.claimIds.map((id, i) => (
                <th key={id} className="pb-2 pr-4 font-medium align-top">
                  <span className={cn(i === 0 && "text-primary")}>{id}</span>
                  <span className="block font-normal">
                    {screen.settledOn[i]
                      ? `settled ${screen.settledOn[i]}`
                      : "under review"}
                  </span>
                </th>
              ))}
              <th className="w-[5rem] pb-2 text-center font-medium">Match</th>
            </tr>
          </thead>
          <tbody>
            {screen.fields.map((f, i) => (
              <tr
                key={f.label}
                className={cn(
                  "border-b last:border-0 transition-all duration-400 motion-reduce:transition-none",
                  f.same ? "bg-[var(--success)]/5" : "bg-amber-50/50"
                )}
                style={{
                  opacity: mounted ? 1 : 0,
                  transitionDelay: `${i * 110}ms`,
                }}
              >
                <td className="py-2 pr-4 align-top text-muted-foreground">
                  {f.label}
                </td>
                {f.values.map((v, j) => (
                  <td
                    key={`${f.label}-${j}`}
                    className={cn(
                      "py-2 pr-4 align-top",
                      j === 0 && "font-medium"
                    )}
                  >
                    {v.map((lineText) => (
                      <span key={lineText} className="block">
                        {lineText}
                      </span>
                    ))}
                  </td>
                ))}
                {/* The mark alone. "Same"/"Different" repeated what the tick
                    and cross already said, and ran off the edge doing it. */}
                <td className="py-2 text-center align-top">
                  {f.same ? (
                    <Check
                      className="mx-auto h-4 w-4 text-[var(--success)]"
                      aria-label="Same"
                    />
                  ) : (
                    <X className="mx-auto h-4 w-4 text-amber-700" aria-label="Different" />
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div
        className={cn(
          "mt-4 flex items-start gap-2 rounded-lg border-2 p-3 transition-opacity duration-500 motion-reduce:transition-none",
          screen.distinct
            ? "border-[var(--success)]/40 bg-[var(--success)]/5"
            : "border-red-300 bg-red-50"
        )}
        style={{ opacity: mounted ? 1 : 0, transitionDelay: "800ms" }}
      >
        <Fingerprint
          className={cn(
            "mt-0.5 h-4 w-4 shrink-0",
            screen.distinct ? "text-[var(--success)]" : "text-red-600"
          )}
        />
        <p className="text-sm">
          {screen.distinct ? (
            <>
              <span className="font-semibold">
                A different payment from every claim already settled.
              </span>{" "}
              <span className="text-muted-foreground">
                The parties and the product are the same, as they are on every
                quarterly claim. The window, the volumes and the invoices are
                not.
              </span>
            </>
          ) : (
            <>
              <span className="font-semibold">
                This payment has already been settled.
              </span>{" "}
              <span className="text-muted-foreground">
                A settled claim covers the same window.
              </span>
            </>
          )}
        </p>
      </div>
    </div>
  );
}
