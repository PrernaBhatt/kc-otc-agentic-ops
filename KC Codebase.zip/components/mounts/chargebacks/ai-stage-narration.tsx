"use client";

import { useEffect, useRef, useState } from "react";
import { Sparkles } from "lucide-react";



import { useTypewriter } from "@/lib/hooks/use-typewriter";
import { cn } from "@/lib/utils";

/**
 * How long the loader holds before the text begins, and how fast the text
 * types. Exported so a run can size its stage dwell to the line it is showing
 * rather than cutting a long line off mid-sentence.
 */
export const NARRATION_GATE_MS = 900;
export const NARRATION_TYPE_MS = 6;

/** Beat left after a line finishes typing, before the run moves on. */
export const NARRATION_SETTLE_MS = 800;

/** How long a stage must hold for its narration to finish and be readable. */
export function narrationDwellMs(text: string, minimumMs: number): number {
  return Math.max(
    minimumMs,
    NARRATION_GATE_MS + text.length * NARRATION_TYPE_MS + NARRATION_SETTLE_MS
  );
}

/**
 * The AI's read of one validation stage: a short gated loader, then the text
 * revealed character by character.
 *
 * The loader is a one-shot gate, not an ambient animation - it runs once when
 * the stage opens and never returns. Because useTypewriter latches once the
 * text is fully revealed, the consumer MUST key this component by stage id so
 * a different stage gets a fresh instance and retypes.
 */
export function AiStageNarration({
  text,
  loaderMs = NARRATION_GATE_MS,
  className,
  playKey,
  children,
  variant = "card",
}: {
  /** "inline" renders a single muted line under the stage title instead of a boxed card. */
  variant?: "card" | "inline";
  /** A single line, or several that render as bullets. */
  text: string | string[];
  loaderMs?: number;
  className?: string;
  /** When set, the narration types only the first time; reopening shows it finished. */
  playKey?: string;
  /** Revealed once the narration has finished typing. */
  children?: React.ReactNode;
}) {
  const alreadyPlayed = !!playKey && playedNarrations.has(playKey);
  const [revealed, setRevealed] = useState(alreadyPlayed);
  const [typed, setTyped] = useState(alreadyPlayed);

  useEffect(() => {
    if (revealed) return;
    const id = setTimeout(() => setRevealed(true), loaderMs);
    return () => clearTimeout(id);
  }, [loaderMs, revealed]);

  useEffect(() => {
    if (typed && playKey) playedNarrations.add(playKey);
  }, [typed, playKey]);

  const body = variant === "inline" ? (
    <div className={cn("flex items-start gap-2", className)}>
      <Sparkles className="mt-1 h-3.5 w-3.5 shrink-0 text-primary" aria-hidden="true" />
      <div className="min-w-0 flex-1">
        {revealed ? (
          <NarrationBody
            text={Array.isArray(text) ? text.join("\n") : text}
            instant={alreadyPlayed}
            muted
            onDone={() => setTyped(true)}
          />
        ) : (
          <div className="h-3 w-2/3 rounded bg-muted animate-agent-pulse mt-1.5" aria-label="AI assessment in progress" />
        )}
      </div>
    </div>
  ) : (
    <div
      className={cn(
        "rounded-lg border bg-gradient-to-br from-white via-gray-50 to-white p-4 shadow-sm",
        className
      )}
    >
      <div className="mb-2 flex items-center gap-2">
        <Sparkles className="h-4 w-4 text-primary" />
        <span className="text-sm font-semibold">AI assessment</span>
      </div>
      {revealed ? (
        <NarrationBody
          text={Array.isArray(text) ? text.join("\n") : text}
          instant={alreadyPlayed}
          onDone={() => setTyped(true)}
        />
      ) : (
        <LoaderBars />
      )}
    </div>
  );

  if (children === undefined) return body;
  return (
    <>
      {body}
      {typed && <div className="flex flex-col gap-3 animate-enter">{children}</div>}
    </>
  );
}

const playedNarrations = new Set<string>();

/**
 * Types the whole assessment as one string, then splits it for rendering, so a
 * multi-point assessment still reveals character by character rather than
 * appearing a bullet at a time.
 */
function NarrationBody({
  text,
  instant = false,
  muted = false,
  onDone,
}: {
  text: string;
  instant?: boolean;
  muted?: boolean;
  onDone?: () => void;
}) {
  const typer = useTypewriter(text, NARRATION_TYPE_MS);
  const visible = instant ? text : typer.visible;
  const done = instant || typer.done;
  const onDoneRef = useRef(onDone);
  onDoneRef.current = onDone;
  useEffect(() => {
    if (done) onDoneRef.current?.();
  }, [done]);
  const lines = visible.split("\n");
  const caret = !done && (
    <span className="ml-0.5 inline-block h-4 w-[2px] align-middle bg-primary animate-caret-blink" />
  );

  const tone = muted ? "text-muted-foreground" : "text-foreground";
  if (lines.length === 1) {
    return (
      <p className={cn("text-sm leading-relaxed", tone)}>
        {lines[0]}
        {caret}
      </p>
    );
  }

  return (
    <ul className={cn("space-y-1 text-sm leading-relaxed", tone)}>
      {lines.map((line, i) => (
        <li key={i} className="flex gap-2">
          <span className="select-none text-muted-foreground">•</span>
          <span>
            {line}
            {i === lines.length - 1 && caret}
          </span>
        </li>
      ))}
    </ul>
  );
}

/** Three bars that pulse while the AI works, then unmount for good. */
function LoaderBars() {
  return (
    <div className="space-y-2" aria-label="AI assessment in progress">
      {[100, 92, 64].map((width, i) => (
        <div
          key={width}
          className="h-3 rounded bg-muted animate-agent-pulse"
          style={{ width: `${width}%`, animationDelay: `${i * 120}ms` }}
        />
      ))}
    </div>
  );
}
