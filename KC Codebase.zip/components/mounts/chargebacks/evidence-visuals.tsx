"use client";

import { useEffect, useState } from "react";
import { Check, X } from "lucide-react";

import { CountUp } from "@/components/ui/count-up";
import { type DuplicateComparison } from "@/lib/chargeback-selectors";
import { cn } from "@/lib/utils";

function useMounted(delayMs = 50) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    const id = setTimeout(() => setMounted(true), delayMs);
    return () => clearTimeout(id);
  }, [delayMs]);
  return mounted;
}

/**
 * Two claims, superimposed.
 *
 * A difference table shows what differs. Sameness needs the opposite: the two
 * claims slide together and every field that matches lights up, until only the
 * claim number is left standing apart.
 */
export function DuplicateOverlay({
  comparison,
}: {
  comparison: DuplicateComparison;
}) {
  const mounted = useMounted();
  const matched = comparison.fields.filter((f) => f.match).length;

  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-3 flex items-start justify-between gap-4">
        <div>
          <h4 className="text-sm font-semibold">
            Duplicate screening
          </h4>
          <p className="mt-0.5 text-xs text-muted-foreground">
            {comparison.candidate.claimId} against{" "}
            {comparison.settled.claimId}, settled{" "}
            {comparison.daysSinceSettled} days ago
          </p>
        </div>
        <div className="shrink-0 text-right">
          <div className="text-2xl font-bold leading-none text-red-600 tabular-nums">
            <CountUp
              value={comparison.matchConfidence * 100}
              durationMs={1200}
              format={(n) => `${Math.round(n)}%`}
            />
          </div>
          <div className="text-xs text-muted-foreground">match</div>
        </div>
      </div>

      {/* Field name first: without it the reader sees "5,000" against "5,000"
          with no way to know what is being compared. */}
      <div className="overflow-hidden rounded-lg border">
        <div className="grid grid-cols-[8rem_1fr_auto_1fr] items-center gap-x-3 bg-muted/40 px-3 py-1.5">
          <span className="text-xs text-muted-foreground">Field</span>
          <span className="truncate text-xs font-medium">
            {comparison.candidate.claimId} · under review
          </span>
          <span className="w-4" aria-hidden />
          <span className="truncate text-right text-xs font-medium">
            {comparison.settled.claimId} · settled
          </span>
        </div>
        {comparison.fields.map((f, i) => (
          <div
            key={f.label}
            className={cn(
              "grid grid-cols-[8rem_1fr_auto_1fr] items-center gap-x-3 border-t px-3 py-1.5 transition-all duration-300 ease-out motion-reduce:transition-none",
              f.match ? "bg-red-50/60" : "bg-card"
            )}
            style={{
              opacity: mounted ? 1 : 0,
              transitionDelay: `${i * 70}ms`,
            }}
          >
            <span className="truncate text-xs text-muted-foreground">
              {f.label}
            </span>
            <span className="truncate text-xs tabular-nums">
              {f.candidateValue}
            </span>
            <span
              className={cn(
                "flex h-4 w-4 items-center justify-center rounded-full",
                f.match ? "bg-red-500 text-white" : "bg-muted text-muted-foreground"
              )}
              title={f.match ? "Identical" : "Differs"}
            >
              {f.match ? <Check className="h-3 w-3" /> : <X className="h-3 w-3" />}
            </span>
            <span className="truncate text-right text-xs tabular-nums">
              {f.settledValue}
            </span>
          </div>
        ))}
      </div>

      <p className="mt-3 text-xs text-muted-foreground">
        {matched} of {comparison.fields.length} identifying fields match. The
        claim number is the only difference.
      </p>
    </div>
  );
}
