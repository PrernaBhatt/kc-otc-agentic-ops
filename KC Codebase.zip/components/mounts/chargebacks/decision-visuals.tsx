"use client";

import { useEffect, useState } from "react";
import { CircleCheck, Sparkles } from "lucide-react";

import { CountUp } from "@/components/ui/count-up";
import type { RiskDimensionScore } from "@/lib/data/chargebacks";
import { formatUsd } from "@/lib/chargeback-selectors";
import { cn } from "@/lib/utils";

/**
 * Assessment summary: the recommended settlement and the weighted findings
 * behind it.
 *
 * Each row is a finding. Row height is its weight, fill is its severity, and
 * the right-hand column prints both. The card carries no commentary on its own
 * construction.
 */
export function RiskWeightStack({
  dimensions,
  score,
  weightsSum,
  confidencePercent,
  onDimensionClick,
}: {
  dimensions: RiskDimensionScore[];
  score: number;
  weightsSum: number;
  confidencePercent: number;
  onDimensionClick?: (stageId: string) => void;
}) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    const id = requestAnimationFrame(() => setMounted(true));
    return () => cancelAnimationFrame(id);
  }, []);

  const weightsClose = Math.abs(weightsSum - 1) < 0.0001;
  const passed = dimensions.filter((d) => d.score === 0);
  const failed = dimensions.filter((d) => d.score > 0);

  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-3 flex items-start justify-between gap-4">
        <h4 className="min-w-0 text-sm font-semibold">Assessment summary</h4>
        <div className="shrink-0 text-right">
          <div className="text-3xl font-bold leading-none tabular-nums">
            <CountUp
              value={confidencePercent}
              durationMs={1400}
              format={(n) => `${Math.round(n)}%`}
            />
          </div>
          <div className="text-xs text-muted-foreground">AI confidence</div>
        </div>
      </div>

      {/* A check that scored nothing is not a finding, and putting it in the
          same weighted bar as the one that failed made three passes look like
          three problems. Passes are listed as passes; only what failed carries
          the arithmetic. */}
      {passed.length > 0 && (
        <div className="mb-3">
          <p className="mb-1.5 text-xs text-muted-foreground">Checks passed</p>
          <div className="space-y-1">
            {passed.map((d) => (
              <button
                key={d.key}
                type="button"
                onClick={() => onDimensionClick?.(d.stageId)}
                title={d.finding}
                className={cn(
                  "flex w-full items-center gap-2 rounded border border-[var(--success)]/30",
                  "bg-[var(--success)]/5 px-2 py-1.5 text-left transition-all",
                  onDimensionClick &&
                    "cursor-pointer hover:ring-1 hover:ring-primary/40"
                )}
              >
                <CircleCheck className="h-3.5 w-3.5 shrink-0 text-[var(--success)]" />
                <span className="min-w-0 flex-1 truncate text-xs font-medium">
                  {d.label}
                </span>
                <span className="shrink-0 text-xs text-[var(--success)]">
                  Passed
                </span>
              </button>
            ))}
          </div>
        </div>
      )}

      {failed.length > 0 && (
        <>
          <div className="mb-1.5 flex items-center justify-between gap-2 text-xs text-muted-foreground">
            <span>What the score is built on</span>
            <span>Weight × severity</span>
          </div>

          <div className="flex w-full flex-col gap-0.5">
            {failed.map((d, i) => (
              <button
                key={d.key}
                type="button"
                onClick={() => onDimensionClick?.(d.stageId)}
                title={d.finding}
                className={cn(
                  "relative w-full overflow-hidden rounded border bg-muted/50 text-left transition-all",
                  onDimensionClick &&
                    "cursor-pointer hover:ring-1 hover:ring-primary/40"
                )}
                style={{ height: `${Math.max(2.5, d.weight * 8)}rem` }}
              >
                <div
                  className="absolute inset-y-0 left-0 bg-red-500/25 transition-all duration-700 ease-out motion-reduce:transition-none"
                  style={{
                    width: mounted ? `${d.score}%` : "0%",
                    transitionDelay: `${i * 120}ms`,
                  }}
                />
                <div className="relative flex h-full items-center justify-between gap-2 px-2">
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-xs font-medium">
                      {d.label}
                    </span>
                    <span className="block truncate text-xs text-muted-foreground">
                      {d.finding}
                    </span>
                  </span>
                  <span className="shrink-0 text-xs tabular-nums text-muted-foreground">
                    {Math.round(d.weight * 100)}% × {d.score}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </>
      )}

      <div className="mt-3 flex flex-wrap items-center justify-end gap-2 border-t pt-3 text-xs">
        <span
          className={cn(
            "whitespace-nowrap rounded px-2 py-0.5 font-medium",
            weightsClose
              ? "bg-muted text-muted-foreground"
              : "bg-amber-50 text-amber-700"
          )}
        >
          {weightsClose
            ? `Weighted exception score ${score}`
            : `Weighted exception score ${score} · incomplete weighting`}
        </span>
      </div>
    </div>
  );
}

/**
 * The claim, carved.
 *
 * One bar for what was asked, split into what we can support and the two
 * separate reasons the rest cannot be. It animates as a single grey bar first
 * and is then cut into pieces, because the carving is the human's act, not a
 * fact that arrived pre-sorted.
 */
export function ClaimDecisionSplitter({
  claimedTotal,
  approveAmount,
  priceRejectAmount,
  quantityRejectAmount,
  supportedUnits,
  approvedPrice,
  unitsException,
  unsupportedRateDelta,
}: {
  claimedTotal: number;
  approveAmount: number;
  priceRejectAmount: number;
  quantityRejectAmount: number;
  supportedUnits: number;
  approvedPrice: number;
  unitsException: number;
  unsupportedRateDelta: number;
}) {
  const [phase, setPhase] = useState<0 | 1 | 2>(0);
  const [hovered, setHovered] = useState<string | null>(null);

  useEffect(() => {
    const a = requestAnimationFrame(() => setPhase(1));
    const b = setTimeout(() => setPhase(2), 600);
    return () => {
      cancelAnimationFrame(a);
      clearTimeout(b);
    };
  }, []);

  const segments = [
    {
      key: "approve",
      label: "Approve",
      amount: approveAmount,
      className: "bg-[var(--success)]",
      note:
        approveAmount === 0
          ? `No chargeback arises: this project is invoiced at $${approvedPrice.toFixed(2)}, the same price the wholesaler paid`
          : `${supportedUnits.toLocaleString("en-US")} units invoiced and delivered × $${(approveAmount / supportedUnits).toFixed(2)} per unit, down to the approved price of $${approvedPrice.toFixed(2)}`,
    },
    {
      key: "quantity",
      label: "Reject · no delivery record",
      amount: quantityRejectAmount,
      className: "bg-red-500",
      note: `${unitsException.toLocaleString("en-US")} units with no invoice or delivery record`,
    },
    {
      key: "price",
      label: "Reject · price not approved",
      amount: priceRejectAmount,
      className: "bg-amber-500",
      note: `$${unsupportedRateDelta.toFixed(2)} per unit below the approved price, across the supportable units`,
    },
    // A segment worth nothing is not a finding. Rendering "$0" beside two real
    // amounts invited the reader to look for a third cause that is not there.
  ].filter((seg) => seg.amount > 0);

  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-3 flex items-baseline justify-between gap-3">
        <h4 className="text-sm font-semibold">Settlement breakdown</h4>
        <span className="text-sm font-semibold tabular-nums whitespace-nowrap">
          {formatUsd(claimedTotal)} claimed
        </span>
      </div>

      <div className="flex h-12 w-full overflow-hidden rounded-lg border">
        {segments.map((s) => (
          <div
            key={s.key}
            onMouseEnter={() => setHovered(s.key)}
            onMouseLeave={() => setHovered(null)}
            className={cn(
              "h-full transition-all duration-500 ease-out motion-reduce:transition-none",
              phase === 2 ? s.className : "bg-slate-300",
              hovered && hovered !== s.key && "opacity-40"
            )}
            style={{
              width: phase === 0 ? "0%" : `${(s.amount / claimedTotal) * 100}%`,
            }}
          />
        ))}
      </div>

      {/* Each card takes the width of its own segment, so the card for the
          rejected amount begins exactly where the red begins. In an even grid
          the two were unmoored from the bar they describe. */}
      <div className="mt-3 flex flex-col gap-3 sm:flex-row">
        {segments.map((s) => (
          <div
            key={s.key}
            onMouseEnter={() => setHovered(s.key)}
            onMouseLeave={() => setHovered(null)}
            className={cn(
              "flex min-w-0 flex-col rounded-lg border p-3 transition-opacity",
              hovered && hovered !== s.key && "opacity-50"
            )}
            style={{
              flex: `${(s.amount / claimedTotal) * 100} 1 0%`,
            }}
          >
            <div className="flex items-center gap-2">
              <span className={cn("h-2.5 w-2.5 shrink-0 rounded-sm", s.className)} />
              <span className="text-xs font-medium leading-tight">{s.label}</span>
            </div>
            <div className="mt-1 text-lg font-bold tabular-nums">
              <CountUp value={s.amount} format={formatUsd} durationMs={1100} />
            </div>
            <p className="mt-auto pt-1 text-xs text-muted-foreground">{s.note}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
