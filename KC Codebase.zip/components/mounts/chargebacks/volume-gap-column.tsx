"use client";

import { useEffect, useState } from "react";
import { CalendarX2 } from "lucide-react";

import { CountUp } from "@/components/ui/count-up";
import type { ClaimPeriodActivityRow } from "@/lib/data/claim-period-activity";
import type { AllocationCeiling } from "@/lib/chargeback-selectors";
import { cn } from "@/lib/utils";

export interface VolumeGapColumnProps {
  claimedUnits: number;
  supportedRows: ClaimPeriodActivityRow[];
  excludedRows: ClaimPeriodActivityRow[];
  supportedUnits: number;
  ceiling: AllocationCeiling | null;
}

/**
 * The volume gap.
 *
 * One column stands for the units the claim asks for. It fills from the bottom
 * with one segment per invoice we actually raised - you watch the claim get
 * backed up document by document, and then run out of documents. What is left
 * is empty, hatched air.
 *
 * A dashed line marks the most units that could physically have shipped in the
 * window. The claim's own ceiling sits above it, so the gap is not merely
 * undocumented - it is impossible.
 */
export function VolumeGapColumn({
  claimedUnits,
  supportedRows,
  excludedRows,
  supportedUnits,
  ceiling,
}: VolumeGapColumnProps) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    const id = requestAnimationFrame(() => setMounted(true));
    return () => cancelAnimationFrame(id);
  }, []);

  const pct = (units: number) => (units / claimedUnits) * 100;
  const gapUnits = Math.max(0, claimedUnits - supportedUnits);

  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-4 flex items-baseline justify-between gap-3">
        <h4 className="text-sm font-semibold">
          Claimed units against supported units
        </h4>
        <span className="text-xs text-muted-foreground whitespace-nowrap">
          {supportedRows.length} invoices matched
        </span>
      </div>

      <div className="flex gap-6">
        {/* The column */}
        <div className="relative w-40 shrink-0">
          <div className="relative h-64 rounded-md border-2 border-slate-300 bg-slate-50 overflow-hidden">
            {/* Empty, hatched air above the fill */}
            <div
              className="absolute inset-x-0 top-0 transition-all duration-500 ease-out motion-reduce:transition-none"
              style={{
                height: mounted ? `${pct(gapUnits)}%` : "0%",
                transitionDelay: "1200ms",
                backgroundImage:
                  "repeating-linear-gradient(45deg, rgba(220,38,38,0.16) 0 6px, transparent 6px 12px)",
              }}
            >
              <div className="flex h-full flex-col items-center justify-center px-2 text-center">
                <span className="text-sm font-bold text-red-600 tabular-nums">
                  <CountUp value={gapUnits} durationMs={700} />
                </span>
                <span className="text-xs leading-tight text-red-600">
                  Units with no invoice
                  <br />
                  and no delivery
                </span>
              </div>
            </div>

            {/* One segment per invoice, stacked from the bottom */}
            <div className="absolute inset-x-0 bottom-0 flex flex-col-reverse">
              {supportedRows.map((row, i) => (
                <div
                  key={row.activityId}
                  className="flex items-center justify-center border-t border-white/70 bg-[var(--success)]/25 transition-all duration-300 ease-out motion-reduce:transition-none"
                  style={{
                    height: mounted
                      ? `${(pct(row.units) / 100) * 256}px`
                      : "0px",
                    transitionDelay: `${200 + i * 200}ms`,
                  }}
                >
                  <span className="text-xs font-medium text-green-800 tabular-nums">
                    {row.units.toLocaleString("en-US")}
                  </span>
                </div>
              ))}
            </div>

            {/* The most that could physically have shipped */}
            {ceiling && (
              <div
                className="absolute inset-x-0 border-t-2 border-dashed border-amber-500 transition-opacity duration-500 motion-reduce:transition-none"
                style={{
                  bottom: `${pct(ceiling.ceilingUnits)}%`,
                  opacity: mounted ? 1 : 0,
                  transitionDelay: "1500ms",
                }}
              />
            )}
          </div>

          <p className="mt-2 text-center text-xs">
            <span className="font-semibold tabular-nums">
              {claimedUnits.toLocaleString("en-US")}
            </span>{" "}
            <span className="text-muted-foreground">units claimed</span>

          </p>
        </div>

        {/* What backs it, and what does not */}
        <div className="min-w-0 flex-1">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b text-left text-muted-foreground">
                <th className="pb-1.5 font-medium">Invoice</th>
                <th className="pb-1.5 font-medium">Date</th>
                <th className="pb-1.5 text-right font-medium">Units</th>
              </tr>
            </thead>
            <tbody>
              {supportedRows.map((row) => (
                <tr key={row.activityId} className="border-b last:border-0">
                  <td className="py-1.5 font-medium">{row.invoiceRef}</td>
                  <td className="py-1.5 text-muted-foreground">
                    {row.invoiceDate}
                  </td>
                  <td className="py-1.5 text-right tabular-nums">
                    {row.units.toLocaleString("en-US")}
                  </td>
                </tr>
              ))}
              <tr className="border-t-2">
                <td className="pt-1.5 font-semibold" colSpan={2}>
                  Invoiced and delivered in the claim window
                </td>
                <td className="pt-1.5 text-right font-semibold tabular-nums">
                  {supportedUnits.toLocaleString("en-US")}
                </td>
              </tr>
            </tbody>
          </table>

          {excludedRows.map((row) => (
            <div
              key={row.activityId}
              className={cn(
                "mt-3 flex items-start gap-2 rounded-md border border-dashed",
                "bg-muted/40 px-3 py-2"
              )}
            >
              <CalendarX2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-muted-foreground" />
              <p className="text-xs text-muted-foreground">
                <span className="font-medium text-foreground">
                  {row.invoiceRef}
                </span>{" "}
                — {row.units.toLocaleString("en-US")} units on {row.invoiceDate}
                . Excluded: dated after the claim window closed.
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
