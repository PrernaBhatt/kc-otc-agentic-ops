"use client";

import { GitCommitVertical, Sparkles } from "lucide-react";

import { windowGap } from "@/components/mounts/shipments/eta-track";
import { lateLabel } from "@/components/mounts/shipments/route-options";
import { SystemMark } from "@/components/shared/system-badge";
import { TypedText } from "@/components/shared/typed-text";
import type { EtaPrediction } from "@/lib/data/loads";
import { MILK_RUN_CASE } from "@/lib/data/shipment-risk";
import { formatUsd } from "@/lib/format";
import { fmtHm, hm, predictLeg } from "@/lib/shipment-selectors";
import { cn } from "@/lib/utils";

const STEP = 140;

/** Left of the settled Track step: what the agent concluded, in figures first and two-line takeaways second. */
export function TrackAiSummary({ prediction, agent }: { prediction: EtaPrediction; agent: string }) {
  const m = MILK_RUN_CASE;
  const preds = prediction.legs.map((leg) => predictLeg(prediction, leg));
  const lates = preds.map((p) => windowGap(p).late).filter((x) => x > 0);
  const departLate = hm(m.actualDepart) - hm(m.plannedDepart);
  const lateStops = new Set(preds.filter((p) => windowGap(p).late > 0).map((p) => p.leg.stop));
  const atStake = m.stops.filter((s) => lateStops.has(s.id)).reduce((a, s) => a + s.valueUsd, 0);
  const peta = preds.find((p) => p.leg.fourKitesPeta);
  const covered = preds.filter((p) => p.leg.fourKitesPeta).length;

  const stats = [
    { k: "Departed", v: m.actualDepart, sub: `${lateLabel(departLate)} late`, tone: "text-red-700" },
    { k: "Last ping", v: prediction.pingAt, sub: prediction.position, tone: "text-muted-foreground" },
    { k: "Outside window", v: `${lates.length} of ${preds.length}`, sub: `${formatUsd(atStake)} at stake`, tone: lates.length ? "text-red-700" : "text-green-700" },
  ];
  const lines = [
    `${m.delayReason} held the truck ${lateLabel(departLate).slice(1)}. Every stop after it inherits the delay.`,
    peta
      ? `FourKites predicts ${covered} of ${preds.length} stops (${peta.leg.fourKitesPeta}). The agent predicted all ${preds.length}${peta.leg.fourKitesPeta === fmtHm(peta.p50) ? " and matches it" : ""}.`
      : `FourKites gives no PETA here. The agent predicted all ${preds.length} stops.`,
    lates.length
      ? `Stops land ${Math.min(...lates)}–${Math.max(...lates)} min after their window closes. Reordering the run is the next check.`
      : "Every stop lands inside its window.",
  ];

  return (
    <section className="animate-enter flex h-full flex-col gap-3 rounded-lg border bg-card px-4 py-3" aria-labelledby="track-ai-summary">
      <header className="flex items-center gap-2">
        <Sparkles className="h-4 w-4 text-[var(--info)]" aria-hidden />
        <h4 id="track-ai-summary" className="text-sm font-semibold text-foreground">
          AI summary
        </h4>
        <span className="ml-auto truncate rounded-md border bg-muted/30 px-1.5 py-0.5 text-[11px] text-muted-foreground">{agent}</span>
      </header>
      <dl className="grid grid-cols-3 gap-2">
        {stats.map((s, i) => (
          <div key={s.k} className="animate-enter flex min-w-0 flex-col rounded-md bg-muted/40 px-2.5 py-2" style={{ animationDelay: `${i * 80}ms` }}>
            <dt className="text-[11px] text-muted-foreground">{s.k}</dt>
            <dd className="font-mono text-base font-semibold text-foreground tabular-nums">{s.v}</dd>
            <dd className={cn("text-[11px] font-medium leading-snug text-pretty", s.tone)}>
              {s.sub}
            </dd>
          </div>
        ))}
      </dl>
      <ul className="flex flex-1 flex-col gap-2">
        {lines.map((l, i) => (
          <li key={l} className="animate-enter flex gap-2 rounded-md border border-[var(--info)]/15 bg-[var(--info)]/5 px-2.5 py-2 text-[13px] leading-relaxed text-foreground" style={{ animationDelay: `${300 + i * 120}ms` }}>
            <Sparkles className="mt-1 h-3.5 w-3.5 shrink-0 text-[var(--info)]" aria-hidden />
            <TypedText text={l} delayMs={300 + i * 700} maxMs={650} className="text-pretty" />
          </li>
        ))}
      </ul>
    </section>
  );
}

type Node = { key: string; at: string; label: string; detail: string; system: string; kind: "actual" | "now" | "predicted"; chip?: { text: string; tone: string } };

/** Right of the settled Track step: the load from tender to the last stop, read top to bottom. Solid = FourKites events, dashed = agent predictions. */
export function LoadTimeline({ prediction }: { prediction: EtaPrediction }) {
  const m = MILK_RUN_CASE;
  const preds = prediction.legs.map((leg) => predictLeg(prediction, leg));
  const departLate = hm(m.actualDepart) - hm(m.plannedDepart);

  const nodes: Node[] = [
    ...m.feed.map((f, i): Node => ({
      key: f.at,
      at: f.at,
      label: f.event,
      detail: f.detail,
      system: "FourKites",
      kind: i === m.feed.length - 1 ? "now" : "actual",
      chip:
        f.at === m.actualDepart
          ? { text: `${lateLabel(departLate)} late`, tone: "border-red-200 bg-red-50 text-red-700" }
          : i === m.feed.length - 1
            ? { text: "Last ping", tone: "border-[var(--info)]/25 bg-[var(--info)]/10 text-[var(--info)]" }
            : undefined,
    })),
    ...preds.map((p): Node => {
      const { late, wait } = windowGap(p);
      return {
        key: p.leg.stop,
        at: fmtHm(p.p50),
        label: `Arrive ${p.leg.customer}`,
        detail: `Window ${p.leg.windowFrom}–${p.leg.windowTo} · agent p50`,
        system: p.leg.customer,
        kind: "predicted",
        chip: late
          ? { text: `+${late} min`, tone: "border-red-200 bg-red-50 text-red-700" }
          : wait
            ? { text: `Waits ${wait} min`, tone: "border-amber-200 bg-amber-50 text-amber-700" }
            : { text: "On time", tone: "border-green-200 bg-green-100 text-green-700" },
      };
    }),
  ];

  return (
    <section className="animate-enter flex h-full flex-col gap-3 rounded-lg border bg-card px-4 py-3" style={{ animationDelay: "80ms" }} aria-labelledby="load-timeline">
      <header className="flex items-center gap-2">
        <GitCommitVertical className="h-4 w-4 text-[var(--info)]" aria-hidden />
        <h4 id="load-timeline" className="text-sm font-semibold text-foreground">
          Load timeline
        </h4>
        <span className="ml-auto flex items-center gap-1.5 rounded-md border px-1.5 py-0.5 font-mono text-[11px] text-muted-foreground">
          <SystemMark name="FourKites" /> {m.loadId}
        </span>
      </header>
      <ol className="flex flex-col">
        {nodes.map((n, i) => {
          const last = i === nodes.length - 1;
          const nextPredicted = nodes[i + 1]?.kind === "predicted";
          const delay = { animationDelay: `${200 + i * STEP}ms` };
          return (
            <li key={n.key} className="grid grid-cols-[1rem_minmax(0,1fr)_auto] gap-x-3">
              <span className="relative flex justify-center">
                <span
                  className={cn(
                    "step-pop relative z-10 mt-1 block size-3 rounded-full border-2",
                    n.kind === "predicted" ? "border-dashed border-[var(--info)] bg-card" : "border-[var(--info)]",
                    n.kind === "actual" && "bg-card",
                    n.kind === "now" && "step-halo bg-[var(--info)] [--halo:6px]"
                  )}
                  style={delay}
                  aria-hidden
                />
                {!last && (
                  <span
                    className={cn(
                      "animate-enter-fade absolute top-4 bottom-0 block",
                      nextPredicted ? "border-l-2 border-dashed border-[var(--info)]/35" : "w-0.5 bg-[var(--info)]/30"
                    )}
                    style={{ animationDelay: `${280 + i * STEP}ms` }}
                    aria-hidden
                  />
                )}
              </span>
              <span className={cn("animate-enter flex min-w-0 flex-col", !last && "pb-3")} style={delay}>
                <span className="flex min-w-0 items-center gap-1.5">
                  <SystemMark name={n.system} />
                  <span className={cn("truncate text-[13px] font-semibold", n.kind === "predicted" ? "text-foreground/85" : "text-foreground")} title={n.label}>
                    {n.label}
                  </span>
                </span>
                <span className="text-[11px] leading-snug text-muted-foreground text-pretty">{n.detail}</span>
              </span>
              <span className="animate-enter-fade flex flex-col items-end gap-1 pt-0.5" style={delay}>
                <span className={cn("font-mono text-[13px] tabular-nums", n.kind === "predicted" ? "text-muted-foreground" : "font-semibold text-foreground")}>{n.at}</span>
                {n.chip && <span className={cn("whitespace-nowrap rounded-md border px-1.5 py-px text-[10px] font-semibold tabular-nums", n.chip.tone)}>{n.chip.text}</span>}
              </span>
            </li>
          );
        })}
      </ol>
    </section>
  );
}
