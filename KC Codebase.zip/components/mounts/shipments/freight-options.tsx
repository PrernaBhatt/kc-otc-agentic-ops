"use client";

import { useEffect, useRef, useState } from "react";

import { Spinner } from "@/components/agents/spinner";
import { CheckChip } from "@/components/shared/check-chip";
import { PREMIUM_CASE } from "@/lib/data/shipment-risk";
import { formatUsd } from "@/lib/format";
import { optionOutcome, premiumFreight, shortStamp } from "@/lib/shipment-selectors";
import { cn } from "@/lib/utils";

const played = new Set<string>();

/**
 * The three ways to protect the Kroger window, judged one by one against on
 * time and in full. Read only: the choice is made at the approval gate.
 */
export function FreightOptions({ playKey, onDone }: { playKey: string; onDone?: () => void }) {
  const b = PREMIUM_CASE;
  const [judged, setJudged] = useState(() => (played.has(playKey) ? b.options.length : 0));
  const finished = judged >= b.options.length;
  const doneRef = useRef(onDone);
  doneRef.current = onDone;

  useEffect(() => {
    if (finished) {
      played.add(playKey);
      doneRef.current?.();
      return;
    }
    const t = window.setTimeout(() => setJudged((n) => n + 1), 700);
    return () => window.clearTimeout(t);
  }, [finished, judged, playKey]);

  return (
    <ul className="flex flex-col gap-2" aria-label="Freight options">
      {b.options.map((o, i) => {
        const out = optionOutcome(o.id);
        const done = i < judged;
        const lit = finished && o.recommended;
        return (
          <li
            key={o.id}
            data-freight-option={o.id}
            className={cn(
              "animate-enter-fade grid gap-2 rounded-lg border bg-card px-3 py-2.5 transition-colors duration-500 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center",
              lit && "border-[var(--success)] bg-green-50/60"
            )}
            style={{ animationDelay: `${i * 80}ms` }}
          >
            <div className="flex min-w-0 flex-col gap-0.5">
              <span className="flex flex-wrap items-center gap-1.5 text-sm font-medium text-foreground">
                <span className="font-mono text-xs text-muted-foreground">{String.fromCharCode(65 + i)}</span>
                {o.label}
                {lit && (
                  <span className="animate-enter-fade rounded-md bg-[var(--success)] px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-[var(--success-foreground)]">
                    Recommended
                  </span>
                )}
              </span>
              <span className="truncate text-xs text-muted-foreground">
                {o.carrier} · pickup {shortStamp(o.pickup)} · ETA {shortStamp(o.eta)}
              </span>
              <span className="text-xs tabular-nums text-foreground">
                {formatUsd(o.rateUsd)}
                {o.id === "keep" && <span className="text-muted-foreground"> · fine risk {formatUsd(premiumFreight.fineUsd)}</span>}
                {o.id === "team" && <span className="text-muted-foreground"> · premium {formatUsd(premiumFreight.premiumUsd)}</span>}
                {o.id === "dc-atl" && <span className="text-muted-foreground"> · {o.pallets} of {b.pallets} pallets</span>}
              </span>
            </div>
            <div className="flex items-center gap-1.5">
              {done ? (
                <>
                  <span className="animate-enter-fade">
                    <CheckChip result={out.onTime ? "pass" : "flag"}>
                      {out.onTime ? "On time" : `${out.lateDays} day late`}
                    </CheckChip>
                  </span>
                  <span className="animate-enter-fade">
                    <CheckChip result={out.inFull ? "pass" : "flag"}>{out.inFull ? "In full" : "Short"}</CheckChip>
                  </span>
                </>
              ) : (
                <Spinner size="sm" className={cn("text-primary", i > judged && "opacity-30")} />
              )}
            </div>
          </li>
        );
      })}
    </ul>
  );
}
