"use client";

import { ChevronLeft, ChevronRight } from "lucide-react";

import { OtifRiskChip } from "@/components/mounts/shipments/eta-prediction-card";
import { Tip } from "@/components/shared/floating-tip";
import { SystemMark } from "@/components/shared/system-badge";
import { Button } from "@/components/ui/button";
import { LOAD_MILESTONES, type EtaSource, type NetworkLoad } from "@/lib/data/loads";
import { loadStatus, predictLoad, type LoadStatus } from "@/lib/shipment-selectors";
import { cn } from "@/lib/utils";

export type ShownStatus = LoadStatus | "Recovered";

export const STATUS_TONE: Record<ShownStatus, string> = {
  "On track": "border-green-200 bg-green-50 text-green-700",
  Watch: "border-amber-200 bg-amber-50 text-amber-700",
  "At risk": "border-red-200 bg-red-50 text-red-700",
  Delivered: "border-green-200 bg-green-100 text-green-800",
  "Delivered late": "border-red-200 bg-red-50 text-red-700",
  Recovered: "border-green-200 bg-green-100 text-green-800",
};

export const SOURCE_TONE: Record<EtaSource, string> = {
  "TMS plan": "border-border bg-muted/40 text-muted-foreground",
  "FourKites PETA": "border-sky-200 bg-sky-50 text-sky-700",
  "Agent ETA": "border-primary/30 bg-primary/5 text-primary",
  POD: "border-green-200 bg-green-50 text-green-700",
};

export function shownStatus(l: NetworkLoad, resolved: Record<string, string>): ShownStatus {
  const s = loadStatus(l);
  return l.caseId && resolved[l.caseId] && (s === "At risk" || s === "Watch") ? "Recovered" : s;
}

export function StatusChip({ status }: { status: ShownStatus }) {
  return (
    <span className={cn("inline-flex whitespace-nowrap rounded-md border px-1.5 py-0.5 text-[11px] font-semibold", STATUS_TONE[status])}>
      {status}
    </span>
  );
}

/** Six milestone dots: reached = filled, current pulses (amber / red when at risk). */
export function MilestoneDots({ load, status }: { load: NetworkLoad; status: ShownStatus }) {
  const last = LOAD_MILESTONES.length - 1;
  const hot = status === "At risk" ? "bg-red-500" : status === "Watch" ? "bg-amber-500" : "bg-primary";
  return (
    <ol className="flex items-center" aria-label={`Milestone: ${LOAD_MILESTONES[load.stage]}`}>
      {LOAD_MILESTONES.map((m, i) => {
        const reached = i <= load.stage;
        const current = i === load.stage && i !== last;
        return (
          <li key={m} className="flex items-center">
            {i > 0 && <span className={cn("h-px w-4", i <= load.stage ? "bg-primary/60" : "bg-border")} aria-hidden />}
            <Tip
              content={{ title: m, value: load.times[i] ?? "Pending" }}
              className={cn(
                "relative block h-2.5 w-2.5 rounded-full border",
                reached ? cn("border-transparent", current ? hot : "bg-primary/70") : "border-border bg-card",
                current && "ring-2 ring-offset-1 ring-offset-card",
                current && (status === "At risk" ? "ring-red-200" : status === "Watch" ? "ring-amber-200" : "ring-primary/20")
              )}
            />
          </li>
        );
      })}
    </ol>
  );
}

export const PAGE_SIZE = 10;

export function LoadList({
  loads,
  page,
  onPage,
  selectedId,
  onSelect,
  resolved,
}: {
  loads: NetworkLoad[];
  page: number;
  onPage: (p: number) => void;
  selectedId: string | null;
  onSelect: (id: string) => void;
  resolved: Record<string, string>;
}) {
  const pages = Math.max(1, Math.ceil(loads.length / PAGE_SIZE));
  const shown = loads.slice(page * PAGE_SIZE, page * PAGE_SIZE + PAGE_SIZE);

  return (
    <div className="flex min-w-0 flex-col overflow-hidden rounded-xl border bg-card">
      <div className="hidden grid-cols-[minmax(0,1.5fr)_140px_minmax(0,1fr)_minmax(0,0.9fr)_172px] gap-4 border-b bg-muted/30 px-4 py-2 text-[11px] font-medium uppercase tracking-wide text-muted-foreground lg:grid">
        <span>Load</span>
        <span>Milestones</span>
        <span>ETA</span>
        <span>Window</span>
        <span className="text-right">Status</span>
      </div>
      {shown.length === 0 ? (
        <p className="px-4 py-10 text-center text-sm text-muted-foreground">No loads match.</p>
      ) : (
        <ul className="flex flex-col divide-y">
          {shown.map((l, i) => {
            const status = shownStatus(l, resolved);
            const pred = predictLoad(l)[0];
            const selected = l.loadId === selectedId;
            return (
              <li key={l.loadId} className="animate-enter" style={{ animationDelay: `${i * 35}ms` }}>
                <button
                  type="button"
                  onClick={() => onSelect(l.loadId)}
                  aria-pressed={selected}
                  className={cn(
                    "grid w-full grid-cols-1 gap-2 px-4 py-3 text-left transition-colors hover:bg-muted/40 lg:grid-cols-[minmax(0,1.5fr)_140px_minmax(0,1fr)_minmax(0,0.9fr)_172px] lg:items-center lg:gap-4",
                    selected && "bg-primary/5 hover:bg-primary/10"
                  )}
                >
                  <span className="flex min-w-0 items-center gap-2.5">
                    <SystemMark name={l.customer.split(" · ")[0]} />
                    <span className="flex min-w-0 flex-col">
                      <span className="truncate font-mono text-xs font-semibold text-foreground">{l.loadId}</span>
                      <span className="truncate text-xs text-muted-foreground">
                        {l.customer} · {l.site}
                      </span>
                    </span>
                  </span>
                  <MilestoneDots load={l} status={status} />
                  <span className="flex min-w-0 flex-col items-start gap-1">
                    <span className="truncate text-sm font-semibold tabular-nums text-foreground">{l.etaLabel}</span>
                    <span className={cn("whitespace-nowrap rounded-md border px-1.5 py-0.5 text-[10px] font-semibold", SOURCE_TONE[l.etaSource])}>
                      {l.etaSource}
                    </span>
                  </span>
                  <span className="truncate text-xs tabular-nums text-muted-foreground">{l.window.label}</span>
                  <span className="flex items-center gap-1.5 lg:justify-end">
                    {pred && status !== "Recovered" && <OtifRiskChip pct={pred.riskPct} level={pred.level} />}
                    <StatusChip status={status} />
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      )}
      <div className="flex items-center justify-between gap-2 border-t px-4 py-2 text-xs text-muted-foreground">
        <span className="tabular-nums">
          {loads.length === 0 ? 0 : page * PAGE_SIZE + 1}–{Math.min(loads.length, (page + 1) * PAGE_SIZE)} of {loads.length}
        </span>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" className="h-7 w-7" disabled={page === 0} onClick={() => onPage(page - 1)} aria-label="Previous page">
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <span className="tabular-nums">
            {page + 1} / {pages}
          </span>
          <Button variant="ghost" size="icon" className="h-7 w-7" disabled={page >= pages - 1} onClick={() => onPage(page + 1)} aria-label="Next page">
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
