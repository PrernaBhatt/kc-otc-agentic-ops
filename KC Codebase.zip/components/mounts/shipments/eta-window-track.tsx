"use client";

import { useEffect, useState } from "react";

import { Tip } from "@/components/shared/floating-tip";
import type { RiskRow } from "@/lib/data/shipment-risk";
import { etaInside, trackPositions } from "@/lib/shipment-selectors";
import { cn } from "@/lib/utils";

/**
 * A row's OTIF window (green band) against its predicted arrival (dot). The
 * dot starts at the window opening and slides to the prediction on mount.
 */
export function EtaWindowTrack({ row, resolved = false }: { row: RiskRow; resolved?: boolean }) {
  const pos = trackPositions(row);
  const inside = resolved || etaInside(row);
  const [placed, setPlaced] = useState(false);

  useEffect(() => {
    const id = requestAnimationFrame(() => setPlaced(true));
    return () => cancelAnimationFrame(id);
  }, []);

  return (
    <div className="flex flex-col gap-1">
      <div className="relative h-2 rounded-full bg-muted">
        <Tip
          content={{ title: "OTIF window", value: row.track.windowLabel }}
          className="absolute inset-y-0 rounded-full bg-[var(--success)]/30 hover:bg-[var(--success)]/45"
          style={{ left: `${pos.windowFrom}%`, width: `${Math.max(2, pos.windowTo - pos.windowFrom)}%` }}
        />
        <Tip
          content={{
            title: resolved ? "Resolved" : inside ? "Predicted arrival · in window" : "Predicted arrival · outside window",
            value: resolved ? row.resolvedLabel : row.track.etaLabel,
          }}
          className={cn(
            "absolute top-1/2 h-3.5 w-3.5 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-card shadow-sm transition-[left] duration-1000 ease-out motion-reduce:transition-none",
            inside ? "bg-[var(--success)]" : "bg-red-600"
          )}
          style={{ left: `${resolved || placed ? (resolved ? (pos.windowFrom + pos.windowTo) / 2 : pos.eta) : pos.windowFrom}%` }}
        />
      </div>
      <div className="flex items-center justify-between gap-2 text-[11px] tabular-nums">
        <span className="truncate text-muted-foreground">{row.track.windowLabel}</span>
        <span className={cn("shrink-0 font-medium", inside ? "text-[var(--success)]" : "text-red-700")}>
          {resolved ? row.resolvedLabel : row.track.etaLabel}
        </span>
      </div>
    </div>
  );
}
