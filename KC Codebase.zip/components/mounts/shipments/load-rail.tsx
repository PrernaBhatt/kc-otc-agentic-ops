"use client";

import { CircleCheck, Eye, Play, Radar } from "lucide-react";

import { EtaPredictionCard } from "@/components/mounts/shipments/eta-prediction-card";
import { SOURCE_TONE, StatusChip, shownStatus } from "@/components/mounts/shipments/load-list";
import { SystemMark } from "@/components/shared/system-badge";
import { Button } from "@/components/ui/button";
import { LOAD_MILESTONES, type NetworkLoad } from "@/lib/data/loads";
import { RISK_ROWS } from "@/lib/data/shipment-risk";
import { cn } from "@/lib/utils";

/** Track & Trace detail: milestone ladder, the ETA (predicted when in transit), and the run behind an at-risk load. */
export function LoadRail({
  load,
  resolved,
  onOpenRun,
}: {
  load: NetworkLoad;
  resolved: Record<string, string>;
  onOpenRun: (caseId: string) => void;
}) {
  const status = shownStatus(load, resolved);
  const row = RISK_ROWS.find((r) => r.caseId === load.caseId);
  const done = row && resolved[row.caseId];
  const last = LOAD_MILESTONES.length - 1;

  return (
    <aside
      key={load.loadId}
      className="animate-enter flex flex-col gap-3 lg:sticky lg:top-4 lg:max-h-[calc(100vh-6rem)] lg:overflow-y-auto"
      aria-label={`Load ${load.loadId}`}
    >
      <div className="flex flex-col gap-3 rounded-xl border bg-card p-4">
        <div className="flex items-start justify-between gap-2">
          <div className="flex min-w-0 flex-col gap-0.5">
            <span className="truncate font-mono text-sm font-semibold text-foreground">{load.loadId}</span>
            <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <SystemMark name={load.customer.split(" · ")[0]} />
              <span className="truncate">{load.customer}</span>
            </span>
          </div>
          <StatusChip status={status} />
        </div>
        <dl className="grid grid-cols-2 gap-x-3 gap-y-2 text-xs">
          {[
            ["Order", load.orderRef],
            ["Carrier", load.carrier.split(" · ")[0]],
            ["Lane", `${load.origin} → ${load.site.split(",")[0]}`],
            ["Window", load.window.label],
          ].map(([k, v], i) => (
            <div key={k} className="animate-enter flex min-w-0 flex-col" style={{ animationDelay: `${i * 40}ms` }}>
              <dt className="text-muted-foreground">{k}</dt>
              <dd className="truncate font-medium text-foreground">{v}</dd>
            </div>
          ))}
        </dl>
      </div>

      {row && (
        <div
          className={cn(
            "flex flex-col gap-2.5 rounded-xl border p-4",
            done ? "border-green-200 bg-green-50/60" : row.level === "high" ? "border-red-200 bg-red-50/50" : "border-amber-200 bg-amber-50/50"
          )}
        >
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="font-mono text-xs font-semibold text-foreground">{row.caseId}</span>
            <span className="inline-flex items-center gap-1 rounded-md border bg-card px-1.5 py-0.5 text-[10px] font-semibold text-muted-foreground">
              <Radar className="h-3 w-3" aria-hidden /> Detected at {row.detectedAt}
            </span>
          </div>
          <p className="text-sm leading-relaxed text-foreground">{done ? row.resolvedLabel ?? done : row.signal}</p>
          {row.run ? (
            <Button size="sm" variant={done ? "outline" : "default"} className="h-8 gap-1.5 self-start text-xs" onClick={() => onOpenRun(row.caseId)}>
              {done ? <CircleCheck className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
              {done ? "Review run" : "Open run"}
            </Button>
          ) : (
            row.watch && (
              <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <Eye className="h-3.5 w-3.5" aria-hidden /> {row.watch.agent} · next check {row.watch.nextCheck}
              </span>
            )
          )}
        </div>
      )}

      <div className="rounded-xl border bg-card p-4">
        <h3 className="mb-2 text-xs font-semibold text-foreground">Milestones</h3>
        <ol className="flex flex-col">
          {LOAD_MILESTONES.map((m, i) => {
            const reached = i <= load.stage;
            const current = i === load.stage && i !== last;
            return (
              <li key={m} className="animate-enter relative flex items-center gap-3 py-1.5" style={{ animationDelay: `${i * 60}ms` }}>
                {i < last && (
                  <span className={cn("absolute left-[5px] top-5 h-full w-px", i < load.stage ? "bg-primary/50" : "bg-border")} aria-hidden />
                )}
                <span
                  className={cn(
                    "relative h-2.5 w-2.5 shrink-0 rounded-full border",
                    reached ? "border-transparent bg-primary" : "border-border bg-card",
                    current && "ring-2 ring-primary/20 ring-offset-1 ring-offset-card"
                  )}
                  aria-hidden
                />
                <span className={cn("flex-1 text-sm", reached ? "text-foreground" : "text-muted-foreground")}>{m}</span>
                <span className="text-xs tabular-nums text-muted-foreground">{load.times[i] ?? "—"}</span>
              </li>
            );
          })}
        </ol>
      </div>

      {load.predict ? (
        <EtaPredictionCard prediction={load.predict} playKey={`tt:${load.loadId}`} />
      ) : (
        <div className="flex items-center justify-between gap-2 rounded-xl border bg-card p-4">
          <div className="flex flex-col">
            <span className="text-xs text-muted-foreground">{load.stage === last ? "Delivered" : "Planned arrival"}</span>
            <span className="text-lg font-semibold tabular-nums text-foreground">{load.etaLabel}</span>
          </div>
          <span className={cn("whitespace-nowrap rounded-md border px-1.5 py-0.5 text-[10px] font-semibold", SOURCE_TONE[load.etaSource])}>
            {load.etaSource}
          </span>
        </div>
      )}
    </aside>
  );
}
