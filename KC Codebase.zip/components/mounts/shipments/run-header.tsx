"use client";

import type { ReactNode } from "react";
import { ArrowLeft } from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import { ControlTags } from "@/components/shared/control-tag";
import { OwnerChip } from "@/components/shared/owner-chip";
import { Button } from "@/components/ui/button";
import { TRANSPORT_LEAD } from "@/lib/data/account-owners";

/** Back link, case ID and the agents working the case, shared by the three shipment runs. */
export function ShipmentRunHeader({
  caseId,
  summary,
  accountId,
  agents,
  controls = [],
  onBack,
  backLabel = "Back to Track & Trace",
}: {
  caseId: string;
  summary: ReactNode;
  accountId?: string;
  agents: { name: string; type: string }[];
  controls?: string[];
  onBack: () => void;
  backLabel?: string;
}) {
  return (
    <>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Button variant="outline" size="sm" onClick={onBack} className="gap-1.5">
          <ArrowLeft className="h-4 w-4" /> {backLabel}
        </Button>
        <div className="flex flex-wrap items-center gap-3">
          <span className="font-mono text-base font-semibold" data-shipment-case={caseId}>
            {caseId}
          </span>
          <span className="text-sm text-muted-foreground">{summary}</span>
          {accountId && <OwnerChip account={accountId} />}
        </div>
      </div>
      <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
        <span>Agents working for {TRANSPORT_LEAD.name.split(" ")[0]}</span>
        <span className="flex items-center -space-x-1">
          {agents.map((a) => (
            <span key={a.name} className="rounded-full bg-background ring-2 ring-background" title={a.name}>
              <AgentIcon type={a.type} size="sm" className="text-primary" />
            </span>
          ))}
        </span>
        {controls.length > 0 && <ControlTags refs={controls} />}
      </div>
    </>
  );
}
