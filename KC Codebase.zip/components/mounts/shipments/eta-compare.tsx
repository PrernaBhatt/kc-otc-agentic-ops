"use client";

import { Hourglass, Package, Radar, Truck } from "lucide-react";

import { OtifRiskChip } from "@/components/mounts/shipments/eta-prediction-card";
import { EtaAxis, EtaLegend, EtaTrack, etaScale, windowGap } from "@/components/mounts/shipments/eta-track";
import { Tip } from "@/components/shared/floating-tip";
import { SystemMark } from "@/components/shared/system-badge";
import type { EtaPrediction } from "@/lib/data/loads";
import { formatUsd } from "@/lib/format";
import { fmtHm, hm, predictLeg, type LegPrediction } from "@/lib/shipment-selectors";
import { cn } from "@/lib/utils";

/** What pushes this stop late: nothing ahead of it means the late departure, otherwise the unloads before it. */
function cause(p: LegPrediction) {
  if (p.leg.dwellMin === 0) return { icon: Truck, label: "Late departure carries straight through" };
  return { icon: Hourglass, label: `${p.leg.dwellNote.split(",")[0]} ahead · ${p.leg.dwellMin} min` };
}

/** Where the minutes from the last ping to p50 go: drive, traffic, unloads ahead. */
function TimeSplit({ p, id }: { p: LegPrediction; id: string }) {
  const parts = [
    { key: "drive", label: "Drive", v: p.leg.driveMin, cls: "bg-[var(--info)]" },
    { key: "traffic", label: "Traffic", v: p.leg.trafficMin, cls: "bg-amber-500" },
    { key: "dwell", label: "Unloads ahead", v: p.leg.dwellMin, cls: "bg-foreground/60" },
  ].filter((x) => x.v > 0);
  const total = parts.reduce((s, x) => s + x.v, 0);
  return (
    <span className="flex items-center gap-2">
      <span className="flex h-2 w-24 overflow-hidden rounded-full bg-muted" aria-label={parts.map((x) => `${x.label} ${x.v} min`).join(", ")}>
        {parts.map((x, i) => (
          <Tip
            key={x.key}
            content={{ title: x.label, value: `${x.v} min`, note: `of ${total} min to arrival` }}
            className={cn("grow-x h-full border-r border-card last:border-r-0", x.cls)}
            style={{ width: `${(x.v / total) * 100}%`, animationDelay: `${300 + i * 120}ms` }}
            label={`${id} ${x.label}`}
          />
        ))}
      </span>
      <span className="text-[11px] tabular-nums text-muted-foreground">
        {parts.map((x) => `${x.label.toLowerCase()} ${x.v}`).join(" + ")} = <span className="font-semibold text-foreground">{total} min</span>
      </span>
    </span>
  );
}

/**
 * After the prediction: every stop on one shared time axis, so the client
 * sees at a glance which stops miss, by how much, and why each one differs.
 */
export function EtaCompare({ prediction, values }: { prediction: EtaPrediction; values?: Record<string, number> }) {
  const preds = prediction.legs.map((leg) => predictLeg(prediction, leg));
  const ping = hm(prediction.pingAt);
  const scale = etaScale(preds, [ping]);
  const misses = preds.filter((p) => windowGap(p).late > 0);
  const atStake = values ? misses.reduce((s, p) => s + (values[p.leg.stop] ?? 0), 0) : 0;

  return (
    <section className="animate-enter flex flex-col rounded-lg border bg-card" aria-labelledby="eta-compare-title">
      <header className="flex flex-wrap items-center gap-2 border-b bg-muted/30 px-3 py-2">
        <Radar className="h-4 w-4 text-[var(--info)]" aria-hidden />
        <h4 id="eta-compare-title" className="text-sm font-semibold text-foreground">
          Stop ETAs vs receiving windows
        </h4>
        <span className="ml-auto flex flex-wrap items-center gap-1.5">
          <span
            className={cn(
              "step-pop rounded-md border px-1.5 py-0.5 text-[11px] font-semibold tabular-nums",
              misses.length ? "border-red-200 bg-red-50 text-red-700" : "border-green-200 bg-green-100 text-green-700"
            )}
          >
            {misses.length} of {preds.length} outside window
          </span>
          {atStake > 0 && (
            <span className="step-pop rounded-md border bg-card px-1.5 py-0.5 text-[11px] font-semibold text-foreground tabular-nums" style={{ animationDelay: "120ms" }}>
              {formatUsd(atStake)} at stake
            </span>
          )}
        </span>
      </header>

      <div className="flex flex-col gap-1 border-b px-4 pt-2 pb-1">
        <div className="relative h-5">
          <span
            className="animate-enter-fade absolute top-0 flex -translate-x-1/2 items-center gap-1 whitespace-nowrap rounded-full border bg-card px-1.5 py-px text-[10px] font-medium text-foreground"
            style={{ left: `${scale.at(ping)}%` }}
          >
            <SystemMark name="FourKites" /> Last ping {prediction.pingAt}
          </span>
        </div>
        <EtaAxis scale={scale} />
      </div>

      <ol className="flex flex-col divide-y">
        {preds.map((p, i) => {
          const { late, wait } = windowGap(p);
          const c = cause(p);
          const value = values?.[p.leg.stop];
          return (
            <li key={p.leg.stop} className="animate-enter flex flex-col gap-1.5 px-4 py-3" style={{ animationDelay: `${120 + i * 140}ms` }}>
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                <span className="font-mono text-xs text-muted-foreground">{i + 1}</span>
                <SystemMark name={p.leg.customer} />
                <span className="text-sm font-semibold text-foreground">{p.leg.customer}</span>
                <span className="min-w-0 truncate text-xs text-muted-foreground">
                  {p.leg.site} · window <span className="font-mono tabular-nums">{p.leg.windowFrom}–{p.leg.windowTo}</span>
                </span>
                <span className="ml-auto flex items-center gap-2">
                  <span className="text-[11px] text-muted-foreground">Agent ETA</span>
                  <span className="font-mono text-base font-semibold text-foreground tabular-nums">{fmtHm(p.p50)}</span>
                  <OtifRiskChip pct={p.riskPct} level={p.level} />
                </span>
              </div>
              <EtaTrack p={p} scale={scale} ping={ping} delayMs={200 + i * 140} />
              <div className="flex flex-wrap items-center gap-x-5 gap-y-1.5">
                <span
                  className={cn(
                    "flex items-center gap-1.5 text-xs font-medium",
                    late ? "text-red-700" : wait ? "text-amber-700" : "text-green-700"
                  )}
                >
                  <c.icon className="h-3.5 w-3.5" aria-hidden />
                  {late || wait ? c.label : "Inside the window"}
                </span>
                <TimeSplit p={p} id={p.leg.customer} />
                <span className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                  <SystemMark name="FourKites" />
                  {p.leg.fourKitesPeta
                    ? `PETA ${p.leg.fourKitesPeta}${p.leg.fourKitesPeta === fmtHm(p.p50) ? " · matches agent" : ""}`
                    : "No FourKites PETA · agent only"}
                </span>
                {value != null && (
                  <span className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                    <Package className="h-3.5 w-3.5" aria-hidden />
                    <span className="font-semibold text-foreground tabular-nums">{formatUsd(value)}</span> on this stop
                  </span>
                )}
              </div>
            </li>
          );
        })}
      </ol>

      <EtaLegend
        className="border-t bg-muted/20 px-3 py-2"
        late={misses.length > 0}
        wait={preds.some((p) => windowGap(p).wait > 0)}
        ping
        band={preds.some((p) => p.level === "high") ? "high" : "medium"}
      />
    </section>
  );
}
