import type { ReactNode } from "react";

import { snapshotDays, snapshotSlots, snapshotSummary, snapshotTimes, type SnapshotSlot } from "@/lib/calendar-snapshot";
import { APPOINTMENT_CASE as a, RDC_6094_SNAPSHOT as s } from "@/lib/data/shipment-risk";
import { shortStamp } from "@/lib/shipment-selectors";
import { cn } from "@/lib/utils";

/*
 * Print palette of the Walmart supplier portal export. Fixed values on
 * purpose: this is a reproduction of a third-party document, not app chrome.
 */
const BLUE = "#0071DC";
const NAVY = "#041E42";
const FONT = '"Helvetica Neue", Helvetica, Arial, sans-serif';
const HATCH = "repeating-linear-gradient(135deg, #eef0f3 0 6px, #e2e5ea 6px 7px)";

const [genDate, genTime] = s.generatedAt.split(" ");
const genWeekday = new Date(`${genDate}T12:00:00Z`).toLocaleDateString("en-US", { weekday: "short", timeZone: "UTC" });
const generatedLabel = `${genWeekday} ${genDate} ${genTime} MST`;
const [pallets, weight, equipment] = a.tmsPlan.load.split(" · ");
const [carrierName, scac] = a.tmsPlan.carrier.split(" · ");
const mabdDay = snapshotDays.find((d) => d.isMabd)!;
const TOTAL_PAGES = 2;

/* ------------------------------------------------------------------ */

function Header({ compact }: { compact?: boolean }) {
  return (
    <header className="flex items-end justify-between border-b-[3px] pb-3" style={{ borderColor: BLUE }}>
      <div className="flex items-center gap-2.5">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/brand/systems/walmart.png" alt="" className={compact ? "h-6 w-6" : "h-8 w-8"} />
        <span className={cn("font-bold tracking-tight", compact ? "text-[20px]" : "text-[26px]")} style={{ color: BLUE }}>
          Walmart
        </span>
        <span className="ml-1 border-l border-[#c9ced6] pl-3 text-[12px] font-medium text-[#46505e]">
          Delivery Scheduling
        </span>
      </div>
      <div className="text-right">
        <p className={cn("font-bold", compact ? "text-[13px]" : "text-[15px]")} style={{ color: NAVY }}>
          Receiving Calendar Snapshot
        </p>
        <p className="text-[11px] text-[#5a6170]">Generated {generatedLabel}</p>
      </div>
    </header>
  );
}

function Footer({ n }: { n: number }) {
  return (
    <footer className="mt-auto flex items-center justify-between border-t border-[#d8dce3] pt-2.5 text-[10px] text-[#5a6170]">
      <span>Walmart Inc. · Confidential · Supplier and carrier use only</span>
      <span>{s.docNo}</span>
      <span>
        Page {n} of {TOTAL_PAGES}
      </span>
    </footer>
  );
}

function PageFrame({ n, children }: { n: number; children: ReactNode }) {
  return (
    <div className="flex h-full flex-col px-12 pb-8 pt-10 text-[12px] leading-[1.45] text-[#1a1a1a]" style={{ fontFamily: FONT }}>
      <Header compact={n > 1} />
      <div className="flex flex-col gap-5 pt-4">{children}</div>
      <Footer n={n} />
    </div>
  );
}

function SectionTitle({ children, aside }: { children: ReactNode; aside?: ReactNode }) {
  return (
    <div className="mb-2 flex items-baseline justify-between border-b border-[#d8dce3] pb-1">
      <h3 className="text-[11px] font-bold uppercase tracking-[0.08em]" style={{ color: NAVY }}>
        {children}
      </h3>
      {aside && <span className="text-[10px] text-[#5a6170]">{aside}</span>}
    </div>
  );
}

function Fields({ rows }: { rows: [string, ReactNode][] }) {
  return (
    <dl className="grid grid-cols-[112px_1fr] gap-x-3 gap-y-1">
      {rows.map(([label, value]) => (
        <div key={label} className="contents">
          <dt className="text-[#5a6170]">{label}</dt>
          <dd className="font-medium">{value}</dd>
        </div>
      ))}
    </dl>
  );
}

function SlotStatus({ slot }: { slot: SnapshotSlot }) {
  return slot.open > 0 ? (
    <span className="rounded-sm border border-[#2a8703] bg-[#eaf5e4] px-1.5 py-px text-[10px] font-bold uppercase tracking-wide text-[#1f6402]">
      Open
    </span>
  ) : (
    <span className="rounded-sm bg-[#e2e5ea] px-1.5 py-px text-[10px] font-bold uppercase tracking-wide text-[#46505e]">
      Booked
    </span>
  );
}

/* ------------------------------------------------------------------ *
 * Page 1 · facility, request, availability and the week grid
 * ------------------------------------------------------------------ */

function PageOne() {
  const sum = snapshotSummary;
  return (
    <PageFrame n={1}>
      <div className="flex items-center justify-between rounded-sm px-3 py-2 text-[11px]" style={{ backgroundColor: "#e6f1fc", color: NAVY }}>
        <span className="font-bold">
          Facility {s.facility.number} · {s.facility.name}
        </span>
        <span>Period {sum.period}</span>
        <span>Times in {s.timezone}</span>
      </div>

      <div className="grid grid-cols-2 gap-8">
        <section>
          <SectionTitle>Facility</SectionTitle>
          <Fields
            rows={[
              ["DC number", s.facility.number],
              ["Type", s.facility.type],
              ["Location", s.facility.address],
              ["Receiving", s.facility.hours],
              ["Unload", s.facility.unload],
              ["Slot length", `${s.slotMinutes} min`],
            ]}
          />
        </section>
        <section>
          <SectionTitle>Purchase order &amp; load</SectionTitle>
          <Fields
            rows={[
              ["Supplier", `${s.supplier.name} · No. ${s.supplier.number}`],
              ["PO number", a.poNumber],
              ["Supplier order", a.orderId],
              ["Load", a.tmsPlan.loadId],
              ["Carrier · SCAC", `${carrierName} · ${scac}`],
              ["Freight", `${pallets} · ${weight} · ${equipment}`],
              ["Planned arrival", `${shortStamp(a.tmsPlan.eta)} (TMS)`],
              [
                "MABD",
                <span key="mabd" className="font-bold text-[#c8102e]">
                  {mabdDay.weekday} {a.otifWindow.mabd}
                </span>,
              ],
            ]}
          />
        </section>
      </div>

      <section>
        <SectionTitle aside={a.otifWindow.label}>Availability summary</SectionTitle>
        <div className="grid grid-cols-4 divide-x divide-[#d8dce3] border border-[#d8dce3]">
          {[
            { label: "Slots in window", value: String(sum.inWindowSlots), sub: `${sum.inWindowDoors} doors` },
            { label: "Open in window", value: String(sum.openInWindow), sub: "None bookable", alert: true },
            { label: "First open slot", value: sum.firstOpenLabel, sub: sum.firstOpen.doors },
            { label: "Versus MABD", value: `+${sum.daysAfterMabd} day`, sub: "OTIF miss if booked", alert: true },
          ].map((m) => (
            <div key={m.label} className="px-3 py-2.5">
              <p className="text-[10px] uppercase tracking-wide text-[#5a6170]">{m.label}</p>
              <p className={cn("text-[18px] font-bold leading-tight tabular-nums", m.alert ? "text-[#c8102e]" : "text-[#1a1a1a]")}>
                {m.value}
              </p>
              <p className="text-[10px] text-[#5a6170]">{m.sub}</p>
            </div>
          ))}
        </div>
      </section>

      <section>
        <SectionTitle aside={`Open doors after MABD: ${sum.openDoorsAfter} across ${sum.openSlotsAfter} slots`}>
          Receiving calendar
        </SectionTitle>
        <table className="w-full table-fixed border-collapse text-[11px]">
          <thead>
            <tr>
              <th className="w-[92px] border border-[#d8dce3] bg-[#f5f6f8] px-2 py-1.5 text-left font-semibold text-[#46505e]">
                Slot
              </th>
              {snapshotDays.map((d) => (
                <th
                  key={d.date}
                  className={cn(
                    "border border-[#d8dce3] px-2 py-1.5 text-left",
                    d.isMabd && "border-r-2 border-r-[#c8102e]"
                  )}
                  style={{ backgroundColor: d.inWindow ? "#e6f1fc" : "#fff4d6" }}
                >
                  <span className="flex items-center justify-between">
                    <span className="font-bold" style={{ color: NAVY }}>
                      {d.dayShort}
                    </span>
                    {d.isMabd && (
                      <span className="rounded-sm bg-[#c8102e] px-1 text-[9px] font-bold uppercase tracking-wide text-[#ffffff]">
                        MABD
                      </span>
                    )}
                  </span>
                  <span className={cn("block text-[10px] font-medium", d.inWindow ? "text-[#0053a6]" : "text-[#8a5a00]")}>
                    {d.inWindow ? "OTIF window" : "After MABD"}
                  </span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {snapshotTimes.map((time) => (
              <tr key={time}>
                <td className="border border-[#d8dce3] bg-[#f5f6f8] px-2 py-1.5 align-top">
                  <span className="block font-semibold tabular-nums">{snapshotSlots.find((x) => x.time === time)!.window}</span>
                  <span className="text-[10px] text-[#5a6170]">{s.slotDoors[time].doors}</span>
                </td>
                {snapshotDays.map((d) => {
                  const slot = d.slots.find((x) => x.time === time)!;
                  const isFirst = slot.key === snapshotSummary.firstOpen.key;
                  return (
                    <td
                      key={slot.key}
                      className={cn(
                        "h-[58px] border border-[#d8dce3] px-2 py-1.5 align-top",
                        d.isMabd && "border-r-2 border-r-[#c8102e]",
                        slot.open > 0 && "outline outline-2 -outline-offset-2 outline-[#2a8703]"
                      )}
                      style={{ background: slot.open > 0 ? "#ffffff" : HATCH }}
                    >
                      <span className="flex items-center justify-between">
                        <SlotStatus slot={slot} />
                        <span className="text-[10px] tabular-nums text-[#46505e]">
                          {slot.booked}/{slot.capacity}
                        </span>
                      </span>
                      <span className={cn("mt-1 block text-[10px]", slot.open > 0 ? "font-semibold text-[#1f6402]" : "text-[#5a6170]")}>
                        {slot.open > 0 ? `${slot.open} door${slot.open > 1 ? "s" : ""} free` : "No door free"}
                      </span>
                      {isFirst && <span className="block text-[9px] font-bold uppercase text-[#c8102e]">First open</span>}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
        <div className="mt-2 flex items-center gap-5 text-[10px] text-[#46505e]">
          <span className="flex items-center gap-1.5">
            <span className="h-3 w-4 border border-[#d8dce3]" style={{ background: HATCH }} /> Booked · all doors taken
          </span>
          <span className="flex items-center gap-1.5">
            <span className="h-3 w-4 border-2 border-[#2a8703] bg-[#ffffff]" /> Open · bookable
          </span>
          <span className="flex items-center gap-1.5">
            <span className="h-3 w-0.5 bg-[#c8102e]" /> Must-arrive-by date
          </span>
          <span className="ml-auto">Booked / door capacity</span>
        </div>
      </section>
    </PageFrame>
  );
}

/* ------------------------------------------------------------------ *
 * Page 2 · slot detail, OTIF basis, routing, export record
 * ------------------------------------------------------------------ */

function PageTwo() {
  return (
    <PageFrame n={2}>
      <section>
        <SectionTitle aside={`${snapshotSlots.length} slots · ${snapshotSummary.period}`}>Slot detail</SectionTitle>
        <table className="w-full border-collapse text-[11px]">
          <thead>
            <tr className="text-left text-[10px] uppercase tracking-wide" style={{ backgroundColor: NAVY, color: "#ffffff" }}>
              <th className="px-2 py-1.5 font-semibold">Day</th>
              <th className="px-2 py-1.5 font-semibold">Window</th>
              <th className="px-2 py-1.5 font-semibold">Doors</th>
              <th className="px-2 py-1.5 text-right font-semibold">Booked</th>
              <th className="px-2 py-1.5 text-right font-semibold">Free</th>
              <th className="px-2 py-1.5 font-semibold">Status</th>
              <th className="px-2 py-1.5 font-semibold">vs MABD</th>
            </tr>
          </thead>
          <tbody>
            {snapshotSlots.map((slot, i) => {
              const isFirst = slot.key === snapshotSummary.firstOpen.key;
              return (
                <tr
                  key={slot.key}
                  className={cn("border-b border-[#e4e7ec]", i % 2 === 1 && "bg-[#f8f9fb]", isFirst && "bg-[#fdf6d3]")}
                >
                  <td className={cn("px-2 py-[5px] font-medium", isFirst && "border-l-4 border-l-[#e9a300]")}>{slot.dayShort}</td>
                  <td className="px-2 py-[5px] tabular-nums">{slot.window}</td>
                  <td className="px-2 py-[5px] text-[#46505e]">{slot.doors}</td>
                  <td className="px-2 py-[5px] text-right tabular-nums">{slot.booked}</td>
                  <td className={cn("px-2 py-[5px] text-right tabular-nums", slot.open > 0 && "font-bold text-[#1f6402]")}>
                    {slot.open}
                  </td>
                  <td className="px-2 py-[5px]">
                    <SlotStatus slot={slot} />
                  </td>
                  <td className={cn("px-2 py-[5px]", slot.inWindow ? "text-[#0053a6]" : "font-semibold text-[#c8102e]")}>
                    {slot.inWindow ? "In window" : `+${slot.daysAfterMabd} day · late`}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </section>

      <div className="grid grid-cols-2 gap-5">
        <section className="border border-[#d8dce3] p-3">
          <SectionTitle>OTIF on-time basis</SectionTitle>
          <p>{a.otifWindow.rule}.</p>
          <p className="mt-1 text-[#46505e]">
            This PO: <span className="font-semibold text-[#1a1a1a]">{a.otifWindow.label}</span>.
          </p>
        </section>
        <section className="border p-3" style={{ borderColor: BLUE, backgroundColor: "#f2f8fe" }}>
          <SectionTitle>Request an added slot</SectionTitle>
          <p>No slot inside the window can be self-scheduled.</p>
          <p className="mt-1 text-[#46505e]">Ask the buyer or the RDC {s.facility.number} inbound scheduler to open one.</p>
        </section>
      </div>

      <section>
        <SectionTitle>Export record</SectionTitle>
        <Fields
          rows={[
            ["Source", a.portal],
            ["Exported by", s.generatedBy],
            ["Generated", generatedLabel],
            ["Document no.", s.docNo],
          ]}
        />
      </section>
    </PageFrame>
  );
}

export function calendarSnapshotPages(): ReactNode[] {
  return [<PageOne key="p1" />, <PageTwo key="p2" />];
}
