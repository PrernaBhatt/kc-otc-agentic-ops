"use client";

import { useState } from "react";
import { X } from "lucide-react";

import { OtifForecast } from "@/components/mounts/shipments/otif-forecast";
import { FloatingTip, Tip, useTipAnchor } from "@/components/shared/floating-tip";
import { Card, CardContent } from "@/components/ui/card";
import { RISK_ROWS, type RiskLevel } from "@/lib/data/shipment-risk";
import { formatUsd } from "@/lib/format";
import { riskSummary } from "@/lib/shipment-selectors";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const LEVEL_STYLE: Record<RiskLevel, { bar: string; label: string }> = {
  high: { bar: "bg-red-500 hover:bg-red-600", label: "High" },
  medium: { bar: "bg-amber-400 hover:bg-amber-500", label: "Medium" },
  low: { bar: "bg-slate-300 hover:bg-slate-400", label: "Low" },
};
const SWATCH: Record<RiskLevel, string> = { high: "bg-red-500", medium: "bg-amber-400", low: "bg-slate-300" };

const STAT_TIP =
  "cursor-help rounded-sm underline decoration-dotted decoration-muted-foreground/50 underline-offset-2 outline-none transition-colors hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring";

const casesAt = (level: RiskLevel) => RISK_ROWS.filter((r) => r.level === level);

function LevelSegment({
  level,
  count,
  dim,
  active,
  onHover,
  onToggle,
}: {
  level: RiskLevel;
  count: number;
  dim: boolean;
  active: boolean;
  onHover: (level: RiskLevel | null) => void;
  onToggle: (level: RiskLevel) => void;
}) {
  const { anchor, show, hide } = useTipAnchor();
  const on = (el: HTMLElement) => {
    show(el.getBoundingClientRect());
    onHover(level);
  };
  const off = () => {
    hide();
    onHover(null);
  };
  return (
    <>
      <button
        type="button"
        aria-pressed={active}
        aria-label={`${LEVEL_STYLE[level].label} risk, ${count} shipments`}
        onClick={() => onToggle(level)}
        onPointerEnter={(e) => on(e.currentTarget)}
        onPointerLeave={off}
        onFocus={(e) => on(e.currentTarget)}
        onBlur={off}
        className={cn(
          "grow-x block h-full cursor-pointer transition-[opacity,background-color] duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
          LEVEL_STYLE[level].bar,
          dim && "opacity-30"
        )}
        style={{ flex: `${count} 1 0` }}
      />
      <FloatingTip
        anchor={anchor}
        content={{
          title: `${LEVEL_STYLE[level].label} risk`,
          value: `${count} shipments · ${formatUsd(casesAt(level).reduce((n, r) => n + r.valueUsd, 0))}`,
          note: casesAt(level)
            .map((r) => r.caseId)
            .join(" · "),
          swatch: SWATCH[level],
        }}
      />
    </>
  );
}

/**
 * OTIF at risk: the 7-day OTIF D forecast and every shipment the agents
 * predict will miss its window. Levels filter the list; rows open the run.
 */
export function OtifRiskBoard({ onOpen }: { onOpen: (caseId: string) => void }) {
  const { resolvedShipments } = useOtcStore();
  const [levelFilter, setLevelFilter] = useState<RiskLevel | null>(null);
  const [hoverLevel, setHoverLevel] = useState<RiskLevel | null>(null);
  const [rowLevel, setRowLevel] = useState<RiskLevel | null>(null);

  const highRows = casesAt("high");
  const openCases = RISK_ROWS.filter((r) => r.run && !resolvedShipments[r.caseId]);
  const totalOrders = RISK_ROWS.reduce((n, r) => n + r.orders, 0);
  const segmentFocus = hoverLevel ?? rowLevel ?? levelFilter;
  const toggle = (level: RiskLevel) => setLevelFilter((cur) => (cur === level ? null : level));

  return (
    <Card data-risk-board className="animate-enter gap-0 py-0">
      <CardContent className="flex flex-col gap-4 p-4">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div className="flex flex-col gap-0.5">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-primary">Predictive</span>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-semibold text-foreground">OTIF at risk</h2>
              {levelFilter && (
                <button
                  type="button"
                  onClick={() => setLevelFilter(null)}
                  className="animate-enter-fade flex items-center gap-1 rounded-md border bg-muted/50 px-1.5 py-0.5 text-[11px] font-medium text-foreground transition-colors hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  <span className={cn("size-2 rounded-[2px]", SWATCH[levelFilter])} aria-hidden />
                  {LEVEL_STYLE[levelFilter].label} risk
                  <X className="h-3 w-3 text-muted-foreground" aria-label="Clear filter" />
                </button>
              )}
            </div>
            <p className="text-xs text-muted-foreground">
              <Tip
                focusable
                className={STAT_TIP}
                content={{
                  title: "Shipments at risk",
                  value: `${riskSummary.total} shipments · ${totalOrders} orders`,
                  note: `${riskSummary.pre} pre-shipment · ${riskSummary.post} post-shipment`,
                }}
              >
                {riskSummary.total} shipments at risk
              </Tip>
              {" · "}
              <Tip
                focusable
                className={STAT_TIP}
                content={{
                  title: "Need a decision",
                  value: openCases.length ? openCases.map((r) => r.caseId).join(" · ") : "All decided",
                }}
              >
                {openCases.length} need action
              </Tip>
              {" · high-risk value "}
              <Tip
                focusable
                className={cn(STAT_TIP, "font-medium text-foreground")}
                content={{
                  title: "High-risk value",
                  value: formatUsd(riskSummary.highValueUsd),
                  note: highRows.map((r) => `${r.caseId} ${formatUsd(r.valueUsd)}`).join(" · "),
                }}
              >
                {formatUsd(riskSummary.highValueUsd)}
              </Tip>
            </p>
          </div>
          <div className="flex w-full flex-col gap-1 sm:w-56">
            <div className="flex h-2.5 gap-0.5 overflow-hidden rounded-full" role="group" aria-label="Filter shipments by risk level">
              {riskSummary.byLevel.map((b) => (
                <LevelSegment
                  key={b.level}
                  level={b.level}
                  count={b.count}
                  active={levelFilter === b.level}
                  dim={!!segmentFocus && segmentFocus !== b.level}
                  onHover={setHoverLevel}
                  onToggle={toggle}
                />
              ))}
            </div>
            <div className="flex justify-between text-[11px] text-muted-foreground">
              {riskSummary.byLevel.map((b) => (
                <button
                  key={b.level}
                  type="button"
                  aria-pressed={levelFilter === b.level}
                  onClick={() => toggle(b.level)}
                  onPointerEnter={() => setHoverLevel(b.level)}
                  onPointerLeave={() => setHoverLevel(null)}
                  className={cn(
                    "-mx-1 flex items-center gap-1 rounded px-1 transition-[color,opacity] hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                    levelFilter === b.level && "font-medium text-foreground",
                    !!segmentFocus && segmentFocus !== b.level && "opacity-50"
                  )}
                >
                  {LEVEL_STYLE[b.level].label} <span className="tabular-nums text-foreground">{b.count}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
        <OtifForecast
          resolved={resolvedShipments}
          onOpen={onOpen}
          levelFilter={levelFilter}
          dimLevel={hoverLevel}
          onRowLevel={setRowLevel}
        />
      </CardContent>
    </Card>
  );
}
