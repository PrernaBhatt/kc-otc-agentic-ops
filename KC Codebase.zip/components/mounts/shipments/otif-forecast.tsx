"use client";

import { useState } from "react";
import { ChevronDown, ChevronRight, CircleCheck, Clock } from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import { FloatingTip, Tip, useTipAnchor } from "@/components/shared/floating-tip";
import { SystemMark } from "@/components/shared/system-badge";
import { CountUp } from "@/components/ui/count-up";
import { OTIF_FORECAST } from "@/lib/data/loads";
import { MILK_RUN_CASE, RISK_ROWS, type RiskLevel, type RiskRow } from "@/lib/data/shipment-risk";
import { formatUsd } from "@/lib/format";
import { milkRunSummary, otifForecast } from "@/lib/shipment-selectors";
import { cn } from "@/lib/utils";

const LO = 86;
const HI = 93;
const at = (v: number) => `${((v - LO) / (HI - LO)) * 100}%`;

const LEVEL_CHIP: Record<RiskLevel, string> = {
  high: "border-red-200 bg-red-50 text-red-700",
  medium: "border-amber-200 bg-amber-50 text-amber-700",
  low: "border-slate-200 bg-slate-50 text-slate-600",
};
const LEVEL_LABEL: Record<RiskLevel, string> = { high: "High", medium: "Medium", low: "Low" };

type MarkerId = "untreated" | "best" | "target";

const orderWord = (n: number) => `${n} ${n === 1 ? "order" : "orders"}`;
const savedOrders = (r: RiskRow) => r.orders - (r.caseId === MILK_RUN_CASE.caseId ? milkRunSummary.missesAfter : 0);

function Marker({
  id,
  left,
  line,
  active,
  tip,
  onHover,
}: {
  id: MarkerId;
  left: string;
  line: string;
  active: boolean;
  tip: { title: string; value: string; note?: string };
  onHover: (id: MarkerId | null) => void;
}) {
  const { anchor, show, hide } = useTipAnchor();
  const on = (el: HTMLElement) => {
    show(el.getBoundingClientRect());
    onHover(id);
  };
  const off = () => {
    hide();
    onHover(null);
  };
  return (
    <>
      <span
        tabIndex={0}
        aria-label={`${tip.title} ${tip.value}`}
        className="group absolute top-1/2 z-10 flex h-7 w-4 -translate-x-1/2 -translate-y-1/2 cursor-default items-center justify-center rounded-sm outline-none focus-visible:ring-2 focus-visible:ring-ring"
        style={{ left }}
        onPointerEnter={(e) => on(e.currentTarget)}
        onPointerLeave={off}
        onFocus={(e) => on(e.currentTarget)}
        onBlur={off}
      >
        <span className={cn("rounded transition-all duration-200 group-hover:h-6 group-hover:w-1", active ? "h-6 w-1" : "h-4 w-0.5", line)} />
      </span>
      <FloatingTip anchor={anchor} content={tip} />
    </>
  );
}

function CaseRow({
  row,
  index,
  resolvedLabel,
  dim,
  onOpen,
  onHover,
}: {
  row: RiskRow;
  index: number;
  resolvedLabel?: string;
  dim: boolean;
  onOpen: (caseId: string) => void;
  onHover: (row: RiskRow | null) => void;
}) {
  const { anchor, show, hide } = useTipAnchor();
  const done = !!resolvedLabel;
  const saved = savedOrders(row);
  const on = (el: HTMLElement) => {
    show(el.getBoundingClientRect());
    onHover(row);
  };
  const off = () => {
    hide();
    onHover(null);
  };

  return (
    <li className="animate-enter" style={{ animationDelay: `${index * 60}ms` }}>
      <button
        type="button"
        data-forecast-row={row.caseId}
        onClick={() => onOpen(row.caseId)}
        onPointerEnter={(e) => on(e.currentTarget)}
        onPointerLeave={off}
        onFocus={(e) => on(e.currentTarget)}
        onBlur={off}
        aria-label={`${row.caseId}, ${row.customer}: ${row.signal}`}
        className={cn(
          "group flex w-full items-center gap-2 rounded-md border bg-card px-2.5 py-1.5 text-left text-xs transition-[background-color,border-color,box-shadow,opacity] duration-200 hover:border-primary/40 hover:shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
          done && "border-green-200 bg-green-50/70 hover:border-green-300",
          dim && "opacity-40"
        )}
      >
        <SystemMark name={row.customer.split(" · ")[0]} />
        <span className="font-mono font-semibold text-foreground">{row.caseId}</span>
        {row.run ? (
          <span className="min-w-0 flex-1 truncate text-muted-foreground">{orderWord(row.orders)} at risk</span>
        ) : (
          <span className="flex min-w-0 flex-1 items-center gap-1.5">
            <span className={cn("shrink-0 rounded border px-1 text-[10px] font-semibold", LEVEL_CHIP[row.level])}>
              {LEVEL_LABEL[row.level]}
            </span>
            <span className="truncate text-muted-foreground">{row.customer}</span>
          </span>
        )}
        <span className="flex shrink-0 items-center gap-1 group-hover:hidden group-focus-visible:hidden">
          {done ? (
            <span className="flex items-center gap-1 font-semibold text-green-700">
              <CircleCheck className="h-3.5 w-3.5" aria-hidden />
              {saved === row.orders ? "Recovered" : `${saved} of ${row.orders} recovered`}
            </span>
          ) : row.run ? (
            <span className="flex items-center gap-1 text-muted-foreground">
              <Clock className="h-3.5 w-3.5" aria-hidden /> Awaiting decision
            </span>
          ) : (
            <span className="flex items-center gap-1 text-muted-foreground">
              <AgentIcon type="delivery" size="sm" className="h-3.5 w-3.5 text-primary" />
              Watching · {row.watch?.nextCheck}
            </span>
          )}
        </span>
        <span className="hidden shrink-0 items-center gap-0.5 font-semibold text-primary group-hover:flex group-focus-visible:flex">
          {row.run ? (done ? "View run" : "Open run") : "Track & Trace"}
          <ChevronRight className="h-3.5 w-3.5 transition-transform duration-200 group-hover:translate-x-0.5" aria-hidden />
        </span>
      </button>
      <FloatingTip
        anchor={anchor}
        content={{
          title: `${row.customer} · ${row.shipTo}`,
          value: row.signal,
          note: `Detected at ${row.detectedAt} · ${row.orderRef} · ${formatUsd(row.valueUsd)}`,
        }}
      />
    </li>
  );
}

/**
 * OTIF D forecast for orders due in the next 7 days, beside every at-risk
 * shipment. Hovering an open case previews the forecast once it is decided.
 */
export function OtifForecast({
  resolved,
  onOpen,
  levelFilter,
  dimLevel,
  onRowLevel,
}: {
  resolved: Record<string, string>;
  onOpen: (caseId: string) => void;
  levelFilter: RiskLevel | null;
  dimLevel: RiskLevel | null;
  onRowLevel: (level: RiskLevel | null) => void;
}) {
  const f = otifForecast(resolved);
  const [hoverRow, setHoverRow] = useState<RiskRow | null>(null);
  const [marker, setMarker] = useState<MarkerId | null>(null);
  const [watchOpen, setWatchOpen] = useState(false);

  const visible = RISK_ROWS.filter((r) => !levelFilter || r.level === levelFilter);
  const action = visible.filter((r) => r.run);
  const watch = visible.filter((r) => !r.run);
  const watchForced = levelFilter === "medium" || levelFilter === "low";
  const showWatch = watchForced || watchOpen;
  const watchOrders = watch.reduce((n, r) => n + r.orders, 0);

  const previewPct =
    hoverRow?.run && !resolved[hoverRow.caseId] ? otifForecast({ ...resolved, [hoverRow.caseId]: "preview" }).pct : null;
  const onTime = f.scheduled - f.misses;
  const toTarget = Math.ceil((f.scheduled * f.targetPct) / 100) - onTime;
  const recoveredBy = RISK_ROWS.filter((r) => r.run && resolved[r.caseId]);

  const hoverRowChange = (row: RiskRow | null) => {
    setHoverRow(row);
    onRowLevel(row?.level ?? null);
  };

  const legend: { id: MarkerId; label: string; line: string }[] = [
    { id: "untreated", label: "If no agent acts", line: "bg-muted-foreground/60" },
    { id: "best", label: "All runs decided", line: "bg-primary" },
    { id: "target", label: "Target", line: "bg-amber-500" },
  ];

  return (
    <div className="grid items-stretch gap-4 rounded-lg border bg-muted/30 p-3 md:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]" data-forecast>
      <div className="flex flex-col gap-2">
        <div className="flex items-baseline justify-between gap-2">
          <span className="text-xs font-medium text-muted-foreground">
            OTIF D · next {OTIF_FORECAST.horizonDays} days
          </span>
          <span className="text-[11px] tabular-nums text-muted-foreground">{f.scheduled} orders scheduled</span>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Tip
            focusable
            label={`Forecast ${f.pct}%`}
            content={{ title: "OTIF D forecast", value: `${onTime} of ${f.scheduled} on time`, note: `${f.misses} predicted misses` }}
            className="cursor-help rounded-sm text-2xl font-bold tabular-nums text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <CountUp key={f.pct} from={f.untreatedPct} value={f.pct} decimals={1} format={(n) => `${n.toFixed(1)}%`} />
          </Tip>
          <Tip
            focusable
            label={`Target ${f.targetPct}%`}
            content={{
              title: `Gap to ${f.targetPct}% target`,
              value: `${(f.targetPct - f.pct).toFixed(1)} pts · ${orderWord(toTarget)}`,
              note: `${OTIF_FORECAST.baselineMisses} misses come from lane history`,
            }}
            className="cursor-help rounded-md border border-amber-200 bg-amber-50 px-1.5 py-0.5 text-[11px] font-semibold text-amber-700 outline-none transition-colors hover:border-amber-300 hover:bg-amber-100 focus-visible:ring-2 focus-visible:ring-ring"
          >
            Target {f.targetPct}%
          </Tip>
          {f.recovered > 0 && (
            <Tip
              focusable
              label={`${orderWord(f.recovered)} recovered`}
              content={{
                title: "Recovered by agent runs",
                value: orderWord(f.recovered),
                note: recoveredBy.map((r) => `${r.caseId} · ${orderWord(savedOrders(r))}`).join(" · "),
              }}
              className="step-pop cursor-help rounded-md bg-green-50 px-1.5 py-0.5 text-[11px] font-semibold tabular-nums text-green-700 outline-none transition-colors hover:bg-green-100 focus-visible:ring-2 focus-visible:ring-ring"
            >
              +{orderWord(f.recovered)} recovered
            </Tip>
          )}
          {previewPct !== null && (
            <span className="animate-enter-fade text-[11px] font-semibold tabular-nums text-primary">
              {`→ ${previewPct.toFixed(1)}% once ${hoverRow?.caseId} is decided`}
            </span>
          )}
        </div>
        <div
          className="relative mt-3 h-2 rounded-full bg-muted"
          role="img"
          aria-label={`Forecast ${f.pct}%, untreated ${f.untreatedPct}%, target ${f.targetPct}%`}
        >
          <Tip
            content={{ title: "Forecast now", value: `${f.pct.toFixed(1)}%`, note: `${f.misses} predicted misses` }}
            className="grow-x absolute inset-y-0 left-0 rounded-full bg-primary/70 transition-[width,background-color] duration-700 hover:bg-primary/85"
            style={{ width: at(f.pct) }}
          />
          {previewPct !== null && (
            <span
              className="animate-enter-fade absolute inset-y-0 rounded-r-full bg-primary/30"
              style={{ left: at(f.pct), width: `calc(${at(previewPct)} - ${at(f.pct)})` }}
              aria-hidden
            />
          )}
          <Marker
            id="untreated"
            left={at(f.untreatedPct)}
            line="bg-muted-foreground/60"
            active={marker === "untreated"}
            onHover={setMarker}
            tip={{ title: "If no agent acts", value: `${f.untreatedPct.toFixed(1)}%`, note: `${orderWord(f.atRiskOrders)} at risk miss` }}
          />
          <Marker
            id="best"
            left={at(f.bestPct)}
            line="bg-primary"
            active={marker === "best"}
            onHover={setMarker}
            tip={{ title: "Once every run is decided", value: `${f.bestPct.toFixed(1)}%` }}
          />
          <Marker
            id="target"
            left={at(f.targetPct)}
            line="bg-amber-500"
            active={marker === "target"}
            onHover={setMarker}
            tip={{ title: "OTIF D target", value: `${f.targetPct}%`, note: `${OTIF_FORECAST.baselineMisses} misses come from lane history` }}
          />
        </div>
        <div className="flex flex-wrap items-center justify-between gap-x-3 gap-y-1 text-[10px] tabular-nums text-muted-foreground">
          <span>{LO}%</span>
          <span className="flex flex-wrap items-center gap-x-3 gap-y-1">
            {legend.map((l) => (
              <span
                key={l.id}
                onPointerEnter={() => setMarker(l.id)}
                onPointerLeave={() => setMarker(null)}
                className={cn("flex cursor-default items-center gap-1 transition-colors", marker === l.id && "text-foreground")}
              >
                <span className={cn("h-2.5 w-0.5 rounded", l.line)} aria-hidden />
                {l.label}
              </span>
            ))}
          </span>
          <span>{HI}%</span>
        </div>
      </div>

      <div className="flex flex-col gap-1.5">
        {action.length > 0 && (
          <ul className="flex flex-col gap-1.5" aria-label="Orders the agents can recover">
            {action.map((r, i) => (
              <CaseRow
                key={r.caseId}
                row={r}
                index={i}
                resolvedLabel={resolved[r.caseId]}
                dim={!!dimLevel && dimLevel !== r.level}
                onOpen={onOpen}
                onHover={hoverRowChange}
              />
            ))}
          </ul>
        )}
        {watch.length > 0 && !watchForced && (
          <button
            type="button"
            aria-expanded={watchOpen}
            onClick={() => setWatchOpen((v) => !v)}
            className="group flex items-center gap-1 rounded-md px-2.5 py-1 text-left text-[11px] text-muted-foreground transition-colors hover:bg-muted/60 hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <ChevronDown className={cn("h-3.5 w-3.5 transition-transform duration-200", watchOpen && "rotate-180")} aria-hidden />
            {watchOrders} more {watchOrders === 1 ? "order" : "orders"} on watch, inside their windows.
          </button>
        )}
        {watch.length > 0 && showWatch && (
          <ul className="flex flex-col gap-1.5" aria-label="Orders on watch">
            {watch.map((r, i) => (
              <CaseRow
                key={r.caseId}
                row={r}
                index={i}
                resolvedLabel={resolved[r.caseId]}
                dim={!!dimLevel && dimLevel !== r.level}
                onOpen={onOpen}
                onHover={hoverRowChange}
              />
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
