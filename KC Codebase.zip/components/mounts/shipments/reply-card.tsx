"use client";

import { useEffect, useRef, useState } from "react";
import { Mail } from "lucide-react";

import { TypedText } from "@/components/shared/typed-text";

const played = new Set<string>();

/**
 * An inbound reply arriving in the shared mailbox: typing dots first, then
 * the message types in. Calls onDone once the text has landed.
 */
export function ReplyCard({
  from,
  role,
  at,
  text,
  playKey,
  onDone,
}: {
  from: string;
  role: string;
  at: string;
  text: string;
  playKey: string;
  onDone?: () => void;
}) {
  const instant = played.has(playKey);
  const [arrived, setArrived] = useState(instant);
  const doneRef = useRef(onDone);
  doneRef.current = onDone;

  useEffect(() => {
    if (arrived) return;
    const t = window.setTimeout(() => setArrived(true), 1100);
    return () => window.clearTimeout(t);
  }, [arrived]);

  const initials = from
    .split(" ")
    .map((p) => p[0])
    .join("")
    .slice(0, 2);

  return (
    <div className="flex items-start gap-3 rounded-lg border bg-card p-3">
      <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-muted text-xs font-semibold text-foreground">
        {initials}
      </span>
      <div className="flex min-w-0 flex-1 flex-col gap-1">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="text-sm font-semibold text-foreground">
            {from} <span className="font-normal text-muted-foreground">· {role}</span>
          </span>
          <span className="flex items-center gap-1 text-[11px] text-muted-foreground">
            <Mail className="h-3 w-3" aria-hidden /> Reply · {at}
          </span>
        </div>
        {arrived ? (
          <p className="text-sm leading-relaxed text-foreground">
            <TypedText
              text={text}
              instant={instant}
              onDone={() => {
                played.add(playKey);
                doneRef.current?.();
              }}
            />
          </p>
        ) : (
          <span className="flex h-5 items-center gap-1" aria-label="Reply arriving">
            {[0, 1, 2].map((i) => (
              <span
                key={i}
                className="h-1.5 w-1.5 animate-bounce rounded-full bg-muted-foreground/60"
                style={{ animationDelay: `${i * 140}ms` }}
              />
            ))}
          </span>
        )}
      </div>
    </div>
  );
}
