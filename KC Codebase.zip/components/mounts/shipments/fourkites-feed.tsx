"use client";

import { useEffect, useId, useState } from "react";
import { ChevronDown } from "lucide-react";

import { EtaCompare } from "@/components/mounts/shipments/eta-compare";
import { EtaPredictionCard } from "@/components/mounts/shipments/eta-prediction-card";
import { LoadTimeline, TrackAiSummary } from "@/components/mounts/shipments/track-settled";
import { SystemMark } from "@/components/shared/system-badge";
import { TickList } from "@/components/shared/tick-list";
import { NETWORK_LOADS } from "@/lib/data/loads";
import { MILK_RUN_CASE } from "@/lib/data/shipment-risk";
import { cn } from "@/lib/utils";

const FOURKITES = "FourKites";
/** How long the full read stays open after the last stop is written, before it folds. */
const FOLD_AFTER_MS = 1200;
const settledKeys = new Set<string>();

/**
 * Track and trace input and output: the FourKites milestones tick in, then
 * the agent predicts every stop. Once done, the read folds in place into one
 * line and the step settles into AI summary + load timeline, then every stop
 * on one shared axis.
 */
export function FourKitesFeed({ playKey, agent, onDone }: { playKey: string; agent: string; onDone?: () => void }) {
  const m = MILK_RUN_CASE;
  const [read, setRead] = useState(false);
  const [predicted, setPredicted] = useState(false);
  const [settled, setSettled] = useState(() => settledKeys.has(playKey));
  const [more, setMore] = useState(false);
  const bodyId = useId();
  const prediction = NETWORK_LOADS.find((l) => l.caseId === m.caseId)?.predict;

  useEffect(() => {
    if (!predicted || settled) return;
    const t = setTimeout(() => {
      settledKeys.add(playKey);
      setSettled(true);
    }, FOLD_AFTER_MS);
    return () => clearTimeout(t);
  }, [predicted, settled, playKey]);

  const legs = prediction?.legs ?? [];
  const inputs = m.feed.length + legs.reduce((s, l, i) => s + 3 + (i === 0 ? 1 : 0) + (l.fourKitesPeta ? 1 : 0), 0);
  const open = !settled || more;
  const values = Object.fromEntries(m.stops.map((s) => [s.id, s.valueUsd]));

  return (
    <div className="flex flex-col gap-3">
      <div className={cn(settled && "rounded-lg border bg-card")}>
        {settled && (
          <header className="animate-enter-fade flex flex-wrap items-center gap-x-3 gap-y-1.5 px-3 py-2">
            <span className="flex items-center gap-1" aria-hidden>
              <SystemMark name={FOURKITES} />
              <SystemMark name="SAP TM" />
            </span>
            <span className="text-sm font-semibold text-foreground">Inputs read</span>
            <span className="hidden min-w-0 flex-1 truncate text-xs text-muted-foreground md:block">
              FourKites feed · lane history · live traffic · dwell ahead · hours of service
            </span>
            <span className="ml-auto flex items-center gap-2">
              <span className="rounded-md border border-green-200 bg-green-100 px-1.5 py-0.5 text-[11px] font-semibold text-green-700 tabular-nums">
                {inputs} of {inputs} read
              </span>
              <button
                type="button"
                onClick={() => setMore((v) => !v)}
                aria-expanded={open}
                aria-controls={bodyId}
                className="flex h-7 items-center gap-1 rounded-md border px-2 text-xs font-semibold text-foreground transition-colors hover:bg-muted/50"
              >
                {open ? "Show less" : "Show more"}
                <ChevronDown className={cn("h-3.5 w-3.5 transition-transform duration-300", open && "rotate-180")} aria-hidden />
              </button>
            </span>
          </header>
        )}
        <div
          id={bodyId}
          className={cn(
            "grid transition-[grid-template-rows,opacity] duration-500 ease-out",
            open ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
          )}
          inert={!open}
        >
          <div className="min-h-0 overflow-hidden">
            <div className={cn("flex flex-col gap-3", settled && "border-t p-3")}>
              <div className="rounded-lg border bg-card">
                <header className="flex items-center justify-between gap-2 border-b bg-muted/30 px-3 py-2">
                  <span className="flex items-center gap-1.5 text-xs font-semibold text-foreground">
                    <SystemMark name={FOURKITES} /> {FOURKITES} · {m.loadId}
                  </span>
                  <span className="text-[11px] text-muted-foreground">
                    {m.carrier} · {m.equipment}
                  </span>
                </header>
                <TickList
                  className="px-3 py-2"
                  playKey={`${playKey}:feed`}
                  onDone={() => setRead(true)}
                  items={m.feed.map((f) => ({ id: f.at, label: `${f.at} · ${f.event}`, detail: f.detail, system: FOURKITES }))}
                />
              </div>
              {(read || settled) && prediction && (
                <EtaPredictionCard
                  prediction={prediction}
                  playKey={`${playKey}:predict`}
                  onDone={() => {
                    setPredicted(true);
                    onDone?.();
                  }}
                />
              )}
            </div>
          </div>
        </div>
      </div>

      {settled && prediction && (
        <>
          <div className="grid grid-cols-1 items-stretch gap-3 md:grid-cols-2">
            <TrackAiSummary prediction={prediction} agent={agent} />
            <LoadTimeline prediction={prediction} />
          </div>
          <EtaCompare prediction={prediction} values={values} />
        </>
      )}
    </div>
  );
}
