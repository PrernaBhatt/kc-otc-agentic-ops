"use client";

import { useEffect, useRef, useState } from "react";

import { Spinner } from "@/components/agents/spinner";
import { Tip } from "@/components/shared/floating-tip";
import { CheckChip } from "@/components/shared/check-chip";
import { SystemMark } from "@/components/shared/system-badge";
import { MILK_RUN_CASE, type StopId } from "@/lib/data/shipment-risk";
import { fmtHm, hm, routeResults, type StopTiming } from "@/lib/shipment-selectors";
import { cn } from "@/lib/utils";

const played = new Set<string>();

const AXIS_FROM = hm("06:00");
const AXIS_TO = hm("13:00");
const at = (mins: number) => Math.max(0, Math.min(100, ((mins - AXIS_FROM) / (AXIS_TO - AXIS_FROM)) * 100));
const TICKS = ["06:00", "08:00", "10:00", "12:00"];

export const stopName = (id: StopId) => MILK_RUN_CASE.stops.find((s) => s.id === id)?.customer ?? id;
export const routeLabel = (order: StopId[]) => order.map(stopName).join(" → ");

export function lateLabel(mins: number) {
  if (mins < 60) return `+${mins} min`;
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return m ? `+${h} h ${m} min` : `+${h} h`;
}

/** Each stop's receiving window against the truck's arrival, on one 06:00–13:00 axis. */
export function StopTimeline({ timeline, playKey, onDone }: { timeline: StopTiming[]; playKey: string; onDone?: () => void }) {
  const [placed, setPlaced] = useState(() => played.has(playKey));
  const doneRef = useRef(onDone);
  doneRef.current = onDone;
  const misses = timeline.filter((t) => t.miss).length;

  useEffect(() => {
    if (placed) {
      const t = window.setTimeout(() => {
        played.add(playKey);
        doneRef.current?.();
      }, 1100);
      return () => window.clearTimeout(t);
    }
    const id = requestAnimationFrame(() => setPlaced(true));
    return () => cancelAnimationFrame(id);
  }, [placed, playKey]);

  return (
    <div className="flex flex-col gap-2 rounded-lg border bg-card px-3 py-2.5">
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs font-semibold text-foreground">Arrival vs receiving window · {routeLabel(timeline.map((t) => t.stop.id))}</span>
        <CheckChip result={misses ? "flag" : "pass"}>{misses ? `${misses} OTIF ${misses === 1 ? "miss" : "misses"}` : "All on time"}</CheckChip>
      </div>
      <div className="flex flex-col gap-2.5">
        {timeline.map((t) => (
          <div key={t.stop.id} className="grid grid-cols-[6.5rem_minmax(0,1fr)_4.5rem] items-center gap-2">
            <span className="flex min-w-0 items-center gap-1.5 text-xs text-foreground">
              <SystemMark name={t.stop.customer} />
              <span className="truncate">{t.stop.customer}</span>
            </span>
            <div className="relative h-2 rounded-full bg-muted">
              <Tip
                content={{ title: `${t.stop.customer} window`, value: `${t.stop.windowFrom}–${t.stop.windowTo}`, note: t.stop.site }}
                className="absolute inset-y-0 rounded-full bg-[var(--success)]/35 hover:bg-[var(--success)]/50"
                style={{ left: `${at(hm(t.stop.windowFrom))}%`, width: `${at(hm(t.stop.windowTo)) - at(hm(t.stop.windowFrom))}%` }}
              />
              <Tip
                content={{ title: t.miss ? "Arrives outside the window" : "Arrives in the window", value: fmtHm(t.arrive), note: t.miss ? lateLabel(t.lateMin) : undefined }}
                className={cn(
                  "absolute top-1/2 h-3.5 w-3.5 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-card shadow-sm transition-[left] duration-1000 ease-out motion-reduce:transition-none",
                  t.miss ? "bg-red-600" : "bg-[var(--success)]"
                )}
                style={{ left: `${placed ? at(t.arrive) : at(hm(t.stop.windowFrom))}%` }}
              />
            </div>
            <span className={cn("text-right text-xs font-medium tabular-nums", t.miss ? "text-red-700" : "text-[var(--success)]")}>
              {fmtHm(t.arrive)}
              {t.miss && <span className="block text-[10px] font-normal">{lateLabel(t.lateMin)}</span>}
            </span>
          </div>
        ))}
        <div className="grid grid-cols-[6.5rem_minmax(0,1fr)_4.5rem] gap-2">
          <span />
          <div className="relative h-3 text-[10px] tabular-nums text-muted-foreground">
            {TICKS.map((tick) => (
              <span key={tick} className="absolute -translate-x-1/2" style={{ left: `${at(hm(tick))}%` }}>
                {tick}
              </span>
            ))}
          </div>
          <span />
        </div>
      </div>
    </div>
  );
}

/** The three stop orders judged one by one; the one with the fewest misses lights up last. Read only. */
export function RouteOptions({ playKey, onDone }: { playKey: string; onDone?: () => void }) {
  const [judged, setJudged] = useState(() => (played.has(playKey) ? routeResults.length : 0));
  const finished = judged >= routeResults.length;
  const fewest = Math.min(...routeResults.map((r) => r.misses));
  const doneRef = useRef(onDone);
  doneRef.current = onDone;

  useEffect(() => {
    if (finished) {
      played.add(playKey);
      doneRef.current?.();
      return;
    }
    const t = window.setTimeout(() => setJudged((n) => n + 1), 800);
    return () => window.clearTimeout(t);
  }, [finished, judged, playKey]);

  return (
    <ul className="flex flex-col gap-2" aria-label="Route options">
      {routeResults.map((r, i) => {
        const done = i < judged;
        const lit = finished && r.misses === fewest;
        return (
          <li
            key={r.id}
            data-route-option={r.id}
            className={cn(
              "animate-enter-fade flex flex-col gap-2 rounded-lg border bg-card px-3 py-2.5 transition-colors duration-500",
              lit && "border-[var(--success)] bg-green-50/60"
            )}
            style={{ animationDelay: `${i * 80}ms` }}
          >
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="flex flex-wrap items-center gap-1.5 text-sm font-medium text-foreground">
                <span className="font-mono text-xs text-muted-foreground">{i + 1}</span>
                {routeLabel(r.order)}
                {lit && (
                  <span className="animate-enter-fade rounded-md bg-[var(--success)] px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-[var(--success-foreground)]">
                    Recommended
                  </span>
                )}
              </span>
              {done ? (
                <span className={cn("animate-enter-fade text-xs font-semibold tabular-nums", r.misses > 1 ? "text-red-700" : "text-amber-700")}>
                  {r.misses} OTIF {r.misses === 1 ? "miss" : "misses"}
                </span>
              ) : (
                <Spinner size="sm" className={cn("text-primary", i > judged && "opacity-30")} />
              )}
            </div>
            <div className="flex flex-wrap gap-1.5">
              {r.timeline.map((t, si) => (
                <span
                  key={t.stop.id}
                  className={cn(
                    "flex items-center gap-1.5 rounded-md border px-2 py-1 text-xs tabular-nums transition-opacity duration-300",
                    !done && "opacity-40"
                  )}
                  style={{ transitionDelay: `${si * 120}ms` }}
                >
                  <SystemMark name={t.stop.customer} />
                  {fmtHm(t.arrive)}
                  {done && (
                    <CheckChip result={t.miss ? "flag" : "pass"} className="animate-enter-fade">
                      {t.miss ? lateLabel(t.lateMin) : `${t.stop.windowFrom}–${t.stop.windowTo}`}
                    </CheckChip>
                  )}
                </span>
              ))}
            </div>
          </li>
        );
      })}
    </ul>
  );
}
