"use client";

import { useState } from "react";
import { Sparkles } from "lucide-react";

import { EtaAxis, EtaLegend, EtaTrack, etaScale, windowGap } from "@/components/mounts/shipments/eta-track";
import { FillFields } from "@/components/shared/fill-fields";
import { SystemMark } from "@/components/shared/system-badge";
import { TickList } from "@/components/shared/tick-list";
import type { EtaPrediction } from "@/lib/data/loads";
import type { RiskLevel } from "@/lib/data/shipment-risk";
import { fmtHm, predictLeg, type LegPrediction } from "@/lib/shipment-selectors";
import { cn } from "@/lib/utils";

const RISK_TONE: Record<RiskLevel, string> = {
  high: "border-red-200 bg-red-50 text-red-700",
  medium: "border-amber-200 bg-amber-50 text-amber-700",
  low: "border-green-200 bg-green-100 text-green-700",
};

export function OtifRiskChip({ pct, level, className }: { pct: number; level: RiskLevel; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex shrink-0 items-center whitespace-nowrap rounded-md border px-1.5 py-0.5 text-[11px] font-semibold tabular-nums",
        RISK_TONE[level],
        className
      )}
    >
      OTIF risk {pct}%
    </span>
  );
}

const hmin = (m: number) => (m >= 60 ? `${Math.floor(m / 60)} h ${String(m % 60).padStart(2, "0")} min` : `${m} min`);

/** One stop's window against the predicted arrival, on its own time axis. */
function StopTrack({ p }: { p: LegPrediction }) {
  const scale = etaScale([p]);
  return (
    <div className="flex flex-col gap-0.5 pt-1">
      <EtaTrack p={p} scale={scale} />
      <EtaAxis scale={scale} />
    </div>
  );
}

/**
 * The agent's predictive ETA: FourKites gives current status (and a PETA for
 * the next stop at most); the agent reads lane history, live traffic, dwell
 * ahead and hours of service (ticks in), then writes p50, the 80% band and
 * the OTIF risk for each stop (types in).
 */
export function EtaPredictionCard({
  prediction,
  playKey,
  onDone,
  className,
}: {
  prediction: EtaPrediction;
  playKey: string;
  onDone?: () => void;
  className?: string;
}) {
  const legs = prediction.legs.map((leg) => predictLeg(prediction, leg));
  /** legIdx·2 = reading that leg's inputs, legIdx·2+1 = writing its result. */
  const [step, setStep] = useState(0);
  const next = (at: number) => () => setStep((s) => (s === at ? s + 1 : s));

  return (
    <div className={cn("animate-enter overflow-hidden rounded-lg border bg-card", className)} data-card="eta-prediction">
      <header className="flex flex-wrap items-center justify-between gap-2 border-b bg-muted/30 px-3 py-2">
        <span className="flex items-center gap-1.5 text-xs font-semibold text-foreground">
          <Sparkles className="h-3.5 w-3.5 text-[var(--info)]" aria-hidden /> Agent ETA prediction
        </span>
        <span className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
          <SystemMark name="FourKites" /> Last ping {prediction.pingAt} · {prediction.position}
        </span>
      </header>
      <ul className="flex flex-col divide-y">
        {legs.map((p, i) => {
          if (step < i * 2) return null;
          const items = [
            { id: "drive", label: "Drive left · lane p50, 90 days", detail: `${p.leg.miles} mi · ${hmin(p.leg.driveMin)}`, system: "SAP TM" },
            {
              id: "traffic",
              label: "Live traffic",
              detail: `${p.leg.trafficMin ? `+${p.leg.trafficMin} min` : "+0 min"} · ${p.leg.trafficNote}`,
              system: "FourKites",
            },
            { id: "dwell", label: "Dwell ahead", detail: `${p.leg.dwellMin} min · ${p.leg.dwellNote}`, system: "SAP TM" },
            ...(i === 0
              ? [{ id: "hos", label: "Driver hours of service", detail: `${hmin(prediction.hosLeftMin)} left`, system: "FourKites" }]
              : []),
            ...(p.leg.fourKitesPeta
              ? [{ id: "peta", label: "FourKites PETA", detail: p.leg.fourKitesPeta, system: "FourKites" }]
              : []),
          ];
          return (
            <li key={p.leg.stop} className="flex flex-col gap-2 px-3 py-2.5">
              <div className="flex flex-wrap items-center gap-2">
                {legs.length > 1 && <span className="font-mono text-xs text-muted-foreground">{i + 1}</span>}
                <SystemMark name={p.leg.customer} />
                <span className="min-w-0 flex-1 truncate text-sm font-medium text-foreground">{p.leg.site}</span>
                <span className="text-[11px] tabular-nums text-muted-foreground">
                  Window {p.leg.windowFrom}–{p.leg.windowTo}
                </span>
              </div>
              <TickList playKey={`${playKey}:in:${p.leg.stop}`} stepMs={380} onDone={next(i * 2)} items={items} />
              {step >= i * 2 + 1 && (
                <div className="animate-enter flex flex-col gap-2 rounded-md border bg-muted/20 px-3 py-2">
                  <FillFields
                    playKey={`${playKey}:out:${p.leg.stop}`}
                    onDone={() => {
                      next(i * 2 + 1)();
                      if (i === legs.length - 1) onDone?.();
                    }}
                    fields={[
                      { label: "ETA p50", value: fmtHm(p.p50), strong: true },
                      { label: "80% band", value: `${fmtHm(p.p10)}–${fmtHm(p.p90)}` },
                      { label: "OTIF risk", value: `${p.riskPct}%`, strong: true },
                    ]}
                    stamp={<OtifRiskChip pct={p.riskPct} level={p.level} className="step-pop" />}
                  />
                  {step >= i * 2 + 2 && <StopTrack p={p} />}
                </div>
              )}
            </li>
          );
        })}
      </ul>
      {step >= 2 && (
        <EtaLegend
          className="animate-enter-fade border-t bg-muted/20 px-3 py-2"
          late={legs.some((p) => windowGap(p).late > 0)}
          wait={legs.some((p) => windowGap(p).wait > 0)}
          band={legs.some((p) => p.level === "high") ? "high" : legs.some((p) => p.level === "medium") ? "medium" : "low"}
        />
      )}
    </div>
  );
}
