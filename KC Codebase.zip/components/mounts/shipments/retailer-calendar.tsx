"use client";

import { useEffect, useRef, useState } from "react";

import { CheckChip } from "@/components/shared/check-chip";
import { SystemMark } from "@/components/shared/system-badge";
import type { CalendarDay } from "@/lib/data/shipment-risk";
import { cn } from "@/lib/utils";

const played = new Set<string>();

/**
 * The retailer's receiving calendar as the agent reads it: each slot resolves
 * one by one, days up to the MABD sit in the OTIF window, later days fade.
 * The result chip lands once every slot is known.
 */
export function RetailerCalendar({
  portal,
  calendar,
  windowFrom,
  mabd,
  windowLabel,
  playKey,
  onDone,
}: {
  portal: string;
  calendar: CalendarDay[];
  windowFrom: string;
  mabd: string;
  windowLabel: string;
  playKey: string;
  onDone?: () => void;
}) {
  const total = calendar.reduce((n, d) => n + d.slots.length, 0);
  const [shown, setShown] = useState(() => (played.has(playKey) ? total : 0));
  const finished = shown >= total;
  const doneRef = useRef(onDone);
  doneRef.current = onDone;

  useEffect(() => {
    if (finished) {
      played.add(playKey);
      doneRef.current?.();
      return;
    }
    const t = window.setTimeout(() => setShown((n) => n + 1), 110);
    return () => window.clearTimeout(t);
  }, [finished, shown, playKey]);

  const inWindow = (date: string) => {
    const d = date.split(" ")[1];
    return d >= windowFrom && d <= mabd;
  };
  const openInWindow = calendar.some((d) => inWindow(d.date) && d.slots.some((s) => s.state === "open"));
  let cursor = 0;

  return (
    <div className="flex flex-col gap-2 rounded-lg border bg-card">
      <header className="flex items-center justify-between gap-2 border-b bg-muted/30 px-3 py-2">
        <span className="flex items-center gap-1.5 text-xs font-semibold text-foreground">
          <SystemMark name={portal} /> {portal}
        </span>
        <span className="text-[11px] text-muted-foreground">OTIF window {windowLabel}</span>
      </header>
      <div className="flex flex-col divide-y px-3">
        {calendar.map((day) => {
          const within = inWindow(day.date);
          return (
            <div key={day.date} className={cn("flex flex-wrap items-center gap-2 py-2", !within && "opacity-70")}>
              <span className="w-28 shrink-0 text-xs font-medium tabular-nums text-foreground">{day.date}</span>
              <div className="flex flex-1 flex-wrap gap-1.5">
                {day.slots.map((s) => {
                  const known = cursor++ < shown;
                  return (
                    <span
                      key={s.time}
                      className={cn(
                        "rounded-md border px-2 py-0.5 text-xs tabular-nums transition-all duration-300",
                        !known && "border-dashed text-muted-foreground",
                        known && s.state === "full" && "border-transparent bg-muted text-muted-foreground line-through",
                        known && s.state === "open" && "border-dashed border-amber-400 bg-amber-50 text-amber-800"
                      )}
                    >
                      {s.time}
                      <span className="sr-only">{!known ? " checking" : s.state === "full" ? " booked" : " open"}</span>
                    </span>
                  );
                })}
              </div>
              <span
                className={cn(
                  "shrink-0 text-[11px] font-medium",
                  within ? "text-[var(--success)]" : "text-amber-700"
                )}
              >
                {within ? "In OTIF window" : "After MABD"}
              </span>
            </div>
          );
        })}
      </div>
      <footer className="flex flex-wrap items-center justify-between gap-2 border-t px-3 py-2">
        <div className="flex flex-wrap gap-x-3 gap-y-0.5 text-[11px] text-muted-foreground">
          <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-sm bg-muted" /> Booked by others</span>
          <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-sm border border-dashed border-amber-400 bg-amber-50" /> Open, outside window</span>
        </div>
        {finished && (
          <span className="animate-enter-fade">
            <CheckChip result={openInWindow ? "pass" : "flag"}>
              {openInWindow ? "Slot inside the OTIF window" : "No slot inside the OTIF window"}
            </CheckChip>
          </span>
        )}
      </footer>
    </div>
  );
}
