"use client";

import type { CSSProperties } from "react";

import { Tip } from "@/components/shared/floating-tip";
import type { RiskLevel } from "@/lib/data/shipment-risk";
import { fmtHm, hm, type LegPrediction } from "@/lib/shipment-selectors";
import { cn } from "@/lib/utils";

export const BAND_TONE: Record<RiskLevel, string> = {
  high: "bg-red-500",
  medium: "bg-amber-500",
  low: "bg-[var(--info)]",
};

export const LATE_HATCH = "repeating-linear-gradient(135deg, rgb(239 68 68 / 0.5) 0 3px, rgb(239 68 68 / 0.1) 3px 6px)";
export const WAIT_HATCH = "repeating-linear-gradient(135deg, rgb(245 158 11 / 0.5) 0 3px, rgb(245 158 11 / 0.1) 3px 6px)";

/** Minutes the p50 lands after the window closes (late) or before it opens (wait). */
export function windowGap(p: LegPrediction) {
  return { late: Math.max(0, p.p50 - hm(p.leg.windowTo)), wait: Math.max(0, hm(p.leg.windowFrom) - p.p50) };
}

export interface EtaScale {
  lo: number;
  hi: number;
  ticks: number[];
  at: (mins: number) => number;
}

/** One time axis for one or many stops, so their bars can be compared. */
export function etaScale(preds: LegPrediction[], extra: number[] = []): EtaScale {
  const xs = preds.flatMap((p) => [hm(p.leg.windowFrom), hm(p.leg.windowTo), p.p10, p.p90]).concat(extra);
  const lo = Math.floor((Math.min(...xs) - 10) / 30) * 30;
  const hi = Math.ceil((Math.max(...xs) + 10) / 30) * 30;
  const step = hi - lo > 180 ? 60 : 30;
  const ticks: number[] = [];
  for (let t = Math.ceil(lo / step) * step; t <= hi; t += step) ticks.push(t);
  return { lo, hi, ticks, at: (x) => ((x - lo) / (hi - lo)) * 100 };
}

const anchor = (pct: number) => (pct > 84 ? "-translate-x-full" : pct < 16 ? "" : "-translate-x-1/2");

/**
 * The receiving window against where the truck will really arrive: green is
 * the window, the bar is 80% of arrivals on this lane, the black tick is p50,
 * and the hatched gap is the time outside the window.
 */
export function EtaTrack({ p, scale, ping, delayMs = 0 }: { p: LegPrediction; scale: EtaScale; ping?: number; delayMs?: number }) {
  const { at } = scale;
  const from = hm(p.leg.windowFrom);
  const to = hm(p.leg.windowTo);
  const { late, wait } = windowGap(p);
  const d = (ms: number): CSSProperties => ({ animationDelay: `${delayMs + ms}ms` });
  const verdict = late ? `${late} min after the window closes` : wait ? `${wait} min before the window opens` : "inside the window";

  return (
    <div
      className="relative h-14"
      role="img"
      aria-label={`${p.leg.customer}: window ${p.leg.windowFrom}–${p.leg.windowTo}, ETA ${fmtHm(p.p50)}, ${verdict}`}
    >
      {ping != null && (
        <span
          className="absolute inset-y-0 border-l border-dashed border-foreground/35"
          style={{ left: `${at(ping)}%` }}
          aria-hidden
        />
      )}
      <span
        className={cn(
          "animate-enter-fade absolute top-0 whitespace-nowrap rounded bg-foreground px-1 py-px font-mono text-[10px] font-semibold text-background tabular-nums",
          anchor(at(p.p50))
        )}
        style={{ left: `${at(p.p50)}%`, ...d(500) }}
      >
        ETA {fmtHm(p.p50)}
      </span>
      <span className="absolute inset-x-0 top-7 h-px bg-border" aria-hidden />
      <Tip
        content={{ title: "Receiving window", value: `${p.leg.windowFrom}–${p.leg.windowTo}`, note: p.leg.site, swatch: "var(--success)" }}
        className="animate-enter-fade absolute top-5 flex h-4 items-center justify-center overflow-hidden rounded-sm border border-[var(--success)]/45 bg-[var(--success)]/15 hover:bg-[var(--success)]/25"
        style={{ left: `${at(from)}%`, width: `${at(to) - at(from)}%`, ...d(0) }}
      >
        <span className="truncate px-1 font-mono text-[9px] font-semibold text-[var(--success)] tabular-nums">
          {p.leg.windowFrom}–{p.leg.windowTo}
        </span>
      </Tip>
      {late > 0 && (
        <Tip
          content={{ title: "Outside the window", value: `+${late} min`, note: `Closes ${p.leg.windowTo} · p50 ${fmtHm(p.p50)}`, swatch: "#ef4444" }}
          className="grow-x absolute top-5 h-4 rounded-sm"
          style={{ left: `${at(to)}%`, width: `${at(p.p50) - at(to)}%`, backgroundImage: LATE_HATCH, ...d(350) }}
        />
      )}
      {wait > 0 && (
        <Tip
          content={{ title: "Waits at the gate", value: `${wait} min`, note: `Opens ${p.leg.windowFrom} · p50 ${fmtHm(p.p50)}`, swatch: "#f59e0b" }}
          className="grow-x absolute top-5 h-4 rounded-sm"
          style={{ left: `${at(p.p50)}%`, width: `${at(from) - at(p.p50)}%`, backgroundImage: WAIT_HATCH, ...d(350) }}
        />
      )}
      <Tip
        content={{ title: "80% of arrivals", value: `${fmtHm(p.p10)}–${fmtHm(p.p90)}`, note: "Lane history, last 90 days" }}
        className={cn("grow-x absolute top-6 h-2 rounded-full ring-2 ring-card", BAND_TONE[p.level])}
        style={{ left: `${at(p.p10)}%`, width: `${Math.max(at(p.p90) - at(p.p10), 1)}%`, ...d(200) }}
      />
      <Tip
        content={{ title: "Predicted arrival p50", value: fmtHm(p.p50), note: `OTIF risk ${p.riskPct}%` }}
        className="step-pop absolute top-4 h-6 w-1 -translate-x-1/2 rounded-full bg-foreground ring-2 ring-card"
        style={{ left: `${at(p.p50)}%`, ...d(450) }}
      />
      {(late > 0 || wait > 0) && (
        <span
          className={cn(
            "animate-enter-fade absolute top-10 -translate-x-1/2 whitespace-nowrap text-[10px] font-semibold tabular-nums",
            late ? "text-red-700" : "text-amber-700"
          )}
          style={{ left: `${late ? (at(to) + at(p.p50)) / 2 : (at(p.p50) + at(from)) / 2}%`, ...d(650) }}
        >
          {late ? `+${late} min late` : `waits ${wait} min`}
        </span>
      )}
    </div>
  );
}

export function EtaAxis({ scale, className }: { scale: EtaScale; className?: string }) {
  return (
    <div className={cn("relative h-4", className)} aria-hidden>
      {scale.ticks.map((t) => (
        <span
          key={t}
          className={cn("absolute top-0 font-mono text-[10px] text-muted-foreground tabular-nums", anchor(scale.at(t)))}
          style={{ left: `${scale.at(t)}%` }}
        >
          {fmtHm(t)}
        </span>
      ))}
    </div>
  );
}

/** What each mark on the track means, so a client can read it without a walkthrough. */
export function EtaLegend({
  late,
  wait,
  ping,
  band = "high",
  className,
}: {
  late?: boolean;
  wait?: boolean;
  ping?: boolean;
  band?: RiskLevel;
  className?: string;
}) {
  const items = [
    { key: "window", label: "Receiving window", mark: <span className="h-3 w-5 rounded-sm border border-[var(--success)]/45 bg-[var(--success)]/15" /> },
    { key: "band", label: "80% of arrivals", mark: <span className={cn("h-2 w-5 rounded-full", BAND_TONE[band])} /> },
    { key: "p50", label: "Agent ETA p50", mark: <span className="h-3.5 w-1 rounded-full bg-foreground" /> },
    ...(late ? [{ key: "late", label: "Late", mark: <span className="h-3 w-5 rounded-sm" style={{ backgroundImage: LATE_HATCH }} /> }] : []),
    ...(wait ? [{ key: "wait", label: "Waits at gate", mark: <span className="h-3 w-5 rounded-sm" style={{ backgroundImage: WAIT_HATCH }} /> }] : []),
    ...(ping ? [{ key: "ping", label: "Last FourKites ping", mark: <span className="h-3.5 border-l border-dashed border-foreground/50" /> }] : []),
  ];
  return (
    <ul className={cn("flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[11px] text-muted-foreground", className)}>
      {items.map((it) => (
        <li key={it.key} className="flex items-center gap-1.5">
          <span className="flex w-5 justify-center" aria-hidden>
            {it.mark}
          </span>
          {it.label}
        </li>
      ))}
    </ul>
  );
}
