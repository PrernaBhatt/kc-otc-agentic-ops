"use client";

import { useEffect, useState } from "react";

/**
 * Counts a number up from 0 to `value` on mount (once). Respects
 * prefers-reduced-motion by jumping straight to the final value.
 * `format` renders the animating number (e.g. add $, %, commas).
 */
export function CountUp({
  value,
  from = 0,
  durationMs = 900,
  decimals = 0,
  format,
  className,
}: {
  value: number;
  /** Where the count starts; a re-keyed CountUp climbs from here to `value`. */
  from?: number;
  durationMs?: number;
  decimals?: number;
  format?: (n: number) => string;
  className?: string;
}) {
  const [display, setDisplay] = useState(from);

  useEffect(() => {
    const reduce =
      typeof window !== "undefined" &&
      window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    if (reduce) {
      setDisplay(value);
      return;
    }

    // Driven by setInterval (not requestAnimationFrame) so it keeps advancing
    // even when the tab is backgrounded or RAF is throttled; self-corrects to
    // the exact final value on the last tick.
    const start = Date.now();
    const ease = (t: number) => 1 - Math.pow(1 - t, 3); // ease-out cubic
    const id = setInterval(() => {
      const t = Math.min(1, (Date.now() - start) / durationMs);
      setDisplay(from + (value - from) * ease(t));
      if (t >= 1) {
        setDisplay(value);
        clearInterval(id);
      }
    }, 33);
    return () => clearInterval(id);
  }, [value, from, durationMs]);

  const rounded =
    decimals > 0
      ? display.toFixed(decimals)
      : Math.round(display).toLocaleString("en-US");
  return <span className={className}>{format ? format(display) : rounded}</span>;
}

/**
 * Animates the numeric part of a pre-formatted string like "94.2%",
 * "38 days", or "$275,000", keeping any prefix/suffix intact.
 */
export function CountUpText({
  text,
  durationMs = 900,
  className,
}: {
  text: string;
  durationMs?: number;
  className?: string;
}) {
  const match = text.match(/^(\D*?)([\d,]+(?:\.\d+)?)(.*)$/);
  if (!match) return <span className={className}>{text}</span>;
  const [, prefix, numStr, suffix] = match;
  const value = parseFloat(numStr.replace(/,/g, ""));
  const decimals = numStr.includes(".") ? numStr.split(".")[1].length : 0;
  return (
    <span className={className}>
      {prefix}
      <CountUp value={value} durationMs={durationMs} decimals={decimals} />
      {suffix}
    </span>
  );
}
