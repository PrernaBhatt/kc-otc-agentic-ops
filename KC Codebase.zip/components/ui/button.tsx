import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const buttonVariants = cva(
  // the workspace's buttons shrink on hover rather than changing colour —
  // `transform: scale(0.95)` on hover, captured from the client's site. The
  // press state carries it a little further. Colour is held steady on purpose.
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[scale,transform,color,background-color,border-color,box-shadow] duration-150 ease-in-out hover:scale-95 active:scale-[0.93] disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 aria-invalid:border-destructive",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-[#17608f]",
        destructive:
          "bg-destructive text-white hover:bg-[#b30000] focus-visible:ring-destructive/20",
        // the workspace darkens the rule on an outline control rather than filling it.
        outline: "border border-input bg-background hover:border-[#494949]",
        secondary:
          "bg-secondary text-secondary-foreground hover:bg-[#ececec]",
        ghost: "hover:bg-[#ececec]",
        // A text link underlines; it does not shrink.
        link: "text-primary underline-offset-4 hover:underline hover:scale-100 active:scale-100",
      },
      size: {
        default: "h-9 px-4 py-2 has-[>svg]:px-3",
        sm: "h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",
        lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
        icon: "size-9",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
);

function Button({
  className,
  variant,
  size,
  ...props
}: React.ComponentProps<"button"> & VariantProps<typeof buttonVariants>) {
  return (
    <button
      data-slot="button"
      className={cn(buttonVariants({ variant, size, className }))}
      {...props}
    />
  );
}

export { Button, buttonVariants };
