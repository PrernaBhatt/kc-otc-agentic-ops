"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  Bot,
  Building2,
  CircleCheck,
  FileSearch,
  Landmark,
  Network,
  ScanLine,
  Scale,
  Send,
  Sparkles,
} from "lucide-react";

import { Spinner } from "@/components/agents/spinner";
import { SystemBadge } from "@/components/shared/system-badge";
import { StepRail } from "@/components/views/cash/step-rail";
import { RunCompleteModal } from "@/components/mounts/shared/run-complete-modal";
import { KpiCard } from "@/components/views/cash-scenario-unidentified-payer";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { findCashPayment } from "@/lib/data/cash-application";
import type { CashPayment, CrossEntityCase, EntityLeg } from "@/lib/data/cash-application";
import { formatMoney } from "@/lib/cash-application-selectors";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const STEPS = [
  { id: "ingest", label: "Ingest", icon: FileSearch },
  { id: "map", label: "Map hierarchy", icon: Network },
  { id: "match", label: "Match & FX", icon: Scale },
  { id: "post", label: "Approve & post", icon: Send },
] as const;

const eur = (n: number) => formatMoney(n, "EUR");

export function CrossEntityWorkspace({
  paymentId,
  onBack,
}: {
  paymentId: string;
  onBack: () => void;
}) {
  const { postedCashPayments, postCashPayment } = useOtcStore();
  const payment = findCashPayment(paymentId)!;
  const ce = payment.crossEntity!;
  const posted = postedCashPayments.includes(paymentId);

  const [stepIndex, setStepIndex] = useState(0);
  const currentStep = STEPS[stepIndex].id;
  const maxReached = Math.max(stepIndex, posted ? STEPS.length - 1 : 0);

  const primaryActionRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Enter") return;
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      if (!primaryActionRef.current) return;
      e.preventDefault();
      primaryActionRef.current();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const goTo = useCallback((i: number) => setStepIndex(i), []);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={onBack} className="gap-1.5">
            <ArrowLeft className="h-4 w-4" />
            Back to queue
          </Button>
          <div>
            <h2 className="text-lg font-semibold">
              {payment.paymentId} · {payment.customer}
            </h2>
            <p className="text-xs text-muted-foreground">
              {eur(payment.amount)} received {payment.receivedDate} · one receipt
              across {ce.legs.length} legal entities · {payment.erpSystems.join(" + ")}
            </p>
          </div>
        </div>
        <Badge
          variant="outline"
          className={cn(
            posted
              ? "border-[var(--success)]/30 bg-[var(--success)]/10 text-[var(--success)]"
              : "border-amber-200 bg-amber-50 text-amber-700"
          )}
        >
          {posted ? "Posted & reconciled" : "Cross-entity review"}
        </Badge>
      </div>

      <StepRail steps={STEPS} activeIndex={stepIndex} maxReached={maxReached} onSelect={goTo} />

      {currentStep === "ingest" && (
        <IngestStep payment={payment} ce={ce} primaryActionRef={primaryActionRef} onContinue={() => goTo(1)} />
      )}
      {currentStep === "map" && (
        <MapStep payment={payment} ce={ce} primaryActionRef={primaryActionRef} onContinue={() => goTo(2)} />
      )}
      {currentStep === "match" && (
        <MatchStep payment={payment} ce={ce} primaryActionRef={primaryActionRef} onContinue={() => goTo(3)} />
      )}
      {currentStep === "post" && (
        <PostStep
          payment={payment}
          ce={ce}
          posted={posted}
          primaryActionRef={primaryActionRef}
          onApprove={() => postCashPayment(payment.paymentId)}
          onDone={onBack}
        />
      )}
    </div>
  );
}

function legValue(leg: EntityLeg): string {
  return formatMoney(leg.nativeValue, leg.currency);
}

/* ------------------------------------------------------------------ *
 * Step 1 — Ingest: one receipt in one company code
 * ------------------------------------------------------------------ */

function IngestStep({
  payment,
  ce,
  primaryActionRef,
  onContinue,
}: {
  payment: CashPayment;
  ce: CrossEntityCase;
  primaryActionRef: React.MutableRefObject<(() => void) | null>;
  onContinue: () => void;
}) {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setReady(true), 1400);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    primaryActionRef.current = ready ? onContinue : null;
    return () => {
      primaryActionRef.current = null;
    };
  }, [ready, onContinue, primaryActionRef]);

  const fields = [
    { label: "Paying group", value: ce.payerGroup, confidence: 99 },
    { label: "Amount received", value: eur(payment.amount), confidence: 100 },
    { label: "Value date", value: payment.receivedDate, confidence: 99 },
    { label: "Landed in", value: ce.bankEntity, confidence: 100 },
    { label: "Remittance addressed to", value: `${payment.customer} (parent)`, confidence: 72, warn: true },
  ];

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_20rem]">
      <Card className="bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">
            One receipt landed in a single company code
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center gap-3 rounded-lg border px-4 py-3">
            <div className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full bg-muted">
              <Landmark className="h-4 w-4 text-muted-foreground" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium">Bank statement</p>
              <p className="text-xs text-muted-foreground">
                {eur(payment.amount)} from {ce.payerGroup} into {ce.bankEntity}
              </p>
            </div>
            <CircleCheck className="h-4 w-4 flex-shrink-0 text-[var(--success)]" />
          </div>

          <div className="flex items-center gap-3 rounded-lg border border-amber-200 bg-amber-50 px-4 py-3">
            <div className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full bg-amber-100">
              <Network className="h-4 w-4 text-amber-700" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium text-amber-800">
                Addressed to the parent group
              </p>
              <p className="text-xs text-amber-700">
                The invoices it settles sit under two different K-C legal
                entities — one billed in EUR, one in USD.
              </p>
            </div>
          </div>

          <div className="rounded-lg border border-primary/20 bg-primary/5 px-3 py-2.5 text-xs text-muted-foreground">
            <span className="text-foreground">Cash can&apos;t simply move across entities.</span>{" "}
            The receipt landed in one company code, but some open items belong to
            another — so any cross-entity transfer follows the approved accounting
            treatment, with a person&apos;s sign-off.
          </div>

          <div className="flex items-center justify-between pt-1">
            <p className="text-xs text-muted-foreground">
              {ready ? "Statement read. Hierarchy not yet confirmed." : "Reading the bank statement…"}
            </p>
            <Button size="sm" disabled={!ready} onClick={onContinue}>
              Map the hierarchy
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="h-fit bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-1.5 text-sm font-semibold">
            <ScanLine className="h-4 w-4 text-muted-foreground" />
            AI extraction
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2.5">
          {ready ? (
            fields.map((f) => (
              <div key={f.label} className="flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <p className="text-xs text-muted-foreground">{f.label}</p>
                  <p className="truncate text-sm font-medium">{f.value}</p>
                </div>
                <span
                  className={cn(
                    "flex-shrink-0 text-xs font-semibold tabular-nums",
                    f.confidence >= 97 ? "text-[var(--success)]" : "text-amber-600"
                  )}
                >
                  {f.confidence}%
                </span>
              </div>
            ))
          ) : (
            <div className="flex items-center gap-2 py-6 text-xs text-muted-foreground">
              <Spinner className="h-4 w-4" />
              Reading fields off the statement…
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Step 2 — Map the paying group to legal entities
 * ------------------------------------------------------------------ */

function MapStep({
  payment,
  ce,
  primaryActionRef,
  onContinue,
}: {
  payment: CashPayment;
  ce: CrossEntityCase;
  primaryActionRef: React.MutableRefObject<(() => void) | null>;
  onContinue: () => void;
}) {
  const [working, setWorking] = useState(true);

  useEffect(() => {
    const t = setTimeout(() => setWorking(false), 1600);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    primaryActionRef.current = working ? null : onContinue;
    return () => {
      primaryActionRef.current = null;
    };
  }, [working, onContinue, primaryActionRef]);

  if (working) {
    return (
      <Card className="bg-card">
        <CardContent className="flex items-center justify-center gap-3 py-12">
          <Spinner className="h-5 w-5" />
          <p className="text-sm text-muted-foreground">
            Resolving {ce.payerGroup} to sold-to accounts and confirming the
            customer hierarchy…
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card className="bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-1.5 text-sm font-semibold">
            <Sparkles className="h-4 w-4 text-muted-foreground" />
            Hierarchy confirmed — not assumed
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2 text-xs text-muted-foreground">
            {ce.hierarchy.map((h, i) => (
              <li key={i} className="flex gap-1.5">
                <CircleCheck className="mt-0.5 h-3.5 w-3.5 flex-shrink-0 text-[var(--success)]" />
                <span>{h}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <div className="grid gap-4 sm:grid-cols-2">
        {ce.legs.map((leg) => (
          <Card key={leg.companyCode} className="bg-card">
            <CardContent className="p-4">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Building2 className="h-4 w-4 text-muted-foreground" />
                  <p className="text-sm font-semibold">{leg.entity}</p>
                </div>
                <SystemBadge name={leg.erp} />
              </div>
              <div className="mt-3 grid grid-cols-3 gap-2 text-xs">
                <div>
                  <p className="text-muted-foreground">Company code</p>
                  <p className="font-mono font-medium">{leg.companyCode}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Billed in</p>
                  <p className="font-medium">{leg.currency}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Open invoices</p>
                  <p className="font-medium tabular-nums">{leg.invoices}</p>
                </div>
              </div>
              <div className="mt-3 border-t pt-2">
                <p className="text-xs text-muted-foreground">Open value</p>
                <p className="text-lg font-bold tabular-nums">{legValue(leg)}</p>
                {leg.currency !== "EUR" && (
                  <p className="text-xs text-muted-foreground">
                    ≈ {eur(leg.eurValue)} at value-date rate
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="flex items-center justify-between rounded-lg border bg-muted/30 px-3 py-2.5">
        <p className="text-xs text-muted-foreground">
          Two entities, two currencies — {payment.customer} is the verified parent
          of both.
        </p>
        <Button size="sm" onClick={onContinue}>
          Match across entities
        </Button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Step 3 — Match across entities, resolve FX
 * ------------------------------------------------------------------ */

function MatchStep({
  payment,
  ce,
  primaryActionRef,
  onContinue,
}: {
  payment: CashPayment;
  ce: CrossEntityCase;
  primaryActionRef: React.MutableRefObject<(() => void) | null>;
  onContinue: () => void;
}) {
  const [matching, setMatching] = useState(true);

  useEffect(() => {
    const t = setTimeout(() => setMatching(false), 1600);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    primaryActionRef.current = matching ? null : onContinue;
    return () => {
      primaryActionRef.current = null;
    };
  }, [matching, onContinue, primaryActionRef]);

  if (matching) {
    return (
      <Card className="bg-card">
        <CardContent className="flex items-center justify-center gap-3 py-12">
          <Spinner className="h-5 w-5" />
          <p className="text-sm text-muted-foreground">
            Matching open items across {payment.erpSystems.join(" and ")} while
            respecting company-code boundaries…
          </p>
        </CardContent>
      </Card>
    );
  }

  const clearNow = ce.legs.find((l) => l.action === "clear-now")!;
  const transfer = ce.legs.find((l) => l.action === "approve-transfer")!;

  const tiles = [
    { label: `Clearable in ${clearNow.companyCode} now`, value: eur(clearNow.eurValue), tone: "success" as const },
    { label: `${transfer.companyCode} equivalent (cross-entity)`, value: eur(transfer.eurValue), tone: "warning" as const },
    { label: "FX / bank difference", value: eur(ce.fxDifference), tone: "default" as const },
    { label: "Genuine short-pay", value: eur(0), tone: "success" as const },
  ];

  return (
    <div className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {tiles.map((t) => (
          <Card key={t.label} className="bg-card">
            <CardContent className="p-4">
              <p className="text-xs text-muted-foreground">{t.label}</p>
              <p
                className={cn(
                  "mt-1 text-xl font-bold tabular-nums",
                  t.tone === "success" && "text-[var(--success)]",
                  t.tone === "warning" && "text-amber-600"
                )}
              >
                {t.value}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_20rem]">
        <Card className="bg-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">
              How the receipt splits across entities
            </CardTitle>
          </CardHeader>
          <CardContent>
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-left text-xs text-muted-foreground">
                  <th className="pb-2 font-medium">Entity</th>
                  <th className="pb-2 font-medium">Company code</th>
                  <th className="pb-2 text-center font-medium">Invoices</th>
                  <th className="pb-2 text-right font-medium">Value (EUR)</th>
                  <th className="pb-2 text-right font-medium">Treatment</th>
                </tr>
              </thead>
              <tbody>
                {ce.legs.map((leg) => (
                  <tr key={leg.companyCode} className="border-b last:border-0">
                    <td className="py-2.5 text-xs">
                      <div className="flex items-center gap-1.5">
                        <SystemBadge name={leg.erp} />
                        {leg.entity}
                      </div>
                    </td>
                    <td className="py-2.5 font-mono text-xs">{leg.companyCode}</td>
                    <td className="py-2.5 text-center tabular-nums">{leg.invoices}</td>
                    <td className="py-2.5 text-right tabular-nums">
                      {eur(leg.eurValue)}
                      {leg.currency !== "EUR" && (
                        <span className="block text-[10px] text-muted-foreground">
                          {legValue(leg)}
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 text-right">
                      {leg.action === "clear-now" ? (
                        <Badge
                          variant="outline"
                          className="border-[var(--success)]/30 bg-[var(--success)]/10 text-[var(--success)]"
                        >
                          Clear now
                        </Badge>
                      ) : (
                        <Badge
                          variant="outline"
                          className="border-amber-200 bg-amber-50 text-amber-700"
                        >
                          Needs approval
                        </Badge>
                      )}
                    </td>
                  </tr>
                ))}
                <tr className="border-b last:border-0">
                  <td className="py-2.5 text-xs text-muted-foreground" colSpan={3}>
                    FX / bank-charge residual
                  </td>
                  <td className="py-2.5 text-right tabular-nums">{eur(ce.fxDifference)}</td>
                  <td className="py-2.5 text-right">
                    <Badge
                      variant="outline"
                      className="border-amber-200 bg-amber-50 text-amber-700"
                    >
                      Needs approval
                    </Badge>
                  </td>
                </tr>
              </tbody>
            </table>
          </CardContent>
        </Card>

        <Card className="h-fit bg-card">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-1.5 text-sm font-semibold">
              <Bot className="h-4 w-4 text-muted-foreground" />
              FX difference explained
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm">
              <span className="font-semibold tabular-nums">{eur(ce.fxDifference)}</span>{" "}
              residual
            </p>
            <p className="text-xs text-muted-foreground">{ce.fxNote}</p>
            <div className="flex flex-wrap gap-1.5">
              <SystemBadge name={clearNow.erp} />
              <SystemBadge name={ce.matchEngine} />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex items-center justify-between rounded-lg border border-amber-200 bg-amber-50 px-3 py-2.5">
        <p className="text-xs text-amber-800">
          {clearNow.companyCode} can clear automatically. Moving cash to{" "}
          {transfer.companyCode} crosses a legal-entity boundary, so it routes to{" "}
          {ce.approvalRoute} for approval.
        </p>
        <Button size="sm" onClick={onContinue}>
          Resolve &amp; approve
        </Button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Step 4 — Approve cross-entity transfer, post, reconcile
 * ------------------------------------------------------------------ */

function PostStep({
  payment,
  ce,
  posted,
  primaryActionRef,
  onApprove,
  onDone,
}: {
  payment: CashPayment;
  ce: CrossEntityCase;
  posted: boolean;
  primaryActionRef: React.MutableRefObject<(() => void) | null>;
  onApprove: () => void;
  onDone: () => void;
}) {
  const [approved, setApproved] = useState(posted);
  const [showCeremony, setShowCeremony] = useState(false);

  const clearNow = ce.legs.find((l) => l.action === "clear-now")!;
  const transfer = ce.legs.find((l) => l.action === "approve-transfer")!;

  const approveAndCelebrate = useCallback(() => {
    onApprove();
    setShowCeremony(true);
  }, [onApprove]);

  useEffect(() => {
    if (posted) {
      primaryActionRef.current = onDone;
    } else if (!approved) {
      primaryActionRef.current = () => setApproved(true);
    } else if (showCeremony) {
      primaryActionRef.current = null;
    } else {
      primaryActionRef.current = approveAndCelebrate;
    }
    return () => {
      primaryActionRef.current = null;
    };
  }, [posted, approved, showCeremony, approveAndCelebrate, onDone, primaryActionRef]);

  return (
    <div className="space-y-4">
      <Card className="bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">
            {posted ? "Posted & reconciled" : "Ready to post"}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Entity A — clears automatically */}
          <div className="flex items-center justify-between rounded-lg border border-[var(--success)]/30 bg-[var(--success)]/5 px-3 py-2.5">
            <div className="flex items-center gap-2">
              <CircleCheck className="h-4 w-4 text-[var(--success)]" />
              <div>
                <p className="text-sm font-medium">
                  {clearNow.entity} · {clearNow.companyCode}
                </p>
                <p className="text-xs text-muted-foreground">
                  Cleared automatically against {clearNow.invoices} open items
                </p>
              </div>
            </div>
            <span className="text-sm font-semibold tabular-nums text-[var(--success)]">
              {eur(clearNow.eurValue)}
            </span>
          </div>

          {/* Entity B — needs approval */}
          <div
            className={cn(
              "rounded-lg border px-3 py-2.5",
              approved
                ? "border-[var(--success)]/30 bg-[var(--success)]/5"
                : "border-amber-200 bg-amber-50"
            )}
          >
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                {approved ? (
                  <CircleCheck className="h-4 w-4 text-[var(--success)]" />
                ) : (
                  <Building2 className="h-4 w-4 text-amber-700" />
                )}
                <div>
                  <p className="text-sm font-medium">
                    {transfer.entity} · {transfer.companyCode}
                  </p>
                  <p
                    className={cn(
                      "text-xs",
                      approved ? "text-muted-foreground" : "text-amber-700"
                    )}
                  >
                    Cross-entity transfer + FX residual · {transfer.invoices} open
                    items · {legValue(transfer)}
                  </p>
                </div>
              </div>
              {approved ? (
                <span className="text-sm font-semibold tabular-nums text-[var(--success)]">
                  {eur(transfer.eurValue + ce.fxDifference)}
                </span>
              ) : (
                <Button size="sm" variant="outline" onClick={() => setApproved(true)}>
                  Approve transfer
                </Button>
              )}
            </div>
            {!approved && (
              <p className="mt-2 flex items-center gap-1.5 text-xs text-amber-700">
                <Sparkles className="h-3.5 w-3.5" />
                Routed to {ce.approvalRoute} with the accounting entries and
                evidence attached.
              </p>
            )}
          </div>

          <ul className="space-y-2 border-t pt-3 text-sm">
            <li className="flex items-center justify-between text-muted-foreground">
              <span>FX / bank-charge residual</span>
              <span className="tabular-nums text-foreground">{eur(ce.fxDifference)}</span>
            </li>
            <li className="flex items-center justify-between font-medium">
              <span>Total applied</span>
              <span className="tabular-nums">{eur(payment.amount)}</span>
            </li>
          </ul>

          {posted ? (
            <div className="space-y-2 rounded-md border border-[var(--success)]/30 bg-[var(--success)]/5 px-3 py-2.5">
              <p className="text-xs font-medium text-[var(--success)]">Audit trail</p>
              <p className="text-xs text-muted-foreground">
                {payment.paymentId} posted for {payment.customer} — {clearNow.companyCode}{" "}
                cleared, the {transfer.companyCode} transfer and FX residual approved by{" "}
                {ce.approvalRoute}, and both company codes reconciled. HighRadius
                and SAP updated so collections and AR reporting reflect the payment.
              </p>
            </div>
          ) : (
            <p className="text-xs text-muted-foreground">
              Approving posts {clearNow.companyCode} now, books the approved
              cross-entity transfer and FX adjustment, and reconciles both company
              codes — every balancing entry traceable to this receipt.
            </p>
          )}

          <div className="flex justify-end">
            {posted ? (
              <Button size="sm" onClick={onDone}>
                Back to queue
              </Button>
            ) : (
              <Button size="sm" disabled={!approved} onClick={approveAndCelebrate}>
                Approve &amp; post to SAP
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <KpiCard
        title="KPIs demonstrated"
        items={[
          "Cross-entity payment exception rate",
          "FX residual handling accuracy",
          "Cash application accuracy",
          "Time to resolve a cross-company receipt",
          "Bank reconciliation breaks",
          "Invoices cleared once cash is applied",
        ]}
      />

      {showCeremony && (
        <RunCompleteModal
          eyebrow="Cash application complete"
          title={`${payment.paymentId} posted across both entities`}
          narrative={`${eur(payment.amount)} from ${ce.payerGroup} settled invoices in two legal entities and two currencies; ${clearNow.companyCode} cleared automatically. The ${transfer.companyCode} transfer and the ${eur(ce.fxDifference)} FX residual were approved by ${ce.approvalRoute}, and both company codes reconcile.`}
          stats={[
            { label: `${clearNow.companyCode} cleared`, value: eur(clearNow.eurValue), tone: "success" },
            { label: `${transfer.companyCode} transfer`, value: eur(transfer.eurValue) },
            { label: "FX residual", value: eur(ce.fxDifference) },
            { label: "Short-pay", value: eur(0), tone: "success" },
          ]}
          primaryLabel="Back to queue"
          onPrimary={onDone}
          secondaryLabel="Review posting"
          onSecondary={() => setShowCeremony(false)}
        />
      )}
    </div>
  );
}
