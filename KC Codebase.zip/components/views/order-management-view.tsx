"use client";

import { Fragment, useEffect, useMemo, useRef, useState } from "react";
import { HeldOrderCard } from "@/components/mounts/order-management/held-order-card";
import { AppointmentSlotRun } from "@/components/views/appointment-slot-run";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { OwnerChip } from "@/components/shared/owner-chip";
import { AgentIcon } from "@/components/agents/agent-icon";
import { AnimatedProgress } from "@/components/agents/animated-progress";
import {
  ChevronDown,
  ChevronLeft,
  CircleCheck,
  MessageCircle,
  Play,
  Send,
  ThumbsUp,
  X,
} from "lucide-react";
import {
  StageRail,
  type StageRailChip,
  type StageDotState,
} from "@/components/mounts/order-management/stage-rail";
import { PoIntakePanel } from "@/components/mounts/order-management/po-intake-panel";
import { PricingValidationPanel } from "@/components/mounts/order-management/pricing-validation-panel";
import { RegulatoryPanel } from "@/components/mounts/order-management/regulatory-panel";
import { OrderShipmentCard } from "@/components/mounts/order-management/fulfillment-tracker";
import { InventoryAllocationPanel } from "@/components/mounts/order-management/inventory-allocation-panel";
import { Spinner } from "@/components/agents/spinner";
import {
  AiStepReasoning,
  RevealWhen,
 waitForStepReasoning,
 skipStepReasoning,
 resetStepReasoning,
} from "@/components/mounts/order-management/step-reasoning";
import {
  allocationReasoning,
  AllocationLogicCard,
  appointmentReasoning,
  CustomerConfirmationDialog,
  CustomerConfirmationRow,
  FulfillmentEvidence,
  evidenceLogs,
  hasOrderEvidence,
  OrderStatusTimeline,
  ShipToTermsCard,
  SHIP_TO_ROW_COUNT,
} from "@/components/mounts/order-management/order-evidence";
import { AppointmentStagePanel } from "@/components/mounts/order-management/appointment-stage-panel";
import {
  DeliveryStagePanel,
  deliveryReasoning,
  ShipmentPlanPanel,
  shipmentPlanReasoning,
} from "@/components/mounts/order-management/logistics-stage-panels";
import { orderLogistics } from "@/lib/data/order-logistics";
import { invoiceToCashFor } from "@/lib/data/invoice-to-cash";
import { PodStagePanel } from "@/components/mounts/order-management/downstream-stage-panels";
import type { ViewId } from "@/components/layout/sidebar";
import type { Invoice, Order } from "@/lib/data/types";
import { customers } from "@/lib/data/customers";
import {
  findInboundPo,
  isPricingHoldOrder,
  pricingHoldCase,
} from "@/lib/data/pipeline-orders";
import { PricingHoldCard } from "@/components/mounts/order-management/pricing-hold-card";
import { recallNotices, regulatoryReviews } from "@/lib/data/regulatory";
import { findShipmentByOrder } from "@/lib/data/shipments";
import { RunCompleteModal } from "@/components/mounts/order-management/run-complete-modal";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { StepNode } from "@/components/mounts/shared/step-node";
import { useFollowLatest } from "@/components/mounts/shared/use-follow-latest";

/**
 * The Order Management workflow: purchase order in, signed proof of delivery
 * out. Billing and everything after it are separate workflows with their own
 * workspaces — confirming the POD is what unlocks them.
 */
const MACRO_STAGES: { id: string; label: string }[] = [
  { id: "po_intake", label: "PO Intake" },
  { id: "po_understanding", label: "PO Validation" },
  { id: "regulatory", label: "Regulatory Checks" },
  { id: "fulfillment", label: "Fulfillment" },
  { id: "pod", label: "POD" },
];

/** Short chip labels so every stage fits one compact row. */
const SHORT_LABEL: Record<string, string> = {
  po_intake: "PO Intake",
  po_understanding: "Validation",
  regulatory: "Regulatory",
  fulfillment: "Fulfillment",
  pod: "POD",
};

/** One-line summary shown when a completed stage is collapsed in the run. */
const STAGE_SUMMARY: Record<string, string> = {
  po_intake: "Securely queued · workflow planned · content extracted",
  po_understanding: "Customer verified · no duplicate SO · MOQ met · credit approved · ship-to & terms valid",
  regulatory: "Product and regulatory checks passed",
  fulfillment: "Inventory allocated · customer confirmed · TMS plan read · slot booked · delivered on time, in full",
  pod: "Delivery confirmed — billing unlocked",
};

/**
 * Internal simulation stages, in run order. Each maps to a macro stage — PO
 * Validation groups read/validate, pricing, credit and minimum-order, and
 * Regulatory runs after it (client's true process order).
 */
interface SimStage {
  id: string;
  label: string;
  macro: string;
  agentType: string;
}
const SIM_STAGES: SimStage[] = [
  { id: "capture", label: "PO Intake", macro: "po_intake", agentType: "orchestrator" },
  { id: "validation", label: "Read & validate", macro: "po_understanding", agentType: "validation" },
  { id: "pricing", label: "Pricing", macro: "po_understanding", agentType: "pricing" },
  { id: "moq", label: "Minimum order", macro: "po_understanding", agentType: "moq" },
  { id: "credit", label: "Credit", macro: "po_understanding", agentType: "credit" },
  { id: "regulatory", label: "Regulatory Checks", macro: "regulatory", agentType: "document" },
  { id: "atp", label: "Inventory Allocation", macro: "fulfillment", agentType: "atp" },
  { id: "confirmed", label: "Customer Confirmation", macro: "fulfillment", agentType: "orchestrator" },
  { id: "shipment_plan", label: "Shipment Planning", macro: "fulfillment", agentType: "delivery" },
  { id: "appointment", label: "Appointment", macro: "fulfillment", agentType: "delivery" },
  { id: "delivery", label: "Track & Deliver", macro: "fulfillment", agentType: "delivery" },
];

/** Chip text for each run step on the order card. */
const STEP_SHORT_LABEL: Record<string, string> = {
  capture: "PO Intake",
  validation: "Validation",
  pricing: "Pricing",
  moq: "MOQ",
  credit: "Credit",
  regulatory: "Regulatory",
  atp: "Allocation",
  confirmed: "Confirmation",
  shipment_plan: "Shipment plan",
  appointment: "Appointment",
  delivery: "Track & deliver",
  pod: "POD",
};

const FULFILLMENT_STEP_IDS = ["atp", "shipment_plan", "appointment", "delivery"] as const;
type FulfillmentStepId = (typeof FULFILLMENT_STEP_IDS)[number];
function isFulfillmentStep(id: string): id is FulfillmentStepId {
  return (FULFILLMENT_STEP_IDS as readonly string[]).includes(id);
}

const PIPELINE_ORDER_IDS = [
  "SO-710260",
  "SO-710249",
  "SO-710261",
  "SO-710262",
  "SO-710263",
];

type SimStatus = "waiting" | "running" | "passed" | "blocked" | "needsReview";
type LogStatus = "info" | "success" | "warning";

interface AgentLog {
  id: string;
  timestamp: string;
  agent: string;
  agentType: string;
  message: string;
  status: LogStatus;
}

interface PricingDetails {
  basePrice: number;
  discounts: { type: string; amount: number; rule: string }[];
  taxes: number;
  total: number;
}
interface CreditDetails {
  creditExposure: number;
  creditLimit: number;
  exposureRatio: number;
  decision: string;
  reason?: string;
}

interface OrderPipelineState {
  orderId: string;
  currentStage: string;
  stageStatuses: Record<string, SimStatus>;
  agentLogs: AgentLog[];
  /** Read/validate results shown once PO Validation runs. */
  understandingChecks?: { name: string; detail: string }[];
  regulatoryChecked?: boolean;
  pricingDetails?: PricingDetails;
  /** Scenario 2: contract-price mismatch hold and its human release. */
  pricingHold?: "held" | "released";
  creditDetails?: CreditDetails;
  moqMet?: boolean;
  atpReady?: boolean;
}

interface ChatMessage {
  role: "user" | "agent";
  text: string;
  isApproval?: boolean;
}
interface ChatState {
  open: boolean;
  messages: ChatMessage[];
  input: string;
}

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function orderStatusBadgeClass(status: string) {
  return status === "Hold"
    ? "bg-red-50 text-red-700 border-red-200"
    : status === "Blocked"
      ? "bg-amber-50 text-amber-700 border-amber-200"
      : status === "Fulfilled"
        ? "bg-green-50 text-green-700 border-green-200"
        : "bg-gray-50 text-gray-600 border-gray-200";
}

function validationChecks(order: Order) {
  return [
    {
      name: "Customer details",
      detail: `${order.customerName} verified against master data`,
    },
    {
      name: "Duplicate sales order",
      detail: "No existing sales order for this PO reference",
    },
    {
      name: "Shipping address & payment terms",
      detail: "Ship-to matches master data · Net 30 terms confirmed",
    },
  ];
}

function validationLog(order: Order) {
  return `Verified ${order.customerName}; found no duplicate SO; matched ship-to and Net 30 terms.`;
}

function captureLog(order: Order) {
  const po = findInboundPo(order.orderId);
  if (!po) return "Queued the sales-entry order; planned the workflow.";
  const source = po.channel === "Sales Order Dashboard" ? "the Sales Order Dashboard" : po.channel.toLowerCase();
  return `Queued ${po.poNumber} from ${source}; planned the workflow.`;
}

function extractionLog(order: Order) {
  const po = findInboundPo(order.orderId);
  if (!po) return "Extracted customer, lines, dates and terms.";
  return `Extracted ${po.lines.length} lines, ${po.paymentTerms}, delivery ${po.requestedDelivery}, total $${order.totalValue.toLocaleString()}.`;
}

const MOQ_LOG = "Met MOQ on every line.";
const REGULATORY_PASS_LOG = "Passed 4 of 4 product checks: recall, quality release, restriction, allocation.";
const PRICING_APPLIED_LOG = "Applied PRC-200 volume discount; computed taxes.";
const CREDIT_OK_LOG = "Approved credit within limit.";
const POD_LOG = "Confirmed proof of delivery; unlocked billing.";
const INVOICE_LOG = "Sent invoice from the delivery tie-out; awaiting payment.";

/** Scenario 1: a valid PO uploaded via the Sales Order Dashboard runs fully touchless. */
function isTouchlessOrder(orderId: string) {
  return findInboundPo(orderId)?.channel === "Sales Order Dashboard";
}
const TOUCHLESS_SKIPPED_STAGES = new Set(["pricing", "regulatory"]);
/** Orders without a TMS plan close on the POD stage instead of planning and tracking. */
const LOGISTICS_STAGES = new Set(["shipment_plan", "delivery"]);
function skipsStage(orderId: string, stageId: string) {
  return (
    (isTouchlessOrder(orderId) && TOUCHLESS_SKIPPED_STAGES.has(stageId)) ||
    (!orderLogistics(orderId) && LOGISTICS_STAGES.has(stageId))
  );
}

/** Scenario runs (Costco, Target) close on Track & deliver, which carries the POD: no separate POD stage. */
function isScenarioOrder(orderId: string) {
  return isTouchlessOrder(orderId) || isPricingHoldOrder(orderId);
}

function macroStagesFor(orderId: string) {
  return isScenarioOrder(orderId) ? MACRO_STAGES.filter((m) => m.id !== "pod") : MACRO_STAGES;
}

function stageSummaryFor(orderId: string, macroId: string) {
  if (isPricingHoldOrder(orderId) && macroId === "po_understanding") {
    return `Customer verified · no duplicate SO · 4 contract-price mismatches ($${pricingHoldCase.totalVariance}) billed at contract, signed by ${pricingHoldCase.approver} · MOQ met · credit approved`;
  }
  return STAGE_SUMMARY[macroId];
}

/** One-line summary for each run step once it completes and collapses. */
const STEP_SUMMARY: Record<string, string> = {
  capture: "Securely queued · workflow planned · content extracted",
  validation: "Customer verified · no duplicate SO · ship-to & Net 30 terms valid",
  pricing: "Contract pricing applied · taxes computed",
  moq: "Minimum order quantity met on every line",
  credit: "Credit approved within limit",
  regulatory: "Recall, quality release, restriction & allocation checks passed",
  atp: "Inventory allocated per the allocation rules",
  confirmed: "Order confirmed to the customer",
  shipment_plan: "Route, load and carrier read from SAP TM · tender accepted",
  appointment: "Slot booked inside the customer's OTIF rule · calendar blocked",
  delivery: "Available · Shipped · Delivered · POD signed · billing unlocked",
  pod: "Delivery confirmed — billing unlocked",
};

function stepSummaryFor(orderId: string, stepId: string) {
  if (stepId === "pricing" && isPricingHoldOrder(orderId)) {
    return `${pricingHoldCase.lines.length} contract-price mismatches ($${pricingHoldCase.totalVariance}) billed at contract, signed by ${pricingHoldCase.approver}`;
  }
  return STEP_SUMMARY[stepId] ?? "";
}

const PRICING_HOLD_LOG = `Held ${pricingHoldCase.poNumber}: ${pricingHoldCase.lines.length} lines above ${
  pricingHoldCase.contract
} (${pricingHoldCase.lines.map((l) => `+$${l.variance}`).join(", ")}); variance $${pricingHoldCase.totalVariance}.`;
const PRICING_RECOMMENDATION_LOG = `$${pricingHoldCase.totalVariance} gap is above the $${pricingHoldCase.tolerancePerOrderUsd} perfect-invoice tolerance. Recommends billing at contract ${pricingHoldCase.contract}.`;
const PRICING_RELEASE_LOG = `${pricingHoldCase.approver} signed billing at contract price; recorded ${pricingHoldCase.discrepancyRecordId} · ${pricingHoldCase.decisionId}.`;

function creditFor(order: Order): CreditDetails {
  if (order.status === "Hold") {
    return {
      creditExposure: 485000 + order.totalValue,
      creditLimit: 500000,
      exposureRatio: (485000 + order.totalValue) / 500000,
      decision: "Blocked",
      reason: "Exposure exceeds the limit by $110K",
    };
  }
  const customer = customers.find((c) => c.customerId === order.customerId);
  const exposure = (customer?.currentExposure ?? 0) + order.totalValue;
  const limit = customer?.creditLimit ?? exposure;
  return {
    creditExposure: exposure,
    creditLimit: limit,
    exposureRatio: exposure / limit,
    decision: "Approved",
  };
}

function creditLog(order: Order) {
  const c = creditFor(order);
  return `Approved credit: $${Math.round(c.creditExposure).toLocaleString()} of $${Math.round(
    c.creditLimit
  ).toLocaleString()} limit (${Math.round(c.exposureRatio * 100)}%).`;
}

/** Evidence-backed log lines for the fulfillment stage, one per card on screen. */
function fulfillmentLogEntries(orderId: string): [agent: string, message: string][] | null {
  const logs = evidenceLogs(orderId, { humanTouchpoints: isPricingHoldOrder(orderId) ? 1 : 0 });
  if (!logs) return null;
  return [
    ["Allocation Agent", logs.allocation],
    ["Freight Planning Agent", logs.shipmentPlan],
    ["Appointment Scheduling Agent", logs.appointment],
    ["Track and Trace Agent", logs.delivery],
  ];
}

function confirmationLog(orderId: string) {
  return (
    evidenceLogs(orderId, { humanTouchpoints: isPricingHoldOrder(orderId) ? 1 : 0 })?.confirmation ??
    STAGE_COMPLETE_LOG.confirmed
  );
}

const GENERIC_FULFILLMENT_LOG: Record<FulfillmentStepId, string> = {
  atp: "Allocated inventory per the allocation rules.",
  shipment_plan: "Read route, load and carrier from the TMS plan.",
  appointment: "Booked the receiving slot inside the OTIF window.",
  delivery: "Delivered on time and in full; billing unlocked.",
};

/** The log line for one fulfillment step — evidence-backed when the order has it. */
function fulfillmentStepLog(orderId: string, stepId: FulfillmentStepId): [string, string] {
  const evidence = fulfillmentLogEntries(orderId);
  return (
    evidence?.[FULFILLMENT_STEP_IDS.indexOf(stepId)] ?? [
      "Fulfillment Agent",
      GENERIC_FULFILLMENT_LOG[stepId],
    ]
  );
}

const STAGE_COMPLETE_LOG: Record<"atp" | "confirmed", string> = {
  atp: "Allocated inventory per the allocation rules.",
  confirmed: "Confirmed the order to the customer; 0 manual touchpoints.",
};

/**
 * A fully-completed phase-1 pipeline (all checks passed) with a canonical
 * audit trail. Used to rehydrate an in-progress run after the human returns
 * from a downstream page, so the workspace picks up exactly where it left off.
 */
function buildCompletedPipeline(order: Order): OrderPipelineState {
  const ts = new Date().toISOString();
  const entry = (
    agentType: string,
    agent: string,
    message: string
  ): AgentLog => ({
    id: `log-${agent}-${message.slice(0, 12)}`,
    timestamp: ts,
    agent,
    agentType,
    message,
    status: "success",
  });
  return {
    orderId: order.orderId,
    currentStage: "confirmed",
    stageStatuses: Object.fromEntries(
      SIM_STAGES.map((s) => [s.id, "passed" as SimStatus])
    ),
    understandingChecks: validationChecks(order),
    regulatoryChecked: true,
    pricingDetails: {
      basePrice: 0.97 * order.totalValue,
      discounts: [
        { type: "Volume discount", amount: 0.03 * order.totalValue, rule: "PRC-200" },
      ],
      taxes: 0.18 * order.totalValue,
      total: order.totalValue,
    },
    creditDetails: creditFor(order),
    moqMet: true,
    atpReady: true,
    pricingHold: isPricingHoldOrder(order.orderId) ? "released" : undefined,
    agentLogs: isPricingHoldOrder(order.orderId)
      ? [
          entry("orchestrator", "Orchestrator Agent", captureLog(order)),
          entry("extraction", "Extraction Agent", extractionLog(order)),
          entry("validation", "PO Validation Agent", validationLog(order)),
          entry("pricing", "PO Validation Agent", PRICING_HOLD_LOG),
          entry("pricing", "Pricing Agent", PRICING_RECOMMENDATION_LOG),
          entry("pricing", "Pricing Agent", PRICING_RELEASE_LOG),
          entry("moq", "PO Validation Agent", MOQ_LOG),
          entry("credit", "Credit Risk Agent", creditLog(order)),
          entry(
            "document",
            "Regulatory Check Agent",
            REGULATORY_PASS_LOG
          ),
          entry("atp", ...fulfillmentStepLog(order.orderId, "atp")),
          entry("orchestrator", "Communication Agent", confirmationLog(order.orderId)),
          entry("delivery", ...fulfillmentStepLog(order.orderId, "shipment_plan")),
          entry("delivery", ...fulfillmentStepLog(order.orderId, "appointment")),
          entry("delivery", ...fulfillmentStepLog(order.orderId, "delivery")),
        ]
      : isTouchlessOrder(order.orderId)
      ? [
          entry("orchestrator", "Orchestrator Agent", captureLog(order)),
          entry("extraction", "Extraction Agent", extractionLog(order)),
          entry("validation", "Validation Agent", validationLog(order)),
          entry("moq", "Validation Agent", MOQ_LOG),
          entry("credit", "Credit Risk Agent", creditLog(order)),
          entry("atp", ...fulfillmentStepLog(order.orderId, "atp")),
          entry("orchestrator", "Communication Agent", confirmationLog(order.orderId)),
          entry("delivery", ...fulfillmentStepLog(order.orderId, "shipment_plan")),
          entry("delivery", ...fulfillmentStepLog(order.orderId, "appointment")),
          entry("delivery", ...fulfillmentStepLog(order.orderId, "delivery")),
        ]
      : [
          entry("orchestrator", "PO Intake Agent", captureLog(order)),
          entry("extraction", "PO Validation Agent", validationLog(order)),
          entry(
            "pricing",
            "Pricing Agent",
            PRICING_APPLIED_LOG
          ),
          entry(
            "moq",
            "PO Validation Agent",
            MOQ_LOG
          ),
          entry(
            "credit",
            "PO Validation Agent",
            CREDIT_OK_LOG
          ),
          entry(
            "document",
            "Regulatory Check Agent",
            REGULATORY_PASS_LOG
          ),
          entry("atp", ...fulfillmentStepLog(order.orderId, "atp")),
          entry("orchestrator", "OTC Orchestrator", STAGE_COMPLETE_LOG.confirmed),
          entry("atp", ...fulfillmentStepLog(order.orderId, "appointment")),
          entry(
            "delivery",
            "POD Validation Agent",
            POD_LOG
          ),
          entry(
            "billing",
            "Billing Agent",
            INVOICE_LOG
          ),
        ],
  };
}

export function OrderManagementView({
  onNavigate,
}: {
  onNavigate?: (view: ViewId, orderId?: string) => void;
}) {
  const store = useOtcStore();
  const {
    orders,
    allInvoices,
    releasedRegulatoryOrders,
    issueInvoice,
    runOrderId,
    runResumePending,
    completedRunOrders,
    startRun,
    consumeResume,
    markRunComplete,
    endRun,
  } = store;

  const pipelineOrders = useMemo(
    () =>
      PIPELINE_ORDER_IDS.map((id) =>
        orders.find((o) => o.orderId === id)
      ).filter((o): o is Order => !!o),
    [orders]
  );

  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
  /** The Walmart order held at Appointment opens Run A in place. */
  const [heldRunOpen, setHeldRunOpen] = useState(false);
  const [pipelines, setPipelines] = useState<Record<string, OrderPipelineState>>({});
  const [processing, setProcessing] = useState<Record<string, boolean>>({});
  const [awaitingApproval, setAwaitingApproval] = useState<Record<string, boolean>>({});
  /** Which stage panel is open on each card (one at a time). */
  const [openStage, setOpenStage] = useState<Record<string, string | null>>({});
  /** Orders whose proof-of-delivery email has been confirmed by a human. */
  const [podConfirmed, setPodConfirmed] = useState<Set<string>>(new Set());
  const [chat, setChat] = useState<ChatState>({ open: false, messages: [], input: "" });
  const auditLogRef = useRef<HTMLDivElement>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const holdResolverRef = useRef<(() => void) | null>(null);
  /** Order whose customer-confirmation dialog (EDI 855 or reply email) is showing mid-run. */
  const [confirmDialogOrder, setConfirmDialogOrder] = useState<string | null>(null);
  const confirmResolverRef = useRef<(() => void) | null>(null);
  /** Scenario runs step forward only when the presenter presses Enter. */
  const [awaitingAdvance, setAwaitingAdvance] = useState<string | null>(null);
  const advanceRef = useRef<(() => void) | null>(null);
  const waitForEnter = (orderId: string) =>
    new Promise<void>((resolve) => {
      advanceRef.current = () => {
        advanceRef.current = null;
        setAwaitingAdvance(null);
        resolve();
      };
      setAwaitingAdvance(orderId);
    });

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Enter" || e.repeat) return;
      if (!advanceRef.current) return;
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      e.preventDefault();
      advanceRef.current();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const selectedOrder = pipelineOrders.find((o) => o.orderId === selectedOrderId) ?? null;

  useEffect(() => {
    if (auditLogRef.current) {
      auditLogRef.current.scrollTop = auditLogRef.current.scrollHeight;
    }
  }, [pipelines]);
  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [chat.messages]);

  useEffect(() => {
    setPipelines((prev) => {
      const next = { ...prev };
      pipelineOrders.forEach((order) => {
        if (!next[order.orderId]) {
          next[order.orderId] = {
            orderId: order.orderId,
            currentStage: "capture",
            stageStatuses: Object.fromEntries(
              SIM_STAGES.map((s) => [s.id, "waiting" as SimStatus])
            ),
            agentLogs: [],
          };
        }
      });
      return next;
    });
  }, [pipelineOrders]);

  // Resuming a run: when we land back here after resolving a downstream stage
  // on its own page, rehydrate that order's pipeline as completed and reopen
  // its detail so the run picks up where it left off.
  useEffect(() => {
    if (!runResumePending || !runOrderId) return;
    if (selectedOrderId !== null && selectedOrderId !== runOrderId) return;
    const order = pipelineOrders.find((o) => o.orderId === runOrderId);
    if (!order) return;
    setPipelines((prev) => ({
      ...prev,
      [order.orderId]: buildCompletedPipeline(order),
    }));
    setPodConfirmed((prev) => new Set(prev).add(order.orderId));
    setSelectedOrderId(order.orderId);
    consumeResume();
  }, [
    runResumePending,
    runOrderId,
    selectedOrderId,
    pipelineOrders,
    consumeResume,
  ]);

  const addAgentLog = (
    orderId: string,
    agentType: string,
    agent: string,
    message: string,
    status: LogStatus
  ) => {
    setPipelines((prev) => ({
      ...prev,
      [orderId]: {
        ...prev[orderId],
        agentLogs: [
          ...prev[orderId].agentLogs,
          {
            id: `log-${Date.now()}-${Math.random()}`,
            timestamp: new Date().toISOString(),
            agent,
            agentType,
            message,
            status,
          },
        ],
      },
    }));
  };

  const runPipeline = async (order: Order) => {
    setProcessing((prev) => ({ ...prev, [order.orderId]: true }));
    const startIndex = SIM_STAGES.findIndex(
      (s) => s.id === (pipelines[order.orderId]?.currentStage ?? "capture")
    );
    const touchless = isTouchlessOrder(order.orderId);
    const pricingHoldOrder = isPricingHoldOrder(order.orderId);
    const agentName = (generic: string, scenario: string) =>
      touchless || pricingHoldOrder ? scenario : generic;
    const manualAdvance = touchless || pricingHoldOrder;
    // Scenario runs follow the deduction runs: a step opens and plays at its own
    // pace, and the next Enter closes it and opens the following step.
    // One Enter per step: it is listened for from the moment the step opens, so
    // the step's animation plays at full pace but a press at any point advances.
    let stageAdvance: Promise<void> | null = null;
    const pause = (ms: number) =>
      stageAdvance ? Promise.race([delay(ms), stageAdvance]) : delay(ms);
    if (manualAdvance && startIndex <= 0) resetStepReasoning(`${order.orderId}:`);
    const stepDone = async (key: string) => {
      if (manualAdvance) {
        await (stageAdvance ?? waitForEnter(order.orderId));
        skipStepReasoning(key);
      } else {
        await waitForStepReasoning(key);
      }
    };
    for (let i = Math.max(0, startIndex); i < SIM_STAGES.length; i++) {
      const stage = SIM_STAGES[i];
      if (skipsStage(order.orderId, stage.id)) {
        setPipelines((prev) => ({
          ...prev,
          [order.orderId]: {
            ...prev[order.orderId],
            stageStatuses: {
              ...prev[order.orderId].stageStatuses,
              [stage.id]: "passed",
            },
          },
        }));
        continue;
      }
      const stepKey = `${order.orderId}:${stage.id}`;
      setPipelines((prev) => ({
        ...prev,
        [order.orderId]: {
          ...prev[order.orderId],
          currentStage: stage.id,
          stageStatuses: {
            ...prev[order.orderId].stageStatuses,
            [stage.id]: "running",
          },
        },
      }));
      stageAdvance =
        manualAdvance && !(stage.id === "pricing" && pricingHoldOrder)
          ? waitForEnter(order.orderId)
          : null;
      await pause(1200);

      if (stage.id === "validation") {
        setPipelines((prev) => ({
          ...prev,
          [order.orderId]: {
            ...prev[order.orderId],
            understandingChecks: validationChecks(order),
          },
        }));
        addAgentLog(
          order.orderId,
          "extraction",
          pricingHoldOrder
            ? "PO Validation Agent"
            : agentName("PO Validation Agent", "Validation Agent"),
          validationLog(order),
          "success"
        );
      } else if (stage.id === "pricing" && pricingHoldOrder) {
        setPipelines((prev) => ({
          ...prev,
          [order.orderId]: {
            ...prev[order.orderId],
            pricingHold: "held",
            stageStatuses: {
              ...prev[order.orderId].stageStatuses,
              pricing: "blocked",
            },
          },
        }));
        addAgentLog(order.orderId, "pricing", "PO Validation Agent", PRICING_HOLD_LOG, "warning");
        // In a scenario run the approval click is the advance for this step.
        if (!manualAdvance) await waitForStepReasoning(stepKey);
        await pause(600);
        addAgentLog(order.orderId, "pricing", "Pricing Agent", PRICING_RECOMMENDATION_LOG, "info");
        setAwaitingApproval((prev) => ({ ...prev, [order.orderId]: true }));
        await new Promise<void>((resolve) => {
          holdResolverRef.current = resolve;
        });
        skipStepReasoning(stepKey);
        setAwaitingApproval((prev) => ({ ...prev, [order.orderId]: false }));
        setPipelines((prev) => ({
          ...prev,
          [order.orderId]: {
            ...prev[order.orderId],
            pricingHold: "released",
            stageStatuses: {
              ...prev[order.orderId].stageStatuses,
              pricing: "passed",
            },
          },
        }));
        addAgentLog(order.orderId, "pricing", "Pricing Agent", PRICING_RELEASE_LOG, "success");
        await pause(400);
        continue;
      } else if (stage.id === "pricing") {
        setPipelines((prev) => ({
          ...prev,
          [order.orderId]: {
            ...prev[order.orderId],
            pricingDetails: {
              basePrice: 0.97 * order.totalValue,
              discounts: [
                { type: "Volume discount", amount: 0.03 * order.totalValue, rule: "PRC-200" },
              ],
              taxes: 0.18 * order.totalValue,
              total: order.totalValue,
            },
          },
        }));
        addAgentLog(order.orderId, "pricing", "Pricing Agent", PRICING_APPLIED_LOG, "success");
      } else if (stage.id === "moq") {
        setPipelines((prev) => ({
          ...prev,
          [order.orderId]: { ...prev[order.orderId], moqMet: true },
        }));
        addAgentLog(
          order.orderId,
          "moq",
          pricingHoldOrder
            ? "PO Validation Agent"
            : agentName("PO Validation Agent", "Validation Agent"),
          MOQ_LOG,
          "success"
        );
      } else if (stage.id === "credit") {
        const isHold = order.status === "Hold";
        setPipelines((prev) => ({
          ...prev,
          [order.orderId]: {
            ...prev[order.orderId],
            stageStatuses: {
              ...prev[order.orderId].stageStatuses,
              credit: isHold ? "blocked" : "running",
            },
            creditDetails: creditFor(order),
          },
        }));
        if (isHold) setAwaitingApproval((prev) => ({ ...prev, [order.orderId]: true }));
        await stepDone(stepKey);
        if (!isHold) {
          setPipelines((prev) => ({
            ...prev,
            [order.orderId]: {
              ...prev[order.orderId],
              stageStatuses: { ...prev[order.orderId].stageStatuses, credit: "passed" },
            },
          }));
        }
        addAgentLog(
          order.orderId,
          "credit",
          agentName("PO Validation Agent", "Credit Risk Agent"),
          isHold
            ? "Blocked credit: exposure over limit; awaiting approval in chat."
            : touchless || pricingHoldOrder
              ? creditLog(order)
              : CREDIT_OK_LOG,
          isHold ? "warning" : "success"
        );
        if (isHold) {
          setAwaitingApproval((prev) => ({ ...prev, [order.orderId]: true }));
          await new Promise<void>((resolve) => {
            holdResolverRef.current = resolve;
          });
          setAwaitingApproval((prev) => ({ ...prev, [order.orderId]: false }));
        }
        await pause(400);
        continue;
      } else if (stage.id === "regulatory") {
        const review = regulatoryReviews.find((r) => r.orderId === order.orderId);
        const released = releasedRegulatoryOrders.has(order.orderId);
        const isQualityHold = !!review && review.overall === "Hold" && !released;
        if (!isQualityHold) await stepDone(stepKey);
        setPipelines((prev) => ({
          ...prev,
          [order.orderId]: {
            ...prev[order.orderId],
            regulatoryChecked: true,
            stageStatuses: {
              ...prev[order.orderId].stageStatuses,
              regulatory: isQualityHold ? "needsReview" : "passed",
            },
          },
        }));
        addAgentLog(
          order.orderId,
          "document",
          "Regulatory Check Agent",
          review && review.overall === "Hold"
            ? released
              ? `Released quality hold; applied substitute lot ${review.substituteLot}.`
              : `Held a line on lot ${review.affectedLot} (notice ${recallNotices[0].id}); awaiting Review Order Hold.`
            : REGULATORY_PASS_LOG,
          isQualityHold ? "warning" : "success"
        );
        if (isQualityHold) {
          setProcessing((prev) => ({ ...prev, [order.orderId]: false }));
          return;
        }
        await pause(400);
        continue;
      } else if (stage.id === "atp") {
        setPipelines((prev) => ({
          ...prev,
          [order.orderId]: { ...prev[order.orderId], atpReady: true },
        }));
      } else if (stage.id === "confirmed" && hasOrderEvidence(order.orderId)) {
        // The Communication Agent's confirmation opens centered; the run
        // continues once it has been sent and acknowledged.
        await stepDone(stepKey);
        setConfirmDialogOrder(order.orderId);
        await new Promise<void>((resolve) => {
          confirmResolverRef.current = resolve;
        });
        setConfirmDialogOrder(null);
      }

      // Hold the step open until the AI has finished explaining it (or, in a
      // scenario run, until Enter). Sending the confirmation already advanced.
      if (stage.id === "confirmed" && hasOrderEvidence(order.orderId)) {
        skipStepReasoning(stepKey);
      } else {
        await stepDone(stepKey);
      }
      setPipelines((prev) => ({
        ...prev,
        [order.orderId]: {
          ...prev[order.orderId],
          stageStatuses: {
            ...prev[order.orderId].stageStatuses,
            [stage.id]: "passed",
          },
        },
      }));
      if (isFulfillmentStep(stage.id)) {
        const [agent, message] = fulfillmentStepLog(order.orderId, stage.id);
        addAgentLog(order.orderId, stage.id === "atp" ? "atp" : "delivery", agent, message, "success");
        const i2c = stage.id === "delivery" ? invoiceToCashFor(order.orderId) : null;
        if (i2c) issueInvoice(order.orderId, i2c.invoiceId);
      } else if (stage.id === "confirmed" && hasOrderEvidence(order.orderId)) {
        addAgentLog(order.orderId, "orchestrator", "Communication Agent", confirmationLog(order.orderId), "success");
      } else if (stage.id === "capture" || stage.id === "confirmed") {
        const name =
          stage.id === "capture"
            ? agentName("PO Intake Agent", "Orchestrator Agent")
            : agentName("OTC Orchestrator", "Communication Agent");
        addAgentLog(
          order.orderId,
          stage.agentType,
          name,
          stage.id === "capture" ? captureLog(order) : STAGE_COMPLETE_LOG.confirmed,
          "success"
        );
        if (stage.id === "capture") {
          addAgentLog(
            order.orderId,
            "extraction",
            agentName("PO Intake Agent", "Extraction Agent"),
            extractionLog(order),
            "success"
          );
        }
      }
      await pause(400);
    }
    setProcessing((prev) => ({ ...prev, [order.orderId]: false }));
  };

  /** Scenario 2: the human accepts the agent recommendation and releases the hold. */
  const releasePricingHold = (orderId: string) => {
    if (!awaitingApproval[orderId]) return;
    setAwaitingApproval((prev) => ({ ...prev, [orderId]: false }));
    holdResolverRef.current?.();
    holdResolverRef.current = null;
  };

  /** Macro-stage status once the quality hold is released elsewhere. */
  const releasedRegulatory = (orderId: string) =>
    releasedRegulatoryOrders.has(orderId);

  /** Build the ten-stage rail for an order from the simulation + the store. */
  const railChips = (order: Order): StageRailChip[] => {
    // A finished run reads as ten green stages even after the active run ends.
    const macros = macroStagesFor(order.orderId);
    if (completedRunOrders.includes(order.orderId)) {
      return macros.map((macro) => ({
        id: macro.id,
        label: macro.label,
        dot: "done" as StageDotState,
        caption: "Done",
        captionTone: "positive" as StageRailChip["captionTone"],
        clickable: true,
        title: `${macro.label} — complete`,
      }));
    }
    const sim = pipelines[order.orderId];
    const shipment = findShipmentByOrder(order.orderId);

    const macroSimStatus = (macroId: string): StageDotState => {
      if (!sim) return "pending";
      const stagesForMacro = SIM_STAGES.filter((s) => s.macro === macroId);
      if (stagesForMacro.length === 0) return "pending";
      const currentMacro = SIM_STAGES.find((s) => s.id === sim.currentStage)?.macro;
      const currentSim = sim.stageStatuses[sim.currentStage];
      if (
        macroId === "regulatory" &&
        sim.stageStatuses.regulatory === "needsReview" &&
        !releasedRegulatory(order.orderId)
      )
        return "pause";
      if (
        macroId === "po_understanding" &&
        currentMacro === "po_understanding" &&
        currentSim === "blocked"
      )
        return "pause";
      const allPassed = stagesForMacro.every(
        (s) => sim.stageStatuses[s.id] === "passed"
      );
      if (allPassed) return "done";
      if (currentMacro === macroId) return "active";
      // regulatory reads done once released
      if (macroId === "regulatory" && releasedRegulatory(order.orderId)) return "done";
      return "pending";
    };

    return macros.map((macro) => {
      if (["po_intake", "po_understanding", "regulatory", "fulfillment"].includes(macro.id)) {
        return {
          id: macro.id,
          label: macro.label,
          dot: macroSimStatus(macro.id),
          clickable: true,
          title: `Open the ${macro.label} details for ${order.orderId}`,
        };
      }
      // POD — the closing stage, live from the carrier record
      let dot: StageDotState = "pending";
      let caption: string | undefined;
      let captionTone: StageRailChip["captionTone"] = "muted";
      if (shipment?.status === "Delivered" || podConfirmed.has(order.orderId)) {
        dot = "done";
        caption = "Delivered";
        captionTone = "positive";
      } else if (shipment) {
        caption = shipment.status;
        captionTone = shipment.status === "Delayed" ? "attention" : "muted";
      } else {
        caption = "Awaiting delivery";
      }
      return {
        id: macro.id,
        label: macro.label,
        dot,
        caption,
        captionTone,
        clickable: true,
        title: `Open the ${macro.label} details for ${order.orderId}`,
      };
    });
  };

  /** Every run step as its own chip; each opens its stage's detail panel. */
  const stepChips = (order: Order): (StageRailChip & { macro: string })[] => {
    const complete = completedRunOrders.includes(order.orderId);
    const sim = pipelines[order.orderId];
    const chips = SIM_STAGES.filter((s) => !skipsStage(order.orderId, s.id)).map((s) => {
      const status = sim?.stageStatuses[s.id];
      let dot: StageDotState =
        complete || status === "passed"
          ? "done"
          : status === "running"
            ? "active"
            : status === "blocked" || status === "needsReview"
              ? "pause"
              : "pending";
      if (s.id === "regulatory" && releasedRegulatory(order.orderId)) dot = "done";
      return {
        id: s.id,
        macro: s.macro,
        label: s.label,
        dot,
        clickable: true,
        title: `${s.label} — open the details for ${order.orderId}`,
      };
    });
    const pod = railChips(order).find((c) => c.id === "pod");
    return pod ? [...chips, { ...pod, macro: "pod" }] : chips;
  };

  const handleChipClick = (order: Order, stageId: string) => {
    setOpenStage((prev) => ({
      ...prev,
      [order.orderId]: prev[order.orderId] === stageId ? null : stageId,
    }));
  };

  // Confirming delivery authorizes billing — mark POD done and issue the
  // invoice so the thread keeps moving. Shared by the POD email modal and the
  // POD stage panel in the detail view.
  const confirmPodAndBill = (orderId: string) => {
    setPodConfirmed((prev) => new Set(prev).add(orderId));
    addAgentLog(
      orderId,
      "delivery",
      "POD Validation Agent",
      POD_LOG,
      "success"
    );
    issueInvoice(orderId);
    addAgentLog(
      orderId,
      "billing",
      "Billing Agent",
      INVOICE_LOG,
      "success"
    );
  };

  const sendChatMessage = () => {
    const text = chat.input.trim();
    if (!text) return;
    setChat((prev) => ({
      ...prev,
      messages: [...prev.messages, { role: "user", text }],
      input: "",
    }));
    const lower = text.toLowerCase();
    const orderId = selectedOrderId ?? "";
    setTimeout(() => {
      let reply = "";
      let isApproval = false;
      if (
        lower.includes("approve") ||
        lower.includes("release") ||
        lower.includes("override")
      ) {
        if (awaitingApproval[orderId] && isPricingHoldOrder(orderId)) {
          reply = `${orderId} is billed at contract ${pricingHoldCase.contract}. The $${pricingHoldCase.totalVariance} gap is recorded as ${pricingHoldCase.discrepancyRecordId} and the buyer is notified.`;
          isApproval = true;
          releasePricingHold(orderId);
        } else if (awaitingApproval[orderId]) {
          reply = `Credit hold for ${orderId} approved. Resuming the order.`;
          isApproval = true;
          setPipelines((prev) =>
            prev[orderId]
              ? {
                  ...prev,
                  [orderId]: {
                    ...prev[orderId],
                    stageStatuses: { ...prev[orderId].stageStatuses, credit: "passed" },
                  },
                }
              : prev
          );
          setAwaitingApproval((prev) => ({ ...prev, [orderId]: false }));
          holdResolverRef.current?.();
          holdResolverRef.current = null;
        } else {
          reply = `No pending credit hold for ${orderId}.`;
        }
      } else {
        const stage = pipelines[orderId]?.currentStage ?? "pending";
        reply = `Order ${orderId} is at the ${stage} step. Type 'approve' to release a credit hold.`;
      }
      setChat((prev) => ({
        ...prev,
        messages: [...prev.messages, { role: "agent", text: reply, isApproval }],
      }));
    }, 600);
  };

  if (heldRunOpen) {
    return <AppointmentSlotRun onBack={() => setHeldRunOpen(false)} backLabel="Back to Pipeline" />;
  }

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold text-foreground">Agentic Order Management</h2>

      {selectedOrder ? (
        <OrderDetail
          order={selectedOrder}
          pipeline={pipelines[selectedOrder.orderId]}
          awaiting={awaitingApproval[selectedOrder.orderId]}
          chips={stepChips(selectedOrder).map((c) => ({
            ...c,
            label: STEP_SHORT_LABEL[c.id] ?? c.label,
          }))}
          invoice={allInvoices.find(
            (i) => i.orderId === selectedOrder.orderId
          )}
          podDone={
            podConfirmed.has(selectedOrder.orderId) ||
            !!findShipmentByOrder(selectedOrder.orderId)
          }
          onConfirmPod={() => confirmPodAndBill(selectedOrder.orderId)}
          onReleasePricingHold={() => releasePricingHold(selectedOrder.orderId)}
          auditLogRef={auditLogRef}
          onBack={() => setSelectedOrderId(null)}
          onEndRun={() => {
            endRun();
            setSelectedOrderId(null);
          }}
          onRunComplete={() => markRunComplete(selectedOrder.orderId)}
          chat={chat}
          setChat={setChat}
          chatEndRef={chatEndRef}
          sendChatMessage={sendChatMessage}
        />
      ) : (
        <div className="space-y-4">
          <p className="text-sm text-muted-foreground">
            <span className="font-medium text-foreground">
              {pipelineOrders.length + 1}
            </span>{" "}
            orders in the pipeline
          </p>
          {pipelineOrders.map((order, idx) => {
            const state = pipelines[order.orderId];
            const isProcessing = processing[order.orderId];
            const runComplete = completedRunOrders.includes(order.orderId);
            const done = state?.currentStage === "confirmed" || runComplete;
            const open = openStage[order.orderId] ?? null;
            const chips = stepChips(order);
            const allChipsDone = chips.every((c) => c.dot === "done");
            const activeIdx = chips.findIndex(
              (c) => c.dot === "active" || c.dot === "pause"
            );
            const currentIdx = activeIdx >= 0 ? activeIdx : 0;
            const doneUnits =
              chips.filter((c) => c.dot === "done").length +
              (activeIdx >= 0 ? 0.5 : 0);
            const progressPct = allChipsDone
              ? 100
              : Math.round((doneUnits / chips.length) * 100);
            return (
              <Fragment key={order.orderId}>
              {idx === 2 && <HeldOrderCard onOpen={() => setHeldRunOpen(true)} />}
              <Card className="hover:shadow-md transition-shadow">
                <CardContent className="p-5 space-y-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-sm">{order.orderId}</h3>
                        {order.loopOrderFlag && (
                          <Badge
                            variant="outline"
                            className="text-xs bg-blue-50 text-blue-700 border-blue-200"
                          >
                            Loop Order
                          </Badge>
                        )}
                        <Badge
                          variant="outline"
                          className={`text-xs ${orderStatusBadgeClass(order.status)}`}
                        >
                          {order.status}
                        </Badge>
                      </div>
                      <p className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                        {order.customerName}
                        <OwnerChip account={order.customerName} variant="compact" />
                      </p>
                      <p className="text-sm font-medium text-foreground">
                        ${order.totalValue.toLocaleString()}
                      </p>
                    </div>
                    <Button
                      size="sm"
                      onClick={() => {
                        setSelectedOrderId(order.orderId);
                        setChat({ open: false, messages: [], input: "" });
                        startRun(order.orderId);
                        runPipeline(order);
                      }}
                      disabled={isProcessing || done}
                      className="gap-1.5 text-xs h-8 whitespace-nowrap"
                    >
                      {done ? (
                        <>
                          <CircleCheck className="h-3.5 w-3.5" /> Complete
                        </>
                      ) : (
                        <>
                          <Play className="h-3.5 w-3.5" /> Process
                        </>
                      )}
                    </Button>
                  </div>

                  {/* Original-style compact rail: stage label + progress bar + one chip row */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span>
                        Stage:{" "}
                        <span
                          className={cn(
                            "font-medium",
                            allChipsDone
                              ? "text-[var(--success)]"
                              : "text-foreground"
                          )}
                        >
                          {allChipsDone ? "Complete" : chips[currentIdx].label}
                        </span>
                      </span>
                      <span>
                        {allChipsDone ? chips.length : currentIdx + 1} /{" "}
                        {chips.length}
                      </span>
                    </div>
                    <div className="relative h-1.5 bg-muted rounded-full overflow-hidden">
                      <div
                        className="absolute h-full bg-[var(--success)] transition-all duration-500"
                        style={{ width: `${progressPct}%` }}
                      />
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {chips.map((chip) => (
                        <button
                          key={chip.id}
                          type="button"
                          title={chip.title}
                          onClick={() => handleChipClick(order, chip.macro)}
                          className={cn(
                            "flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium transition-all cursor-pointer whitespace-nowrap",
                            open === chip.macro && "ring-1 ring-primary/50",
                            chip.dot === "done" &&
                              "bg-green-50 text-green-700 border-green-200",
                            chip.dot === "active" &&
                              "bg-blue-50 text-blue-700 border-blue-200",
                            chip.dot === "pause" &&
                              "bg-amber-50 text-amber-700 border-amber-200",
                            chip.dot === "pending" &&
                              "bg-muted/40 text-muted-foreground border-border hover:border-primary/40"
                          )}
                        >
                          <span
                            className={cn(
                              "h-1.5 w-1.5 rounded-full shrink-0",
                              chip.dot === "done" && "bg-[var(--success)]",
                              chip.dot === "active" &&
                                "bg-[var(--info)] animate-pulse",
                              chip.dot === "pause" &&
                                "bg-amber-500 animate-pulse",
                              chip.dot === "pending" && "bg-muted-foreground/40"
                            )}
                          />
                          {STEP_SHORT_LABEL[chip.id] ?? chip.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {open === "po_intake" &&
                    (findInboundPo(order.orderId) ? (
                      <PoIntakePanel orderId={order.orderId} />
                    ) : (
                      <Card className="border-dashed">
                        <CardContent className="p-4 text-sm text-muted-foreground">
                          Entered directly by the sales team — no inbound purchase
                          order document.
                        </CardContent>
                      </Card>
                    ))}
                  {open === "po_understanding" && (
                    <div className="space-y-3">
                      <PricingValidationPanel
                        orderId={order.orderId}
                        totalValue={order.totalValue}
                        lines={order.lineItems}
                      />
                      <ShipToTermsCard orderId={order.orderId} />
                    </div>
                  )}
                  {open === "regulatory" && (
                    <RegulatoryPanel orderId={order.orderId} />
                  )}
                  {open === "fulfillment" && (
                    <div className="space-y-3">
                      <InventoryAllocationPanel
                        orderId={order.orderId}
                        autoApproved={
                    isTouchlessOrder(order.orderId) ||
                    isPricingHoldOrder(order.orderId)
                  }
                        lines={order.lineItems.map((l) => ({
                          sku: l.sku,
                          productName: l.productName,
                          qty: l.qty,
                        }))}
                      />
                      <FulfillmentEvidence
                        orderId={order.orderId}
                        customerName={order.customerName}
                        confirmed={
                          done || state?.stageStatuses?.confirmed === "passed"
                        }
                      />
                      {(!hasOrderEvidence(order.orderId) ||
                        findShipmentByOrder(order.orderId)) && (
                        <OrderShipmentCard orderId={order.orderId} />
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
              </Fragment>
            );
          })}
        </div>
      )}

      {confirmDialogOrder && (
        <CustomerConfirmationDialog
          orderId={confirmDialogOrder}
          customerName={
            pipelineOrders.find((o) => o.orderId === confirmDialogOrder)?.customerName ?? ""
          }
          onClose={() => {
            confirmResolverRef.current?.();
            confirmResolverRef.current = null;
          }}
        />
      )}
    </div>
  );
}

/** Detail view shown while an order runs through the pipeline. */
function OrderDetail({
  order,
  pipeline,
  awaiting,
  chips,
  invoice,
  podDone,
  onConfirmPod,
  onReleasePricingHold,
  auditLogRef,
  onBack,
  onEndRun,
  onRunComplete,
  chat,
  setChat,
  chatEndRef,
  sendChatMessage,
}: {
  order: Order;
  pipeline?: OrderPipelineState;
  awaiting?: boolean;
  chips: StageRailChip[];
  invoice?: Invoice;
  podDone: boolean;
  onConfirmPod: () => void;
  onReleasePricingHold: () => void;
  auditLogRef: React.RefObject<HTMLDivElement | null>;
  onBack: () => void;
  onEndRun: () => void;
  onRunComplete: () => void;
  chat: ChatState;
  setChat: React.Dispatch<React.SetStateAction<ChatState>>;
  chatEndRef: React.RefObject<HTMLDivElement | null>;
  sendChatMessage: () => void;
}) {
  const stageIds = chips.map((c) => c.id);
  // A stage is done when its rail chip is green. The run walks to the first
  // not-done stage and closes on POD.
  const isDone = (id: string) =>
    chips.find((c) => c.id === id)?.dot === "done";
  const activeIndex = stageIds.findIndex((id) => !isDone(id));
  const allDone = activeIndex === -1;
  const activeStage = allDone ? null : stageIds[activeIndex];
  // Only stages reached so far are shown; completed ones collapse to a line.
  const reachedIds = allDone ? stageIds : stageIds.slice(0, activeIndex + 1);

  // The open accordion row auto-follows the current stage; the human can click
  // a completed row to peek, and it re-syncs when the run advances.
  const [expandedStage, setExpandedStage] = useState<string | null>(activeStage);
  useEffect(() => {
    setExpandedStage(activeStage);
  }, [activeStage]);
  const [finaleDismissed, setFinaleDismissed] = useState(false);

  const activeCardRef = useRef<HTMLDivElement>(null);
  useFollowLatest(() => activeCardRef.current, activeStage);

  // When the last stage clears, record the run finished (once) so the pipeline
  // card reads 100% even after the run ends.
  const completedRef = useRef(false);
  useEffect(() => {
    if (allDone && !completedRef.current) {
      completedRef.current = true;
      onRunComplete();
    }
  }, [allDone, onRunComplete]);

  /** Wraps a step body in the AI's typed reasoning; `body` gets lines finished. */
  const reason = (
    id: string,
    lines: string[],
    body: (phase: number) => React.ReactNode,
    _variant?: string,
    cardSteps = 0
  ) => {
    const playKey = `${order.orderId}:${id}`;
    return (
      <AiStepReasoning
        key={playKey}
        stepKey={playKey}
        playKey={playKey}
        lines={lines}
        instant={isDone(id)}
        cardSteps={cardSteps}
      >
        {body}
      </AiStepReasoning>
    );
  };
  const inboundPo = findInboundPo(order.orderId);
  const lastPhase = (lines: string[]) => lines.length;

  /** The expanded detail for one stage of the run. */
  const renderStageBody = (id: string) => {
    switch (id) {
      case "capture": {
        const lines = inboundPo
          ? [
              `Picked up ${inboundPo.poNumber} from the ${inboundPo.channel} and planned the workflow.`,
              `Reading the document — ${inboundPo.lines.length} lines, ${inboundPo.paymentTerms}, delivery ${inboundPo.requestedDelivery}. Every field checks out against the master data.`,
            ]
          : [`No inbound PO document — ${order.orderId} was keyed in by the sales team.`];
        return reason(id, lines, (phase) => (
          <RevealWhen when={phase >= lastPhase(lines)}>
            {inboundPo ? (
              <PoIntakePanel orderId={order.orderId} revealed={phase - lines.length} />
            ) : (
              <Card className="border-dashed">
                <CardContent className="p-4 text-sm text-muted-foreground">
                  Entered directly by the sales team — no inbound purchase order
                  document.
                </CardContent>
              </Card>
            )}
          </RevealWhen>
        ), undefined, inboundPo ? inboundPo.extraction.length + 1 : 0);
      }
      case "validation": {
        const lines = [
          `Checking ${order.customerName} against customer master and looking for a duplicate sales order…`,
          "No duplicate found. Matching ship-to and payment terms to the agreement…",
          "Ship-to and terms match — validation passed.",
        ];
        return reason(id, lines, (phase) => (
          <div className="space-y-3">
            {pipeline?.understandingChecks && (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <AgentIcon type="validation" size="sm" /> Order checks
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {pipeline.understandingChecks.map((c) => (
                    <div
                      key={c.name}
                      className="flex items-center justify-between p-2 bg-muted/50 rounded text-sm"
                    >
                      <span>{c.name}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-muted-foreground">
                          {phase >= 1 ? c.detail : "Checking…"}
                        </span>
                        {phase >= 1 ? (
                          <CircleCheck className="h-4 w-4 text-[var(--success)] animate-enter-fade" />
                        ) : (
                          <Spinner size="sm" />
                        )}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}
            <RevealWhen when={phase >= lines.length}>
              <ShipToTermsCard orderId={order.orderId} revealed={phase - lines.length} />
            </RevealWhen>
          </div>
        ), undefined, SHIP_TO_ROW_COUNT + 1);
      }
      case "pricing": {
        if (!pipeline?.pricingHold && !pipeline?.pricingDetails) return null;
        const hold = pipeline.pricingHold;
        const lines = hold
          ? hold === "released"
            ? [
                "Comparing every PO line to the contract price agreement…",
                "Lines were above contract. Signed to bill at the contract price.",
                "Repricing the order to contract and moving on.",
              ]
            : [
                "Comparing every PO line to the contract price agreement…",
                "Found 4 lines above contract, a gap above the perfect-invoice tolerance.",
                "Recommending billing at contract price. Holding for the owner's signature.",
              ]
          : [
              "Pulling base price and applicable discount rules…",
              "Discounts applied, taxes computed — total reconciles to the PO.",
            ];
        return reason(id, lines, (phase) => (
          <RevealWhen when={phase >= lastPhase(lines)}>
          <div className="space-y-3">
            {pipeline.pricingHold && (
              <PricingHoldCard
                awaiting={!!awaiting}
                released={pipeline.pricingHold === "released"}
                onRelease={onReleasePricingHold}
              />
            )}
            {pipeline.pricingDetails && (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <AgentIcon type="pricing" size="sm" /> Pricing &amp;
                    commercial validation
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Base price</span>
                    <span className="font-medium">
                      ${pipeline.pricingDetails.basePrice.toLocaleString()}
                    </span>
                  </div>
                  {pipeline.pricingDetails.discounts.map((d, i) => (
                    <div key={i} className="flex justify-between">
                      <span className="text-[var(--success)]">
                        {d.type} ({d.rule})
                      </span>
                      <span className="text-[var(--success)]">
                        -${d.amount.toLocaleString()}
                      </span>
                    </div>
                  ))}
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Taxes</span>
                    <span className="font-medium">
                      ${pipeline.pricingDetails.taxes.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between pt-2 border-t font-semibold">
                    <span>Order total</span>
                    <span>${pipeline.pricingDetails.total.toLocaleString()}</span>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
          </RevealWhen>
        ), hold ?? undefined);
      }
      case "moq": {
        const lines = [
          `Checking ${order.lineItems.length} lines against the minimum order quantity for each SKU…`,
          "Every line clears its minimum — MOQ met.",
        ];
        return reason(id, lines, (phase) => (
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <AgentIcon type="moq" size="sm" /> Minimum order quantity
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {order.lineItems.map((l) => (
                <div
                  key={l.sku}
                  className="flex items-center justify-between gap-3 p-2 bg-muted/50 rounded text-sm"
                >
                  <span className="truncate">
                    <span className="font-mono text-xs text-muted-foreground">
                      {l.sku}
                    </span>{" "}
                    {l.productName}
                  </span>
                  <div className="flex shrink-0 items-center gap-2">
                    <span className="text-xs text-muted-foreground">
                      {l.qty.toLocaleString()} units
                    </span>
                    <StepNode
                      size="xs"
                      state={phase >= 2 && (pipeline?.moqMet || isDone("moq")) ? "done" : "active"}
                      label={phase >= 2 && pipeline?.moqMet ? "MOQ met" : "Checking MOQ"}
                    />
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        ));
      }
      case "credit": {
        if (!pipeline?.creditDetails) return null;
        const cd = pipeline.creditDetails;
        const lines = [
          `Pulling open exposure for ${order.customerName} against the $${cd.creditLimit.toLocaleString()} limit…`,
          `Exposure with this order is $${cd.creditExposure.toLocaleString()} — ${Math.round(cd.exposureRatio * 100)}% of limit.`,
          awaiting
            ? "That is over the limit — pausing for a credit approval."
            : `Decision: ${cd.decision}.`,
        ];
        return reason(id, lines, (phase) => (
          <RevealWhen when={phase >= 1}>
          <Card className={awaiting ? "border-primary/50 shadow-md" : ""}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <AgentIcon type="credit" size="sm" /> Credit evaluation
                {awaiting && (
                  <Badge className="ml-auto bg-primary text-primary-foreground text-xs">
                    Awaiting approval
                  </Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <div className="text-xs text-muted-foreground">Credit limit</div>
                  <div className="font-bold">
                    ${cd.creditLimit.toLocaleString()}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">Exposure</div>
                  <div className="font-bold">
                    ${cd.creditExposure.toLocaleString()}
                  </div>
                </div>
              </div>
              <AnimatedProgress
                progress={phase >= lines.length ? cd.exposureRatio * 100 : 0}
                label="Exposure ratio"
                color={cd.exposureRatio > 1 ? "warning" : "info"}
              />
              {phase >= lines.length + 2 && (<>
              <Badge
                className={
                  cd.decision === "Approved"
                    ? "bg-[var(--success)] text-white"
                    : "bg-primary text-primary-foreground"
                }
              >
                {cd.decision}
              </Badge>
              {cd.reason && (
                <p className="text-xs text-primary">{cd.reason}</p>
              )}
              {awaiting && (
                <div className="rounded-md bg-primary/5 border border-primary/20 p-3 text-xs text-primary">
                  Paused. Open the chat and type <strong>approve</strong> to
                  release this order.
                </div>
              )}
              </>)}
            </CardContent>
          </Card>
          </RevealWhen>
        ), awaiting ? "awaiting" : undefined, 3);
      }
      case "regulatory": {
        const lines = [
          "Screening each product for recalls, quality release, and ship-to restrictions…",
          "All product checks passed — clear to allocate.",
        ];
        return reason(id, lines, (phase) => (
          <RevealWhen when={phase >= lastPhase(lines)}>
            <RegulatoryPanel orderId={order.orderId} />
          </RevealWhen>
        ));
      }
      case "atp": {
        const lines = allocationReasoning(order.orderId) ?? [
          "Checking available-to-promise across the distribution network…",
          "Reserving inventory per the allocation rules.",
        ];
        return reason(id, lines, (phase) => (
          <RevealWhen when={phase >= lastPhase(lines)}>
          <div className="space-y-3">
            <InventoryAllocationPanel
              orderId={order.orderId}
              autoApproved={
                isTouchlessOrder(order.orderId) || isPricingHoldOrder(order.orderId)
              }
              lines={order.lineItems.map((l) => ({
                sku: l.sku,
                productName: l.productName,
                qty: l.qty,
              }))}
            />
            {hasOrderEvidence(order.orderId) && (
              <AllocationLogicCard orderId={order.orderId} />
            )}
          </div>
          </RevealWhen>
        ));
      }
      case "shipment_plan": {
        const lines = shipmentPlanReasoning(order.orderId) ?? [
          "Reading route, load and carrier from the TMS plan…",
          "Tender accepted; expected delivery confirmed.",
        ];
        return reason(
          id,
          lines,
          (phase) => <ShipmentPlanPanel orderId={order.orderId} phase={phase} />,
          undefined,
          5
        );
      }
      case "appointment": {
        const lines = appointmentReasoning(order.orderId) ?? [
          "Reading the expected delivery from the TMS plan…",
          "Booking the receiving slot inside the OTIF window.",
        ];
        return reason(
          id,
          lines,
          (phase) => <AppointmentStagePanel orderId={order.orderId} phase={phase} />,
          undefined,
          6
        );
      }
      case "delivery": {
        const lines = deliveryReasoning(order.orderId) ?? [
          "Following the load from the DC to the customer…",
          "Delivered and POD signed; unlocking billing.",
        ];
        return reason(
          id,
          lines,
          (phase) => <DeliveryStagePanel orderId={order.orderId} phase={phase} />,
          undefined,
          7
        );
      }
      case "confirmed": {
        const lines = [
          `Drafting the order confirmation to ${order.customerName} with lines, total, and the delivery appointment…`,
          "Draft is ready — logging the status history and handing off to shipment tracking.",
        ];
        return reason(id, lines, (phase) =>
          hasOrderEvidence(order.orderId) ? (
            <div className="space-y-3">
              <RevealWhen when={phase >= 1}>
                <CustomerConfirmationRow
                  orderId={order.orderId}
                  customerName={order.customerName}
                />
              </RevealWhen>
              <RevealWhen when={phase >= 2}>
                <div className="space-y-3">
                  <OrderStatusTimeline orderId={order.orderId} />
                  {findShipmentByOrder(order.orderId) && (
                    <OrderShipmentCard orderId={order.orderId} />
                  )}
                </div>
              </RevealWhen>
            </div>
          ) : (
            <RevealWhen when={phase >= lastPhase(lines)}>
              <Card className="border-dashed">
                <CardContent className="p-4 text-sm text-muted-foreground">
                  Order and appointment confirmed to {order.customerName}.
                </CardContent>
              </Card>
            </RevealWhen>
          )
        );
      }
      case "pod":
        return (
          <div className="space-y-3">
            {!podDone && (
              <div className="rounded-md border border-amber-200 bg-amber-50 p-3 text-xs text-amber-800">
                The carrier&apos;s proof-of-delivery email just arrived — read
                it, open the signed document, then confirm the delivery below.
              </div>
            )}
            <PodStagePanel
              order={order}
              confirmed={podDone}
              onConfirm={onConfirmPod}
            />
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-4" data-stage-count={SIM_STAGES.length}>
      <div className="flex items-center justify-between">
        <Button variant="outline" size="sm" onClick={onBack} className="gap-1.5">
          <ChevronLeft className="h-4 w-4" /> Back to Pipeline
        </Button>
        <div className="flex items-center gap-3">
          <span className="font-semibold text-base">{order.orderId}</span>
          <span className="text-sm text-muted-foreground">
            {order.customerName} · ${order.totalValue.toLocaleString()}
          </span>
          <OwnerChip account={order.customerName} />
          <Badge
            variant="outline"
            className={cn(
              "text-xs",
              allDone && "border-[var(--success)] text-[var(--success)]"
            )}
          >
            {allDone
              ? "Complete"
              : chips.find((c) => c.id === activeStage)?.label}
          </Badge>
        </div>
      </div>

      <Card>
        <CardContent className="p-4">
          <StageRail
            chips={chips}
            openStageId={expandedStage ?? ""}
            onChipClick={(id) => {
              if (reachedIds.includes(id)) setExpandedStage(id);
            }}
          />
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-2">
          {reachedIds.map((id) => {
            const chip = chips.find((c) => c.id === id);
            const label = chip?.label ?? id;
            const done = isDone(id);
            const active = id === activeStage;
            const expanded = expandedStage === id;
            return (
              <Card
                key={id}
                ref={active ? activeCardRef : undefined}
                className="overflow-hidden py-0 gap-0 animate-enter"
              >
                <button
                  type="button"
                  aria-expanded={expanded}
                  onClick={() =>
                    setExpandedStage((prev) => (prev === id ? null : id))
                  }
                  className={cn(
                    "flex w-full items-center gap-2.5 px-4 text-left cursor-pointer",
                    expanded ? "py-2.5" : "py-1"
                  )}
                >
                  <StepNode
                    size={expanded ? "sm" : "xs"}
                    state={
                      done
                        ? "done"
                        : awaiting || chip?.dot === "pause"
                          ? "pause"
                          : "active"
                    }
                  />
                  <span className="text-sm font-semibold text-foreground shrink-0">
                    {label}
                  </span>
                  {!expanded && (
                    <span className="truncate text-xs text-muted-foreground">
                      {done
                        ? stepSummaryFor(order.orderId, id)
                        : active
                          ? "In progress"
                          : ""}
                    </span>
                  )}
                  {active && !done && (
                    <Badge
                      variant="outline"
                      className="ml-auto shrink-0 border-[var(--info)]/40 bg-[var(--info)]/5 text-[var(--info)] text-xs"
                    >
                      Current step
                    </Badge>
                  )}
                  <ChevronDown
                    className={cn(
                      "h-4 w-4 shrink-0 text-muted-foreground transition-transform",
                      active && !done ? "" : "ml-auto",
                      expanded && "rotate-180"
                    )}
                  />
                </button>
                {/* The running step stays mounted while collapsed so its animation keeps playing. */}
                {(expanded || (active && !done)) && (
                  <div className={cn("border-t px-4 py-4", !expanded && "hidden")}>
                    {renderStageBody(id) ?? (
                      <p className="text-xs text-muted-foreground">
                        Agent is working on this step…
                      </p>
                    )}
                  </div>
                )}
              </Card>
            );
          })}
        </div>

        <div>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">AI Agent Audit Trail</CardTitle>
              <CardDescription className="text-xs">
                Real-time agent reasoning log
              </CardDescription>
            </CardHeader>
            <CardContent className="p-3">
              <div ref={auditLogRef} className="max-h-[600px] overflow-y-auto space-y-3">
                {(pipeline?.agentLogs.length ?? 0) === 0 && (
                  <p className="text-xs text-muted-foreground italic">
                    Waiting for processing to begin...
                  </p>
                )}
                {pipeline?.agentLogs.map((log) => (
                  <div key={log.id} className="flex gap-2 text-xs">
                    <div className="flex-shrink-0 mt-0.5">
                      <AgentIcon type={log.agentType} size="sm" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="font-medium text-foreground">{log.agent}</span>
                        <span className="text-muted-foreground">
                          {new Date(log.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                      <div
                        className={
                          log.status === "success"
                            ? "text-[var(--success)] mt-0.5"
                            : log.status === "warning"
                              ? "text-amber-600 mt-0.5"
                              : "text-muted-foreground mt-0.5"
                        }
                      >
                        {log.message}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {allDone && !finaleDismissed && (
        <RunCompleteModal
          order={order}
          stageCount={stageIds.length}
          onBackToPipeline={onEndRun}
          onStay={() => setFinaleDismissed(true)}
        />
      )}

      <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-2">
        {chat.open && (
          <div
            className="w-80 rounded-xl shadow-2xl border border-border bg-background flex flex-col overflow-hidden"
            style={{ height: "420px" }}
          >
            <div className="flex items-center justify-between px-4 py-3 bg-primary text-primary-foreground">
              <span className="text-sm font-semibold">Order Agent</span>
              <button
                onClick={() => setChat((prev) => ({ ...prev, open: false }))}
                className="opacity-70 hover:opacity-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-3 space-y-2">
              {chat.messages.length === 0 && (
                <p className="text-xs text-muted-foreground italic text-center mt-4">
                  Ask about the order or type &apos;approve&apos; to release a hold.
                </p>
              )}
              {chat.messages.map((message, index) => (
                <div
                  key={index}
                  className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[85%] rounded-lg px-3 py-2 text-xs ${
                      message.role === "user"
                        ? "bg-primary text-primary-foreground"
                        : message.isApproval
                          ? "bg-green-50 border border-green-200 text-green-800"
                          : "bg-muted text-foreground"
                    }`}
                  >
                    {message.isApproval && (
                      <ThumbsUp className="h-3 w-3 inline mr-1 text-green-600" />
                    )}
                    {message.text}
                  </div>
                </div>
              ))}
              <div ref={chatEndRef} />
            </div>
            <div className="flex items-center gap-2 px-3 py-2 border-t">
              <Input
                value={chat.input}
                onChange={(e) => setChat((prev) => ({ ...prev, input: e.target.value }))}
                onKeyDown={(e) => {
                  if (e.key === "Enter") sendChatMessage();
                }}
                placeholder="Type 'approve' to release a hold..."
                className="h-7 text-xs flex-1 bg-muted/40 border-muted"
              />
              <Button
                size="sm"
                variant="ghost"
                onClick={sendChatMessage}
                className="h-7 w-7 p-0 text-muted-foreground hover:text-foreground"
              >
                <Send className="h-3 w-3" />
              </Button>
            </div>
          </div>
        )}
        <button
          onClick={() => setChat((prev) => ({ ...prev, open: !prev.open }))}
          className="h-11 w-11 rounded-full bg-primary text-primary-foreground shadow-lg flex items-center justify-center hover:bg-primary/90 transition-all"
        >
          {chat.open ? <X className="h-5 w-5" /> : <MessageCircle className="h-5 w-5" />}
        </button>
      </div>
    </div>
  );
}
