"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ArrowLeft, ArrowRight, Banknote, ChevronDown, CircleCheck, Landmark, ListFilter, Mail, Route, Scale, ThumbsUp, User } from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import { Spinner } from "@/components/agents/spinner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { claimLineMath, formatUnitPrice, formatUsd } from "@/lib/chargeback-selectors";
import { PROGRAMME_SCOPE } from "@/lib/data/gross-to-net";
import { settledChannelDeductions } from "@/lib/data/channel-deductions";
import { shortPaySplit } from "@/lib/short-pay-selectors";
import { promoClaimSplit } from "@/lib/promo-claim-selectors";
import { dupClaimAssessment } from "@/lib/dup-claim-selectors";
import { rebateClaimAssessment } from "@/lib/rebate-claim-selectors";
import { fundClaimAssessment } from "@/lib/fund-claim-selectors";
import { ShortPayRun } from "@/components/views/short-pay-run";
import { MultiCauseDeductionRun } from "@/components/views/multi-cause-deduction-run";
import {
  MULTI_CAUSE_DEDUCTION,
  multiCauseApplied,
} from "@/lib/data/multi-cause-deduction";
import { cashPayments } from "@/lib/data/cash-application";
import { PromoClaimRun } from "@/components/views/promo-claim-run";
import { DupClaimRun } from "@/components/views/dup-claim-run";
import { RebateClaimRun } from "@/components/views/rebate-claim-run";
import { FundClaimRun } from "@/components/views/fund-claim-run";
import { promoClaimCases } from "@/lib/data/promo-claims";
import { dupClaimCases } from "@/lib/data/dup-claims";
import { rebateClaimCases } from "@/lib/data/rebate-claims";
import { fundClaimCases } from "@/lib/data/fund-claims";
import {
  claimRecoilLink,
  classificationTrail,
  deductionAccounting,
  renderDisputeLetter,
  recoveryOptions,
  shortPayPosition,
} from "@/lib/deduction-selectors";
import {
  buildChargebackClaimDoc,
  buildContractPriceListDoc,
  buildDisputeLetterDoc,
  buildRemittanceAdviceDoc,
} from "@/lib/docs-chargebacks";
import type { DeductionCase } from "@/lib/data/deductions";
import { useOtcStore } from "@/lib/store";
import { ControlTag, ControlTags } from "@/components/shared/control-tag";
import { OwnerChip } from "@/components/shared/owner-chip";
import { SystemBadge } from "@/components/shared/system-badge";
import { DeductionLaneTabs, LaneSummary } from "@/components/views/deductions/lane-summary";
import { SplitOutList, type SplitOutRow } from "@/components/mounts/non-trade/split-out-list";
import { NonTradeBatchRun } from "@/components/views/non-trade-batch-run";
import { findAccount } from "@/lib/data/account-owners";
import { NON_TRADE_BATCH, SPLIT_OUT_CLAIMS } from "@/lib/data/non-trade-batch";
import { batchTotals } from "@/lib/non-trade-selectors";
import { cn } from "@/lib/utils";

import {
  AiStageNarration,
  narrationDwellMs,
} from "@/components/mounts/chargebacks/ai-stage-narration";
import {
  AgentAuditTrail,
  RunStageRow,
  RUN_STAGE_BODY_CLASS,
  RUN_STAGE_CARD_CLASS,
} from "@/components/mounts/shared/run-stage-row";
import { StageProgressRail } from "@/components/mounts/shared/stage-progress-rail";
import { RunCompleteModal } from "@/components/mounts/shared/run-complete-modal";
import {
  ChargebackRecoilTrace,
  PaymentShortfallBar,
  ReasonCodeFunnel,
  RecoveryLadder,
} from "@/components/mounts/deductions/deduction-visuals";
import { DisputeLetterComposer } from "@/components/mounts/deductions/dispute-letter-composer";
import { GtnImpactPanel } from "@/components/mounts/deductions/gtn-impact-panel";
import {
  ClassificationConfirmModal,
  RecoveryImpactModal,
} from "@/components/mounts/deductions/confirm-modals";

type SimStatus = "waiting" | "running" | "passed" | "needsReview";

const STAGES = [
  {
    id: "intake",
    label: "Short payment",
    heading: "Payment against invoice",
    agent: "Cash Matching Agent",
    agentType: "orchestrator",
    icon: Banknote,
    log: "Payment matched to the invoice. The remittance is short.",
  },
  {
    id: "classify",
    label: "Classification",
    heading: "Deduction classification",
    agent: "Deduction Classification Agent",
    agentType: "validation",
    icon: ListFilter,
    log: "Three candidate reasons ruled out. One is supported by the evidence.",
  },
  {
    id: "root_cause",
    label: "Root cause",
    heading: "Source of the deduction",
    agent: "Root Cause Agent",
    agentType: "document",
    icon: Route,
    log: "Traced to the rejected chargeback claim.",
  },
  {
    id: "recover",
    label: "Recovery",
    heading: "Recovery options",
    agent: "Recovery Agent",
    agentType: "credit",
    icon: Scale,
    log: "Options ranked. Awaiting a decision.",
  },
  {
    id: "letter",
    label: "Dispute letter",
    heading: "Dispute correspondence",
    agent: "Correspondence Agent",
    agentType: "invoice",
    icon: Mail,
    log: "Letter drafted from the rejection evidence. Not yet issued.",
  },
  {
    id: "outcome",
    label: "Impact",
    heading: "Gross-to-net and accounting impact",
    agent: "Revenue Accounting Agent",
    agentType: "invoice",
    icon: Landmark,
    log: "None of the deduction is a gross-to-net cost.",
  },
] as const;

interface AgentLog {
  id: string;
  agent: string;
  agentType: string;
  message: string;
  tone: "info" | "attention" | "success";
}

/** Floor for the automatic steps after a gate, so they are still readable. */
const STAGE_DWELL_MS = 4000;

/** The assessment as one string, so the dwell can be sized to its length. */
const asText = (n: string | string[] | undefined) =>
  Array.isArray(n) ? n.join("\n") : (n ?? "");

/**
 * One short line per stage, in the same register as the chargeback run: name
 * the subject, state what the step found, stop. The previous lines ran to
 * paragraphs and made a reviewer read for the finding instead of seeing it.
 */
function buildNarration(
  deduction: DeductionCase,
  math: NonNullable<ReturnType<typeof claimLineMath>>,
  position: ReturnType<typeof shortPayPosition>,
  link: NonNullable<ReturnType<typeof claimRecoilLink>>
): Record<string, string | string[]> {
  const who = deduction.customerName;
  const amount = formatUsd(deduction.amount);

  return {
    intake: `${who} withheld ${amount} on invoice ${deduction.invoiceId}. The remittance advice carries no claim reference.`,
    classify: [
      `Freight damage, promotion allowance, pricing and shortage were each tested and ruled out.`,
      `Unauthorised chargeback, ${Math.round(deduction.reasonConfidence * 100)}% confidence. Your confirmation is required.`,
    ],
    root_cause: `${amount} matches the amount rejected on claim ${deduction.linkedClaimId} to the dollar, taken ${link.daysToDeduction} days later.`,
    recover: `AI recommends to request repayment of ${amount} in full.`,
    letter: `Dispute letter ${deduction.disputeLetter?.letterRef ?? ""} drafted, with ${deduction.disputeLetter?.attachments.length ?? 0} documents attached. Approval required before it is sent.`,
    outcome: `None of the ${amount} is a gross-to-net cost. It remains collectible in full.`,
  };
}

export function DeductionsView({
  onNavigateToCashApplication,
}: {
  /**
   * The seven Scenario 6 deduction cases are opened from the Cash
   * Application workbench, not from a run inside this module. Without this,
   * a viewer who lands here after that demo finds no trace of them — the
   * case record exists but only in the other module. Clicking that row
   * jumps back to Cash Application instead of trying to open a local run.
   */
  onNavigateToCashApplication?: () => void;
}) {
  const { pendingCaseId, consumePendingCase, channelDeductionCases } = useOtcStore();
  const runnable = (id: string | null): id is string =>
    !!id &&
    (id === NON_TRADE_BATCH.batchId ||
      id === "DED-SP-002" ||
      id === MULTI_CAUSE_DEDUCTION.caseId ||
      [...promoClaimCases, ...dupClaimCases, ...rebateClaimCases, ...fundClaimCases].some((c) => c.caseId === id) ||
      channelDeductionCases.some((d) => d.deductionId === id));
  const [openCaseId, setOpenCaseId] = useState<string | null>(() =>
    runnable(pendingCaseId) ? pendingCaseId : null
  );
  useEffect(() => {
    if (!runnable(pendingCaseId)) return;
    setOpenCaseId(pendingCaseId);
    consumePendingCase();
    // runnable only reads static case lists and the store's channel cases
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pendingCaseId, consumePendingCase]);

  if (openCaseId === NON_TRADE_BATCH.batchId) {
    return <NonTradeBatchRun onBack={() => setOpenCaseId(null)} />;
  }

  // The runs. The promotion-claim ones match a deduction to a promotion and
  // split it store by store; the short-pay one splits a part-valid deduction;
  // the chargeback-linked one traces a deduction back to a rejected claim.
  if (openCaseId && promoClaimCases.some((c) => c.caseId === openCaseId)) {
    return (
      <PromoClaimRun caseId={openCaseId} onBack={() => setOpenCaseId(null)} />
    );
  }
  if (openCaseId && dupClaimCases.some((c) => c.caseId === openCaseId)) {
    return (
      <DupClaimRun caseId={openCaseId} onBack={() => setOpenCaseId(null)} />
    );
  }
  if (openCaseId && rebateClaimCases.some((c) => c.caseId === openCaseId)) {
    return (
      <RebateClaimRun caseId={openCaseId} onBack={() => setOpenCaseId(null)} />
    );
  }
  if (openCaseId && fundClaimCases.some((c) => c.caseId === openCaseId)) {
    return (
      <FundClaimRun caseId={openCaseId} onBack={() => setOpenCaseId(null)} />
    );
  }
  if (openCaseId === "DED-SP-002") {
    return <ShortPayRun caseId={openCaseId} onBack={() => setOpenCaseId(null)} />;
  }
  if (openCaseId === MULTI_CAUSE_DEDUCTION.caseId) {
    return <MultiCauseDeductionRun onBack={() => setOpenCaseId(null)} />;
  }
  return openCaseId ? (
    <DeductionRun onBack={() => setOpenCaseId(null)} />
  ) : (
    <DeductionQueue
      onOpen={setOpenCaseId}
      onNavigateToCashApplication={onNavigateToCashApplication}
    />
  );
}

/* ---------------------------------------------------------------- *
 * Overview
 * ---------------------------------------------------------------- */

function DeductionQueue({
  onOpen,
  onNavigateToCashApplication,
}: {
  onOpen: (id: string) => void;
  onNavigateToCashApplication?: () => void;
}) {
  const {
    channelDeductionCases,
    resolvedShortPays,
    resolvedPromoClaims,
    resolvedDupClaims,
    resolvedRebateClaims,
    resolvedFundClaims,
    resolvedMultiCauseDeductions,
    openedCashDeductionCases,
    deductionLane,
    setDeductionLane,
    nonTradeBatchPosted,
    resolvedSplitOuts,
  } = useOtcStore();

  const sp = shortPaySplit("DED-SP-002");

  // The new scenarios lead the queue, in order. Each renders from its split
  // so the amounts on the card match the run behind it.
  const promoRows = promoClaimCases.flatMap((pc) => {
    const split = promoClaimSplit(pc.caseId);
    if (!split) return [];
    const done = resolvedPromoClaims.includes(pc.caseId);
    return [
      {
        id: pc.caseId,
        customer: pc.customerName,
        invoice: pc.invoiceId,
        amount: split.claimed,
        reason: "Incomplete proof of promotion",
        status: done ? "Resolved" : "Open",
        outcome: done
          ? `Approved ${formatUsd(split.supported)}, billing back ${formatUsd(split.billBack)}`
          : "Awaiting investigation",
        owner: pc.routedTo,
        closedOn: null as string | null,
        open: !done,
        finding: done
          ? `${formatUsd(split.claimed)} withheld on invoice ${pc.invoiceId}. ${formatUsd(split.supported)} supported, ${formatUsd(split.billBack)} billed back.`
          : `${formatUsd(split.claimed)} withheld on invoice ${pc.invoiceId} as a feature-and-display allowance. Store, date and SKU eligibility not yet established.`,
      },
    ];
  });

  // Scenario 2 rows, second in the queue. Each renders from its assessment so
  // the card amount matches the run behind it.
  const dupRows = dupClaimCases.flatMap((dc) => {
    const a = dupClaimAssessment(dc.caseId);
    if (!a) return [];
    const done = resolvedDupClaims.includes(dc.caseId);
    return [
      {
        id: dc.caseId,
        customer: dc.customerName,
        invoice: dc.invoiceId,
        amount: a.claimed,
        reason: "Duplicate / resubmitted claim",
        status: done ? "Resolved" : "Open",
        outcome: done
          ? `Rejected ${formatUsd(a.duplicateValue)} as duplicate`
          : "Awaiting investigation",
        owner: dc.routedTo,
        closedOn: null as string | null,
        open: !done,
        finding: done
          ? `${formatUsd(a.claimed)} re-deducted on invoice ${dc.invoiceId}. Matched to ${dc.originalClaimRef} at ${Math.round(a.duplicateConfidence * 100)}% and rejected in full.`
          : `${formatUsd(a.claimed)} re-deducted on invoice ${dc.invoiceId} under a new reference ${dc.resubmittedClaimRef}. Possible duplicate of a settled event — not yet confirmed.`,
      },
    ];
  });

  // Scenario 3 rows, third in the queue. Each renders from its assessment so
  // the card amount matches the run behind it.
  const rebateRows = rebateClaimCases.flatMap((rc) => {
    const a = rebateClaimAssessment(rc.caseId);
    if (!a) return [];
    const done = resolvedRebateClaims.includes(rc.caseId);
    return [
      {
        id: rc.caseId,
        customer: rc.customerName,
        invoice: rc.invoiceId,
        amount: a.claimed,
        reason: "Incorrect growth rebate calculation",
        status: done ? "Resolved" : "Open",
        outcome: done
          ? `Validated ${formatUsd(a.validated)}, disputing ${formatUsd(a.unsupported)}`
          : "Awaiting investigation",
        owner: rc.routedTo,
        closedOn: null as string | null,
        open: !done,
        finding: done
          ? `${formatUsd(a.claimed)} withheld on invoice ${rc.invoiceId}. Re-run on the amended agreement: validated ${formatUsd(a.validated)} at ${a.attainedTier.ratePct}%, ${formatUsd(a.unsupported)} unsupported.`
          : `${formatUsd(a.claimed)} withheld on invoice ${rc.invoiceId} for a ${a.claimedTierPct}% growth rebate on gross sales. Contract basis, entity and product eligibility not yet established.`,
      },
    ];
  });

  // Scenario 4 rows, fourth in the queue. A valid claim that must be split
  // across two funds — the card renders from its assessment.
  const fundRows = fundClaimCases.flatMap((fc) => {
    const a = fundClaimAssessment(fc.caseId);
    if (!a) return [];
    const done = resolvedFundClaims.includes(fc.caseId);
    return [
      {
        id: fc.caseId,
        customer: fc.customerName,
        invoice: fc.invoiceId,
        amount: a.claimed,
        reason: "Fund allocation / accrual shortfall",
        status: done ? "Resolved" : "Open",
        outcome: done
          ? `Approved ${formatUsd(a.claimed)}, split ${formatUsd(a.referencedAllocated)} + ${formatUsd(a.overflow)}`
          : "Awaiting allocation",
        owner: fc.routedTo,
        closedOn: null as string | null,
        open: !done,
        finding: done
          ? `${formatUsd(a.claimed)} withheld on invoice ${fc.invoiceId}. Valid promotion split across two funds — ${formatUsd(a.referencedAllocated)} to the referenced fund, ${formatUsd(a.overflow)} to a second eligible fund.`
          : `${formatUsd(a.claimed)} withheld on invoice ${fc.invoiceId} for a valid promotion. The referenced fund holds only ${formatUsd(a.referencedAvailable)}; allocation across funds not yet settled.`,
      },
    ];
  });

  // Scenario 9 leads the queue: one short payment that decomposes into an
  // existing credit, a promotion allowance and a freight claim.
  const mc = MULTI_CAUSE_DEDUCTION;
  const mcCredit = mc.causes[0].amount;
  const mcDone = resolvedMultiCauseDeductions.includes(mc.caseId);
  const multiCauseRow = {
    id: mc.caseId,
    customer: mc.customerName,
    invoice: mc.remittanceRef,
    amount: mc.shortPay,
    reason: "Short payment, three root causes",
    status: mcDone ? "Resolved" : "Open",
    outcome: mcDone
      ? `Applied ${formatUsd(multiCauseApplied(mc))}, routed 2 cases`
      : "Awaiting investigation",
    owner: "Cash Application · Trade · Logistics",
    closedOn: null as string | null,
    open: !mcDone,
    finding: mcDone
      ? `${formatUsd(mc.shortPay)} short on ${formatUsd(
          mc.invoicesOpen
        )} of open invoices. ${formatUsd(
          multiCauseApplied(mc)
        )} applied (cash + existing credit ${formatUsd(
          mcCredit
        )}); promotion ${formatUsd(
          mc.causes[1].amount
        )} and freight ${formatUsd(
          mc.causes[2].amount
        )} routed to trade and logistics.`
      : `${formatUsd(mc.shortPay)} short on ${formatUsd(
          mc.invoicesOpen
        )} of open invoices. Splits into an existing credit ${formatUsd(
          mcCredit
        )}, a promotion allowance ${formatUsd(
          mc.causes[1].amount
        )} and a freight claim ${formatUsd(
          mc.causes[2].amount
        )} — ${formatUsd(multiCauseApplied(mc))} applies now.`,
  };

  // Scenario 6: the seven deduction lines a remittance decomposed into in
  // Cash Application. Those cases are opened from that workbench, not from a
  // run in this module — without a row here, the audit trail looks broken
  // once a viewer checks the Deductions queue for them. Clicking the row
  // while it's still open jumps back to Cash Application to open the cases;
  // once every case is opened it reads like every other resolved row here.
  const cashDeductionPayment = cashPayments.find(
    (p) => p.paymentId === "PAY-32001"
  );
  const cashDeductionLines =
    cashDeductionPayment?.lines.filter((l) => l.type === "deduction") ?? [];
  const cashDeductionTotal = cashDeductionLines.reduce(
    (s, l) => s + l.amount,
    0
  );
  const cashDeductionAllOpened =
    cashDeductionLines.length > 0 &&
    cashDeductionLines.every((l) =>
      openedCashDeductionCases.includes(l.lineId)
    );
  const cashDeductionTeams = Array.from(
    new Set(cashDeductionLines.map((l) => l.routeTeam).filter(Boolean))
  ) as string[];
  const cashDeductionRow =
    cashDeductionPayment && cashDeductionLines.length > 0
      ? {
          id: `CASE-${cashDeductionPayment.paymentId}`,
          customer: cashDeductionPayment.customer,
          invoice: cashDeductionPayment.paymentId,
          amount: cashDeductionTotal,
          reason: "Remittance short pay, seven reason codes",
          status: cashDeductionAllOpened ? "Cases opened" : "Open",
          outcome: cashDeductionAllOpened
            ? `${cashDeductionLines.length} cases opened, ${formatUsd(cashDeductionTotal)} routed`
            : "Identified in Cash Application",
          owner: cashDeductionTeams.join(" · "),
          closedOn: null as string | null,
          open: !cashDeductionAllOpened,
          navigateToCashApplication: true,
          finding: cashDeductionAllOpened
            ? `${formatUsd(cashDeductionTotal)} short on remittance ${cashDeductionPayment.paymentId}, split across ${cashDeductionLines.length} reason codes. Each line opened as a tracked case with its evidence attached and an SLA clock, routed to ${cashDeductionTeams.join(", ")} — nothing written off.`
            : `${formatUsd(cashDeductionTotal)} short on remittance ${cashDeductionPayment.paymentId}, split across ${cashDeductionLines.length} reason codes. Identified while applying the payment in Cash Application — not yet opened as cases.`,
        }
      : null;

  // Trade claims are investigated one by one and ranked by value.
  const tradeRows = [
    ...promoRows.map((r) => ({ ...r, control: "1.7.3" })),
    ...dupRows.map((r) => ({ ...r, control: "1.7.5" })),
    ...rebateRows.map((r) => ({ ...r, control: "1.7.4" })),
    ...fundRows.map((r) => ({ ...r, control: "1.7.2" })),
  ].sort((a, b) => b.amount - a.amount);

  // Non-trade cases that need a full run sit beside the batch exceptions.
  const channelCase = channelDeductionCases[0];
  const splitRunRows: SplitOutRow[] = [
    ...(sp
      ? [
          {
            id: sp.case.caseId,
            accountId: findAccount(sp.case.customerName)?.accountId ?? "",
            customer: findAccount(sp.case.customerName)?.shortName ?? sp.case.customerName,
            category: "run" as const,
            title: "Short pay against chargebacks",
            amount: sp.shortPay,
            status: resolvedShortPays.includes(sp.case.caseId) ? "Resolved" : "Open",
            runCase: true,
            traceNote: resolvedShortPays.includes(sp.case.caseId)
              ? `Accepted ${formatUsd(sp.acceptAmount)}, recovering ${formatUsd(sp.recoverAmount)}`
              : `${formatUsd(sp.shortPay)} withheld on invoice ${sp.case.invoiceId}`,
          },
        ]
      : []),
    {
      id: multiCauseRow.id,
      accountId: findAccount(multiCauseRow.customer)?.accountId ?? "",
      customer: findAccount(multiCauseRow.customer)?.shortName ?? multiCauseRow.customer,
      category: "run" as const,
      title: multiCauseRow.reason,
      amount: multiCauseRow.amount,
      status: multiCauseRow.open ? "Open" : "Resolved",
      runCase: true,
      traceNote: "1 trade line routed to the Trade lane",
    },
    ...(channelCase
      ? [
          {
            id: channelCase.deductionId,
            accountId: findAccount(channelCase.customerName)?.accountId ?? "",
            customer: findAccount(channelCase.customerName)?.shortName ?? channelCase.customerName,
            category: "run" as const,
            title: channelCase.reasonCode,
            amount: channelCase.amount,
            status: channelCase.status === "Resolved" ? "Resolved" : "Open",
            runCase: true,
            traceNote: "Traced to a rejected chargeback claim",
          },
        ]
      : []),
  ];
  const splitRows: SplitOutRow[] = [
    ...(nonTradeBatchPosted
      ? SPLIT_OUT_CLAIMS.map((c) => ({
          id: c.id,
          accountId: c.accountId,
          customer: c.customer,
          category: c.category,
          title: c.title,
          amount: c.usd,
          ageDays: c.ageDays,
          status: resolvedSplitOuts[c.id]
            ? resolvedSplitOuts[c.id] === "credit"
              ? "Credited"
              : "Charged back"
            : "Open",
        }))
      : []),
    ...splitRunRows,
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold">Short pays and deductions</h2>
        <p className="text-sm text-muted-foreground">
          Where a customer remits less than the invoiced amount, the cause is
          established, traced to its source and answered in writing. Every
          recovery action and every outgoing letter is approved by a person.
        </p>
        <p className="mt-1 text-xs text-muted-foreground">{PROGRAMME_SCOPE}</p>
      </div>

      <LaneSummary
        lane={deductionLane}
        onSelect={setDeductionLane}
        tradeItems={tradeRows.map((r) => ({ id: r.id, label: r.reason, amount: r.amount }))}
      />

      <DeductionLaneTabs
        lane={deductionLane}
        onSelect={setDeductionLane}
        tradeCount={tradeRows.length}
        nonTradeLabel={`${batchTotals.total.count} + ${splitRunRows.length}`}
      />

      {deductionLane === "non-trade" ? (
        <div key="non-trade" className="animate-enter flex flex-col gap-4">
          <NonTradeBatchCard posted={nonTradeBatchPosted} onOpen={() => onOpen(NON_TRADE_BATCH.batchId)} />
          <SplitOutList rows={splitRows} onOpenCase={onOpen} />
        </div>
      ) : (
      /* Laid out like the Exceptions page: one card per case, icon then
          title with its badges, the finding, and the references underneath. */
      <div key="trade" className="space-y-3">
          {tradeRows.map((r) => (
          <Card
            data-deduction-class="trade"
            key={r.id}
            className={cn(
              "transition-all",
              r.open
                ? "cursor-pointer hover:shadow-md"
                : "bg-[var(--success)]/5 opacity-75"
            )}
            onClick={
              r.open
                ? "navigateToCashApplication" in r && r.navigateToCashApplication
                  ? () => onNavigateToCashApplication?.()
                  : () => onOpen(r.id)
                : undefined
            }
          >
            <CardContent className="p-4">
              <div className="flex items-start gap-4">
                <div
                  className={cn(
                    "flex h-10 w-10 shrink-0 items-center justify-center rounded-lg",
                    r.open
                      ? "bg-primary/10 text-primary"
                      : "bg-[var(--success)]/10 text-[var(--success)]"
                  )}
                >
                  {r.open ? (
                    <AgentIcon type="validation" size="sm" />
                  ) : (
                    <CircleCheck className="h-5 w-5" />
                  )}
                </div>

                <div className="min-w-0 flex-1">
                  <div className="mb-1 flex flex-wrap items-center gap-2">
                    <span className="font-semibold text-foreground">
                      {r.reason}
                    </span>
                    {r.open && (
                      <Badge className="whitespace-nowrap bg-primary/10 text-primary">
                        {formatUsd(r.amount)}
                      </Badge>
                    )}
                    <Badge
                      variant="outline"
                      className={cn(
                        "whitespace-nowrap",
                        r.open
                          ? "border-amber-300 bg-amber-50 text-amber-800"
                          : "bg-[var(--success)]/10 text-[var(--success)]"
                      )}
                    >
                      {r.open ? "Open" : r.outcome}
                    </Badge>
                  </div>

                  <p className="mb-2 text-sm text-muted-foreground">
                    {r.finding}
                  </p>

                  <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                    <span className="font-mono">{r.id}</span>
                    <span>{r.customer}</span>
                    <OwnerChip account={r.customer} variant="compact" />
                    <ControlTag controlRef={r.control} />
                  </div>
                </div>

                {r.open && (
                  <ArrowRight className="mt-1 h-5 w-5 shrink-0 text-muted-foreground" />
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      )}
    </div>
  );
}

function NonTradeBatchCard({ posted, onOpen }: { posted: boolean; onOpen: () => void }) {
  const b = NON_TRADE_BATCH;
  const t = batchTotals;
  return (
    <Card
      data-batch={b.batchId}
      data-batch-total={t.total.usd}
      className={cn("bg-card", posted ? "border-green-200 bg-green-50/30" : "border-primary/30")}
    >
      <CardContent className="flex flex-wrap items-center justify-between gap-4 p-4">
        <div className="flex items-start gap-4">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
            {posted ? <CircleCheck className="h-5 w-5" /> : <AgentIcon type="validation" size="sm" />}
          </div>
          <div className="flex flex-col gap-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-semibold text-foreground">Weekly non-trade batch</span>
              <span className="font-mono text-xs text-muted-foreground">{b.batchId}</span>
              <Badge
                variant="outline"
                className={cn(
                  "whitespace-nowrap",
                  posted ? "border-green-300 bg-green-50 text-green-700" : "border-amber-300 bg-amber-50 text-amber-800"
                )}
              >
                {posted ? "Posted" : "Ready for agents"}
              </Badge>
              <ControlTags refs={["1.4.5", "1.4.3", "1.4.4"]} />
            </div>
            <p className="text-sm text-muted-foreground">
              {posted
                ? `${t.valid.count} credited · ${t.invalid.count} charged back · ${t.exception.count} with owners`
                : `${t.total.count} claims · ${formatUsd(t.total.usd)} · ${b.categories.length} categories · week ${b.week}`}
            </p>
            <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
              <SystemBadge name="SAP FSCM" />
              <span>Policy {b.policyRef}</span>
            </div>
          </div>
        </div>
        <Button size="sm" variant={posted ? "outline" : "default"} onClick={onOpen}>
          {posted ? "Review batch" : "Open batch"} <ArrowRight className="h-4 w-4" />
        </Button>
      </CardContent>
    </Card>
  );
}

/* ---------------------------------------------------------------- *
 * The run
 * ---------------------------------------------------------------- */

function DeductionRun({ onBack }: { onBack: () => void }) {
  const {
    channelDeductionCases,
    chooseRecovery,
    sendDisputeLetter,
    resolveChannelDeduction,
  } = useOtcStore();

  const deduction = channelDeductionCases[0];
  const [statuses, setStatuses] = useState<Record<string, SimStatus>>(() =>
    Object.fromEntries(STAGES.map((s) => [s.id, "waiting" as SimStatus]))
  );
  const [processing, setProcessing] = useState(false);
  const [logs, setLogs] = useState<AgentLog[]>([]);
  const [openStages, setOpenStages] = useState<Set<string>>(new Set());
  const [activeStage, setActiveStage] = useState<string | null>(null);
  const [finaleDismissed, setFinaleDismissed] = useState(false);
  const [awaitingAdvance, setAwaitingAdvance] = useState(false);
  /** Selected in the ladder, not yet confirmed. Nothing is written yet. */
  const [pendingRecovery, setPendingRecovery] = useState<string | null>(null);
  const [classifyModalOpen, setClassifyModalOpen] = useState(false);
  const [classificationConfirmed, setClassificationConfirmed] = useState(false);
  /** Resolves when the presenter presses Enter. */
  const advanceRef = useRef<(() => void) | null>(null);
  const classifyRef = useRef(false);
  const rootCauseRef = useRef(false);
  const letterRef = useRef(false);
  const outcomeRef = useRef(false);
  const startedRef = useRef(false);
  const cardRefs = useRef<Record<string, HTMLDivElement | null>>({});

  // These selectors build a fresh object on every call. Memoised so the
  // narration below keeps a stable identity — without this it changed on every
  // render, and any effect depending on it cleared its own timer before the
  // timer could fire, which froze the run at the letter stage.
  const linkedClaimId = deduction?.linkedClaimId;
  const math = useMemo(
    () => (linkedClaimId ? claimLineMath(linkedClaimId) : null),
    [linkedClaimId]
  );
  const position = useMemo(
    () => (deduction ? shortPayPosition(deduction) : null),
    [deduction]
  );
  const link = useMemo(
    () => (deduction ? claimRecoilLink(deduction) : null),
    [deduction]
  );

  const narration = useMemo(
    () =>
      deduction && math && position && link
        ? buildNarration(deduction, math, position, link)
        : ({} as Record<string, string>),
    [deduction, math, position, link]
  );

  /**
   * Read inside effects without making them depend on the narration, so a
   * re-render can never restart a stage timer.
   */
  const narrationRef = useRef(narration);
  narrationRef.current = narration;

  /**
   * One stage open at a time. Keeping every completed stage expanded pushed
   * the rail and the header off screen, so a finished stage collapses back to
   * its heading and stays one click away.
   */
  const openStage = useCallback((stageId: string) => {
    setOpenStages(new Set([stageId]));
    setActiveStage(stageId);
  }, []);

  const addLog = useCallback((stageId: string, tone: AgentLog["tone"]) => {
    const stage = STAGES.find((s) => s.id === stageId)!;
    setLogs((prev) => [
      ...prev,
      {
        id: `${stageId}-${prev.length}`,
        agent: stage.agent,
        agentType: stage.agentType,
        message: stage.log,
        tone,
      },
    ]);
  }, []);

  /**
   * Runs from a given stage onward, stopping at each gate.
   *
   * Two stages are gates and neither is marked passed on the way through: the
   * classification, because a wrong reason code sends the whole case down the
   * wrong path, and the recovery choice, because it commits money. Each is
   * resumed by its own effect once a person has confirmed.
   */
  const runFrom = useCallback(
    async (startId: string) => {
      setProcessing(true);
      const startAt = Math.max(
        0,
        STAGES.findIndex((s) => s.id === startId)
      );
      for (const stage of STAGES.slice(startAt)) {
        if (stage.id === "classify" && !classifyRef.current) {
          setStatuses((prev) => ({ ...prev, classify: "needsReview" }));
          openStage("classify");
          addLog("classify", "attention");
          setProcessing(false);
          return;
        }
        if (stage.id === "recover") {
          // Not marked passed — the run pauses here for a person to choose.
          setStatuses((prev) => ({ ...prev, recover: "needsReview" }));
          openStage("recover");
          addLog("recover", "attention");
          setProcessing(false);
          return;
        }
        setStatuses((prev) => ({ ...prev, [stage.id]: "running" }));
        openStage(stage.id);

        // The node turns green under its own timer once the narration has been
        // read, so a stage waiting on the presenter never looks like a stage
        // still working. Enter is armed from the moment the stage appears and
        // works at any point — arming it later made the key feel dead.
        let marked = false;
        const markPassed = () => {
          if (marked) return;
          marked = true;
          setStatuses((prev) => ({ ...prev, [stage.id]: "passed" }));
          addLog(stage.id, "info");
        };
        const dwell = setTimeout(
          markPassed,
          narrationDwellMs(asText(narrationRef.current[stage.id]), STAGE_DWELL_MS)
        );

        const advanced = new Promise<void>((resolve) => {
          advanceRef.current = resolve;
        });
        setAwaitingAdvance(true);
        await advanced;
        setAwaitingAdvance(false);

        clearTimeout(dwell);
        markPassed();
      }
    },
    [addLog, openStage]
  );

  /**
   * The run is presenter-paced. A stage finishes its narration, then holds
   * until Enter. Every other key is ignored, and Enter does nothing while a
   * stage is still working or while a decision is outstanding.
   */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Enter") return;
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      if (!advanceRef.current) return;
      e.preventDefault();
      const go = advanceRef.current;
      advanceRef.current = null;
      go();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  /** The run starts on its own; the ref survives Strict Mode's double mount. */
  useEffect(() => {
    if (startedRef.current || !deduction) return;
    startedRef.current = true;
    void runFrom("intake");
  }, [runFrom, deduction]);

  /** Keeps the stage being worked on in the middle of the screen. */
  useEffect(() => {
    if (!activeStage) return;
    const node = cardRefs.current[activeStage];
    if (!node) return;
    const reduce =
      typeof window !== "undefined" &&
      window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    node.scrollIntoView({
      behavior: reduce ? "auto" : "smooth",
      block: "center",
    });
  }, [activeStage]);

  /** A confirmed classification releases the run on to the root cause. */
  useEffect(() => {
    if (!classificationConfirmed || rootCauseRef.current) return;
    rootCauseRef.current = true;
    setStatuses((prev) => ({ ...prev, classify: "passed" }));
    addLog("classify", "success");
    void runFrom("root_cause");
  }, [classificationConfirmed, addLog, runFrom]);

  /** A recovery choice moves the run on to the letter, and stops again. */
  useEffect(() => {
    if (!deduction?.chosenRecovery || letterRef.current) return;
    letterRef.current = true;
    setStatuses((prev) => ({ ...prev, recover: "passed", letter: "running" }));
    setOpenStages((prev) => new Set(prev).add("letter"));
    setActiveStage("letter");
    const id = setTimeout(() => {
      // Drafted, not sent. The letter stage waits for its own approval.
      setStatuses((prev) => ({ ...prev, letter: "needsReview" }));
      addLog("letter", "attention");
    }, narrationDwellMs(asText(narrationRef.current.letter), STAGE_DWELL_MS));
    return () => clearTimeout(id);
  }, [deduction?.chosenRecovery, addLog]);

  /** Only a sent letter closes the case. */
  useEffect(() => {
    if (deduction?.disputeStatus !== "Sent" || outcomeRef.current) return;
    outcomeRef.current = true;
    setStatuses((prev) => ({ ...prev, letter: "passed", outcome: "running" }));
    setOpenStages((prev) => new Set(prev).add("outcome"));
    setActiveStage("outcome");
    const id = setTimeout(() => {
      setStatuses((prev) => ({ ...prev, outcome: "passed" }));
      addLog("outcome", "success");
      setActiveStage(null);
    }, narrationDwellMs(asText(narrationRef.current.outcome), STAGE_DWELL_MS));
    return () => clearTimeout(id);
  }, [deduction?.disputeStatus, addLog]);

  if (!deduction || !math || !position || !link) return null;


  const reached: string[] = STAGES.filter(
    (s) => statuses[s.id] !== "waiting"
  ).map((s) => s.id);
  const doneCount = STAGES.filter((s) => statuses[s.id] === "passed").length;

  const renderBody = (stageId: string) => {
    switch (stageId) {
      case "intake":
        return (
          <div className="space-y-4">
            <PaymentShortfallBar
              position={position}
              matchedClaimAmount={link.rejectedAmount}
              matchesExactly={link.matchesExactly}
            />
            <SourceDocTrigger
              doc={buildRemittanceAdviceDoc(deduction)}
              label="View the remittance advice"
            />
          </div>
        );
      case "classify":
        return (
          <div className="space-y-4">
            <ReasonCodeFunnel
              steps={classificationTrail(deduction)}
              confidence={deduction.reasonConfidence}
            />
            {statuses.classify === "needsReview" && (
              <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border-2 border-amber-200 bg-amber-50/60 px-3 py-2.5">
                <p className="text-xs text-amber-900">
                  Awaiting your decision. The classification determines how the
                  case is pursued and nothing proceeds until you confirm it.
                </p>
                <Button
                  size="sm"
                  onClick={() => setClassifyModalOpen(true)}
                  className="whitespace-nowrap"
                >
                  Review the classification
                </Button>
              </div>
            )}
            {classificationConfirmed && (
              <p className="flex items-center gap-1.5 text-xs text-[var(--success)]">
                <ThumbsUp className="h-3.5 w-3.5" />
                Confirmed by you — {deduction.reasonCode.toLowerCase()}.
              </p>
            )}
            {classifyModalOpen && (
              <ClassificationConfirmModal
                deduction={deduction}
                steps={classificationTrail(deduction)}
                onCancel={() => setClassifyModalOpen(false)}
                onConfirm={() => {
                  classifyRef.current = true;
                  setClassifyModalOpen(false);
                  setClassificationConfirmed(true);
                }}
              />
            )}
          </div>
        );
      case "root_cause":
        return (
          <ChargebackRecoilTrace
            link={link}
            claimId={deduction.linkedClaimId!}
            customerName={deduction.customerName}
          />
        );
      case "recover":
        return (
          <div className="space-y-4">
            <RecoveryLadder
              options={recoveryOptions(deduction)}
              chosen={deduction.chosenRecovery}
              pending={pendingRecovery ?? undefined}
              onChoose={setPendingRecovery}
              disabled={statuses.recover !== "needsReview"}
            />
            {!deduction.chosenRecovery && (
              <p className="rounded-lg border-2 border-amber-200 bg-amber-50/60 px-3 py-2 text-xs text-amber-800">
                Awaiting your decision. Selecting an action shows what it
                recovers, what it concedes and what it posts; nothing is written
                until you confirm it.
              </p>
            )}
            {pendingRecovery && !deduction.chosenRecovery && (
              <RecoveryImpactModal
                deduction={deduction}
                option={pendingRecovery}
                onCancel={() => setPendingRecovery(null)}
                onConfirm={() => {
                  chooseRecovery(deduction.deductionId, pendingRecovery);
                  setPendingRecovery(null);
                }}
              />
            )}
          </div>
        );
      case "letter":
        return (
          <DisputeLetterComposer
            letterKey={deduction.deductionId}
            from={`${deduction.disputeLetter!.from} <${deduction.disputeLetter!.fromEmail}>`}
            to={`${deduction.disputeLetter!.to} <${deduction.disputeLetter!.toEmail}>`}
            subject={renderDisputeLetter(deduction)?.subject ?? ""}
            body={renderDisputeLetter(deduction)?.body ?? ""}
            attachments={[
              {
                doc: buildChargebackClaimDoc(deduction.linkedClaimId!),
                label: "Chargeback claim",
              },
              {
                doc: buildContractPriceListDoc(deduction.linkedClaimId!),
                label: "Price records",
              },
              {
                doc: buildRemittanceAdviceDoc(deduction),
                label: "Remittance advice",
              },
              {
                doc: buildDisputeLetterDoc(deduction, {
                  sent: deduction.disputeStatus === "Sent",
                }),
                label: "Letter as a document",
              },
            ]}
            sent={deduction.disputeStatus === "Sent"}
            sentDate={deduction.disputeSentDate}
            sentNote={`Issued to ${deduction.customerName} accounts payable. Repayment requested within 30 days.`}
            canSend={statuses.letter === "needsReview"}
            blockedNote="Choose a recovery action first."
            onSend={() => {
              sendDisputeLetter(deduction.deductionId);
              resolveChannelDeduction(
                deduction.deductionId,
                deduction.chosenRecovery ?? "Request repayment"
              );
            }}
          />
        );
      case "outcome": {
        const acct = deductionAccounting(deduction);
        if (!acct) return null;
        return (
          <GtnImpactPanel
            shortPay={deduction.amount}
            gtnImpact={acct.gtnImpact}
            recoveryRequired={acct.recoveryRequired}
            basis={acct.basis}
            lines={acct.lines}
            caseRef={deduction.deductionId}
            claimRef={deduction.linkedClaimId}
          />
        );
      }
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <button
            type="button"
            onClick={onBack}
            className="mb-1 inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            All deductions
          </button>
          <h2 className="text-xl font-semibold">
            {deduction?.deductionId} — {deduction?.customerName}
          </h2>
          <p className="text-sm text-muted-foreground">
            The cause is established, traced to its source and answered in
            writing. Every recovery action and every outgoing letter is
            approved by a person.
          </p>
        </div>
        {processing && !awaitingAdvance && (
          <span className="flex items-center gap-2 text-sm text-muted-foreground">
            <Spinner size="sm" />
            Investigation in progress
          </span>
        )}
      </div>

      <Card className="bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="flex flex-wrap items-center gap-2 text-sm font-semibold">
            <Badge variant="outline" className="whitespace-nowrap">
              {formatUsd(deduction.amount)} withheld on {deduction.invoiceId}
            </Badge>
            <span className="text-xs font-normal text-muted-foreground">
              {doneCount}/{STAGES.length} steps cleared
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-2">
          <StageProgressRail
            stages={STAGES}
            statuses={statuses}
            openStageId={activeStage}
            onStageClick={(id) => {
              if (reached.includes(id)) openStage(id);
            }}
          />
        </CardContent>
      </Card>

      {reached.length === 0 ? (
        <Card className="bg-card">
          <CardContent className="p-8 text-center">
            <p className="text-sm text-muted-foreground">
              Investigation starting.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-[minmax(0,1fr)_280px]">
          <div className="min-w-0 space-y-2">
            {STAGES.filter((s) => reached.includes(s.id)).map((stage) => {
              const open = openStages.has(stage.id);
              const status = statuses[stage.id];
              return (
                <Card
                  key={stage.id}
                  ref={(node) => {
                    cardRefs.current[stage.id] = node;
                  }}
                  className={RUN_STAGE_CARD_CLASS}
                >
                  <RunStageRow
                    label={stage.heading}
                    status={status}
                    expanded={open}
                    summary={stage.log}
                    onToggle={() =>
                      setOpenStages((prev) => {
                        const next = new Set(prev);
                        if (next.has(stage.id)) next.delete(stage.id);
                        else next.add(stage.id);
                        return next;
                      })}
                  />
                  {open && (
                    <div className={RUN_STAGE_BODY_CLASS}>
                      <AiStageNarration
                        key={stage.id}
                        text={narration[stage.id]}
                      />
                      {renderBody(stage.id)}
                    </div>
                  )}
                </Card>
              );
            })}
          </div>

          <AgentAuditTrail entries={logs} />
        </div>
      )}

      {statuses.outcome === "passed" && !finaleDismissed && (
        <RunCompleteModal
          eyebrow="Deduction recovery complete"
          title={`${deduction.deductionId} moved to recovery`}
          narrative="The deduction was traced to its source, the recovery action was chosen by a person, and the dispute letter was approved before it was issued."
          stats={[
            {
              label: "steps cleared",
              value: `${STAGES.length} / ${STAGES.length}`,
            },
            {
              label: "requested back",
              value: formatUsd(deduction.amount),
              tone: "danger",
            },
            {
              label: "action",
              value: deduction.chosenRecovery ?? "—",
            },
            {
              label: "letter issued",
              value: deduction.disputeSentDate ?? "—",
            },
          ]}
          docs={[
            {
              doc: buildDisputeLetterDoc(deduction, { sent: true }),
              label: `Dispute letter ${deduction.disputeLetter?.letterRef ?? ""}`,
            },
            {
              doc: buildRemittanceAdviceDoc(deduction),
              label: `Remittance ${position.remittance?.remittanceId ?? ""}`,
            },
          ]}
          primaryLabel="Review the chargeback claim"
          onPrimary={() => setFinaleDismissed(true)}
          secondaryLabel="Stay on this case"
          onSecondary={() => setFinaleDismissed(true)}
        />
      )}
    </div>
  );
}
