"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import {
  ArrowLeft,
  ArrowRight,
  Bot,
  Building2,
  CircleCheck,
  FileSearch,
  Landmark,
  Link2,
  Mail,
  ShieldCheck,
  Sparkles,
  X,
} from "lucide-react";

import {
  AiStepReasoning,
  RevealWhen,
  waitForStepReasoning,
} from "@/components/mounts/order-management/step-reasoning";
import {
  AgentAuditTrail,
  RUN_STAGE_BODY_CLASS,
  RUN_STAGE_CARD_CLASS,
  RunStageRow,
  type AuditEntry,
  type RunStageStatus,
} from "@/components/mounts/shared/run-stage-row";
import { RunCompleteModal } from "@/components/mounts/shared/run-complete-modal";
import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { EmailDraftDialog } from "@/components/shared/email-draft-dialog";
import { SystemBadge } from "@/components/shared/system-badge";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  BatchCaseModal,
  DeductionCaseModal,
  EvidencePanel,
  LineTypeBadge,
} from "@/components/views/cash/cash-case-parts";
import {
  findCashPayment,
  formatCashUsd as formatUsd,
  paymentResolution,
} from "@/lib/cash-application-selectors";
import { AMOUNT_MATCH_TOLERANCE_USD } from "@/lib/data/cash-application";
import type { CashPayment, RemittanceLine } from "@/lib/data/cash-application";
import {
  buildDeductionRegisterDoc,
  buildLockboxDoc,
  buildPostingDoc,
  buildRemittanceDoc,
  deductionCaseId,
} from "@/lib/docs-cash-application";
import { useTypewriter } from "@/lib/hooks/use-typewriter";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const STAGES = [
  { id: "receive", label: "Receive & pair" },
  { id: "read", label: "Read the remittance" },
  { id: "match", label: "Match to SAP" },
  { id: "classify", label: "Classify deductions" },
  { id: "residual", label: "Investigate the residual" },
  { id: "post", label: "Approve & post" },
] as const;
type StageId = (typeof STAGES)[number]["id"];
const stageIndex = (id: StageId) => STAGES.findIndex((s) => s.id === id);

type Disposition = "on-account" | "intercompany";

interface RunProgress {
  /** Index of the current stage; STAGES.length once posted. */
  stage: number;
  /** The current stage has finished its AI work and is waiting on a person. */
  awaiting: boolean;
  disposition: Disposition | null;
}

/** Survives leaving and re-opening the payment, so a finished step never replays. */
const progressByPayment = new Map<string, RunProgress>();

/** Walmart's 12-month payment behaviour, as the agent reads it from AR history. */
const CUSTOMER_PROFILE = [
  { label: "Average days to pay", value: "28 days", note: "Terms Net 30" },
  { label: "Deduction rate", value: "1.2%", note: "Of receipts, last 12 months" },
  { label: "Remittance with payment", value: "96%", note: "Same-day 820s" },
  { label: "On-account items", value: "4.2 days", note: "Average time to clear" },
];

const span = (l: RemittanceLine) => (l.isAggregate ? l.aggregateCount ?? 1 : 1);
const sumSpan = (ls: RemittanceLine[]) => ls.reduce((n, l) => n + span(l), 0);
const sumAmt = (ls: RemittanceLine[]) => ls.reduce((n, l) => n + l.amount, 0);

export function RemittanceRun({
  paymentId,
  onBack,
}: {
  paymentId: string;
  onBack: () => void;
}) {
  const {
    postedCashPayments,
    postCashPayment,
    openedCashDeductionCases,
    openCashDeductionCase,
    openCashDeductionCases,
  } = useOtcStore();
  const payment = findCashPayment(paymentId) as CashPayment;
  const resolution = paymentResolution(payment);
  const posted = postedCashPayments.includes(paymentId);

  const [progress, setProgress] = useState<RunProgress>(
    () =>
      progressByPayment.get(paymentId) ??
      (posted
        ? { stage: STAGES.length, awaiting: false, disposition: "on-account" }
        : { stage: 0, awaiting: false, disposition: null })
  );
  useEffect(() => {
    progressByPayment.set(paymentId, progress);
  }, [paymentId, progress]);

  const { stage, awaiting, disposition } = progress;
  const currentId: StageId | null = STAGES[stage]?.id ?? null;

  const lines = payment.lines;
  const deductions = lines.filter((l) => l.type === "deduction");
  const autoDeductions = deductions.filter((l) => !l.reviewReason);
  const allCasesOpen = deductions.every((l) =>
    openedCashDeductionCases.includes(l.lineId)
  );

  const advance = useCallback(
    () => setProgress((p) => ({ ...p, stage: p.stage + 1, awaiting: false })),
    []
  );

  const [readyStage, setReadyStage] = useState<number | null>(null);
  const readyForEnter = readyStage === stage && currentId !== null;

  // The run only moves on once the current step's reasoning and its card
  // animation have both finished playing — and then only when the user presses Enter.
  useEffect(() => {
    if (!currentId || awaiting) return;
    let cancelled = false;
    waitForStepReasoning(`${paymentId}:${currentId}`).then(() => {
      if (cancelled) return;
      if (currentId === "classify") {
        openCashDeductionCases(autoDeductions.map((l) => l.lineId));
        setProgress((p) => ({ ...p, awaiting: true }));
      } else if (currentId === "residual" || currentId === "post") {
        setProgress((p) => ({ ...p, awaiting: true }));
      } else {
        setReadyStage(stage);
      }
    });
    return () => {
      cancelled = true;
    };
    // autoDeductions is derived from static payment data.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentId, awaiting, paymentId, openCashDeductionCases]);

  useEffect(() => {
    if (currentId === "classify" && awaiting && allCasesOpen) setReadyStage(stage);
  }, [currentId, awaiting, allCasesOpen, stage]);

  useEffect(() => {
    if (!readyForEnter) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Enter" || e.isComposing || e.keyCode === 229) return;
      const t = e.target as HTMLElement | null;
      if (t && (t.closest("input, textarea, select, [contenteditable='true']"))) return;
      e.preventDefault();
      setReadyStage(null);
      advance();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [readyForEnter, advance]);

  const [expanded, setExpanded] = useState<string | null>(currentId);
  useEffect(() => {
    setExpanded(currentId);
  }, [currentId]);

  const cardRefs = useRef<Record<string, HTMLDivElement | null>>({});
  useEffect(() => {
    if (!currentId || stage === 0) return;
    const t = setTimeout(
      () =>
        cardRefs.current[currentId]?.scrollIntoView({ behavior: "smooth", block: "nearest" }),
      150
    );
    return () => clearTimeout(t);
  }, [currentId, stage]);

  const [showComplete, setShowComplete] = useState(false);
  const approveAndPost = () => {
    postCashPayment(paymentId);
    advance();
    setShowComplete(true);
    toast.success("Posted to SAP — the document balances to $0");
  };

  const chooseDisposition = (d: Disposition) => {
    setProgress((p) => ({ ...p, disposition: d, stage: p.stage + 1, awaiting: false }));
  };

  const statusOf = (i: number): RunStageStatus =>
    i < stage ? "passed" : i === stage && awaiting ? "needsReview" : "running";

  const reason = (
    id: StageId,
    reasoning: string[],
    cardSteps: number,
    body: (phase: number) => React.ReactNode,
    cardStepMs?: number
  ) => {
    const key = `${paymentId}:${id}`;
    return (
      <AiStepReasoning
        key={key}
        stepKey={key}
        lines={reasoning}
        instant={stageIndex(id) < stage}
        cardSteps={cardSteps}
        cardStepMs={cardStepMs}
      >
        {body}
      </AiStepReasoning>
    );
  };

  const summaries: Record<StageId, string> = {
    receive: `${formatUsd(payment.amount)} lockbox credit paired with the EDI 820 remittance`,
    read: `${payment.remittanceItemCount} lines read · ${sumSpan(lines.filter((l) => l.type === "invoice"))} invoices, ${sumSpan(lines.filter((l) => l.type === "credit"))} credits, ${deductions.length} deductions, 1 unknown`,
    match: `${formatUsd(resolution.matched + resolution.credits)} cleared against SAP open items`,
    classify: `${deductions.length} deduction cases open · ${autoDeductions.length} by the AI, ${deductions.length - autoDeductions.length} confirmed by you`,
    residual:
      disposition === "intercompany"
        ? `${formatUsd(resolution.unidentified)} on account · intercompany check opened`
        : `${formatUsd(resolution.unidentified)} on account (UNID) · remittance requested`,
    post: "Posted to SAP · document balances to $0",
  };

  const renderBody = (id: StageId) => {
    switch (id) {
      case "receive":
        return reason("receive", RECEIVE_LINES(payment), 4, (p) => (
          <ReceiveCard payment={payment} phase={p} base={RECEIVE_LINES(payment).length} />
        ));
      case "read":
        return reason("read", READ_LINES(payment), 5, (p) => (
          <ReadCard payment={payment} phase={p} base={READ_LINES(payment).length} />
        ));
      case "match": {
        const r = MATCH_LINES(payment);
        return reason("match", r, 6, (p) => (
          <MatchCard payment={payment} phase={p} base={r.length} />
        ), 520);
      }
      case "classify": {
        const r = CLASSIFY_LINES(payment);
        return reason("classify", r, deductions.length + 1, (p) => (
          <ClassifyCard
            payment={payment}
            phase={p}
            base={r.length}
            awaiting={currentId === "classify" && awaiting}
            opened={openedCashDeductionCases}
            onOpen={openCashDeductionCase}
            onOpenAll={openCashDeductionCases}
          />
        ), 380);
      }
      case "residual": {
        const r = RESIDUAL_LINES(payment);
        return reason("residual", r, 5, (p) => (
          <ResidualCard
            payment={payment}
            phase={p}
            base={r.length}
            awaiting={currentId === "residual" && awaiting}
            disposition={disposition}
            onChoose={chooseDisposition}
          />
        ), 600);
      }
      case "post": {
        const r = POST_LINES(payment);
        return reason("post", r, 6, (p) => (
          <PostCard
            payment={payment}
            phase={p}
            base={r.length}
            awaiting={currentId === "post" && awaiting}
            posted={posted}
            disposition={disposition}
            onApprove={approveAndPost}
          />
        ), 420);
      }
    }
  };

  const reached = STAGES.slice(0, Math.min(stage + 1, STAGES.length));

  return (
    <div className="flex flex-col gap-4 p-4 md:p-6">
      <div className="flex flex-wrap items-center gap-3">
        <Button variant="ghost" size="sm" onClick={onBack} className="gap-1.5">
          <ArrowLeft className="h-4 w-4" aria-hidden />
          Payments
        </Button>
        <div className="flex min-w-0 flex-1 flex-col">
          <h1 className="text-balance text-lg font-semibold">
            {payment.paymentId} · {payment.customer}
          </h1>
          <p className="text-sm text-muted-foreground">
            {formatUsd(payment.amount)} · ACH · received {payment.receivedDate}
          </p>
        </div>
        <Badge variant={posted ? "default" : "secondary"}>
          {posted ? "Posted" : currentId ? STAGES[stage].label : "Complete"}
        </Badge>
      </div>

      <ReconciliationBar payment={payment} stage={stage} />

      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_20rem]">
        <div className="flex min-w-0 flex-col gap-3">
          {reached.map((s, i) => {
            const status = statusOf(i);
            const isOpen = expanded === s.id;
            return (
              <div key={s.id} ref={(el) => { cardRefs.current[s.id] = el; }}>
                <Card className={RUN_STAGE_CARD_CLASS}>
                  <RunStageRow
                    label={s.label}
                    status={status}
                    expanded={isOpen}
                    onToggle={() => setExpanded(isOpen ? null : s.id)}
                    summary={status === "passed" ? summaries[s.id] : undefined}
                  />
                  {isOpen && <div className={RUN_STAGE_BODY_CLASS}>{renderBody(s.id)}</div>}
                </Card>
              </div>
            );
          })}
        </div>

        <aside className="flex flex-col gap-4">
          <CustomerProfileCard payment={payment} />
          <CoPilotAsk payment={payment} stage={stage} />
          <AgentAuditTrail
            entries={auditEntries(payment, stage, awaiting, disposition, autoDeductions.length)}
          />
        </aside>
      </div>


      {showComplete && (
        <RunCompleteModal
          eyebrow="Cash application complete"
          title={`${payment.paymentId} applied and posted`}
          narrative={`${formatUsd(resolution.matched)} cleared invoices, ${formatUsd(resolution.credits)} applied credit memos, ${formatUsd(resolution.deductions)} opened as ${deductions.length} dispute items and ${formatUsd(resolution.unidentified)} sits on account while the remittance is chased. The document balances to zero; nothing was written off.`}
          stats={[
            { label: "Cleared", value: formatUsd(resolution.matched + resolution.credits), tone: "success" },
            { label: "Dispute items", value: formatUsd(resolution.deductions) },
            { label: "On account", value: formatUsd(resolution.unidentified) },
          ]}
          docs={[{ doc: buildPostingDoc(payment), label: "Posting document" }]}
          primaryLabel="Back to payments"
          onPrimary={() => {
            setShowComplete(false);
            onBack();
          }}
          secondaryLabel="Stay on this payment"
          onSecondary={() => setShowComplete(false)}
        />
      )}
    </div>
  );
}

/* ---------------------------------------------------------------- *
 * The signature element: where every dollar of the bank credit went
 * ---------------------------------------------------------------- */

function ReconciliationBar({ payment, stage }: { payment: CashPayment; stage: number }) {
  const r = paymentResolution(payment);
  const segments = [
    { key: "inv", label: "Invoices cleared", amount: r.matched, shown: stage > stageIndex("match"), color: "bg-[var(--success)]" },
    { key: "cr", label: "Credit memos", amount: r.credits, shown: stage > stageIndex("match"), color: "bg-[var(--info)]" },
    { key: "ded", label: "Dispute items", amount: r.deductions, shown: stage > stageIndex("classify"), color: "bg-[var(--warning)]" },
    { key: "oa", label: "On account", amount: r.unidentified, shown: stage > stageIndex("residual"), color: "bg-muted-foreground/60" },
  ];
  const applied = segments.reduce((n, s) => n + (s.shown ? s.amount : 0), 0);
  const left = payment.amount - applied;

  return (
    <Card className="gap-3 py-4">
      <CardContent className="flex flex-col gap-3 px-4">
        <div className="flex flex-wrap items-end justify-between gap-2">
          <div className="flex flex-col">
            <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              Where the {formatUsd(payment.amount)} goes
            </span>
            <span className="text-sm text-muted-foreground">
              Fills as each step applies its share of the bank credit
            </span>
          </div>
          <div className="flex flex-col items-end">
            <span className="text-xs text-muted-foreground">Left to apply</span>
            <span
              key={left}
              className={cn(
                "animate-enter-fade font-mono text-xl font-semibold tabular-nums",
                left === 0 ? "text-[var(--success)]" : "text-foreground"
              )}
            >
              {formatUsd(left)}
            </span>
          </div>
        </div>
        <div
          className="flex h-3 w-full gap-0.5 overflow-hidden rounded-full bg-muted"
          role="img"
          aria-label={`${formatUsd(applied)} of ${formatUsd(payment.amount)} applied`}
        >
          {segments.map((s) => (
            <div
              key={s.key}
              className={cn("h-full transition-[width] duration-1000 ease-out", s.color)}
              style={{
                width: s.shown ? `${(s.amount / payment.amount) * 100}%` : "0%",
                minWidth: s.shown ? 6 : 0,
              }}
            />
          ))}
        </div>
        <ul className="flex flex-wrap gap-x-5 gap-y-1 text-xs">
          {segments.map((s) => (
            <li
              key={s.key}
              className={cn(
                "flex items-center gap-1.5 transition-opacity duration-500",
                s.shown ? "opacity-100" : "opacity-40"
              )}
            >
              <span className={cn("h-2 w-2 rounded-full", s.color)} aria-hidden />
              <span className="text-muted-foreground">{s.label}</span>
              <span className="font-mono tabular-nums text-foreground">{formatUsd(s.amount)}</span>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}

/* ---------------------------------------------------------------- *
 * Step reasoning copy
 * ---------------------------------------------------------------- */

const RECEIVE_LINES = (p: CashPayment) => [
  `A lockbox credit of ${formatUsd(p.amount)} landed from ${p.customer} on ${p.receivedDate} by ACH.`,
  `The EDI 820 remittance arrived on the same trace number. I paired them on payer, amount, value date and trace reference before trusting either.`,
  `Pulled Walmart's open items from S/4HANA and ECC so every remittance line has something to match against.`,
];

const READ_LINES = (p: CashPayment) => [
  `Parsed ${p.remittanceItemCount} remittance lines from the 820 and its PDF addendum.`,
  `No line carries a SAP invoice number — Walmart cites its own shipment and invoice references, so matching on reference alone would miss almost everything.`,
  `Classified each line by its adjustment code before matching, so short-pays never get forced onto an invoice.`,
];

function matchLayers(p: CashPayment) {
  const inv = p.lines.filter((l) => l.type === "invoice");
  return [
    { key: "reference", label: "PO / reference", note: "Remittance cites a PO that resolves to one SAP invoice", lines: inv.filter((l) => l.matchStrategy === "reference") },
    { key: "amount-date", label: "Amount + date + customer", note: `Inside the ${formatUsd(AMOUNT_MATCH_TOLERANCE_USD)} tolerance`, lines: inv.filter((l) => l.matchStrategy === "amount-date") },
    { key: "combined", label: "Combined shipment", note: "One remittance line clears several SAP invoices", lines: inv.filter((l) => l.matchStrategy === "combined-shipment") },
    { key: "credit", label: "Credit memos", note: "Approved open credit memos applied", lines: p.lines.filter((l) => l.type === "credit") },
  ];
}

const MATCH_LINES = (p: CashPayment) => {
  const [ref, amt, comb, cr] = matchLayers(p);
  const combined = comb.lines[0];
  const left = p.remittanceItemCount - sumSpan([...ref.lines, ...amt.lines, ...comb.lines, ...cr.lines]);
  return [
    `I matched in layers, strictest first — a line only falls through to the next layer if it didn't resolve.`,
    `Reference: ${sumSpan(ref.lines)} line resolves on its PO. Amount + date + customer: ${sumSpan(amt.lines)} lines inside the ${formatUsd(AMOUNT_MATCH_TOLERANCE_USD)} tolerance.`,
    combined?.splitInto
      ? `${combined.lineId} is a combined shipment — ${formatUsd(combined.amount)} against ${combined.splitInto.length} SAP invoices totalling ${formatUsd(combined.splitInto.reduce((n, s) => n + s.amount, 0))}. The gap is inside tolerance, so both clear.`
      : `One combined shipment clears two SAP invoices inside tolerance.`,
    `Credits: ${sumSpan(cr.lines)} lines resolve to approved open credit memos. That leaves ${left} lines — short-pays and one I can't place.`,
  ];
};

const CLASSIFY_LINES = (p: CashPayment) => {
  const ded = p.lines.filter((l) => l.type === "deduction");
  const review = ded.filter((l) => l.reviewReason);
  return [
    `${ded.length} short-pays total ${formatUsd(sumAmt(ded))}. Each invoice still clears in full — the short amount stays open as a residual item with a dispute case. Nothing is written off.`,
    `${ded.length - review.length} have evidence at 90% or better in VISTEX, PROMAX, CAS and PricerX, so I'm opening those cases myself.`,
    `${review.map((l) => l.lineId).join(" and ")} need your judgement — the claim is cited without the proof that would back it.`,
  ];
};

const RESIDUAL_LINES = (p: CashPayment) => {
  const u = p.lines.find((l) => l.type === "unidentified");
  return [
    `${u?.customerRef ?? "The last line"} · ${formatUsd(u?.amount ?? 0)} doesn't resolve to any Walmart document in S/4HANA or ECC.`,
    `I weighed every candidate across SAP, VISTEX and freight records — none clears the 85% bar I need to apply cash.`,
    `The cash still posts today. Holding it would leave the bank unreconciled for no gain — on account, it stays visible, ages, and gets chased.`,
  ];
};

const POST_LINES = (p: CashPayment) => [
  `Built the DZ posting document for US01: the bank credit against four groups of items.`,
  `Balance check: debits equal credits to the cent — every dollar lands on an account.`,
  `This one needs a sign-off because it opens dispute items and an on-account item. Clean payments under $250k at 95%+ confidence post without a person.`,
];

/* ---------------------------------------------------------------- *
 * Step cards
 * ---------------------------------------------------------------- */

function Appear({
  when,
  className,
  children,
}: {
  when: boolean;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <div
      aria-hidden={!when}
      className={cn(
        "transition-all duration-500 ease-out",
        when ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-1 opacity-0",
        className
      )}
    >
      {children}
    </div>
  );
}

function SourceTile({
  icon: Icon,
  title,
  lines,
  action,
}: {
  icon: typeof Landmark;
  title: string;
  lines: string[];
  action?: React.ReactNode;
}) {
  return (
    <div className="flex h-full flex-col gap-2 rounded-lg border bg-muted/30 p-3">
      <div className="flex items-center gap-2 text-sm font-medium">
        <Icon className="h-4 w-4 text-primary" aria-hidden />
        {title}
      </div>
      {lines.map((l, i) => (
        <p key={l} className={cn("text-sm", i === 0 ? "font-mono font-semibold tabular-nums" : "text-muted-foreground")}>
          {l}
        </p>
      ))}
      {action && <div className="mt-auto pt-1">{action}</div>}
    </div>
  );
}

function ReceiveCard({ payment, phase, base }: { payment: CashPayment; phase: number; base: number }) {
  const keys = ["Payer", "Amount", "Value date", "Trace reference"];
  return (
    <div className="flex flex-col gap-3">
      <div className="grid items-stretch gap-3 md:grid-cols-[1fr_auto_1fr]">
        <Appear when={phase >= base}>
          <SourceTile
            icon={Landmark}
            title="Bank · lockbox credit"
            lines={[formatUsd(payment.amount), `ACH CCD+ · value date ${payment.receivedDate}`]}
            action={<SourceDocTrigger doc={buildLockboxDoc(payment)} label="View lockbox file" />}
          />
        </Appear>
        <div className="flex items-center justify-center">
          <div
            className={cn(
              "flex h-9 w-9 items-center justify-center rounded-full border transition-all duration-500",
              phase >= base + 2
                ? "border-[var(--success)] bg-[var(--success)] text-[var(--success-foreground)]"
                : "border-dashed text-muted-foreground"
            )}
          >
            <Link2 className="h-4 w-4" aria-hidden />
            <span className="sr-only">{phase >= base + 2 ? "Paired" : "Pairing"}</span>
          </div>
        </div>
        <Appear when={phase >= base + 1}>
          <SourceTile
            icon={FileSearch}
            title="Remittance · EDI 820 + PDF"
            lines={[`${payment.remittanceItemCount} lines`, "Same trace number as the bank credit"]}
            action={<SourceDocTrigger doc={buildRemittanceDoc(payment)} label="View remittance" />}
          />
        </Appear>
      </div>
      <RevealWhen when={phase >= base + 2}>
        <ul className="grid grid-cols-2 gap-2 md:grid-cols-4">
          {keys.map((k, i) => (
            <li
              key={k}
              className="flex animate-enter items-center gap-1.5 rounded-md border px-2.5 py-1.5 text-sm"
              style={{ animationDelay: `${i * 90}ms` }}
            >
              <CircleCheck className="h-4 w-4 shrink-0 text-[var(--success)]" aria-hidden />
              {k}
            </li>
          ))}
        </ul>
      </RevealWhen>
      <RevealWhen when={phase >= base + 3}>
        <div className="flex animate-enter flex-wrap items-center gap-2 rounded-lg border px-3 py-2.5 text-sm">
          <Building2 className="h-4 w-4 text-primary" aria-hidden />
          <span className="font-medium">Walmart open items loaded</span>
          <span className="text-muted-foreground">to match against</span>
          <span className="ml-auto flex gap-1.5">
            <SystemBadge name="S/4HANA" />
            <SystemBadge name="ECC" />
          </span>
        </div>
      </RevealWhen>
    </div>
  );
}

function ReadCard({ payment, phase, base }: { payment: CashPayment; phase: number; base: number }) {
  const ls = payment.lines;
  const groups = [
    { label: "Invoices", count: sumSpan(ls.filter((l) => l.type === "invoice")), color: "bg-[var(--success)]" },
    { label: "Credits", count: sumSpan(ls.filter((l) => l.type === "credit")), color: "bg-[var(--info)]" },
    { label: "Deductions", count: sumSpan(ls.filter((l) => l.type === "deduction")), color: "bg-[var(--warning)]" },
    { label: "Unknown", count: sumSpan(ls.filter((l) => l.type === "unidentified")), color: "bg-muted-foreground/60" },
  ];
  const total = groups.reduce((n, g) => n + g.count, 0);
  const sample = ls.find((l) => l.type === "invoice");

  return (
    <div className="flex flex-col gap-3">
      <RevealWhen when={phase >= base}>
        <dl className="grid animate-enter grid-cols-2 gap-3 rounded-lg border p-3 md:grid-cols-4">
          {[
            ["Payer", payment.customer],
            ["Amount", formatUsd(payment.amount)],
            ["Lines", String(payment.remittanceItemCount)],
            ["Format", "EDI 820 + PDF"],
          ].map(([k, v]) => (
            <div key={k} className="flex flex-col">
              <dt className="text-xs text-muted-foreground">{k}</dt>
              <dd className="text-sm font-medium">{v}</dd>
            </div>
          ))}
        </dl>
        {sample && (
          <p className="mt-2 rounded-md bg-muted/50 px-3 py-2 font-mono text-xs text-muted-foreground">
            {"As printed: "}
            {sample.customerRef} · {formatUsd(sample.amount)} · no SAP document number
          </p>
        )}
      </RevealWhen>
      <Appear when={phase >= base + 1} className="flex flex-col gap-2">
        <div className="flex h-7 w-full gap-0.5 overflow-hidden rounded-md bg-muted">
          {groups.map((g, i) => (
            <div
              key={g.label}
              className={cn("h-full transition-[width] duration-700 ease-out", g.color)}
              style={{
                width: phase >= base + 1 + i ? `${(g.count / total) * 100}%` : "0%",
                minWidth: phase >= base + 1 + i ? 8 : 0,
              }}
            />
          ))}
        </div>
        <ul className="grid grid-cols-2 gap-2 md:grid-cols-4">
          {groups.map((g, i) => (
            <li
              key={g.label}
              className={cn(
                "flex items-center gap-2 text-sm transition-opacity duration-300",
                phase >= base + 1 + i ? "opacity-100" : "opacity-30"
              )}
            >
              <span className={cn("h-2.5 w-2.5 rounded-sm", g.color)} aria-hidden />
              <span className="text-muted-foreground">{g.label}</span>
              <span className="ml-auto font-mono font-semibold tabular-nums">{g.count}</span>
            </li>
          ))}
        </ul>
      </Appear>
    </div>
  );
}

function MatchCard({ payment, phase, base }: { payment: CashPayment; phase: number; base: number }) {
  const layers = matchLayers(payment);
  const [selected, setSelected] = useState<RemittanceLine | null>(null);
  const combined = layers[2].lines[0];
  let remaining = payment.remittanceItemCount;

  return (
    <div className="flex flex-col gap-3">
      <ol className="flex flex-col gap-2" aria-label="Matching layers">
        {layers.map((layer, i) => {
          const shown = phase >= base + i;
          remaining -= sumSpan(layer.lines);
          return (
            <li key={layer.key}>
              <Appear when={shown}>
                <div className="flex flex-col gap-2 rounded-lg border p-3">
                  <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
                    <span className="text-sm font-medium">{layer.label}</span>
                    <span className="text-xs text-muted-foreground">{layer.note}</span>
                    <span className="ml-auto font-mono text-sm tabular-nums">
                      {sumSpan(layer.lines)} lines · {formatUsd(sumAmt(layer.lines))}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-muted">
                      <div
                        className="h-full rounded-full bg-primary transition-[width] duration-700 ease-out"
                        style={{
                          width: shown
                            ? `${(remaining / payment.remittanceItemCount) * 100}%`
                            : `${((remaining + sumSpan(layer.lines)) / payment.remittanceItemCount) * 100}%`,
                        }}
                      />
                    </div>
                    <span className="w-24 text-right text-xs text-muted-foreground tabular-nums">
                      {remaining} left
                    </span>
                  </div>
                </div>
              </Appear>
            </li>
          );
        })}
      </ol>

      {combined?.splitInto && (
        <RevealWhen when={phase >= base + 4}>
          <div className="flex animate-enter flex-col gap-2 rounded-lg border bg-muted/30 p-3">
            <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              Combined shipment · {combined.lineId}
            </span>
            <div className="flex flex-wrap items-center gap-3">
              <div className="rounded-md border bg-card px-3 py-2">
                <p className="text-xs text-muted-foreground">{combined.customerRef}</p>
                <p className="font-mono text-sm font-semibold tabular-nums">{formatUsd(combined.amount)}</p>
              </div>
              <ArrowRight className="h-4 w-4 text-muted-foreground" aria-hidden />
              {combined.splitInto.map((s, i) => (
                <div
                  key={s.sapDocument}
                  className="animate-enter rounded-md border bg-card px-3 py-2"
                  style={{ animationDelay: `${150 + i * 150}ms` }}
                >
                  <p className="text-xs text-muted-foreground">SAP {s.sapDocument}</p>
                  <p className="font-mono text-sm font-semibold tabular-nums">{formatUsd(s.amount)}</p>
                </div>
              ))}
              <Badge variant="outline" className="ml-auto">
                {formatUsd(combined.amount - combined.splitInto.reduce((n, s) => n + s.amount, 0))}
                {" variance · under "}
                {formatUsd(AMOUNT_MATCH_TOLERANCE_USD)}
              </Badge>
            </div>
          </div>
        </RevealWhen>
      )}

      <RevealWhen when={phase >= base + 5}>
        <div className="grid animate-enter gap-3 md:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
          <div className="overflow-hidden rounded-lg border">
            <table className="w-full text-sm">
              <caption className="sr-only">Remittance lines and how each resolved</caption>
              <thead className="bg-muted/50 text-xs text-muted-foreground">
                <tr>
                  <th scope="col" className="px-3 py-2 text-left font-medium">Line</th>
                  <th scope="col" className="px-3 py-2 text-left font-medium">Type</th>
                  <th scope="col" className="px-3 py-2 text-right font-medium">Amount</th>
                </tr>
              </thead>
              <tbody>
                {payment.lines.map((l) => (
                  <tr
                    key={l.lineId}
                    className={cn(
                      "cursor-pointer border-t hover:bg-muted/40",
                      selected?.lineId === l.lineId && "bg-muted/60"
                    )}
                    onClick={() => setSelected(l)}
                  >
                    <td className="px-3 py-1.5">
                      <button type="button" className="text-left font-mono text-xs underline-offset-2 hover:underline">
                        {l.lineId}
                        {l.isAggregate ? ` +${(l.aggregateCount ?? 1) - 1}` : ""}
                      </button>
                    </td>
                    <td className="px-3 py-1.5"><LineTypeBadge type={l.type} /></td>
                    <td className="px-3 py-1.5 text-right font-mono tabular-nums">{formatUsd(l.amount)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <EvidencePanel line={selected} />
        </div>
      </RevealWhen>
    </div>
  );
}

function ClassifyCard({
  payment,
  phase,
  base,
  awaiting,
  opened,
  onOpen,
  onOpenAll,
}: {
  payment: CashPayment;
  phase: number;
  base: number;
  awaiting: boolean;
  opened: string[];
  onOpen: (lineId: string) => void;
  onOpenAll: (lineIds: string[]) => void;
}) {
  const ded = payment.lines.filter((l) => l.type === "deduction");
  const review = ded.filter((l) => l.reviewReason && !opened.includes(l.lineId));
  const [caseLine, setCaseLine] = useState<RemittanceLine | null>(null);
  const [batchOpen, setBatchOpen] = useState(false);
  const allShown = phase >= base + ded.length;

  return (
    <div className="flex flex-col gap-3">
      <div className="overflow-hidden rounded-lg border">
        <table className="w-full text-sm">
          <caption className="sr-only">Deductions and their reason codes</caption>
          <thead className="bg-muted/50 text-xs text-muted-foreground">
            <tr>
              <th scope="col" className="px-3 py-2 text-left font-medium">Line</th>
              <th scope="col" className="px-3 py-2 text-left font-medium">Reason</th>
              <th scope="col" className="hidden px-3 py-2 text-left font-medium xl:table-cell">Evidence</th>
              <th scope="col" className="px-3 py-2 text-right font-medium">Amount</th>
              <th scope="col" className="px-3 py-2 text-right font-medium">Case</th>
            </tr>
          </thead>
          <tbody>
            {ded.map((l, i) => {
              const stamped = phase >= base + i;
              const isOpen = opened.includes(l.lineId);
              return (
                <tr key={l.lineId} className="border-t">
                  <td className="whitespace-nowrap px-3 py-2 font-mono text-xs">{l.lineId}</td>
                  <td className="px-3 py-2">
                    {stamped ? (
                      <span className="inline-flex animate-enter items-center gap-1.5">
                        <span className="rounded bg-muted px-1.5 py-0.5 font-mono text-xs">{l.reasonCode}</span>
                        <span className="text-xs text-muted-foreground">{l.confidence}%</span>
                      </span>
                    ) : (
                      <span className="text-xs text-muted-foreground">Classifying…</span>
                    )}
                  </td>
                  <td className="hidden px-3 py-2 xl:table-cell">
                    {stamped && l.caseSystem && (
                      <span className="animate-enter-fade"><SystemBadge name={l.caseSystem} /></span>
                    )}
                  </td>
                  <td className="whitespace-nowrap px-3 py-2 text-right font-mono tabular-nums">{formatUsd(l.amount)}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-right">
                    {!stamped ? null : isOpen ? (
                      <span className="inline-flex animate-enter items-center gap-1 text-xs text-[var(--success)]">
                        <CircleCheck className="h-3.5 w-3.5" aria-hidden />
                        {deductionCaseId(l)}
                      </span>
                    ) : l.reviewReason ? (
                      <Badge variant="outline" className="border-[var(--warning)] text-xs">Needs you</Badge>
                    ) : (
                      <span className="text-xs text-muted-foreground">Queued</span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <RevealWhen when={allShown}>
        <div className="flex animate-enter flex-wrap items-center gap-2 text-sm">
          <Bot className="h-4 w-4 text-primary" aria-hidden />
          <span>
            {ded.length - ded.filter((l) => l.reviewReason).length} cases opened automatically · SLA clocks started
          </span>
          <SourceDocTrigger
            doc={buildDeductionRegisterDoc(payment)}
            label="Deduction register"
            variant="ghost"
            className="ml-auto"
          />
        </div>
      </RevealWhen>

      {awaiting && review.length > 0 && (
        <div className="flex animate-enter flex-col gap-2 rounded-lg border border-[var(--warning)] bg-[var(--warning)]/10 p-3">
          <p className="text-sm font-medium">
            {review.length === 1 ? "1 deduction needs your judgement" : `${review.length} deductions need your judgement`}
          </p>
          {review.map((l) => (
            <div key={l.lineId} className="flex flex-col gap-2 rounded-md border bg-card p-3 md:flex-row md:items-center">
              <div className="flex min-w-0 flex-1 flex-col">
                <span className="text-sm font-medium">
                  {l.lineId} · {l.reasonCode} · {formatUsd(l.amount)}
                </span>
                <span className="text-pretty text-sm text-muted-foreground">{l.reviewReason}</span>
              </div>
              <div className="flex shrink-0 gap-2">
                <Button size="sm" variant="outline" onClick={() => setCaseLine(l)}>
                  Review case
                </Button>
                <Button
                  size="sm"
                  onClick={() => {
                    onOpen(l.lineId);
                    toast.success(`${deductionCaseId(l)} opened with a document request`);
                  }}
                >
                  Open with document request
                </Button>
              </div>
            </div>
          ))}
          <Button size="sm" variant="ghost" className="self-start" onClick={() => setBatchOpen(true)}>
            Review all {ded.length} cases together
          </Button>
        </div>
      )}

      {caseLine && (
        <DeductionCaseModal
          line={caseLine}
          customer={payment.customer}
          alreadyOpened={opened.includes(caseLine.lineId)}
          onOpenCase={() => onOpen(caseLine.lineId)}
          onClose={() => setCaseLine(null)}
        />
      )}
      {batchOpen && (
        <BatchCaseModal
          payment={payment}
          lines={ded}
          alreadyOpened={ded.every((l) => opened.includes(l.lineId))}
          onInspect={(l) => {
            setBatchOpen(false);
            setCaseLine(l);
          }}
          onConfirm={() => {
            onOpenAll(ded.map((l) => l.lineId));
            setBatchOpen(false);
          }}
          onClose={() => setBatchOpen(false)}
        />
      )}
    </div>
  );
}

function ResidualCard({
  payment,
  phase,
  base,
  awaiting,
  disposition,
  onChoose,
}: {
  payment: CashPayment;
  phase: number;
  base: number;
  awaiting: boolean;
  disposition: Disposition | null;
  onChoose: (d: Disposition) => void;
}) {
  const u = payment.lines.find((l) => l.type === "unidentified");
  const candidates = u?.candidates ?? [];
  const [emailOpen, setEmailOpen] = useState(false);
  if (!u) return null;

  return (
    <div className="flex flex-col gap-3">
      <ol className="flex flex-col gap-2" aria-label="Candidates the AI weighed">
        {candidates.map((c, i) => {
          const shown = phase >= base + i;
          const ruledOut = phase >= base + i + 1;
          return (
            <li key={c.label}>
              <Appear when={shown}>
                <div className="flex flex-col gap-1.5 rounded-lg border p-3">
                  <div className="flex items-baseline gap-2">
                    <span
                      className={cn(
                        "text-sm font-medium transition-colors duration-500",
                        ruledOut && "text-muted-foreground line-through"
                      )}
                    >
                      {c.label}
                    </span>
                    <span className="ml-auto font-mono text-xs tabular-nums text-muted-foreground">
                      {c.confidence}%
                    </span>
                    {ruledOut && (
                      <span className="inline-flex animate-enter-fade items-center gap-1 text-xs text-muted-foreground">
                        <X className="h-3 w-3" aria-hidden />
                        Ruled out
                      </span>
                    )}
                  </div>
                  <div className="relative h-1.5 overflow-hidden rounded-full bg-muted">
                    <div
                      className={cn(
                        "h-full rounded-full transition-[width] duration-700 ease-out",
                        ruledOut ? "bg-muted-foreground/40" : "bg-primary"
                      )}
                      style={{ width: shown ? `${c.confidence}%` : "0%" }}
                    />
                    <div className="absolute inset-y-0 w-px bg-foreground/60" style={{ left: "85%" }} aria-hidden />
                  </div>
                  <p className="text-pretty text-xs text-muted-foreground">{c.detail}</p>
                </div>
              </Appear>
            </li>
          );
        })}
      </ol>

      <RevealWhen when={phase >= base + candidates.length + 1 || phase >= base + 4}>
        {disposition ? (
          <div className="flex animate-enter items-start gap-2 rounded-lg border p-3 text-sm">
            <CircleCheck className="mt-0.5 h-4 w-4 shrink-0 text-[var(--success)]" aria-hidden />
            <span className="text-pretty">
              {formatUsd(u.amount)} posted on account to Walmart under reason UNID.{" "}
              {disposition === "intercompany"
                ? "An intercompany check with Walmart de México is open; the item re-matches as soon as it's confirmed."
                : "Walmart has been asked for the remittance; the item re-matches automatically when it arrives, with a reminder on day 3."}
            </span>
          </div>
        ) : (
          <div className="grid animate-enter gap-3 md:grid-cols-2">
            <div className="flex flex-col gap-2 rounded-lg border-2 border-primary p-3">
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold">Post on account · UNID</span>
                <Badge className="ml-auto">Recommended</Badge>
              </div>
              <ul className="flex flex-col gap-1 text-sm text-muted-foreground">
                <li>Cash posts today — the bank reconciles</li>
                <li>Item ages on Walmart&apos;s account and stays visible</li>
                <li>AI emails Walmart for the remittance and re-matches on arrival</li>
              </ul>
              {awaiting && (
                <Button size="sm" className="mt-auto gap-1.5 self-start" onClick={() => setEmailOpen(true)}>
                  <Mail className="h-4 w-4" aria-hidden />
                  Post on account & email Walmart
                </Button>
              )}
            </div>
            <div className="flex flex-col gap-2 rounded-lg border p-3">
              <span className="text-sm font-semibold">Verify with Walmart de México</span>
              <p className="text-pretty text-sm text-muted-foreground">
                {candidates[0]?.detail ?? "A credit on a related sold-to matches the amount."} Posts on account the same way, with an intercompany check instead of a customer email.
              </p>
              {awaiting && (
                <Button
                  size="sm"
                  variant="outline"
                  className="mt-auto self-start"
                  onClick={() => {
                    onChoose("intercompany");
                    toast.success("Posted on account · intercompany check opened");
                  }}
                >
                  Post on account & open intercompany check
                </Button>
              )}
            </div>
          </div>
        )}
      </RevealWhen>

      {emailOpen && (
        <EmailDraftDialog
          to="remittance@walmart.com"
          toOrg="Walmart Inc. · Accounts Payable"
          subject={`Remittance detail needed — ${u.customerRef} · ${formatUsd(u.amount)}`}
          body={`Hello,\n\nPayment ${payment.paymentId} (${formatUsd(payment.amount)}) included a line referenced ${u.customerRef} for ${formatUsd(u.amount)} that we can't match to an open Walmart invoice or credit memo.\n\nWe've placed the ${formatUsd(u.amount)} on account to you under reference UNID rather than apply it to the wrong document. Could you send the invoice or credit memo it relates to? We'll apply it as soon as it arrives.\n\nThank you,\nAccounts Receivable`}
          sentLabel="Remittance request sent"
          onSend={() => {
            setEmailOpen(false);
            onChoose("on-account");
          }}
          onClose={() => setEmailOpen(false)}
        />
      )}
    </div>
  );
}

function PostCard({
  payment,
  phase,
  base,
  awaiting,
  posted,
  disposition,
  onApprove,
}: {
  payment: CashPayment;
  phase: number;
  base: number;
  awaiting: boolean;
  posted: boolean;
  disposition: Disposition | null;
  onApprove: () => void;
}) {
  const r = paymentResolution(payment);
  const entries = [
    { pk: "40", account: "100010 · Bank — lockbox", debit: payment.amount, credit: 0 },
    { pk: "15", account: "140000 · AR — invoices cleared", debit: 0, credit: r.matched },
    { pk: "15", account: "140000 · AR — credit memos applied", debit: 0, credit: r.credits },
    { pk: "15", account: "195000 · Dispute items (cases open)", debit: 0, credit: r.deductions },
    { pk: "15", account: "196000 · On account — Walmart (UNID)", debit: 0, credit: r.unidentified },
  ];
  const creditsShown = entries.reduce(
    (n, e, i) => n + (phase >= base + i ? e.credit : 0),
    0
  );
  const debitsShown = phase >= base ? payment.amount : 0;
  const diff = debitsShown - creditsShown;
  const balanced = phase >= base + entries.length;

  return (
    <div className="flex flex-col gap-3">
      <div className="overflow-hidden rounded-lg border">
        <table className="w-full text-sm">
          <caption className="sr-only">Proposed SAP posting document</caption>
          <thead className="bg-muted/50 text-xs text-muted-foreground">
            <tr>
              <th scope="col" className="px-3 py-2 text-left font-medium">PK</th>
              <th scope="col" className="px-3 py-2 text-left font-medium">Account</th>
              <th scope="col" className="px-3 py-2 text-right font-medium">Debit</th>
              <th scope="col" className="px-3 py-2 text-right font-medium">Credit</th>
            </tr>
          </thead>
          <tbody className="font-mono text-xs">
            {entries.map((e, i) => (
              <tr
                key={e.account}
                className={cn(
                  "border-t transition-opacity duration-300",
                  phase >= base + i ? "opacity-100" : "opacity-0"
                )}
              >
                <td className="px-3 py-2">{e.pk}</td>
                <td className="px-3 py-2 font-sans text-sm">{e.account}</td>
                <td className="px-3 py-2 text-right tabular-nums">{e.debit ? formatUsd(e.debit) : "—"}</td>
                <td className="px-3 py-2 text-right tabular-nums">{e.credit ? formatUsd(e.credit) : "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="flex items-center gap-3 border-t bg-muted/30 px-3 py-2">
          <span className="text-xs text-muted-foreground">Difference</span>
          <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-muted">
            <div
              className={cn(
                "h-full rounded-full transition-[width] duration-500",
                balanced ? "bg-[var(--success)]" : "bg-[var(--warning)]"
              )}
              style={{ width: `${debitsShown ? (diff / payment.amount) * 100 : 0}%` }}
            />
          </div>
          <span
            className={cn(
              "font-mono text-sm font-semibold tabular-nums",
              balanced && "text-[var(--success)]"
            )}
          >
            {formatUsd(Math.max(0, diff))}
          </span>
        </div>
      </div>

      <RevealWhen when={balanced}>
        {posted ? (
          <div className="flex animate-enter flex-col gap-3 rounded-lg border p-3">
            <div className="flex items-center gap-2 text-sm font-medium">
              <ShieldCheck className="h-4 w-4 text-[var(--success)]" aria-hidden />
              Posted to SAP · full history kept for audit
            </div>
            <ul className="flex flex-col gap-1.5 text-sm text-muted-foreground">
              <li>{payment.lines.filter((l) => l.type === "deduction").length} dispute items tracked against their SLA dates</li>
              <li>
                {disposition === "intercompany"
                  ? "Intercompany check with Walmart de México open for the on-account item"
                  : "Remittance request sent to Walmart · reminder on day 3"}
              </li>
              <li>On-account item re-matches automatically when new remittance arrives</li>
            </ul>
            <SourceDocTrigger doc={buildPostingDoc(payment)} label="View posting document" className="self-start" />
          </div>
        ) : (
          <div className="flex animate-enter flex-col gap-3 rounded-lg border border-[var(--warning)] bg-[var(--warning)]/10 p-3">
            <p className="text-sm font-medium">Sign-off required before posting</p>
            <ul className="flex flex-col gap-1 text-sm text-muted-foreground">
              <li>Opens {formatUsd(r.deductions)} of dispute items</li>
              <li>Places {formatUsd(r.unidentified)} on account</li>
              <li>Payment is over the $250k auto-post limit</li>
            </ul>
            <div className="flex flex-wrap gap-2">
              <SourceDocTrigger doc={buildPostingDoc(payment)} label="Preview posting document" />
              {awaiting && (
                <Button size="sm" onClick={onApprove}>
                  Approve & post to SAP
                </Button>
              )}
            </div>
          </div>
        )}
      </RevealWhen>
    </div>
  );
}

/* ---------------------------------------------------------------- *
 * Side column
 * ---------------------------------------------------------------- */

function CustomerProfileCard({ payment }: { payment: CashPayment }) {
  return (
    <Card className="gap-3 py-4">
      <CardHeader className="px-4">
        <CardTitle className="flex items-center gap-2 text-sm">
          <Building2 className="h-4 w-4 text-primary" aria-hidden />
          How {payment.customer.split(" ")[0]} pays
        </CardTitle>
      </CardHeader>
      <CardContent className="px-4">
        <dl className="grid grid-cols-2 gap-3">
          {CUSTOMER_PROFILE.map((f) => (
            <div key={f.label} className="flex flex-col">
              <dt className="text-xs text-muted-foreground">{f.label}</dt>
              <dd className="font-mono text-base font-semibold tabular-nums">{f.value}</dd>
              <dd className="text-xs text-muted-foreground">{f.note}</dd>
            </div>
          ))}
        </dl>
      </CardContent>
    </Card>
  );
}

function coPilotQuestions(p: CashPayment): { stage: StageId; q: string; a: string }[] {
  const r = paymentResolution(p);
  return [
    { stage: "read", q: "Why not match on reference?", a: "Walmart's remittance cites its own shipment and invoice numbers, not SAP document numbers. Only one line resolves on a PO, so reference-only matching would leave almost the whole payment unapplied." },
    { stage: "match", q: `What does the ${formatUsd(AMOUNT_MATCH_TOLERANCE_USD)} tolerance cover?`, a: `A line matches on amount only when customer and date also agree and the gap is under ${formatUsd(AMOUNT_MATCH_TOLERANCE_USD)}. Anything larger is treated as a short-pay and gets its own case — it is never absorbed.` },
    { stage: "classify", q: "Why do two deductions need me?", a: "Both cite a reason without the proof behind it — a damage claim with no POD exception and a compliance fine with no violation notice. Opening them is fine; deciding whether to accept or dispute them is a judgement call." },
    { stage: "residual", q: "Why post on account instead of holding?", a: `Holding the ${formatUsd(r.unidentified)} would leave the bank unreconciled and hide the item. On account, it posts today, ages on Walmart's account, and re-matches automatically when the remittance arrives.` },
    { stage: "post", q: "Why does this need a sign-off?", a: "Clean payments under $250k at 95%+ confidence post on their own. This one is larger, opens dispute items and places cash on account, so a person approves before SAP is updated." },
  ];
}

function CoPilotAsk({ payment, stage }: { payment: CashPayment; stage: number }) {
  const [asked, setAsked] = useState<string | null>(null);
  const questions = useMemo(
    () => coPilotQuestions(payment).filter((q) => stageIndex(q.stage) <= stage).slice(-3),
    [payment, stage]
  );
  const active = coPilotQuestions(payment).find((q) => q.q === asked);

  return (
    <Card className="gap-3 py-4">
      <CardHeader className="px-4">
        <CardTitle className="flex items-center gap-2 text-sm">
          <Sparkles className="h-4 w-4 text-primary" aria-hidden />
          Ask the agent
        </CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col gap-2 px-4">
        {questions.length === 0 && (
          <p className="text-sm text-muted-foreground">Questions appear as the run reaches each step.</p>
        )}
        {questions.map((q) => (
          <button
            key={q.q}
            type="button"
            onClick={() => setAsked(q.q)}
            className={cn(
              "rounded-md border px-3 py-2 text-left text-sm transition-colors hover:bg-muted/50",
              asked === q.q && "border-primary bg-muted/50"
            )}
          >
            {q.q}
          </button>
        ))}
        {active && <CoPilotAnswer key={active.q} text={active.a} />}
      </CardContent>
    </Card>
  );
}

function CoPilotAnswer({ text }: { text: string }) {
  const typed = useTypewriter(text);
  const shown = typeof typed === "string" ? typed : typed.visible;
  return (
    <p className="text-pretty rounded-md bg-muted/50 px-3 py-2 text-sm leading-relaxed" aria-live="polite">
      {shown}
    </p>
  );
}

function auditEntries(
  p: CashPayment,
  stage: number,
  awaiting: boolean,
  disposition: Disposition | null,
  autoCount: number
): AuditEntry[] {
  const r = paymentResolution(p);
  const at = (id: StageId) => stageIndex(id);
  const out: AuditEntry[] = [
    { id: "start", agent: "Cash Application Agent", agentType: "orchestrator", message: `Picked up ${p.paymentId} — ${formatUsd(p.amount)} from ${p.customer}`, tone: "info" },
  ];
  if (stage > at("receive")) out.push({ id: "pair", agent: "Intake Agent", agentType: "document", message: "Paired the lockbox credit with its EDI 820 remittance", tone: "success" });
  if (stage > at("read")) out.push({ id: "read", agent: "Extraction Agent", agentType: "extraction", message: `Read ${p.remittanceItemCount} remittance lines and classified each one`, tone: "success" });
  if (stage > at("match")) out.push({ id: "match", agent: "Matching Agent", agentType: "validation", message: `Cleared ${formatUsd(r.matched + r.credits)} against SAP open items`, tone: "success" });
  if (stage > at("classify") || (stage === at("classify") && awaiting))
    out.push({ id: "auto-cases", agent: "Deductions Agent", agentType: "invoice", message: `Opened ${autoCount} deduction cases automatically`, tone: "success" });
  if (stage === at("classify") && awaiting)
    out.push({ id: "review-cases", agent: "Deductions Agent", agentType: "invoice", message: "2 deductions need your judgement before their cases open", tone: "attention" });
  if (stage > at("classify")) out.push({ id: "all-cases", agent: "Deductions Agent", agentType: "invoice", message: `All dispute items open · ${formatUsd(r.deductions)}`, tone: "success" });
  if (stage === at("residual") && awaiting)
    out.push({ id: "residual-rec", agent: "Cash Application Agent", agentType: "orchestrator", message: `Recommends posting ${formatUsd(r.unidentified)} on account (UNID)`, tone: "attention" });
  if (stage > at("residual"))
    out.push({ id: "residual", agent: "Collections Agent", agentType: "dunning", message: disposition === "intercompany" ? "On account · intercompany check opened" : "On account · remittance request sent to Walmart", tone: "success" });
  if (stage === at("post") && awaiting)
    out.push({ id: "post-wait", agent: "Cash Application Agent", agentType: "orchestrator", message: "Posting document balances — waiting on your sign-off", tone: "attention" });
  if (stage > at("post")) out.push({ id: "posted", agent: "Cash Application Agent", agentType: "orchestrator", message: "Posted to SAP · balances to $0", tone: "success" });
  return out;
}
