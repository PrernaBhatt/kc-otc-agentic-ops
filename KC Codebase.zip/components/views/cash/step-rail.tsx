"use client";

import { CircleCheck } from "lucide-react";
import type { LucideIcon } from "lucide-react";

import { cn } from "@/lib/utils";

/**
 * The horizontal stage rail shared by every cash-application workbench —
 * the remittance flow plus the scenario-specific flows (unidentified payer,
 * cross-entity receipt). Steps already reached are clickable; steps ahead
 * are locked until the reviewer gets there.
 */
export function StepRail({
  steps,
  activeIndex,
  maxReached,
  onSelect,
}: {
  steps: readonly { id: string; label: string; icon: LucideIcon }[];
  activeIndex: number;
  maxReached: number;
  onSelect: (i: number) => void;
}) {
  return (
    <div className="grid grid-cols-2 gap-2 lg:flex lg:items-stretch">
      {steps.map((step, i) => {
        const Icon = step.icon;
        const isActive = i === activeIndex;
        const reachable = i <= maxReached;
        return (
          <button
            key={step.id}
            type="button"
            disabled={!reachable}
            onClick={() => reachable && onSelect(i)}
            className={cn(
              "flex min-w-0 flex-1 items-center gap-2 rounded-lg border px-3 py-2.5 text-left transition-colors",
              isActive
                ? "border-primary bg-primary/5"
                : reachable
                  ? "border-border bg-card hover:bg-muted/50"
                  : "border-border bg-card opacity-50",
              !reachable && "cursor-not-allowed"
            )}
          >
            <span
              className={cn(
                "flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-full text-xs font-semibold",
                isActive
                  ? "bg-primary text-primary-foreground"
                  : i < activeIndex
                    ? "bg-[var(--success)]/15 text-[var(--success)]"
                    : "bg-muted text-muted-foreground"
              )}
            >
              {i < activeIndex ? <CircleCheck className="h-4 w-4" /> : i + 1}
            </span>
            <div className="min-w-0">
              <p
                className={cn(
                  "text-sm font-medium leading-tight",
                  isActive && "text-primary"
                )}
              >
                {step.label}
              </p>
            </div>
            <Icon className="ml-auto h-4 w-4 flex-shrink-0 text-muted-foreground" />
          </button>
        );
      })}
    </div>
  );
}
