"use client";

import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { toast } from "sonner";
import { Bot, Building2, CircleCheck, Clock, FileSearch, Send, Sparkles, X } from "lucide-react";

import { SystemBadge } from "@/components/shared/system-badge";
import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatCashUsd as formatUsd, lineTypeLabel } from "@/lib/cash-application-selectors";
import { AMOUNT_MATCH_TOLERANCE_USD } from "@/lib/data/cash-application";
import type { CashPayment, RemittanceLine } from "@/lib/data/cash-application";
import {
  buildDeductionRegisterDoc,
  buildSapOpenItemDoc,
  deductionCaseId,
  slaDueLabel,
} from "@/lib/docs-cash-application";
import { useTypewriter } from "@/lib/hooks/use-typewriter";
import { cn } from "@/lib/utils";

export function LineTypeBadge({ type }: { type: RemittanceLine["type"] }) {
  const label = lineTypeLabel(type);
  return (
    <Badge
      variant="outline"
      className={cn(
        "whitespace-nowrap text-[10px]",
        type === "invoice" &&
          "border-[var(--success)]/30 bg-[var(--success)]/10 text-[var(--success)]",
        type === "deduction" && "border-amber-200 bg-amber-50 text-amber-700",
        type === "unidentified" && "border-red-200 bg-red-50 text-red-700"
      )}
    >
      {label}
    </Badge>
  );
}

export function EvidencePanel({ line }: { line: RemittanceLine | null }) {
  if (!line) {
    return (
      <Card className="h-fit bg-card">
        <CardContent className="p-4">
          <p className="text-xs text-muted-foreground">
            Select a line to see why the AI matched it — or didn&apos;t.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="h-fit bg-card">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-semibold">
          Why this {lineTypeLabel(line.type).toLowerCase()}d
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="text-sm font-semibold tabular-nums">
          {formatUsd(line.amount)}
        </p>
        <ul className="space-y-1.5 text-xs text-muted-foreground">
          {line.evidence.map((e, i) => (
            <li key={i} className="flex gap-1.5">
              <span aria-hidden="true">·</span>
              <span>{e}</span>
            </li>
          ))}
        </ul>
        <div className="grid grid-cols-2 gap-2">
          <div className="rounded-md bg-muted/50 px-3 py-2">
            <p className="text-xs text-muted-foreground">Confidence</p>
            <p
              className={cn(
                "text-sm font-semibold tabular-nums",
                line.confidence < 85 ? "text-red-600" : "text-[var(--success)]"
              )}
            >
              {line.confidence}%
            </p>
          </div>
          {line.toleranceNote && (
            <div className="rounded-md bg-muted/50 px-3 py-2">
              <p className="text-xs text-muted-foreground">Amount tolerance</p>
              <p className="text-sm font-semibold tabular-nums text-[var(--success)]">
                Within ${AMOUNT_MATCH_TOLERANCE_USD}
              </p>
            </div>
          )}
        </div>
        {line.toleranceNote && (
          <p className="text-xs leading-snug text-muted-foreground">
            {line.toleranceNote}
          </p>
        )}
        <div>
          <p className="text-xs text-muted-foreground">Recommended action</p>
          <p className="text-sm font-medium">{line.recommendedAction}</p>
        </div>
        {line.caseSystem && <SystemBadge name={line.caseSystem} />}
        {line.sapDocument && (line.type === "invoice" || line.type === "credit") && (
          <SourceDocTrigger
            doc={buildSapOpenItemDoc(line)}
            label={`Open SAP ${line.sapDocument}`}
            variant="outline"
            className="w-full"
          />
        )}
      </CardContent>
    </Card>
  );
}

/**
 * The full deduction case a reviewer opens from a row: routing, SLA, the
 * evidence the AI attached, and an AI-drafted case note ready to post into the
 * downstream system.
 */
export function DeductionCaseModal({
  line,
  customer,
  alreadyOpened,
  onOpenCase,
  onClose,
}: {
  line: RemittanceLine;
  customer: string;
  alreadyOpened: boolean;
  onOpenCase: () => void;
  onClose: () => void;
}) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.stopPropagation();
        onClose();
      }
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [onClose]);

  const caseId = `DED-${line.lineId.replace("RL-", "")}${line.customerRef.replace(/\D/g, "").slice(-3)}`;
  const note = `${line.reasonCode} of ${formatUsd(
    line.amount
  )} short-paid by ${customer} on ${line.customerRef}. ${line.evidence[0]}. Routed to ${line.routeTeam} for validation against ${line.caseSystem}; deducted amount is supportable pending confirmation. Recommend ${
    line.confidence >= 90 ? "approve on evidence attached" : "request supporting document before settling"
  }.`;

  const { visible: noteVisible, done: noteDone } = useTypewriter(note, 8);

  const facts = [
    { label: "Case", value: caseId },
    { label: "Customer", value: customer },
    { label: "Reason", value: line.reasonCode ?? "—" },
    { label: "Amount", value: formatUsd(line.amount) },
    { label: "Routes to", value: line.routeTeam ?? "—" },
    { label: "System of record", value: line.caseSystem ?? "—" },
    { label: "SLA", value: line.slaDays ? `${line.slaDays} business days` : "—" },
    { label: "AI confidence", value: `${line.confidence}%` },
  ];

  if (!mounted) return null;

  return createPortal(
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4"
      onClick={onClose}
    >
      <div
        className="max-h-[85vh] w-full max-w-lg overflow-y-auto rounded-xl border bg-card shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between border-b p-4">
          <div>
            <p className="text-xs font-medium text-muted-foreground">
              Deduction case
            </p>
            <h3 className="text-base font-semibold">
              {line.reasonCode} — {formatUsd(line.amount)}
            </h3>
            <p className="text-xs text-muted-foreground">
              {line.customerRef} · {customer}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-md p-1 text-muted-foreground hover:bg-muted"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="space-y-4 p-4">
          <div className="grid grid-cols-2 gap-x-4 gap-y-3">
            {facts.map((f) => (
              <div key={f.label}>
                <p className="text-xs text-muted-foreground">{f.label}</p>
                <p className="text-sm font-medium">{f.value}</p>
              </div>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-2 rounded-md bg-muted/40 px-3 py-2">
            <Building2 className="h-4 w-4 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">
              Owned by {line.routeTeam}
            </span>
            <span className="text-muted-foreground">·</span>
            <Clock className="h-4 w-4 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">
              {line.slaDays} business day SLA
            </span>
          </div>

          <div>
            <p className="mb-1.5 text-xs font-semibold">Evidence attached</p>
            <ul className="space-y-1 text-xs text-muted-foreground">
              {line.evidence.map((e, i) => (
                <li key={i} className="flex gap-1.5">
                  <CircleCheck className="mt-0.5 h-3.5 w-3.5 flex-shrink-0 text-[var(--success)]" />
                  <span>{e}</span>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold">
              <Sparkles
                className={cn(
                  "h-3.5 w-3.5 text-muted-foreground",
                  !noteDone && "animate-pulse text-primary"
                )}
              />
              {noteDone ? "AI-drafted case note" : "Drafting case note…"}
            </p>
            <div className="rounded-md border bg-muted/30 p-3">
              <p className="text-sm leading-relaxed">
                {noteVisible}
                {!noteDone && (
                  <span className="ml-0.5 inline-block h-3.5 w-[2px] animate-pulse bg-foreground/60 align-middle" />
                )}
              </p>
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-2 border-t p-4">
          <Button variant="outline" size="sm" onClick={onClose}>
            Close
          </Button>
          {alreadyOpened ? (
            <Button size="sm" disabled>
              <CircleCheck className="h-4 w-4" />
              Case opened in {line.caseSystem}
            </Button>
          ) : (
            <Button
                size="sm"
                onClick={() => {
                  onOpenCase();
                  toast.success("Case created", {
                    description: `${caseId} · ${line.reasonCode} · opened in ${line.caseSystem}`,
                    icon: <CircleCheck className="h-4 w-4 text-[var(--success)]" />,
                  });
                  onClose();
                }}
              >
                <Send className="h-4 w-4" />
                Open case in {line.caseSystem}
            </Button>
          )}
        </div>
      </div>
    </div>,
    document.body
  );
}

/**
 * The batch a reviewer sees when opening all deduction cases at once: each
 * short-pay grouped by the system it routes to, the SLA clock it starts, the
 * evidence already attached, and the system-of-record register it writes to —
 * so "open 7 cases" is a visible, auditable act, not a silent status flip.
 */
export function BatchCaseModal({
  payment,
  lines,
  alreadyOpened,
  onInspect,
  onConfirm,
  onClose,
}: {
  payment: CashPayment;
  lines: RemittanceLine[];
  alreadyOpened: boolean;
  onInspect: (line: RemittanceLine) => void;
  onConfirm: () => void;
  onClose: () => void;
}) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.stopPropagation();
        onClose();
      }
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [onClose]);

  const total = lines.reduce((s, l) => s + l.amount, 0);
  const evidenceCount = lines.reduce((s, l) => s + l.evidence.length, 0);

  // Group by the downstream system each case routes into.
  const groups = lines.reduce<Record<string, RemittanceLine[]>>((acc, line) => {
    const key = line.caseSystem ?? "—";
    (acc[key] ??= []).push(line);
    return acc;
  }, {});
  const systemCount = Object.keys(groups).length;

  if (!mounted) return null;

  return createPortal(
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4"
      onClick={onClose}
    >
      <div
        className="flex max-h-[88vh] w-full max-w-2xl flex-col overflow-hidden rounded-xl border bg-card shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between border-b p-4">
          <div>
            <p className="text-xs font-medium text-muted-foreground">
              Open deduction cases
            </p>
            <h3 className="text-base font-semibold">
              {lines.length} cases · {formatUsd(total)}
            </h3>
            <p className="text-xs text-muted-foreground">
              {payment.customer} · routed to {systemCount}{" "}
              {systemCount === 1 ? "system" : "systems"} · {evidenceCount} evidence
              items attached
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-md p-1 text-muted-foreground hover:bg-muted"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="flex-1 space-y-4 overflow-y-auto p-4">
          <div className="flex items-center gap-2 rounded-lg border border-primary/20 bg-primary/5 px-3 py-2 text-xs text-muted-foreground">
            <Bot className="h-4 w-4 flex-shrink-0 text-primary" />
            <span>
              Each line below becomes a tracked case with its evidence attached
              and an SLA clock — <span className="text-foreground">nothing here is written off.</span>
            </span>
          </div>

          {Object.entries(groups).map(([system, groupLines]) => {
            const groupTotal = groupLines.reduce((s, l) => s + l.amount, 0);
            return (
              <div key={system} className="rounded-lg border">
                <div className="flex items-center justify-between border-b bg-muted/30 px-3 py-2">
                  <div className="flex items-center gap-2">
                    <SystemBadge name={system} />
                    <span className="text-xs text-muted-foreground">
                      {groupLines.length}{" "}
                      {groupLines.length === 1 ? "case" : "cases"}
                    </span>
                  </div>
                  <span className="text-xs font-semibold tabular-nums">
                    {formatUsd(groupTotal)}
                  </span>
                </div>
                <div>
                  {groupLines.map((line) => (
                    <button
                      key={line.lineId}
                      type="button"
                      onClick={() => onInspect(line)}
                      className="flex w-full items-center gap-3 border-b px-3 py-2.5 text-left last:border-0 hover:bg-muted/40"
                    >
                      <div className="min-w-0 flex-1">
                        <p className="flex items-center gap-1.5 text-sm font-medium">
                          <span className="font-mono text-xs">
                            {deductionCaseId(line)}
                          </span>
                          <span className="text-muted-foreground">·</span>
                          {line.reasonCode}
                        </p>
                        <p className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-muted-foreground">
                          <span className="inline-flex items-center gap-1">
                            <Building2 className="h-3 w-3" />
                            {line.routeTeam}
                          </span>
                          <span className="inline-flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            SLA due {slaDueLabel(payment.receivedDate, line.slaDays)}
                          </span>
                          <span className="inline-flex items-center gap-1">
                            <CircleCheck className="h-3 w-3 text-[var(--success)]" />
                            {line.evidence.length} evidence
                          </span>
                        </p>
                      </div>
                      <span className="text-sm font-semibold tabular-nums">
                        {formatUsd(line.amount)}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            );
          })}

          <div className="flex items-center justify-between rounded-lg border bg-muted/20 px-3 py-2.5">
            <div className="flex items-center gap-2">
              <FileSearch className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-xs font-medium">Deduction case register</p>
                <p className="text-xs text-muted-foreground">
                  The system-of-record ledger these cases post into
                </p>
              </div>
            </div>
            <SourceDocTrigger
              doc={buildDeductionRegisterDoc(payment)}
              label="View register"
              variant="outline"
            />
          </div>
        </div>

        <div className="flex items-center justify-between gap-2 border-t p-4">
          <p className="text-xs text-muted-foreground">
            Click any case to review its evidence before creating.
          </p>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={onClose}>
              Cancel
            </Button>
            <Button size="sm" onClick={onConfirm} disabled={alreadyOpened}>
              <Send className="h-4 w-4" />
              Create {lines.length} cases
            </Button>
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
}
