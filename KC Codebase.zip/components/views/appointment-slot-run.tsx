"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { CalendarCheck, CalendarSearch, Mail, RefreshCw, Route } from "lucide-react";

import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { AiStageNarration } from "@/components/mounts/chargebacks/ai-stage-narration";
import { OrderThreadStrip } from "@/components/mounts/order-management/order-thread-strip";
import { RunAgentLog } from "@/components/mounts/shared/run-agent-log";
import { RunCompleteModal } from "@/components/mounts/shared/run-complete-modal";
import { RunStageCard, type RunStageMeta } from "@/components/mounts/shared/run-stage-card";
import { StageProgressRail } from "@/components/mounts/shared/stage-progress-rail";
import { useFollowLatest } from "@/components/mounts/shared/use-follow-latest";
import { useStagedRun } from "@/components/mounts/shared/use-staged-run";
import { ReplyCard } from "@/components/mounts/shipments/reply-card";
import { calendarSnapshotPages } from "@/components/mounts/shipments/calendar-snapshot-pdf";
import { RetailerCalendar } from "@/components/mounts/shipments/retailer-calendar";
import { ShipmentRunHeader } from "@/components/mounts/shipments/run-header";
import { CheckChip } from "@/components/shared/check-chip";
import { EmailDraftDialog } from "@/components/shared/email-draft-dialog";
import { FillFields } from "@/components/shared/fill-fields";
import { PdfTrigger } from "@/components/shared/pdf-viewer";
import { StagedChangeTable } from "@/components/shared/staged-change-table";
import { TickList } from "@/components/shared/tick-list";
import { Button } from "@/components/ui/button";
import { TRANSPORT_LEAD } from "@/lib/data/account-owners";
import { TMS_SYSTEM } from "@/lib/data/order-logistics";
import { APPOINTMENT_CASE, RDC_6094_SNAPSHOT, RISK_ROWS } from "@/lib/data/shipment-risk";
import {
  buildRunAConfirmationDoc,
  buildRunAReplanDoc,
  buildRunATmsPlanDoc,
} from "@/lib/docs-logistics";
import { formatUsd } from "@/lib/format";
import { appointmentRun, shortStamp } from "@/lib/shipment-selectors";
import { useOtcStore } from "@/lib/store";

const ORDER = ["plan", "calendar", "ask", "confirmed", "replan"] as const;
type StageId = (typeof ORDER)[number];
const HOLDS = ["ask"] as const satisfies readonly StageId[];

const ICONS = { plan: Route, calendar: CalendarSearch, ask: Mail, confirmed: CalendarCheck, replan: RefreshCw } as const;

const AGENTS = {
  appointment: "Appointment Scheduling Agent",
  comms: "Communication Agent",
  freight: "Freight Planning Agent",
};

/**
 * Run A: the TMS plan has no receiving slot inside Walmart's OTIF window. The
 * agent asks the buyer for one, locks the slot the DC opens, then pushes TMS
 * to replan the load so the truck arrives for it.
 */
export function AppointmentSlotRun({
  onBack,
  backLabel,
}: {
  onBack: () => void;
  backLabel?: string;
}) {
  const { appendAudit, resolveShipment, resolvedShipments } = useOtcStore();
  const a = APPOINTMENT_CASE;
  const caseId = a.caseId;
  const row = RISK_ROWS.find((r) => r.caseId === caseId);

  const [emailOpen, setEmailOpen] = useState(false);
  const [sent, setSent] = useState(false);
  const [replied, setReplied] = useState(false);
  const [finaleDismissed, setFinaleDismissed] = useState(false);
  const cardRefs = useRef<Record<string, HTMLDivElement | null>>({});

  const firstOpen = appointmentRun.firstOpenAfterMabd;
  const stages: Record<StageId, RunStageMeta> = useMemo(
    () => ({
      plan: { id: "plan", label: "TMS plan", heading: "TMS shipment plan read", agent: AGENTS.appointment, summary: `${a.tmsPlan.loadId} · ETA ${shortStamp(a.tmsPlan.eta)}` },
      calendar: { id: "calendar", label: "Calendar", heading: "Walmart receiving calendar checked", agent: AGENTS.appointment, summary: `No slot up to MABD · first open ${firstOpen}` },
      ask: { id: "ask", label: "Ask buyer", heading: `Slot request to ${a.buyer.name}`, agent: AGENTS.comms, summary: `Sent to ${a.buyer.name} · ${a.requestSentAt.split(" ")[1]}` },
      confirmed: { id: "confirmed", label: "Slot confirmed", heading: "Receiving slot confirmed and locked", agent: AGENTS.appointment, summary: `${a.appointment.id} · ${a.appointment.label}` },
      replan: { id: "replan", label: "TMS replan", heading: "TMS load replanned to the slot", agent: AGENTS.freight, summary: `${a.replan.id} · ETA ${shortStamp(a.replan.eta)}` },
    }),
    [a, firstOpen]
  );

  const log = useCallback(
    (agent: string, action: string, extra: { evidence?: string[]; system?: string } = {}) => {
      appendAudit({
        caseId,
        accountId: a.accountId,
        module: "Order Management",
        actor: { kind: "agent", name: agent, role: `Agent · works for ${TRANSPORT_LEAD.name}` },
        action,
        controlRefs: [],
        amountUsd: a.valueUsd,
        evidence: extra.evidence ?? [],
        system: extra.system ?? TMS_SYSTEM,
      });
    },
    [appendAudit, a, caseId]
  );

  const onStart = useCallback(
    (id: StageId) => {
      if (id === "plan") log(AGENTS.appointment, `Read TMS plan ${a.tmsPlan.loadId}: ETA ${shortStamp(a.tmsPlan.eta)} at RDC 6094`, { evidence: [a.tmsPlan.loadId] });
      if (id === "calendar") log(AGENTS.appointment, `No open slot from ${a.otifWindow.from} to MABD ${a.otifWindow.mabd}; first open ${firstOpen}`, { evidence: ["RDC 6094 calendar snapshot"], system: a.portal });
      if (id === "ask") setEmailOpen(true);
      if (id === "confirmed") log(AGENTS.appointment, `Locked ${a.appointment.id} ${a.appointment.label}, inside the OTIF window`, { evidence: [a.appointment.id], system: a.portal });
      if (id === "replan") log(AGENTS.freight, `TMS accepted replan ${a.replan.id}: pickup ${shortStamp(a.replan.pickup)}, ETA ${shortStamp(a.replan.eta)}`, { evidence: [a.replan.id, a.appointment.id] });
    },
    [a, firstOpen, log]
  );

  const run = useStagedRun<StageId>({ order: ORDER, gates: [], holds: HOLDS, onStart });
  const passHoldRef = useRef(run.passHold);
  passHoldRef.current = run.passHold;
  const startRun = run.start;
  useEffect(() => {
    startRun("plan");
  }, [startRun]);

  const ready = useMemo(
    () => Object.fromEntries(ORDER.map((id) => [id, () => run.markReady(id)])) as Record<StageId, () => void>,
    // markReady is stable
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  const done = run.complete;
  useEffect(() => {
    if (done && row?.resolvedLabel) resolveShipment(caseId, row.resolvedLabel);
  }, [done, caseId, row, resolveShipment]);

  useFollowLatest(() => (run.active ? cardRefs.current[run.active] ?? null : null), run.active);

  const handleSend = () => {
    if (sent) return;
    setSent(true);
    setEmailOpen(false);
    log(AGENTS.comms, `Sent slot request to ${a.buyer.name} for ${a.poNumber}`, { evidence: ["RDC 6094 calendar snapshot"], system: "Outlook" });
    setTimeout(() => passHoldRef.current("ask"), 400);
  };

  return (
    <div className="flex flex-col gap-4">
      <ShipmentRunHeader
        caseId={caseId}
        summary={`${a.customer} · ${a.orderId} · ${formatUsd(a.valueUsd)}`}
        accountId={a.accountId}
        agents={[
          { name: AGENTS.appointment, type: "delivery" },
          { name: AGENTS.comms, type: "document" },
          { name: AGENTS.freight, type: "orchestrator" },
        ]}
        onBack={onBack}
        backLabel={backLabel}
      />

      <OrderThreadStrip at="Appointment" resolved={!!resolvedShipments[caseId]} />

      <StageProgressRail
        stages={ORDER.map((id) => ({ id, label: stages[id].label, icon: ICONS[id] }))}
        statuses={run.statuses}
        openStageId={run.active}
        onStageClick={(id) => run.focus(id)}
      />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-[minmax(0,1fr)_300px]">
        <div className="flex min-w-0 flex-col gap-4">
          {ORDER.map((id) => {
            const status = run.statuses[id];
            if (status === "waiting") return null;
            return (
              <RunStageCard
                key={id}
                ref={(el) => {
                  cardRefs.current[id] = el;
                }}
                stage={stages[id]}
                status={status}
                open={run.open.has(id)}
                ready={run.ready.has(id)}
                canContinue={run.active === id && run.canAdvance}
                onToggle={() => run.toggle(id)}
                onContinue={run.advance}
              >
                {id === "plan" && (
                  <>
                    <AiStageNarration
                      variant="inline"
                      playKey={`${caseId}:n:plan`}
                      text={`TMS picks up ${shortStamp(a.tmsPlan.pickup)} at DC-ONT and plans arrival at RDC 6094 for ${shortStamp(a.tmsPlan.eta)}. Walmart requires arrival by the MABD, Wed 08-26.`}
                    />
                    <div className="rounded-lg border bg-card px-3 py-2">
                      <TickList
                        playKey={`${caseId}:plan`}
                        onDone={ready.plan}
                        items={[
                          { id: "route", label: "Route", detail: a.tmsPlan.route, system: TMS_SYSTEM },
                          { id: "load", label: "Load", detail: `${a.tmsPlan.load} · ${a.tmsPlan.loadId}`, system: TMS_SYSTEM },
                          { id: "carrier", label: "Carrier", detail: `${a.tmsPlan.carrier} · ${formatUsd(a.tmsPlan.rateUsd)}`, system: TMS_SYSTEM },
                          { id: "pickup", label: "Pickup", detail: shortStamp(a.tmsPlan.pickup), system: TMS_SYSTEM },
                          { id: "eta", label: "Expected delivery", detail: shortStamp(a.tmsPlan.eta), system: TMS_SYSTEM },
                        ]}
                      />
                    </div>
                    <SourceDocTrigger doc={buildRunATmsPlanDoc()} label="TMS shipment plan" className="self-start" />
                  </>
                )}
                {id === "calendar" && (
                  <>
                    <AiStageNarration
                      variant="inline"
                      playKey={`${caseId}:n:calendar`}
                      text={`Every slot from Mon to Wed is booked. The first open slot, ${firstOpen}, is after the MABD.`}
                    />
                    <RetailerCalendar
                      portal={a.portal}
                      calendar={a.calendar}
                      windowFrom={a.otifWindow.from}
                      mabd={a.otifWindow.mabd}
                      windowLabel={a.otifWindow.label}
                      playKey={`${caseId}:calendar`}
                      onDone={ready.calendar}
                    />
                    <PdfTrigger
                      fileName={RDC_6094_SNAPSHOT.fileName}
                      pages={calendarSnapshotPages}
                      label="Calendar snapshot"
                      className="self-start"
                    />
                  </>
                )}
                {id === "ask" && (
                  <>
                    <AiStageNarration
                      variant="inline"
                      playKey={`${caseId}:n:ask`}
                      text={`Only Walmart can open a slot inside the window. The request to ${a.buyer.name} is drafted.`}
                    />
                    <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border bg-card px-3 py-2.5">
                      <div className="flex min-w-0 flex-col gap-0.5">
                        <span className="text-sm font-medium text-foreground">
                          {a.buyer.name} <span className="font-normal text-muted-foreground">· {a.buyer.role}</span>
                        </span>
                        <span className="truncate text-xs text-muted-foreground">
                          Receiving slot needed at RDC 6094 by Wed 08-26 · {a.poNumber}
                        </span>
                      </div>
                      {sent ? (
                        <span className="rounded-md border border-green-200 bg-green-100 px-1.5 py-0.5 text-[11px] font-semibold text-green-700">
                          Sent · {a.requestSentAt.split(" ")[1]}
                        </span>
                      ) : (
                        <Button size="sm" onClick={() => setEmailOpen(true)}>
                          <Mail className="h-4 w-4" /> Open draft
                        </Button>
                      )}
                    </div>
                  </>
                )}
                {id === "confirmed" && (
                  <>
                    <ReplyCard
                      from={a.reply.from}
                      role={a.reply.role}
                      at={a.reply.at.split(" ")[1]}
                      text={a.reply.text}
                      playKey={`${caseId}:reply`}
                      onDone={() => setReplied(true)}
                    />
                    {replied && (
                      <div className="animate-enter flex flex-col gap-2 rounded-lg border bg-muted/20 px-3 py-2">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <span className="text-xs font-semibold text-foreground">{a.portal}</span>
                          <CheckChip result={appointmentRun.slotInsideWindow ? "pass" : "flag"}>Inside OTIF window</CheckChip>
                        </div>
                        <FillFields
                          playKey={`${caseId}:lock`}
                          onDone={ready.confirmed}
                          columns={2}
                          fields={[
                            { label: "Appointment", value: a.appointment.id, mono: true },
                            { label: "Dock", value: a.appointment.door },
                            { label: "Window", value: a.appointment.label },
                            { label: "PO", value: a.poNumber, mono: true },
                            { label: "Load", value: a.tmsPlan.loadId, mono: true },
                            { label: "Calendar", value: "Blocked", strong: true },
                          ]}
                          stamp={
                            <span className="rounded border-2 border-[var(--success)] px-2 py-0.5 text-[11px] font-bold uppercase tracking-widest text-[var(--success)]">
                              Booked
                            </span>
                          }
                        />
                        <SourceDocTrigger doc={buildRunAConfirmationDoc()} label="Slot confirmation" variant="ghost" className="self-start" />
                      </div>
                    )}
                  </>
                )}
                {id === "replan" && (
                  <>
                    <AiStageNarration
                      variant="inline"
                      playKey={`${caseId}:n:replan`}
                      text={`The slot is ${shortStamp(`${a.appointment.day} ${a.appointment.from}`)} but TMS still plans ${shortStamp(a.tmsPlan.eta)}. Pushing a replan so the truck arrives for the slot.`}
                    />
                    <StagedChangeTable
                      title={`Replan ${a.replan.id} · ${a.tmsPlan.loadId}`}
                      system={TMS_SYSTEM}
                      playKey={`${caseId}:replan`}
                      onDone={ready.replan}
                      rows={[
                        { key: "pickup", label: "Pickup", from: shortStamp(a.tmsPlan.pickup), to: shortStamp(a.replan.pickup) },
                        { key: "eta", label: "Expected delivery", from: shortStamp(a.tmsPlan.eta), to: shortStamp(a.replan.eta) },
                        { key: "appt", label: "Appointment", from: "—", to: a.appointment.id },
                        { key: "carrier", label: "Carrier", from: a.tmsPlan.carrier, to: a.tmsPlan.carrier, unchanged: true },
                        { key: "rate", label: "Rate", from: formatUsd(a.tmsPlan.rateUsd), to: formatUsd(a.tmsPlan.rateUsd), unchanged: true },
                      ]}
                      footer={`Replan ${a.replan.id} accepted by TMS · ${a.replan.acceptedAt.split(" ")[1]}`}
                      footerTrailing={<CheckChip result="pass" />}
                    />
                    <SourceDocTrigger doc={buildRunAReplanDoc()} label={`Replan ${a.replan.id}`} className="self-start" />
                  </>
                )}
              </RunStageCard>
            );
          })}
        </div>
        <div className="lg:sticky lg:top-4 lg:self-start">
          <RunAgentLog caseId={caseId} />
        </div>
      </div>

      {emailOpen && (
        <EmailDraftDialog
          to={a.buyer.email}
          toOrg={`${a.buyer.name} · ${a.buyer.role}`}
          subject={`Receiving slot needed at RDC 6094 by Wed 08-26 · ${a.poNumber}`}
          body={`Hi ${a.buyer.name.split(" ")[0]},\n\n${a.poNumber} (${a.orderId}, ${a.tmsPlan.load.split(" · ")[0]}) is planned into RDC 6094, but the scheduling portal has no open receiving slot from Mon 08-24 through the MABD, Wed 08-26. The first open slot is ${firstOpen}, which would miss OTIF.\n\nCould you ask RDC 6094 to open a slot on or before Wed 08-26? Our carrier can deliver any time in that window.\n\nThank you,\nCustomer Service — Order Management`}
          attachment={{ name: RDC_6094_SNAPSHOT.fileName, meta: `${a.portal} · Mon–Thu`, pages: calendarSnapshotPages() }}
          sentLabel="Slot request sent"
          onSend={handleSend}
          onClose={() => setEmailOpen(false)}
        />
      )}

      {done && !finaleDismissed && (
        <RunCompleteModal
          eyebrow="Shipment resolved"
          title={`${caseId} back inside the OTIF window`}
          narrative={`Slot booked inside the window · TMS replanned · ${formatUsd(0)} cost change.`}
          stats={[
            { label: "Slot", value: `Tue ${a.appointment.from}` },
            { label: "New ETA", value: `${shortStamp(a.replan.eta).split(" ")[0]} ${a.replan.eta.split(" ")[1]}`, tone: "success" },
            { label: "Order value protected", value: formatUsd(a.valueUsd) },
          ]}
          docs={[
            { doc: buildRunAConfirmationDoc(), label: "Slot confirmation" },
            { doc: buildRunAReplanDoc(), label: `Replan ${a.replan.id}` },
          ]}
          primaryLabel={backLabel ?? "Back to Track & Trace"}
          onPrimary={onBack}
          secondaryLabel="Stay here"
          onSecondary={() => setFinaleDismissed(true)}
          exportCaseId={caseId}
        />
      )}
    </div>
  );
}
