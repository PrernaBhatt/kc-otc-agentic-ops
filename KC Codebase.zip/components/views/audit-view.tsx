"use client";

import { useEffect, useMemo, useState } from "react";
import { Download } from "lucide-react";

import { Button } from "@/components/ui/button";
import { AuditKpiRow } from "@/components/mounts/audit/audit-kpis";
import { AuditFilterBar, AuditTable } from "@/components/mounts/audit/audit-table";
import { AuditRail } from "@/components/mounts/audit/audit-rail";
import {
  AuditExportDialog,
  type AuditExportScope,
} from "@/components/mounts/audit/audit-export-dialog";
import {
  EMPTY_AUDIT_FILTER,
  auditKpis,
  auditModules,
  filterAudit,
  sortNewestFirst,
  type AuditFilter,
} from "@/lib/audit-selectors";
import { auditSeed } from "@/lib/data/audit-seed";
import { findAccount } from "@/lib/data/account-owners";
import { useOtcStore } from "@/lib/store";

const SEED_IDS = new Set(auditSeed.map((e) => e.entryId));

export function AuditView() {
  const { auditLog, auditPreset, clearAuditPreset } = useOtcStore();
  const [filter, setFilter] = useState<AuditFilter>(() => ({
    ...EMPTY_AUDIT_FILTER,
    controlRef: auditPreset?.controlRef ?? "all",
    accountId: auditPreset?.accountId ?? "all",
    query: auditPreset?.caseId ?? "",
  }));
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [exportOpen, setExportOpen] = useState(false);

  useEffect(() => {
    if (!auditPreset) return;
    setFilter({
      ...EMPTY_AUDIT_FILTER,
      controlRef: auditPreset.controlRef ?? "all",
      accountId: auditPreset.accountId ?? "all",
      query: auditPreset.caseId ?? "",
    });
    clearAuditPreset();
  }, [auditPreset, clearAuditPreset]);

  const all = useMemo(() => sortNewestFirst(auditLog), [auditLog]);
  const filtered = useMemo(() => filterAudit(all, filter), [all, filter]);
  const kpis = useMemo(() => auditKpis(filtered), [filtered]);
  const modules = useMemo(() => auditModules(all), [all]);
  const freshIds = useMemo(
    () => new Set(all.filter((e) => !SEED_IDS.has(e.entryId)).map((e) => e.entryId)),
    [all]
  );
  const selected = filtered.find((e) => e.entryId === selectedId) ?? null;

  const scopes: AuditExportScope[] = useMemo(() => {
    const list: AuditExportScope[] = [
      { id: "filtered", label: "Current filters", slug: "filtered", entries: filtered },
    ];
    if (selected) {
      list.push({
        id: "case",
        label: `Case ${selected.caseId}`,
        slug: selected.caseId.toLowerCase(),
        entries: all.filter((e) => e.caseId === selected.caseId),
      });
    }
    if (filter.accountId !== "all") {
      const account = findAccount(filter.accountId);
      list.push({
        id: "account",
        label: `Account ${account?.shortName ?? filter.accountId}`,
        slug: (account?.shortName ?? filter.accountId).toLowerCase(),
        entries: all.filter((e) => e.accountId === filter.accountId),
      });
    }
    list.push({ id: "all", label: "All entries", slug: "all", entries: all });
    return list;
  }, [all, filtered, selected, filter.accountId]);

  return (
    <div className="animate-enter flex flex-col gap-6">
      <div className="flex items-center justify-between gap-3">
        <h2 className="text-xl font-semibold text-foreground">Audit trail</h2>
        <Button size="sm" onClick={() => setExportOpen(true)}>
          <Download className="h-4 w-4" /> Export
        </Button>
      </div>

      <AuditKpiRow kpis={kpis} />

      <AuditFilterBar filter={filter} onChange={setFilter} modules={modules} />

      <div className="grid items-start gap-4 lg:grid-cols-[minmax(0,1fr)_380px]">
        <AuditTable
          entries={filtered}
          selectedId={selected?.entryId ?? null}
          onSelect={setSelectedId}
          freshIds={freshIds}
        />
        {selected ? (
          <AuditRail entry={selected} all={all} onClose={() => setSelectedId(null)} />
        ) : (
          <div className="hidden rounded-xl border border-dashed p-6 text-center text-sm text-muted-foreground lg:block">
            Select an entry to see its control, evidence and signature.
          </div>
        )}
      </div>

      {exportOpen && (
        <AuditExportDialog
          scopes={scopes}
          defaultScopeId={selected ? "case" : "filtered"}
          onClose={() => setExportOpen(false)}
        />
      )}
    </div>
  );
}
