"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useMounted } from "@/lib/hooks/use-mounted";
import {
  ArrowLeft,
  Banknote,
  Check,
  ChevronRight,
  CircleCheck,
  ClipboardList,
  Landmark,
  Link2,
  Mail,
  Scale,
  Pencil,
  ThumbsUp,
  X,
} from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import { Spinner } from "@/components/agents/spinner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { SignedApproveButton } from "@/components/shared/signed-approve-button";
import { findAccount } from "@/lib/data/account-owners";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  SourceDocTrigger,
  SourceDocRowTrigger,
} from "@/components/modals/source-doc-preview";
import { formatUsd } from "@/lib/chargeback-selectors";
import { TODAY } from "@/lib/data/clock";
import {
  promoClaimSplit,
  promoClaimAccounting,
  renderPromoClaimLetter,
  PROMO_CATEGORY_LABEL,
} from "@/lib/promo-claim-selectors";
import type { PromoLineCategory } from "@/lib/data/promo-claims";
import {
  buildPromoDeductionDoc,
  buildPromotionAgreementDoc,
  buildProofOfPerformanceDoc,
  buildProofSourceDoc,
  buildStoreExceptionDoc,
  buildPromoLetterDoc,
  buildStoreListDoc,
  buildSkuListDoc,
} from "@/lib/docs-promo-claims";
  import { useOtcStore } from "@/lib/store";
import { ClaimEditModal } from "@/components/modals/claim-edit-modal";
import { cn } from "@/lib/utils";
import { SystemMark } from "@/components/shared/system-badge";

import {
  AiStageNarration,
  narrationDwellMs,
} from "@/components/mounts/chargebacks/ai-stage-narration";
import {
  AgentAuditTrail,
  RunStageRow,
  RUN_STAGE_BODY_CLASS,
  RUN_STAGE_CARD_CLASS,
} from "@/components/mounts/shared/run-stage-row";
import { StageProgressRail } from "@/components/mounts/shared/stage-progress-rail";
import { RunCompleteModal } from "@/components/mounts/shared/run-complete-modal";
import { GtnImpactPanel } from "@/components/mounts/deductions/gtn-impact-panel";
import { DisputeLetterComposer } from "@/components/mounts/deductions/dispute-letter-composer";
import { StoreProofMatrix, ExceptionSplitBar } from "@/components/views/promo/promo-visuals";
import { AgentDecision } from "@/components/mounts/deductions/agent-decision";

type SimStatus = "waiting" | "running" | "passed" | "needsReview";

/**
 * Scenario 1 — incomplete proof of promotion, in seven steps.
 *
 * The claim arrives without a clean promotion reference and bundles many
 * stores, weeks and SKUs into one lump sum. The run has to (1) match it to the
 * right promotion, (2) gather proof of performance from several systems, (3)
 * build a store-level exception list, and (4) split the claim into a supported
 * part and a billed-back part a person approves. Three steps are gates: the
 * promotion match, the partial-approval decision and the outgoing letter.
 */
const STAGES = [
  {
    id: "intake",
    label: "Deduction",
    heading: "Deduction taken against the invoice",
    agent: "Deduction Intake Agent",
    agentType: "orchestrator",
    icon: Banknote,
    log: "Short payment matched to the invoice. Booked as a promotion allowance.",
  },
  {
    id: "match",
    label: "Promotion match",
    heading: "Claim matched to the promotion",
    agent: "Promotion Matching Agent",
    agentType: "validation",
    icon: Link2,
    log: "Retailer event number resolved to one of our promotions. Confirmation required.",
  },
  {
    id: "evidence",
    label: "Proof of performance",
    heading: "Proof of performance gathered",
    agent: "Proof of Performance Agent",
    agentType: "document",
    icon: ClipboardList,
    log: "Evidence gathered from six sources and reconciled against the claim.",
  },
  {
    id: "validate",
    label: "Store validation",
    heading: "Store, date and SKU eligibility",
    agent: "Claim Validation Agent",
    agentType: "validation",
    icon: Scale,
    log: "Store-level exception list built. Claim split into supported and unsupported.",
  },
  {
    id: "decision",
    label: "Decision",
    heading: "Partial approval",
    agent: "Trade Finance Agent",
    agentType: "credit",
    icon: Check,
    log: "Split prepared. Awaiting a decision.",
  },
  {
    id: "letter",
    label: "Retailer response",
    heading: "Retailer response",
    agent: "Correspondence Agent",
    agentType: "invoice",
    icon: Mail,
    log: "Response drafted with the exception list. Not yet issued.",
  },
  {
    id: "impact",
    label: "Impact",
    heading: "Trade spend and accounting impact",
    agent: "Revenue Accounting Agent",
    agentType: "invoice",
    icon: Landmark,
    log: "Only the supported part draws the trade-promotion accrual.",
  },
] as const;

const STAGE_DWELL_MS = 4000;

const asText = (n: string | string[] | undefined) =>
  Array.isArray(n) ? n.join("\n") : (n ?? "");

export function PromoClaimRun({
  caseId,
  onBack,
}: {
  caseId: string;
  onBack: () => void;
}) {
  const { resolvePromoClaim, claimEdits, setClaimEdit } = useOtcStore();
  const edit = claimEdits[caseId];
  const split = promoClaimSplit(caseId, edit);
  const accounting = promoClaimAccounting(caseId, edit);
  const anchorSupported = promoClaimSplit(caseId)?.supported ?? 0;

  const [statuses, setStatuses] = useState<Record<string, SimStatus>>(() =>
    Object.fromEntries(STAGES.map((s) => [s.id, "waiting" as SimStatus]))
  );
  const [openStages, setOpenStages] = useState<Set<string>>(new Set());
  const [activeStage, setActiveStage] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);
  const [awaitingAdvance, setAwaitingAdvance] = useState(false);
  const [matchConfirmed, setMatchConfirmed] = useState(false);
  const [matchSystemsCleared, setMatchSystemsCleared] = useState(false);
  const [decided, setDecided] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [letterSent, setLetterSent] = useState(false);
  const [sentOn, setSentOn] = useState<string | undefined>(undefined);
  const [finaleDismissed, setFinaleDismissed] = useState(false);

  const advanceRef = useRef<(() => void) | null>(null);
  const startedRef = useRef(false);
  const matchRef = useRef(false);
  const decidedRef = useRef(false);
  const letterRef = useRef(false);
  const cardRefs = useRef<Record<string, HTMLDivElement | null>>({});

  const narration: Record<string, string | string[]> = split
    ? {
  intake: `${split.case.customerName} withheld ${formatUsd(split.claimed)} as a feature-and-display allowance under event ${split.case.retailerEventRef}.`,
  match: [
  `The deduction carries the retailer's event number, not our promotion ID.`,
  `Matched on customer, dates, SKUs and stores to ${split.case.promotion.promotionId} — ${split.case.promotion.name}. Confirmation required.`,
  ],
  evidence: `Querying ${split.case.proofSources.length} sources store by store.`,
  validate: `${split.exceptionStores} stores fail a store, date or SKU test.`,
  decision: `AI recommends partial approval — approve ${formatUsd(split.supported)} and bill back ${formatUsd(split.billBack)}.`,
  letter: `Response ${split.case.responseLetter.letterRef} drafted with the store-level exception list. Approval required before sending.`,
  impact: `${formatUsd(split.supported)} draws the ${split.case.promotion.accrualId} accrual; ${formatUsd(split.billBack)} remains collectible.`,
      }
    : {};
  const narrationRef = useRef(narration);
  narrationRef.current = narration;

  const openStage = useCallback((id: string) => {
    setOpenStages(new Set([id]));
    setActiveStage(id);
  }, []);

  const runFrom = useCallback(
    async (startId: string) => {
      setProcessing(true);
      const from = Math.max(0, STAGES.findIndex((s) => s.id === startId));
      for (const stage of STAGES.slice(from)) {
        if (stage.id === "match" && !matchRef.current) {
          setStatuses((p) => ({ ...p, match: "needsReview" }));
          setMatchSystemsCleared(false);
          openStage("match");
          setProcessing(false);
          return;
        }
        if (stage.id === "decision" && !decidedRef.current) {
          setStatuses((p) => ({ ...p, decision: "needsReview" }));
          openStage("decision");
          setProcessing(false);
          return;
        }
        if (stage.id === "letter" && !letterRef.current) {
          setStatuses((p) => ({ ...p, letter: "needsReview" }));
          openStage("letter");
          setProcessing(false);
          return;
        }
        setStatuses((p) => ({ ...p, [stage.id]: "running" }));
        openStage(stage.id);

        let marked = false;
        const markPassed = () => {
          if (marked) return;
          marked = true;
          setStatuses((p) => ({ ...p, [stage.id]: "passed" }));
        };
        const dwell = setTimeout(
          markPassed,
          narrationDwellMs(asText(narrationRef.current[stage.id]), STAGE_DWELL_MS)
        );
        const advanced = new Promise<void>((r) => {
          advanceRef.current = r;
        });
        setAwaitingAdvance(true);
        await advanced;
        setAwaitingAdvance(false);
        clearTimeout(dwell);
        markPassed();
      }
      setProcessing(false);
      setActiveStage(null);
    },
    [openStage]
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Enter") return;
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      if (!advanceRef.current) return;
      e.preventDefault();
      const go = advanceRef.current;
      advanceRef.current = null;
      go();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    if (startedRef.current || !split) return;
    startedRef.current = true;
    void runFrom("intake");
  }, [runFrom, split]);

  useEffect(() => {
    if (!activeStage) return;
    const node = cardRefs.current[activeStage];
    node?.scrollIntoView({ behavior: "smooth", block: "center" });
  }, [activeStage]);

  useEffect(() => {
    if (!matchConfirmed) return;
    setStatuses((p) => ({ ...p, match: "passed" }));
    void runFrom("evidence");
  }, [matchConfirmed, runFrom]);

  useEffect(() => {
    if (!decided) return;
    setStatuses((p) => ({ ...p, decision: "passed" }));
    void runFrom("letter");
  }, [decided, runFrom]);

  useEffect(() => {
    if (!letterSent) return;
    setStatuses((p) => ({ ...p, letter: "passed" }));
    void runFrom("impact");
  }, [letterSent, runFrom]);

  useEffect(() => {
    if (statuses.impact === "passed") resolvePromoClaim(caseId);
  }, [statuses.impact, resolvePromoClaim, caseId]);

  if (!split || !accounting) return null;

  const c = split.case;
  const p = c.promotion;
  const doneCount = STAGES.filter((s) => statuses[s.id] === "passed").length;
  const reached: string[] = STAGES.filter(
    (s) => statuses[s.id] !== "waiting"
  ).map((s) => s.id);

  const decisionReasoning = [
    `${split.supportedStores} of ${split.claimedStores} stores have full proof of performance.`,
    `The other ${split.exceptionStores} stores fail on list, window or SKU — ${formatUsd(split.billBack)} can't be approved.`,
    `Decision: approve ${formatUsd(split.supported)}, bill back ${formatUsd(split.billBack)}.`,
  ];
  const renderStage = (stageId: string) =>
    stageId === "decision" ? (
      <AgentDecision stepKey={`${caseId}:decision`} lines={decisionReasoning}>
        {renderBody(stageId)}
      </AgentDecision>
    ) : (
      renderBody(stageId)
    );

  const renderBody = (id: string) => {
    switch (id) {
      case "intake":
        return (
          <div className="space-y-3">
            <PaymentSplitBar split={split} />
            <SourceDocTrigger
              doc={buildPromoDeductionDoc(caseId)}
              label="View the deduction backup"
            />
          </div>
        );
      case "match":
        return (
          <div className="space-y-3">
            <PromotionMatchCard split={split} caseId={caseId} />
            {matchConfirmed ? (
              <p className="flex items-center gap-1.5 text-xs text-[var(--success)]">
                <ThumbsUp className="h-3.5 w-3.5" />
                Confirmed by you — deduction belongs to {p.promotionId}.
              </p>
            ) : (
              <div className="flex flex-wrap items-center gap-3 rounded-lg border-2 border-amber-200 bg-amber-50/60 px-3 py-2.5">
                <span className="text-xs text-amber-900">
                  Confirm the promotion match before proof of performance is
                  gathered. Nothing is recorded until you click.
                </span>
                <Button
                  size="sm"
                  className="whitespace-nowrap"
                  onClick={() => {
                    matchRef.current = true;
                    setMatchConfirmed(true);
                  }}
                >
                  Confirm match to {p.promotionId}
                </Button>
              </div>
            )}
          </div>
        );
      case "evidence":
        return <StoreProofMatrix split={split} caseId={caseId} />;
      case "validate":
        return <ExceptionSplitBar split={split} caseId={caseId} />;
      case "decision":
        return (
          <div className="space-y-3">
            <div className="grid gap-3 sm:grid-cols-3">
              <div className="rounded-lg border-2 border-[var(--success)]/40 bg-[var(--success)]/5 p-3">
                <p className="text-xs text-muted-foreground">Approve</p>
                <p className="text-2xl font-bold text-[var(--success)]">
                  {formatUsd(split.supported)}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {split.supportedStores} evidenced stores
                </p>
              </div>
              <div className="rounded-lg border-2 border-amber-300 bg-amber-50 p-3">
                <p className="text-xs text-muted-foreground">Bill back</p>
                <p className="text-2xl font-bold text-amber-700">
                  {formatUsd(split.billBack)}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {split.exceptionStores} stores in exception
                </p>
              </div>
              <div className="rounded-lg border-2 border-muted bg-muted/30 p-3">
                <p className="text-xs text-muted-foreground">Claimed</p>
                <p className="text-2xl font-bold tabular-nums">
                  {formatUsd(split.claimed)}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {split.claimedStores} stores billed
                </p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <SourceDocTrigger
                doc={buildStoreListDoc(caseId)}
                label={`View all ${split.claimedStores} stores billed`}
              />
              <SourceDocTrigger
                doc={buildSkuListDoc(caseId)}
                label="View SKUs billed"
              />
              <SourceDocTrigger
                doc={buildStoreListDoc(caseId, { approvedOnly: true })}
                label={`View ${split.supportedStores} approved stores`}
                variant="secondary"
              />
              <SourceDocTrigger
                doc={buildSkuListDoc(caseId, { approvedOnly: true })}
                label="View approved SKUs"
                variant="secondary"
              />
            </div>
            {decided ? (
              <p className="flex items-center gap-1.5 text-xs text-[var(--success)]">
                <ThumbsUp className="h-3.5 w-3.5" />
                Decided by you — approve {formatUsd(split.supported)}, bill back{" "}
                {formatUsd(split.billBack)}.
              </p>
            ) : (
              <div className="flex flex-wrap items-center gap-3 rounded-lg border-2 border-amber-200 bg-amber-50/60 px-3 py-2.5">
                <span className="text-xs text-amber-900">
                  Awaiting your decision. Nothing is recorded until you click.
                </span>
                <div className="flex flex-wrap items-center gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="whitespace-nowrap gap-1.5"
                    onClick={() => setEditOpen(true)}
                  >
                    <Pencil className="h-3.5 w-3.5" />
                    Edit
                  </Button>
                  <SignedApproveButton
                    gateId={`${caseId}:G1`}
                    title="Settle the promotion claim"
                    caseId={c.caseId}
                    accountId={findAccount(c.customerName)?.accountId ?? ""}
                    module="Deductions"
                    system="Vistex"
                    controls={["1.7.3", "1.4.4"]}
                    evidence={[
                      { id: "event", label: `Retailer event ${c.retailerEventRef}`, system: "Vistex" },
                      { id: "pop", label: "Proof of performance checked", system: "Vistex" },
                    ]}
                    lines={[
                      { label: "Supported claim", amountUsd: split.supported, kind: "other" },
                      { label: "Bill-back", amountUsd: split.billBack, kind: "charge-back" },
                    ]}
                    attestation={`I approve ${formatUsd(split.supported)} with proof of performance and bill back ${formatUsd(split.billBack)} on ${c.caseId}.`}
                    action={`Approved ${formatUsd(split.supported)}, bill-back ${formatUsd(split.billBack)}`}
                    decision="Partially approved"
                    onSigned={() => {
                      decidedRef.current = true;
                      setDecided(true);
                    }}
                  >
                    Approve {formatUsd(split.supported)} · bill back{" "}
                    {formatUsd(split.billBack)}
                  </SignedApproveButton>
                </div>
              </div>
            )}
          </div>
        );
      case "letter": {
        const letter = renderPromoClaimLetter(caseId, edit)!;
        return (
          <DisputeLetterComposer
            letterKey={c.caseId}
            from={`${c.responseLetter.from} <trade.finance@internal.example>`}
            to={`${c.responseLetter.to} <deductions@retailer.example>`}
            subject={letter.subject}
            body={letter.body}
            attachments={[
              {
                doc: buildPromoDeductionDoc(caseId),
                label: `Deduction ${c.remittanceId}`,
              },
              {
                doc: buildPromotionAgreementDoc(caseId),
                label: `Agreement ${p.promotionId}`,
              },
              {
                doc: buildStoreExceptionDoc(caseId),
                label: "Store-level exception list",
              },
              {
                doc: buildPromoLetterDoc(caseId, letterSent),
                label: "Letter as a document",
              },
            ]}
            sent={letterSent}
            sentDate={sentOn}
            sentNote={`Issued to ${c.customerName} deduction management. Repayment of ${formatUsd(split.billBack)}, or supporting evidence, requested within 30 days.`}
            canSend={statuses.letter === "needsReview"}
            blockedNote="Take the decision first."
            onSend={() => {
              letterRef.current = true;
              setSentOn(TODAY);
              setLetterSent(true);
            }}
          />
        );
      }
      case "impact":
        return (
          <GtnImpactPanel
            shortPay={split.claimed}
            gtnImpact={accounting.gtnImpact}
            recoveryRequired={accounting.recoveryRequired}
            basis={`${formatUsd(split.supported)} of supported allowance draws the ${p.accrualId} trade-promotion accrual, as it was already reserved for ${p.promotionId}. ${formatUsd(split.billBack)} failed a store, date or SKU test, is not a cost at all, and remains collectible.`}
            lines={accounting.lines}
            caseRef={c.caseId}
            claimRef={p.promotionId}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      {editOpen && (
        <ClaimEditModal
          title="Edit promo claim approval"
          caseLabel={`${split.case.caseId} — ${split.case.customerName} · ${formatUsd(split.claimed)} claimed`}
          total={split.claimed}
          primaryValue={split.supported}
          anchorValue={anchorSupported}
          leftLabel="Approve allowance"
          rightLabel="Bill back"
          leftHint="Draws the trade-promotion accrual"
          rightHint="Collectible from the customer"
          leftTone="success"
          rightTone="amber"
          aiRationale={`AI supports ${formatUsd(anchorSupported)} across evidenced stores and bills back the rest of the ${formatUsd(split.claimed)} claim. Adjust what you approve and the letter and postings follow.`}
          presets={[
            { id: "ai", label: "AI recommendation", detail: "Evidenced stores only", value: anchorSupported, ai: true },
            { id: "full", label: "Approve in full", detail: "Honor the full claim", value: split.claimed },
            { id: "half", label: "Meet halfway", detail: "Split the difference", value: Math.round((anchorSupported + split.claimed) / 2) },
            { id: "none", label: "Bill back all", detail: "Recover the full claim", value: 0 },
          ]}
          confirmLabel="Apply decision"
          onConfirm={(v) => {
            setClaimEdit(caseId, { approvedAmount: v });
            setEditOpen(false);
          }}
          onReset={() => {
            setClaimEdit(caseId, null);
            setEditOpen(false);
          }}
          onClose={() => setEditOpen(false)}
        />
      )}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <button
            type="button"
            onClick={onBack}
            className="mb-1 inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            All deductions
          </button>
          <h2 className="text-xl font-semibold">
            {c.caseId} — {c.customerName}
          </h2>
          <p className="text-sm text-muted-foreground">
            A promotion deduction that is part supported and part unproven. The
            claim is matched, the proof reconciled and the split proposed; the
            decision and the letter are yours.
          </p>
        </div>
        {processing && !awaitingAdvance && (
          <span className="flex items-center gap-2 text-sm text-muted-foreground">
            <Spinner size="sm" />
            Investigation in progress
          </span>
        )}
      </div>

      <Card className="bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="flex flex-wrap items-center gap-2 text-sm font-semibold">
            <Badge variant="outline" className="whitespace-nowrap">
              {formatUsd(split.claimed)} deducted on {c.invoiceId}
            </Badge>
            <span className="text-xs font-normal text-muted-foreground">
              {doneCount}/{STAGES.length} steps cleared
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-2">
          <StageProgressRail
            stages={STAGES}
            statuses={statuses}
            openStageId={activeStage}
            onStageClick={(id) => {
              if (reached.includes(id)) openStage(id);
            }}
          />
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[minmax(0,1fr)_320px]">
        <div className="space-y-4">
          {STAGES.filter((s) => reached.includes(s.id)).map((stage) => (
            <Card
              key={stage.id}
              ref={(el) => {
                cardRefs.current[stage.id] = el;
              }}
              className={RUN_STAGE_CARD_CLASS}
            >
              <RunStageRow
                label={stage.heading}
                status={statuses[stage.id]}
                expanded={openStages.has(stage.id)}
                summary={stage.log}
                onToggle={() =>
                  setOpenStages((prev) => {
                    const next = new Set(prev);
                    next.has(stage.id) ? next.delete(stage.id) : next.add(stage.id);
                    return next;
                  })}
              />
              {openStages.has(stage.id) &&
                (stage.id === "match" && !matchSystemsCleared ? (
                  <CardContent className="space-y-4 border-t px-4 py-4 animate-in fade-in slide-in-from-top-2 duration-300">
                    <MultiSystemMatchLoader
                      onDone={() => setMatchSystemsCleared(true)}
                    />
                  </CardContent>
                ) : (
                  <CardContent className="space-y-4 border-t px-4 py-4 animate-in fade-in slide-in-from-top-2 duration-300">
                    {narration[stage.id] && stage.id !== "decision" && (
                      <AiStageNarration key={stage.id} text={narration[stage.id]} variant="inline" />
                    )}
                    {renderStage(stage.id)}
                  </CardContent>
                ))}
            </Card>
          ))}
        </div>

        <AgentAuditTrail
          entries={STAGES.filter((s) => statuses[s.id] !== "waiting").map((s) => ({
            id: s.id,
            agent: s.agent,
            agentType: s.agentType,
            message: s.log,
            tone:
              statuses[s.id] === "needsReview"
                ? ("attention" as const)
                : statuses[s.id] === "running"
                  ? ("info" as const)
                  : ("success" as const),
          }))}
        />
      </div>

      {statuses.impact === "passed" && !finaleDismissed && (
        <RunCompleteModal
          eyebrow="Promotion claim resolved"
          title={`${c.caseId} split and answered`}
          narrative="The deduction was matched to its promotion, its proof of performance reconciled across six sources, and the claim split store by store. Only the supported allowance draws the trade-promotion accrual; the unproven remainder is billed back and stays collectible."
          stats={[
            { label: "claimed", value: formatUsd(split.claimed) },
            {
              label: "approved",
              value: formatUsd(split.supported),
              tone: "success",
            },
            {
              label: "billed back",
              value: formatUsd(split.billBack),
              tone: "danger",
            },
          ]}
          docs={[
            {
              doc: buildStoreExceptionDoc(caseId),
              label: "Store-level exception list",
            },
            {
              doc: buildPromoLetterDoc(caseId, true),
              label: `Retailer response ${c.responseLetter.letterRef}`,
            },
          ]}
          primaryLabel="Back to deductions"
          onPrimary={() => {
            setFinaleDismissed(true);
            onBack();
          }}
          secondaryLabel="Stay on this case"
          onSecondary={() => setFinaleDismissed(true)}
        />
      )}
    </div>
  );
}

/* ---------------------------------------------------------------- */

/** The invoice as one bar: what arrived, and what was deducted. */
function PaymentSplitBar({
  split,
}: {
  split: NonNullable<ReturnType<typeof promoClaimSplit>>;
}) {
  const c = split.case;
  const paidPct = (c.amountPaid / c.invoiceAmount) * 100;
  const mounted = useMounted();
  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-3 flex items-baseline justify-between gap-3">
        <h4 className="text-sm font-semibold">Payment against invoice</h4>
        <span className="whitespace-nowrap text-xs text-muted-foreground">
          {c.remittanceId} · {c.receivedDate}
        </span>
      </div>
      <div className="flex h-12 w-full overflow-hidden rounded-lg border-2">
        <div
          className="flex items-center justify-center bg-[var(--success)]/25 transition-all duration-700 ease-out motion-reduce:transition-none"
          style={{ width: mounted ? `${paidPct}%` : "0%" }}
        >
          <span className="text-sm font-semibold text-green-800 tabular-nums">
            {formatUsd(c.amountPaid)} paid
          </span>
        </div>
        <div
          className="flex flex-1 items-center justify-center transition-all duration-500 ease-out motion-reduce:transition-none"
          style={{
            opacity: mounted ? 1 : 0,
            transitionDelay: "600ms",
            backgroundImage:
              "repeating-linear-gradient(45deg, rgba(220,38,38,0.20) 0 6px, transparent 6px 12px)",
          }}
        >
          <span className="whitespace-nowrap px-1 text-xs font-semibold text-red-700 tabular-nums">
            {formatUsd(split.claimed)}
          </span>
        </div>
      </div>
      <p className="mt-2 text-xs text-muted-foreground">
        Invoice {formatUsd(c.invoiceAmount)} less {formatUsd(split.claimed)}{" "}
        withheld equals {formatUsd(c.amountPaid)} paid.{" "}
        {split.reconciles ? "Reconciles." : "Does not reconcile."}
      </p>
      <p className="mt-3 rounded border-l-2 border-muted-foreground/40 bg-muted/30 px-3 py-2 text-xs italic text-muted-foreground">
        &ldquo;{c.customerNote}&rdquo; — remittance note
      </p>
    </div>
  );
}

/**
 * Before the promotion match can be shown, the agent has to query every TPM
 * system that might hold the retailer's event — Vistex, Promax, CAS and SAP
 * each own a slice of promotion data, and none of them talk to each other.
 * This renders that reconciliation as a one-shot sequence: one system at a
 * time, spinning, then checked off, before the next starts. Once all four
 * have cleared, `onDone` reveals the actual match.
 */
const PROMO_MATCH_SYSTEMS = ["Vistex", "Promax", "CAS", "SAP"] as const;
const SYSTEM_QUERY_MS = 650;
const SYSTEM_CLEAR_MS = 320;

function MultiSystemMatchLoader({ onDone }: { onDone: () => void }) {
  const [index, setIndex] = useState(0);
  const [cleared, setCleared] = useState(false);
  const [exiting, setExiting] = useState(false);
  const onDoneRef = useRef(onDone);
  onDoneRef.current = onDone;

  useEffect(() => {
    if (index >= PROMO_MATCH_SYSTEMS.length) {
      const t = setTimeout(() => onDoneRef.current(), 200);
      return () => clearTimeout(t);
    }
    setCleared(false);
    setExiting(false);
    const clearTimer = setTimeout(() => setCleared(true), SYSTEM_QUERY_MS);
    const exitTimer = setTimeout(
      () => setExiting(true),
      SYSTEM_QUERY_MS + SYSTEM_CLEAR_MS
    );
    const nextTimer = setTimeout(
      () => setIndex((i) => i + 1),
      SYSTEM_QUERY_MS + SYSTEM_CLEAR_MS + 220
    );
    return () => {
      clearTimeout(clearTimer);
      clearTimeout(exitTimer);
      clearTimeout(nextTimer);
    };
  }, [index]);

  if (index >= PROMO_MATCH_SYSTEMS.length) return null;
  const system = PROMO_MATCH_SYSTEMS[index];

  return (
    <div className="space-y-3" aria-live="polite">
      <div
        key={system}
        className={cn(
          "flex items-center gap-2 text-sm transition-opacity duration-200",
          exiting
            ? "opacity-0"
            : "animate-in fade-in slide-in-from-left-1 duration-300"
        )}
      >
        {cleared ? (
          <CircleCheck className="h-3.5 w-3.5 shrink-0 text-[var(--success)]" />
        ) : (
          <Spinner size="sm" className="text-primary" />
        )}
        <span
          className={cn(
            "text-foreground",
            cleared && "text-muted-foreground line-through"
          )}
        >
          Matching promotions with {system}
        </span>
      </div>
      <div className="mt-3 flex gap-1.5">
        {PROMO_MATCH_SYSTEMS.map((sys, i) => (
          <span
            key={sys}
            className={cn(
              "h-1 flex-1 rounded-full transition-colors duration-300",
              i < index || (i === index && cleared)
                ? "bg-[var(--success)]"
                : i === index
                  ? "bg-primary/50"
                  : "bg-muted"
            )}
          />
        ))}
      </div>
    </div>
  );
}

/** The retailer event number resolved to our promotion, with the terms. */
function PromotionMatchCard({
  split,
  caseId,
}: {
  split: NonNullable<ReturnType<typeof promoClaimSplit>>;
  caseId: string;
}) {
  const c = split.case;
  const p = c.promotion;
  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-3 flex items-baseline justify-between gap-3">
        <h4 className="text-sm font-semibold">Promotion match</h4>
        <span className="inline-flex items-center gap-1.5 whitespace-nowrap text-xs text-muted-foreground">
          <SystemMark name={p.tpmSystem} />
          {p.tpmSystem}
        </span>
      </div>
      <div className="flex flex-wrap items-center gap-2 text-sm">
        <Badge variant="outline" className="font-mono">
          {c.retailerEventRef}
        </Badge>
        <span className="text-muted-foreground">resolves to</span>
        <Badge className="bg-primary/10 font-mono text-primary">
          {p.promotionId}
        </Badge>
      </div>
      <p className="mt-2 text-sm font-medium">{p.name}</p>
      <div className="mt-3 grid gap-2 text-xs text-muted-foreground sm:grid-cols-2">
        <span>
          Window: {p.windowStart} to {p.windowEnd} ({p.weeks} weeks)
        </span>
        <span>Approved stores: {p.approvedStores}</span>
        <span>Tactic: {p.tactic}</span>
        <span>Rate: {p.rateBasis}</span>
      </div>
      <div className="mt-3 flex flex-wrap gap-2 border-t pt-3">
        <SourceDocTrigger
          doc={buildPromoDeductionDoc(caseId)}
          label="View the deduction"
        />
        <SourceDocTrigger
          doc={buildPromotionAgreementDoc(caseId)}
          label={`View agreement ${p.promotionId}`}
        />
        <SourceDocTrigger
          doc={buildStoreListDoc(caseId)}
          label={`View all ${split.claimedStores} stores claimed`}
        />
        <SourceDocTrigger
          doc={buildSkuListDoc(caseId)}
          label="View SKUs claimed"
        />
      </div>
    </div>
  );
}
