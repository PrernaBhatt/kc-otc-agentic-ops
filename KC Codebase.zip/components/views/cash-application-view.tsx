"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { toast } from "sonner";
import {
  ArrowLeft,
  Banknote,
  Bot,
  Building2,
  CircleCheck,
  Clock,
  FileSearch,
  Gauge,
  Landmark,
  ListChecks,
  Mail,
  PieChart,
  ScanLine,
  Scale,
  Send,
  Sparkles,
  Wallet,
  X,
  Zap,
} from "lucide-react";

import { Spinner } from "@/components/agents/spinner";
 import { SystemBadge } from "@/components/shared/system-badge";
 import { EmailDraftDialog } from "@/components/shared/email-draft-dialog";
import { RemittanceRun } from "@/components/views/cash/remittance-run";
import { UnidentifiedPayerWorkspace } from "@/components/views/cash-scenario-unidentified-payer";
import { CrossEntityWorkspace } from "@/components/views/cash-scenario-cross-entity";
import { RunCompleteModal } from "@/components/mounts/shared/run-complete-modal";
import {
  SourceDocTrigger,
} from "@/components/modals/source-doc-preview";
import { Badge } from "@/components/ui/badge";
import { OwnerChip } from "@/components/shared/owner-chip";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CountUp } from "@/components/ui/count-up";
import {
  findCashPayment,
  formatCashUsd as formatUsd,
  lineTypeLabel,
  paymentQueueRows,
  paymentQueueSummary,
  paymentResolution,
} from "@/lib/cash-application-selectors";
import {
  AMOUNT_MATCH_TOLERANCE_USD,
  CASH_APP_SCOPE,
  cashAppMetrics,
  unappliedAging,
} from "@/lib/data/cash-application";
import type { CashPayment, RemittanceLine } from "@/lib/data/cash-application";
import {
  buildDeductionRegisterDoc,
  buildLockboxDoc,
  buildPostingDoc,
  buildRemittanceDoc,
  buildSapOpenItemDoc,
  deductionCaseId,
  slaDueLabel,
} from "@/lib/docs-cash-application";
import { useOtcStore } from "@/lib/store";
import { useTypewriter } from "@/lib/hooks/use-typewriter";
import { cn } from "@/lib/utils";

export function CashApplicationView() {
  const [openPaymentId, setOpenPaymentId] = useState<string | null>(null);

  if (!openPaymentId) {
    return <PaymentQueue onOpen={setOpenPaymentId} />;
  }

  const back = () => setOpenPaymentId(null);
  const payment = findCashPayment(openPaymentId);

  if (payment?.kind === "unidentified-payer") {
    return <UnidentifiedPayerWorkspace paymentId={openPaymentId} onBack={back} />;
  }
  if (payment?.kind === "cross-entity") {
    return <CrossEntityWorkspace paymentId={openPaymentId} onBack={back} />;
  }
  return <RemittanceRun paymentId={openPaymentId} onBack={back} />;
}

/* ---------------------------------------------------------------- *
 * Queue
 * ---------------------------------------------------------------- */

function PaymentQueue({ onOpen }: { onOpen: (paymentId: string) => void }) {
  const { postedCashPayments } = useOtcStore();
  const summary = paymentQueueSummary(postedCashPayments);
  const rows = paymentQueueRows(postedCashPayments);

  const tiles = [
    {
      label: "Payments awaiting decision",
      value: summary.paymentsAwaiting,
      format: (n: number) => String(Math.round(n)),
      tone: "default" as const,
    },
    {
      label: "Incoming cash",
      value: summary.incomingCash,
      format: formatUsd,
      tone: "default" as const,
    },
    {
      label: "Auto-matched",
      value: summary.autoMatched,
      format: formatUsd,
      tone: "success" as const,
    },
    {
      label: "Exception value",
      value: summary.exceptionValue,
      format: formatUsd,
      tone: "danger" as const,
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold">Cash application</h2>
        <p className="text-sm text-muted-foreground">
          Match incoming customer payments to invoices, credits and
          deductions before posting to SAP. Every payment is classified line
          by line, and every posting is approved by a person.
        </p>
        <p className="mt-1 text-xs text-muted-foreground">
          {CASH_APP_SCOPE}
        </p>
      </div>

      <div className="grid items-stretch gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {tiles.map((t) => (
          <Card key={t.label} className="flex h-full flex-col bg-card">
            <CardContent className="flex flex-1 flex-col p-4">
              <p className="text-xs text-muted-foreground">{t.label}</p>
              <p
                className={cn(
                  "mt-1 text-2xl font-bold tabular-nums",
                  t.tone === "success" && "text-[var(--success)]",
                  t.tone === "danger" && "text-red-600"
                )}
              >
                <CountUp value={t.value} format={t.format} />
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">
            Payments in the queue
          </CardTitle>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <table className="w-full min-w-[720px] text-sm">
            <thead>
              <tr className="border-b text-left text-xs text-muted-foreground">
                <th className="pb-2 font-medium">Payment</th>
                <th className="pb-2 font-medium">Customer</th>
                <th className="pb-2 font-medium">Received</th>
                <th className="pb-2 text-right font-medium">Amount</th>
                <th className="pb-2 text-center font-medium">Remittance</th>
                <th className="pb-2 text-center font-medium">Resolved</th>
                <th className="pb-2 text-right font-medium">Exception</th>
                <th className="pb-2 text-right font-medium">Action</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr
                  key={row.paymentId}
                  className={cn(
                    "border-b last:border-0",
                    row.status === "Cleared" && "text-muted-foreground"
                  )}
                >
                  <td className="py-2.5 font-medium">{row.paymentId}</td>
                  <td className="py-2.5">
                    <span className="flex flex-wrap items-center gap-2">
                      {row.customer}
                      <OwnerChip account={row.customer} variant="compact" />
                    </span>
                  </td>
                  <td className="py-2.5">{row.receivedDate}</td>
                  <td className="py-2.5 text-right tabular-nums">
                    {row.amountDisplay}
                  </td>
                  <td className="py-2.5 text-center tabular-nums">
                    {row.remittanceDisplay === "Not received" ? (
                      <span className="text-xs text-amber-600">Not received</span>
                    ) : (
                      row.remittanceDisplay
                    )}
                  </td>
                  <td className="py-2.5 text-center tabular-nums">
                    {row.resolvedDisplay}
                  </td>
                  <td className="py-2.5 text-right tabular-nums">
                    {row.exceptionDisplay !== "—" ? (
                      <span className="font-semibold text-red-600">
                        {row.exceptionDisplay}
                      </span>
                    ) : (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </td>
                  <td className="py-2.5 text-right">
                    {row.status === "Cleared" ? (
                      <span className="text-xs text-muted-foreground">
                        Cleared
                      </span>
                    ) : row.status === "Posted" ? (
                      <Badge
                        variant="outline"
                        className="border-[var(--success)]/30 bg-[var(--success)]/10 text-[var(--success)]"
                      >
                        Posted
                      </Badge>
                    ) : (
                      <Button
                        size="sm"
                        className="whitespace-nowrap"
                        onClick={() => onOpen(row.paymentId)}
                      >
                        Review payment
                      </Button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>

      <ProgramHealthCard />
    </div>
  );
}

/* ---------------------------------------------------------------- *
 * Programme health — book-wide context under the single demo case
 * ---------------------------------------------------------------- */

const KPI_ICONS: Record<string, typeof Bot> = {
  "Auto-match rate": Bot,
  "Cash application accuracy": CircleCheck,
  "Touchless posting": Zap,
  "Avg. time to apply": Clock,
  "Unapplied cash": Wallet,
  "Residual rate": PieChart,
};

function ProgramHealthCard() {
  const agingTotal = unappliedAging.reduce((s, b) => s + b.amount, 0);
  const maxBucket = Math.max(...unappliedAging.map((b) => b.amount));

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_20rem]">
      <Card className="bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">
            Cash application performance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
            {cashAppMetrics.map((m) => {
              const Icon = KPI_ICONS[m.label] ?? Gauge;
              return (
                <div
                  key={m.label}
                  className="rounded-xl border border-border/60 bg-muted/30 p-4"
                >
                  <div className="flex items-center gap-2">
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                      <Icon className="h-4 w-4" />
                    </span>
                    <p className="text-xs text-muted-foreground">{m.label}</p>
                  </div>
                  <p className="mt-2.5 text-2xl font-bold tabular-nums">
                    {m.value}
                  </p>
                  {m.trend && (
                    <p className="mt-1.5 inline-flex items-center rounded-full bg-[var(--success)]/10 px-2 py-0.5 text-xs font-medium text-[var(--success)]">
                      {m.trend}
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Card className="bg-card">
        <CardHeader className="pb-2">
          <div className="flex items-baseline justify-between">
            <CardTitle className="text-sm font-semibold">
              Unapplied cash by age
            </CardTitle>
            <span className="text-xs font-semibold tabular-nums">
              {formatUsd(agingTotal)}
            </span>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {unappliedAging.map((b) => (
            <div key={b.bucket}>
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">{b.bucket}</span>
                <span className="tabular-nums">
                  {formatUsd(b.amount)}
                  <span className="ml-1 text-muted-foreground">
                    · {b.items} {b.items === 1 ? "item" : "items"}
                  </span>
                </span>
              </div>
              <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-muted">
                <div
                  className={cn(
                    "h-full rounded-full",
                    b.tone === "ok" && "bg-[var(--success)]",
                    b.tone === "watch" && "bg-amber-500",
                    b.tone === "risk" && "bg-red-500"
                  )}
                  style={{ width: `${Math.round((b.amount / maxBucket) * 100)}%` }}
                />
              </div>
            </div>
          ))}
          <p className="pt-1 text-xs text-muted-foreground">
            Residual is held here, never written off — aged so nothing sits
            unexplained.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

