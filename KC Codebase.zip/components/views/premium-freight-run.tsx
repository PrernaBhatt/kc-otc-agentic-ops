"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { FileSignature, PenLine, Radar, Scale, Send } from "lucide-react";

import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { AiStageNarration } from "@/components/mounts/chargebacks/ai-stage-narration";
import { RunAgentLog } from "@/components/mounts/shared/run-agent-log";
import { RunCompleteModal } from "@/components/mounts/shared/run-complete-modal";
import { RunStageCard, type RunStageMeta } from "@/components/mounts/shared/run-stage-card";
import { StageProgressRail } from "@/components/mounts/shared/stage-progress-rail";
import { useFollowLatest } from "@/components/mounts/shared/use-follow-latest";
import { useStagedRun } from "@/components/mounts/shared/use-staged-run";
import { EtaWindowTrack } from "@/components/mounts/shipments/eta-window-track";
import { FreightOptions } from "@/components/mounts/shipments/freight-options";
import { ShipmentRunHeader } from "@/components/mounts/shipments/run-header";
import { CheckChip } from "@/components/shared/check-chip";
import { ControlTags } from "@/components/shared/control-tag";
import { FillFields } from "@/components/shared/fill-fields";
import { GateSignoffModal } from "@/components/shared/gate-signoff-modal";
import { StagedChangeTable } from "@/components/shared/staged-change-table";
import { TickList } from "@/components/shared/tick-list";
import { Button } from "@/components/ui/button";
import { PREMIUM_FREIGHT_LIMIT_USD, TRANSPORT_LEAD } from "@/lib/data/account-owners";
import { TMS_SYSTEM } from "@/lib/data/order-logistics";
import { PREMIUM_CASE, RISK_ROWS, type FreightOption } from "@/lib/data/shipment-risk";
import { buildPremiumPlanDoc, buildRunBOptionsDoc, buildRunBTmsPlanDoc } from "@/lib/docs-logistics";
import { formatUsd } from "@/lib/format";
import { optionOutcome, premiumFreight, shortStamp } from "@/lib/shipment-selectors";
import { useOtcStore } from "@/lib/store";

const ORDER = ["signal", "options", "plan", "approve", "tender"] as const;
type StageId = (typeof ORDER)[number];
const GATES = ["approve"] as const satisfies readonly StageId[];

const ICONS = { signal: Radar, options: Scale, plan: FileSignature, approve: PenLine, tender: Send } as const;
const CONTROLS = ["1.2.1"];
const AGENT = "Freight Planning Agent";

/**
 * Run B: the carrier rejected the tender and the TMS replan lands a day after
 * Kroger's window. The agent compares three recoveries, writes a premium
 * freight plan, and tenders the one the transportation manager approves.
 */
export function PremiumFreightRun({ onBack }: { onBack: () => void }) {
  const { appendAudit, resolveShipment } = useOtcStore();
  const b = PREMIUM_CASE;
  const caseId = b.caseId;
  const row = RISK_ROWS.find((r) => r.caseId === caseId);
  const keep = b.options.find((o) => o.id === "keep") as FreightOption;
  const team = b.options.find((o) => o.id === "team") as FreightOption;

  const [signOpen, setSignOpen] = useState(false);
  const [chosenId, setChosenId] = useState<FreightOption["id"]>("team");
  const [signalRead, setSignalRead] = useState(false);
  const [finaleDismissed, setFinaleDismissed] = useState(false);
  const cardRefs = useRef<Record<string, HTMLDivElement | null>>({});

  const chosen = b.options.find((o) => o.id === chosenId) as FreightOption;
  const chosenOut = optionOutcome(chosenId);
  const chosenPremium = Math.max(0, chosen.rateUsd - keep.rateUsd);
  const missDays = optionOutcome("keep").lateDays;

  const stages: Record<StageId, RunStageMeta> = useMemo(
    () => ({
      signal: { id: "signal", label: "Signal", heading: "TMS replan misses the Kroger window", agent: AGENT, summary: `ETA ${shortStamp(keep.eta)} · window ${b.appointment.label}` },
      options: { id: "options", label: "Options", heading: "Three recoveries judged on time and in full", agent: AGENT, summary: `${team.label} recommended · ${formatUsd(team.rateUsd)}` },
      plan: { id: "plan", label: "Freight plan", heading: `Premium freight plan ${b.plan.id} written`, agent: AGENT, summary: `Premium ${formatUsd(premiumFreight.premiumUsd)} · net ${formatUsd(premiumFreight.netUsd)} saved` },
      approve: { id: "approve", label: "Approval", heading: `Approval by ${TRANSPORT_LEAD.name}`, agent: `${TRANSPORT_LEAD.name} · ${TRANSPORT_LEAD.role}`, summary: `${chosen.label} signed by ${TRANSPORT_LEAD.name}` },
      tender: { id: "tender", label: "Tender", heading: `Load tendered · ${chosen.carrier.split(" · ")[0]}`, agent: AGENT, summary: `ETA ${shortStamp(chosen.eta)} · ${chosenOut.pass ? "inside the window" : "outside the window"}` },
    }),
    [b, keep, team, chosen, chosenOut.pass]
  );

  const log = useCallback(
    (action: string, extra: { evidence?: string[]; amountUsd?: number; controlRefs?: string[] } = {}) => {
      appendAudit({
        caseId,
        accountId: b.accountId,
        module: "Order Management",
        actor: { kind: "agent", name: AGENT, role: `Agent · works for ${TRANSPORT_LEAD.name}` },
        action,
        controlRefs: extra.controlRefs ?? [],
        amountUsd: extra.amountUsd,
        evidence: extra.evidence ?? [],
        system: TMS_SYSTEM,
      });
    },
    [appendAudit, b.accountId, caseId]
  );

  const onStart = useCallback(
    (id: StageId) => {
      if (id === "signal") log(`Tender rejected by ${b.rejection.carrier}; TMS replan ETA ${shortStamp(keep.eta)} misses ${b.appointment.id}`, { evidence: [b.appointment.id, "Tender rejection"] });
      if (id === "options") log(`Judged 3 recoveries; ${team.label} is the only one on time and in full`, { evidence: ["Freight options"] });
      if (id === "plan") log(`Wrote ${b.plan.id}: premium ${formatUsd(premiumFreight.premiumUsd)}, fine avoided ${formatUsd(premiumFreight.fineUsd)}`, { amountUsd: premiumFreight.premiumUsd, evidence: [b.plan.id] });
      if (id === "approve") setSignOpen(true);
    },
    [b, keep, team, log]
  );

  const run = useStagedRun<StageId>({ order: ORDER, gates: GATES, onStart });
  const startRun = run.start;
  useEffect(() => {
    startRun("signal");
  }, [startRun]);

  const ready = useMemo(
    () => Object.fromEntries(ORDER.map((id) => [id, () => run.markReady(id)])) as Record<StageId, () => void>,
    // markReady is stable
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  const tenderLogged = useRef(false);
  useEffect(() => {
    if (run.statuses.tender !== "running" || tenderLogged.current) return;
    tenderLogged.current = true;
    log(`Tendered ${chosen.carrier}: pickup ${shortStamp(chosen.pickup)}, ETA ${shortStamp(chosen.eta)}`, {
      controlRefs: CONTROLS,
      amountUsd: chosen.rateUsd,
      evidence: [b.plan.id, b.appointment.id],
    });
  }, [run.statuses.tender, chosen, b, log]);

  const done = run.complete;
  useEffect(() => {
    if (!done) return;
    resolveShipment(caseId, chosenOut.pass ? row?.resolvedLabel ?? chosen.label : `${chosen.label} · ETA ${shortStamp(chosen.eta)}`);
  }, [done, caseId, chosen, chosenOut.pass, row, resolveShipment]);

  useFollowLatest(() => (run.active ? cardRefs.current[run.active] ?? null : null), run.active);

  const optionDetail = (o: FreightOption) => {
    const out = optionOutcome(o.id);
    return `${formatUsd(o.rateUsd)} · ETA ${shortStamp(o.eta)} · ${out.pass ? "on time, in full" : !out.onTime ? `${out.lateDays} day late` : "short"}`;
  };

  return (
    <div className="flex flex-col gap-4">
      <ShipmentRunHeader
        caseId={caseId}
        summary={`${b.customer} · ${b.orderId} · ${formatUsd(b.valueUsd)}`}
        accountId={b.accountId}
        agents={[{ name: AGENT, type: "delivery" }]}
        controls={CONTROLS}
        onBack={onBack}
      />

      <StageProgressRail
        stages={ORDER.map((id) => ({ id, label: stages[id].label, icon: ICONS[id] }))}
        statuses={run.statuses}
        openStageId={run.active}
        onStageClick={(id) => run.focus(id)}
      />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-[minmax(0,1fr)_300px]">
        <div className="flex min-w-0 flex-col gap-4">
          {ORDER.map((id) => {
            const status = run.statuses[id];
            if (status === "waiting") return null;
            return (
              <RunStageCard
                key={id}
                ref={(el) => {
                  cardRefs.current[id] = el;
                }}
                stage={stages[id]}
                status={status}
                open={run.open.has(id)}
                ready={run.ready.has(id)}
                canContinue={run.active === id && run.canAdvance}
                onToggle={() => run.toggle(id)}
                onContinue={run.advance}
                headerExtra={id === "approve" ? <ControlTags refs={CONTROLS} /> : undefined}
              >
                {id === "signal" && (
                  <>
                    <AiStageNarration
                      variant="inline"
                      playKey={`${caseId}:n:signal`}
                      text={`${b.rejection.carrier.split(" · ")[0]} rejected the tender, and the TMS replan arrives ${shortStamp(keep.eta)}. Kroger's appointment closes ${shortStamp(b.appointment.to)}.`}
                    />
                    <div className="rounded-lg border bg-card px-3 py-2">
                      <TickList
                        playKey={`${caseId}:signal`}
                        onDone={() => setSignalRead(true)}
                        items={[
                          { id: "route", label: "Route", detail: b.route, system: TMS_SYSTEM },
                          { id: "rejected", label: "Tender rejected", detail: `${b.rejection.carrier} · ${b.rejection.reason}`, system: TMS_SYSTEM },
                          { id: "replan", label: "TMS replan", detail: `${keep.carrier} · pickup ${shortStamp(keep.pickup)} · ETA ${shortStamp(keep.eta)}`, system: TMS_SYSTEM },
                          { id: "appt", label: "Appointment", detail: `${b.appointment.id} · ${b.appointment.label}`, system: "Kroger" },
                        ]}
                      />
                    </div>
                    {signalRead && row && (
                      <div className="animate-enter flex flex-col gap-2 rounded-lg border bg-card px-3 py-2.5">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-xs font-semibold text-foreground">Predicted arrival vs window</span>
                          <CheckChip result="flag">Misses the window by {missDays} day</CheckChip>
                        </div>
                        <EtaWindowTrack row={row} />
                        <SignalDone onDone={ready.signal} />
                      </div>
                    )}
                    <SourceDocTrigger doc={buildRunBTmsPlanDoc()} label="TMS plan and rejection" className="self-start" />
                  </>
                )}
                {id === "options" && (
                  <>
                    <AiStageNarration
                      variant="inline"
                      playKey={`${caseId}:n:options`}
                      text={`Missing the window risks a ${b.fineRatePct}% OTIF fine of ${formatUsd(premiumFreight.fineUsd)}. Only the team-driver expedite is on time and in full.`}
                    />
                    <FreightOptions playKey={`${caseId}:options`} onDone={ready.options} />
                    <SourceDocTrigger doc={buildRunBOptionsDoc()} label="Freight options" className="self-start" />
                  </>
                )}
                {id === "plan" && (
                  <div className="flex flex-col gap-2 rounded-lg border bg-card">
                    <header className="flex items-center justify-between gap-2 border-b bg-muted/30 px-3 py-2">
                      <span className="text-xs font-semibold text-foreground">Premium freight plan · {b.plan.id}</span>
                      <SourceDocTrigger doc={buildPremiumPlanDoc()} label="Open plan" variant="ghost" className="h-7 px-2 text-xs" />
                    </header>
                    <FillFields
                      className="px-3 pb-2"
                      playKey={`${caseId}:plan`}
                      onDone={ready.plan}
                      columns={2}
                      fields={[
                        { label: "Carrier", value: team.carrier },
                        { label: "Pickup", value: shortStamp(team.pickup) },
                        { label: "ETA", value: shortStamp(team.eta) },
                        { label: "Reason", value: b.plan.reason },
                        { label: "Rate", value: formatUsd(team.rateUsd), align: "right" },
                        { label: "Base rate", value: formatUsd(keep.rateUsd), align: "right" },
                        { label: "Premium", value: formatUsd(premiumFreight.premiumUsd), align: "right", strong: true },
                        { label: "Fine avoided", value: formatUsd(premiumFreight.fineUsd), align: "right" },
                        { label: "Net saving", value: formatUsd(premiumFreight.netUsd), align: "right", strong: true },
                        { label: "Cost center", value: b.plan.costCenter, mono: true },
                      ]}
                      stamp={
                        <span className="rounded border-2 border-primary px-2 py-0.5 text-[11px] font-bold uppercase tracking-widest text-primary">
                          Proposed
                        </span>
                      }
                    />
                  </div>
                )}
                {id === "approve" && (
                  <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border bg-muted/20 px-4 py-3">
                    <div className="flex flex-col gap-0.5 text-sm text-foreground">
                      <span>
                        Premium <span className="font-semibold tabular-nums">{formatUsd(premiumFreight.premiumUsd)}</span> · limit{" "}
                        <span className="tabular-nums">{formatUsd(PREMIUM_FREIGHT_LIMIT_USD)}</span>
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {status === "passed" ? `${chosen.label} approved` : "Choose the option in the sign-off"}
                      </span>
                    </div>
                    <Button size="sm" variant={status === "passed" ? "outline" : "default"} onClick={() => setSignOpen(true)}>
                      <PenLine className="h-4 w-4" />
                      {status === "passed" ? "View signature" : "Review & sign"}
                    </Button>
                  </div>
                )}
                {id === "tender" && (
                  <StagedChangeTable
                    title={`Tender · ${b.orderId}`}
                    system={TMS_SYSTEM}
                    playKey={`${caseId}:tender:${chosenId}`}
                    onDone={ready.tender}
                    rows={[
                      { key: "carrier", label: "Carrier", from: keep.carrier, to: chosen.carrier, unchanged: chosen.carrier === keep.carrier },
                      { key: "pickup", label: "Pickup", from: shortStamp(keep.pickup), to: shortStamp(chosen.pickup), unchanged: chosen.pickup === keep.pickup },
                      { key: "eta", label: "Expected delivery", from: shortStamp(keep.eta), to: shortStamp(chosen.eta), unchanged: chosen.eta === keep.eta },
                      { key: "rate", label: "Rate", from: formatUsd(keep.rateUsd), to: formatUsd(chosen.rateUsd), unchanged: chosen.rateUsd === keep.rateUsd },
                      { key: "accrual", label: "Premium accrual", code: b.plan.costCenter, from: "—", to: chosenPremium ? formatUsd(chosenPremium) : "—", unchanged: !chosenPremium },
                      { key: "appt", label: "Appointment", from: b.appointment.id, to: b.appointment.id, unchanged: true },
                    ]}
                    footer={`Tender accepted by ${chosen.carrier.split(" · ")[0]} · ETA ${shortStamp(chosen.eta)}`}
                    footerTrailing={<CheckChip result={chosenOut.pass ? "pass" : "flag"} />}
                  />
                )}
              </RunStageCard>
            );
          })}
        </div>
        <div className="lg:sticky lg:top-4 lg:self-start">
          <RunAgentLog caseId={caseId} />
        </div>
      </div>

      <GateSignoffModal
        open={signOpen}
        onClose={() => setSignOpen(false)}
        gateId={`${caseId}:G1`}
        title="Approve the premium freight plan"
        documentNo={`${b.plan.id} · ${b.orderId}`}
        caseId={caseId}
        accountId={b.accountId}
        module="Order Management"
        system={TMS_SYSTEM}
        controls={CONTROLS}
        signers={[{ name: TRANSPORT_LEAD.name, role: TRANSPORT_LEAD.role }]}
        evidence={[
          { id: "tms", label: `TMS plan and tender rejection · ${b.orderId}`, system: TMS_SYSTEM, doc: buildRunBTmsPlanDoc() },
          { id: "options", label: "Freight options · 3 judged", system: TMS_SYSTEM, doc: buildRunBOptionsDoc() },
          { id: "plan", label: `Premium freight plan ${b.plan.id}`, detail: `Premium ${formatUsd(premiumFreight.premiumUsd)} · fine avoided ${formatUsd(premiumFreight.fineUsd)}`, system: TMS_SYSTEM, doc: buildPremiumPlanDoc() },
        ]}
        options={b.options.map((o) => ({ id: o.id, label: o.label, detail: optionDetail(o), recommended: o.recommended }))}
        defaultOptionId="team"
        lines={[{ label: `Premium over base rate`, amountUsd: premiumFreight.premiumUsd, kind: "other" }]}
        attestation={`I approve ${b.plan.id} for ${b.orderId}: the option selected above, within my ${formatUsd(PREMIUM_FREIGHT_LIMIT_USD)} premium freight limit.`}
        confirmLabel="Approve plan"
        action={`Approved premium freight plan ${b.plan.id}`}
        decision={(optionId) => `Approved ${b.options.find((o) => o.id === optionId)?.label ?? "plan"}`}
        onSigned={(result) => {
          setSignOpen(false);
          if (result.optionId) setChosenId(result.optionId as FreightOption["id"]);
          run.passGate("approve");
        }}
      >
        <div className="flex items-center justify-between gap-2 rounded-md border bg-muted/30 px-3 py-2 text-xs">
          <span className="text-muted-foreground">Delegated premium freight limit</span>
          <span className="font-medium tabular-nums text-foreground">
            {formatUsd(premiumFreight.premiumUsd)} within {formatUsd(PREMIUM_FREIGHT_LIMIT_USD)}
          </span>
        </div>
      </GateSignoffModal>

      {done && !finaleDismissed && (
        <RunCompleteModal
          eyebrow="Shipment resolved"
          title={chosenOut.pass ? `${caseId} back inside the Kroger window` : `${caseId} tendered`}
          narrative={
            chosenOut.pass
              ? `${chosen.label} · ETA ${shortStamp(chosen.eta)} · ${formatUsd(premiumFreight.netUsd)} better than paying the fine.`
              : `${chosen.label} · ETA ${shortStamp(chosen.eta)}.`
          }
          stats={[
            { label: "Premium", value: formatUsd(chosenPremium) },
            { label: "Fine avoided", value: chosenOut.pass ? formatUsd(premiumFreight.fineUsd) : formatUsd(0), tone: "success" },
            { label: "Order value protected", value: formatUsd(b.valueUsd) },
          ]}
          docs={[{ doc: buildPremiumPlanDoc(TRANSPORT_LEAD.name), label: `Premium freight plan ${b.plan.id}` }]}
          primaryLabel="Back to Track & Trace"
          onPrimary={onBack}
          secondaryLabel="Stay here"
          onSecondary={() => setFinaleDismissed(true)}
          exportCaseId={caseId}
        />
      )}
    </div>
  );
}

/** Marks the signal stage ready once the ETA dot has slid into place. */
function SignalDone({ onDone }: { onDone: () => void }) {
  const doneRef = useRef(onDone);
  doneRef.current = onDone;
  useEffect(() => {
    const t = window.setTimeout(() => doneRef.current(), 1100);
    return () => window.clearTimeout(t);
  }, []);
  return null;
}
