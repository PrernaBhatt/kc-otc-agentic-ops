"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  Building2,
  ChevronDown,
  CircleCheck,
  Copy,
  FileText,
  Landmark,
  Package,
  Receipt,
  Tag,
  UserCheck,
  type LucideIcon,
} from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import { Spinner } from "@/components/agents/spinner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CountUp } from "@/components/ui/count-up";
import {
  chargebackQueueSummary,
  claimLineMath,
  claimQueueRows,
  claimRiskScore,
  distributorName,
  formatUsd,
  stageNarration,
} from "@/lib/chargeback-selectors";
import { findClaim, type ChargebackClaim } from "@/lib/data/chargebacks";
import {
  grossToNetLevers,
  opsSplit,
  PROGRAMME_SCOPE,
  claimsReceived,
  potentialOverpayment,
  totalClaimValue,
} from "@/lib/data/gross-to-net";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

import { StageProgressRail } from "@/components/mounts/shared/stage-progress-rail";
import { RunCompleteModal } from "@/components/mounts/shared/run-complete-modal";
import { narrationDwellMs } from "@/components/mounts/chargebacks/ai-stage-narration";
import {
  buildChargebackClaimDoc,
  buildChargebackSettlementDoc,
} from "@/lib/docs-chargebacks";
import { ClaimStagePanel } from "@/components/mounts/chargebacks/stage-panels";
import { FinancialImpactPanel } from "@/components/mounts/financial-impact/financial-impact-panel";

type SimStatus = "waiting" | "running" | "passed" | "needsReview";

const CLAIM_STAGES: {
  id: string;
  label: string;
  heading: string;
  agentType: string;
  agent: string;
  icon: LucideIcon;
}[] = [
  {
    id: "claim_intake",
    label: "Claim received",
    heading: "Claim as submitted",
    agentType: "orchestrator",
    agent: "Claim Intake Agent",
    icon: FileText,
  },
  {
    id: "customer_check",
    label: "Eligibility",
    heading: "End customer eligibility",
    agentType: "validation",
    agent: "Customer Eligibility Agent",
    icon: Building2,
  },
  {
    id: "price_check",
    label: "Price",
    heading: "Contract price verification",
    agentType: "pricing",
    agent: "Contract Pricing Agent",
    icon: Tag,
  },
  {
    id: "duplicate_check",
    label: "Duplicate",
    heading: "Duplicate screening",
    agentType: "document",
    agent: "Duplicate Screening Agent",
    icon: Copy,
  },
  {
    id: "volume_check",
    label: "Volume",
    heading: "Invoice and delivery trace",
    agentType: "atp",
    agent: "Invoice Trace Agent",
    icon: Package,
  },
  {
    id: "decision",
    label: "Decision",
    heading: "Settlement decision",
    agentType: "credit",
    agent: "Settlement Recommendation Agent",
    icon: UserCheck,
  },
  {
    id: "settlement",
    label: "Settlement",
    heading: "Settlement recorded",
    agentType: "invoice",
    agent: "Settlement Agent",
    icon: Receipt,
  },
];

/**
 * The stages a claim actually walks.
 *
 * A confirmed duplicate skips the validation chain: once a claim has already
 * been settled, pricing and volume cannot change the outcome. The veto is a
 * control, not a weighted input, and this is where that becomes visible.
 */
function stagesForClaim(claim: ChargebackClaim) {
  if (!claim.duplicateVeto) return CLAIM_STAGES;
  const kept = new Set(["claim_intake", "duplicate_check", "decision"]);
  return CLAIM_STAGES.filter((s) => kept.has(s.id));
}

/**
 * What the agent panel records for a stage, derived per claim rather than read
 * from a flat map.
 *
 * A duplicate claim reaches the same stage ids as a clean one, so a map keyed
 * on stage alone printed the clean-claim finding - "the payment is distinct
 * from every claim already settled" - in the panel beside a decision card
 * rejecting that very claim as a duplicate. The unsupported units are read
 * from the claim arithmetic for the same reason a component never hardcodes a
 * figure: the number has one source.
 */
function stageLog(claimId: string, stageId: string): string {
  const claim = findClaim(claimId);
  const math = claimLineMath(claimId);

  switch (stageId) {
    case "claim_intake":
      return "Claim received. Wholesaler, end customer and product identified.";
    case "customer_check":
      return "Roster checked. The project is covered by the cited contract.";
    case "price_check":
      return "Price records checked. The claimed price is the contracted price.";
    case "duplicate_check":
      return claim?.duplicateVeto
        ? `Settled claims screened. Matches ${
            claim.duplicateOfClaimId ?? "a settled claim"
          } on every field but the claim number.`
        : "Settled claims screened. The payment is distinct from every claim already settled.";
    case "volume_check":
      return math
        ? `Invoice history summed. ${math.unitsException.toLocaleString(
            "en-US"
          )} units are unsupported.`
        : "Invoice history summed.";
    case "decision":
      return "Recommendation prepared. Awaiting a decision.";
    case "settlement":
      return "Decision recorded. Credit note raised.";
    default:
      return "";
  }
}

interface AgentLog {
  id: string;
  agent: string;
  agentType: string;
  message: string;
  tone: "info" | "success" | "attention";
}

/** Floor for the automatic steps after a gate, so they are still readable. */
const STAGE_DWELL_MS = 4000;

/** The assessment as one string, for sizing the dwell to its length. */
function narrationText(claimId: string, stageId: string): string {
  const n = stageNarration(claimId, stageId);
  return Array.isArray(n) ? n.join("\n") : n;
}

export function ChargebacksView() {
  const [openClaimId, setOpenClaimId] = useState<string | null>(null);

  return openClaimId ? (
    <ClaimRun claimId={openClaimId} onBack={() => setOpenClaimId(null)} />
  ) : (
    <ClaimQueue onOpen={setOpenClaimId} />
  );
}

/* ---------------------------------------------------------------- *
 * Queue
 * ---------------------------------------------------------------- */

function ClaimQueue({ onOpen }: { onOpen: (claimId: string) => void }) {
  const { claimDecisions } = useOtcStore();
  const decidedIds = claimDecisions.map((d) => d.claimId);
  const summary = chargebackQueueSummary(decidedIds);
  const rows = claimQueueRows(decidedIds);

  const tiles = [
    {
      label: "Claims awaiting decision",
      value: summary.claimsWaiting,
      format: (n: number) => String(Math.round(n)),
      tone: "default" as const,
    },
    {
      label: "Value claimed",
      value: summary.valueClaimed,
      format: formatUsd,
      tone: "default" as const,
    },
    {
      label: "Supportable value",
      value: summary.valueSupportable,
      format: formatUsd,
      tone: "success" as const,
    },
    {
      label: "Unsupported value",
      value: summary.valueNotSupported,
      format: formatUsd,
      tone: "danger" as const,
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold">Wholesaler chargeback claims</h2>
        <p className="text-sm text-muted-foreground">
          Wholesalers buy from us at an agreed price, resell to institutional
          buyers at a contracted price, and claim the difference back. Every claim is
          validated before settlement, and every settlement is decided by a
          person.
        </p>
        <p className="mt-1 text-xs text-muted-foreground">{PROGRAMME_SCOPE}</p>
      </div>

      <div className="grid items-stretch gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {tiles.map((t) => (
          <Card key={t.label} className="flex h-full flex-col bg-card">
            <CardContent className="flex flex-1 flex-col p-4">
              <p className="text-xs text-muted-foreground">{t.label}</p>
              <p
                className={cn(
                  "mt-1 text-2xl font-bold tabular-nums",
                  t.tone === "success" && "text-[var(--success)]",
                  t.tone === "danger" && "text-red-600"
                )}
              >
                <CountUp value={t.value} format={t.format} />
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">
            Claims in the queue
          </CardTitle>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <table className="w-full min-w-[720px] text-sm">
            <thead>
              <tr className="border-b text-left text-xs text-muted-foreground">
                <th className="pb-2 font-medium">Claim</th>
                <th className="pb-2 font-medium">Wholesaler</th>
                <th className="pb-2 font-medium">End customer</th>
                <th className="pb-2 text-right font-medium">Claimed</th>
                <th className="pb-2 text-center font-medium">Exception score</th>
                <th className="pb-2 font-medium">Reason</th>
                <th className="pb-2 text-right font-medium">Action</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr
                  key={row.claimId}
                  className={cn(
                    "border-b last:border-0",
                    row.status === "Settled" && "text-muted-foreground"
                  )}
                >
                  <td className="py-2.5 font-medium">{row.claimId}</td>
                  <td className="py-2.5">{row.wholesaler}</td>
                  <td className="py-2.5">{row.endCustomer}</td>
                  <td className="py-2.5 text-right tabular-nums">
                    {formatUsd(row.claimedAmount)}
                  </td>
                  <td className="py-2.5 text-center">
                    {row.score === null ? (
                      <span className="text-muted-foreground">—</span>
                    ) : (
                      <span
                        className={cn(
                          "font-semibold tabular-nums",
                          row.score >= 70 ? "text-red-600" : "text-muted-foreground"
                        )}
                      >
                        {row.score}
                      </span>
                    )}
                  </td>
                  <td className="py-2.5 text-xs">
                    {row.vetoed ? (
                      <span className="font-medium text-red-700">
                        {row.reason}
                      </span>
                    ) : (
                      <span className="text-muted-foreground">{row.reason}</span>
                    )}
                  </td>
                  <td className="py-2.5 text-right">
                    {row.status !== "Settled" && (
                      <Button
                        size="sm"
                        variant={row.decided ? "outline" : "default"}
                        className="whitespace-nowrap"
                        onClick={() => onOpen(row.claimId)}
                      >
                        {row.decided ? "View" : "Review claim"}
                      </Button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>

      <Card className="bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">
            Gross-to-net exposure by lever
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-3 text-xs text-muted-foreground">
            {claimsReceived.toLocaleString("en-US")} claims worth{" "}
            {formatUsd(totalClaimValue)} were received this period.{" "}
            {formatUsd(potentialOverpayment)} was identified as unsupported
            before settlement. {opsSplit.autoSettledPercent}% settled
            automatically, {opsSplit.underReviewPercent}% went to review and{" "}
            {opsSplit.onHoldPercent}% were held.
          </p>
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b text-left text-xs text-muted-foreground">
                <th className="pb-2 font-medium">Lever</th>
                <th className="pb-2 font-medium">Description</th>
                <th className="pb-2 text-right font-medium">Exposure</th>
                <th className="pb-2 text-center font-medium">Attention</th>
              </tr>
            </thead>
            <tbody>
              {grossToNetLevers.map((lever) => (
                <tr key={lever.id} className="border-b last:border-0">
                  <td className="py-2 font-medium">{lever.label}</td>
                  <td className="py-2 text-xs text-muted-foreground">
                    {lever.plainDescription}
                  </td>
                  <td className="py-2 text-right tabular-nums">
                    {formatUsd(lever.exposure)}
                  </td>
                  <td className="py-2 text-center">
                    <Badge
                      variant="outline"
                      className={cn(
                        "whitespace-nowrap",
                        lever.attention === "High" &&
                          "border-red-200 bg-red-50 text-red-700",
                        lever.attention === "Medium" &&
                          "border-amber-200 bg-amber-50 text-amber-700"
                      )}
                    >
                      {lever.attention}
                    </Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}

/* ---------------------------------------------------------------- *
 * The run
 * ---------------------------------------------------------------- */

function ClaimRun({
  claimId,
  onBack,
}: {
  claimId: string;
  onBack: () => void;
}) {
  const { claimDecisions } = useOtcStore();
  const claim = findClaim(claimId)!;
  const decision = claimDecisions.find((d) => d.claimId === claimId);
  const stages = stagesForClaim(claim);
  const risk = claimRiskScore(claimId);

  const [statuses, setStatuses] = useState<Record<string, SimStatus>>(() =>
    Object.fromEntries(stages.map((s) => [s.id, "waiting" as SimStatus]))
  );
  const [processing, setProcessing] = useState(false);
  const [logs, setLogs] = useState<AgentLog[]>([]);
  const [openStages, setOpenStages] = useState<Set<string>>(new Set());
  const [activeStage, setActiveStage] = useState<string | null>(null);
  const [impactOpen, setImpactOpen] = useState(false);
  const [finaleDismissed, setFinaleDismissed] = useState(false);
  const [awaitingAdvance, setAwaitingAdvance] = useState(false);
  const settledRef = useRef(false);
  const startedRef = useRef(false);
  const cardRefs = useRef<Record<string, HTMLDivElement | null>>({});
  /** Resolves when the presenter presses Enter. */
  const advanceRef = useRef<(() => void) | null>(null);

  /**
   * The run is presenter-paced. A stage finishes its narration, then holds
   * until Enter. Every other key is ignored, and Enter does nothing while a
   * stage is still working or while a decision is outstanding.
   */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Enter") return;
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      if (!advanceRef.current) return;
      e.preventDefault();
      const go = advanceRef.current;
      advanceRef.current = null;
      go();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  /**
   * One stage open at a time. Keeping every completed stage expanded pushed
   * the rail and the header off screen, so a finished stage collapses back to
   * its heading and stays one click away.
   */
  const openStage = useCallback((stageId: string) => {
    setOpenStages(new Set([stageId]));
    setActiveStage(stageId);
  }, []);

  const addLog = useCallback((stageId: string, tone: AgentLog["tone"]) => {
    const stage = CLAIM_STAGES.find((s) => s.id === stageId)!;
    setLogs((prev) => [
      ...prev,
      {
        id: `${stageId}-${prev.length}`,
        agent: stage.agent,
        agentType: stage.agentType,
        message: stageLog(claimId, stageId),
        tone,
      },
    ]);
  }, [claimId]);

  /** Walks the checks, then stops dead at the decision. */
  const runChecks = useCallback(async () => {
    setProcessing(true);
    for (const stage of stages) {
      if (stage.id === "decision") {
        // Deliberately not marked passed: the run pauses here until a person
        // decides. Nothing downstream of this point runs on its own.
        setStatuses((prev) => ({ ...prev, decision: "needsReview" }));
        openStage("decision");
        addLog("decision", "attention");
        setProcessing(false);
        return;
      }
      setStatuses((prev) => ({ ...prev, [stage.id]: "running" }));
      openStage(stage.id);

      // The node turns green under its own timer once the narration has been
      // read, so a stage waiting on the presenter never looks like a stage
      // still working. Enter is armed from the moment the stage appears and
      // works at any point — arming it later made the key feel dead.
      let marked = false;
      const markPassed = () => {
        if (marked) return;
        marked = true;
        setStatuses((prev) => ({ ...prev, [stage.id]: "passed" }));
        addLog(stage.id, "info");
      };
      const dwell = setTimeout(
        markPassed,
        narrationDwellMs(narrationText(claimId, stage.id), STAGE_DWELL_MS)
      );

      const advanced = new Promise<void>((resolve) => {
        advanceRef.current = resolve;
      });
      setAwaitingAdvance(true);
      await advanced;
      setAwaitingAdvance(false);

      clearTimeout(dwell);
      markPassed();
    }
  }, [addLog, claim, openStage, stages]);

  /** The run starts on its own; the ref survives Strict Mode's double mount. */
  useEffect(() => {
    if (startedRef.current) return;
    startedRef.current = true;
    void runChecks();
  }, [runChecks]);

  /** Keeps the stage being worked on in the middle of the screen. */
  useEffect(() => {
    if (!activeStage) return;
    const node = cardRefs.current[activeStage];
    if (!node) return;
    const reduce =
      typeof window !== "undefined" &&
      window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    node.scrollIntoView({
      behavior: reduce ? "auto" : "smooth",
      block: "center",
    });
  }, [activeStage]);

  /** Resumes only once a decision exists in the store. */
  useEffect(() => {
    if (!decision || settledRef.current) return;
    settledRef.current = true;
    setStatuses((prev) => ({ ...prev, decision: "passed", settlement: "running" }));
    setOpenStages((prev) => new Set(prev).add("settlement"));
    setActiveStage("settlement");
    const id = setTimeout(() => {
      setStatuses((prev) => ({ ...prev, settlement: "passed" }));
      addLog("settlement", "success");
      setActiveStage(null);
    }, narrationDwellMs(narrationText(claimId, "settlement"), STAGE_DWELL_MS));
    return () => clearTimeout(id);
  }, [decision, addLog, claim]);

  const reached = stages.filter(
    (s) => statuses[s.id] !== "waiting"
  ).map((s) => s.id);
  const doneCount = stages.filter((s) => statuses[s.id] === "passed").length;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="sm"
            className="whitespace-nowrap"
            onClick={onBack}
          >
            <ArrowLeft className="h-4 w-4" />
            All claims
          </Button>
          <div>
            <h2 className="text-lg font-semibold">
              {claim.claimId} — {distributorName(claim.distributorId)}
            </h2>
            <p className="text-xs text-muted-foreground">
              {risk.vetoed
                ? "Duplicate — reject outright"
                : `Exception score ${risk.score}`}{" "}
              · {doneCount}/{stages.length} steps cleared
            </p>
          </div>
        </div>
        {decision && (
          <Button
            variant="outline"
            className="whitespace-nowrap"
            onClick={() => setImpactOpen(true)}
          >
            <Landmark className="h-4 w-4" />
            Open financial impact
          </Button>
        )}
        {processing && !awaitingAdvance && (
          <span className="flex items-center gap-2 text-sm text-muted-foreground">
            <Spinner size="sm" />
            Validation in progress
          </span>
        )}
      </div>

      <StageProgressRail
        stages={stages}
        statuses={statuses}
        openStageId={activeStage}
        onStageClick={(id) => {
          if (reached.includes(id)) openStage(id);
        }}
      />

      {reached.length === 0 ? (
        <Card className="bg-card">
          <CardContent className="p-8 text-center">
            <p className="text-sm text-muted-foreground">
              Validation starting.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-[minmax(0,1fr)_280px]">
          <div className="min-w-0 space-y-2">
            {stages.filter((s) => reached.includes(s.id)).map((stage) => {
              const open = openStages.has(stage.id);
              const status = statuses[stage.id];
              return (
                <Card
                  key={stage.id}
                  ref={(node) => {
                    cardRefs.current[stage.id] = node;
                  }}
                  className="overflow-hidden bg-card"
                >
                  <button
                    type="button"
                    onClick={() =>
                      setOpenStages((prev) => {
                        const next = new Set(prev);
                        if (next.has(stage.id)) next.delete(stage.id);
                        else next.add(stage.id);
                        return next;
                      })
                    }
                    className="flex w-full items-center gap-3 px-4 py-3 text-left"
                  >
                    {status === "running" ? (
                      <Spinner size="sm" />
                    ) : status === "passed" ? (
                      <CircleCheck className="h-5 w-5 shrink-0 text-[var(--success)]" />
                    ) : (
                      <AgentIcon type={stage.agentType} size="sm" />
                    )}
                    <span className="min-w-0 flex-1">
                      <span className="block text-sm font-medium">
                        {stage.heading}
                      </span>
                    </span>
                    {status === "needsReview" && (
                      <Badge
                        variant="outline"
                        className="whitespace-nowrap border-amber-300 bg-amber-50 text-amber-800"
                      >
                        Awaiting decision
                      </Badge>
                    )}
                    <ChevronDown
                      className={cn(
                        "h-4 w-4 shrink-0 text-muted-foreground transition-transform",
                        open && "rotate-180"
                      )}
                    />
                  </button>
                  {open && (
                    <div className="border-t px-4 py-4">
                      <ClaimStagePanel
                        stageId={stage.id}
                        claimId={claimId}
                        isCurrentStage={status === "needsReview"}
                        onJumpToStage={(id) => {
                          if (reached.includes(id)) openStage(id);
                        }}
                      />
                    </div>
                  )}
                </Card>
              );
            })}
          </div>

          <Card className="h-fit bg-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold">
                Agent activity
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {logs.map((log) => {
                // The recommendation agent used to sit at "awaiting a
                // decision" for the rest of the run, contradicting the
                // settlement two rows below it. Its line is read from the
                // decision rather than frozen when the log was written, so it
                // is right however the run was reached.
                const resolved =
                  log.id.startsWith("decision-") && decision
                    ? {
                        message: `Recommendation ${
                          decision.outcome === "Approved in part"
                            ? "accepted"
                            : "overridden"
                        }. ${formatUsd(decision.approvedAmount)} approved, ${formatUsd(decision.rejectedAmount)} rejected.`,
                        tone: "success" as const,
                      }
                    : { message: log.message, tone: log.tone };
                return (
                <div key={log.id} className="flex gap-2">
                  <AgentIcon type={log.agentType} size="sm" />
                  <div className="min-w-0">
                    <p className="text-xs font-medium leading-tight">
                      {log.agent}
                    </p>
                    <p
                      className={cn(
                        "text-xs leading-snug",
                        resolved.tone === "attention"
                          ? "text-amber-700"
                          : resolved.tone === "success"
                            ? "text-[var(--success)]"
                            : "text-muted-foreground"
                      )}
                    >
                      {resolved.message}
                    </p>
                  </div>
                </div>
                );
              })}
              {logs.length === 0 && (
                <p className="text-xs text-muted-foreground">
                  No activity recorded yet.
                </p>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {impactOpen && (
        <FinancialImpactPanel claimId={claimId} onClose={() => setImpactOpen(false)} />
      )}

      {statuses.settlement === "passed" && decision && !finaleDismissed && (
        <RunCompleteModal
          eyebrow="Chargeback validation complete"
          title={`${claim.claimId} settled`}
          // Do NOT say the reserve entry follows from this decision. It does
          // not: settling a claim consumes and releases reserve, it does not
          // add to it. The two postings are separate and the copy has to say
          // so, or the first question from a controller has a wrong answer.
          narrative={
            decision.approvedAmount > 0
              ? "Every check produced a document and a person decided the settlement. The credit note posts against this claim's receivable; the month-end reserve for open claims is a separate posting."
              : "Every check produced a document and a person rejected the claim in full. Nothing is credited, and the wholesaler is notified of the rejection."
          }
          stats={[
            {
              label: "checks cleared",
              value: `${stages.length} / ${stages.length}`,
            },
            {
              label: "approved",
              value: formatUsd(decision.approvedAmount),
              tone: decision.approvedAmount > 0 ? "success" : undefined,
            },
            {
              label: "rejected",
              value: formatUsd(decision.rejectedAmount),
              tone: "danger",
            },
            {
              label: "payment hold",
              value: decision.paymentBlockPlaced ? "Placed" : "None",
            },
          ]}
          docs={[
            {
              doc: buildChargebackSettlementDoc(
                claimId,
                decision.creditNoteId,
                decision.decidedAt
              ),
              label: `Settlement ${decision.creditNoteId}`,
            },
            {
              doc: buildChargebackClaimDoc(claimId),
              label: `Claim ${claim.claimId} as submitted`,
            },
          ]}
          primaryLabel="Review financial impact"
          onPrimary={() => {
            setFinaleDismissed(true);
            setImpactOpen(true);
          }}
          secondaryLabel="Stay on this claim"
          onSecondary={() => setFinaleDismissed(true)}
        />
      )}
    </div>
  );
}
