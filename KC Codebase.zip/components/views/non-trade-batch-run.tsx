"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ArrowLeft, Inbox, Landmark, ListFilter, PenLine, ScanSearch } from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import { Button } from "@/components/ui/button";
import { AiStageNarration } from "@/components/mounts/chargebacks/ai-stage-narration";
import { BatchCapture } from "@/components/mounts/non-trade/batch-capture";
import { BatchMatrix } from "@/components/mounts/non-trade/batch-matrix";
import { CategoryVolumeChart } from "@/components/mounts/non-trade/category-volume-chart";
import { RunAgentLog } from "@/components/mounts/shared/run-agent-log";
import { RunCompleteModal } from "@/components/mounts/shared/run-complete-modal";
import { RunStageCard, type RunStageMeta } from "@/components/mounts/shared/run-stage-card";
import { StageProgressRail } from "@/components/mounts/shared/stage-progress-rail";
import { useFollowLatest } from "@/components/mounts/shared/use-follow-latest";
import { useStagedRun } from "@/components/mounts/shared/use-staged-run";
import { ControlTags } from "@/components/shared/control-tag";
import { FillFields } from "@/components/shared/fill-fields";
import { GateSignoffModal } from "@/components/shared/gate-signoff-modal";
import { DEDUCTIONS_LEAD, findAccount } from "@/lib/data/account-owners";
import { NON_TRADE_BATCH } from "@/lib/data/non-trade-batch";
import { formatUsd } from "@/lib/format";
import { batchTotals, closedByPolicy, mergedComplianceUsd } from "@/lib/non-trade-selectors";
import { useOtcStore } from "@/lib/store";

const ORDER = ["capture", "classify", "validate", "policy", "post"] as const;
type StageId = (typeof ORDER)[number];
const GATES = ["policy"] as const satisfies readonly StageId[];

const ICONS = {
  capture: Inbox,
  classify: ListFilter,
  validate: ScanSearch,
  policy: PenLine,
  post: Landmark,
} as const;

const AGENT_TYPES: Record<StageId, string> = {
  capture: "billing",
  classify: "validation",
  validate: "document",
  policy: "orchestrator",
  post: "invoice",
};

const CONTROLS = ["1.4.5", "1.4.3", "1.4.4"];
const MULTI = "Multiple";

/**
 * Non-trade deductions are a volume problem: a week of low-value claims is
 * judged by policy in one batch, one person signs the policy outcome, and only
 * the exceptions reach an account owner.
 */
export function NonTradeBatchRun({ onBack }: { onBack: () => void }) {
  const { appendAudit, raiseEscalation, postNonTradeBatch } = useOtcStore();
  const b = NON_TRADE_BATCH;
  const caseId = b.batchId;
  const coSign = findAccount(b.coSignAccountId);
  const t = batchTotals;

  const [signOpen, setSignOpen] = useState(false);
  const [finaleDismissed, setFinaleDismissed] = useState(false);
  const cardRefs = useRef<Record<string, HTMLDivElement | null>>({});

  const stages: Record<StageId, RunStageMeta> = useMemo(
    () => ({
      capture: { id: "capture", label: "Capture", heading: `Week ${b.week} captured`, agent: "Cash Application Agent", summary: `${t.total.count} claims · ${formatUsd(t.total.usd)} from ${b.sources.length} customers` },
      classify: { id: "classify", label: "Classify", heading: "Claims classified by reason code", agent: "Deduction Classification Agent", summary: `${b.categories.length} categories by reason-code rule` },
      validate: { id: "validate", label: "Validate", heading: "Each claim judged against its evidence", agent: "Evidence Matching Agent", summary: `${t.valid.count} valid · ${t.invalid.count} invalid · ${t.exception.count} to owners` },
      policy: { id: "policy", label: "Policy sign-off", heading: `Policy sign-off by ${DEDUCTIONS_LEAD.name}`, agent: `${DEDUCTIONS_LEAD.name} · ${coSign?.owner.name ?? ""} co-signs for Walmart`, summary: `Signed by ${DEDUCTIONS_LEAD.name} and ${coSign?.owner.name ?? ""}` },
      post: { id: "post", label: "Post & signal", heading: "Posted in FSCM, signal sent to supply chain", agent: "FSCM Posting Agent", summary: `${closedByPolicy} closed by policy · ${b.escalationId} raised` },
    }),
    [b, t, coSign]
  );

  const log = useCallback(
    (agent: string, action: string, extra: { controlRefs?: string[]; amountUsd?: number; evidence?: string[]; system?: string } = {}) => {
      appendAudit({
        caseId,
        accountId: MULTI,
        module: "Deductions",
        actor: { kind: "agent", name: agent, role: `Agent · works for ${DEDUCTIONS_LEAD.name}` },
        action,
        controlRefs: extra.controlRefs ?? [],
        amountUsd: extra.amountUsd,
        evidence: extra.evidence ?? [],
        system: extra.system ?? "SAP FSCM",
      });
    },
    [appendAudit, caseId]
  );

  const onStart = useCallback(
    (id: StageId) => {
      if (id === "capture") log("Cash Application Agent", `Captured ${t.total.count} non-trade claims for week ${b.week}`, { amountUsd: t.total.usd, evidence: b.sources.map((s) => `${s.customer} ${s.channel}`), system: "EDI 820" });
      if (id === "classify") log("Deduction Classification Agent", `Classified ${t.total.count} claims into ${b.categories.length} categories under ${b.policyRef}`, { evidence: [`Batch rule set ${b.policyRef}`] });
      if (id === "validate") log("Evidence Matching Agent", `Judged every claim: ${t.valid.count} valid, ${t.invalid.count} invalid, ${t.exception.count} exceptions`, { controlRefs: ["1.4.5"], amountUsd: t.total.usd, evidence: ["Validation matrix NT-2026-W44", "POD and ASN", "Carrier claims"] });
      if (id === "policy") setSignOpen(true);
      if (id === "post") {
        log("FSCM Posting Agent", `Posted ${t.valid.count} credit memos (${formatUsd(t.valid.usd)}) and ${t.invalid.count} charge-backs (${formatUsd(t.invalid.usd)})`, { controlRefs: ["1.4.3", "1.4.4"], amountUsd: t.valid.usd + t.invalid.usd, evidence: ["Credit memo batch", "Charge-back notices"] });
        log("FSCM Posting Agent", `Opened ${t.exception.count} dispute cases with account owners`, { amountUsd: t.exception.usd, evidence: ["Split-out list NT-2026-W44"] });
        raiseEscalation(b.escalationId);
        log("Root Cause Agent", `Raised ${b.escalationId} to Supply chain: ${b.signal.title}, ${b.signal.validShortages} valid claims`, { amountUsd: b.signal.usd, evidence: [b.escalationId] });
        log("Root Cause Agent", `Added Walmart compliance exceptions (${formatUsd(mergedComplianceUsd)}) to ${b.mergedEscalationId}`, { evidence: [b.mergedEscalationId] });
      }
    },
    [b, t, log, raiseEscalation]
  );

  const run = useStagedRun<StageId>({ order: ORDER, gates: GATES, onStart });
  const startRun = run.start;
  useEffect(() => {
    startRun("capture");
  }, [startRun]);

  const ready = useMemo(
    () => Object.fromEntries(ORDER.map((id) => [id, () => run.markReady(id)])) as Record<StageId, () => void>,
    // markReady is stable
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  const done = run.complete;
  useEffect(() => {
    if (done) postNonTradeBatch();
  }, [done, postNonTradeBatch]);

  useFollowLatest(() => (run.active ? cardRefs.current[run.active] ?? null : null), run.active);

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Button variant="outline" size="sm" onClick={onBack} className="gap-1.5">
          <ArrowLeft className="h-4 w-4" /> Back to Deductions
        </Button>
        <div className="flex flex-wrap items-center gap-3">
          <span className="font-mono text-base font-semibold" data-batch={b.batchId}>
            {b.batchId}
          </span>
          <span className="text-sm text-muted-foreground">
            Non-trade · {t.total.count} claims · {formatUsd(t.total.usd)}
          </span>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
        <span>Agents working for {DEDUCTIONS_LEAD.name.split(" ")[0]}</span>
        <span className="flex items-center -space-x-1">
          {ORDER.filter((id) => id !== "policy").map((id) => (
            <span key={id} className="rounded-full bg-background ring-2 ring-background" title={stages[id].agent}>
              <AgentIcon type={AGENT_TYPES[id]} size="sm" className="text-primary" />
            </span>
          ))}
        </span>
        <ControlTags refs={CONTROLS} />
      </div>

      <StageProgressRail
        stages={ORDER.map((id) => ({ id, label: stages[id].label, icon: ICONS[id] }))}
        statuses={run.statuses}
        openStageId={run.active}
        onStageClick={(id) => run.focus(id)}
      />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-[minmax(0,1fr)_300px]">
        <div className="flex min-w-0 flex-col gap-4">
          {ORDER.map((id) => {
            const status = run.statuses[id];
            if (status === "waiting") return null;
            return (
              <RunStageCard
                key={id}
                ref={(el) => {
                  cardRefs.current[id] = el;
                }}
                stage={stages[id]}
                status={status}
                open={run.open.has(id)}
                ready={run.ready.has(id)}
                canContinue={run.active === id && run.canAdvance}
                onToggle={() => run.toggle(id)}
                onContinue={run.advance}
                headerExtra={id === "policy" ? <ControlTags refs={CONTROLS} /> : undefined}
              >
                {id === "capture" && (
                  <>
                    <AiStageNarration
                      variant="inline"
                      playKey={`${caseId}:n:capture`}
                      text={`${t.total.count} low-value claims arrived this week. They are judged by policy as one batch, not case by case.`}
                    />
                    <BatchCapture onDone={ready.capture} />
                  </>
                )}
                {id === "classify" && <CategoryVolumeChart onDone={ready.classify} />}
                {id === "validate" && (
                  <>
                    <AiStageNarration
                      variant="inline"
                      playKey={`${caseId}:n:validate`}
                      text={`Every claim is checked against its evidence. ${t.exception.count} do not fit a rule and go to their account owners.`}
                    />
                    <BatchMatrix onDone={ready.validate} />
                  </>
                )}
                {id === "policy" && (
                  <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border bg-muted/20 px-4 py-3">
                    <div className="grid gap-x-6 gap-y-1 text-sm text-foreground sm:grid-cols-3">
                      <span>
                        Credit <span className="font-semibold tabular-nums">{t.valid.count}</span> ·{" "}
                        <span className="tabular-nums">{formatUsd(t.valid.usd)}</span>
                      </span>
                      <span>
                        Charge back <span className="font-semibold tabular-nums">{t.invalid.count}</span> ·{" "}
                        <span className="tabular-nums">{formatUsd(t.invalid.usd)}</span>
                      </span>
                      <span>
                        To owners <span className="font-semibold tabular-nums">{t.exception.count}</span> ·{" "}
                        <span className="tabular-nums">{formatUsd(t.exception.usd)}</span>
                      </span>
                    </div>
                    <Button size="sm" variant={status === "passed" ? "outline" : "default"} onClick={() => setSignOpen(true)}>
                      <PenLine className="h-4 w-4" />
                      {status === "passed" ? "View signatures" : "Review & sign"}
                    </Button>
                  </div>
                )}
                {id === "post" && (
                  <div className="rounded-lg border">
                    <header className="border-b bg-muted/30 px-3 py-2 text-xs font-semibold text-foreground">
                      SAP FSCM · {b.batchId}
                    </header>
                    <FillFields
                      className="px-3 py-2"
                      playKey={`${caseId}:post`}
                      onDone={ready.post}
                      columns={2}
                      fields={[
                        { label: "Credit memos", value: `${t.valid.count} · ${formatUsd(t.valid.usd)}`, align: "right" },
                        { label: "Charge-backs", value: `${t.invalid.count} · ${formatUsd(t.invalid.usd)}`, align: "right" },
                        { label: "Dispute cases to owners", value: `${t.exception.count} · ${formatUsd(t.exception.usd)}`, align: "right" },
                        { label: "Supply-chain signal", value: `${b.escalationId} · ${b.signal.title}` },
                        { label: "Walmart compliance", value: `${formatUsd(mergedComplianceUsd)} added to ${b.mergedEscalationId}` },
                        { label: "Batch status", value: "Posted", strong: true },
                      ]}
                    />
                  </div>
                )}
              </RunStageCard>
            );
          })}
        </div>
        <div className="lg:sticky lg:top-4 lg:self-start">
          <RunAgentLog caseId={caseId} />
        </div>
      </div>

      <GateSignoffModal
        open={signOpen}
        onClose={() => setSignOpen(false)}
        gateId={`${caseId}:G1`}
        title="Sign the non-trade policy outcome"
        documentNo={`${caseId} · policy outcome`}
        caseId={caseId}
        accountId={b.coSignAccountId}
        module="Deductions"
        system="SAP FSCM"
        controls={CONTROLS}
        signers={[
          { name: DEDUCTIONS_LEAD.name, role: DEDUCTIONS_LEAD.role },
          ...(coSign ? [{ name: coSign.owner.name, role: `${coSign.shortName} account owner` }] : []),
        ]}
        evidence={[
          { id: "rules", label: `Batch rule set ${b.policyRef}`, system: "SAP FSCM" },
          { id: "matrix", label: `Validation matrix ${b.batchId}`, system: "SAP FSCM" },
          ...b.categories.map((c) => ({
            id: c.key,
            label: `${c.label} · ${c.total.count} claims · ${formatUsd(c.total.usd)}`,
            detail: c.evidence,
            system: "SAP FSCM",
          })),
        ]}
        lines={[
          { label: `Credit ${t.valid.count} claims`, amountUsd: t.valid.usd, kind: "other" },
          { label: `Charge back ${t.invalid.count} claims`, amountUsd: t.invalid.usd, kind: "other" },
          { label: `Route ${t.exception.count} to owners`, amountUsd: t.exception.usd, kind: "other" },
        ]}
        attestation={`I approve the policy outcome for ${b.batchId}: credit ${t.valid.count} claims (${formatUsd(t.valid.usd)}), charge back ${t.invalid.count} (${formatUsd(t.invalid.usd)}) and route ${t.exception.count} to their owners.`}
        confirmLabel="Approve batch"
        action={`Approved batch outcome: ${t.valid.count} credit, ${t.invalid.count} charge-back, ${t.exception.count} to owners`}
        decision="Batch approved"
        onSigned={() => {
          setSignOpen(false);
          run.passGate("policy");
        }}
      />

      {done && !finaleDismissed && (
        <RunCompleteModal
          eyebrow="Batch posted"
          title={`${b.batchId} closed by policy`}
          narrative={`${t.total.count} claims · ${closedByPolicy} closed by policy · ${t.exception.count} with owners · 1 signal to supply chain.`}
          stats={[
            { label: "Credited", value: formatUsd(t.valid.usd) },
            { label: "Charged back", value: formatUsd(t.invalid.usd), tone: "success" },
            { label: "To owners", value: String(t.exception.count) },
          ]}
          primaryLabel="Back to Deductions"
          onPrimary={onBack}
          secondaryLabel="Stay here"
          onSecondary={() => setFinaleDismissed(true)}
          exportCaseId={caseId}
        />
      )}
    </div>
  );
}
