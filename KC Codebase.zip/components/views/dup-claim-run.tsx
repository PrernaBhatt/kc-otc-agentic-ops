"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useMounted } from "@/lib/hooks/use-mounted";
import {
  ArrowLeft,
  Banknote,
  Check,
  CircleCheck,
  ClipboardList,
  Copy,
  GitBranch,
  Landmark,
  Layers,
  Mail,
  Megaphone,
  ShieldX,
  ThumbsUp,
  X,
} from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import { Spinner } from "@/components/agents/spinner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { SignedApproveButton } from "@/components/shared/signed-approve-button";
import { findAccount } from "@/lib/data/account-owners";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  SourceDocTrigger,
  SourceDocRowTrigger,
} from "@/components/modals/source-doc-preview";
import { formatUsd } from "@/lib/chargeback-selectors";
import { TODAY } from "@/lib/data/clock";
import {
  dupClaimAssessment,
  dupClaimAccounting,
  renderDupClaimLetter,
  DUP_CATEGORY_LABEL,
  LINEAGE_KIND_LABEL,
} from "@/lib/dup-claim-selectors";
import {
  buildDupDeductionDoc,
  buildSimilarityMatchDoc,
  buildLineageDoc,
  buildLineageNodeDoc,
  buildDuplicateBreakdownDoc,
  buildDupLetterDoc,
} from "@/lib/docs-dup-claims";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { SystemMark } from "@/components/shared/system-badge";

import {
  AiStageNarration,
  narrationDwellMs,
} from "@/components/mounts/chargebacks/ai-stage-narration";
import {
  AgentAuditTrail,
  RunStageRow,
  RUN_STAGE_BODY_CLASS,
  RUN_STAGE_CARD_CLASS,
} from "@/components/mounts/shared/run-stage-row";
import { StageProgressRail } from "@/components/mounts/shared/stage-progress-rail";
import { RunCompleteModal } from "@/components/mounts/shared/run-complete-modal";
import { GtnImpactPanel } from "@/components/mounts/deductions/gtn-impact-panel";
import { DisputeLetterComposer } from "@/components/mounts/deductions/dispute-letter-composer";
import { AgentDecision } from "@/components/mounts/deductions/agent-decision";

type SimStatus = "waiting" | "running" | "passed" | "needsReview";

/**
 * Scenario 2 — duplicate / resubmitted claim, in seven steps.
 *
 * A post-audit firm re-deducts $95,000 for an event already dealt with, under a
 * new reference and a changed reason code so exact-match never fires. The run
 * has to (1) match it on similarity to the original claim, (2) rebuild the full
 * claim-and-settlement lineage, (3) show every dollar is already settled or
 * already rejected, and (4) decline it in full. Three steps are gates: the
 * similarity match, the reject decision and the outgoing letter.
 */
const STAGES = [
  {
    id: "intake",
    label: "Deduction",
    heading: "Deduction re-taken against the invoice",
    agent: "Deduction Intake Agent",
    agentType: "orchestrator",
    icon: Banknote,
    log: "Post-audit deduction matched to the invoice. New reference, changed reason code.",
  },
  {
    id: "match",
    label: "Similarity match",
    heading: "Matched to a prior claim by similarity",
    agent: "Similarity Matching Agent",
    agentType: "validation",
    icon: Copy,
    log: "Matched to the original claim on event, window, SKUs and stores — not on reference.",
  },
  {
    id: "lineage",
    label: "Lineage",
    heading: "Claim and settlement lineage rebuilt",
    agent: "Lineage Agent",
    agentType: "document",
    icon: GitBranch,
    log: "Original claim, credit memo, rejection and resubmission connected across systems.",
  },
  {
    id: "assess",
    label: "Duplicate assessment",
    heading: "Repeated and previously rejected value",
    agent: "Duplicate Assessment Agent",
    agentType: "validation",
    icon: Layers,
    log: "Whole claim maps to value already settled or already rejected.",
  },
  {
    id: "decision",
    label: "Decision",
    heading: "Reject duplicate claim",
    agent: "Trade Finance Agent",
    agentType: "credit",
    icon: ShieldX,
    log: "Duplicate confirmed. Awaiting a decision.",
  },
  {
    id: "letter",
    label: "Retailer response",
    heading: "Retailer response",
    agent: "Correspondence Agent",
    agentType: "invoice",
    icon: Mail,
    log: "Evidence-led response drafted with the lineage. Not yet issued.",
  },
  {
    id: "impact",
    label: "Impact",
    heading: "Leakage prevented and accounting impact",
    agent: "Revenue Accounting Agent",
    agentType: "invoice",
    icon: Landmark,
    log: "No double payment. None of the claim is a new gross-to-net cost.",
  },
] as const;

const STAGE_DWELL_MS = 4000;

const asText = (n: string | string[] | undefined) =>
  Array.isArray(n) ? n.join("\n") : (n ?? "");

const pct = (n: number) => `${Math.round(n * 100)}%`;

export function DupClaimRun({
  caseId,
  onBack,
}: {
  caseId: string;
  onBack: () => void;
}) {
  const { resolveDupClaim } = useOtcStore();
  const assessment = dupClaimAssessment(caseId);
  const accounting = dupClaimAccounting(caseId);

  const [statuses, setStatuses] = useState<Record<string, SimStatus>>(() =>
    Object.fromEntries(STAGES.map((s) => [s.id, "waiting" as SimStatus]))
  );
  const [openStages, setOpenStages] = useState<Set<string>>(new Set());
  const [activeStage, setActiveStage] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);
  const [awaitingAdvance, setAwaitingAdvance] = useState(false);
  const [matchConfirmed, setMatchConfirmed] = useState(false);
  const [decided, setDecided] = useState(false);
  const [letterSent, setLetterSent] = useState(false);
  const [sentOn, setSentOn] = useState<string | undefined>(undefined);
  const [finaleDismissed, setFinaleDismissed] = useState(false);

  const advanceRef = useRef<(() => void) | null>(null);
  const startedRef = useRef(false);
  const matchRef = useRef(false);
  const decidedRef = useRef(false);
  const letterRef = useRef(false);
  const cardRefs = useRef<Record<string, HTMLDivElement | null>>({});

  const narration: Record<string, string | string[]> = assessment
    ? {
  intake: `${assessment.case.customerName}'s post-audit firm withheld ${formatUsd(assessment.claimed)} under new reference ${assessment.case.resubmittedClaimRef}, citing "${assessment.case.resubmittedReasonCode}".`,
  match: [
  `The reference, reason code, invoice and date are all new, so exact-match finds nothing.`,
  `Matched on event, window, SKUs and stores to ${assessment.case.originalClaimRef} — ${pct(assessment.duplicateConfidence)} confidence. Confirmation required.`,
  ],
  lineage: `Same event, resubmitted eleven months after it was closed.`,
  assess: `Every dollar was already paid or already rejected.`,
  decision: `AI recommends rejecting the duplicate claim in full — request repayment of ${formatUsd(assessment.claimed)}.`,
  letter: `Response ${assessment.case.responseLetter.letterRef} drafted, citing the credit memo and rejection. Approval required before sending.`,
  impact: `No double payment: ${formatUsd(assessment.previouslySettled)} already paid is protected, and the full ${formatUsd(assessment.claimed)} remains collectible.`,
      }
    : {};
  const narrationRef = useRef(narration);
  narrationRef.current = narration;

  const openStage = useCallback((id: string) => {
    setOpenStages(new Set([id]));
    setActiveStage(id);
  }, []);

  const runFrom = useCallback(
    async (startId: string) => {
      setProcessing(true);
      const from = Math.max(0, STAGES.findIndex((s) => s.id === startId));
      for (const stage of STAGES.slice(from)) {
        if (stage.id === "match" && !matchRef.current) {
          setStatuses((p) => ({ ...p, match: "needsReview" }));
          openStage("match");
          setProcessing(false);
          return;
        }
        if (stage.id === "decision" && !decidedRef.current) {
          setStatuses((p) => ({ ...p, decision: "needsReview" }));
          openStage("decision");
          setProcessing(false);
          return;
        }
        if (stage.id === "letter" && !letterRef.current) {
          setStatuses((p) => ({ ...p, letter: "needsReview" }));
          openStage("letter");
          setProcessing(false);
          return;
        }
        setStatuses((p) => ({ ...p, [stage.id]: "running" }));
        openStage(stage.id);

        let marked = false;
        const markPassed = () => {
          if (marked) return;
          marked = true;
          setStatuses((p) => ({ ...p, [stage.id]: "passed" }));
        };
        const dwell = setTimeout(
          markPassed,
          narrationDwellMs(asText(narrationRef.current[stage.id]), STAGE_DWELL_MS)
        );
        const advanced = new Promise<void>((r) => {
          advanceRef.current = r;
        });
        setAwaitingAdvance(true);
        await advanced;
        setAwaitingAdvance(false);
        clearTimeout(dwell);
        markPassed();
      }
      setProcessing(false);
      setActiveStage(null);
    },
    [openStage]
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Enter") return;
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      if (!advanceRef.current) return;
      e.preventDefault();
      const go = advanceRef.current;
      advanceRef.current = null;
      go();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    if (startedRef.current || !assessment) return;
    startedRef.current = true;
    void runFrom("intake");
  }, [runFrom, assessment]);

  useEffect(() => {
    if (!activeStage) return;
    const node = cardRefs.current[activeStage];
    node?.scrollIntoView({ behavior: "smooth", block: "center" });
  }, [activeStage]);

  useEffect(() => {
    if (!matchConfirmed) return;
    setStatuses((p) => ({ ...p, match: "passed" }));
    void runFrom("lineage");
  }, [matchConfirmed, runFrom]);

  useEffect(() => {
    if (!decided) return;
    setStatuses((p) => ({ ...p, decision: "passed" }));
    void runFrom("letter");
  }, [decided, runFrom]);

  useEffect(() => {
    if (!letterSent) return;
    setStatuses((p) => ({ ...p, letter: "passed" }));
    void runFrom("impact");
  }, [letterSent, runFrom]);

  useEffect(() => {
    if (statuses.impact === "passed") resolveDupClaim(caseId);
  }, [statuses.impact, resolveDupClaim, caseId]);

  if (!assessment || !accounting) return null;

  const a = assessment;
  const c = a.case;
  const doneCount = STAGES.filter((s) => statuses[s.id] === "passed").length;
  const reached: string[] = STAGES.filter(
    (s) => statuses[s.id] !== "waiting"
  ).map((s) => s.id);

  const decisionReasoning = [
    `${formatUsd(assessment.previouslySettled)} was already paid and ${formatUsd(assessment.previouslyRejected)} was already rejected.`,
    assessment.genuinelyNew > 0 ? `Only ${formatUsd(assessment.genuinelyNew)} is new value.` : `Nothing in the ${formatUsd(assessment.claimed)} resubmission is new, and no new evidence is attached.`,
    `Decision: reject the resubmission and reinstate ${formatUsd(assessment.claimed)}.`,
  ];
  const renderStage = (stageId: string) =>
    stageId === "decision" ? (
      <AgentDecision stepKey={`${caseId}:decision`} lines={decisionReasoning}>
        {renderBody(stageId)}
      </AgentDecision>
    ) : (
      renderBody(stageId)
    );

  const renderBody = (id: string) => {
    switch (id) {
      case "intake":
        return (
          <div className="space-y-3">
            <PaymentSplitBar assessment={a} />
            <SourceDocTrigger
              doc={buildDupDeductionDoc(caseId)}
              label="View the deduction backup"
            />
          </div>
        );
      case "match":
        return (
          <div className="space-y-3">
            <SimilarityMatchCard assessment={a} caseId={caseId} />
            {matchConfirmed ? (
              <p className="flex items-center gap-1.5 text-xs text-[var(--success)]">
                <ThumbsUp className="h-3.5 w-3.5" />
                Confirmed by you — same event as {c.originalClaimRef}.
              </p>
            ) : (
              <div className="flex flex-wrap items-center gap-3 rounded-lg border-2 border-amber-200 bg-amber-50/60 px-3 py-2.5">
                <span className="text-xs text-amber-900">
                  Confirm the claim is the same event as {c.originalClaimRef}{" "}
                  before the lineage is rebuilt. Nothing is recorded until you
                  click.
                </span>
                <Button
                  size="sm"
                  className="whitespace-nowrap"
                  onClick={() => {
                    matchRef.current = true;
                    setMatchConfirmed(true);
                  }}
                >
                  Confirm match to {c.originalClaimRef}
                </Button>
              </div>
            )}
          </div>
        );
      case "lineage":
        return <LineageTrail assessment={a} caseId={caseId} />;
      case "assess":
        return <DuplicateBreakdown assessment={a} caseId={caseId} />;
      case "decision":
        return (
          <div className="space-y-3">
            <div className="grid gap-3 sm:grid-cols-3">
              <div className="rounded-lg border-2 border-red-300 bg-red-50 p-3">
                <p className="text-xs text-muted-foreground">Reject as duplicate</p>
                <p className="text-2xl font-bold text-red-700">
                  {formatUsd(a.duplicateValue)}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {pct(a.duplicateConfidence)} confidence
                </p>
              </div>
              <div className="rounded-lg border-2 border-[var(--success)]/40 bg-[var(--success)]/5 p-3">
                <p className="text-xs text-muted-foreground">Genuinely new</p>
                <p className="text-2xl font-bold text-[var(--success)]">
                  {formatUsd(a.genuinelyNew)}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  nothing to investigate
                </p>
              </div>
              <div className="rounded-lg border-2 border-muted bg-muted/30 p-3">
                <p className="text-xs text-muted-foreground">Re-deducted</p>
                <p className="text-2xl font-bold tabular-nums">
                  {formatUsd(a.claimed)}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  under {c.resubmittedClaimRef}
                </p>
              </div>
            </div>
            {decided ? (
              <p className="flex items-center gap-1.5 text-xs text-[var(--success)]">
                <ThumbsUp className="h-3.5 w-3.5" />
                Decided by you — reject {formatUsd(a.duplicateValue)} as a
                duplicate.
              </p>
            ) : (
              <div className="flex flex-wrap items-center gap-3 rounded-lg border-2 border-amber-200 bg-amber-50/60 px-3 py-2.5">
                <span className="text-xs text-amber-900">
                  Awaiting your decision. Nothing is recorded until you click.
                </span>
                <SignedApproveButton
                  variant="destructive"
                  gateId={`${caseId}:G1`}
                  title="Reject the duplicate claim"
                  caseId={c.caseId}
                  accountId={findAccount(c.customerName)?.accountId ?? ""}
                  module="Deductions"
                  system="Vistex"
                  controls={["1.7.5", "1.4.4"]}
                  evidence={[
                    { id: "resub", label: `Resubmitted claim ${c.resubmittedClaimRef}`, system: "Vistex" },
                    { id: "dup", label: "Duplicate of a settled claim", system: "Vistex" },
                  ]}
                  lines={[{ label: "Repayment requested", amountUsd: a.duplicateValue, kind: "charge-back" }]}
                  attestation={`I reject ${formatUsd(a.duplicateValue)} on ${c.caseId} as a duplicate and request repayment.`}
                  action={`Rejected ${formatUsd(a.duplicateValue)} as duplicate`}
                  decision="Rejected · duplicate"
                  onSigned={() => {
                    decidedRef.current = true;
                    setDecided(true);
                  }}
                >
                  Reject {formatUsd(a.duplicateValue)} · request repayment
                </SignedApproveButton>
              </div>
            )}
          </div>
        );
      case "letter": {
        const letter = renderDupClaimLetter(caseId)!;
        return (
          <DisputeLetterComposer
            letterKey={c.caseId}
            from={`${c.responseLetter.from} <trade.finance@internal.example>`}
            to={`${c.responseLetter.to} <postaudit@retailer.example>`}
            subject={letter.subject}
            body={letter.body}
            attachments={[
              {
                doc: buildDupDeductionDoc(caseId),
                label: `Deduction ${c.remittanceId}`,
              },
              {
                doc: buildSimilarityMatchDoc(caseId),
                label: "Similarity match",
              },
              {
                doc: buildLineageDoc(caseId),
                label: "Claim & settlement lineage",
              },
              {
                doc: buildDupLetterDoc(caseId, letterSent),
                label: "Letter as a document",
              },
            ]}
            sent={letterSent}
            sentDate={sentOn}
            sentNote={`Issued to ${c.customerName} post-audit recovery. Repayment of ${formatUsd(a.claimed)} requested within 30 days.`}
            canSend={statuses.letter === "needsReview"}
            blockedNote="Take the decision first."
            onSend={() => {
              letterRef.current = true;
              setSentOn(TODAY);
              setLetterSent(true);
            }}
          />
        );
      }
      case "impact":
        return (
          <GtnImpactPanel
            shortPay={a.claimed}
            gtnImpact={accounting.gtnImpact}
            recoveryRequired={accounting.recoveryRequired}
            basis={`${formatUsd(a.previouslySettled)} was already expensed when credit memo ${a.byCategory["previously-settled"][0]?.priorRef} was issued, and ${formatUsd(a.previouslyRejected)} was never a cost. None of the ${formatUsd(a.claimed)} is a new gross-to-net charge; the receivable stands and repayment is requested.`}
            lines={accounting.lines}
            caseRef={c.caseId}
            claimRef={c.promotion.promotionId}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <button
            type="button"
            onClick={onBack}
            className="mb-1 inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            All deductions
          </button>
          <h2 className="text-xl font-semibold">
            {c.caseId} — {c.customerName}
          </h2>
          <p className="text-sm text-muted-foreground">
            A promotion deduction re-deducted under a new reference. It is
            matched on similarity to a prior claim, its lineage rebuilt and the
            duplicate proven; the decision and the letter are yours.
          </p>
        </div>
        {processing && !awaitingAdvance && (
          <span className="flex items-center gap-2 text-sm text-muted-foreground">
            <Spinner size="sm" />
            Investigation in progress
          </span>
        )}
      </div>

      <Card className="bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="flex flex-wrap items-center gap-2 text-sm font-semibold">
            <Badge variant="outline" className="whitespace-nowrap">
              {formatUsd(a.claimed)} deducted on {c.invoiceId}
            </Badge>
            <span className="text-xs font-normal text-muted-foreground">
              {doneCount}/{STAGES.length} steps cleared
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-2">
          <StageProgressRail
            stages={STAGES}
            statuses={statuses}
            openStageId={activeStage}
            onStageClick={(id) => {
              if (reached.includes(id)) openStage(id);
            }}
          />
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[minmax(0,1fr)_320px]">
        <div className="space-y-4">
          {STAGES.filter((s) => reached.includes(s.id)).map((stage) => (
            <Card
              key={stage.id}
              ref={(el) => {
                cardRefs.current[stage.id] = el;
              }}
              className={RUN_STAGE_CARD_CLASS}
            >
              <RunStageRow
                label={stage.heading}
                status={statuses[stage.id]}
                expanded={openStages.has(stage.id)}
                summary={stage.log}
                onToggle={() =>
                  setOpenStages((prev) => {
                    const next = new Set(prev);
                    next.has(stage.id) ? next.delete(stage.id) : next.add(stage.id);
                    return next;
                  })}
              />
              {openStages.has(stage.id) && (
                <CardContent className="space-y-4 border-t px-4 py-4 animate-in fade-in slide-in-from-top-2 duration-300">
                  {narration[stage.id] && stage.id !== "decision" && (
                    <AiStageNarration key={stage.id} text={narration[stage.id]} variant="inline" />
                  )}
                  {renderStage(stage.id)}
                </CardContent>
              )}
            </Card>
          ))}
        </div>

        <AgentAuditTrail
          entries={STAGES.filter((s) => statuses[s.id] !== "waiting").map((s) => ({
            id: s.id,
            agent: s.agent,
            agentType: s.agentType,
            message: s.log,
            tone:
              statuses[s.id] === "needsReview"
                ? ("attention" as const)
                : statuses[s.id] === "running"
                  ? ("info" as const)
                  : ("success" as const),
          }))}
        />
      </div>

      {statuses.impact === "passed" && !finaleDismissed && (
        <RunCompleteModal
          eyebrow="Duplicate claim resolved"
          title={`${c.caseId} matched and declined`}
          narrative="The resubmission was matched on similarity to a claim already settled and rejected, its lineage rebuilt across systems, and every dollar shown to be a duplicate. The claim is declined in full, no value is paid twice, and the rejection reason is recorded to catch the next resubmission."
          stats={[
            { label: "re-deducted", value: formatUsd(a.claimed) },
            {
              label: "double payment stopped",
              value: formatUsd(a.previouslySettled),
              tone: "success",
            },
            {
              label: "rejected",
              value: formatUsd(a.duplicateValue),
              tone: "danger",
            },
          ]}
          docs={[
            {
              doc: buildLineageDoc(caseId),
              label: "Claim & settlement lineage",
            },
            {
              doc: buildDupLetterDoc(caseId, true),
              label: `Retailer response ${c.responseLetter.letterRef}`,
            },
          ]}
          primaryLabel="Back to deductions"
          onPrimary={() => {
            setFinaleDismissed(true);
            onBack();
          }}
          secondaryLabel="Stay on this case"
          onSecondary={() => setFinaleDismissed(true)}
        />
      )}
    </div>
  );
}

/* ---------------------------------------------------------------- */

/** The invoice as one bar: what arrived, and what was re-deducted. */
function PaymentSplitBar({
  assessment,
}: {
  assessment: NonNullable<ReturnType<typeof dupClaimAssessment>>;
}) {
  const c = assessment.case;
  const paidPct = (c.amountPaid / c.invoiceAmount) * 100;
  const mounted = useMounted();
  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-3 flex items-baseline justify-between gap-3">
        <h4 className="text-sm font-semibold">Payment against invoice</h4>
        <span className="whitespace-nowrap text-xs text-muted-foreground">
          {c.remittanceId} · {c.receivedDate}
        </span>
      </div>
      <div className="flex h-12 w-full overflow-hidden rounded-lg border-2">
        <div
          className="flex items-center justify-center bg-[var(--success)]/25 transition-all duration-700 ease-out motion-reduce:transition-none"
          style={{ width: mounted ? `${paidPct}%` : "0%" }}
        >
          <span className="text-sm font-semibold text-green-800 tabular-nums">
            {formatUsd(c.amountPaid)} paid
          </span>
        </div>
        <div
          className="flex flex-1 items-center justify-center transition-all duration-500 ease-out motion-reduce:transition-none"
          style={{
            opacity: mounted ? 1 : 0,
            transitionDelay: "600ms",
            backgroundImage:
              "repeating-linear-gradient(45deg, rgba(220,38,38,0.20) 0 6px, transparent 6px 12px)",
          }}
        >
          <span className="whitespace-nowrap px-1 text-xs font-semibold text-red-700 tabular-nums">
            {formatUsd(assessment.claimed)}
          </span>
        </div>
      </div>
      <p className="mt-2 text-xs text-muted-foreground">
        Invoice {formatUsd(c.invoiceAmount)} less {formatUsd(assessment.claimed)}{" "}
        withheld equals {formatUsd(c.amountPaid)} paid.{" "}
        {assessment.reconciles ? "Reconciles." : "Does not reconcile."}
      </p>
      <p className="mt-3 rounded border-l-2 border-muted-foreground/40 bg-muted/30 px-3 py-2 text-xs italic text-muted-foreground">
        &ldquo;{c.customerNote}&rdquo; — remittance note
      </p>
    </div>
  );
}

/** The resubmission matched to the original, with signals and evasion fields. */
function SimilarityMatchCard({
  assessment,
  caseId,
}: {
  assessment: NonNullable<ReturnType<typeof dupClaimAssessment>>;
  caseId: string;
}) {
  const c = assessment.case;
  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-3 flex items-baseline justify-between gap-3">
        <h4 className="text-sm font-semibold">Similarity match</h4>
        <span className="inline-flex items-center gap-1.5 whitespace-nowrap text-xs text-muted-foreground">
          <SystemMark name={c.promotion.tpmSystem} />
          {c.promotion.tpmSystem}
        </span>
      </div>
      <div className="flex flex-wrap items-center gap-2 text-sm">
        <Badge variant="outline" className="font-mono">
          {c.resubmittedClaimRef}
        </Badge>
        <span className="text-muted-foreground">is the same event as</span>
        <Badge className="bg-primary/10 font-mono text-primary">
          {c.originalClaimRef}
        </Badge>
        <Badge
          variant="outline"
          className="border-red-300 bg-red-50 text-red-700"
        >
          {pct(assessment.duplicateConfidence)} confidence
        </Badge>
      </div>

      {/* The identity dimensions, each scored, with a weighted meter. */}
      <div className="mt-3 space-y-2">
        {c.signals.map((s) => (
          <div key={s.signalId} className="rounded-lg border p-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="flex items-center gap-2 text-sm font-medium">
                {s.matchScore === 1 ? (
                  <Check className="h-4 w-4 shrink-0 text-[var(--success)]" />
                ) : (
                  <span className="text-xs font-semibold text-amber-700">
                    {pct(s.matchScore)}
                  </span>
                )}
                {s.dimension}
              </span>
              <span className="text-xs text-muted-foreground">
                {s.original} → {s.resubmitted}
              </span>
            </div>
            <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-muted">
              <div
                className={cn(
                  "h-full rounded-full",
                  s.matchScore === 1 ? "bg-[var(--success)]" : "bg-amber-400"
                )}
                style={{ width: `${s.matchScore * 100}%` }}
              />
            </div>
          </div>
        ))}
      </div>

      {/* What the resubmission altered — why exact-match failed. */}
      <div className="mt-3 rounded-lg border border-dashed border-amber-300 bg-amber-50/50 p-3">
        <p className="mb-2 text-xs font-semibold text-amber-900">
          Fields changed to evade exact-match
        </p>
        <div className="space-y-1.5">
          {c.evasionSignals.map((e) => (
            <div
              key={e.field}
              className="grid grid-cols-[minmax(0,1fr)_minmax(0,1fr)_minmax(0,1fr)] items-baseline gap-2 text-xs"
            >
              <span className="font-medium text-foreground">{e.field}</span>
              <span className="text-left text-muted-foreground line-through">
                {e.original}
              </span>
              <span className="text-right font-medium text-amber-800">
                {e.resubmitted}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-3 flex flex-wrap gap-2 border-t pt-3">
        <SourceDocTrigger
          doc={buildDupDeductionDoc(caseId)}
          label="View the deduction"
        />
        <SourceDocTrigger
          doc={buildSimilarityMatchDoc(caseId)}
          label="View the similarity match"
        />
      </div>
    </div>
  );
}

/** Icon for the system a lineage node's document lives in. */
function SystemIcon({ system }: { system: string }) {
  return <SystemMark name={system} className="h-4 w-4" />;
}

/** Short "YY-MM-DD" form of an ISO date, for the lineage marker. */
function shortDate(date: string) {
  return date.slice(2);
}

/** Icon for a lineage node's kind, shown inside its timeline marker. */
function LineageKindIcon({ kind }: { kind: string }) {
  const cls = "h-4 w-4";
  switch (kind) {
    case "credit":
      return <Check className={cls} />;
    case "rejection":
      return <X className={cls} />;
    case "resubmission":
      return <GitBranch className={cls} />;
    case "promotion":
      return <Megaphone className={cls} />;
    default:
      return <ClipboardList className={cls} />;
  }
}

/** The claim-and-settlement lineage as a horizontal track; one click opens each record. */
function LineageTrail({
  assessment,
  caseId,
}: {
  assessment: NonNullable<ReturnType<typeof dupClaimAssessment>>;
  caseId: string;
}) {
  const c = assessment.case;
  const nodes = c.lineage;
  const [shown, setShown] = useState(0);

  useEffect(() => {
    if (shown >= nodes.length) return;
    const id = setTimeout(() => setShown((n) => n + 1), shown === 0 ? 150 : 450);
    return () => clearTimeout(id);
  }, [shown, nodes.length]);

  const dotTone = (kind: string) =>
    kind === "credit"
      ? "border-[var(--success)] bg-[var(--success)] text-primary-foreground"
      : kind === "rejection"
        ? "border-red-500 bg-red-500 text-primary-foreground"
        : kind === "resubmission"
          ? "border-amber-500 bg-amber-50 text-amber-700 ring-4 ring-amber-100"
          : "border-border bg-card text-muted-foreground";

  return (
    <div className="flex flex-col gap-4 rounded-xl border bg-card p-4">
      <div className="flex items-baseline justify-between gap-3">
        <h4 className="text-sm font-semibold">Claim & settlement lineage</h4>
        <span className="whitespace-nowrap text-xs text-muted-foreground">
          {c.promotion.promotionId}
        </span>
      </div>

      <ol
        className="relative grid gap-2"
        style={{ gridTemplateColumns: `repeat(${nodes.length}, minmax(0, 1fr))` }}
      >
        <span
          aria-hidden
          className="absolute left-[10%] top-4 h-0.5 bg-border transition-all duration-700 ease-out"
          style={{
            width: `${Math.max(0, ((Math.min(shown, nodes.length) - 1) / nodes.length) * 100)}%`,
          }}
        />
        {nodes.map((n, i) => (
          <li
            key={n.nodeId}
            className={cn(
              "relative transition-all duration-500",
              i < shown ? "translate-y-0 opacity-100" : "translate-y-1 opacity-0"
            )}
          >
            <SourceDocRowTrigger
              doc={buildLineageNodeDoc(caseId, n.nodeId)}
              className="flex w-full flex-col items-center gap-1.5 rounded-lg px-1 pb-2 text-center hover:bg-muted/50"
            >
              <span
                className={cn(
                  "relative z-10 flex h-8 w-8 items-center justify-center rounded-full border-2",
                  dotTone(n.kind)
                )}
                title={n.detail}
              >
                <LineageKindIcon kind={n.kind} />
              </span>
              <span className="text-xs font-medium leading-tight">
                {LINEAGE_KIND_LABEL[n.kind] ?? n.kind}
              </span>
              <span className="text-sm font-semibold tabular-nums">
                {n.amount != null ? formatUsd(n.amount) : "—"}
              </span>
              <span className="font-mono text-[10px] leading-tight text-muted-foreground">
                {n.ref.split(" / ").pop()}
                <br />
                {shortDate(n.date)}
              </span>
            </SourceDocRowTrigger>
          </li>
        ))}
      </ol>

      <div className="border-t pt-3">
        <SourceDocTrigger doc={buildLineageDoc(caseId)} label="View the lineage" />
      </div>
    </div>
  );
}

/** The re-deducted amount as one bar, split by what already happened to each dollar. */
function DuplicateBreakdown({
  assessment,
  caseId,
}: {
  assessment: NonNullable<ReturnType<typeof dupClaimAssessment>>;
  caseId: string;
}) {
  const c = assessment.case;
  const total = assessment.claimed || 1;
  const [grown, setGrown] = useState(0);

  useEffect(() => {
    if (grown >= c.components.length) return;
    const id = setTimeout(() => setGrown((g) => g + 1), grown === 0 ? 200 : 500);
    return () => clearTimeout(id);
  }, [grown, c.components.length]);

  return (
    <div className="flex flex-col gap-4 rounded-xl border bg-card p-4">
      <div className="flex items-baseline justify-between gap-3">
        <h4 className="text-sm font-semibold">
          {formatUsd(assessment.claimed)} re-deducted
        </h4>
        <span className="text-sm tabular-nums text-muted-foreground">
          <span className="font-semibold text-[var(--success)]">
            {formatUsd(assessment.genuinelyNew)}
          </span>{" "}
          genuinely new
        </span>
      </div>

      <div className="flex h-10 w-full gap-0.5 overflow-hidden rounded-md bg-muted">
        {c.components.map((x, i) => {
          const settled = x.category === "previously-settled";
          return (
            <div
              key={x.componentId}
              title={x.finding}
              className={cn(
                "flex h-full items-center overflow-hidden whitespace-nowrap px-3 text-xs font-medium text-primary-foreground transition-all duration-700 ease-out",
                settled ? "bg-[var(--success)]" : "bg-red-500"
              )}
              style={{ width: i < grown ? `${(x.amount / total) * 100}%` : "0%" }}
            >
              {formatUsd(x.amount)}
            </div>
          );
        })}
      </div>

      <ul className="flex flex-col">
        {c.components.map((x, i) => {
          const settled = x.category === "previously-settled";
          return (
            <li
              key={x.componentId}
              title={x.finding}
              className={cn(
                "flex items-center gap-2 border-t py-2 text-sm transition-opacity duration-500",
                i < grown ? "opacity-100" : "opacity-0"
              )}
            >
              <span
                className={cn(
                  "h-2.5 w-2.5 shrink-0 rounded-[2px]",
                  settled ? "bg-[var(--success)]" : "bg-red-500"
                )}
              />
              <span className="flex-1">
                {settled ? "Already paid" : "Already rejected"}
              </span>
              <span className="font-mono text-xs text-muted-foreground">
                {x.priorRef.split(" / ").pop()}
              </span>
              <span className="w-24 text-right font-medium tabular-nums">
                {formatUsd(x.amount)}
              </span>
            </li>
          );
        })}
      </ul>

      <div className="border-t pt-3">
        <SourceDocTrigger
          doc={buildDuplicateBreakdownDoc(caseId)}
          label="View the duplicate breakdown"
        />
      </div>
    </div>
  );
}
