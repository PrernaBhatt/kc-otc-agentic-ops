"use client";

import { useEffect, useMemo, useState } from "react";

import { AccountList } from "@/components/mounts/accounts/account-list";
import { AccountRail } from "@/components/mounts/accounts/account-rail";
import { AccountsKpis } from "@/components/mounts/accounts/accounts-kpis";
import {
  accountEscalations,
  accountOpenWork,
  accountRows,
  type AccountLiveState,
} from "@/lib/account-selectors";
import { findAccount } from "@/lib/data/account-owners";
import { useOtcStore } from "@/lib/store";

export function AccountsView() {
  const store = useOtcStore();
  const { focusAccountId, escalations } = store;

  const live: AccountLiveState = useMemo(
    () => ({
      resolvedPromoClaims: store.resolvedPromoClaims,
      resolvedDupClaims: store.resolvedDupClaims,
      resolvedRebateClaims: store.resolvedRebateClaims,
      resolvedFundClaims: store.resolvedFundClaims,
      resolvedBillingDisputes: store.resolvedBillingDisputes,
      resolvedShortPays: store.resolvedShortPays,
      resolvedMultiCauseDeductions: store.resolvedMultiCauseDeductions,
      nonTradeBatchPosted: store.nonTradeBatchPosted,
      resolvedSplitOuts: store.resolvedSplitOuts,
      escalations: store.escalations,
      channelCases: store.channelDeductionCases,
    }),
    [
      store.resolvedPromoClaims,
      store.resolvedDupClaims,
      store.resolvedRebateClaims,
      store.resolvedFundClaims,
      store.resolvedBillingDisputes,
      store.resolvedShortPays,
      store.resolvedMultiCauseDeductions,
      store.nonTradeBatchPosted,
      store.resolvedSplitOuts,
      store.escalations,
      store.channelDeductionCases,
    ]
  );

  const rows = useMemo(
    () =>
      accountRows(live).sort(
        (a, b) => b.overdueEscalations - a.overdueEscalations || b.atRiskUsd - a.atRiskUsd
      ),
    [live]
  );
  const [selectedId, setSelectedId] = useState<string>(() => focusAccountId ?? rows[0]?.accountId);
  useEffect(() => {
    if (focusAccountId) setSelectedId(focusAccountId);
  }, [focusAccountId]);

  const account = findAccount(selectedId);
  const work = useMemo(() => (account ? accountOpenWork(account.accountId, live) : []), [account, live]);
  const accountEsc = useMemo(
    () => (account ? accountEscalations(account.accountId, escalations) : []),
    [account, escalations]
  );

  return (
    <div className="animate-enter flex flex-col gap-6">
      <h2 className="text-xl font-semibold text-foreground">Accounts</h2>
      <AccountsKpis escalations={escalations} />
      <div className="grid items-start gap-4 lg:grid-cols-[minmax(0,1fr)_380px]">
        <AccountList rows={rows} selectedId={account?.accountId ?? null} onSelect={setSelectedId} />
        {account && <AccountRail account={account} work={work} escalations={accountEsc} />}
      </div>
    </div>
  );
}
