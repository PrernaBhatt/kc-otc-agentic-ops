"use client";

import { useState } from "react";
import {
  ArrowRight,
  CircleCheck,
  ChevronDown,
  ChevronUp,
  Clock,
  DollarSign,
  Package,
  Play,
  Shield,
  Sparkles,
  TrendingUp,
  TriangleAlert,
  User,
  type LucideIcon,
} from "lucide-react";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AgentIcon } from "@/components/agents/agent-icon";
import { Spinner } from "@/components/agents/spinner";
import { AgentActivityFeed } from "@/components/agents/agent-activity-feed";
import { RegulatoryHoldCard } from "@/components/mounts/review-hold/regulatory-hold-card";
import { creditDecision, agentActivities } from "@/lib/data";
import { REGULATED_ORDER_ID } from "@/lib/data/regulatory";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

interface CreditHoldLine {
  orderLineId: string;
  sku: string;
  productName: string;
  qty: number;
  unitPrice: number;
  lineValue: number;
  loopLineFlag: boolean;
  priceValidated: boolean;
}

interface CreditHoldOrder {
  orderId: string;
  customerName: string;
  totalValue: number;
  status: string;
  loopOrderFlag: boolean;
  orderDate: string;
  holdReason?: string | null;
  lineItems: CreditHoldLine[];
}

interface CreditDecisionOptionData {
  id: string;
  name: string;
  type: string;
  confidence: number;
  conditions: string[];
  riskDelta: number;
  ltvImpact: number;
  cashFlowEffect: number;
}

interface CreditDecisionData {
  orderId: string;
  riskScore: number;
  ltvScore: number;
  propensityScore: number;
  options: CreditDecisionOptionData[];
  guardrailsApplied: string[];
}

// Decision options for the second hold order (SO-710252, from the store)
const extraCreditDecision: CreditDecisionData = {
  orderId: "SO-710252",
  riskScore: 0.58,
  ltvScore: 0.71,
  propensityScore: 0.64,
  options: [
    {
      id: "split",
      name: "Split Shipment Release",
      type: "Balanced",
      confidence: 0.82,
      conditions: ["Release 50% now", "Balance on payment", "Insurance required"],
      riskDelta: -0.15,
      ltvImpact: 0.08,
      cashFlowEffect: 92500,
    },
    {
      id: "conditional",
      name: "Full Conditional Release",
      type: "Aggressive",
      confidence: 0.76,
      conditions: ["30-day payment plan", "COD on future orders"],
      riskDelta: 0.08,
      ltvImpact: 0.12,
      cashFlowEffect: 185000,
    },
    {
      id: "hold",
      name: "Maintain Hold",
      type: "Conservative",
      confidence: 0.89,
      conditions: ["Payment upfront", "No release"],
      riskDelta: -0.25,
      ltvImpact: -0.18,
      cashFlowEffect: 0,
    },
  ],
  guardrailsApplied: [
    "Credit Limit Check",
    "Payment History Review",
    "Industry Risk Assessment",
  ],
};

function CreditOrderCard({
  order,
  onClick,
  isCompleted = false,
  isExpanded = false,
}: {
  order: CreditHoldOrder;
  onClick?: () => void;
  isCompleted?: boolean;
  isExpanded?: boolean;
}) {
  const [expanded, setExpanded] = useState(isExpanded);
  const statusConfig = ((status: string): { color: string; icon: LucideIcon } => {
    switch (status) {
      case "Hold":
        return { color: "bg-primary text-primary-foreground", icon: TriangleAlert };
      case "Blocked":
        return {
          color: "bg-[var(--warning)] text-[var(--warning-foreground)]",
          icon: TriangleAlert,
        };
      case "Processing":
        return { color: "bg-[var(--info)] text-white", icon: Clock };
      case "Released":
      case "Fulfilled":
        return { color: "bg-[var(--success)] text-white", icon: CircleCheck };
      default:
        return { color: "bg-muted text-muted-foreground", icon: Package };
    }
  })(order.status);
  const StatusIcon = statusConfig.icon;
  return (
    <Card
      className={cn(
        "transition-all",
        order.status === "Hold" && "border-primary/50",
        order.status === "Blocked" && "border-[var(--warning)]/50",
        isCompleted && "opacity-60"
      )}
    >
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <CardTitle className="text-base font-semibold">
                {order.orderId}
              </CardTitle>
              {isCompleted ? (
                <Badge className="bg-[var(--success)] text-white">
                  <CircleCheck className="h-3 w-3 mr-1" />
                  Complete
                </Badge>
              ) : (
                <Badge className={statusConfig.color}>
                  <StatusIcon className="h-3 w-3 mr-1" />
                  {order.status}
                </Badge>
              )}
              {order.loopOrderFlag && (
                <Badge
                  variant="outline"
                  className="border-[var(--success)] text-[var(--success)]"
                >
                  Loop Order
                </Badge>
              )}
            </div>
            <p className="text-sm text-muted-foreground">{order.customerName}</p>
          </div>
          <div className="text-right">
            <div className="text-lg font-bold text-foreground">
              ${order.totalValue.toLocaleString()}
            </div>
            <div className="text-xs text-muted-foreground">{order.orderDate}</div>
          </div>
        </div>
        {order.holdReason && (
          <div className="flex items-center gap-2 mt-2 p-2 bg-primary/10 rounded-md">
            <TriangleAlert className="h-4 w-4 text-destructive" />
            <span className="text-sm text-primary font-medium">
              Hold Reason: {order.holdReason}
            </span>
          </div>
        )}
      </CardHeader>
      {expanded && (
        <CardContent className="pt-0">
          <div className="border-t pt-3">
            <div className="text-sm font-medium mb-2 text-foreground">
              Line Items ({order.lineItems.length})
            </div>
            <div className="space-y-2">
              {order.lineItems.map((line) => (
                <div
                  key={line.orderLineId}
                  className="flex items-center justify-between p-2 bg-muted/50 rounded-md text-sm"
                >
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-xs text-muted-foreground">
                      {line.sku}
                    </span>
                    <span className="text-foreground">{line.productName}</span>
                    {line.loopLineFlag && (
                      <Badge
                        variant="outline"
                        className="text-xs border-[var(--success)] text-[var(--success)]"
                      >
                        Loop
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-muted-foreground">Qty: {line.qty}</span>
                    <span className="font-medium text-foreground">
                      ${line.lineValue.toLocaleString()}
                    </span>
                    {line.priceValidated && (
                      <CircleCheck className="h-4 w-4 text-[var(--success)]" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      )}
      <div className="px-6 pb-4 flex items-center justify-between">
        <Button variant="ghost" size="sm" onClick={() => setExpanded(!expanded)}>
          {expanded ? (
            <>
              <ChevronUp className="h-4 w-4 mr-1" />
              Collapse
            </>
          ) : (
            <>
              <ChevronDown className="h-4 w-4 mr-1" />
              View Lines
            </>
          )}
        </Button>
        {onClick && (
          <Button
            variant="default"
            size="sm"
            onClick={onClick}
            className="bg-primary hover:bg-primary/90"
            disabled={isCompleted}
          >
            <Play className="h-4 w-4 mr-1" />
            {isCompleted ? "Completed" : "Process Order"}
          </Button>
        )}
      </div>
    </Card>
  );
}

function AiDecisionPanel({
  decision,
  onApprove,
}: {
  decision: CreditDecisionData;
  onApprove: (optionId: string) => void;
}) {
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isApproving, setIsApproving] = useState(false);
  const handleApprove = async () => {
    if (selectedOption) {
      setIsApproving(true);
      await new Promise((resolve) => setTimeout(resolve, 1500));
      onApprove(selectedOption);
      setIsApproving(false);
    }
  };
  return (
    <Card className="border-primary/20 bg-card">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            <CardTitle className="text-lg">AI Decision Options</CardTitle>
          </div>
          <Badge variant="outline" className="text-primary border-primary">
            Golden Trio
          </Badge>
        </div>
        <CardDescription>
          Select an option to release order {decision.orderId}. Human approval
          required.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-3 gap-4 p-4 bg-muted/50 rounded-lg">
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 text-muted-foreground text-sm mb-1">
              <Shield className="h-4 w-4" />
              Risk Score
            </div>
            <div className="text-2xl font-bold text-foreground">
              {(100 * decision.riskScore).toFixed(0)}%
            </div>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 text-muted-foreground text-sm mb-1">
              <TrendingUp className="h-4 w-4" />
              LTV Score
            </div>
            <div className="text-2xl font-bold text-foreground">
              {(100 * decision.ltvScore).toFixed(0)}%
            </div>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 text-muted-foreground text-sm mb-1">
              <DollarSign className="h-4 w-4" />
              Propensity
            </div>
            <div className="text-2xl font-bold text-foreground">
              {(100 * decision.propensityScore).toFixed(0)}%
            </div>
          </div>
        </div>
        <div className="space-y-3">
          {decision.options.map((option) => (
            <div
              key={option.id}
              className={cn(
                "p-4 border rounded-lg cursor-pointer transition-all",
                selectedOption === option.id
                  ? "border-primary bg-primary/5 ring-2 ring-primary/20"
                  : "border-border hover:border-primary/50"
              )}
              onClick={() => setSelectedOption(option.id)}
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-semibold text-foreground">
                      {option.name}
                    </span>
                    <Badge
                      className={((type: string) => {
                        switch (type) {
                          case "Aggressive":
                            return "bg-[var(--success)] text-white";
                          case "Balanced":
                            return "bg-[var(--info)] text-white";
                          case "Conservative":
                            return "bg-[var(--warning)] text-[var(--warning-foreground)]";
                          default:
                            return "bg-muted text-muted-foreground";
                        }
                      })(option.type)}
                    >
                      {option.type}
                    </Badge>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {option.conditions.map((condition, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {condition}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm text-muted-foreground">Confidence</div>
                  <div className="text-lg font-bold text-foreground">
                    {(100 * option.confidence).toFixed(0)}%
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3 mt-3 pt-3 border-t">
                <div>
                  <div className="text-xs text-muted-foreground">
                    Residual Risk
                  </div>
                  <div className="font-semibold text-foreground text-base mt-0.5">
                    {(100 * option.riskDelta).toFixed(0)}%
                  </div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">LTV Impact</div>
                  <div
                    className={cn(
                      "font-semibold text-base mt-0.5",
                      option.ltvImpact > 0
                        ? "text-[var(--success)]"
                        : "text-primary"
                    )}
                  >
                    {option.ltvImpact > 0 ? "+" : ""}
                    {(100 * option.ltvImpact).toFixed(0)}%
                  </div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">
                    Cash Exposure
                  </div>
                  <div className="font-semibold text-foreground text-base mt-0.5">
                    {option.cashFlowEffect > 0
                      ? `$${option.cashFlowEffect.toLocaleString()}`
                      : "-"}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="p-3 bg-[var(--success)]/10 rounded-lg">
          <div className="flex items-center gap-2 text-sm font-medium text-[var(--success)] mb-2">
            <CircleCheck className="h-4 w-4" />
            Guardrails Applied
          </div>
          <div className="flex flex-wrap gap-2">
            {decision.guardrailsApplied.map((guardrail, index) => (
              <Badge
                key={index}
                variant="secondary"
                className="bg-[var(--success)]/20 text-[var(--success)]"
              >
                {guardrail}
              </Badge>
            ))}
          </div>
        </div>
        <Button
          className="w-full"
          size="lg"
          disabled={!selectedOption || isApproving}
          onClick={handleApprove}
        >
          {isApproving ? (
            <>Processing Approval...</>
          ) : (
            <>
              <User className="h-4 w-4 mr-2" />
              Approve as Credit Manager
              <ArrowRight className="h-4 w-4 ml-2" />
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
}

export function CreditReviewView({
  focusOrderId,
  onNavigateToFulfillment,
  onBack,
}: {
  focusOrderId?: string;
  onNavigateToFulfillment: () => void;
  onBack?: () => void;
}) {
  const [approvedOrders, setApprovedOrders] = useState<Record<string, boolean>>(
    {}
  );
  const [approvedOptions, setApprovedOptions] = useState<
    Record<string, string>
  >({});
  const { releasedRegulatoryOrders, orders, approveCreditHold } = useOtcStore();
  // Hold cards come from the store; orders approved in this session stay
  // visible (with the released banner) even after the store flips their
  // status to Processing.
  const allHoldOrders: CreditHoldOrder[] = orders.filter(
    (order) => order.status === "Hold" || approvedOrders[order.orderId]
  );
  const displayOrders = focusOrderId
    ? allHoldOrders.filter((order) => order.orderId === focusOrderId)
    : allHoldOrders;
  // Quality hold mount: shown below the credit cards (or alone when focused).
  const showRegulatoryHold =
    !focusOrderId || focusOrderId === REGULATED_ORDER_ID;
  const regulatoryPendingCount =
    showRegulatoryHold && !releasedRegulatoryOrders.has(REGULATED_ORDER_ID)
      ? 1
      : 0;
  const pendingReviewCount =
    displayOrders.filter((order) => !approvedOrders[order.orderId]).length +
    regulatoryPendingCount;
  return (
    <div className="space-y-6 pb-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          {onBack && (
            <Button
              variant="outline"
              size="sm"
              onClick={onBack}
              className="gap-1.5"
            >
              <ArrowRight className="h-4 w-4 rotate-180" />
              Back to Exceptions
            </Button>
          )}
          <div>
            <h1 className="text-lg font-bold text-foreground">
              Review Order Hold
            </h1>
            <p className="text-muted-foreground">
              {focusOrderId
                ? focusOrderId === REGULATED_ORDER_ID
                  ? `Reviewing quality hold for ${focusOrderId} — select a release option to proceed`
                  : `Reviewing credit hold for ${focusOrderId} — select a release option to proceed`
                : "Review and approve AI-recommended decisions for credit holds"}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="gap-1">
            <AgentIcon type="credit" size="sm" />
            {pendingReviewCount} Pending Review
          </Badge>
        </div>
      </div>
      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {displayOrders.map((order, index) => {
            const decision: CreditDecisionData =
              order.orderId === "SO-710252"
                ? extraCreditDecision
                : creditDecision;
            const isApproved = approvedOrders[order.orderId];
            return (
              <div key={order.orderId} className="space-y-6">
                {!isApproved && (
                  <Card className="border-primary/50 bg-primary/5">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <TriangleAlert className="h-5 w-5 text-destructive" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-semibold text-foreground">
                            Credit Hold Detected
                          </div>
                          <div className="text-sm text-muted-foreground">
                            Order {order.orderId} requires approval. AI agents
                            have curated decision options.
                          </div>
                        </div>
                        <Badge className="bg-primary text-primary-foreground gap-1 flex-shrink-0">
                          <Spinner size="sm" />
                          Action Required
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                )}
                {isApproved && (
                  <Card className="border-[var(--success)]/50 bg-[var(--success)]/5">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="h-10 w-10 rounded-full bg-[var(--success)]/10 flex items-center justify-center flex-shrink-0">
                          <CircleCheck className="h-5 w-5 text-[var(--success)]" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-semibold text-foreground">
                            Order Released Successfully
                          </div>
                          <div className="text-sm text-muted-foreground">
                            Decision approved: {approvedOptions[order.orderId]}.
                            Ready to proceed with fulfillment.
                          </div>
                        </div>
                        <Badge className="bg-[var(--success)] text-white flex-shrink-0">
                          Released
                        </Badge>
                      </div>
                      <Button
                        onClick={() => onNavigateToFulfillment()}
                        className="w-full bg-[var(--success)] hover:bg-[var(--success)]/90"
                        size="lg"
                      >
                        View Fulfillment Progress
                        <ArrowRight className="h-4 w-4 ml-2" />
                      </Button>
                    </CardContent>
                  </Card>
                )}
                <CreditOrderCard
                  order={{
                    ...order,
                    status: isApproved ? "Released" : order.status,
                  }}
                  isExpanded
                />
                {!isApproved && (
                  <AiDecisionPanel
                    decision={decision}
                    onApprove={(optionId) => {
                      setApprovedOrders({
                        ...approvedOrders,
                        [order.orderId]: true,
                      });
                      setApprovedOptions({
                        ...approvedOptions,
                        [order.orderId]: optionId,
                      });
                      // Propagate the human decision: order leaves Hold and
                      // its Credit Hold exception resolves on every page.
                      approveCreditHold(order.orderId);
                    }}
                  />
                )}
                {index < displayOrders.length - 1 && (
                  <div className="border-t pt-6" />
                )}
              </div>
            );
          })}
          {showRegulatoryHold && (
            <>
              {displayOrders.length > 0 && <div className="border-t pt-6" />}
              <RegulatoryHoldCard onBackToExceptions={onBack} />
            </>
          )}
        </div>
        <div className="space-y-6">
          <AgentActivityFeed activities={agentActivities} />
        </div>
      </div>
    </div>
  );
}
