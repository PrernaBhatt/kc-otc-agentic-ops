"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useMounted } from "@/lib/hooks/use-mounted";
import {
  ArrowLeft,
  Banknote,
  Check,
  CircleCheck,
  FileText,
  Landmark,
  Mail,
  Scale,
  SlidersHorizontal,
  Pencil,
  ThumbsUp,
  Users,
  X,
} from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import { Spinner } from "@/components/agents/spinner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { SignedApproveButton } from "@/components/shared/signed-approve-button";
import { findAccount } from "@/lib/data/account-owners";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  SourceDocTrigger,
  SourceDocRowTrigger,
} from "@/components/modals/source-doc-preview";
import { formatUsd } from "@/lib/chargeback-selectors";
import { TODAY } from "@/lib/data/clock";
import {
  rebateClaimAssessment,
  rebateClaimAccounting,
  renderRebateClaimLetter,
  REBATE_VARIANCE_LABEL,
} from "@/lib/rebate-claim-selectors";
import {
  buildRebateDeductionDoc,
  buildAgreementDoc,
  buildBasisDoc,
  buildEntityDoc,
  buildProductGroupDoc,
  buildVarianceDoc,
  buildRebateLetterDoc,
} from "@/lib/docs-rebate-claims";
  import { useOtcStore } from "@/lib/store";
import { ClaimEditModal } from "@/components/modals/claim-edit-modal";
import { cn } from "@/lib/utils";
import { SystemMark } from "@/components/shared/system-badge";

import {
  AiStageNarration,
  narrationDwellMs,
} from "@/components/mounts/chargebacks/ai-stage-narration";
import {
  AgentAuditTrail,
  RunStageRow,
  RUN_STAGE_BODY_CLASS,
  RUN_STAGE_CARD_CLASS,
} from "@/components/mounts/shared/run-stage-row";
import { StageProgressRail } from "@/components/mounts/shared/stage-progress-rail";
import { RunCompleteModal } from "@/components/mounts/shared/run-complete-modal";
import { GtnImpactPanel } from "@/components/mounts/deductions/gtn-impact-panel";
import { DisputeLetterComposer } from "@/components/mounts/deductions/dispute-letter-composer";
import { AgentDecision } from "@/components/mounts/deductions/agent-decision";

type SimStatus = "waiting" | "running" | "passed" | "needsReview";

/**
 * Scenario 3 — growth rebate recalculation, in seven steps.
 *
 * A retailer bills a 3% growth rebate of $500,000 on gross sales across itself
 * and its affiliates. The run reads the rebate formula out of the signed
 * agreement (as amended), decides which entities and SKUs are in scope,
 * rebuilds net eligible sales, re-derives the attained tier, and shows the
 * four drivers that close the gap to a validated $335,000. Three steps are
 * gates: confirming the contract basis, the partial-approval decision and the
 * outgoing letter.
 */
const STAGES = [
  {
    id: "intake",
    label: "Deduction",
    heading: "Growth rebate withheld on the invoice",
    agent: "Deduction Intake Agent",
    agentType: "orchestrator",
    icon: Banknote,
    log: "Rebate deduction matched to the invoice and the rebate program.",
  },
  {
    id: "contract",
    label: "Contract terms",
    heading: "Rebate formula read from the signed agreement",
    agent: "Contract Intelligence Agent",
    agentType: "document",
    icon: FileText,
    log: "Formula and the latest amendment extracted — net basis, exclusions, amended rate table.",
  },
  {
    id: "scope",
    label: "Eligibility",
    heading: "Eligible entities and products mapped",
    agent: "Entitlement Agent",
    agentType: "validation",
    icon: Users,
    log: "Contracted entities and eligible SKUs separated from the aggregated claim.",
  },
  {
    id: "recalc",
    label: "Recalculation",
    heading: "Net eligible sales and attained tier",
    agent: "Rebate Calculation Agent",
    agentType: "validation",
    icon: SlidersHorizontal,
    log: "Net eligible sales rebuilt; growth re-tested against the amended tier table.",
  },
  {
    id: "decision",
    label: "Decision",
    heading: "Validated rebate and unsupported value",
    agent: "Trade Finance Agent",
    agentType: "credit",
    icon: Scale,
    log: "Validated rebate computed. Awaiting a decision.",
  },
  {
    id: "letter",
    label: "Retailer response",
    heading: "Retailer response",
    agent: "Correspondence Agent",
    agentType: "invoice",
    icon: Mail,
    log: "Evidence-led response drafted with the calculation. Not yet issued.",
  },
  {
    id: "impact",
    label: "Impact",
    heading: "Accrual true-up and accounting impact",
    agent: "Revenue Accounting Agent",
    agentType: "invoice",
    icon: Landmark,
    log: "Validated rebate expensed; accrual trued up; receivable reinstated.",
  },
] as const;

const STAGE_DWELL_MS = 4000;

const asText = (n: string | string[] | undefined) =>
  Array.isArray(n) ? n.join("\n") : (n ?? "");

const pct1 = (n: number) => `${n.toLocaleString("en-US")}%`;

export function RebateClaimRun({
  caseId,
  onBack,
}: {
  caseId: string;
  onBack: () => void;
}) {
  const { resolveRebateClaim, claimEdits, setClaimEdit } = useOtcStore();
  const edit = claimEdits[caseId];
  const assessment = rebateClaimAssessment(caseId, edit);
  const accounting = rebateClaimAccounting(caseId, edit);
  const anchorValidated = rebateClaimAssessment(caseId)?.validated ?? 0;

  const [statuses, setStatuses] = useState<Record<string, SimStatus>>(() =>
    Object.fromEntries(STAGES.map((s) => [s.id, "waiting" as SimStatus]))
  );
  const [openStages, setOpenStages] = useState<Set<string>>(new Set());
  const [activeStage, setActiveStage] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);
  const [awaitingAdvance, setAwaitingAdvance] = useState(false);
  const [basisConfirmed, setBasisConfirmed] = useState(false);
  const [decided, setDecided] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [letterSent, setLetterSent] = useState(false);
  const [sentOn, setSentOn] = useState<string | undefined>(undefined);
  const [finaleDismissed, setFinaleDismissed] = useState(false);

  const advanceRef = useRef<(() => void) | null>(null);
  const startedRef = useRef(false);
  const basisRef = useRef(false);
  const decidedRef = useRef(false);
  const letterRef = useRef(false);
  const cardRefs = useRef<Record<string, HTMLDivElement | null>>({});

  const narration: Record<string, string | string[]> = assessment
    ? {
  intake: `${assessment.case.customerName} withheld ${formatUsd(assessment.claimed)} for a ${pct1(assessment.claimedTierPct)} growth rebate under ${assessment.case.claimRef}, calculated on gross sales across affiliates.`,
  contract: [
  `The answer is in the contract, not the claim.`,
  `Agreement ${assessment.case.program.agreementRef} measures growth on net eligible sales, excludes the Professional wiper range, and caps the rate at 2%.`,
  ],
  scope: `Only contracted entities and eligible ranges count toward the basis.`,
  recalc: [
  `Net eligible sales rebuild to ${formatUsd(assessment.netEligibleSales)} against a baseline of ${formatUsd(assessment.case.program.baselineNetSales)} — ${pct1(assessment.netGrowthPct)} growth.`,
  `That attains ${assessment.attainedTier.label} at ${pct1(assessment.attainedTier.ratePct)}, not the ${pct1(assessment.claimedTierPct)} billed.`,
  ],
  decision: `AI recommends approving the validated ${formatUsd(assessment.validated)} and disputing ${formatUsd(assessment.unsupported)} across four drivers.`,
  letter: `Response ${assessment.case.responseLetter.letterRef} drafted, explaining each driver with the calculation attached. Approval required before sending.`,
  impact: `Only the validated ${formatUsd(assessment.validated)} is a trade cost; ${formatUsd(assessment.unsupported)} of receivable is reinstated.`,
      }
    : {};
  const narrationRef = useRef(narration);
  narrationRef.current = narration;

  const openStage = useCallback((id: string) => {
    setOpenStages(new Set([id]));
    setActiveStage(id);
  }, []);

  const runFrom = useCallback(
    async (startId: string) => {
      setProcessing(true);
      const from = Math.max(0, STAGES.findIndex((s) => s.id === startId));
      for (const stage of STAGES.slice(from)) {
        if (stage.id === "scope" && !basisRef.current) {
          setStatuses((p) => ({ ...p, contract: "needsReview" }));
          openStage("contract");
          setProcessing(false);
          return;
        }
        if (stage.id === "decision" && !decidedRef.current) {
          setStatuses((p) => ({ ...p, decision: "needsReview" }));
          openStage("decision");
          setProcessing(false);
          return;
        }
        if (stage.id === "letter" && !letterRef.current) {
          setStatuses((p) => ({ ...p, letter: "needsReview" }));
          openStage("letter");
          setProcessing(false);
          return;
        }
        setStatuses((p) => ({ ...p, [stage.id]: "running" }));
        openStage(stage.id);

        let marked = false;
        const markPassed = () => {
          if (marked) return;
          marked = true;
          setStatuses((p) => ({ ...p, [stage.id]: "passed" }));
        };
        const dwell = setTimeout(
          markPassed,
          narrationDwellMs(asText(narrationRef.current[stage.id]), STAGE_DWELL_MS)
        );
        const advanced = new Promise<void>((r) => {
          advanceRef.current = r;
        });
        setAwaitingAdvance(true);
        await advanced;
        setAwaitingAdvance(false);
        clearTimeout(dwell);
        markPassed();
      }
      setProcessing(false);
      setActiveStage(null);
    },
    [openStage]
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Enter") return;
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      if (!advanceRef.current) return;
      e.preventDefault();
      const go = advanceRef.current;
      advanceRef.current = null;
      go();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    if (startedRef.current || !assessment) return;
    startedRef.current = true;
    void runFrom("intake");
  }, [runFrom, assessment]);

  useEffect(() => {
    if (!activeStage) return;
    const node = cardRefs.current[activeStage];
    node?.scrollIntoView({ behavior: "smooth", block: "center" });
  }, [activeStage]);

  useEffect(() => {
    if (!basisConfirmed) return;
    setStatuses((p) => ({ ...p, contract: "passed" }));
    void runFrom("scope");
  }, [basisConfirmed, runFrom]);

  useEffect(() => {
    if (!decided) return;
    setStatuses((p) => ({ ...p, decision: "passed" }));
    void runFrom("letter");
  }, [decided, runFrom]);

  useEffect(() => {
    if (!letterSent) return;
    setStatuses((p) => ({ ...p, letter: "passed" }));
    void runFrom("impact");
  }, [letterSent, runFrom]);

  useEffect(() => {
    if (statuses.impact === "passed") resolveRebateClaim(caseId);
  }, [statuses.impact, resolveRebateClaim, caseId]);

  if (!assessment || !accounting) return null;

  const a = assessment;
  const c = a.case;
  const doneCount = STAGES.filter((s) => statuses[s.id] === "passed").length;
  const reached: string[] = STAGES.filter(
    (s) => statuses[s.id] !== "waiting"
  ).map((s) => s.id);

  const decisionReasoning = [
    `Recalculated on ${formatUsd(assessment.netEligibleSales)} of eligible sales, the rebate is ${formatUsd(assessment.validated)}.`,
    `The other ${formatUsd(assessment.unsupported)} of the ${formatUsd(assessment.claimed)} claim rests on ineligible entities and products.`,
    `Decision: settle ${formatUsd(assessment.validated)}, dispute ${formatUsd(assessment.unsupported)}.`,
  ];
  const renderStage = (stageId: string) =>
    stageId === "decision" ? (
      <AgentDecision stepKey={`${caseId}:decision`} lines={decisionReasoning}>
        {renderBody(stageId)}
      </AgentDecision>
    ) : (
      renderBody(stageId)
    );

  const renderBody = (id: string) => {
    switch (id) {
      case "intake":
        return (
          <div className="space-y-3">
            <PaymentSplitBar assessment={a} />
            <SourceDocTrigger
              doc={buildRebateDeductionDoc(caseId)}
              label="View the rebate claim"
            />
          </div>
        );
      case "contract":
        return (
          <div className="space-y-3">
            <ComparisonCard assessment={a} caseId={caseId} />
            {basisConfirmed ? (
              <p className="flex items-center gap-1.5 text-xs text-[var(--success)]">
                <ThumbsUp className="h-3.5 w-3.5" />
                Confirmed by you — re-run on {c.program.amendmentRef}.
              </p>
            ) : (
              <div className="flex flex-wrap items-center gap-3 rounded-lg border-2 border-amber-200 bg-amber-50/60 px-3 py-2.5">
                <span className="text-xs text-amber-900">
                  Confirm the rebate should be re-run on the amended agreement
                  ({c.program.amendmentRef}) before the recalculation. Nothing is
                  recorded until you click.
                </span>
                <Button
                  size="sm"
                  className="whitespace-nowrap"
                  onClick={() => {
                    basisRef.current = true;
                    setBasisConfirmed(true);
                  }}
                >
                  Confirm contract basis
                </Button>
              </div>
            )}
          </div>
        );
      case "scope":
        return <EligibilityCard assessment={a} caseId={caseId} />;
      case "recalc":
        return <RecalcCard assessment={a} caseId={caseId} />;
      case "decision":
        return (
          <div className="space-y-3">
            <div className="grid gap-3 sm:grid-cols-3">
              <div className="rounded-lg border-2 border-[var(--success)]/40 bg-[var(--success)]/5 p-3">
                <p className="text-xs text-muted-foreground">Validated rebate</p>
                <p className="text-2xl font-bold text-[var(--success)]">
                  {formatUsd(a.validated)}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {pct1(a.attainedTier.ratePct)} on net eligible sales
                </p>
              </div>
              <div className="rounded-lg border-2 border-red-300 bg-red-50 p-3">
                <p className="text-xs text-muted-foreground">Unsupported</p>
                <p className="text-2xl font-bold text-red-700">
                  {formatUsd(a.unsupported)}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  request repayment
                </p>
              </div>
              <div className="rounded-lg border-2 border-muted bg-muted/30 p-3">
                <p className="text-xs text-muted-foreground">Claimed</p>
                <p className="text-2xl font-bold tabular-nums">
                  {formatUsd(a.claimed)}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  at {pct1(a.claimedTierPct)}
                </p>
              </div>
            </div>
            {decided ? (
              <p className="flex items-center gap-1.5 text-xs text-[var(--success)]">
                <ThumbsUp className="h-3.5 w-3.5" />
                Decided by you — approve {formatUsd(a.validated)}, dispute{" "}
                {formatUsd(a.unsupported)}.
              </p>
            ) : (
              <div className="flex flex-wrap items-center gap-3 rounded-lg border-2 border-amber-200 bg-amber-50/60 px-3 py-2.5">
                <span className="text-xs text-amber-900">
                  Awaiting your decision. Nothing is recorded until you click.
                </span>
                <div className="flex flex-wrap items-center gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="whitespace-nowrap gap-1.5"
                    onClick={() => setEditOpen(true)}
                  >
                    <Pencil className="h-3.5 w-3.5" />
                    Edit
                  </Button>
                  <SignedApproveButton
                    gateId={`${caseId}:G1`}
                    title="Settle the growth rebate claim"
                    caseId={c.caseId}
                    accountId={findAccount(c.customerName)?.accountId ?? ""}
                    module="Deductions"
                    system="Vistex"
                    controls={["1.7.4", "1.4.4"]}
                    evidence={[
                      { id: "claim", label: `Rebate claim ${c.claimRef}`, system: "Vistex" },
                      { id: "tier", label: "Tier validated on net sales", system: "Vistex" },
                    ]}
                    lines={[
                      { label: "Validated rebate", amountUsd: a.validated, kind: "other" },
                      { label: "Disputed", amountUsd: a.unsupported, kind: "charge-back" },
                    ]}
                    attestation={`I approve ${formatUsd(a.validated)} against the contract tier and dispute ${formatUsd(a.unsupported)} on ${c.caseId}.`}
                    action={`Approved ${formatUsd(a.validated)}, disputed ${formatUsd(a.unsupported)}`}
                    decision="Partially approved"
                    onSigned={() => {
                      decidedRef.current = true;
                      setDecided(true);
                    }}
                  >
                    Approve {formatUsd(a.validated)} · dispute{" "}
                    {formatUsd(a.unsupported)}
                  </SignedApproveButton>
                </div>
              </div>
            )}
          </div>
        );
      case "letter": {
        const letter = renderRebateClaimLetter(caseId, edit)!;
        return (
          <DisputeLetterComposer
            letterKey={c.caseId}
            from={`${c.responseLetter.from} <trade.finance@internal.example>`}
            to={`${c.responseLetter.to} <trade.finance@retailer.example>`}
            subject={letter.subject}
            body={letter.body}
            attachments={[
              {
                doc: buildRebateDeductionDoc(caseId),
                label: `Deduction ${c.remittanceId}`,
              },
              {
                doc: buildAgreementDoc(caseId),
                label: "Signed agreement (amended)",
              },
              {
                doc: buildBasisDoc(caseId),
                label: "Net eligible sales build-up",
              },
              {
                doc: buildVarianceDoc(caseId),
                label: "Variance breakdown",
              },
              {
                doc: buildRebateLetterDoc(caseId, letterSent),
                label: "Letter as a document",
              },
            ]}
            sent={letterSent}
            sentDate={sentOn}
            sentNote={`Issued to ${c.customerName}. Validated ${formatUsd(a.validated)} settled; repayment of ${formatUsd(a.unsupported)} requested within 30 days.`}
            canSend={statuses.letter === "needsReview"}
            blockedNote="Take the decision first."
            onSend={() => {
              letterRef.current = true;
              setSentOn(TODAY);
              setLetterSent(true);
            }}
          />
        );
      }
      case "impact":
        return (
          <GtnImpactPanel
            shortPay={a.claimed}
            gtnImpact={accounting.gtnImpact}
            recoveryRequired={accounting.recoveryRequired}
            basis={`Only the validated ${formatUsd(a.validated)} is a genuine growth-rebate cost and settles against the deduction. The accrual, carried at the claimed rate, is trued up by ${formatUsd(accounting.accrualTrueUp)}, and ${formatUsd(a.unsupported)} of receivable is reinstated for repayment.`}
            lines={accounting.lines}
            caseRef={c.caseId}
            claimRef={c.program.programId}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      {editOpen && (
        <ClaimEditModal
          title="Edit rebate approval"
          caseLabel={`${c.caseId} — ${c.customerName} · ${formatUsd(a.claimed)} claimed`}
          total={a.claimed}
          primaryValue={a.validated}
          anchorValue={anchorValidated}
          leftLabel="Approve as rebate"
          rightLabel="Dispute"
          leftHint="Paid as a valid growth rebate (gross-to-net)"
          rightHint="Recovered from the customer"
          leftTone="success"
          rightTone="amber"
          aiRationale={`AI validates ${formatUsd(anchorValidated)} against the audited tier and disputes the rest of the ${formatUsd(a.claimed)} claim. Adjust what you approve and the letter and postings follow.`}
          presets={[
            { id: "ai", label: "AI recommendation", detail: "Validated tier only", value: anchorValidated, ai: true },
            { id: "full", label: "Approve in full", detail: "Honor the claimed tier", value: a.claimed },
            { id: "half", label: "Meet halfway", detail: "Split the difference", value: Math.round((anchorValidated + a.claimed) / 2) },
            { id: "none", label: "Dispute all", detail: "Recover the full claim", value: 0 },
          ]}
          confirmLabel="Apply decision"
          onConfirm={(v) => {
            setClaimEdit(caseId, { approvedAmount: v });
            setEditOpen(false);
          }}
          onReset={() => {
            setClaimEdit(caseId, null);
            setEditOpen(false);
          }}
          onClose={() => setEditOpen(false)}
        />
      )}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <button
            type="button"
            onClick={onBack}
            className="mb-1 inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            All deductions
          </button>
          <h2 className="text-xl font-semibold">
            {c.caseId} — {c.customerName}
          </h2>
          <p className="text-sm text-muted-foreground">
            A growth rebate billed on gross sales at the wrong tier. The rebate
            formula is read from the signed agreement, eligibility and net sales
            rebuilt, and the tier re-derived; the decision and the letter are
            yours.
          </p>
        </div>
        {processing && !awaitingAdvance && (
          <span className="flex items-center gap-2 text-sm text-muted-foreground">
            <Spinner size="sm" />
            Investigation in progress
          </span>
        )}
      </div>

      <Card className="bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="flex flex-wrap items-center gap-2 text-sm font-semibold">
            <Badge variant="outline" className="whitespace-nowrap">
              {formatUsd(a.claimed)} withheld on {c.invoiceId}
            </Badge>
            <span className="text-xs font-normal text-muted-foreground">
              {doneCount}/{STAGES.length} steps cleared
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-2">
          <StageProgressRail
            stages={STAGES}
            statuses={statuses}
            openStageId={activeStage}
            onStageClick={(id) => {
              if (reached.includes(id)) openStage(id);
            }}
          />
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[minmax(0,1fr)_320px]">
        <div className="space-y-4">
          {STAGES.filter((s) => reached.includes(s.id)).map((stage) => (
            <Card
              key={stage.id}
              ref={(el) => {
                cardRefs.current[stage.id] = el;
              }}
              className={RUN_STAGE_CARD_CLASS}
            >
              <RunStageRow
                label={stage.heading}
                status={statuses[stage.id]}
                expanded={openStages.has(stage.id)}
                summary={stage.log}
                onToggle={() =>
                  setOpenStages((prev) => {
                    const next = new Set(prev);
                    next.has(stage.id) ? next.delete(stage.id) : next.add(stage.id);
                    return next;
                  })}
              />
              {openStages.has(stage.id) && (
                <CardContent className="space-y-4 border-t px-4 py-4 animate-in fade-in slide-in-from-top-2 duration-300">
                  {narration[stage.id] && stage.id !== "decision" && (
                    <AiStageNarration key={stage.id} text={narration[stage.id]} variant="inline" />
                  )}
                  {renderStage(stage.id)}
                </CardContent>
              )}
            </Card>
          ))}
        </div>

        <AgentAuditTrail
          entries={STAGES.filter((s) => statuses[s.id] !== "waiting").map((s) => ({
            id: s.id,
            agent: s.agent,
            agentType: s.agentType,
            message: s.log,
            tone:
              statuses[s.id] === "needsReview"
                ? ("attention" as const)
                : statuses[s.id] === "running"
                  ? ("info" as const)
                  : ("success" as const),
          }))}
        />
      </div>

      {statuses.impact === "passed" && !finaleDismissed && (
        <RunCompleteModal
          eyebrow="Growth rebate resolved"
          title={`${c.caseId} recalculated and validated`}
          narrative="The rebate was re-run on the signed agreement as amended: growth on net eligible sales, contracted entities and eligible SKUs only, at the amended 2% tier. The validated rebate is approved, the unsupported balance disputed, and the accrual trued up to the contract figure."
          stats={[
            { label: "claimed", value: formatUsd(a.claimed) },
            {
              label: "validated",
              value: formatUsd(a.validated),
              tone: "success",
            },
            {
              label: "unsupported",
              value: formatUsd(a.unsupported),
              tone: "danger",
            },
          ]}
          docs={[
            {
              doc: buildVarianceDoc(caseId),
              label: "Variance breakdown",
            },
            {
              doc: buildRebateLetterDoc(caseId, true),
              label: `Retailer response ${c.responseLetter.letterRef}`,
            },
          ]}
          primaryLabel="Back to deductions"
          onPrimary={() => {
            setFinaleDismissed(true);
            onBack();
          }}
          secondaryLabel="Stay on this case"
          onSecondary={() => setFinaleDismissed(true)}
        />
      )}
    </div>
  );
}

/* ---------------------------------------------------------------- */

/** The invoice as one bar: what arrived, and what was withheld. */
function PaymentSplitBar({
  assessment,
}: {
  assessment: NonNullable<ReturnType<typeof rebateClaimAssessment>>;
}) {
  const c = assessment.case;
  const paidPct = (c.amountPaid / c.invoiceAmount) * 100;
  const mounted = useMounted();
  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-3 flex items-baseline justify-between gap-3">
        <h4 className="text-sm font-semibold">Payment against invoice</h4>
        <span className="whitespace-nowrap text-xs text-muted-foreground">
          {c.remittanceId} · {c.receivedDate}
        </span>
      </div>
      <div className="flex h-12 w-full overflow-hidden rounded-lg border-2">
        <div
          className="flex items-center justify-center bg-[var(--success)]/25 transition-all duration-700 ease-out motion-reduce:transition-none"
          style={{ width: mounted ? `${paidPct}%` : "0%" }}
        >
          <span className="text-sm font-semibold text-green-800 tabular-nums">
            {formatUsd(c.amountPaid)} paid
          </span>
        </div>
        <div
          className="flex flex-1 items-center justify-center transition-all duration-500 ease-out motion-reduce:transition-none"
          style={{
            opacity: mounted ? 1 : 0,
            transitionDelay: "600ms",
            backgroundImage:
              "repeating-linear-gradient(45deg, rgba(220,38,38,0.20) 0 6px, transparent 6px 12px)",
          }}
        >
          <span className="whitespace-nowrap px-1 text-xs font-semibold text-red-700 tabular-nums">
            {formatUsd(assessment.claimed)}
          </span>
        </div>
      </div>
      <p className="mt-2 text-xs text-muted-foreground">
        Invoice {formatUsd(c.invoiceAmount)} less {formatUsd(assessment.claimed)}{" "}
        withheld equals {formatUsd(c.amountPaid)} paid.{" "}
        {assessment.reconciles ? "Reconciles." : "Does not reconcile."}
      </p>
      <p className="mt-3 rounded border-l-2 border-muted-foreground/40 bg-muted/30 px-3 py-2 text-xs italic text-muted-foreground">
        &ldquo;{c.customerNote}&rdquo; — remittance note
      </p>
    </div>
  );
}

/** Signature card: retailer position vs contract-validated position, side by side. */
function ComparisonCard({
  assessment,
  caseId,
}: {
  assessment: NonNullable<ReturnType<typeof rebateClaimAssessment>>;
  caseId: string;
}) {
  const c = assessment.case;
  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-3 flex items-baseline justify-between gap-3">
        <h4 className="text-sm font-semibold">Retailer position vs the contract</h4>
        <span className="inline-flex items-center gap-1.5 whitespace-nowrap text-xs text-muted-foreground">
          <SystemMark name={c.program.tpmSystem} />
          {c.program.tpmSystem} · {c.program.agreementRef}
        </span>
      </div>

      {/* Three columns: element | retailer | validated. */}
      <div className="overflow-hidden rounded-lg border">
        <div className="grid grid-cols-[1.1fr_1fr_1fr] bg-muted/50 text-xs font-semibold">
          <div className="px-3 py-2">Calculation element</div>
          <div className="border-l px-3 py-2 text-red-700">Retailer position</div>
          <div className="border-l px-3 py-2 text-[var(--success)]">
            Contract-validated
          </div>
        </div>
        {c.comparison.map((row, i) => (
          <div
            key={row.rowId}
            className={cn(
              "grid grid-cols-[1.1fr_1fr_1fr] text-xs",
              i % 2 === 1 && "bg-muted/20"
            )}
          >
            <div className="flex items-center justify-between gap-1.5 px-3 py-2 font-medium">
              <span>{row.element}</span>
              {row.drives && (
                <Badge
                  variant="outline"
                  className="hidden shrink-0 text-[10px] sm:inline-flex"
                >
                  {REBATE_VARIANCE_LABEL[row.drives]}
                </Badge>
              )}
            </div>
            <div className="border-l px-3 py-2 text-muted-foreground line-through decoration-red-300">
              {row.retailerPosition}
            </div>
            <div className="border-l px-3 py-2 font-medium text-foreground">
              {row.validatedPosition}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-3 rounded-lg border-2 border-amber-300 bg-amber-50/60 p-3">
        <p className="text-xs text-amber-900">
          <span className="font-semibold">Latest amendment: </span>
          {c.program.amendmentNote}
        </p>
      </div>

      <div className="mt-3 flex flex-wrap gap-2 border-t pt-3">
        <SourceDocTrigger
          doc={buildRebateDeductionDoc(caseId)}
          label="View the claim"
        />
        <SourceDocTrigger
          doc={buildAgreementDoc(caseId)}
          label="View the signed agreement"
        />
      </div>
    </div>
  );
}

/** Eligible vs out-of-scope sales, once by buying entity and once by product group. */
function EligibilityCard({
  assessment,
  caseId,
}: {
  assessment: NonNullable<ReturnType<typeof rebateClaimAssessment>>;
  caseId: string;
}) {
  const c = assessment.case;
  const [grown, setGrown] = useState(false);
  useEffect(() => {
    const id = setTimeout(() => setGrown(true), 150);
    return () => clearTimeout(id);
  }, []);

  type Item = {
    id: string;
    name: string;
    eligible: boolean;
    value: number;
    note: string;
    doc: ReturnType<typeof buildEntityDoc>;
  };

  const dimension = (title: string, items: Item[], delay: number) => {
    const total = items.reduce((a, i) => a + i.value, 0) || 1;
    const excluded = items.filter((i) => !i.eligible).reduce((a, i) => a + i.value, 0);
    let greenIdx = 0;
    let redIdx = 0;
    const fills = items.map((i) =>
      i.eligible
        ? ["bg-[var(--success)]", "bg-[var(--success)]/60", "bg-[var(--success)]/35"][greenIdx++ % 3]
        : ["bg-red-500", "bg-red-300"][redIdx++ % 2]
    );
    return (
      <div className="flex flex-col gap-2">
        <div className="flex items-baseline justify-between gap-3 text-xs">
          <span className="font-semibold text-muted-foreground">{title}</span>
          <span className="tabular-nums text-muted-foreground">
            <span className="font-medium text-red-700">−{formatUsd(excluded)}</span> excluded
          </span>
        </div>
        <div className="flex h-6 w-full gap-0.5 overflow-hidden rounded-md bg-muted">
          {items.map((i, idx) => (
            <div
              key={i.id}
              title={`${i.name} — ${formatUsd(i.value)}`}
              className={cn("h-full transition-all duration-700 ease-out", fills[idx])}
              style={{
                width: grown ? `${(i.value / total) * 100}%` : "0%",
                transitionDelay: `${delay + idx * 120}ms`,
              }}
            />
          ))}
        </div>
        <ul className="flex flex-col">
          {items.map((i, idx) => (
            <li key={i.id}>
              <SourceDocRowTrigger
                doc={i.doc}
                className="flex w-full items-center gap-2 rounded px-1 py-1.5 text-left text-sm hover:bg-muted/50"
              >
                <span className={cn("h-2.5 w-2.5 shrink-0 rounded-[2px]", fills[idx])} />
                <span className="min-w-0 flex-1 truncate" title={i.note}>
                  {i.name}
                </span>
                {!i.eligible && (
                  <span className="rounded bg-red-50 px-1.5 py-0.5 text-[10px] font-medium text-red-700">
                    Out of scope
                  </span>
                )}
                <span
                  className={cn(
                    "w-24 text-right tabular-nums",
                    i.eligible ? "font-medium" : "text-muted-foreground line-through"
                  )}
                >
                  {formatUsd(i.value)}
                </span>
              </SourceDocRowTrigger>
            </li>
          ))}
        </ul>
      </div>
    );
  };

  return (
    <div className="flex flex-col gap-4 rounded-xl border bg-card p-4">
      <div className="flex items-baseline justify-between gap-3">
        <h4 className="text-sm font-semibold">Eligible sales</h4>
        <span className="text-sm tabular-nums text-muted-foreground">
          <span className="font-semibold text-[var(--success)]">
            {formatUsd(assessment.netEligibleSales)}
          </span>{" "}
          net eligible
        </span>
      </div>

      {dimension(
        "By buying entity",
        c.entities.map((e) => ({
          id: e.entityId,
          name: e.name.replace(/ — .*/, ""),
          eligible: e.eligible,
          value: e.netEligibleSales,
          note: e.note,
          doc: buildEntityDoc(caseId, e.entityId),
        })),
        0
      )}
      <div className="border-t" />
      {dimension(
        "By product group",
        c.productGroups.map((p) => ({
          id: p.groupId,
          name: p.label.replace(/ \((eligible|excluded[^)]*)\)/, ""),
          eligible: p.eligible,
          value: p.netEligibleSales,
          note: p.note,
          doc: buildProductGroupDoc(caseId, p.groupId),
        })),
        500
      )}

      <div className="border-t pt-3">
        <SourceDocTrigger doc={buildBasisDoc(caseId)} label="View the sales build-up" />
      </div>
    </div>
  );
}

/** Net eligible build-up, growth, tier attainment and the four variance drivers. */
function RecalcCard({
  assessment,
  caseId,
}: {
  assessment: NonNullable<ReturnType<typeof rebateClaimAssessment>>;
  caseId: string;
}) {
  const c = assessment.case;
  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-3 flex items-baseline justify-between gap-3">
        <h4 className="text-sm font-semibold">Recalculation on the contract basis</h4>
        <span className="whitespace-nowrap text-xs text-muted-foreground">
          {pct1(assessment.netGrowthPct)} net growth
        </span>
      </div>

      {/* Gross → net eligible build-up. */}
      <div className="space-y-1.5">
        {c.basisBuildUp.map((l) => {
          const total = !l.isDeduction && l.lineId !== "BB-1";
          return (
            <div
              key={l.lineId}
              className={cn(
                "flex items-center justify-between gap-2 rounded px-2.5 py-1.5 text-xs",
                total
                  ? "border-2 border-primary/30 bg-primary/5 font-semibold"
                  : l.isDeduction
                    ? "text-muted-foreground"
                    : "font-medium"
              )}
            >
              <span>{l.label}</span>
              <span className="tabular-nums">
                {l.isDeduction ? "−" : ""}
                {formatUsd(l.amount)}
              </span>
            </div>
          );
        })}
      </div>

      {/* Tier attainment against the amended table. */}
      <div className="mt-3 rounded-lg border p-3">
        <p className="mb-2 text-xs font-semibold">Tier attained (amended table)</p>
        <div className="flex flex-wrap gap-2">
          {c.tierTable
            .filter((t) => t.minGrowthPct < 999)
            .map((t) => {
              const isAttained = t.tierId === assessment.attainedTier.tierId;
              return (
                <div
                  key={t.tierId}
                  className={cn(
                    "flex-1 rounded-lg border-2 p-2 text-center",
                    isAttained
                      ? "border-[var(--success)] bg-[var(--success)]/10"
                      : "border-muted bg-muted/20 opacity-70"
                  )}
                >
                  <p className="text-xs text-muted-foreground">{t.label}</p>
                  <p className="text-sm font-bold tabular-nums">{pct1(t.ratePct)}</p>
                  <p className="text-[10px] text-muted-foreground">
                    ≥ {pct1(t.minGrowthPct)}
                  </p>
                </div>
              );
            })}
          <div className="flex-1 rounded-lg border-2 border-red-200 bg-red-50 p-2 text-center opacity-70">
            <p className="text-xs text-muted-foreground">3% tier</p>
            <p className="text-sm font-bold tabular-nums text-red-700 line-through">
              3%
            </p>
            <p className="text-[10px] text-red-700">removed by A2</p>
          </div>
        </div>
        <p className="mt-2 text-xs text-muted-foreground">
          Net eligible growth of {pct1(assessment.netGrowthPct)} attains{" "}
          {assessment.attainedTier.label} at {pct1(assessment.attainedTier.ratePct)}
          , not the {pct1(assessment.claimedTierPct)} billed.
        </p>
      </div>

      {/* The four drivers that close the gap. */}
      <p className="mb-1.5 mt-3 text-xs font-semibold text-muted-foreground">
        What closes the {formatUsd(assessment.unsupported)} gap
      </p>
      <div className="space-y-2">
        {c.varianceDrivers.map((d) => (
          <div key={d.driverId} className="rounded-lg border p-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="flex items-center gap-2 text-sm font-medium">
                <Badge variant="outline" className="text-[10px]">
                  {REBATE_VARIANCE_LABEL[d.kind]}
                </Badge>
                {d.label}
              </span>
              <span className="text-sm font-bold tabular-nums text-red-700">
                −{formatUsd(d.amount)}
              </span>
            </div>
            <p className="mt-1 text-xs text-muted-foreground">{d.detail}</p>
          </div>
        ))}
      </div>

      <div className="mt-3 grid grid-cols-3 gap-2 border-t pt-3 text-center">
        <div>
          <p className="text-xs text-muted-foreground">Claimed</p>
          <p className="text-sm font-bold tabular-nums">
            {formatUsd(assessment.claimed)}
          </p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground">Validated</p>
          <p className="text-sm font-bold tabular-nums text-[var(--success)]">
            {formatUsd(assessment.validated)}
          </p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground">Unsupported</p>
          <p className="text-sm font-bold tabular-nums text-red-700">
            {formatUsd(assessment.unsupported)}
          </p>
        </div>
      </div>

      <div className="mt-3 flex flex-wrap gap-2 border-t pt-3">
        <SourceDocTrigger
          doc={buildVarianceDoc(caseId)}
          label="View the variance breakdown"
        />
        <SourceDocTrigger
          doc={buildAgreementDoc(caseId)}
          label="View the amended agreement"
        />
      </div>
    </div>
  );
}
