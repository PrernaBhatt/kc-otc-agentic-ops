"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  Banknote,
  Check,
  CircleCheck,
  Landmark,
  Mail,
  Scissors,
  Pencil,
  ThumbsUp,
  X,
} from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import { Spinner } from "@/components/agents/spinner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { SignedApproveButton } from "@/components/shared/signed-approve-button";
import { findAccount } from "@/lib/data/account-owners";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { formatUsd } from "@/lib/chargeback-selectors";
import { TODAY } from "@/lib/data/clock";
import {
  renderShortPayLetter,
  shortPayAccounting,
  shortPaySplit,
} from "@/lib/short-pay-selectors";
import {
  buildApprovedClaimDoc,
  buildCreditMemoDoc,
  buildShortPayLetterDoc,
  buildShortPayRemittanceDoc,
} from "@/lib/docs-chargebacks";
  import { useOtcStore } from "@/lib/store";
import { ClaimEditModal } from "@/components/modals/claim-edit-modal";
import { cn } from "@/lib/utils";

import {
  AiStageNarration,
  narrationDwellMs,
} from "@/components/mounts/chargebacks/ai-stage-narration";
import {
  AgentAuditTrail,
  RunStageRow,
  RUN_STAGE_BODY_CLASS,
  RUN_STAGE_CARD_CLASS,
} from "@/components/mounts/shared/run-stage-row";
import { StageProgressRail } from "@/components/mounts/shared/stage-progress-rail";
import { RunCompleteModal } from "@/components/mounts/shared/run-complete-modal";
import { GtnImpactPanel } from "@/components/mounts/deductions/gtn-impact-panel";
import { DisputeLetterComposer } from "@/components/mounts/deductions/dispute-letter-composer";
import { AgentDecision } from "@/components/mounts/deductions/agent-decision";

type SimStatus = "waiting" | "running" | "passed" | "needsReview";

/**
 * The second deduction case, in five steps.
 *
 * The first case traces a deduction to a claim we rejected and recovers all of
 * it. This one has to SEPARATE: part of the short pay is genuinely owed to the
 * distributor and part has already been credited. Accepting all of it concedes
 * money we do not owe; disputing all of it fights money we do.
 *
 * Five steps, one point each, because the case is only interesting if a
 * reviewer can follow the split without being walked through a ledger.
 */
const STAGES = [
  {
    id: "intake",
    label: "Short payment",
    heading: "Payment against invoice",
    agent: "Cash Matching Agent",
    agentType: "orchestrator",
    icon: Banknote,
    log: "Payment matched to the invoice. The remittance is short.",
  },
  {
    id: "split",
    label: "Reconciliation",
    heading: "Deduction reconciled against claims and credits",
    agent: "Deduction Matching Agent",
    agentType: "validation",
    icon: Scissors,
    log: "Deduction matched against claims and credits. Part of it is valid.",
  },
  {
    id: "decision",
    label: "Decision",
    heading: "Accept and recover",
    agent: "Recovery Agent",
    agentType: "credit",
    icon: Check,
    log: "Split prepared. Awaiting a decision.",
  },
  {
    id: "letter",
    label: "Dispute letter",
    heading: "Dispute correspondence",
    agent: "Correspondence Agent",
    agentType: "invoice",
    icon: Mail,
    log: "Letter drafted against the credit memo. Not yet issued.",
  },
  {
    id: "impact",
    label: "Impact",
    heading: "Gross-to-net and accounting impact",
    agent: "Revenue Accounting Agent",
    agentType: "invoice",
    icon: Landmark,
    log: "Only the valid part becomes a gross-to-net cost.",
  },
] as const;

const STAGE_DWELL_MS = 4000;

export function ShortPayRun({
  caseId,
  onBack,
}: {
  caseId: string;
  onBack: () => void;
}) {
  const { resolveShortPay, claimEdits, setClaimEdit } = useOtcStore();
  const edit = claimEdits[caseId];
  const split = shortPaySplit(caseId, edit);
  const accounting = shortPayAccounting(caseId, edit);
  const anchorAccept = shortPaySplit(caseId)?.acceptAmount ?? 0;

  const [statuses, setStatuses] = useState<Record<string, SimStatus>>(() =>
    Object.fromEntries(STAGES.map((s) => [s.id, "waiting" as SimStatus]))
  );
  const [openStages, setOpenStages] = useState<Set<string>>(new Set());
  const [activeStage, setActiveStage] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);
  const [awaitingAdvance, setAwaitingAdvance] = useState(false);
  const [decided, setDecided] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [letterSent, setLetterSent] = useState(false);
  const [sentOn, setSentOn] = useState<string | undefined>(undefined);
  const [finaleDismissed, setFinaleDismissed] = useState(false);

  const advanceRef = useRef<(() => void) | null>(null);
  const startedRef = useRef(false);
  const decidedRef = useRef(false);
  const letterRef = useRef(false);
  const cardRefs = useRef<Record<string, HTMLDivElement | null>>({});

  const narration: Record<string, string | string[]> = split
    ? {
        intake: `${split.case.customerName} paid ${formatUsd(split.amountPaid)} of a ${formatUsd(split.invoiceAmount)} invoice, withholding ${formatUsd(split.shortPay)}.`,
        split: [
          `${formatUsd(split.acceptAmount)} is a valid deduction against approved claim ${split.case.approvedClaim.claimId}.`,
          `${formatUsd(split.recoverAmount)} was already credited by ${split.case.creditMemo.creditMemoId} and is being taken twice.`,
        ],
        decision: `AI recommends to accept ${formatUsd(split.acceptAmount)} and recover ${formatUsd(split.recoverAmount)}.`,
        letter: `Dispute letter ${split.case.disputeLetter.letterRef} drafted, citing the credit memo. Approval required before it is sent.`,
        impact: `${formatUsd(split.acceptAmount)} is recognised as a gross-to-net cost. ${formatUsd(split.recoverAmount)} remains collectible.`,
      }
    : {};
  const narrationRef = useRef(narration);
  narrationRef.current = narration;

  const openStage = useCallback((id: string) => {
    setOpenStages(new Set([id]));
    setActiveStage(id);
  }, []);

  const asText = (n: string | string[] | undefined) =>
    Array.isArray(n) ? n.join("\n") : (n ?? "");

  const runFrom = useCallback(
    async (startId: string) => {
      setProcessing(true);
      const from = Math.max(0, STAGES.findIndex((s) => s.id === startId));
      for (const stage of STAGES.slice(from)) {
        if (stage.id === "decision" && !decidedRef.current) {
          setStatuses((p) => ({ ...p, decision: "needsReview" }));
          openStage("decision");
          setProcessing(false);
          return;
        }
        if (stage.id === "letter" && !letterRef.current) {
          setStatuses((p) => ({ ...p, letter: "needsReview" }));
          openStage("letter");
          setProcessing(false);
          return;
        }
        setStatuses((p) => ({ ...p, [stage.id]: "running" }));
        openStage(stage.id);

        let marked = false;
        const markPassed = () => {
          if (marked) return;
          marked = true;
          setStatuses((p) => ({ ...p, [stage.id]: "passed" }));
        };
        const dwell = setTimeout(
          markPassed,
          narrationDwellMs(asText(narrationRef.current[stage.id]), STAGE_DWELL_MS)
        );
        const advanced = new Promise<void>((r) => {
          advanceRef.current = r;
        });
        setAwaitingAdvance(true);
        await advanced;
        setAwaitingAdvance(false);
        clearTimeout(dwell);
        markPassed();
      }
      setProcessing(false);
      setActiveStage(null);
    },
    [openStage]
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Enter") return;
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      if (!advanceRef.current) return;
      e.preventDefault();
      const go = advanceRef.current;
      advanceRef.current = null;
      go();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    if (startedRef.current || !split) return;
    startedRef.current = true;
    void runFrom("intake");
  }, [runFrom, split]);

  useEffect(() => {
    if (!activeStage) return;
    const node = cardRefs.current[activeStage];
    node?.scrollIntoView({ behavior: "smooth", block: "center" });
  }, [activeStage]);

  useEffect(() => {
    if (!decided) return;
    setStatuses((p) => ({ ...p, decision: "passed" }));
    void runFrom("letter");
  }, [decided, runFrom]);

  useEffect(() => {
    if (!letterSent) return;
    setStatuses((p) => ({ ...p, letter: "passed" }));
    void runFrom("impact");
  }, [letterSent, runFrom]);

  // The queue reads this: a finished run has to leave a trace, or the card
  // still reads "cause not yet established" for a case that is closed.
  useEffect(() => {
    if (statuses.impact === "passed") resolveShortPay(caseId);
  }, [statuses.impact, resolveShortPay, caseId]);

  if (!split || !accounting) return null;

  const doneCount = STAGES.filter((s) => statuses[s.id] === "passed").length;
  const reached: string[] = STAGES.filter(
    (s) => statuses[s.id] !== "waiting"
  ).map((s) => s.id);

  const decisionReasoning = [
    `${formatUsd(split.shortPay)} short checked against claim ${split.case.approvedClaim.claimId} and credit memo ${split.case.creditMemo.creditMemoId}.`,
    `${formatUsd(split.acceptAmount)} is owed on the approved claim — accepting it is correct.`,
    `${formatUsd(split.recoverAmount)} was already credited — conceding it would pay twice.`,
    `Decision: accept ${formatUsd(split.acceptAmount)}, recover ${formatUsd(split.recoverAmount)}.`,
  ];
  const renderStage = (stageId: string) =>
    stageId === "decision" ? (
      <AgentDecision stepKey={`${caseId}:decision`} lines={decisionReasoning}>
        {renderBody(stageId)}
      </AgentDecision>
    ) : (
      renderBody(stageId)
    );

  const renderBody = (id: string) => {
    switch (id) {
      case "intake":
        return (
          <div className="space-y-3">
            <PaymentSplitBar split={split} />
            <SourceDocTrigger
              doc={buildShortPayRemittanceDoc(caseId)}
              label="View the remittance"
            />
          </div>
        );
      case "split":
        return (
          <div className="space-y-3">
            <ComponentTable split={split} caseId={caseId} />
          </div>
        );
      case "decision":
        return (
          <div className="space-y-3">
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="rounded-lg border-2 border-[var(--success)]/40 bg-[var(--success)]/5 p-3">
                <p className="text-xs text-muted-foreground">Accept</p>
                <p className="text-2xl font-bold text-[var(--success)]">
                  {formatUsd(split.acceptAmount)}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  Owed to the distributor on {split.case.approvedClaim.claimId}
                </p>
              </div>
              <div className="rounded-lg border-2 border-amber-300 bg-amber-50 p-3">
                <p className="text-xs text-muted-foreground">Recover</p>
                <p className="text-2xl font-bold text-amber-700">
                  {formatUsd(split.recoverAmount)}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  Already credited by {split.case.creditMemo.creditMemoId}
                </p>
              </div>
            </div>
            {decided ? (
              <p className="flex items-center gap-1.5 text-xs text-[var(--success)]">
                <ThumbsUp className="h-3.5 w-3.5" />
                Decided by you — accept {formatUsd(split.acceptAmount)}, recover{" "}
                {formatUsd(split.recoverAmount)}.
              </p>
            ) : (
              <div className="flex flex-wrap items-center gap-3 rounded-lg border-2 border-amber-200 bg-amber-50/60 px-3 py-2.5">
                <span className="text-xs text-amber-900">
                  Awaiting your decision. Nothing is recorded until you click.
                </span>
                <div className="flex flex-wrap items-center gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="whitespace-nowrap gap-1.5"
                    onClick={() => setEditOpen(true)}
                  >
                    <Pencil className="h-3.5 w-3.5" />
                    Edit
                  </Button>
                  <SignedApproveButton
                    gateId={`${caseId}:G1`}
                    title="Settle the short-pay"
                    caseId={split.case.caseId}
                    accountId={findAccount(split.case.customerName)?.accountId ?? ""}
                    module="Deductions"
                    system="SAP FSCM"
                    controls={["1.4.5", "1.4.4"]}
                    evidence={[
                      { id: "case", label: `Deduction ${split.case.caseId}`, system: "SAP FSCM" },
                      { id: "pod", label: "Delivery and invoice matched", system: "SAP S/4HANA" },
                    ]}
                    lines={[
                      { label: "Accepted", amountUsd: split.acceptAmount, kind: "credit" },
                      { label: "Recover", amountUsd: split.recoverAmount, kind: "charge-back" },
                    ]}
                    attestation={`I accept ${formatUsd(split.acceptAmount)} within tolerance and recover ${formatUsd(split.recoverAmount)} on ${split.case.caseId}.`}
                    action={`Accepted ${formatUsd(split.acceptAmount)}, recover ${formatUsd(split.recoverAmount)}`}
                    decision="Partially accepted"
                    onSigned={() => {
                      decidedRef.current = true;
                      setDecided(true);
                    }}
                  >
                    Accept {formatUsd(split.acceptAmount)} · recover{" "}
                    {formatUsd(split.recoverAmount)}
                  </SignedApproveButton>
                </div>
              </div>
            )}
          </div>
        );
      case "letter": {
        const letter = renderShortPayLetter(caseId, edit)!;
        const c = split.case;
        return (
          <DisputeLetterComposer
            letterKey={c.caseId}
            from={`${c.disputeLetter.from} <trade.finance@internal.example>`}
            to={`${c.disputeLetter.to} <ap@northbridgesupply.example>`}
            subject={letter.subject}
            body={letter.body}
            attachments={[
              {
                doc: buildShortPayRemittanceDoc(caseId),
                label: `Remittance ${c.remittanceId}`,
              },
              {
                doc: buildCreditMemoDoc(caseId),
                label: `Credit memo ${c.creditMemo.creditMemoId}`,
              },
              {
                doc: buildApprovedClaimDoc(caseId),
                label: `Approved claim ${c.approvedClaim.claimId}`,
              },
              {
                doc: buildShortPayLetterDoc(caseId, letterSent),
                label: "Letter as a document",
              },
            ]}
            sent={letterSent}
            sentDate={sentOn}
            sentNote={`Issued to ${c.customerName} accounts payable. Repayment of ${formatUsd(split.recoverAmount)} requested within 30 days.`}
            canSend={statuses.letter === "needsReview"}
            blockedNote="Take the decision first."
            onSend={() => {
              letterRef.current = true;
              setSentOn(TODAY);
              setLetterSent(true);
            }}
          />
        );
      }
      case "impact":
        return (
          <GtnImpactPanel
            shortPay={split.shortPay}
            gtnImpact={accounting.gtnImpact}
            recoveryRequired={accounting.recoveryRequired}
            basis={`${formatUsd(split.acceptAmount)} relates to approved claim ${split.case.approvedClaim.claimId} and draws on the reserve. ${formatUsd(split.recoverAmount)} was already credited by ${split.case.creditMemo.creditMemoId} and is not a cost at all.`}
            lines={accounting.lines}
            caseRef={split.case.caseId}
            claimRef={split.case.approvedClaim.claimId}
          />
        );
      default:
        return null;
    }
  };


  return (
    <div className="space-y-6">
      {editOpen && (
        <ClaimEditModal
          title="Edit short-pay decision"
          caseLabel={`${split.case.caseId} — ${split.case.customerName} · ${formatUsd(split.shortPay)} withheld`}
          total={split.shortPay}
          primaryValue={split.acceptAmount}
          anchorValue={anchorAccept}
          leftLabel="Accept as gross-to-net"
          rightLabel="Recover"
          leftHint="Recognised as a gross-to-net cost"
          rightHint="Collectible receivable to recover"
          leftTone="success"
          rightTone="amber"
          aiRationale={`AI accepts ${formatUsd(anchorAccept)} against the chargeback reserve and recovers the rest of the ${formatUsd(split.shortPay)} withheld. Adjust what you accept and the letter and postings follow.`}
          presets={[
            { id: "ai", label: "AI recommendation", detail: "Reserve-backed only", value: anchorAccept, ai: true },
            { id: "full", label: "Accept in full", detail: "Absorb the full short-pay", value: split.shortPay },
            { id: "half", label: "Meet halfway", detail: "Split the difference", value: Math.round((anchorAccept + split.shortPay) / 2) },
            { id: "none", label: "Recover all", detail: "Recover the full short-pay", value: 0 },
          ]}
          confirmLabel="Apply decision"
          onConfirm={(v) => {
            setClaimEdit(caseId, { approvedAmount: v });
            setEditOpen(false);
          }}
          onReset={() => {
            setClaimEdit(caseId, null);
            setEditOpen(false);
          }}
          onClose={() => setEditOpen(false)}
        />
      )}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <button
            type="button"
            onClick={onBack}
            className="mb-1 inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            All deductions
          </button>
          <h2 className="text-xl font-semibold">
            {split.case.caseId} — {split.case.customerName}
          </h2>
          <p className="text-sm text-muted-foreground">
            A short payment that is part valid and part already credited. The
            split is proposed; the decision and the letter are yours.
          </p>
        </div>
        {processing && !awaitingAdvance && (
          <span className="flex items-center gap-2 text-sm text-muted-foreground">
            <Spinner size="sm" />
            Investigation in progress
          </span>
        )}
      </div>

      <Card className="bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="flex flex-wrap items-center gap-2 text-sm font-semibold">
            <Badge variant="outline" className="whitespace-nowrap">
              {formatUsd(split.shortPay)} short on {split.case.invoiceId}
            </Badge>
            <span className="text-xs font-normal text-muted-foreground">
              {doneCount}/{STAGES.length} steps cleared
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-2">
          <StageProgressRail
            stages={STAGES}
            statuses={statuses}
            openStageId={activeStage}
            onStageClick={(id) => {
              if (reached.includes(id)) openStage(id);
            }}
          />
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[minmax(0,1fr)_320px]">
        <div className="space-y-4">
          {STAGES.filter((s) => reached.includes(s.id)).map((stage) => (
            <Card
              key={stage.id}
              ref={(el) => {
                cardRefs.current[stage.id] = el;
              }}
              className={RUN_STAGE_CARD_CLASS}
            >
              <RunStageRow
                label={stage.heading}
                status={statuses[stage.id]}
                expanded={openStages.has(stage.id)}
                summary={stage.log}
                onToggle={() =>
                  setOpenStages((prev) => {
                    const next = new Set(prev);
                    next.has(stage.id) ? next.delete(stage.id) : next.add(stage.id);
                    return next;
                  })}
              />
              {openStages.has(stage.id) && (
                <CardContent className="space-y-4 border-t px-4 py-4 animate-in fade-in slide-in-from-top-2 duration-300">
                  {narration[stage.id] && stage.id !== "decision" && (
                    <AiStageNarration key={stage.id} text={narration[stage.id]} variant="inline" />
                  )}
                  {renderStage(stage.id)}
                </CardContent>
              )}
            </Card>
          ))}
        </div>

        <AgentAuditTrail
          entries={STAGES.filter((s) => statuses[s.id] !== "waiting").map((s) => ({
            id: s.id,
            agent: s.agent,
            agentType: s.agentType,
            message: s.log,
            tone:
              statuses[s.id] === "needsReview"
                ? ("attention" as const)
                : statuses[s.id] === "running"
                  ? ("info" as const)
                  : ("success" as const),
          }))}
        />
      </div>

      {statuses.impact === "passed" && !finaleDismissed && (
        <RunCompleteModal
          eyebrow="Short pay resolved"
          title={`${split.case.caseId} split and answered`}
          narrative="The deduction was separated into the amount owed and the amount already credited. Only the valid portion is recognised as a gross-to-net cost; the remainder is collectible in full."
          stats={[
            { label: "short paid", value: formatUsd(split.shortPay) },
            {
              label: "accepted",
              value: formatUsd(split.acceptAmount),
              tone: "success",
            },
            {
              label: "to recover",
              value: formatUsd(split.recoverAmount),
              tone: "danger",
            },
          ]}
          docs={[
            {
              doc: buildCreditMemoDoc(caseId),
              label: `Credit memo ${split.case.creditMemo.creditMemoId}`,
            },
            {
              doc: buildShortPayLetterDoc(caseId, true),
              label: `Dispute letter ${split.case.disputeLetter.letterRef}`,
            },
          ]}
          primaryLabel="Back to deductions"
          onPrimary={() => {
            setFinaleDismissed(true);
            onBack();
          }}
          secondaryLabel="Stay on this case"
          onSecondary={() => setFinaleDismissed(true)}
        />
      )}
    </div>
  );
}

/* ---------------------------------------------------------------- */

/** The invoice as one bar: what arrived, and what did not. */
function PaymentSplitBar({ split }: { split: NonNullable<ReturnType<typeof shortPaySplit>> }) {
  const [grown, setGrown] = useState(false);
  useEffect(() => {
    const id = setTimeout(() => setGrown(true), 150);
    return () => clearTimeout(id);
  }, []);
  const paidPct = (split.amountPaid / split.invoiceAmount) * 100;
  return (
    <div className="flex flex-col gap-3 rounded-xl border bg-card p-4">
      <div className="flex items-baseline justify-between gap-3">
        <h4 className="text-sm font-semibold">
          {formatUsd(split.invoiceAmount)} invoice
        </h4>
        <span className="whitespace-nowrap text-xs text-muted-foreground">
          {split.case.remittanceId} · {split.case.receivedDate}
        </span>
      </div>
      <div className="flex h-10 w-full gap-0.5 overflow-hidden rounded-md bg-muted">
        <div
          className="flex h-full items-center whitespace-nowrap bg-[var(--success)] px-3 text-xs font-medium text-primary-foreground transition-all duration-700 ease-out"
          style={{ width: grown ? `${paidPct}%` : "0%" }}
        >
          {formatUsd(split.amountPaid)} paid
        </div>
        <div className="flex h-full flex-1 items-center justify-center whitespace-nowrap bg-amber-400 px-2 text-xs font-medium text-amber-950">
          {formatUsd(split.shortPay)}
        </div>
      </div>
      <p className="text-xs italic text-muted-foreground">
        &ldquo;{split.case.customerNote}&rdquo;
      </p>
    </div>
  );
}

/** The withheld amount, split into the halves that each document settles. */
function ComponentTable({
  split,
  caseId,
}: {
  split: NonNullable<ReturnType<typeof shortPaySplit>>;
  caseId: string;
}) {
  const [grown, setGrown] = useState(false);
  useEffect(() => {
    const id = setTimeout(() => setGrown(true), 150);
    return () => clearTimeout(id);
  }, []);
  const total = split.shortPay || 1;
  const fill = (valid: boolean) => (valid ? "bg-[var(--success)]" : "bg-amber-400");

  return (
    <div className="flex flex-col gap-4 rounded-xl border bg-card p-4">
      <h4 className="text-sm font-semibold">{formatUsd(split.shortPay)} withheld</h4>

      <div className="flex h-10 w-full gap-0.5 overflow-hidden rounded-md bg-muted">
        {split.case.components.map((c, i) => (
          <div
            key={c.componentId}
            title={c.finding}
            className={cn(
              "flex h-full items-center overflow-hidden whitespace-nowrap px-3 text-xs font-medium transition-all duration-700 ease-out",
              fill(c.valid),
              c.valid ? "text-primary-foreground" : "text-amber-950"
            )}
            style={{
              width: grown ? `${(c.amount / total) * 100}%` : "0%",
              transitionDelay: `${i * 250}ms`,
            }}
          >
            {formatUsd(c.amount)}
          </div>
        ))}
      </div>

      <ul className="flex flex-col">
        {split.case.components.map((c) => (
          <li
            key={c.componentId}
            title={c.finding}
            className="flex items-center gap-2 border-t py-2 text-sm first:border-t-0"
          >
            <span className={cn("h-2.5 w-2.5 shrink-0 rounded-[2px]", fill(c.valid))} />
            <span className="min-w-0 flex-1 truncate">{c.label}</span>
            <span
              className={cn(
                "text-xs font-medium",
                c.valid ? "text-[var(--success)]" : "text-amber-700"
              )}
            >
              {c.valid ? "Supported" : "Unsupported"}
            </span>
            <span className="w-24 text-right font-medium tabular-nums">
              {formatUsd(c.amount)}
            </span>
          </li>
        ))}
      </ul>

      <div className="flex flex-wrap gap-2 border-t pt-3">
        <SourceDocTrigger
          doc={buildApprovedClaimDoc(caseId)}
          label={`View claim ${split.case.approvedClaim.claimId}`}
        />
        <SourceDocTrigger
          doc={buildCreditMemoDoc(caseId)}
          label={`View credit memo ${split.case.creditMemo.creditMemoId}`}
        />
      </div>
    </div>
  );
}
