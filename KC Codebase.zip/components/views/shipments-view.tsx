"use client";

import { useEffect, useMemo, useState } from "react";
import { Search } from "lucide-react";

import { LoadList, shownStatus } from "@/components/mounts/shipments/load-list";
import { LoadRail } from "@/components/mounts/shipments/load-rail";
import { Input } from "@/components/ui/input";
import { AppointmentSlotRun } from "@/components/views/appointment-slot-run";
import { MilkRunRerouteRun } from "@/components/views/milk-run-reroute-run";
import { PremiumFreightRun } from "@/components/views/premium-freight-run";
import { NETWORK_LOADS, type NetworkLoad } from "@/lib/data/loads";
import { OM_AS_OF } from "@/lib/data/om-kpis";
import { RISK_ROWS, type ShipmentRunKind } from "@/lib/data/shipment-risk";
import { loadSummary } from "@/lib/shipment-selectors";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

type LoadFilter = "all" | "pre" | "transit" | "risk" | "delivered";

const FILTERS: { id: LoadFilter; label: string; count: number }[] = [
  { id: "all", label: "All", count: loadSummary.total },
  { id: "pre", label: "Pre-shipment", count: loadSummary.pre },
  { id: "transit", label: "In transit", count: loadSummary.transit },
  { id: "risk", label: "At risk", count: loadSummary.atRisk },
  { id: "delivered", label: "Delivered", count: loadSummary.delivered },
];

const MATCH: Record<LoadFilter, (l: NetworkLoad) => boolean> = {
  all: () => true,
  pre: (l) => l.stage <= 2,
  transit: (l) => l.stage === 3 || l.stage === 4,
  risk: (l) => !!l.caseId,
  delivered: (l) => l.stage === 5,
};

const runKind = (caseId: string | null): ShipmentRunKind | null =>
  RISK_ROWS.find((r) => r.caseId === caseId)?.run ?? null;

/** A watched (no-run) case opens Track & Trace on its load. */
const watchedLoadId = (caseId: string | null) =>
  caseId && !runKind(caseId) ? (NETWORK_LOADS.find((l) => l.caseId === caseId)?.loadId ?? null) : null;

/** At-risk loads first (high, then watch), then by stage, so the list reads like a control tower. */
const RANK = { "At risk": 0, Watch: 1, Recovered: 2, "On track": 3, "Delivered late": 4, Delivered: 5 } as const;

/** Track & Trace: every load the agents follow, a detail rail, and the run behind each at-risk load. */
export function ShipmentsView() {
  const { pendingCaseId, consumePendingCase, resolvedShipments } = useOtcStore();
  const [openCaseId, setOpenCaseId] = useState<string | null>(() => (runKind(pendingCaseId) ? pendingCaseId : null));
  const [filter, setFilter] = useState<LoadFilter>(() => (watchedLoadId(pendingCaseId) ? "risk" : "all"));
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(0);
  const [selectedId, setSelectedId] = useState<string | null>(
    () =>
      watchedLoadId(pendingCaseId) ??
      NETWORK_LOADS.find((l) => l.caseId === RISK_ROWS.find((r) => r.level === "high" && r.lane === "post")?.caseId)?.loadId ??
      null
  );

  useEffect(() => {
    if (!pendingCaseId) return;
    if (runKind(pendingCaseId)) {
      setOpenCaseId(pendingCaseId);
    } else {
      const loadId = watchedLoadId(pendingCaseId);
      if (!loadId) return;
      setSelectedId(loadId);
      setFilter("risk");
      setPage(0);
    }
    consumePendingCase();
  }, [pendingCaseId, consumePendingCase]);

  const loads = useMemo(() => {
    const q = search.trim().toLowerCase();
    return NETWORK_LOADS.filter(MATCH[filter])
      .filter((l) => !q || [l.loadId, l.customer, l.site, l.orderRef, l.caseId ?? ""].some((v) => v.toLowerCase().includes(q)))
      .sort((a, b) => RANK[shownStatus(a, resolvedShipments)] - RANK[shownStatus(b, resolvedShipments)] || b.stage - a.stage);
  }, [filter, search, resolvedShipments]);

  const back = () => setOpenCaseId(null);
  const kind = runKind(openCaseId);
  if (kind === "appointment") return <AppointmentSlotRun onBack={back} />;
  if (kind === "premium") return <PremiumFreightRun onBack={back} />;
  if (kind === "milkrun") return <MilkRunRerouteRun onBack={back} />;

  const selected = NETWORK_LOADS.find((l) => l.loadId === selectedId) ?? loads[0];

  return (
    <div className="flex flex-col gap-4 pb-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
          <h1 className="text-lg font-bold text-foreground">Track &amp; Trace</h1>
          <span className="text-xs text-muted-foreground">{OM_AS_OF.label}</span>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div role="group" aria-label="Filter loads" className="flex flex-wrap rounded-lg border bg-card p-0.5">
            {FILTERS.map((f) => (
              <button
                key={f.id}
                type="button"
                aria-pressed={filter === f.id}
                onClick={() => {
                  setFilter(f.id);
                  setPage(0);
                }}
                className={cn(
                  "flex items-center gap-1.5 rounded-md px-2.5 py-1 text-xs font-medium transition-colors",
                  filter === f.id ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
                )}
              >
                {f.label}
                <span className={cn("tabular-nums", filter === f.id ? "text-primary-foreground/80" : "text-muted-foreground/80")}>{f.count}</span>
              </button>
            ))}
          </div>
          <div className="relative">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" aria-hidden />
            <Input
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(0);
              }}
              placeholder="Load, customer, order"
              aria-label="Search loads"
              className="h-8 w-56 pl-8 text-xs"
            />
          </div>
        </div>
      </div>

      <div className="grid items-start gap-4 lg:grid-cols-[minmax(0,1fr)_380px]">
        <LoadList
          loads={loads}
          page={page}
          onPage={setPage}
          selectedId={selected?.loadId ?? null}
          onSelect={setSelectedId}
          resolved={resolvedShipments}
        />
        {selected && <LoadRail load={selected} resolved={resolvedShipments} onOpenRun={setOpenCaseId} />}
      </div>
    </div>
  );
}
