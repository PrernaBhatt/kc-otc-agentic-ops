"use client";

import { useEffect, useRef, useState } from "react";
import {
  Bot,
  CircleCheck,
  CircleX,
  Clock,
  Inbox,
  MessageSquare,
  Send,
  User,
} from "lucide-react";

import { FulfillmentFlow } from "@/components/flows/fulfillment-flow";
import { QueryHub } from "@/components/mounts/query-hub/query-hub";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

interface CopilotMessage {
  id: string;
  sender: "agent" | "human";
  content: string;
  timestamp: string;
  type?: "info" | "decision" | "action" | "question";
}

interface AuditEntry {
  id: string;
  action: string;
  agent: string;
  timestamp: string;
  status: "success" | "pending" | "failed";
  details: string;
}

const initialMessages: CopilotMessage[] = [
  {
    id: "msg-1",
    sender: "agent",
    content:
      "Hello! I've detected a Credit Hold situation for Order SO-710245 from Walmart Inc.. Let me walk you through the details.",
    timestamp: "2026-08-15T08:30:15Z",
    type: "info",
  },
  {
    id: "msg-2",
    sender: "agent",
    content:
      "Order Details:\n• Order ID: SO-710245\n• Customer: Walmart Inc. (CUST-001)\n• Total Value: $125,000\n• Current Credit Exposure: $485K / $500K limit\n• New exposure would be: $610K (exceeds by $110K)",
    timestamp: "2026-08-15T08:30:18Z",
    type: "info",
  },
  {
    id: "msg-3",
    sender: "agent",
    content:
      "I've analyzed the customer profile:\n• Credit Rating: BB (downgraded recently)\n• Relationship Tier: Gold\n• LTV Score: 0.82 (high value customer)\n• Churn Risk: 0.15 (low)\n• Payment History: 87% on-time",
    timestamp: "2026-08-15T08:30:22Z",
    type: "info",
  },
  {
    id: "msg-4",
    sender: "agent",
    content:
      "Based on AI analysis, I've generated three decision options:\n\n**Option A: Conditional Release (Recommended)**\n• Partial prepayment (20% = $25K)\n• Accelerated dunning protocol\n• Weekly credit monitoring\n• Risk Reduction: -15%\n• LTV Impact: +8%\n• Confidence: 87%\n\n**Option B: Split Shipment**\n• 50/50 split delivery\n• First shipment COD ($62.5K)\n• Balance on Net-15\n• Risk Reduction: -25%\n• LTV Impact: +2%\n• Confidence: 79%\n\n**Option C: Hard Hold**\n• Full prepayment required\n• Manual credit review\n• Escalate to Credit Manager\n• Risk Reduction: -35%\n• LTV Impact: -12% (may harm relationship)\n• Confidence: 92%",
    timestamp: "2026-08-15T08:30:25Z",
    type: "decision",
  },
  {
    id: "msg-5",
    sender: "agent",
    content:
      "What would you like to do? I recommend Option A (Conditional Release) as it balances risk mitigation with customer relationship preservation.",
    timestamp: "2026-08-15T08:30:28Z",
    type: "action",
  },
];

const initialAuditTrail: AuditEntry[] = [
  {
    id: "audit-1",
    action: "PO Validation Started",
    agent: "PO Validation Agent",
    timestamp: "2026-08-15T08:30:10Z",
    status: "success",
    details: "Customer ID validated, Item SKUs verified",
  },
  {
    id: "audit-2",
    action: "Pricing Validation",
    agent: "Pricing Agent",
    timestamp: "2026-08-15T08:30:12Z",
    status: "success",
    details: "Contract pricing applied, Volume discounts calculated",
  },
  {
    id: "audit-3",
    action: "Credit Check Triggered",
    agent: "Credit Risk Agent",
    timestamp: "2026-08-15T08:30:15Z",
    status: "success",
    details: "Credit exposure exceeds limit by $110K",
  },
  {
    id: "audit-4",
    action: "LTV Analysis Completed",
    agent: "Customer LTV Agent",
    timestamp: "2026-08-15T08:30:20Z",
    status: "success",
    details: "High-value customer identified (LTV: 0.82)",
  },
  {
    id: "audit-5",
    action: "Decision Options Generated",
    agent: "OTC Orchestrator",
    timestamp: "2026-08-15T08:30:25Z",
    status: "success",
    details: "Generated 3 decision options (Golden Trio)",
  },
  {
    id: "audit-6",
    action: "Awaiting Human Decision",
    agent: "OTC Orchestrator",
    timestamp: "2026-08-15T08:30:28Z",
    status: "pending",
    details: "Human-in-the-loop approval required",
  },
];

export function CopilotView() {
  const { runReturnStage } = useOtcStore();
  // Land on the Query Hub during a guided run so the run row is in view.
  const [activeTab, setActiveTab] = useState<"copilot" | "query-hub">(
    runReturnStage === "service_hub" ? "query-hub" : "copilot"
  );
  const [messages, setMessages] = useState<CopilotMessage[]>(initialMessages);
  const [auditTrail, setAuditTrail] = useState<AuditEntry[]>(initialAuditTrail);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [showFulfillment, setShowFulfillment] = useState(false);
  const chatScrollRef = useRef<HTMLDivElement>(null);
  const auditScrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [messages]);

  useEffect(() => {
    if (auditScrollRef.current) {
      auditScrollRef.current.scrollTop = auditScrollRef.current.scrollHeight;
    }
  }, [auditTrail]);

  const handleSend = () => {
    if (!input.trim()) return;

    const humanMessage: CopilotMessage = {
      id: `msg-human-${Date.now()}`,
      sender: "human",
      content: input,
      timestamp: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, humanMessage]);

    const lowerInput = input.toLowerCase();
    setInput("");

    const humanAuditEntry: AuditEntry = {
      id: `audit-msg-${Date.now()}`,
      action: "Human Question/Input",
      agent: "Credit Manager (Human)",
      timestamp: new Date().toISOString(),
      status: "success",
      details: input.substring(0, 50) + (input.length > 50 ? "..." : ""),
    };
    setAuditTrail((prev) => [...prev, humanAuditEntry]);

    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);

      let agentResponse: CopilotMessage;
      if (lowerInput.includes("payment") || lowerInput.includes("history")) {
        agentResponse = {
          id: `msg-agent-${Date.now()}`,
          sender: "agent",
          content:
            "Here's Walmart Inc. payment history for the last 12 months:\n\n• Total invoices: 24\n• On-time payments: 21 (87.5%)\n• Average days late: 3.2 days\n• Largest invoice paid: $89,500 (paid early)\n• Recent trend: Payments slowing (last 60 days)\n• Average payment cycle: 32 days vs 30-day terms\n\nThe recent slowdown correlates with their credit rating downgrade. Should I factor this into the recommendation?",
          timestamp: new Date().toISOString(),
          type: "info",
        };
      } else if (lowerInput.includes("risk") || lowerInput.includes("exposure")) {
        agentResponse = {
          id: `msg-agent-${Date.now()}`,
          sender: "agent",
          content:
            "Current risk analysis:\n\n**Credit Exposure**\n• Current: $485K / $500K (97%)\n• New order: $125K\n• Projected: $610K (122% over limit)\n\n**Risk Factors**\n• Credit rating: BB (downgraded from BBB)\n• Industry sector: Manufacturing (moderate risk)\n• Market volatility: 12% increase\n• Default probability: 8.5%\n\n**Mitigation Options**\n• Conditional release reduces exposure risk by 15%\n• Prepayment creates immediate $25K cash inflow\n• Weekly monitoring enables early intervention\n\nWould you like me to run a stress test scenario?",
          timestamp: new Date().toISOString(),
          type: "info",
        };
      } else if (
        lowerInput.includes("customer") ||
        lowerInput.includes("relationship")
      ) {
        agentResponse = {
          id: `msg-agent-${Date.now()}`,
          sender: "agent",
          content:
            "Walmart Inc. relationship profile:\n\n**Customer Value**\n• Lifetime Value (LTV): 0.82 (Gold tier)\n• Annual revenue: ~$1.2M\n• Customer since: 2019 (6 years)\n• Growth rate: +18% YoY\n• Churn risk: 15% (low)\n\n**Relationship Health**\n• Contact frequency: Weekly\n• Service tickets: 2 (both resolved)\n• NPS score: 8.5/10\n• Key contact: John Martinez (Procurement Director)\n\n**Strategic Importance**\n• Part of major regional expansion\n• Referenced us to 3 new customers\n• Potential for 2x volume next quarter\n\nHard hold could damage this valuable relationship. Option A preserves the partnership while managing risk.",
          timestamp: new Date().toISOString(),
          type: "info",
        };
      } else if (lowerInput.includes("why") || lowerInput.includes("recommend")) {
        agentResponse = {
          id: `msg-agent-${Date.now()}`,
          sender: "agent",
          content:
            "I recommend Option A (Conditional Release) because:\n\n1. **Risk Mitigation**: 20% prepayment ($25K) reduces exposure immediately\n2. **Relationship Preservation**: Avoids hard rejection that could trigger churn\n3. **LTV Protection**: High-value customer (0.82 LTV score) worth preserving\n4. **Data-Driven**: 87% confidence based on 1,200+ similar cases\n5. **Balanced Approach**: Accelerated dunning provides ongoing monitoring\n6. **Revenue Protection**: Allows order to proceed, maintaining $125K revenue\n\nOption C (Hard Hold) is safer but risks:\n• 12% negative LTV impact\n• Potential customer churn\n• Lost revenue opportunity\n• Damage to 6-year relationship\n\nOption B (Split Shipment) is viable but operationally more complex. Does this clarify my reasoning?",
          timestamp: new Date().toISOString(),
          type: "info",
        };
      } else if (
        lowerInput.includes("approve") ||
        lowerInput.includes("yes") ||
        lowerInput.includes("proceed")
      ) {
        agentResponse = {
          id: `msg-agent-${Date.now()}`,
          sender: "agent",
          content:
            "Great! Please click one of the 'Approve Option' buttons above to proceed, or let me know if you'd like to modify any terms first.",
          timestamp: new Date().toISOString(),
          type: "action",
        };
      } else {
        agentResponse = {
          id: `msg-agent-${Date.now()}`,
          sender: "agent",
          content:
            "I understand your question. Let me provide more context:\n\nI have access to:\n• Complete customer history and analytics\n• Real-time credit exposure data\n• Industry benchmarks and trends\n• Similar case outcomes and patterns\n• Policy rules and guardrails\n\nWhat specific aspect would you like me to elaborate on?",
          timestamp: new Date().toISOString(),
          type: "question",
        };
      }
      setMessages((prev) => [...prev, agentResponse]);

      const responseAuditEntry: AuditEntry = {
        id: `audit-response-${Date.now()}`,
        action: "AI Response Generated",
        agent: "OTC Orchestrator",
        timestamp: new Date().toISOString(),
        status: "success",
        details: "Contextual response provided",
      };
      setAuditTrail((prev) => [...prev, responseAuditEntry]);
    }, 1500);
  };

  if (showFulfillment) {
    // Original slice passed orderData: { orderId: "SO-710245", customerName: "Walmart Inc.", totalValue: 125000 };
    // Phase-1 contract signature takes orderId/onBack/onComplete.
    return (
      <FulfillmentFlow
        orderId="SO-710245"
        onBack={() => setShowFulfillment(false)}
        onComplete={() => setShowFulfillment(false)}
      />
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <Button
          variant={activeTab === "copilot" ? "default" : "outline"}
          className="whitespace-nowrap"
          onClick={() => setActiveTab("copilot")}
        >
          <MessageSquare className="h-4 w-4 mr-2" />
          Case Co-Pilot
        </Button>
        <Button
          variant={activeTab === "query-hub" ? "default" : "outline"}
          className="whitespace-nowrap"
          onClick={() => setActiveTab("query-hub")}
        >
          <Inbox className="h-4 w-4 mr-2" />
          Query Hub
        </Button>
      </div>
      {activeTab === "query-hub" ? (
        <QueryHub />
      ) : (
        <div className="grid lg:grid-cols-3 gap-4 h-screen">
      <Card className="lg:col-span-2 flex flex-col overflow-hidden h-full">
        <div
          ref={chatScrollRef}
          className="flex-1 overflow-y-auto p-4 space-y-4 bg-background min-h-0"
        >
          {messages.map((message) => (
            <div
              key={message.id}
              className={cn(
                "flex gap-3",
                message.sender === "human" && "flex-row-reverse"
              )}
            >
              <div
                className={cn(
                  "w-8 h-8 rounded-full flex items-center justify-center shrink-0",
                  message.sender === "agent" ? "bg-primary/10" : "bg-accent"
                )}
              >
                {message.sender === "agent" ? (
                  <Bot className="h-4 w-4 text-primary" />
                ) : (
                  <User className="h-4 w-4 text-foreground" />
                )}
              </div>
              <div
                className={cn(
                  "flex-1 space-y-1 max-w-[85%]",
                  message.sender === "human" && "flex flex-col items-end"
                )}
              >
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">
                    {message.sender === "agent" ? "AI Agent" : "You"}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {new Date(message.timestamp).toLocaleTimeString()}
                  </span>
                </div>
                <div
                  className={cn(
                    "rounded-lg p-3 whitespace-pre-wrap text-sm",
                    message.sender === "agent"
                      ? "bg-muted/50 text-foreground"
                      : "bg-primary text-primary-foreground",
                    message.type === "decision" && "border-2 border-primary/20"
                  )}
                >
                  {message.content}
                </div>
              </div>
            </div>
          ))}
          {isTyping && (
            <div className="flex gap-3">
              <div className="w-8 h-8 rounded-full flex items-center justify-center bg-primary/10 shrink-0">
                <Bot className="h-4 w-4 text-primary" />
              </div>
              <div className="bg-muted/50 rounded-lg p-3 flex gap-1">
                <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" />
                <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce [animation-delay:0.2s]" />
                <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce [animation-delay:0.4s]" />
              </div>
            </div>
          )}
        </div>
        <div className="border-t bg-muted/20 p-4 shrink-0">
          <div className="flex gap-2">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.nativeEvent.isComposing || e.keyCode === 229) return;
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder="Ask the AI agent a question..."
              className="min-h-[60px] resize-none"
            />
            <Button
              onClick={handleSend}
              disabled={!input.trim()}
              className="shrink-0"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </Card>
      <Card className="flex flex-col overflow-hidden h-full">
        <div
          ref={auditScrollRef}
          className="flex-1 overflow-y-auto p-4 space-y-3 bg-background min-h-0"
        >
          {auditTrail.map((entry) => (
            <div key={entry.id} className="border-l-2 border-primary/20 pl-3 pb-3">
              <div className="flex items-start justify-between gap-2 mb-1">
                <div className="flex items-center gap-2">
                  {entry.status === "success" && (
                    <CircleCheck className="h-4 w-4 text-green-600 shrink-0" />
                  )}
                  {entry.status === "pending" && (
                    <Clock className="h-4 w-4 text-yellow-600 shrink-0" />
                  )}
                  {entry.status === "failed" && (
                    <CircleX className="h-4 w-4 text-red-600 shrink-0" />
                  )}
                  <span className="text-sm font-medium">{entry.action}</span>
                </div>
              </div>
              <div className="text-xs text-muted-foreground">{entry.agent}</div>
              <div className="text-xs text-muted-foreground mt-1">
                {entry.details}
              </div>
              <div className="text-xs text-muted-foreground/60 mt-1">
                {new Date(entry.timestamp).toLocaleTimeString()}
              </div>
            </div>
          ))}
        </div>
      </Card>
        </div>
      )}
    </div>
  );
}
