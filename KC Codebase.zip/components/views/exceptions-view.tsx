"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowRight, CircleCheck, Clock, Play, User } from "lucide-react";
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { OwnerChip } from "@/components/shared/owner-chip";
import { AgentIcon } from "@/components/agents/agent-icon";
import { Spinner } from "@/components/agents/spinner";
import { AnimatedProgress } from "@/components/agents/animated-progress";
import { DeductionCasesSection } from "@/components/mounts/exceptions/deduction-cases";
import {
  QualityHoldDetailAction,
  QualityHoldTypeCard,
  useQualityHoldRecord,
} from "@/components/mounts/exceptions/quality-hold-exception";
import { qualityHoldException } from "@/lib/data/regulatory";
import type { ExceptionRecord } from "@/lib/data";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

function severityBadgeClass(severity: string) {
  switch (severity) {
    case "High":
      return "bg-destructive text-white";
    case "Medium":
      return "bg-[var(--warning)] text-[var(--warning-foreground)]";
    case "Low":
      return "bg-[var(--info)] text-white";
    default:
      return "bg-muted text-muted-foreground";
  }
}

function statusBadgeClass(status: string) {
  switch (status) {
    case "Open":
      return "bg-primary/10 text-primary border-primary/20";
    case "In Progress":
      return "bg-[var(--warning)]/10 text-[var(--warning)] border-[var(--warning)]/20";
    case "Resolved":
      return "bg-[var(--success)]/10 text-[var(--success)] border-[var(--success)]/20";
    default:
      return "bg-muted text-muted-foreground";
  }
}

function getAiRecommendation(exception: ExceptionRecord) {
  switch (exception.type) {
    case "Credit Hold":
      return `Based on ${exception.customerName}'s payment history (92% on-time) and current exposure ratio of 97%, recommend conditional release with 20% prepayment and accelerated dunning schedule.`;
    case "Delivery Delay":
      return "Pallets are waiting on LTL consolidation. Recommend releasing them to a dedicated flatbed carrier with a two-day transit commitment. Customer notification template ready for approval.";
    case "Pricing Mismatch":
      return "Project price variance of 8% detected. Historical analysis shows this distributor was quoted a project price in Q3 that has since lapsed. Recommend honouring the current contract rate and flagging the agreement for renewal review.";
    case "Document Missing":
      return "POD not received within SLA. Carrier API shows delivery confirmed. Recommend auto-generating POD from GPS/signature data and triggering billing release.";
    case "ATP Failure":
      return "Inventory shortfall of 150 units. Safety stock available at alternate DC. Recommend inter-warehouse transfer with 3-day lead time to fulfill order.";
    case "Quality Hold":
      return "The incontinence briefs line is allocated to lot LOT-88412, which is under quality hold. Cleared lot LOT-88907 can cover all 250 units with no change to the delivery date. Recommend substituting the cleared lot and releasing — the decision is made in Review Order Hold.";
    default:
      return "AI analysis in progress. Gathering additional context from related systems.";
  }
}

export function ExceptionsView({
  onResolveWithAI,
  completedOrderIds = [],
}: {
  onResolveWithAI: (orderId: string) => void;
  completedOrderIds: string[];
}) {
  // Exceptions come from the store so resolutions made on other pages
  // (e.g. approving a credit hold in Review Order Hold) show up here live.
  const { exceptions, resolveException } = useOtcStore();
  const [selectedException, setSelectedException] =
    useState<ExceptionRecord | null>(null);
  const [aiProgress, setAiProgress] = useState<Record<string, number>>({});
  const [aiResolvedIds, setAiResolvedIds] = useState<string[]>([]);
  const detailRef = useRef<HTMLDivElement>(null);
  const selectException = (exception: ExceptionRecord) => {
    setSelectedException(exception);
    // Below lg the detail panel stacks under the list, so bring it into view.
    if (window.matchMedia("(max-width: 1023px)").matches) {
      requestAnimationFrame(() =>
        detailRef.current?.scrollIntoView({ behavior: "smooth", block: "start" })
      );
    }
  };
  useEffect(() => {
    const interval = setInterval(() => {
      setAiProgress((prev) => {
        const next = { ...prev };
        Object.keys(next).forEach((key) => {
          if (next[key] < 100) {
            next[key] = Math.min(next[key] + 20 * Math.random(), 100);
            if (next[key] >= 100) {
              setAiResolvedIds((ids) => [...ids, key]);
              // Flip the shared record too so every other page co-moves.
              resolveException(key);
            }
          }
        });
        return next;
      });
    }, 400);
    return () => clearInterval(interval);
  }, [resolveException]);
  const getAgentType = (type: string) => {
    switch (type) {
      case "Credit Hold":
        return "credit";
      case "Delivery Delay":
        return "atp";
      case "Pricing Mismatch":
        return "pricing";
      case "Document Missing":
        return "document";
      default:
        return "validation";
    }
  };
  // Quality Hold mount: live record co-moves with the Review Order Hold store.
  const qualityHoldRecord = useQualityHoldRecord();
  const allExceptions = [...exceptions, qualityHoldRecord];
  // Derive-only resolved state: the store record, this page's AI runs, and
  // the parent workflow's completions all count — no effects needed.
  const isDisplayResolved = (exception: ExceptionRecord) =>
    exception.status === "Resolved" ||
    aiResolvedIds.includes(exception.id) ||
    completedOrderIds.includes(exception.orderId);
  const openExceptions = allExceptions.filter(
    (exception) =>
      exception.status === "Open" && !isDisplayResolved(exception)
  );
  const inProgressExceptions = allExceptions.filter(
    (exception) =>
      !isDisplayResolved(exception) &&
      (exception.status === "In Progress" ||
        aiProgress[exception.id] !== undefined)
  );
  // The details panel reads the live store record for its selection so a
  // resolution made elsewhere flips its action area automatically.
  const selectedLive = selectedException
    ? allExceptions.find(
        (exception) => exception.id === selectedException.id
      ) ?? selectedException
    : null;
  const selectedResolved = selectedLive ? isDisplayResolved(selectedLive) : false;
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-foreground">Exceptions</h2>
        </div>
        <div className="flex gap-2">
          <Badge
            variant="outline"
            className="text-primary border-primary gap-1"
          >
            <AgentIcon type="validation" size="sm" />
            {openExceptions.length} Open
          </Badge>
          <Badge
            variant="outline"
            className="text-[var(--warning)] border-[var(--warning)] gap-1"
          >
            <Spinner size="sm" />
            {inProgressExceptions.length} In Progress
          </Badge>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 xl:grid-cols-5">
        {["Credit Hold", "Delivery Delay", "Pricing Mismatch", "Document Missing"].map(
          (type) => {
            const count = exceptions.filter(
              (exception) =>
                exception.type === type && !isDisplayResolved(exception)
            ).length;
            const agentType = getAgentType(type);
            return (
              <Card key={type} className="bg-card">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div
                      className={cn(
                        "p-2 rounded-lg",
                        count > 0 ? "bg-primary/10" : "bg-muted"
                      )}
                    >
                      <AgentIcon
                        type={agentType}
                        size="sm"
                        className={
                          count > 0 ? "text-primary" : "text-muted-foreground"
                        }
                      />
                    </div>
                    <div>
                      <div className="text-2xl font-bold">{count}</div>
                      <div className="text-xs text-muted-foreground">{type}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          }
        )}
        <QualityHoldTypeCard />
      </div>
      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          {allExceptions.map((exception) => {
            const agentType = getAgentType(exception.type);
            const isProcessing =
              aiProgress[exception.id] !== undefined &&
              aiProgress[exception.id] < 100;
            const isResolved = isDisplayResolved(exception);
            const progress = aiProgress[exception.id] || 0;
            return (
              <Card
                key={exception.id}
                className={cn(
                  "cursor-pointer transition-all hover:shadow-md",
                  selectedException?.id === exception.id && "ring-2 ring-primary",
                  isProcessing && "bg-[var(--info)]/5",
                  isResolved && "bg-[var(--success)]/5 opacity-75"
                )}
                role="button"
                tabIndex={0}
                aria-pressed={selectedException?.id === exception.id}
                onClick={() => selectException(exception)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault();
                    selectException(exception);
                  }
                }}
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <div
                      className={cn(
                        "flex h-10 w-10 items-center justify-center rounded-lg",
                        isResolved
                          ? "bg-[var(--success)]/10 text-[var(--success)]"
                          : exception.severity === "High"
                            ? "bg-primary/10 text-primary"
                            : exception.severity === "Medium"
                              ? "bg-[var(--warning)]/10 text-[var(--warning)]"
                              : "bg-[var(--info)]/10 text-[var(--info)]"
                      )}
                    >
                      {isProcessing ? (
                        <Spinner size="sm" />
                      ) : isResolved ? (
                        <CircleCheck className="h-5 w-5" />
                      ) : (
                        <AgentIcon type={agentType} size="sm" />
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-semibold text-foreground">
                          {exception.type}
                        </span>
                        {!isResolved && (
                          <Badge
                            className={severityBadgeClass(exception.severity)}
                          >
                            {exception.severity}
                          </Badge>
                        )}
                        <Badge
                          variant="outline"
                          className={
                            isResolved
                              ? "bg-[var(--success)]/10 text-[var(--success)]"
                              : statusBadgeClass(exception.status)
                          }
                        >
                          {isResolved ? "Resolved" : exception.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">
                        {exception.description}
                      </p>
                      {isProcessing && (
                        <div className="mb-2">
                          <AnimatedProgress
                            progress={progress}
                            label="AI Agent Processing..."
                            color="info"
                          />
                        </div>
                      )}
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span className="font-mono">{exception.orderId}</span>
                        <span>{exception.customerName}</span>
                        <OwnerChip account={exception.customerName} variant="compact" />
                        <span className="flex items-center gap-1">
                          <User className="h-3 w-3" />
                          {exception.assignedTo}
                        </span>
                      </div>
                    </div>
                    <ArrowRight className="h-5 w-5 text-muted-foreground" />
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
        <div ref={detailRef} className="scroll-mt-24">
          {selectedException ? (
            <Card className="sticky top-24">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <AgentIcon
                    type={getAgentType(selectedException.type)}
                    size="sm"
                    className="text-primary"
                  />
                  Exception Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="text-sm text-muted-foreground">Type</div>
                  <div className="font-medium text-foreground">
                    {selectedException.type}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Order</div>
                  <div className="font-mono text-foreground">
                    {selectedException.orderId}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Customer</div>
                  <div className="text-foreground">
                    {selectedException.customerName}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Description</div>
                  <div className="text-sm text-foreground">
                    {selectedException.description}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Assigned To</div>
                  <div className="flex items-center gap-2">
                    <div className="h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center">
                      <User className="h-3 w-3 text-primary" />
                    </div>
                    <span className="text-foreground">
                      {selectedException.assignedTo}
                    </span>
                  </div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Created</div>
                  <div className="flex items-center gap-1 text-foreground">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    {new Date(selectedException.createdAt).toLocaleString()}
                  </div>
                </div>
                <div className="p-3 bg-muted/50 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <AgentIcon
                      type="orchestrator"
                      size="sm"
                      className="text-primary"
                    />
                    <span className="text-sm font-medium">AI Recommendation</span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {getAiRecommendation(selectedException)}
                  </p>
                </div>
                <div className="pt-4 space-y-2">
                  {selectedException.id === qualityHoldException.id ? (
                    <QualityHoldDetailAction
                      onDecide={() =>
                        onResolveWithAI(selectedException.orderId)
                      }
                    />
                  ) : selectedResolved ? (
                    <div className="w-full flex items-center justify-center gap-2 py-2 rounded-md bg-[var(--success)]/10 text-[var(--success)] text-sm font-medium">
                      <CircleCheck className="h-4 w-4" />
                      Processed & Complete
                    </div>
                  ) : selectedException.orderId === "SO-710245" ? (
                    <Button
                      className="w-full"
                      onClick={() => onResolveWithAI(selectedException.orderId)}
                    >
                      <Play className="h-4 w-4 mr-2" />
                      Resolve with AI
                    </Button>
                  ) : (
                    <Button
                      className="w-full"
                      onClick={() => {
                        const exceptionId = selectedException.id;
                        setAiProgress((prev) => ({
                          ...prev,
                          [exceptionId]: 0,
                        }));
                      }}
                      disabled={aiProgress[selectedException.id] !== undefined}
                    >
                      {aiProgress[selectedException.id] !== undefined &&
                      aiProgress[selectedException.id] < 100 ? (
                        <>
                          <Spinner size="sm" className="mr-2" />
                          AI Processing...
                        </>
                      ) : (
                        <>
                          <Play className="h-4 w-4 mr-2" />
                          Resolve with AI
                        </>
                      )}
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card className="sticky top-24">
              <CardContent className="p-8 text-center text-muted-foreground">
                <AgentIcon
                  type="validation"
                  size="lg"
                  className="mx-auto mb-4 opacity-50"
                />
                <p>Select an exception to view details</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
      <DeductionCasesSection />
    </div>
  );
}
