"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { GitBranch, Mail, PenLine, Radar, Waypoints } from "lucide-react";

import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { AiStageNarration } from "@/components/mounts/chargebacks/ai-stage-narration";
import { RunAgentLog } from "@/components/mounts/shared/run-agent-log";
import { RunCompleteModal } from "@/components/mounts/shared/run-complete-modal";
import { RunStageCard, type RunStageMeta } from "@/components/mounts/shared/run-stage-card";
import { StageProgressRail } from "@/components/mounts/shared/stage-progress-rail";
import { useFollowLatest } from "@/components/mounts/shared/use-follow-latest";
import { useStagedRun } from "@/components/mounts/shared/use-staged-run";
import { FourKitesFeed } from "@/components/mounts/shipments/fourkites-feed";
import { RouteOptions, StopTimeline, lateLabel, routeLabel } from "@/components/mounts/shipments/route-options";
import { ShipmentRunHeader } from "@/components/mounts/shipments/run-header";
import { CheckChip } from "@/components/shared/check-chip";
import { ControlTags } from "@/components/shared/control-tag";
import { EmailDraftDialog } from "@/components/shared/email-draft-dialog";
import { GateSignoffModal } from "@/components/shared/gate-signoff-modal";
import { StagedChangeTable } from "@/components/shared/staged-change-table";
import { Button } from "@/components/ui/button";
import { TRANSPORT_LEAD, findAccount } from "@/lib/data/account-owners";
import { TMS_SYSTEM } from "@/lib/data/order-logistics";
import { MILK_RUN_CASE, RISK_ROWS, type RouteOption } from "@/lib/data/shipment-risk";
import { buildOtifNoticeDoc, buildRouteOptionsDoc, buildTrackingReportDoc } from "@/lib/docs-logistics";
import { formatUsd } from "@/lib/format";
import { fmtHm, milkRunSummary, recommendedRoute, routeResults } from "@/lib/shipment-selectors";
import { useOtcStore } from "@/lib/store";

const ORDER = ["track", "cascade", "routes", "approve", "dispatch"] as const;
type StageId = (typeof ORDER)[number];
const GATES = ["approve"] as const satisfies readonly StageId[];
const HOLDS = ["dispatch"] as const satisfies readonly StageId[];

const ICONS = { track: Radar, cascade: Waypoints, routes: GitBranch, approve: PenLine, dispatch: Mail } as const;
const CONTROLS = ["1.2.2"];
const AGENTS = { track: "Track and Trace Agent", comms: "Communication Agent" };

/**
 * Run C: a milk run left the DC late and every stop is now at risk. The agent
 * predicts each stop from FourKites, compares the stop orders, and after the
 * transportation manager signs, dispatches the new order and warns the stop
 * that will still be late so the load is not refused.
 */
export function MilkRunRerouteRun({ onBack }: { onBack: () => void }) {
  const { appendAudit, resolveShipment } = useOtcStore();
  const m = MILK_RUN_CASE;
  const caseId = m.caseId;
  const row = RISK_ROWS.find((r) => r.caseId === caseId);
  const totalUsd = m.stops.reduce((s, x) => s + x.valueUsd, 0);

  const [signOpen, setSignOpen] = useState(false);
  const [chosenId, setChosenId] = useState<RouteOption["id"]>(recommendedRoute.id);
  const [tableDone, setTableDone] = useState(false);
  const [emailOpen, setEmailOpen] = useState(false);
  const [sent, setSent] = useState(false);
  const [finaleDismissed, setFinaleDismissed] = useState(false);
  const cardRefs = useRef<Record<string, HTMLDivElement | null>>({});

  const current = routeResults[0];
  const chosen = routeResults.find((r) => r.id === chosenId) ?? recommendedRoute;
  const late = chosen.timeline.filter((t) => t.miss);
  const isRecommended = chosen.id === recommendedRoute.id;

  const stages: Record<StageId, RunStageMeta> = useMemo(
    () => ({
      track: { id: "track", label: "Track", heading: "FourKites feed read, stop ETAs predicted", agent: AGENTS.track, summary: `Left ${m.actualDepart} · stop ETAs ${current.timeline.map((t) => fmtHm(t.arrive)).join(" / ")}` },
      cascade: { id: "cascade", label: "Cascade", heading: "Late departure cascades to every stop", agent: AGENTS.track, summary: `${current.misses} of ${m.stops.length} stops outside their window` },
      routes: { id: "routes", label: "Routes", heading: "Three stop orders compared", agent: AGENTS.track, summary: `${routeLabel(recommendedRoute.order)} · ${recommendedRoute.misses} miss` },
      approve: { id: "approve", label: "Approval", heading: `Route approval by ${TRANSPORT_LEAD.name}`, agent: `${TRANSPORT_LEAD.name} · ${TRANSPORT_LEAD.role}`, summary: `${routeLabel(chosen.order)} signed by ${TRANSPORT_LEAD.name}` },
      dispatch: { id: "dispatch", label: "Dispatch & notify", heading: "New stop order dispatched, receiving notified", agent: `${AGENTS.track} · ${AGENTS.comms}`, summary: `${routeLabel(chosen.order)} · ${late.length ? `${late.map((t) => t.stop.customer).join(", ")} notified` : "all on time"}` },
    }),
    [m, current, chosen, late]
  );

  const log = useCallback(
    (agent: string, action: string, extra: { evidence?: string[]; controlRefs?: string[]; system?: string } = {}) => {
      appendAudit({
        caseId,
        accountId: "Multiple",
        module: "Order Management",
        actor: { kind: "agent", name: agent, role: `Agent · works for ${TRANSPORT_LEAD.name}` },
        action,
        controlRefs: extra.controlRefs ?? [],
        amountUsd: totalUsd,
        evidence: extra.evidence ?? [],
        system: extra.system ?? "FourKites",
      });
    },
    [appendAudit, caseId, totalUsd]
  );

  const onStart = useCallback(
    (id: StageId) => {
      if (id === "track") log(AGENTS.track, `Read FourKites ${m.loadId}: departed ${m.actualDepart}, planned ${m.plannedDepart}`, { evidence: [m.loadId] });
      if (id === "cascade") log(AGENTS.track, `Current order ${routeLabel(current.order)}: ${current.misses} OTIF misses`, { evidence: ["FourKites tracking report"] });
      if (id === "routes") log(AGENTS.track, `Compared 3 stop orders; ${routeLabel(recommendedRoute.order)} has ${recommendedRoute.misses} miss`, { evidence: ["Route options"] });
      if (id === "approve") setSignOpen(true);
    },
    [m, current, log]
  );

  const run = useStagedRun<StageId>({ order: ORDER, gates: GATES, holds: HOLDS, onStart });
  const passHoldRef = useRef(run.passHold);
  passHoldRef.current = run.passHold;
  const startRun = run.start;
  useEffect(() => {
    startRun("track");
  }, [startRun]);

  const ready = useMemo(
    () => Object.fromEntries(ORDER.map((id) => [id, () => run.markReady(id)])) as Record<StageId, () => void>,
    // markReady is stable
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  const dispatchLogged = useRef(false);
  useEffect(() => {
    if (run.statuses.dispatch !== "running" || dispatchLogged.current) return;
    dispatchLogged.current = true;
    log(AGENTS.track, `Dispatched ${routeLabel(chosen.order)} to ${m.carrier}`, { controlRefs: CONTROLS, evidence: [m.loadId], system: TMS_SYSTEM });
  }, [run.statuses.dispatch, chosen, m, log]);

  const onTableDone = useCallback(() => {
    setTableDone(true);
    if (late.length) setEmailOpen(true);
    else setTimeout(() => passHoldRef.current("dispatch"), 400);
  }, [late.length]);

  const done = run.complete;
  useEffect(() => {
    if (!done) return;
    resolveShipment(
      caseId,
      isRecommended && row?.resolvedLabel ? row.resolvedLabel : `Rerouted · ${current.misses} misses → ${chosen.misses}`
    );
  }, [done, caseId, isRecommended, row, current.misses, chosen.misses, resolveShipment]);

  useFollowLatest(() => (run.active ? cardRefs.current[run.active] ?? null : null), run.active);

  const lateStop = late[0];
  const lateOwner = lateStop ? findAccount(lateStop.stop.accountId)?.owner : undefined;
  const notice = lateStop
    ? {
        cc: lateOwner ? `${lateOwner.name} · ${lateOwner.role}` : undefined,
        to: isRecommended ? m.reslot.email : `${lateStop.stop.customer.toLowerCase()}.receiving@example.com`,
        org: isRecommended ? m.reslot.to : `Inbound Receiving, ${lateStop.stop.site}`,
        subject: `Late arrival ${lateStop.stop.appointmentId} · ${fmtHm(lateStop.arrive)} today`,
        body: `Hello,\n\nThe load for ${lateStop.stop.site} (${lateStop.stop.orderId}, ${lateStop.stop.appointmentId}) left DC-ONT late and now arrives ${fmtHm(lateStop.arrive)}, outside the ${lateStop.stop.windowFrom}–${lateStop.stop.windowTo} window.\n\n${isRecommended ? `Could you move us to ${m.reslot.window} today so the load is received rather than refused?` : "Could you give us the next open receiving slot today so the load is received rather than refused?"}\n\nThank you,\nCustomer Service — Order Management`,
      }
    : null;

  const handleSend = () => {
    if (sent || !lateStop) return;
    setSent(true);
    setEmailOpen(false);
    log(AGENTS.comms, `Sent late-arrival notice to ${lateStop.stop.customer} for ${lateStop.stop.appointmentId}`, { evidence: ["OTIF-miss notice"], system: "Outlook" });
    setTimeout(() => passHoldRef.current("dispatch"), 400);
  };

  return (
    <div className="flex flex-col gap-4">
      <ShipmentRunHeader
        caseId={caseId}
        summary={`Milk run · ${m.stops.length} stops · ${formatUsd(totalUsd)}`}
        agents={[
          { name: AGENTS.track, type: "delivery" },
          { name: AGENTS.comms, type: "document" },
        ]}
        controls={CONTROLS}
        onBack={onBack}
      />

      <StageProgressRail
        stages={ORDER.map((id) => ({ id, label: stages[id].label, icon: ICONS[id] }))}
        statuses={run.statuses}
        openStageId={run.active}
        onStageClick={(id) => run.focus(id)}
      />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-[minmax(0,1fr)_300px]">
        <div className="flex min-w-0 flex-col gap-4">
          {ORDER.map((id) => {
            const status = run.statuses[id];
            if (status === "waiting") return null;
            return (
              <RunStageCard
                key={id}
                ref={(el) => {
                  cardRefs.current[id] = el;
                }}
                stage={stages[id]}
                status={status}
                open={run.open.has(id)}
                ready={run.ready.has(id)}
                canContinue={run.active === id && run.canAdvance}
                onToggle={() => run.toggle(id)}
                onContinue={run.advance}
                headerExtra={id === "approve" ? <ControlTags refs={CONTROLS} /> : undefined}
              >
                {id === "track" && (
                  <>
                    <AiStageNarration
                      variant="inline"
                      playKey={`${caseId}:n:track`}
                      text={`The truck left DC-ONT at ${m.actualDepart}, ${lateLabel(milkRunSummary.departLateMin).slice(1)} late. FourKites predicts stop 1 only, so the agent predicts all three from lane history, traffic, dwell and driver hours.`}
                    />
                    <FourKitesFeed playKey={caseId} agent={AGENTS.track} onDone={ready.track} />
                    <SourceDocTrigger doc={buildTrackingReportDoc()} label="FourKites tracking report" className="self-start" />
                  </>
                )}
                {id === "cascade" && (
                  <>
                    <AiStageNarration
                      variant="inline"
                      playKey={`${caseId}:n:cascade`}
                      text={`Each stop starts once the one before is unloaded, so the delay carries through. In the current order all ${m.stops.length} stops miss their window.`}
                    />
                    <StopTimeline timeline={current.timeline} playKey={`${caseId}:cascade`} onDone={ready.cascade} />
                  </>
                )}
                {id === "routes" && (
                  <>
                    <AiStageNarration
                      variant="inline"
                      playKey={`${caseId}:n:routes`}
                      text={`Serving Kroger and Costco first keeps both inside their windows. Target is then late, so it gets a notice and a ${m.reslot.window} re-slot request.`}
                    />
                    <RouteOptions playKey={`${caseId}:routes`} onDone={ready.routes} />
                    <SourceDocTrigger doc={buildRouteOptionsDoc()} label="Route options" className="self-start" />
                  </>
                )}
                {id === "approve" && (
                  <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border bg-muted/20 px-4 py-3">
                    <div className="flex flex-col gap-0.5 text-sm text-foreground">
                      <span>
                        OTIF misses <span className="font-semibold tabular-nums">{current.misses}</span> →{" "}
                        <span className="font-semibold tabular-nums">{recommendedRoute.misses}</span> with {routeLabel(recommendedRoute.order)}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {status === "passed" ? `${routeLabel(chosen.order)} approved` : "Choose the stop order in the sign-off"}
                      </span>
                    </div>
                    <Button size="sm" variant={status === "passed" ? "outline" : "default"} onClick={() => setSignOpen(true)}>
                      <PenLine className="h-4 w-4" />
                      {status === "passed" ? "View signature" : "Review & sign"}
                    </Button>
                  </div>
                )}
                {id === "dispatch" && (
                  <>
                    <StagedChangeTable
                      title={`Dispatch · ${m.loadId}`}
                      system={TMS_SYSTEM}
                      playKey={`${caseId}:dispatch:${chosen.id}`}
                      onDone={onTableDone}
                      rows={[
                        { key: "order", label: "Stop order", from: routeLabel(current.order), to: routeLabel(chosen.order), unchanged: chosen.id === current.id },
                        ...chosen.timeline.map((t) => ({
                          key: `eta-${t.stop.id}`,
                          label: `${t.stop.customer} ETA`,
                          code: t.stop.appointmentId,
                          from: fmtHm(current.timeline.find((c) => c.stop.id === t.stop.id)?.arrive ?? t.arrive),
                          to: `${fmtHm(t.arrive)}${t.miss ? ` · ${lateLabel(t.lateMin)}` : " · in window"}`,
                        })),
                        ...(isRecommended && lateStop
                          ? [{ key: "reslot", label: `${lateStop.stop.customer} re-slot request`, from: `${lateStop.stop.windowFrom}–${lateStop.stop.windowTo}`, to: m.reslot.window }]
                          : []),
                      ]}
                      footer={`Dispatched to ${m.carrier.split(" · ")[0]} · ${current.misses} misses → ${chosen.misses}`}
                      footerTrailing={<CheckChip result={chosen.misses < current.misses ? "pass" : "flag"} />}
                    />
                    {tableDone && lateStop && (
                      <div className="animate-enter flex flex-wrap items-center justify-between gap-3 rounded-lg border bg-card px-3 py-2.5">
                        <div className="flex min-w-0 flex-col gap-0.5">
                          <span className="text-sm font-medium text-foreground">{notice?.org}</span>
                          <span className="truncate text-xs text-muted-foreground">{notice?.subject}</span>
                        </div>
                        {sent ? (
                          <span className="rounded-md border border-green-200 bg-green-100 px-1.5 py-0.5 text-[11px] font-semibold text-green-700">
                            Notice sent
                          </span>
                        ) : (
                          <Button size="sm" onClick={() => setEmailOpen(true)}>
                            <Mail className="h-4 w-4" /> Open draft
                          </Button>
                        )}
                      </div>
                    )}
                  </>
                )}
              </RunStageCard>
            );
          })}
        </div>
        <div className="lg:sticky lg:top-4 lg:self-start">
          <RunAgentLog caseId={caseId} />
        </div>
      </div>

      <GateSignoffModal
        open={signOpen}
        onClose={() => setSignOpen(false)}
        gateId={`${caseId}:G1`}
        title="Approve the new stop order"
        documentNo={`${m.loadId} · ${caseId}`}
        caseId={caseId}
        accountId="Multiple"
        module="Order Management"
        system={TMS_SYSTEM}
        controls={CONTROLS}
        signers={[{ name: TRANSPORT_LEAD.name, role: TRANSPORT_LEAD.role }]}
        evidence={[
          { id: "feed", label: `FourKites tracking report · ${m.loadId}`, system: "FourKites", doc: buildTrackingReportDoc() },
          { id: "routes", label: "Route options · 3 compared", system: TMS_SYSTEM, doc: buildRouteOptionsDoc() },
          { id: "notice", label: `OTIF-miss notice to ${m.reslot.to}`, system: "Outlook", doc: buildOtifNoticeDoc() },
        ]}
        options={routeResults.map((r) => ({
          id: r.id,
          label: routeLabel(r.order),
          detail: `${r.timeline.map((t) => fmtHm(t.arrive)).join(" / ")} · ${r.misses} OTIF ${r.misses === 1 ? "miss" : "misses"}`,
          recommended: r.id === recommendedRoute.id,
        }))}
        defaultOptionId={recommendedRoute.id}
        attestation={`I approve the stop order selected above for ${m.loadId} and the notice to any stop that will still be late.`}
        confirmLabel="Approve route"
        action={`Approved new stop order for ${m.loadId}`}
        decision={(optionId) => `Approved ${routeLabel(routeResults.find((r) => r.id === optionId)?.order ?? recommendedRoute.order)}`}
        onSigned={(result) => {
          setSignOpen(false);
          if (result.optionId) setChosenId(result.optionId as RouteOption["id"]);
          run.passGate("approve");
        }}
      />

      {emailOpen && notice && (
        <EmailDraftDialog
          to={notice.to}
          toOrg={notice.org}
          cc={notice.cc}
          subject={notice.subject}
          body={notice.body}
          attachment={{ name: "FourKites-tracking-report.pdf", meta: `${m.loadId} · live ETA` }}
          sentLabel="Notice sent"
          onSend={handleSend}
          onClose={() => setEmailOpen(false)}
        />
      )}

      {done && !finaleDismissed && (
        <RunCompleteModal
          eyebrow="Shipment resolved"
          title={`${caseId} rerouted`}
          narrative={`${current.misses} misses → ${chosen.misses} · ${late.length ? "customer notified before arrival" : "every stop on time"}.`}
          stats={[
            { label: "OTIF misses", value: `${current.misses} → ${chosen.misses}`, tone: "success" },
            { label: "Stops on time", value: `${chosen.timeline.length - chosen.misses} of ${chosen.timeline.length}` },
            { label: "Loads protected", value: formatUsd(totalUsd) },
          ]}
          docs={[
            { doc: buildRouteOptionsDoc(), label: "Route options" },
            { doc: buildOtifNoticeDoc(), label: "OTIF-miss notice" },
          ]}
          primaryLabel="Back to Track & Trace"
          onPrimary={onBack}
          secondaryLabel="Stay here"
          onSecondary={() => setFinaleDismissed(true)}
          exportCaseId={caseId}
        />
      )}
    </div>
  );
}
