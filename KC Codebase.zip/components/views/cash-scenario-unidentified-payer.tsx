"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  Bot,
  CircleCheck,
  Clock,
  FileSearch,
  Landmark,
  Mail,
  RefreshCw,
  ScanLine,
  Send,
  Sparkles,
  Users,
} from "lucide-react";

import { Spinner } from "@/components/agents/spinner";
import { SystemBadge } from "@/components/shared/system-badge";
import { EmailDraftDialog } from "@/components/shared/email-draft-dialog";
import { StepRail } from "@/components/views/cash/step-rail";
import { RunCompleteModal } from "@/components/mounts/shared/run-complete-modal";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { findCashPayment } from "@/lib/data/cash-application";
import type { CashPayment, UnidentifiedPayerCase } from "@/lib/data/cash-application";
import { formatMoney } from "@/lib/cash-application-selectors";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const STEPS = [
  { id: "ingest", label: "Ingest", icon: FileSearch },
  { id: "identify", label: "Identify payer", icon: Users },
  { id: "decide", label: "Decide & request", icon: Send },
  { id: "reprocess", label: "Reprocess", icon: RefreshCw },
] as const;

const usd = (n: number) => formatMoney(n, "USD");

export function UnidentifiedPayerWorkspace({
  paymentId,
  onBack,
}: {
  paymentId: string;
  onBack: () => void;
}) {
  const { postedCashPayments, postCashPayment } = useOtcStore();
  const payment = findCashPayment(paymentId)!;
  const kase = payment.unidentifiedPayer!;
  const posted = postedCashPayments.includes(paymentId);

  const [stepIndex, setStepIndex] = useState(0);
  const currentStep = STEPS[stepIndex].id;
  const maxReached = Math.max(stepIndex, posted ? STEPS.length - 1 : 0);

  const primaryActionRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Enter") return;
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      if (!primaryActionRef.current) return;
      e.preventDefault();
      primaryActionRef.current();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const goTo = useCallback((i: number) => setStepIndex(i), []);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={onBack} className="gap-1.5">
            <ArrowLeft className="h-4 w-4" />
            Back to queue
          </Button>
          <div>
            <h2 className="text-lg font-semibold">
              {payment.paymentId} · {kase.payerName}
            </h2>
            <p className="text-xs text-muted-foreground">
              {usd(payment.amount)} received {payment.receivedDate} · remittance
              not yet received · paid by a treasury centre, not a sold-to
            </p>
          </div>
        </div>
        <Badge
          variant="outline"
          className={cn(
            posted
              ? "border-[var(--success)]/30 bg-[var(--success)]/10 text-[var(--success)]"
              : "border-amber-200 bg-amber-50 text-amber-700"
          )}
        >
          {posted ? "Cleared to accounts" : "Unidentified cash"}
        </Badge>
      </div>

      <StepRail steps={STEPS} activeIndex={stepIndex} maxReached={maxReached} onSelect={goTo} />

      {currentStep === "ingest" && (
        <IngestStep payment={payment} kase={kase} primaryActionRef={primaryActionRef} onContinue={() => goTo(1)} />
      )}
      {currentStep === "identify" && (
        <IdentifyStep payment={payment} kase={kase} primaryActionRef={primaryActionRef} onContinue={() => goTo(2)} />
      )}
      {currentStep === "decide" && (
        <DecideStep payment={payment} kase={kase} primaryActionRef={primaryActionRef} onContinue={() => goTo(3)} />
      )}
      {currentStep === "reprocess" && (
        <ReprocessStep
          payment={payment}
          kase={kase}
          posted={posted}
          primaryActionRef={primaryActionRef}
          onApprove={() => postCashPayment(payment.paymentId)}
          onDone={onBack}
        />
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Step 1 — Ingest: a bank credit with no remittance attached
 * ------------------------------------------------------------------ */

function IngestStep({
  payment,
  kase,
  primaryActionRef,
  onContinue,
}: {
  payment: CashPayment;
  kase: UnidentifiedPayerCase;
  primaryActionRef: React.MutableRefObject<(() => void) | null>;
  onContinue: () => void;
}) {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setReady(true), 1400);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    primaryActionRef.current = ready ? onContinue : null;
    return () => {
      primaryActionRef.current = null;
    };
  }, [ready, onContinue, primaryActionRef]);

  const fields = [
    { label: "Payer on statement", value: kase.payerName, confidence: 100, warn: true },
    { label: "Amount received", value: usd(payment.amount), confidence: 100 },
    { label: "Value date", value: payment.receivedDate, confidence: 99 },
    { label: "Bank narrative", value: kase.bankNarrative, confidence: 61, warn: true },
    { label: "Remittance advice", value: "Not received", confidence: 0, warn: true },
  ];

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_20rem]">
      <Card className="bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">
            A bank credit landed with no remittance
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center gap-3 rounded-lg border px-4 py-3">
            <div className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full bg-muted">
              <Landmark className="h-4 w-4 text-muted-foreground" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium">Bank statement</p>
              <p className="text-xs text-muted-foreground">
                {usd(payment.amount)} from {kase.payerName}
              </p>
            </div>
            <CircleCheck className="h-4 w-4 flex-shrink-0 text-[var(--success)]" />
          </div>

          <div className="flex items-center gap-3 rounded-lg border border-amber-200 bg-amber-50 px-4 py-3">
            <div className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full bg-amber-100">
              <FileSearch className="h-4 w-4 text-amber-700" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium text-amber-800">Remittance advice</p>
              <p className="text-xs text-amber-700">
                Not received — the statement says who paid, how much and when,
                but not which invoices it settles.
              </p>
            </div>
          </div>

          <div className="rounded-lg border border-primary/20 bg-primary/5 px-3 py-2.5 text-xs text-muted-foreground">
            <span className="text-foreground">The statement alone is not enough to post.</span>{" "}
            Applying it to a customer on a guess would risk a false match, so the
            AI first works out <span className="text-foreground">who this payer actually is</span>{" "}
            before any cash moves.
          </div>

          <div className="flex items-center justify-between pt-1">
            <p className="text-xs text-muted-foreground">
              {ready ? "Statement read. Payer not resolved yet." : "Reading the bank statement…"}
            </p>
            <Button size="sm" disabled={!ready} onClick={onContinue}>
              Identify the payer
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="h-fit bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-1.5 text-sm font-semibold">
            <ScanLine className="h-4 w-4 text-muted-foreground" />
            AI extraction
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2.5">
          {ready ? (
            fields.map((f) => (
              <div key={f.label} className="flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <p className="text-xs text-muted-foreground">{f.label}</p>
                  <p className="truncate text-sm font-medium">{f.value}</p>
                </div>
                <span
                  className={cn(
                    "flex-shrink-0 text-xs font-semibold tabular-nums",
                    f.confidence === 0
                      ? "text-amber-600"
                      : f.confidence >= 97
                        ? "text-[var(--success)]"
                        : "text-amber-600"
                  )}
                >
                  {f.confidence === 0 ? "—" : `${f.confidence}%`}
                </span>
              </div>
            ))
          ) : (
            <div className="flex items-center gap-2 py-6 text-xs text-muted-foreground">
              <Spinner className="h-4 w-4" />
              Reading fields off the statement…
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Step 2 — Identify the payer against the customer master
 * ------------------------------------------------------------------ */

function IdentifyStep({
  payment,
  kase,
  primaryActionRef,
  onContinue,
}: {
  payment: CashPayment;
  kase: UnidentifiedPayerCase;
  primaryActionRef: React.MutableRefObject<(() => void) | null>;
  onContinue: () => void;
}) {
  const [working, setWorking] = useState(true);

  useEffect(() => {
    const t = setTimeout(() => setWorking(false), 1600);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    primaryActionRef.current = working ? null : onContinue;
    return () => {
      primaryActionRef.current = null;
    };
  }, [working, onContinue, primaryActionRef]);

  if (working) {
    return (
      <Card className="bg-card">
        <CardContent className="flex items-center justify-center gap-3 py-12">
          <Spinner className="h-5 w-5" />
          <p className="text-sm text-muted-foreground">
            Resolving {kase.payerName} against the customer master and prior
            payment history…
          </p>
        </CardContent>
      </Card>
    );
  }

  const totalOpen = kase.candidateAccounts.reduce((s, a) => s + a.openValue, 0);

  return (
    <div className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-3">
        <Card className="bg-card">
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">Payer-to-customer match</p>
            <p className="mt-1 text-2xl font-bold tabular-nums text-amber-600">
              {kase.matchConfidence}%
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              Below the 95% auto-apply bar — needs assisted review
            </p>
          </CardContent>
        </Card>
        <Card className="bg-card">
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">Candidate invoices</p>
            <p className="mt-1 text-2xl font-bold tabular-nums">
              {kase.candidateInvoices}
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              across {kase.candidateAccounts.length} linked accounts
            </p>
          </CardContent>
        </Card>
        <Card className="bg-card">
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">Open AR on those accounts</p>
            <p className="mt-1 text-2xl font-bold tabular-nums">{usd(totalOpen)}</p>
            <p className="mt-1 text-xs text-muted-foreground">
              equals the receipt to the dollar
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_20rem]">
        <Card className="bg-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">
              Likely customer accounts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-left text-xs text-muted-foreground">
                  <th className="pb-2 font-medium">Account</th>
                  <th className="pb-2 font-medium">Sold-to</th>
                  <th className="pb-2 text-center font-medium">Open invoices</th>
                  <th className="pb-2 text-right font-medium">Open value</th>
                  <th className="pb-2 text-right font-medium">Likely share</th>
                </tr>
              </thead>
              <tbody>
                {kase.candidateAccounts.map((a) => (
                  <tr key={a.account} className="border-b last:border-0">
                    <td className="py-2.5 font-mono text-xs">{a.account}</td>
                    <td className="py-2.5 text-xs">{a.soldTo}</td>
                    <td className="py-2.5 text-center tabular-nums">{a.openInvoices}</td>
                    <td className="py-2.5 text-right tabular-nums">{usd(a.openValue)}</td>
                    <td className="py-2.5 text-right">
                      <span className="inline-flex items-center gap-2">
                        <span className="h-1.5 w-14 overflow-hidden rounded-full bg-muted">
                          <span
                            className="block h-full rounded-full bg-primary"
                            style={{ width: `${a.share}%` }}
                          />
                        </span>
                        <span className="tabular-nums text-xs">{a.share}%</span>
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>

        <Card className="h-fit bg-card">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-1.5 text-sm font-semibold">
              <Sparkles className="h-4 w-4 text-muted-foreground" />
              How the AI reasoned
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-xs text-muted-foreground">
              {kase.reasoning.map((r, i) => (
                <li key={i} className="flex gap-1.5">
                  <span aria-hidden="true">·</span>
                  <span>{r}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>

      <div className="flex items-center justify-between rounded-lg border border-amber-200 bg-amber-50 px-3 py-2.5">
        <p className="text-xs text-amber-800">
          The payer is a treasury centre paying for more than one account, so
          the match is confident but not certain — it goes to a person, not
          straight to post.
        </p>
        <Button size="sm" onClick={onContinue}>
          Decide treatment
        </Button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Step 3 — Decide: post on account, request remittance, pause chasing
 * ------------------------------------------------------------------ */

function DecideStep({
  payment,
  kase,
  primaryActionRef,
  onContinue,
}: {
  payment: CashPayment;
  kase: UnidentifiedPayerCase;
  primaryActionRef: React.MutableRefObject<(() => void) | null>;
  onContinue: () => void;
}) {
  const [posted, setPosted] = useState(false);
  const [requested, setRequested] = useState(false);
  const [paused, setPaused] = useState(false);
  const [showEmail, setShowEmail] = useState(false);
  const [emailSent, setEmailSent] = useState(false);
  const ready = posted && requested && paused;

  useEffect(() => {
    primaryActionRef.current = ready ? onContinue : null;
    return () => {
      primaryActionRef.current = null;
    };
  }, [ready, onContinue, primaryActionRef]);

  const emailSubject = `Remittance needed for ${usd(payment.amount)} received ${payment.receivedDate}`;

  const emailBody = `Hi team,

We've received a payment of ${usd(payment.amount)} from ${kase.payerName} but no remittance advice came with it. We've held the cash on account against the Albertsons group rather than applying it to invoices we aren't sure of.

Could you send the remittance detail so we can apply it to the right invoices? As soon as it arrives we'll clear it the same day.

Thanks,
Accounts Receivable`;

  return (
    <div className="space-y-4">
      <Card className="bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-1.5 text-sm font-semibold">
            <Bot className="h-4 w-4 text-primary" />
            Recommendation
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm">
            Post <span className="font-semibold tabular-nums">{usd(payment.amount)}</span> on
            account against the Albertsons group — the most likely customer —
            and request the missing remittance. Nothing is applied to a specific
            invoice until the remittance confirms it.
          </p>
        </CardContent>
      </Card>

      <div className="space-y-3">
        <ActionRow
          done={posted}
          title="Post on account to the Albertsons group"
          detail="Held at group level, not applied to individual invoices — reversible the moment the remittance lands."
          system="S/4HANA"
          actionLabel="Post on account"
          onAct={() => setPosted(true)}
          doneLabel={`${usd(payment.amount)} held on account`}
        />
        <ActionRow
          done={requested}
          title="Raise a remittance request"
          detail={`A task is opened in ${kase.requestSystem} asking the customer for the missing remittance, with an owner and a follow-up date.`}
          system={kase.requestSystem}
          actionLabel="Raise request"
          onAct={() => setRequested(true)}
          doneLabel="Request raised with owner + SLA"
          extra={
            <Button
              size="sm"
              variant="outline"
              className="mt-2"
              onClick={() => setShowEmail(true)}
            >
              <Mail className="h-4 w-4" />
              {emailSent ? "Email sent" : "View drafted message"}
            </Button>
          }
        />
        <ActionRow
          done={paused}
          title="Pause collections outreach"
          detail={`Collections chasing on the ${kase.candidateInvoices} candidate invoices is paused in ${kase.matchEngine} so the customer isn't chased for cash that has already arrived.`}
          system={kase.matchEngine}
          actionLabel="Pause outreach"
          onAct={() => setPaused(true)}
          doneLabel={`Outreach paused on ${kase.candidateInvoices} invoices`}
        />
      </div>

      <div className="flex items-center justify-between">
        <p className="text-xs text-muted-foreground">
          {ready
            ? "All three actions complete — the cash is safe and the clock is running."
            : "Complete the three actions to continue."}
        </p>
        <Button size="sm" disabled={!ready} onClick={onContinue}>
          Continue
        </Button>
      </div>

      {showEmail && (
        <EmailDraftDialog
          to="AP Contact"
          toOrg={kase.payerName}
          subject={emailSubject}
          body={emailBody}
          sentLabel="Remittance request sent"
          onSend={() => setEmailSent(true)}
          onClose={() => setShowEmail(false)}
        />
      )}
    </div>
  );
}

function ActionRow({
  done,
  title,
  detail,
  system,
  actionLabel,
  onAct,
  doneLabel,
  extra,
  extraOpen,
  extraContent,
}: {
  done: boolean;
  title: string;
  detail: string;
  system: string;
  actionLabel: string;
  onAct: () => void;
  doneLabel: string;
  extra?: React.ReactNode;
  extraOpen?: boolean;
  extraContent?: React.ReactNode;
}) {
  return (
    <Card className={cn("bg-card", done && "border-[var(--success)]/30")}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <p className="text-sm font-medium">{title}</p>
              <SystemBadge name={system} />
            </div>
            <p className="mt-1 text-xs text-muted-foreground">{detail}</p>
            {extra}
            {extraOpen && extraContent}
          </div>
          {done ? (
            <span className="inline-flex flex-shrink-0 items-center gap-1.5 text-xs font-medium text-[var(--success)]">
              <CircleCheck className="h-4 w-4" />
              {doneLabel}
            </span>
          ) : (
            <Button size="sm" variant="outline" className="flex-shrink-0" onClick={onAct}>
              {actionLabel}
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

/* ------------------------------------------------------------------ *
 * Step 4 — Reprocess once the remittance arrives
 * ------------------------------------------------------------------ */

function ReprocessStep({
  payment,
  kase,
  posted,
  primaryActionRef,
  onApprove,
  onDone,
}: {
  payment: CashPayment;
  kase: UnidentifiedPayerCase;
  posted: boolean;
  primaryActionRef: React.MutableRefObject<(() => void) | null>;
  onApprove: () => void;
  onDone: () => void;
}) {
  const [phase, setPhase] = useState<"waiting" | "parsing" | "matching" | "done">(
    posted ? "done" : "waiting"
  );
  const [showCeremony, setShowCeremony] = useState(false);

  const receiveRemittance = useCallback(() => {
    setPhase("parsing");
    setTimeout(() => setPhase("matching"), 1200);
    setTimeout(() => setPhase("done"), 2600);
  }, []);

  const approveAndCelebrate = useCallback(() => {
    onApprove();
    setShowCeremony(true);
  }, [onApprove]);

  useEffect(() => {
    if (posted || phase === "done") {
      primaryActionRef.current = posted
        ? onDone
        : showCeremony
          ? null
          : approveAndCelebrate;
    } else if (phase === "waiting") {
      primaryActionRef.current = receiveRemittance;
    } else {
      primaryActionRef.current = null;
    }
    return () => {
      primaryActionRef.current = null;
    };
  }, [posted, phase, showCeremony, receiveRemittance, approveAndCelebrate, onDone, primaryActionRef]);

  const doneNow = posted || phase === "done";

  return (
    <div className="space-y-4">
      <Card className="bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">
            On account · awaiting remittance
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex flex-wrap items-center gap-x-6 gap-y-2 rounded-lg border bg-muted/30 px-3 py-2.5 text-xs text-muted-foreground">
            <span className="inline-flex items-center gap-1.5">
              <Clock className="h-3.5 w-3.5" />
              Owner: AR Analyst · follow-up in 3 business days
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Sparkles className="h-3.5 w-3.5" />
              Escalates to AR Team Lead if no remittance in 7 days
            </span>
          </div>

          {!doneNow && (
            <p className="text-xs text-muted-foreground">
              The {usd(payment.amount)} is held on account against the Albertsons
              group — visible, owned and aging, never sitting silently in
              suspense. When the remittance arrives by email, portal or EDI, the
              receipt reprocesses automatically.
            </p>
          )}

          {phase === "waiting" && (
            <Button size="sm" onClick={receiveRemittance}>
              <Mail className="h-4 w-4" />
              Simulate remittance received
            </Button>
          )}

          {phase === "parsing" && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Spinner className="h-4 w-4" />
              {kase.parseEngine} is reading the remittance document…
            </div>
          )}
          {phase === "matching" && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Spinner className="h-4 w-4" />
              {kase.matchEngine} is reprocessing the receipt against open SAP
              items…
            </div>
          )}
        </CardContent>
      </Card>

      {doneNow && (
        <Card className="bg-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">
              {posted ? "Cleared to the right accounts" : "Ready to clear"}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <ul className="space-y-2 text-sm">
              <li className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  {posted && <CircleCheck className="h-4 w-4 text-[var(--success)]" />}
                  {kase.reprocess.remittanceItems} remittance items read and
                  matched
                </span>
                <span className="font-semibold tabular-nums text-[var(--success)]">
                  {usd(kase.reprocess.clearedValue)}
                </span>
              </li>
              <li className="flex items-center justify-between text-muted-foreground">
                <span>Applied to</span>
                <span className="text-foreground">{kase.reprocess.accountsCleared}</span>
              </li>
              <li className="flex items-center justify-between text-muted-foreground">
                <span>On-account balance remaining</span>
                <span className="font-semibold tabular-nums text-[var(--success)]">
                  {usd(0)}
                </span>
              </li>
              <li className="flex items-center justify-between text-muted-foreground">
                <span>Collections outreach</span>
                <span className="text-foreground">Resumed on cleared invoices</span>
              </li>
            </ul>

            {!posted && (
              <p className="text-xs text-muted-foreground">
                Reprocessing matched every line automatically — approving clears
                the on-account cash to the confirmed invoices in SAP with no
                duplicate entry.
              </p>
            )}

            <div className="flex justify-end">
              {posted ? (
                <Button size="sm" onClick={onDone}>
                  Back to queue
                </Button>
              ) : (
                <Button size="sm" onClick={approveAndCelebrate}>
                  Approve &amp; clear in SAP
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      <KpiCard
        title="KPIs demonstrated"
        items={[
          "Rate of unidentified cash",
          "Time to identify payer & customer",
          "Remittance capture rate",
          "Aging of cash held on account",
          "Collection contacts avoided",
          "Automatic reprocessing success",
        ]}
      />

      {showCeremony && (
        <RunCompleteModal
          eyebrow="Cash application complete"
          title={`${payment.paymentId} cleared to the right accounts`}
          narrative={`${usd(payment.amount)} arrived under a treasury-centre name with no remittance; the agent tied it to the Albertsons group and held it on account. When the remittance landed it reprocessed and cleared the same day, with collections paused meanwhile.`}
          stats={[
            { label: "Cash cleared", value: usd(kase.reprocess.clearedValue), tone: "success" },
            { label: "Payer match", value: `${kase.matchConfidence}%` },
            { label: "Remittance items", value: `${kase.reprocess.remittanceItems}` },
            { label: "Residual", value: usd(0), tone: "success" },
          ]}
          primaryLabel="Back to queue"
          onPrimary={onDone}
          secondaryLabel="Review result"
          onSecondary={() => setShowCeremony(false)}
        />
      )}
    </div>
  );
}

export function KpiCard({ title, items }: { title: string; items: string[] }) {
  return (
    <Card className="bg-card">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-semibold">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-2">
          {items.map((k) => (
            <span
              key={k}
              className="rounded-full border bg-muted/40 px-3 py-1 text-xs text-muted-foreground"
            >
              {k}
            </span>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
