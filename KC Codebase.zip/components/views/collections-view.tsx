"use client";

import { useState } from "react";
import {
  Bell,
  Calendar,
  CircleCheck,
  Clock,
  Mail,
  MessageSquare,
  Phone,
  TrendingUp,
  User,
} from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import { NudgeActions } from "@/components/mounts/collections/nudge-actions";
import { PriorityWorklistTab } from "@/components/mounts/collections/priority-worklist-tab";
import { ProvisionTab } from "@/components/mounts/collections/provision-tab";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { customers } from "@/lib/data";
import { formatMoney, paymentPropensity } from "@/lib/selectors";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

type CollectionsTab = "workbench" | "worklist" | "provision";

function formatLongDate(isoDate: string): string {
  return new Date(isoDate + "T00:00:00Z").toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    timeZone: "UTC",
  });
}

export function CollectionsView() {
  const { runReturnStage } = useOtcStore();
  // Land on the worklist during a guided run so the run row is in view.
  const [activeTab, setActiveTab] = useState<CollectionsTab>(
    runReturnStage === "collections" ? "worklist" : "workbench"
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap gap-2">
        <Button
          variant={activeTab === "workbench" ? "default" : "outline"}
          onClick={() => setActiveTab("workbench")}
        >
          <AgentIcon type="dunning" size="sm" className="mr-2" />
          Dunning Workbench
        </Button>
        <Button
          variant={activeTab === "worklist" ? "default" : "outline"}
          onClick={() => setActiveTab("worklist")}
        >
          <AgentIcon type="ltv" size="sm" className="mr-2" />
          Priority Worklist
        </Button>
        <Button
          variant={activeTab === "provision" ? "default" : "outline"}
          onClick={() => setActiveTab("provision")}
        >
          <AgentIcon type="billing" size="sm" className="mr-2" />
          Bad Debt Provision
        </Button>
      </div>
      {activeTab === "workbench" && <DunningWorkbenchTab />}
      {activeTab === "worklist" && <PriorityWorklistTab />}
      {activeTab === "provision" && <ProvisionTab />}
    </div>
  );
}

function DunningWorkbenchTab() {
  const customer = customers[0];
  // Same source as every other propensity read — no duplicated literal.
  const propensityPct = Math.round(paymentPropensity["CUST-001"] * 100);
  // The nudge quotes the live invoice record from the store.
  const { allInvoices } = useOtcStore();
  const nudgeInvoice = allInvoices.find(
    (invoice) => invoice.invoiceId === "INV-12345"
  );
  const [nudgeChannel, setNudgeChannel] = useState<"email" | "sms" | "portal">(
    "email"
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-foreground">
            Smart Dunning Workbench
          </h2>
          <p className="text-muted-foreground">
            Proactive collections with AI-powered nudges
          </p>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <User className="h-5 w-5 text-primary" />
              Customer Segment
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="text-xl font-bold text-foreground">
                {customer.name}
              </div>
              <div className="text-sm text-muted-foreground">
                {customer.customerId}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="text-xs text-muted-foreground">Risk Tier</div>
                <Badge className="bg-[var(--warning)] text-[var(--warning-foreground)] mt-1">
                  Medium
                </Badge>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Relationship</div>
                <Badge
                  variant="outline"
                  className="border-[var(--success)] text-[var(--success)] mt-1"
                >
                  {customer.relationshipTier}
                </Badge>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-muted-foreground">Payment Propensity</span>
                <span className="font-medium text-foreground">
                  {propensityPct}%
                </span>
              </div>
              <Progress value={propensityPct} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-muted-foreground">LTV Score</span>
                <span className="font-medium text-foreground">
                  {(100 * customer.ltvScore).toFixed(0)}%
                </span>
              </div>
              <Progress value={100 * customer.ltvScore} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-muted-foreground">Churn Risk</span>
                <span className="font-medium text-foreground">
                  {(100 * customer.churnRiskScore).toFixed(0)}%
                </span>
              </div>
              <Progress value={100 * customer.churnRiskScore} className="h-2" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Calendar className="h-5 w-5 text-primary" />
              Treatment Plan
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-3 bg-primary/10 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Badge className="bg-primary text-primary-foreground">
                  Early Nudge
                </Badge>
                <Badge variant="outline">Accelerated</Badge>
              </div>
              <p className="text-sm text-muted-foreground">
                Pre-due personalized reminder to maintain touchless order flow
              </p>
            </div>
            <div className="space-y-3">
              <div className="flex items-center gap-3 p-2 bg-muted/50 rounded-lg">
                <div className="h-8 w-8 rounded-full bg-[var(--success)]/10 flex items-center justify-center">
                  <CircleCheck className="h-4 w-4 text-[var(--success)]" />
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium text-foreground">
                    Initial Reminder
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Sent 3 days ago
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3 p-2 bg-[var(--warning)]/10 rounded-lg border border-[var(--warning)]/20">
                <div className="h-8 w-8 rounded-full bg-[var(--warning)]/20 flex items-center justify-center">
                  <Clock className="h-4 w-4 text-[var(--warning)]" />
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium text-foreground">
                    Follow-up Nudge
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Scheduled: Today 4:00 PM
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3 p-2 bg-muted/50 rounded-lg opacity-60">
                <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium text-foreground">
                    Call if needed
                  </div>
                  <div className="text-xs text-muted-foreground">
                    5 days before due
                  </div>
                </div>
              </div>
            </div>
            <div className="pt-2">
              <div className="text-xs text-muted-foreground mb-2">Owner</div>
              <div className="flex items-center gap-2">
                <div className="h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center">
                  <User className="h-3 w-3 text-primary" />
                </div>
                <span className="text-sm text-foreground">
                  Collections Specialist
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Mail className="h-5 w-5 text-primary" />
              Nudge Preview
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2" role="group" aria-label="Nudge channel">
              {(
                [
                  { id: "email", label: "Email", Icon: Mail },
                  { id: "sms", label: "SMS", Icon: MessageSquare },
                  { id: "portal", label: "Portal", Icon: Bell },
                ] as const
              ).map(({ id, label, Icon }) => (
                <Button
                  key={id}
                  size="sm"
                  variant={nudgeChannel === id ? "default" : "outline"}
                  aria-pressed={nudgeChannel === id}
                  className={cn("flex-1", nudgeChannel !== id && "bg-transparent")}
                  onClick={() => setNudgeChannel(id)}
                >
                  <Icon className="h-4 w-4 mr-1" />
                  {label}
                </Button>
              ))}
            </div>
            <div className="p-4 bg-muted/50 rounded-lg space-y-3">
              <div className="text-sm font-medium text-foreground">
                Keep future orders touchless—complete early payment for INV-12345
              </div>
              <div className="text-sm text-muted-foreground leading-relaxed">
                Hi Accounts Payable Team,
                <br />
                <br />
                Your recent order SO-710245 was released under a conditional
                approval due to credit limits.
                <br />
                <br />
                To keep your future orders fully touchless (no holds), please
                complete early payment for invoice INV-12345 of{" "}
                <strong>{nudgeInvoice ? formatMoney(nudgeInvoice.amount) : ""}</strong>{" "}
                by{" "}
                <strong>
                  {nudgeInvoice ? formatLongDate(nudgeInvoice.dueDate) : ""}
                </strong>
                .
              </div>
            </div>
            <NudgeActions invoice={nudgeInvoice} />
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Recent Outcomes</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <div className="flex items-center gap-2 p-3 bg-[var(--success)]/10 rounded-lg">
              <CircleCheck className="h-5 w-5 text-[var(--success)]" />
              <div>
                <div className="text-sm font-medium text-foreground">
                  INV-12348
                </div>
                <div className="text-xs text-[var(--success)]">Paid Early</div>
              </div>
            </div>
            <div className="flex items-center gap-2 p-3 bg-[var(--success)]/10 rounded-lg">
              <CircleCheck className="h-5 w-5 text-[var(--success)]" />
              <div>
                <div className="text-sm font-medium text-foreground">
                  Promise Honored
                </div>
                <div className="text-xs text-[var(--success)]">
                  91.5% adherence
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2 p-3 bg-[var(--info)]/10 rounded-lg">
              <TrendingUp className="h-5 w-5 text-[var(--info)]" />
              <div>
                <div className="text-sm font-medium text-foreground">
                  DSO Improvement
                </div>
                <div className="text-xs text-[var(--info)]">
                  -2.5 days this month
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
