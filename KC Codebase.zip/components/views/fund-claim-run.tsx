"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useMounted } from "@/lib/hooks/use-mounted";
import {
  ArrowLeft,
  ArrowRight,
  Banknote,
  CircleCheck,
  FileText,
  Landmark,
  Layers,
  Mail,
  Pencil,
  Scale,
  ShieldCheck,
  ThumbsUp,
  Wallet,
} from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import { Spinner } from "@/components/agents/spinner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { SignedApproveButton } from "@/components/shared/signed-approve-button";
import { findAccount } from "@/lib/data/account-owners";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  SourceDocTrigger,
  SourceDocRowTrigger,
} from "@/components/modals/source-doc-preview";
import { formatUsd } from "@/lib/chargeback-selectors";
import { TODAY } from "@/lib/data/clock";
import {
  fundClaimAssessment,
  fundClaimAccounting,
  renderFundClaimLetter,
} from "@/lib/fund-claim-selectors";
import {
  buildFundDeductionDoc,
  buildFundCheckbookDoc,
  buildAllocationDoc,
  buildControlsDoc,
  buildFundLetterDoc,
  buildEventDoc,
  buildFundDoc,
  buildAllocationLineDoc,
  buildControlLineDoc,
} from "@/lib/docs-fund-claims";
  import { useOtcStore } from "@/lib/store";
import { ClaimEditModal } from "@/components/modals/claim-edit-modal";
import { cn } from "@/lib/utils";
import { SystemMark } from "@/components/shared/system-badge";

import {
  AiStageNarration,
  narrationDwellMs,
} from "@/components/mounts/chargebacks/ai-stage-narration";
import {
  AgentAuditTrail,
  RunStageRow,
  RUN_STAGE_BODY_CLASS,
  RUN_STAGE_CARD_CLASS,
} from "@/components/mounts/shared/run-stage-row";
import { StageProgressRail } from "@/components/mounts/shared/stage-progress-rail";
import { RunCompleteModal } from "@/components/mounts/shared/run-complete-modal";
import { GtnImpactPanel } from "@/components/mounts/deductions/gtn-impact-panel";
import { DisputeLetterComposer } from "@/components/mounts/deductions/dispute-letter-composer";
import { AgentDecision } from "@/components/mounts/deductions/agent-decision";

type SimStatus = "waiting" | "running" | "passed" | "needsReview";

/**
 * Scenario 4 — wrong fund, insufficient accrual and settlement mismatch.
 *
 * A retailer submits a valid $180,000 promotion claim. The promotion happened;
 * the question is how to allocate it. The claim references one fund with only
 * $140,000 available, but it actually spans two overlapping events on two funds.
 * The run matches the claim to both events, checks each fund's available
 * accrual, proposes an auditable split ($140,000 + $40,000), routes the budget
 * exception for trade-finance review, and confirms the four downstream postings
 * reconcile. Two steps are gates: approving the allocation and the letter.
 */
const STAGES = [
  {
    id: "intake",
    label: "Claim",
    heading: "Valid promotion claim withheld on the invoice",
    agent: "Deduction Intake Agent",
    agentType: "orchestrator",
    icon: Banknote,
    log: "Promotion claim matched to the invoice and the referenced plan.",
  },
  {
    id: "events",
    label: "Events",
    heading: "Claim matched to the promotion events",
    agent: "Promotion Matching Agent",
    agentType: "document",
    icon: FileText,
    log: "Claim mapped to two overlapping events — a feature and a display — funded separately.",
  },
  {
    id: "funds",
    label: "Fund budget",
    heading: "Available accrual checked against each fund",
    agent: "Fund Control Agent",
    agentType: "validation",
    icon: Wallet,
    log: "Referenced fund short by $40,000; a second eligible fund holds the balance.",
  },
  {
    id: "allocation",
    label: "Allocation",
    heading: "Auditable split proposed across two funds",
    agent: "Allocation Agent",
    agentType: "validation",
    icon: Layers,
    log: "Split proposed — $140,000 to the referenced fund, $40,000 to the second. Awaiting approval.",
  },
  {
    id: "letter",
    label: "Retailer response",
    heading: "Retailer response",
    agent: "Correspondence Agent",
    agentType: "invoice",
    icon: Mail,
    log: "Confirmation drafted explaining the approval and the two-fund split. Not yet issued.",
  },
  {
    id: "settlement",
    label: "Settlement",
    heading: "Settlement controls and accounting impact",
    agent: "Revenue Accounting Agent",
    agentType: "invoice",
    icon: Landmark,
    log: "Credit memo, checkbook, FI posting and dispute closure reconciled to the claim.",
  },
] as const;

const STAGE_DWELL_MS = 4000;

const asText = (n: string | string[] | undefined) =>
  Array.isArray(n) ? n.join("\n") : (n ?? "");

export function FundClaimRun({
  caseId,
  onBack,
}: {
  caseId: string;
  onBack: () => void;
}) {
  const { resolveFundClaim, claimEdits, setClaimEdit } = useOtcStore();
  const edit = claimEdits[caseId];
  const assessment = fundClaimAssessment(caseId, edit);
  const accounting = fundClaimAccounting(caseId, edit);
  const anchorReferenced = fundClaimAssessment(caseId)?.referencedAllocated ?? 0;

  const [statuses, setStatuses] = useState<Record<string, SimStatus>>(() =>
    Object.fromEntries(STAGES.map((s) => [s.id, "waiting" as SimStatus]))
  );
  const [openStages, setOpenStages] = useState<Set<string>>(new Set());
  const [activeStage, setActiveStage] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);
  const [awaitingAdvance, setAwaitingAdvance] = useState(false);
  const [allocApproved, setAllocApproved] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [letterSent, setLetterSent] = useState(false);
  const [sentOn, setSentOn] = useState<string | undefined>(undefined);
  const [finaleDismissed, setFinaleDismissed] = useState(false);

  const advanceRef = useRef<(() => void) | null>(null);
  const startedRef = useRef(false);
  const allocRef = useRef(false);
  const letterRef = useRef(false);
  const cardRefs = useRef<Record<string, HTMLDivElement | null>>({});

  const narration: Record<string, string | string[]> = assessment
    ? {
  intake: `${assessment.case.customerName} withheld ${formatUsd(assessment.claimed)} for a valid back-to-school promotion under ${assessment.case.claimRef}. The question is how it's allocated and settled.`,
  events: [
  `The claim references one event, but the spend spans two.`,
  `A family-care feature and a baby-care display ran in overlapping weeks, funded from two different funds.`,
  ],
  funds: [
  `The referenced fund holds only ${formatUsd(assessment.referencedAvailable)} against a ${formatUsd(assessment.claimed)} claim — short by ${formatUsd(assessment.overflow)}.`,
  `Rather than overspend it, the ${formatUsd(assessment.overflow)} moves to the second eligible fund, which has ample accrual.`,
  ],
  allocation: [
  `AI proposes ${formatUsd(assessment.referencedAllocated)} to ${assessment.referencedFund.name} and ${formatUsd(assessment.overflow)} to the second fund.`,
  `The ${formatUsd(assessment.budgetExceptionValue)} exception exceeds the ${formatUsd(assessment.case.materialityThreshold)} threshold — Trade Finance review required.`,
  ],
  letter: `Response ${assessment.case.responseLetter.letterRef} drafted, confirming full approval and explaining the two-fund split.`,
  settlement: `The whole ${formatUsd(assessment.claimed)} is a genuine trade cost — one credit memo clears the deduction and everything reconciles.`,
      }
    : {};
  const narrationRef = useRef(narration);
  narrationRef.current = narration;

  const openStage = useCallback((id: string) => {
    setOpenStages(new Set([id]));
    setActiveStage(id);
  }, []);

  const runFrom = useCallback(
    async (startId: string) => {
      setProcessing(true);
      const from = Math.max(0, STAGES.findIndex((s) => s.id === startId));
      for (const stage of STAGES.slice(from)) {
        if (stage.id === "letter" && !allocRef.current) {
          setStatuses((p) => ({ ...p, allocation: "needsReview" }));
          openStage("allocation");
          setProcessing(false);
          return;
        }
        if (stage.id === "settlement" && !letterRef.current) {
          setStatuses((p) => ({ ...p, letter: "needsReview" }));
          openStage("letter");
          setProcessing(false);
          return;
        }
        setStatuses((p) => ({ ...p, [stage.id]: "running" }));
        openStage(stage.id);

        let marked = false;
        const markPassed = () => {
          if (marked) return;
          marked = true;
          setStatuses((p) => ({ ...p, [stage.id]: "passed" }));
        };
        const dwell = setTimeout(
          markPassed,
          narrationDwellMs(asText(narrationRef.current[stage.id]), STAGE_DWELL_MS)
        );
        const advanced = new Promise<void>((r) => {
          advanceRef.current = r;
        });
        setAwaitingAdvance(true);
        await advanced;
        setAwaitingAdvance(false);
        clearTimeout(dwell);
        markPassed();
      }
      setProcessing(false);
      setActiveStage(null);
    },
    [openStage]
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Enter") return;
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      if (!advanceRef.current) return;
      e.preventDefault();
      const go = advanceRef.current;
      advanceRef.current = null;
      go();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    if (startedRef.current || !assessment) return;
    startedRef.current = true;
    void runFrom("intake");
  }, [runFrom, assessment]);

  useEffect(() => {
    if (!activeStage) return;
    const node = cardRefs.current[activeStage];
    node?.scrollIntoView({ behavior: "smooth", block: "center" });
  }, [activeStage]);

  useEffect(() => {
    if (!allocApproved) return;
    setStatuses((p) => ({ ...p, allocation: "passed" }));
    void runFrom("letter");
  }, [allocApproved, runFrom]);

  useEffect(() => {
    if (!letterSent) return;
    setStatuses((p) => ({ ...p, letter: "passed" }));
    void runFrom("settlement");
  }, [letterSent, runFrom]);

  useEffect(() => {
    if (statuses.settlement === "passed") resolveFundClaim(caseId);
  }, [statuses.settlement, resolveFundClaim, caseId]);

  if (!assessment || !accounting) return null;

  const a = assessment;
  const c = a.case;
  const doneCount = STAGES.filter((s) => statuses[s.id] === "passed").length;
  const reached: string[] = STAGES.filter(
    (s) => statuses[s.id] !== "waiting"
  ).map((s) => s.id);

  const decisionReasoning = [
    `The referenced fund can hold ${formatUsd(assessment.referencedAllocated)} of the ${formatUsd(assessment.claimed)} claim.`,
    assessment.overflow > 0 ? `The other ${formatUsd(assessment.overflow)} belongs to the overlapping event's fund.` : `The referenced fund covers the whole claim.`,
    `Decision: allocate across ${assessment.allocations.length} fund${assessment.allocations.length === 1 ? "" : "s"}, nothing left unfunded.`,
  ];
  const renderStage = (stageId: string) =>
    stageId === "allocation" ? (
      <AgentDecision stepKey={`${caseId}:allocation`} lines={decisionReasoning}>
        {renderBody(stageId)}
      </AgentDecision>
    ) : (
      renderBody(stageId)
    );

  const renderBody = (id: string) => {
    switch (id) {
      case "intake":
        return (
          <div className="space-y-3">
            <PaymentSplitBar assessment={a} />
            <SourceDocTrigger
              doc={buildFundDeductionDoc(caseId)}
              label="View the promotion claim"
            />
          </div>
        );
      case "events":
        return <EventsCard assessment={a} caseId={caseId} />;
      case "funds":
        return <CheckbookCard assessment={a} caseId={caseId} />;
      case "allocation":
        return (
          <div className="space-y-3">
            <AllocationCard assessment={a} caseId={caseId} />
            {allocApproved ? (
              <p className="flex items-center gap-1.5 text-xs text-[var(--success)]">
                <ThumbsUp className="h-3.5 w-3.5" />
                Approved by you — {formatUsd(a.referencedAllocated)} +{" "}
                {formatUsd(a.overflow)} across two funds.
              </p>
            ) : (
              <div className="flex flex-wrap items-center gap-3 rounded-lg border-2 border-amber-200 bg-amber-50/60 px-3 py-2.5">
                <ShieldCheck className="h-4 w-4 shrink-0 text-amber-700" />
                <span className="flex-1 text-xs text-amber-900">
                  {a.needsTradeFinanceReview
                    ? `Budget exception of ${formatUsd(a.budgetExceptionValue)} is above the ${formatUsd(c.materialityThreshold)} materiality threshold — Trade Finance review required.`
                    : "Within tolerance — recommended for approval."}{" "}
                  Nothing is settled until you approve the allocation.
                </span>
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="whitespace-nowrap gap-1.5"
                    onClick={() => setEditOpen(true)}
                  >
                    <Pencil className="h-3.5 w-3.5" />
                    Edit
                  </Button>
                  <SignedApproveButton
                    gateId={`${caseId}:G1`}
                    title="Approve the fund allocation"
                    caseId={c.caseId}
                    accountId={findAccount(c.customerName)?.accountId ?? ""}
                    module="Deductions"
                    system="Vistex"
                    controls={["1.7.2"]}
                    evidence={[
                      { id: "ref", label: `${a.referencedFund.name} · ${formatUsd(a.referencedAllocated)}`, system: "Vistex" },
                      { id: "overflow", label: `Second fund · ${formatUsd(a.overflow)}`, system: "Vistex" },
                    ]}
                    lines={[{ label: "Claim allocated", amountUsd: a.claimed, kind: "other" }]}
                    materialityUsd={c.materialityThreshold}
                    attestation={`I approve allocating ${formatUsd(a.claimed)} on ${c.caseId}: ${formatUsd(a.referencedAllocated)} to ${a.referencedFund.name} and ${formatUsd(a.overflow)} to the second fund.`}
                    action={`Approved fund allocation ${formatUsd(a.referencedAllocated)} + ${formatUsd(a.overflow)}`}
                    decision="Allocation approved"
                    onSigned={() => {
                      allocRef.current = true;
                      setAllocApproved(true);
                    }}
                  >
                    Approve split allocation
                  </SignedApproveButton>
                </div>
              </div>
            )}
          </div>
        );
      case "letter": {
        const letter = renderFundClaimLetter(caseId, edit)!;
        return (
          <DisputeLetterComposer
            letterKey={c.caseId}
            from={`${c.responseLetter.from} <trade.finance@internal.example>`}
            to={`${c.responseLetter.to} <trade.finance@retailer.example>`}
            subject={letter.subject}
            body={letter.body}
            attachments={[
              {
                doc: buildFundDeductionDoc(caseId),
                label: `Deduction ${c.remittanceId}`,
              },
              {
                doc: buildFundCheckbookDoc(caseId),
                label: "Fund checkbook",
              },
              {
                doc: buildAllocationDoc(caseId),
                label: "Allocation proposal",
              },
              {
                doc: buildFundLetterDoc(caseId, letterSent),
                label: "Letter as a document",
              },
            ]}
            sent={letterSent}
            sentDate={sentOn}
            sentNote={`Issued to ${c.customerName}. Promotion approved in full at ${formatUsd(a.claimed)}; one credit memo clears the deduction.`}
            canSend={allocApproved && !letterSent}
            blockedNote="Approve the allocation first."
            onSend={() => {
              letterRef.current = true;
              setSentOn(TODAY);
              setLetterSent(true);
            }}
          />
        );
      }
      case "settlement":
        return (
          <div className="space-y-3">
            <ControlsCard assessment={a} caseId={caseId} />
            <GtnImpactPanel
              shortPay={a.claimed}
              gtnImpact={accounting.gtnImpact}
              recoveryRequired={accounting.recoveryRequired}
              basis={`The whole ${formatUsd(a.claimed)} is a genuine promotional cost — the promotion is valid. It settles against the deduction with one credit memo, expensed across the two funds in proportion to where the spend ran: ${formatUsd(a.referencedAllocated)} and ${formatUsd(a.overflow)}. Nothing is clawed back.`}
              lines={accounting.lines}
              caseRef={c.caseId}
              claimRef={c.claimRef}
            />
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      {editOpen && (
        <ClaimEditModal
          title="Edit fund allocation"
          caseLabel={`${c.caseId} — ${c.customerName} · ${formatUsd(a.claimed)} claim`}
          total={a.claimed}
          primaryValue={a.referencedAllocated}
          anchorValue={anchorReferenced}
          leftLabel={a.referencedFund.name}
          rightLabel={a.fundsAfter.find((f) => f.fund.fundId !== a.referencedFund.fundId)?.fund.name ?? "Second fund"}
          leftHint={`Settles on the referenced fund (had ${formatUsd(a.referencedAvailable)} available)`}
          rightHint="Overflow moves to the second eligible fund"
          leftTone="primary"
          rightTone="sky"
          aiRationale={`The whole ${formatUsd(a.claimed)} is a valid claim — this only sets where the spend lands. AI caps the referenced fund at its ${formatUsd(a.referencedAvailable)} accrual and overflows the rest.`}
          presets={[
            { id: "ai", label: "AI recommendation", detail: `Cap at accrual, overflow the rest`, value: anchorReferenced, ai: true },
            { id: "all-ref", label: "All on referenced fund", detail: "Ignore the accrual cap", value: a.claimed },
            { id: "even", label: "Split evenly", detail: "Half to each fund", value: Math.round(a.claimed / 2) },
            { id: "all-second", label: "All to second fund", detail: "Nothing on referenced", value: 0 },
          ]}
          confirmLabel="Apply allocation"
          onConfirm={(v) => {
            setClaimEdit(caseId, { primaryAllocated: v });
            setEditOpen(false);
          }}
          onReset={() => {
            setClaimEdit(caseId, null);
            setEditOpen(false);
          }}
          onClose={() => setEditOpen(false)}
        />
      )}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <button
            type="button"
            onClick={onBack}
            className="mb-1 inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            All deductions
          </button>
          <h2 className="text-xl font-semibold">
            {c.caseId} — {c.customerName}
          </h2>
          <p className="text-sm text-muted-foreground">
            A valid promotion claim that spans two funds. The claim is matched to
            both events, each fund&apos;s accrual is checked, and an auditable
            split is proposed; the allocation approval and the letter are yours.
          </p>
        </div>
        {processing && !awaitingAdvance && (
          <span className="flex items-center gap-2 text-sm text-muted-foreground">
            <Spinner size="sm" />
            Investigation in progress
          </span>
        )}
      </div>

      <Card className="bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="flex flex-wrap items-center gap-2 text-sm font-semibold">
            <Badge variant="outline" className="whitespace-nowrap">
              {formatUsd(a.claimed)} withheld on {c.invoiceId}
            </Badge>
            <span className="text-xs font-normal text-muted-foreground">
              {doneCount}/{STAGES.length} steps cleared
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-2">
          <StageProgressRail
            stages={STAGES}
            statuses={statuses}
            openStageId={activeStage}
            onStageClick={(id) => {
              if (reached.includes(id)) openStage(id);
            }}
          />
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[minmax(0,1fr)_320px]">
        <div className="space-y-4">
          {STAGES.filter((s) => reached.includes(s.id)).map((stage) => (
            <Card
              key={stage.id}
              ref={(el) => {
                cardRefs.current[stage.id] = el;
              }}
              className={RUN_STAGE_CARD_CLASS}
            >
              <RunStageRow
                label={stage.heading}
                status={statuses[stage.id]}
                expanded={openStages.has(stage.id)}
                summary={stage.log}
                onToggle={() =>
                  setOpenStages((prev) => {
                    const next = new Set(prev);
                    next.has(stage.id) ? next.delete(stage.id) : next.add(stage.id);
                    return next;
                  })}
              />
              {openStages.has(stage.id) && (
                <CardContent className="space-y-4 border-t px-4 py-4 animate-in fade-in slide-in-from-top-2 duration-300">
                  {narration[stage.id] && stage.id !== "allocation" && (
                    <AiStageNarration key={stage.id} text={narration[stage.id]} variant="inline" />
                  )}
                  {renderStage(stage.id)}
                </CardContent>
              )}
            </Card>
          ))}
        </div>

        <AgentAuditTrail
          entries={STAGES.filter((s) => statuses[s.id] !== "waiting").map((s) => ({
            id: s.id,
            agent: s.agent,
            agentType: s.agentType,
            message: s.log,
            tone:
              statuses[s.id] === "needsReview"
                ? ("attention" as const)
                : statuses[s.id] === "running"
                  ? ("info" as const)
                  : ("success" as const),
          }))}
        />
      </div>

      {statuses.settlement === "passed" && !finaleDismissed && (
        <RunCompleteModal
          eyebrow="Promotion claim settled"
          title={`${c.caseId} allocated and reconciled`}
          narrative="The valid claim was approved in full and split across the two funds where the spend actually ran — the referenced fund up to its available accrual, and the balance to the second eligible fund. One credit memo clears the deduction, and the checkbook, FI posting and dispute case all reconcile to the same figure."
          stats={[
            { label: "claimed", value: formatUsd(a.claimed) },
            {
              label: "referenced fund",
              value: formatUsd(a.referencedAllocated),
              tone: "success",
            },
            {
              label: "second fund",
              value: formatUsd(a.overflow),
              tone: "success",
            },
          ]}
          docs={[
            {
              doc: buildAllocationDoc(caseId),
              label: "Allocation proposal",
            },
            {
              doc: buildControlsDoc(caseId),
              label: "Settlement controls",
            },
            {
              doc: buildFundLetterDoc(caseId, true),
              label: `Retailer response ${c.responseLetter.letterRef}`,
            },
          ]}
          primaryLabel="Back to deductions"
          onPrimary={() => {
            setFinaleDismissed(true);
            onBack();
          }}
          secondaryLabel="Stay on this case"
          onSecondary={() => setFinaleDismissed(true)}
        />
      )}
    </div>
  );
}

/* ---------------------------------------------------------------- */

/** The invoice as one bar: what arrived, and what was withheld. */
function PaymentSplitBar({
  assessment,
}: {
  assessment: NonNullable<ReturnType<typeof fundClaimAssessment>>;
}) {
  const c = assessment.case;
  const paidPct = (c.amountPaid / c.invoiceAmount) * 100;
  const mounted = useMounted();
  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-3 flex items-baseline justify-between gap-3">
        <h4 className="text-sm font-semibold">Payment against invoice</h4>
        <span className="whitespace-nowrap text-xs text-muted-foreground">
          {c.remittanceId} · {c.receivedDate}
        </span>
      </div>
      <div className="flex h-12 w-full overflow-hidden rounded-lg border-2">
        <div
          className="flex items-center justify-center bg-[var(--success)]/25 transition-all duration-700 ease-out motion-reduce:transition-none"
          style={{ width: mounted ? `${paidPct}%` : "0%" }}
        >
          <span className="text-sm font-semibold text-green-800 tabular-nums">
            {formatUsd(c.amountPaid)} paid
          </span>
        </div>
        <div
          className="flex flex-1 items-center justify-center transition-all duration-500 ease-out motion-reduce:transition-none"
          style={{
            opacity: mounted ? 1 : 0,
            transitionDelay: "600ms",
            backgroundImage:
              "repeating-linear-gradient(45deg, rgba(217,119,6,0.20) 0 6px, transparent 6px 12px)",
          }}
        >
          <span className="whitespace-nowrap px-1 text-xs font-semibold text-amber-700 tabular-nums">
            {formatUsd(assessment.claimed)}
          </span>
        </div>
      </div>
      <p className="mt-2 text-xs text-muted-foreground">
        Invoice {formatUsd(c.invoiceAmount)} less {formatUsd(assessment.claimed)}{" "}
        withheld equals {formatUsd(c.amountPaid)} paid. The withheld amount is a
        valid promotion claim, not a dispute.
      </p>
      <p className="mt-3 rounded border-l-2 border-muted-foreground/40 bg-muted/30 px-3 py-2 text-xs italic text-muted-foreground">
        &ldquo;{c.customerNote}&rdquo; — remittance note
      </p>
    </div>
  );
}

/** The two overlapping events the claim actually spans. */
function EventsCard({
  assessment,
  caseId,
}: {
  assessment: NonNullable<ReturnType<typeof fundClaimAssessment>>;
  caseId: string;
}) {
  const c = assessment.case;
  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-3 flex items-baseline justify-between gap-3">
        <h4 className="text-sm font-semibold">Promotion events behind the claim</h4>
        <span className="whitespace-nowrap text-xs text-muted-foreground">
          {c.events.length} overlapping events
        </span>
      </div>

      <EventTimeline assessment={assessment} caseId={caseId} />

      <div className="mt-3 flex flex-wrap gap-2 border-t pt-3">
        <SourceDocTrigger
          doc={buildFundDeductionDoc(caseId)}
          label="View the claim"
        />
      </div>
    </div>
  );
}

const DAY_MS = 86_400_000;
const toDay = (iso: string) => Math.round(Date.parse(iso) / DAY_MS);
const shortDate = (iso: string) =>
  new Date(iso).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    timeZone: "UTC",
  });

/** Both events on one date axis, so the overlap reads at a glance. */
function EventTimeline({
  assessment,
  caseId,
}: {
  assessment: NonNullable<ReturnType<typeof fundClaimAssessment>>;
  caseId: string;
}) {
  const c = assessment.case;
  const starts = c.events.map((e) => toDay(e.periodStart));
  const ends = c.events.map((e) => toDay(e.periodEnd));
  const min = Math.min(...starts);
  const max = Math.max(...ends);
  const span = Math.max(max - min, 1);
  const pct = (d: number) => ((d - min) / span) * 100;

  const overlapStart = Math.max(...starts);
  const overlapEnd = Math.min(...ends);
  const hasOverlap = overlapEnd > overlapStart;
  const overlapDays = hasOverlap ? overlapEnd - overlapStart : 0;
  const minIso = new Date(min * DAY_MS).toISOString();
  const maxIso = new Date(max * DAY_MS).toISOString();

  return (
    <div className="flex flex-col gap-2">
      {c.events.map((e) => {
        const referenced = e.eventId === c.referencedEventId;
        const left = pct(toDay(e.periodStart));
        const width = pct(toDay(e.periodEnd)) - left;
        return (
          <SourceDocRowTrigger key={e.eventId} doc={buildEventDoc(caseId, e.eventId)}>
            <div className="grid grid-cols-[minmax(0,11rem)_1fr_auto] items-center gap-3 rounded-md px-2 py-2 hover:bg-muted/40">
              <div className="min-w-0">
                <div className="truncate text-sm font-medium">{e.name}</div>
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <span
                    aria-hidden
                    className={cn(
                      "size-1.5 shrink-0 rounded-full",
                      referenced ? "bg-[var(--success)]" : "bg-destructive"
                    )}
                  />
                  <span className="truncate">
                    {referenced ? "Referenced" : "Not referenced"} · {e.mechanic}
                  </span>
                </div>
              </div>

              <div className="relative h-6">
                {hasOverlap && (
                  <div
                    aria-hidden
                    className="absolute inset-y-0 bg-foreground/[0.06]"
                    style={{
                      left: `${pct(overlapStart)}%`,
                      width: `${pct(overlapEnd) - pct(overlapStart)}%`,
                    }}
                  />
                )}
                <div
                  className={cn(
                    "absolute top-1/2 h-2.5 -translate-y-1/2 rounded-full",
                    referenced ? "bg-[var(--success)]" : "bg-destructive/70"
                  )}
                  style={{ left: `${left}%`, width: `${width}%` }}
                  title={`${e.periodStart} → ${e.periodEnd}`}
                />
              </div>

              <span className="text-right text-sm font-semibold tabular-nums">
                {formatUsd(e.accrued)}
              </span>
            </div>
          </SourceDocRowTrigger>
        );
      })}

      <div className="grid grid-cols-[minmax(0,11rem)_1fr_auto] gap-3 px-2 text-[11px] text-muted-foreground">
        <span />
        <div className="relative h-4">
          <span className="absolute left-0">{shortDate(minIso)}</span>
          {hasOverlap && (
            <span
              className="absolute -translate-x-1/2 whitespace-nowrap font-medium text-foreground"
              style={{ left: `${(pct(overlapStart) + pct(overlapEnd)) / 2}%` }}
            >
              {overlapDays}-day overlap
            </span>
          )}
          <span className="absolute right-0">{shortDate(maxIso)}</span>
        </div>
        <span className="invisible text-sm font-semibold tabular-nums">
          {formatUsd(Math.max(...c.events.map((e) => e.accrued)))}
        </span>
      </div>
    </div>
  );
}

/** Signature card: the two funds as a checkbook, available vs demand. */
function CheckbookCard({
  assessment,
  caseId,
}: {
  assessment: NonNullable<ReturnType<typeof fundClaimAssessment>>;
  caseId: string;
}) {
  const c = assessment.case;
  const [animateIn, setAnimateIn] = useState(false);

  useEffect(() => {
    const id = requestAnimationFrame(() => setAnimateIn(true));
    return () => cancelAnimationFrame(id);
  }, []);

  const scale = Math.max(
    assessment.claimed,
    ...assessment.fundsAfter.map((f) => f.availableBefore)
  );
  const claimPct = (assessment.claimed / scale) * 100;

  return (
    <div className="flex flex-col gap-4 rounded-xl border bg-card p-4">
      <div className="flex items-baseline justify-between gap-3">
        <h4 className="text-sm font-semibold">
          {formatUsd(assessment.claimed)} claimed against the checkbook
        </h4>
        <span className="inline-flex items-center gap-1.5 whitespace-nowrap text-xs text-muted-foreground">
          <SystemMark name={c.funds[0].tpmSystem} />
          {c.funds[0].fiscalYear}
        </span>
      </div>

      <ul className="flex flex-col gap-3">
        {assessment.fundsAfter.map((f, index) => {
          const referenced = f.fund.fundId === c.referencedFundId;
          const short = referenced && f.availableBefore < assessment.claimed;
          const availPct = (f.availableBefore / scale) * 100;
          return (
            <li key={f.fund.fundId}>
              <SourceDocRowTrigger
                doc={buildFundDoc(caseId, f.fund.fundId)}
                className="flex w-full flex-col gap-1.5 rounded-md p-1 text-left hover:bg-muted/40"
              >
                <div className="flex items-center justify-between gap-2 text-sm">
                  <span className="flex min-w-0 items-center gap-2" title={f.fund.note}>
                    <span className="truncate font-medium">{f.fund.name}</span>
                    {referenced && (
                      <Badge variant="outline" className="text-[10px]">
                        referenced
                      </Badge>
                    )}
                  </span>
                  <span className="tabular-nums text-muted-foreground">
                    {formatUsd(f.availableBefore)} available
                  </span>
                </div>
                <div className="relative h-3 w-full rounded-full bg-muted">
                  <div
                    className={cn(
                      "absolute inset-y-0 left-0 rounded-full transition-[width] duration-700 ease-out",
                      short ? "bg-amber-400" : "bg-[var(--success)]/70"
                    )}
                    style={{
                      width: animateIn ? `${availPct}%` : "0%",
                      transitionDelay: `${index * 200}ms`,
                    }}
                  />
                  {referenced && (
                    <span
                      aria-hidden
                      className="absolute -inset-y-1 w-0.5 bg-foreground"
                      style={{ left: `calc(${claimPct}% - 1px)` }}
                    />
                  )}
                </div>
                {short && (
                  <span className="text-xs font-medium text-amber-700">
                    {formatUsd(assessment.overflow)} short of the claim
                  </span>
                )}
              </SourceDocRowTrigger>
            </li>
          );
        })}
      </ul>

      <div className="border-t pt-3">
        <SourceDocTrigger doc={buildFundCheckbookDoc(caseId)} label="View the checkbook" />
      </div>
    </div>
  );
}

/** The proposed split across funds, and the reconciliation to the claim. */
function AllocationCard({
  assessment,
  caseId,
}: {
  assessment: NonNullable<ReturnType<typeof fundClaimAssessment>>;
  caseId: string;
}) {
  const a = assessment;
  const [grown, setGrown] = useState(false);
  useEffect(() => {
    const id = setTimeout(() => setGrown(true), 150);
    return () => clearTimeout(id);
  }, []);
  const fill = (ref: boolean) => (ref ? "bg-primary" : "bg-[var(--success)]");

  return (
    <div className="flex flex-col gap-4 rounded-xl border bg-card p-4">
      <div className="flex items-baseline justify-between gap-3">
        <h4 className="text-sm font-semibold">Proposed allocation</h4>
        <span
          className={cn(
            "text-xs font-medium",
            a.reconciles ? "text-[var(--success)]" : "text-red-700"
          )}
        >
          {a.reconciles ? "Reconciles to the claim · no overspend" : "Does not reconcile"}
        </span>
      </div>

      <div className="flex h-10 w-full gap-0.5 overflow-hidden rounded-md bg-muted">
        {a.allocations.map((al, i) => (
          <div
            key={al.allocationId}
            className={cn(
              "flex h-full items-center overflow-hidden whitespace-nowrap px-3 text-xs font-medium text-primary-foreground transition-all duration-700 ease-out",
              fill(al.isReferenced)
            )}
            style={{
              width: grown ? `${(al.allocated / a.claimed) * 100}%` : "0%",
              transitionDelay: `${i * 250}ms`,
            }}
          >
            {formatUsd(al.allocated)}
          </div>
        ))}
      </div>

      <ul className="flex flex-col">
        {a.allocations.map((al) => (
          <li key={al.allocationId} className="border-t first:border-t-0">
            <SourceDocRowTrigger
              doc={buildAllocationLineDoc(caseId, al.allocationId)}
              className="flex w-full items-center gap-2 rounded px-1 py-2 text-left text-sm hover:bg-muted/40"
            >
              <span className={cn("h-2.5 w-2.5 shrink-0 rounded-[2px]", fill(al.isReferenced))} />
              <span className="min-w-0 flex-1 truncate" title={al.note}>
                {al.fundName}
              </span>
              <span className="text-xs text-muted-foreground">
                {al.isReferenced ? "Referenced" : "Reallocated"}
              </span>
              <span className="w-24 text-right font-medium tabular-nums">
                {formatUsd(al.allocated)}
              </span>
            </SourceDocRowTrigger>
          </li>
        ))}
      </ul>

      {a.budgetExceptionValue > 0 && (
        <p className="text-xs text-amber-700">
          {formatUsd(a.budgetExceptionValue)} needs a budget exception approval.
        </p>
      )}

      <div className="flex flex-wrap gap-2 border-t pt-3">
        <SourceDocTrigger doc={buildAllocationDoc(caseId)} label="View the allocation" />
      </div>
    </div>
  );
}

/** The four downstream records the settlement reconciles. */
function ControlsCard({
  assessment,
  caseId,
}: {
  assessment: NonNullable<ReturnType<typeof fundClaimAssessment>>;
  caseId: string;
}) {
  const c = assessment.case;
  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-3 flex items-baseline justify-between gap-3">
        <h4 className="text-sm font-semibold">Post-settlement controls</h4>
        <span className="whitespace-nowrap text-xs text-muted-foreground">
          {c.controls.length} records reconciled
        </span>
      </div>

      <div className="space-y-2">
        {c.controls.map((ctrl) => (
          <SourceDocRowTrigger
            key={ctrl.controlId}
            doc={buildControlLineDoc(caseId, ctrl.controlId)}
          >
            <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border-2 border-[var(--success)]/40 bg-[var(--success)]/5 p-3">
              <span className="flex items-center gap-2 text-sm font-medium">
                <CircleCheck className="h-4 w-4 shrink-0 text-[var(--success)]" />
                {ctrl.label}
                <span className="inline-flex items-center gap-1 text-xs font-normal text-muted-foreground">
                  · <SystemMark name={ctrl.system} />
                  {ctrl.system}
                </span>
              </span>
              <span className="text-sm font-bold tabular-nums text-[var(--success)]">
                {formatUsd(ctrl.expected)}
              </span>
            </div>
          </SourceDocRowTrigger>
        ))}
      </div>

      <div className="mt-3 flex flex-wrap gap-2 border-t pt-3">
        <SourceDocTrigger
          doc={buildControlsDoc(caseId)}
          label="View the controls"
        />
        <SourceDocTrigger
          doc={buildAllocationDoc(caseId)}
          label="View the allocation"
        />
      </div>
    </div>
  );
}
