"use client";

import { useEffect, useRef, useState } from "react";
import { Spinner } from "@/components/agents/spinner";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { AgentIcon } from "@/components/agents/agent-icon";
import {
  ArrowLeft,
  CircleCheck,
  ClipboardCheck,
  Clock,
  FilePenLine,
  FileSearch,
  FileText,
  Mail,
  MessageCircle,
  Receipt,
  Send,
  ThumbsUp,
  Truck,
  X,
  type LucideIcon,
} from "lucide-react";

import { OrderInvoiceTieout } from "@/components/mounts/billing/order-invoice-tieout";
import { RevenueRecognitionTab } from "@/components/mounts/billing/revenue-recognition-tab";
import { BillingStagePanel } from "@/components/mounts/billing/stage-panels";
import { BillingDisputeRun } from "@/components/views/billing-dispute-run";
import { OwnerChip } from "@/components/shared/owner-chip";
import { billingDisputeCases } from "@/lib/data/billing-disputes";
import { billingDispute } from "@/lib/billing-dispute-selectors";
import { formatUsd as formatUsdPlain } from "@/lib/format";
import { useOtcStore } from "@/lib/store";
import { AlertTriangle } from "lucide-react";

interface BillingStage {
  id: string;
  label: string;
  icon: LucideIcon;
}

interface BillingItem {
  billingId: string;
  orderId: string;
  customerName: string;
  amount: number;
  status: string;
  deliveryValidated: boolean;
  poValidated: boolean;
  contractValidated: boolean;
  documentsComplete: boolean;
  invoiceGenerated: boolean;
  invoiceDelivered: boolean;
}

interface BillingLog {
  timestamp: string;
  message: string;
  type: string;
}

interface ChatMessage {
  role: "user" | "agent";
  text: string;
  isApproval?: boolean;
}

interface ChatState {
  open: boolean;
  messages: ChatMessage[];
  input: string;
}

const BILLING_STAGES: BillingStage[] = [
  { id: "capture", label: "Capture", icon: FileText },
  { id: "delivery_validation", label: "Delivery Validation", icon: Truck },
  { id: "po_validation", label: "PO Validation", icon: ClipboardCheck },
  { id: "contract_validation", label: "Contract Validation", icon: FilePenLine },
  { id: "document_check", label: "Document Check", icon: FileSearch },
  { id: "billing_generation", label: "Billing Generation", icon: Receipt },
  { id: "invoice_delivery", label: "Invoice Delivery", icon: Mail },
  { id: "completed", label: "Completed", icon: CircleCheck },
];

const BILLING_ITEMS: BillingItem[] = [
  {
    billingId: "BIL-001",
    orderId: "SO-710270",
    customerName: "Walmart Inc.",
    amount: 125000,
    status: "capture",
    deliveryValidated: false,
    poValidated: false,
    contractValidated: false,
    documentsComplete: false,
    invoiceGenerated: false,
    invoiceDelivered: false,
  },
  {
    billingId: "BIL-002",
    orderId: "SO-710271",
    customerName: "Tesco PLC",
    amount: 340000,
    status: "delivery_validation",
    deliveryValidated: false,
    poValidated: false,
    contractValidated: false,
    documentsComplete: false,
    invoiceGenerated: false,
    invoiceDelivered: false,
  },
  {
    billingId: "BIL-003",
    orderId: "SO-710272",
    customerName: "Woolworths Group",
    amount: 275000,
    status: "po_validation",
    deliveryValidated: true,
    poValidated: false,
    contractValidated: false,
    documentsComplete: false,
    invoiceGenerated: false,
    invoiceDelivered: false,
  },
];

export function BillingView() {
  const { allInvoices, resolvedBillingDisputes, pendingCaseId, consumePendingCase } = useOtcStore();
  const [selectedId, setSelectedId] = useState("");
  const [holdCaseId, setHoldCaseId] = useState<string | null>(() =>
    pendingCaseId && billingDisputeCases.some((c) => c.caseId === pendingCaseId)
      ? pendingCaseId
      : null
  );
  useEffect(() => {
    if (pendingCaseId && billingDisputeCases.some((c) => c.caseId === pendingCaseId)) {
      setHoldCaseId(pendingCaseId);
      consumePendingCase();
    }
  }, [pendingCaseId, consumePendingCase]);
  const [activeTab, setActiveTab] = useState<"pipeline" | "revrec">("pipeline");
  const [items, setItems] = useState<BillingItem[]>(BILLING_ITEMS);
  const [currentItem, setCurrentItem] = useState<BillingItem | null>(null);
  const [currentStep, setCurrentStep] = useState(0);
  /** Stage panel opened from a pipeline card's stage chips (one at a time). */
  const [openPanel, setOpenPanel] = useState<{
    billingId: string;
    stageId: string;
  } | null>(null);
  const [logs, setLogs] = useState<BillingLog[]>([]);
  const [chat, setChat] = useState<ChatState>({
    open: false,
    messages: [],
    input: "",
  });
  const logRef = useRef<HTMLDivElement>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (logRef.current) {
      logRef.current.scrollTop = logRef.current.scrollHeight;
    }
  }, [logs]);

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [chat.messages]);

  const sendChatMessage = () => {
    const text = chat.input.trim();
    if (!text) return;
    const nextMessages: ChatMessage[] = [
      ...chat.messages,
      { role: "user", text },
    ];
    setChat((prev) => ({ ...prev, messages: nextMessages, input: "" }));
    const lower = text.toLowerCase();
    setTimeout(() => {
      let reply = "";
      let isApproval = false;
      const stageLabel = BILLING_STAGES[currentStep]?.label || "unknown";
      if (
        lower.includes("approve") ||
        lower.includes("confirm") ||
        lower.includes("proceed")
      ) {
        reply = `Billing for ${currentItem?.orderId || "this order"} has been approved. Continuing pipeline.`;
        isApproval = true;
      } else if (
        lower.includes("status") ||
        lower.includes("where") ||
        lower.includes("stage")
      ) {
        reply = `${currentItem?.orderId || "Order"} is currently at: ${stageLabel} (step ${currentStep + 1} of ${BILLING_STAGES.length}).`;
      } else if (lower.match(/so-\d+/i)) {
        const match = text.match(/SO-\d+/i);
        const matchedId = match ? match[0].toUpperCase() : "";
        const found = items.find((item) => item.orderId === matchedId);
        reply = found
          ? `${matchedId} is at billing stage: ${found.status}.`
          : `${matchedId} is not in the billing pipeline.`;
      } else {
        reply = `Billing agent monitoring ${currentItem?.orderId || "this order"}. Current stage: ${stageLabel}. Type 'approve' to confirm or ask about a specific order.`;
      }
      setChat((prev) => ({
        ...prev,
        messages: [...prev.messages, { role: "agent", text: reply, isApproval }],
      }));
    }, 600);
  };

  const stageIndex = (stageId: string) =>
    BILLING_STAGES.findIndex((stage) => stage.id === stageId);

  const addLog = (message: string, type = "info") => {
    setLogs((prev) => [
      ...prev,
      { timestamp: new Date().toISOString(), message, type },
    ]);
  };

  /** The real invoice issued for the order being processed, if any. */
  const issuedForCurrent = currentItem
    ? allInvoices.find((inv) => inv.orderId === currentItem.orderId)
    : undefined;
  /** True while the run is stopped at Billing Generation waiting for a human. */
  const pausedForApproval = Boolean(
    currentItem &&
      BILLING_STAGES[currentStep]?.id === "billing_generation" &&
      !currentItem.invoiceGenerated &&
      !issuedForCurrent
  );

  useEffect(() => {
    if (!currentItem) return;
    // Human-in-the-loop gate: the run STOPS at Billing Generation. The AI has
    // only drafted the invoice — nothing advances until a person clicks
    // "Approve & issue invoice", which creates the real invoice in the store.
    if (
      BILLING_STAGES[currentStep]?.id === "billing_generation" &&
      !currentItem.invoiceGenerated
    ) {
      if (!issuedForCurrent) return; // paused — waiting for approval
      const updated: BillingItem = { ...currentItem, invoiceGenerated: true };
      addLog(
        `Billing Generation Agent: Invoice ${issuedForCurrent.invoiceId} issued with your approval`,
        "success"
      );
      setCurrentItem(updated);
      setItems((prev) =>
        prev.map((item) =>
          item.billingId === updated.billingId ? updated : item
        )
      );
      return;
    }
    (async () => {
      if (currentStep >= BILLING_STAGES.length - 1) {
        addLog("Billing process completed successfully", "success");
        setTimeout(() => {
          setItems((prev) =>
            prev.map((item) =>
              item.billingId === currentItem.billingId
                ? { ...item, status: "completed" }
                : item
            )
          );
          setCurrentItem(null);
          setSelectedId("");
        }, 2000);
        return;
      }
      await new Promise((resolve) => setTimeout(resolve, 3000));
      const nextStage = BILLING_STAGES[currentStep + 1];
      const updated: BillingItem = { ...currentItem, status: nextStage.id };
      switch (nextStage.id) {
        case "delivery_validation":
          updated.deliveryValidated = true;
          addLog("Report Extraction Agent: Delivery validated against SO", "success");
          break;
        case "po_validation":
          updated.poValidated = true;
          addLog("PO Validation Agent: All PO conditions met", "success");
          break;
        case "contract_validation":
          updated.contractValidated = true;
          addLog("Contract Validation Agent: Pricing and terms verified", "success");
          break;
        case "document_check":
          updated.documentsComplete = true;
          addLog("Document Extraction Agent: All critical documents available", "success");
          break;
        case "billing_generation":
          // Do NOT mark the invoice generated — the AI only drafts it here.
          // The run pauses at this stage until a human approves and issues.
          addLog(
            "Billing Generation Agent: Draft invoice prepared from the tie-out — waiting for your approval",
            "info"
          );
          break;
        case "invoice_delivery":
          updated.invoiceDelivered = true;
          addLog("Invoice Delivery Agent: Invoice delivered via preferred channel", "success");
      }
      setCurrentItem(updated);
      setItems((prev) =>
        prev.map((item) =>
          item.billingId === updated.billingId ? updated : item
        )
      );
      setCurrentStep((prev) => prev + 1);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentStep, currentItem, issuedForCurrent]);

  return holdCaseId ? (
    <BillingDisputeRun caseId={holdCaseId} onBack={() => setHoldCaseId(null)} />
  ) : selectedId && currentItem ? (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            setSelectedId("");
            setCurrentItem(null);
          }}
          className="gap-1.5"
        >
          <ArrowLeft className="h-4 w-4" /> Back to Pipeline
        </Button>
        <div className="flex items-center gap-3">
          <span className="font-semibold text-base">{currentItem.orderId}</span>
          <span className="text-sm text-muted-foreground">
            {currentItem.customerName} · ${currentItem.amount.toLocaleString()}
          </span>
        </div>
      </div>
      <Card className="p-4">
        <div className="flex items-center justify-between mb-3">
          {BILLING_STAGES.map((stage, index) => {
            const StageIcon = stage.icon;
            const isActive = index === currentStep;
            const isDone = index < currentStep;
            const isUpcoming = index > currentStep;
            return (
              <div key={stage.id} className="flex items-center flex-1">
                <div className="flex flex-col items-center gap-2">
                  <div
                    className={[
                      "w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all",
                      isDone ? "bg-green-500 border-green-500 text-white" : "",
                      isActive
                        ? pausedForApproval
                          ? "bg-amber-500 border-amber-500 text-white"
                          : "bg-blue-500 border-blue-500 text-white animate-pulse"
                        : "",
                      isUpcoming ? "bg-gray-200 border-gray-300 text-gray-500" : "",
                    ].join(" ")}
                  >
                    {isActive && !pausedForApproval ? (
                      <Spinner size="md" />
                    ) : (
                      <StageIcon className="w-5 h-5" />
                    )}
                  </div>
                  <span
                    className={[
                      "text-xs font-medium text-center max-w-[80px]",
                      isActive
                        ? pausedForApproval
                          ? "text-amber-600"
                          : "text-blue-600"
                        : isDone
                          ? "text-green-600"
                          : "text-gray-500",
                    ].join(" ")}
                  >
                    {stage.label}
                  </span>
                </div>
                {index < BILLING_STAGES.length - 1 && (
                  <div
                    className={[
                      "flex-1 h-0.5 mx-2",
                      isDone ? "bg-green-500" : "bg-gray-300",
                    ].join(" ")}
                  />
                )}
              </div>
            );
          })}
        </div>
        <Progress
          value={(currentStep / (BILLING_STAGES.length - 1)) * 100}
          className="h-2"
        />
      </Card>
      <div className="grid lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-4">
          {currentStep >= 1 && (
            <Card className="p-6">
              <div className="flex items-start gap-4">
                <AgentIcon type="extraction" size="lg" />
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-foreground">
                      Report Extraction Agent
                    </h3>
                    {currentItem.deliveryValidated ? (
                      <Badge
                        variant="outline"
                        className="bg-green-50 text-green-700 border-green-300"
                      >
                        <CircleCheck className="w-3 h-3 mr-1" />
                        Passed
                      </Badge>
                    ) : (
                      <Badge
                        variant="outline"
                        className="bg-blue-50 text-blue-700 border-blue-300"
                      >
                        <Spinner size="sm" className="mr-1" />
                        Running
                      </Badge>
                    )}
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <CircleCheck className="w-4 h-4 text-green-600" />
                      <span>Proof of Delivery extracted</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CircleCheck className="w-4 h-4 text-green-600" />
                      <span>SO vs Delivered Order matched</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CircleCheck className="w-4 h-4 text-green-600" />
                      <span>Product codes and quantities validated</span>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          )}
          {currentStep >= 2 && (
            <Card className="p-6">
              <div className="flex items-start gap-4">
                <AgentIcon type="po" size="lg" />
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-foreground">
                      PO Validation Agent
                    </h3>
                    {currentItem.poValidated ? (
                      <Badge
                        variant="outline"
                        className="bg-green-50 text-green-700 border-green-300"
                      >
                        <CircleCheck className="w-3 h-3 mr-1" />
                        Passed
                      </Badge>
                    ) : (
                      <Badge
                        variant="outline"
                        className="bg-blue-50 text-blue-700 border-blue-300"
                      >
                        <Spinner size="sm" className="mr-1" />
                        Running
                      </Badge>
                    )}
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="flex items-center gap-2">
                      <CircleCheck className="w-4 h-4 text-green-600" />
                      <span>Customer details verified</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CircleCheck className="w-4 h-4 text-green-600" />
                      <span>Bill-to / Ship-to validated</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CircleCheck className="w-4 h-4 text-green-600" />
                      <span>Product inclusion checked</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CircleCheck className="w-4 h-4 text-green-600" />
                      <span>Quantity and unit price matched</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CircleCheck className="w-4 h-4 text-green-600" />
                      <span>Tax % validated</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CircleCheck className="w-4 h-4 text-green-600" />
                      <span>Payment terms confirmed</span>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          )}
          {currentStep >= 3 && (
            <Card className="p-6">
              <div className="flex items-start gap-4">
                <AgentIcon type="contract" size="lg" />
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-foreground">
                      Contract Validation Agent
                    </h3>
                    {currentItem.contractValidated ? (
                      <Badge
                        variant="outline"
                        className="bg-green-50 text-green-700 border-green-300"
                      >
                        <CircleCheck className="w-3 h-3 mr-1" />
                        Passed
                      </Badge>
                    ) : (
                      <Badge
                        variant="outline"
                        className="bg-blue-50 text-blue-700 border-blue-300"
                      >
                        <Spinner size="sm" className="mr-1" />
                        Running
                      </Badge>
                    )}
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <CircleCheck className="w-4 h-4 text-green-600" />
                      <span>Pricing elements validated</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CircleCheck className="w-4 h-4 text-green-600" />
                      <span>Discounts applied (promotions, rebates)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CircleCheck className="w-4 h-4 text-green-600" />
                      <span>Contract validity confirmed</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CircleCheck className="w-4 h-4 text-green-600" />
                      <span>SO rates match contract terms</span>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          )}
          {currentStep >= 4 && (
            <Card className="p-6">
              <div className="flex items-start gap-4">
                <AgentIcon type="document" size="lg" />
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-foreground">
                      Document Extraction Agent
                    </h3>
                    {currentItem.documentsComplete ? (
                      <Badge
                        variant="outline"
                        className="bg-green-50 text-green-700 border-green-300"
                      >
                        <CircleCheck className="w-3 h-3 mr-1" />
                        Complete
                      </Badge>
                    ) : (
                      <Badge
                        variant="outline"
                        className="bg-blue-50 text-blue-700 border-blue-300"
                      >
                        <Spinner size="sm" className="mr-1" />
                        Checking
                      </Badge>
                    )}
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <CircleCheck className="w-4 h-4 text-green-600" />
                      <span>Purchase Order</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CircleCheck className="w-4 h-4 text-green-600" />
                      <span>Proof of Delivery</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CircleCheck className="w-4 h-4 text-green-600" />
                      <span>Exception Approvals</span>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          )}
          {currentStep >= 5 && (
            <Card className="p-6">
              <div className="flex items-start gap-4">
                <AgentIcon type="invoice" size="lg" />
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-foreground">
                      Billing Generation Agent
                    </h3>
                    {currentItem.invoiceGenerated ? (
                      <Badge
                        variant="outline"
                        className="bg-green-50 text-green-700 border-green-300"
                      >
                        <CircleCheck className="w-3 h-3 mr-1" />
                        Issued with your approval
                      </Badge>
                    ) : (
                      <Badge
                        variant="outline"
                        className="bg-amber-50 text-amber-700 border-amber-300"
                      >
                        <Clock className="w-3 h-3 mr-1" />
                        Awaiting your approval
                      </Badge>
                    )}
                  </div>
                  <BillingStagePanel
                    stageId="billing_generation"
                    orderId={currentItem.orderId}
                    isCurrentStage
                  />
                </div>
              </div>
            </Card>
          )}
          {currentStep >= 6 && (
            <Card className="p-6">
              <div className="flex items-start gap-4">
                <AgentIcon type="delivery" size="lg" />
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-foreground">
                      Invoice Delivery Agent
                    </h3>
                    {currentItem.invoiceDelivered ? (
                      <Badge
                        variant="outline"
                        className="bg-green-50 text-green-700 border-green-300"
                      >
                        <CircleCheck className="w-3 h-3 mr-1" />
                        Delivered
                      </Badge>
                    ) : (
                      <Badge
                        variant="outline"
                        className="bg-blue-50 text-blue-700 border-blue-300"
                      >
                        <Spinner size="sm" className="mr-1" />
                        Delivering
                      </Badge>
                    )}
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <CircleCheck className="w-4 h-4 text-green-600" />
                      <span>Preferred delivery channel identified</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CircleCheck className="w-4 h-4 text-green-600" />
                      <span>Invoice uploaded to customer portal</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CircleCheck className="w-4 h-4 text-green-600" />
                      <span>Supporting documents attached</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CircleCheck className="w-4 h-4 text-green-600" />
                      <span>Email notification sent</span>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          )}
        </div>
        <div className="lg:col-span-1">
          <Card>
            <div className="p-4 pb-2 border-b">
              <h3 className="font-semibold text-sm flex items-center gap-2">
                <Clock className="w-4 h-4 text-muted-foreground" />
                AI Agent Audit Trail
              </h3>
              <p className="text-xs text-muted-foreground mt-0.5">
                Real-time billing orchestration log
              </p>
            </div>
            <div
              ref={logRef}
              className="max-h-[600px] overflow-y-auto p-3 space-y-2"
            >
              {logs.length === 0 && (
                <p className="text-xs text-muted-foreground italic">
                  Waiting for processing to begin...
                </p>
              )}
              {logs.map((log, index) => (
                <div
                  key={index}
                  className="text-xs border-l-2 border-blue-400 pl-3 py-1 animate-in fade-in slide-in-from-bottom-2 duration-300"
                >
                  <div className="text-muted-foreground text-[10px]">
                    {new Date(log.timestamp).toLocaleTimeString()}
                  </div>
                  <div
                    className={
                      log.type === "success"
                        ? "text-[var(--success)] font-medium"
                        : "text-foreground"
                    }
                  >
                    {log.message}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
      <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-2">
        {chat.open && (
          <div
            className="w-80 rounded-xl shadow-2xl border border-border bg-background flex flex-col overflow-hidden"
            style={{ height: "400px" }}
          >
            <div className="flex items-center justify-between px-4 py-3 bg-gradient-to-r from-primary to-primary/80 text-primary-foreground">
              <span className="text-sm font-semibold">Billing Agent</span>
              <button
                onClick={() => setChat((prev) => ({ ...prev, open: false }))}
                className="opacity-70 hover:opacity-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-3 space-y-2">
              {chat.messages.length === 0 && (
                <p className="text-xs text-muted-foreground italic text-center mt-4">
                  Ask about billing status or type &apos;approve&apos; to confirm a
                  step.
                </p>
              )}
              {chat.messages.map((message, index) => (
                <div
                  key={index}
                  className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[85%] rounded-lg px-3 py-2 text-xs ${message.role === "user" ? "bg-primary text-primary-foreground" : message.isApproval ? "bg-green-50 border border-green-200 text-green-800" : "bg-muted text-foreground"}`}
                  >
                    {message.isApproval && (
                      <ThumbsUp className="h-3 w-3 inline mr-1 text-green-600" />
                    )}
                    {message.text}
                  </div>
                </div>
              ))}
              <div ref={chatEndRef} />
            </div>
            <div className="flex items-center gap-2 px-3 py-2 border-t">
              <Input
                value={chat.input}
                onChange={(e) =>
                  setChat((prev) => ({ ...prev, input: e.target.value }))
                }
                onKeyDown={(e) => {
                  if (e.key !== "Enter" || e.nativeEvent.isComposing || e.keyCode === 229) return;
                  sendChatMessage();
                }}
                placeholder="Type order number or 'approve'..."
                className="h-7 text-xs flex-1 bg-muted/40 border-muted"
              />
              <Button
                size="sm"
                variant="ghost"
                onClick={sendChatMessage}
                className="h-7 w-7 p-0 text-muted-foreground hover:text-foreground"
              >
                <Send className="h-3 w-3" />
              </Button>
            </div>
          </div>
        )}
        <button
          onClick={() => setChat((prev) => ({ ...prev, open: !prev.open }))}
          className="h-11 w-11 rounded-full bg-primary text-primary-foreground shadow-lg flex items-center justify-center hover:bg-primary/90 transition-all"
        >
          {chat.open ? (
            <X className="h-5 w-5" />
          ) : (
            <MessageCircle className="h-5 w-5" />
          )}
        </button>
      </div>
    </div>
  ) : (
    <div className="space-y-6">
      <div className="flex gap-2">
        <Button
          variant={activeTab === "pipeline" ? "default" : "outline"}
          onClick={() => setActiveTab("pipeline")}
          className="whitespace-nowrap"
        >
          <AgentIcon type="billing" size="sm" className="mr-2" />
          Billing Pipeline
        </Button>
        <Button
          variant={activeTab === "revrec" ? "default" : "outline"}
          onClick={() => setActiveTab("revrec")}
          className="whitespace-nowrap"
        >
          <AgentIcon type="contract" size="sm" className="mr-2" />
          Revenue Recognition
        </Button>
      </div>
      {activeTab === "revrec" ? (
        <RevenueRecognitionTab />
      ) : (
        <>
      <div>
        <h2 className="text-lg font-bold text-foreground">Billing Pipeline</h2>
        <p className="text-sm text-muted-foreground">
          AI-powered billing orchestration with intelligent validation
        </p>
      </div>
      <div className="space-y-4">
        {billingDisputeCases.map((c) => {
          const f = billingDispute(c.caseId);
          if (!f) return null;
          const isResolved = resolvedBillingDisputes.includes(c.caseId);
          return (
            <Card
              key={c.caseId}
              data-dispute-case={c.caseId}
              className={
                isResolved
                  ? "p-6 border-green-200 bg-green-50/40"
                  : "p-6 border-amber-300 bg-amber-50/60"
              }
            >
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-start gap-3">
                  {isResolved ? (
                    <CircleCheck className="h-5 w-5 text-green-600 mt-0.5 shrink-0" />
                  ) : (
                    <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5 shrink-0" />
                  )}
                  <div className="flex flex-col gap-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="font-semibold text-foreground">{c.orderId}</h3>
                      <Badge
                        variant="outline"
                        className={
                          isResolved
                            ? "bg-green-50 text-green-700 border-green-300"
                            : "bg-amber-100 text-amber-800 border-amber-300"
                        }
                      >
                        {isResolved ? "Dispute resolved" : "Invoice dispute"}
                      </Badge>
                      <OwnerChip account={c.accountId} />
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {c.customerName} · {c.invoiceId} billed {formatUsdPlain(f.invoiceTotal)}
                    </div>
                    <div className={isResolved ? "text-sm text-foreground" : "text-sm text-amber-800"}>
                      {isResolved
                        ? `Charge-back ${formatUsdPlain(f.chargeBack)} · credit note ${formatUsdPlain(f.credit)} · invoice unchanged`
                        : `${formatUsdPlain(f.shortPaid)} short-paid · ${c.caseId}`}
                    </div>
                  </div>
                </div>
                <Button
                  variant={isResolved ? "outline" : "default"}
                  onClick={() => setHoldCaseId(c.caseId)}
                  className={
                    isResolved
                      ? "border-green-300 text-green-700 hover:bg-green-50"
                      : "bg-amber-600 hover:bg-amber-700 text-white"
                  }
                >
                  {isResolved ? (
                    <CircleCheck className="w-4 h-4 mr-2" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 mr-2" />
                  )}
                  {isResolved ? "View resolution" : "Work dispute"}
                </Button>
              </div>
            </Card>
          );
        })}
        {items.map((item) => {
          const itemStageIndex = stageIndex(item.status);
          const progress = ((itemStageIndex + 1) / BILLING_STAGES.length) * 100;
          return (
            <Card key={item.billingId} className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="font-semibold text-foreground">
                      {item.orderId}
                    </h3>
                    <Badge
                      variant="outline"
                      className={
                        item.status === "completed"
                          ? "bg-green-50 text-green-700 border-green-300"
                          : "bg-blue-50 text-blue-700 border-blue-300"
                      }
                    >
                      {item.status === "completed"
                        ? "Completed"
                        : BILLING_STAGES[itemStageIndex]?.label}
                    </Badge>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {item.customerName}
                  </div>
                  <div className="text-sm font-semibold text-foreground">
                    ${item.amount.toLocaleString()}
                  </div>
                </div>
                {item.status !== "completed" && (
                  <Button
                    onClick={() => {
                      const billingId = item.billingId;
                      setChat({ open: false, messages: [], input: "" });
                      const found = items.find(
                        (entry) => entry.billingId === billingId
                      );
                      if (found) {
                        setCurrentItem(found);
                        setSelectedId(billingId);
                        setCurrentStep(stageIndex(found.status));
                        setLogs([
                          {
                            timestamp: new Date().toISOString(),
                            message: `Started billing process for ${found.orderId}`,
                            type: "info",
                          },
                        ]);
                      }
                    }}
                    className="bg-primary"
                  >
                    <FileText className="w-4 h-4 mr-2" />
                    Process
                  </Button>
                )}
              </div>
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs text-muted-foreground mb-1">
                  <span>Progress</span>
                  <span>{Math.round(progress)}%</span>
                </div>
                <Progress value={progress} className="h-2" />
                <div className="flex gap-2 flex-wrap">
                  {BILLING_STAGES.map((stage, index) => {
                    const StageIcon = stage.icon;
                    const isDone = index < itemStageIndex;
                    const isActive = index === itemStageIndex;
                    const isOpen =
                      openPanel?.billingId === item.billingId &&
                      openPanel?.stageId === stage.id;
                    return (
                      <button
                        type="button"
                        key={stage.id}
                        onClick={() =>
                          setOpenPanel((prev) =>
                            prev &&
                            prev.billingId === item.billingId &&
                            prev.stageId === stage.id
                              ? null
                              : { billingId: item.billingId, stageId: stage.id }
                          )
                        }
                        className={[
                          "flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition-all cursor-pointer whitespace-nowrap",
                          isDone
                            ? "bg-green-50 text-green-700 border-green-300"
                            : "",
                          isActive
                            ? "bg-blue-50 text-blue-700 border-blue-300"
                            : "",
                          index > itemStageIndex
                            ? "bg-gray-50 text-gray-500 border-gray-200"
                            : "",
                          isOpen
                            ? "ring-2 ring-primary/40"
                            : isActive
                              ? "ring-2 ring-blue-200"
                              : "",
                        ].join(" ")}
                      >
                        <StageIcon className="w-3.5 h-3.5" />
                        <span>{stage.label}</span>
                        {isDone && <CircleCheck className="w-3.5 h-3.5" />}
                        {isActive && (
                          <Spinner size="sm" />
                        )}
                      </button>
                    );
                  })}
                </div>
                {openPanel?.billingId === item.billingId && (
                  <BillingStagePanel
                    stageId={openPanel.stageId}
                    orderId={item.orderId}
                    isCurrentStage={openPanel.stageId === item.status}
                  />
                )}
              </div>
            </Card>
          );
        })}
      </div>
      <OrderInvoiceTieout />
        </>
      )}
    </div>
  );
}
