"use client";

import type { ViewId } from "@/components/layout/sidebar";
import { CloseChecklist } from "@/components/mounts/close/close-checklist";
import { OtifRiskBoard } from "@/components/mounts/shipments/otif-risk-board";
import { Badge } from "@/components/ui/badge";
import { AnalyticsChat } from "@/components/views/dashboard/analytics-chat";
import { KpiGrid } from "@/components/views/dashboard/kpi-grid";
import { OmKpiCards } from "@/components/views/dashboard/om-kpi-cards";
import { kpis } from "@/lib/data";
import { OM_AS_OF, OM_BASE_ORDERS, OM_PERIOD } from "@/lib/data/om-kpis";
import { formatCount } from "@/lib/format";
import { useOtcStore } from "@/lib/store";

export function DashboardView({
  onNavigate,
}: {
  onNavigate: (view: ViewId, orderId?: string) => void;
}) {
  const { requestNav } = useOtcStore();

  return (
    <div className="flex flex-col gap-4 pb-8">
      <div className="flex flex-wrap items-center gap-2">
        <h1 className="text-lg font-bold text-foreground">OM Command Center</h1>
        <Badge variant="secondary" className="text-xs font-medium">
          {OM_PERIOD} · {formatCount(OM_BASE_ORDERS)} orders
        </Badge>
        <span className="text-xs text-muted-foreground">{OM_AS_OF.label}</span>
      </div>
      <OmKpiCards onNavigate={onNavigate} />
      <OtifRiskBoard onOpen={(caseId) => requestNav({ view: "shipments", caseId })} />
      <h2 className="pt-2 text-sm font-semibold text-foreground">Order-to-cash</h2>
      <KpiGrid data={kpis} />
      <CloseChecklist onNavigate={onNavigate} defaultExpanded={false} />
      <AnalyticsChat onNavigate={onNavigate} />
    </div>
  );
}
