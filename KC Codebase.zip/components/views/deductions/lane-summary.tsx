"use client";

import type { ReactNode } from "react";

import { Card, CardContent } from "@/components/ui/card";
import { CountUp } from "@/components/ui/count-up";
import { ControlTag } from "@/components/shared/control-tag";
import { Tip } from "@/components/shared/floating-tip";
import type { DeductionLane } from "@/lib/store";
import { NON_TRADE_BATCH } from "@/lib/data/non-trade-batch";
import { formatUsd } from "@/lib/format";
import { batchTotals } from "@/lib/non-trade-selectors";
import { cn } from "@/lib/utils";

export interface TradeLaneItem {
  id: string;
  label: string;
  amount: number;
}

const SHADES = ["bg-primary", "bg-primary/75", "bg-primary/55", "bg-primary/35", "bg-primary/20"];

function LaneCard({
  lane,
  active,
  onSelect,
  eyebrow,
  value,
  unit,
  control,
  footnote,
  delay,
  children,
}: {
  lane: DeductionLane;
  active: boolean;
  onSelect: (lane: DeductionLane) => void;
  eyebrow: string;
  value: ReactNode;
  unit: string;
  control: string;
  footnote: string;
  delay: number;
  children: ReactNode;
}) {
  return (
    <Card
      data-lane={lane}
      role="button"
      tabIndex={0}
      aria-pressed={active}
      onClick={() => onSelect(lane)}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onSelect(lane);
        }
      }}
      style={{ animationDelay: `${delay}ms` }}
      className={cn(
        "flex h-full cursor-pointer flex-col bg-card transition-shadow hover:shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
        active && "ring-2 ring-primary/40"
      )}
    >
      <CardContent className="flex flex-1 flex-col gap-3 p-4">
        <div className="flex items-center justify-between gap-2">
          <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{eyebrow}</span>
          <ControlTag controlRef={control} />
        </div>
        <div className="flex items-baseline gap-2">
          <span className="text-2xl font-bold tabular-nums text-foreground">{value}</span>
          <span className="text-xs text-muted-foreground">{unit}</span>
        </div>
        <div className="mt-auto flex flex-col gap-2">
          {children}
          <p className="text-[11px] text-muted-foreground">{footnote}</p>
        </div>
      </CardContent>
    </Card>
  );
}

export function LaneSummary({
  lane,
  onSelect,
  tradeItems,
}: {
  lane: DeductionLane;
  onSelect: (lane: DeductionLane) => void;
  tradeItems: TradeLaneItem[];
}) {
  const tradeTotal = tradeItems.reduce((s, i) => s + i.amount, 0);
  const maxTrade = Math.max(1, ...tradeItems.map((i) => i.amount));
  const cats = NON_TRADE_BATCH.categories;
  const ntTotal = batchTotals.total.count;

  return (
    <div className="grid items-stretch gap-4 md:grid-cols-2">
      <LaneCard
        lane="trade"
        active={lane === "trade"}
        onSelect={onSelect}
        eyebrow="Trade · by value"
        value={<CountUp value={tradeTotal} format={formatUsd} />}
        unit={`open across ${tradeItems.length} claims`}
        control="1.7.3"
        footnote="K-C Q&A: trade promotion spend is about $2.4B a year"
        delay={0}
      >
        <div className="flex flex-col gap-1.5">
          {tradeItems.map((i, idx) => (
            <Tip
              key={i.id}
              content={{ title: i.label, value: formatUsd(i.amount), note: i.id }}
              className="flex items-center gap-2 text-[11px]"
            >
              <span className="w-28 shrink-0 truncate text-muted-foreground">{i.label}</span>
              <span className="h-2 flex-1 overflow-hidden rounded-full bg-muted">
                <span
                  className="grow-x block h-full rounded-full bg-primary"
                  style={{ width: `${(i.amount / maxTrade) * 100}%`, animationDelay: `${idx * 80}ms` }}
                />
              </span>
              <span className="w-16 text-right tabular-nums text-foreground">{formatUsd(i.amount)}</span>
            </Tip>
          ))}
        </div>
      </LaneCard>

      <LaneCard
        lane="non-trade"
        active={lane === "non-trade"}
        onSelect={onSelect}
        eyebrow="Non-trade · by volume"
        value={<CountUp value={ntTotal} />}
        unit={`claims in ${NON_TRADE_BATCH.batchId} · ${formatUsd(batchTotals.total.usd)}`}
        control="1.4.5"
        footnote="K-C Q&A: about 74% of 786K claims by count are non-trade"
        delay={60}
      >
        <div className="flex h-3 w-full overflow-hidden rounded-full bg-muted">
          {cats.map((c, i) => (
            <Tip
              key={c.key}
              content={{ title: c.label, value: `${c.total.count} claims · ${formatUsd(c.total.usd)}` }}
              className={cn("grow-x block h-full transition-opacity hover:opacity-80", SHADES[i])}
              style={{ width: `${(c.total.count / ntTotal) * 100}%`, animationDelay: `${i * 70}ms` }}
            />
          ))}
        </div>
        <div className="flex flex-wrap gap-x-3 gap-y-1 text-[11px] text-muted-foreground">
          {cats.map((c, i) => (
            <span key={c.key} className="flex items-center gap-1">
              <span className={cn("h-2 w-2 rounded-sm", SHADES[i])} aria-hidden />
              {c.label} <span className="tabular-nums text-foreground">{c.total.count}</span>
            </span>
          ))}
        </div>
      </LaneCard>
    </div>
  );
}

export function DeductionLaneTabs({
  lane,
  onSelect,
  tradeCount,
  nonTradeLabel,
}: {
  lane: DeductionLane;
  onSelect: (lane: DeductionLane) => void;
  tradeCount: number;
  nonTradeLabel: string;
}) {
  const tabs: { id: DeductionLane; label: string }[] = [
    { id: "trade", label: `Trade (${tradeCount})` },
    { id: "non-trade", label: `Non-trade (${nonTradeLabel})` },
  ];
  return (
    <div role="tablist" aria-label="Deduction lanes" className="flex gap-6 border-b">
      {tabs.map((t) => (
        <button
          key={t.id}
          type="button"
          role="tab"
          aria-selected={lane === t.id}
          onClick={() => onSelect(t.id)}
          className={cn(
            "relative -mb-px pb-2 text-sm font-medium transition-colors",
            lane === t.id ? "text-primary" : "text-muted-foreground hover:text-foreground"
          )}
        >
          {t.label}
          <span
            className={cn(
              "absolute inset-x-0 -bottom-px h-0.5 origin-left rounded-full bg-primary transition-transform duration-300",
              lane === t.id ? "scale-x-100" : "scale-x-0"
            )}
          />
        </button>
      ))}
    </div>
  );
}
