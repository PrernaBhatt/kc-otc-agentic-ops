"use client";

import { useState, type ReactNode } from "react";
import { BadgeCheck, PackageCheck, ScanSearch, Timer } from "lucide-react";

import type { ViewId } from "@/components/layout/sidebar";
import { DeltaChip, OmKpiDetail, type OmKpiKey } from "@/components/modals/om-kpi-detail";
import { SystemMark } from "@/components/shared/system-badge";
import { Tip } from "@/components/shared/floating-tip";
import { Card, CardContent } from "@/components/ui/card";
import { CountUp } from "@/components/ui/count-up";
import {
  OM_BASE_ORDERS,
  OM_TREND_MONTHS,
  ORDER_TO_INVOICE,
  OTIF,
  PERFECT_ORDER,
  VALIDATION_ACCURACY,
} from "@/lib/data/om-kpis";
import { formatCount } from "@/lib/format";
import { kpiDeltas, orderToInvoiceDays, otifPct, perfectOrder, validationAccuracy } from "@/lib/shipment-selectors";
import { cn } from "@/lib/utils";

type KpiKey = OmKpiKey;

function TargetChip({ met, target }: { met: boolean; target: string }) {
  return (
    <span
      className={cn(
        "whitespace-nowrap rounded-md border px-1.5 py-0.5 text-[11px] font-semibold",
        met ? "border-green-200 bg-green-100 text-green-700" : "border-amber-200 bg-amber-50 text-amber-700"
      )}
    >
      {met ? "On target" : "Below target"} · {target}
    </span>
  );
}

function OmKpiCard({
  kpi,
  icon,
  label,
  value,
  chip,
  delta,
  systems,
  delay,
  onOpen,
  children,
}: {
  kpi: KpiKey;
  icon: ReactNode;
  label: string;
  value: ReactNode;
  chip: ReactNode;
  delta: ReactNode;
  systems: string[];
  delay: number;
  onOpen: () => void;
  children: ReactNode;
}) {
  return (
    <Card
      data-kpi={kpi}
      role="button"
      tabIndex={0}
      onClick={onOpen}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onOpen();
        }
      }}
      className="animate-enter h-full cursor-pointer gap-0 bg-card py-0 transition-shadow hover:shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      style={{ animationDelay: `${delay}ms` }}
    >
      <CardContent className="flex flex-1 flex-col gap-3 p-4">
        <div className="flex items-center justify-between gap-2">
          <span className="flex min-w-0 items-center gap-1.5 truncate text-xs font-medium text-muted-foreground">
            {icon}
            {label}
          </span>
          {delta}
        </div>
        <div className="flex items-center justify-between gap-2">
          <div className="text-2xl font-bold tabular-nums text-foreground">{value}</div>
          {chip}
        </div>
        <div className="flex flex-1 flex-col justify-end">{children}</div>
        <div className="mt-auto flex items-center gap-1.5 border-t pt-2 text-[11px] text-muted-foreground">
          {systems
            .filter((s, i) => !systems.slice(0, i).some((p) => p.split(" ")[0] === s.split(" ")[0]))
            .map((s) => (
              <SystemMark key={s} name={s} />
            ))}
          <span className="truncate">{systems.join(" · ")}</span>
        </div>
      </CardContent>
    </Card>
  );
}

/** Scales a rate into the 80–100% band so small gaps stay visible. */
const band = (pct: number) => Math.max(4, Math.min(100, ((pct - 80) / 20) * 100));

function OtifVisual() {
  const [a, s, d] = OTIF.stages;
  const drops = [
    { label: "Lost at ship", pts: otifPct.A - otifPct.S, orders: a.orders - s.orders, reasons: OTIF.losses.aToS },
    { label: "Lost in transit", pts: otifPct.S - otifPct.D, orders: s.orders - d.orders, reasons: OTIF.losses.sToD },
  ];
  const bars = OTIF.stages.map((st) => ({ ...st, pct: otifPct[st.key] }));
  return (
    <div className="flex items-stretch gap-1" role="img" aria-label="OTIF by stage: available, shipped, delivered">
      {bars.map((bar, i) => (
        <div key={bar.key} className="flex flex-1 items-center gap-1">
          <Tip
            content={{
              title: `${bar.label} · ${bar.pct}%`,
              value: `${formatCount(bar.orders)} of ${formatCount(OM_BASE_ORDERS)} orders`,
              note: bar.definition,
            }}
            className="group flex flex-1 flex-col items-center gap-1"
          >
            <span className="flex h-20 w-full flex-col items-center justify-end gap-1">
              <span className="text-[11px] font-semibold tabular-nums text-foreground">{bar.pct}</span>
              <span
                className={cn(
                  "grow-y block w-full rounded-sm transition-opacity group-hover:opacity-80",
                  bar.key === "D" ? "bg-primary" : "bg-primary/45"
                )}
                style={{ height: `${band(bar.pct)}%`, animationDelay: `${i * 90}ms` }}
              />
            </span>
            <span className="text-[11px] text-muted-foreground group-hover:text-foreground">
              <span className="font-semibold">{bar.key}</span> {bar.label}
            </span>
          </Tip>
          {i < drops.length && (
            <Tip
              content={{
                title: drops[i].label,
                value: `${formatCount(drops[i].orders)} orders`,
                note: drops[i].reasons.map((r) => `${r.label} ${r.orders}`).join(" · "),
              }}
              className="-mt-4 shrink-0 cursor-default rounded bg-red-50 px-1 py-0.5 text-[10px] font-semibold tabular-nums text-red-700 hover:bg-red-100"
            >
              −{drops[i].pts.toFixed(1)}
            </Tip>
          )}
        </div>
      ))}
    </div>
  );
}

function PerfectOrderVisual() {
  return (
    <ul className="flex flex-col gap-1.5" aria-label="Perfect order components">
      {perfectOrder.components.map((c, i) => (
        <li key={c.key}>
          <Tip
            content={{
                title: `${c.label} · ${c.pct.toFixed(1)}%`,
              value: `${formatCount(c.passing)} pass · ${formatCount(c.failing)} fail`,
              note: c.definition,
            }}
            className="group flex items-center gap-2 text-[11px]"
          >
            <span className="w-28 shrink-0 truncate text-muted-foreground group-hover:text-foreground">{c.label}</span>
            <span className="relative h-1.5 flex-1 overflow-hidden rounded-full bg-muted">
              <span
                className={cn(
                  "grow-x absolute inset-y-0 left-0 rounded-full",
                  c.pct < PERFECT_ORDER.targetPct + 2 ? "bg-amber-500" : "bg-primary/70 group-hover:bg-primary"
                )}
                style={{ width: `${band(c.pct)}%`, animationDelay: `${i * 70}ms` }}
              />
            </span>
            <span className="w-9 shrink-0 text-right font-medium tabular-nums text-foreground">{c.pct.toFixed(1)}</span>
          </Tip>
        </li>
      ))}
    </ul>
  );
}

function ValidationVisual() {
  const va = VALIDATION_ACCURACY;
  const segments = [
    { key: "correct", label: "Correct", count: validationAccuracy.correct, cls: "bg-primary/70 hover:bg-primary", note: "Released or held rightly by the agent" },
    { key: "false", label: "False hold", count: va.falseHolds, cls: "bg-amber-500 hover:bg-amber-600", note: "Held for review, then released unchanged" },
    { key: "missed", label: "Missed", count: va.missedErrors, cls: "bg-red-500 hover:bg-red-600", note: "Released, then corrected in billing" },
  ];
  const max = Math.max(...va.trend);
  const min = Math.min(...va.trend);
  return (
    <div className="flex flex-col gap-2">
      <div className="flex h-2.5 gap-0.5 overflow-hidden rounded-full" role="img" aria-label="Validation outcomes">
        {segments.map((s) => (
          <Tip
            key={s.key}
            content={{ title: s.label, value: `${formatCount(s.count)} orders`, note: s.note }}
            className={cn("grow-x block h-full transition-colors", s.cls)}
            style={{ flex: s.key === "correct" ? `${s.count} 1 0` : "0 0 8%" }}
          />
        ))}
      </div>
      <div className="flex flex-wrap gap-x-3 gap-y-0.5 text-[11px] text-muted-foreground">
        {segments.map((s) => (
          <span key={s.key} className="flex items-center gap-1">
            <span className={cn("h-2 w-2 rounded-sm", s.cls.split(" ")[0])} aria-hidden />
            {s.label} <span className="tabular-nums text-foreground">{formatCount(s.count)}</span>
          </span>
        ))}
      </div>
      <div className="flex h-8 items-end gap-1" role="img" aria-label="Accuracy, last 6 months">
        {va.trend.map((v, i) => (
          <Tip
            key={OM_TREND_MONTHS[i]}
            content={{ title: OM_TREND_MONTHS[i], value: `${v}%` }}
            className="flex h-full flex-1 items-end"
          >
            <span
              className={cn(
                "grow-y block w-full rounded-sm transition-colors",
                i === va.trend.length - 1 ? "bg-primary" : "bg-primary/30 hover:bg-primary/60"
              )}
              style={{ height: `${25 + ((v - min) / Math.max(0.1, max - min)) * 75}%`, animationDelay: `${i * 50}ms` }}
            />
          </Tip>
        ))}
      </div>
      <div className="flex justify-between text-[11px] text-muted-foreground">
        <span>{OM_TREND_MONTHS[0]}</span>
        <span>Accuracy, 6 months</span>
        <span>{OM_TREND_MONTHS[OM_TREND_MONTHS.length - 1]}</span>
      </div>
    </div>
  );
}

const PHASE_TONES = ["bg-primary/35", "bg-primary/55", "bg-amber-500", "bg-primary", "bg-primary/75"];

function CycleVisual() {
  return (
    <div className="flex flex-col gap-2">
      <div className="flex h-3 gap-0.5 overflow-hidden rounded-full" role="img" aria-label="Order-to-invoice by phase">
        {ORDER_TO_INVOICE.phases.map((p, i) => (
          <Tip
            key={p.key}
            content={{
              title: p.label,
              value: `${p.days.toFixed(1)} days`,
              note: `${Math.round((p.days / orderToInvoiceDays) * 100)}% of the cycle`,
            }}
            className={cn("grow-x block h-full transition-opacity hover:opacity-75", PHASE_TONES[i])}
            style={{ flex: `${p.days} 1 0`, animationDelay: `${i * 60}ms` }}
          />
        ))}
      </div>
      <ul className="flex flex-col gap-1 text-[11px] text-muted-foreground">
        {ORDER_TO_INVOICE.phases.map((p, i) => (
          <li key={p.key} className="flex items-center gap-1.5">
            <span className={cn("h-2 w-2 shrink-0 rounded-sm", PHASE_TONES[i])} aria-hidden />
            <span className="truncate">{p.label}</span>
            <span className="ml-auto tabular-nums text-foreground">{p.days.toFixed(1)}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

/** OM Command Center, row 1: the four order-management outcomes the client runs on. */
export function OmKpiCards({ onNavigate }: { onNavigate?: (v: ViewId) => void }) {
  const [open, setOpen] = useState<KpiKey | null>(null);
  const d = OTIF.stages[2];

  return (
    <>
      <div className="grid items-stretch gap-4 md:grid-cols-2 xl:grid-cols-4">
        <OmKpiCard
          kpi="otif"
          delay={0}
          icon={<PackageCheck className="h-3.5 w-3.5" aria-hidden />}
          label="OTIF · A › S › D"
          value={<CountUp value={otifPct.D} decimals={1} format={(n) => `${n.toFixed(1)}%`} />}
          chip={<TargetChip met={otifPct.D >= d.targetPct} target={`${d.targetPct}%`} />}
          delta={<DeltaChip delta={kpiDeltas.otif} />}
          systems={["SAP ECC", "SAP TM", "FourKites"]}
          onOpen={() => setOpen("otif")}
        >
          <OtifVisual />
        </OmKpiCard>
        <OmKpiCard
          kpi="perfect-order"
          delay={80}
          icon={<BadgeCheck className="h-3.5 w-3.5" aria-hidden />}
          label="Perfect order"
          value={<CountUp value={perfectOrder.pct} decimals={1} format={(n) => `${n.toFixed(1)}%`} />}
          chip={<TargetChip met={perfectOrder.pct >= PERFECT_ORDER.targetPct} target={`${PERFECT_ORDER.targetPct}%`} />}
          delta={<DeltaChip delta={kpiDeltas.perfectOrder} />}
          systems={["SAP ECC", "SAP FSCM"]}
          onOpen={() => setOpen("perfect-order")}
        >
          <PerfectOrderVisual />
        </OmKpiCard>
        <OmKpiCard
          kpi="validation-accuracy"
          delay={160}
          icon={<ScanSearch className="h-3.5 w-3.5" aria-hidden />}
          label="Order validation accuracy"
          value={<CountUp value={validationAccuracy.pct} decimals={1} format={(n) => `${n.toFixed(1)}%`} />}
          chip={
            <TargetChip
              met={validationAccuracy.pct >= VALIDATION_ACCURACY.targetPct}
              target={`${VALIDATION_ACCURACY.targetPct.toFixed(1)}%`}
            />
          }
          delta={<DeltaChip delta={kpiDeltas.validation} />}
          systems={["SAP ECC"]}
          onOpen={() => setOpen("validation-accuracy")}
        >
          <ValidationVisual />
        </OmKpiCard>
        <OmKpiCard
          kpi="order-to-invoice"
          delay={240}
          icon={<Timer className="h-3.5 w-3.5" aria-hidden />}
          label="Order-to-invoice cycle"
          value={
            <span>
              <CountUp value={orderToInvoiceDays} decimals={1} format={(n) => n.toFixed(1)} />
              <span className="text-base font-medium text-muted-foreground"> days</span>
            </span>
          }
          chip={
            <TargetChip
              met={orderToInvoiceDays <= ORDER_TO_INVOICE.targetDays}
              target={`${ORDER_TO_INVOICE.targetDays.toFixed(1)} d`}
            />
          }
          delta={<DeltaChip delta={kpiDeltas.cycleDays} unit="d" lowerIsBetter />}
          systems={["SAP ECC", "SAP TM"]}
          onOpen={() => setOpen("order-to-invoice")}
        >
          <CycleVisual />
        </OmKpiCard>
      </div>
      {open && <OmKpiDetail kpi={open} onClose={() => setOpen(null)} onNavigate={onNavigate} />}
    </>
  );
}
