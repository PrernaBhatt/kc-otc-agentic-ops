"use client";

import { useState } from "react";
import {
  DollarSign,
  Percent,
  Target,
  Timer,
  TrendingDown,
  TrendingUp,
  type LucideIcon,
} from "lucide-react";

import { KpiDetailModal } from "@/components/modals/kpi-detail-modal";
import { Card, CardContent } from "@/components/ui/card";
import { CountUpText } from "@/components/ui/count-up";
import type { Kpis } from "@/lib/data";
import { I2C_KPIS, rightFirstTimePct } from "@/lib/data/invoice-to-cash";
import { cn } from "@/lib/utils";

interface KpiDetailRow {
  metric: string;
  value: string;
  status: "Good" | "Warning" | "Critical";
}

interface KpiTile {
  label: string;
  value: string;
  change: string;
  trend: "up" | "down";
  icon: LucideIcon;
  color: string;
  details: KpiDetailRow[];
}

export function KpiGrid({ data }: { data: Kpis }) {
  const [selectedLabel, setSelectedLabel] = useState<string | null>(null);

  const tiles: KpiTile[] = [
    {
      label: "DSO",
      value: `${data.dsoValue} days`,
      change: `${data.dsoDelta} days`,
      trend: "down",
      icon: DollarSign,
      color: "text-[var(--info)]",
      details: [
        { metric: "Current DSO", value: "38 days", status: "Good" },
        { metric: "Target DSO", value: "40 days", status: "Good" },
        { metric: "Best DSO", value: "35 days", status: "Good" },
        { metric: "Trend", value: "Improving", status: "Good" },
      ],
    },
    {
      label: "Right-first-time invoices",
      value: `${rightFirstTimePct}%`,
      change: `${I2C_KPIS.invoicesReissued} reissued`,
      trend: "up",
      icon: Target,
      color: "text-[var(--success)]",
      details: [
        { metric: "Invoices", value: I2C_KPIS.invoicesIssued.toLocaleString(), status: "Good" },
        { metric: "Disputed", value: I2C_KPIS.invoicesDisputed.toLocaleString(), status: "Warning" },
        { metric: "Reissued", value: String(I2C_KPIS.invoicesReissued), status: "Good" },
        {
          metric: "Target",
          value: `${I2C_KPIS.rightFirstTimeTarget}%`,
          status: rightFirstTimePct >= I2C_KPIS.rightFirstTimeTarget ? "Good" : "Warning",
        },
      ],
    },
    {
      label: "Invoice-to-Cash",
      value: `${I2C_KPIS.invoiceToCashDays} days`,
      change: `${I2C_KPIS.invoiceToCashDays - I2C_KPIS.invoiceToCashTrend.at(-2)!} days`,
      trend: "down",
      icon: Timer,
      color: "text-[var(--info)]",
      details: [
        { metric: "Current", value: `${I2C_KPIS.invoiceToCashDays} days`, status: "Warning" },
        { metric: "Target", value: `${I2C_KPIS.invoiceToCashTarget} days`, status: "Good" },
        { metric: "Best", value: `${I2C_KPIS.invoiceToCashBest} days`, status: "Good" },
        { metric: "Trend", value: I2C_KPIS.invoiceToCashTrend.join(" → "), status: "Good" },
      ],
    },
    {
      label: "Collection Rate",
      value: `${data.collectionEffectiveness}%`,
      change: "+1.5%",
      trend: "up",
      icon: Percent,
      color: "text-[var(--success)]",
      details: [
        { metric: "Collected", value: "$2.4M", status: "Good" },
        { metric: "Outstanding", value: "$485K", status: "Warning" },
        { metric: "Overdue", value: "$125K", status: "Critical" },
        { metric: "Promise Rate", value: "91.5%", status: "Good" },
      ],
    },
  ];

  const selectedTile = tiles.find((tile) => tile.label === selectedLabel);

  return (
    <>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {tiles.map((tile, index) => {
          const Icon = tile.icon;
          return (
            <Card
              key={index}
              className="bg-gradient-to-br from-white via-gray-50 to-white dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 cursor-pointer hover:shadow-lg hover:scale-[1.02] transition-all duration-200 border-gray-200 dark:border-gray-700"
              onClick={() => setSelectedLabel(tile.label)}
            >
              <CardContent className="p-3">
                <div className="flex items-center justify-between mb-1">
                  <Icon className={cn("h-4 w-4", tile.color)} />
                  <div
                    className={cn(
                      "flex items-center text-xs font-medium",
                      "text-[var(--success)]"
                    )}
                  >
                    {tile.trend === "up" ? (
                      <TrendingUp className="h-3 w-3 mr-0.5" />
                    ) : (
                      <TrendingDown className="h-3 w-3 mr-0.5" />
                    )}
                    {tile.change}
                  </div>
                </div>
                <div className="text-xl font-bold text-foreground dark:text-white">
                  <CountUpText text={tile.value} />
                </div>
                <div className="text-xs text-muted-foreground dark:text-gray-300 mt-0.5 truncate" title={tile.label}>
                  {tile.label}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
      {selectedTile && (
        <KpiDetailModal
          kpi={selectedTile}
          onClose={() => setSelectedLabel(null)}
        />
      )}
    </>
  );
}
