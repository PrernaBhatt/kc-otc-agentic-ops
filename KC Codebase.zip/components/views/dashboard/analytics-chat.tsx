"use client";

import { useEffect, useRef, useState } from "react";
import { Spinner } from "@/components/agents/spinner";
import {
  Bot,
  ExternalLink,
  Maximize2,
  MessageCircle,
  Minimize2,
  Send,
  User,
  X,
} from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import type { ViewId } from "@/components/layout/sidebar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { exceptions, kpis, orders } from "@/lib/data";
import { I2C_KPIS, rightFirstTimePct } from "@/lib/data/invoice-to-cash";
import { OM_BASE_ORDERS, OM_PERIOD } from "@/lib/data/om-kpis";
import { otifPct, riskSummary } from "@/lib/shipment-selectors";

interface ActionLink {
  text: string;
  view: ViewId;
  orderId?: string;
}

interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  actionLink?: ActionLink;
}

const suggestedQuestions = [
  "What is the current DSO?",
  "Show me orders on hold",
  "Where is SO-710245 stuck?",
  "What's the automation rate?",
];

function generateResponse(query: string): {
  content: string;
  actionLink?: ActionLink;
} {
  const q = query.toLowerCase();
  if (q.includes("dso") || q.includes("days sales outstanding")) {
    return {
      content: `Current DSO is **${kpis.dsoValue} days**, which is ${Math.abs(kpis.dsoDelta)} days ${kpis.dsoDelta < 0 ? "below" : "above"} target. This represents a ${kpis.dsoDelta < 0 ? "positive" : "concerning"} trend. The DSO has been steadily improving over the past 6 months due to proactive collection efforts and automated dunning.`,
    };
  }
  if (
    q.includes("hold") ||
    q.includes("held") ||
    q.includes("stuck") ||
    q.includes("status")
  ) {
    const holdOrders = orders.filter(
      (order) => order.status === "Hold" || order.status === "Blocked"
    );
    if (q.includes("so-") || q.includes("order")) {
      const match = q.match(/so-?\d+/i);
      if (match) {
        const orderId = match[0].toUpperCase().replace(/SO-?/, "SO-");
        const order = orders.find((o) => o.orderId === orderId);
        if (order) {
          let actionLink: ActionLink | undefined;
          let statusDetail = "";
          if (order.status === "Hold") {
            statusDetail = `

**Why is it stuck?**
${order.holdReason} Hold - Customer ${order.customerName} has exceeded their credit limit. Current exposure is near maximum threshold.

**AI Recommendation:**
The Credit Risk Agent has analyzed this case and generated 3 decision options (Golden Trio) for review. You can approve a conditional release, split shipment, or require prepayment.`;
            actionLink = {
              text: "Review Credit Hold Decision",
              view: "credit-review",
              orderId: order.orderId,
            };
          } else if (order.status === "Blocked") {
            statusDetail = `

**Why is it stuck?**
${order.holdReason} Delay - Shipment is blocked due to logistics constraints. Estimated delay: 5 days.

**AI Recommendation:**
The Logistics Agent suggests rerouting through alternate carrier or splitting delivery to meet partial fulfillment.`;
            actionLink = {
              text: "View in Exceptions",
              view: "exceptions",
              orderId: order.orderId,
            };
          } else {
            statusDetail = `

**Current Status:**
Order is progressing normally through the pipeline. No action required.`;
          }
          return {
            content: `**${order.orderId}** for ${order.customerName}:

• Status: **${order.status}**
• Value: **$${order.totalValue.toLocaleString()}**
• Order Date: ${order.orderDate}${statusDetail}`,
            actionLink,
          };
        }
      }
    }
    return {
      content: `Currently **${holdOrders.length} orders** are on hold:

${holdOrders.map((order) => `• **${order.orderId}** - ${order.customerName} ($${order.totalValue.toLocaleString()}) - ${order.holdReason} Hold`).join("\n")}

You can review these in the "Review Order Hold" section for AI-recommended actions.`,
    };
  }
  if (
    q.includes("automation") ||
    q.includes("touchless") ||
    q.includes("automated")
  ) {
    return {
      content: `Current automation metrics:

• **Automation Rate**: ${kpis.automationRate}%
• **Touchless Order Rate**: ${kpis.touchlessOrderRate}%
• **Loop Orders**: ${kpis.loopOrdersPercent}%
• **Loop Lines**: ${kpis.loopLinesPercent}%

The AI agents are processing ${kpis.automationRate}% of transactions without human intervention.`,
    };
  }
  if (q.includes("invoice-to-cash") || q.includes("i2c") || q.includes("cash")) {
    return {
      content: `**Invoice-to-Cash** is **${I2C_KPIS.invoiceToCashDays} days** against a ${I2C_KPIS.invoiceToCashTarget}-day target. **${rightFirstTimePct}%** of invoices are right first time, ${I2C_KPIS.invoicesDisputed} of ${I2C_KPIS.invoicesIssued.toLocaleString()} disputed and ${I2C_KPIS.invoicesReissued} reissued.`,
    };
  }
  if (q.includes("otif") || q.includes("on time") || q.includes("in full")) {
    return {
      content: `**OTIF** over ${OM_PERIOD.toLowerCase()}: available **${otifPct.A}%** → shipped **${otifPct.S}%** → delivered **${otifPct.D}%** of ${OM_BASE_ORDERS.toLocaleString()} orders. ${riskSummary.total} shipments are at risk now, ${riskSummary.needAction} need action.`,
      actionLink: { text: "Open Shipments", view: "shipments" },
    };
  }
  if (q.includes("credit")) {
    return {
      content: `Credit metrics overview:

• **Active Credit Holds**: ${kpis.creditHoldCount}
• **Avg Hold Duration**: ${kpis.avgHoldDuration} hours
• **Collection Effectiveness**: ${kpis.collectionEffectiveness}%

The Credit Risk Agent is actively monitoring ${kpis.creditHoldCount} accounts with elevated exposure.`,
    };
  }
  if (q.includes("exception")) {
    const byType = exceptions.reduce<Record<string, number>>(
      (acc, exception) => {
        acc[exception.type] = (acc[exception.type] || 0) + 1;
        return acc;
      },
      {}
    );
    return {
      content: `Current exceptions breakdown:

${Object.entries(byType)
  .map(([type, count]) => `• **${type}**: ${count}`)
  .join("\n")}

Total: **${exceptions.length}** active exceptions. High severity items should be prioritized in the Exceptions view.`,
    };
  }
  return q.includes("revenue") || q.includes("risk") || q.includes("exposure")
    ? {
        content: `**Revenue at Risk**: $${kpis.revenueAtRisk.toLocaleString()}

This includes:
• Orders on credit hold
• Disputed invoices
• Overdue receivables

The AI agents are actively working to reduce this exposure through proactive collections and credit management.`,
      }
    : q.includes("invoice") || q.includes("billing")
      ? {
          content: `Billing metrics:

• **Invoice Accuracy**: ${kpis.invoiceAccuracy}%
• **Billing Cycle Time**: ${kpis.billingCycleTime} days
• **Dispute Rate**: ${kpis.disputeRate}%

The Billing Agent is maintaining high accuracy while reducing cycle time.`,
        }
      : q.includes("cycle") || q.includes("time") || q.includes("processing")
        ? {
            content: `Order processing metrics:

• **Order Cycle Time**: ${kpis.orderCycleTime} days
• **Order Fill Rate**: ${kpis.orderFillRate}%
• **Perfect Order Rate**: ${kpis.perfectOrderRate}%

Cycle time has improved 15% this quarter due to AI-driven automation.`,
          }
        : q.includes("kpi") ||
            q.includes("performance") ||
            q.includes("metrics") ||
            q.includes("summary")
          ? {
              content: `**OTC Performance Summary**:

📊 **Efficiency**
• Automation Rate: ${kpis.automationRate}%
• Invoice-to-Cash: ${I2C_KPIS.invoiceToCashDays} days (target ${I2C_KPIS.invoiceToCashTarget})

💰 **Financial**
• DSO: ${kpis.dsoValue} days
• Revenue at Risk: $${kpis.revenueAtRisk.toLocaleString()}

✅ **Quality**
• Right-first-time invoices: ${rightFirstTimePct}%
• Invoice Accuracy: ${kpis.invoiceAccuracy}%
• Perfect Order Rate: ${kpis.perfectOrderRate}%`,
            }
          : {
              content: `I can help you with OTC metrics and order status. Try asking about:

• DSO and collection metrics
• Order holds and status
• Automation rates
• Invoice-to-cash
• Specific orders (e.g., "Where is SO-710245?")

What would you like to know?`,
            };
}

export function AnalyticsChat({
  onNavigate,
}: {
  onNavigate: (view: ViewId, orderId?: string) => void;
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "1",
      role: "assistant",
      content:
        "Hello! I'm your OTC Analytics Assistant. I can help you understand KPIs, track orders, and analyze performance metrics. What would you like to know?",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = () => {
    if (!input.trim()) return;
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsTyping(true);
    setTimeout(() => {
      const { content, actionLink } = generateResponse(input);
      const assistantMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content,
        timestamp: new Date(),
        actionLink,
      };
      setMessages((prev) => [...prev, assistantMessage]);
      setIsTyping(false);
    }, 800);
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 z-50 bg-gradient-to-r from-primary to-primary/80 text-primary-foreground rounded-full p-4 shadow-2xl hover:shadow-primary/50 hover:scale-110 transition-all duration-300"
      >
        <MessageCircle className="h-6 w-6" />
      </button>
    );
  }

  return (
    <Card
      className={`fixed bottom-6 right-6 z-50 shadow-2xl transition-all border-2 border-gray-200 dark:border-gray-700 ${isMinimized ? "w-[500px] h-14" : "w-[600px] h-[700px]"} flex flex-col bg-gradient-to-br from-white via-gray-50 to-white dark:from-gray-900 dark:via-gray-800 dark:to-gray-900`}
    >
      <div className="flex items-center justify-between p-3 border-b bg-gradient-to-r from-primary to-primary/80 text-primary-foreground rounded-t-lg shadow-lg">
        <div className="flex items-center gap-2">
          <AgentIcon
            type="orchestrator"
            size="sm"
            className="text-primary-foreground"
          />
          <span className="font-semibold text-sm">OTC Analytics Assistant</span>
          <Badge variant="secondary" className="text-xs">
            AI
          </Badge>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setIsMinimized(!isMinimized)}
            className="p-1 hover:bg-primary-foreground/20 rounded"
          >
            {isMinimized ? (
              <Maximize2 className="h-4 w-4" />
            ) : (
              <Minimize2 className="h-4 w-4" />
            )}
          </button>
          <button
            onClick={() => setIsOpen(false)}
            className="p-1 hover:bg-primary-foreground/20 rounded"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>
      {!isMinimized && (
        <>
          <div className="flex-1 overflow-y-auto p-4 space-y-4 min-h-0 bg-gradient-to-b from-transparent to-gray-50/50 dark:to-gray-900/50">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-2 ${message.role === "user" ? "justify-end" : "justify-start"}`}
              >
                {message.role === "assistant" && (
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Bot className="h-4 w-4 text-primary" />
                  </div>
                )}
                <div className="flex flex-col gap-2 max-w-[85%]">
                  <div
                    className={`rounded-lg px-4 py-3 text-sm ${message.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"}`}
                  >
                    <div className="whitespace-pre-wrap leading-relaxed">
                      {message.content
                        .split("**")
                        .map((part, index) =>
                          index % 2 === 1 ? (
                            <strong key={index}>{part}</strong>
                          ) : (
                            part
                          )
                        )}
                    </div>
                  </div>
                  {message.actionLink && onNavigate && (
                    <Button
                      onClick={() =>
                        onNavigate(
                          message.actionLink!.view,
                          message.actionLink!.orderId
                        )
                      }
                      size="sm"
                      variant="outline"
                      className="w-fit gap-2 bg-primary/5 hover:bg-primary/10 border-primary/20"
                    >
                      <ExternalLink className="h-3 w-3" />
                      {message.actionLink.text}
                    </Button>
                  )}
                </div>
                {message.role === "user" && (
                  <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
                    <User className="h-4 w-4 text-muted-foreground" />
                  </div>
                )}
              </div>
            ))}
            {isTyping && (
              <div className="flex gap-2 items-center">
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                  <Bot className="h-4 w-4 text-primary" />
                </div>
                <div className="bg-muted rounded-lg px-4 py-3">
                  <Spinner size="sm" className="text-muted-foreground" />
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
          {messages.length <= 2 && (
            <div className="px-3 pb-2 bg-gradient-to-t from-white/80 dark:from-gray-900/80">
              <p className="text-xs text-muted-foreground dark:text-gray-300 mb-2 font-medium">
                Suggested questions:
              </p>
              <div className="flex flex-wrap gap-1">
                {suggestedQuestions.map((question) => (
                  <button
                    key={question}
                    onClick={() => {
                      setInput(question);
                      setTimeout(() => handleSend(), 100);
                    }}
                    className="text-xs bg-gradient-to-r from-gray-100 to-gray-200 dark:from-gray-800 dark:to-gray-700 hover:from-primary/10 hover:to-primary/20 px-2 py-1 rounded-full text-foreground dark:text-white transition-all hover:shadow-md"
                  >
                    {question}
                  </button>
                ))}
              </div>
            </div>
          )}
          <div className="p-3 border-t bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm">
            <div className="flex gap-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key !== "Enter" || e.nativeEvent.isComposing || e.keyCode === 229) return;
                  handleSend();
                }}
                placeholder="Ask about KPIs, orders..."
                className="flex-1 text-sm dark:text-white dark:placeholder:text-gray-300"
              />
              <Button onClick={handleSend} size="sm" className="px-3">
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </>
      )}
    </Card>
  );
}
