"use client";

import { useEffect, useMemo, useState } from "react";
import { Check, X } from "lucide-react";

import { Spinner } from "@/components/agents/spinner";
import {
  SourceDocTrigger,
  SourceDocRowTrigger,
} from "@/components/modals/source-doc-preview";
import { SystemMark } from "@/components/shared/system-badge";
import { formatUsd } from "@/lib/chargeback-selectors";
import {
  promoClaimSplit,
  PROMO_CATEGORY_LABEL,
} from "@/lib/promo-claim-selectors";
import type { PromoLineCategory, ProofSource } from "@/lib/data/promo-claims";
import {
  buildProofOfPerformanceDoc,
  buildProofSourceDoc,
  buildStoreExceptionDoc,
} from "@/lib/docs-promo-claims";
import { cn } from "@/lib/utils";

type Split = NonNullable<ReturnType<typeof promoClaimSplit>>;

const CATEGORY_ORDER: PromoLineCategory[] = [
  "supported",
  "not-on-event",
  "out-of-window",
  "ineligible-sku",
  "needs-info",
];

export const CATEGORY_FILL: Record<PromoLineCategory, string> = {
  supported: "bg-[var(--success)]",
  "not-on-event": "bg-red-400",
  "out-of-window": "bg-amber-400",
  "ineligible-sku": "bg-amber-700",
  "needs-info": "bg-muted-foreground/40",
};

const SHORT_LABEL: Record<PromoLineCategory, string> = {
  supported: "Evidenced",
  "not-on-event": "Not on approved list",
  "out-of-window": "Set up after window",
  "ineligible-sku": "Ineligible SKU",
  "needs-info": "Needs info",
};

const SOURCE_QUERY_MS = 700;

/** Stable pseudo-random order so exception stores scatter across the grid. */
function scatter(n: number): number[] {
  const idx = Array.from({ length: n }, (_, i) => i);
  let seed = 7;
  for (let i = n - 1; i > 0; i--) {
    seed = (seed * 9301 + 49297) % 233280;
    const j = Math.floor((seed / 233280) * (i + 1));
    [idx[i], idx[j]] = [idx[j], idx[i]];
  }
  return idx;
}

function storeCategories(split: Split): PromoLineCategory[] {
  const total = split.claimedStores;
  const flat: PromoLineCategory[] = [];
  for (const cat of CATEGORY_ORDER) {
    for (const l of split.byCategory[cat] ?? []) {
      for (let i = 0; i < l.stores && flat.length < total; i++) flat.push(cat);
    }
  }
  while (flat.length < total) flat.push("needs-info");
  const order = scatter(total);
  const out = new Array<PromoLineCategory>(total);
  order.forEach((slot, i) => {
    out[slot] = flat[i];
  });
  return out;
}

function highlightsFor(s: ProofSource): PromoLineCategory[] | "all" {
  if (s.flags?.length) return s.flags;
  return s.status === "supports" ? "all" : ["supported"];
}

/**
 * Proof of performance as a 500-store matrix. Each source is queried in turn;
 * as it answers, the stores it decides light up, until only the evidenced
 * stores remain green.
 */
export function StoreProofMatrix({
  split,
  caseId,
}: {
  split: Split;
  caseId: string;
}) {
  const sources = split.case.proofSources;
  const cats = useMemo(() => storeCategories(split), [split]);
  const [step, setStep] = useState(0);
  const [hover, setHover] = useState<string | null>(null);
  const done = step > sources.length;

  useEffect(() => {
    if (done) return;
    const id = setTimeout(() => setStep((s) => s + 1), SOURCE_QUERY_MS);
    return () => clearTimeout(id);
  }, [step, done]);

  const firstRevealIndex = useMemo(() => {
    const map: Partial<Record<PromoLineCategory, number>> = {};
    sources.forEach((s, i) => {
      for (const f of s.flags ?? []) if (map[f] === undefined) map[f] = i;
    });
    return map;
  }, [sources]);
  const shipmentIndex = sources.findIndex((s) => s.status === "supports");

  const hovered = sources.find((s) => s.sourceId === hover);
  const focus = hovered && done ? highlightsFor(hovered) : null;

  const colorFor = (cat: PromoLineCategory) => {
    if (cat === "supported") {
      if (done) return CATEGORY_FILL.supported;
    } else {
      const at = firstRevealIndex[cat];
      if (at !== undefined ? step > at : done) return CATEGORY_FILL[cat];
    }
    return shipmentIndex >= 0 && step > shipmentIndex
      ? "bg-muted-foreground/25"
      : "bg-muted";
  };

  const counts = CATEGORY_ORDER.map((cat) => ({
    cat,
    n: cats.filter((c) => c === cat).length,
  })).filter((c) => c.n > 0);

  return (
    <div className="flex flex-col gap-4 rounded-xl border bg-card p-4">
      <div className="flex items-baseline justify-between gap-3">
        <h4 className="text-sm font-semibold">
          {split.claimedStores} billed stores
        </h4>
        <span className="text-sm tabular-nums text-muted-foreground">
          <span
            className={cn(
              "text-lg font-semibold transition-colors",
              done ? "text-[var(--success)]" : "text-foreground"
            )}
          >
            {done ? split.supportedStores : "—"}
          </span>
          /{split.claimedStores} evidenced
        </span>
      </div>

      <div
        className="grid grid-cols-[repeat(50,minmax(0,1fr))] gap-[3px]"
        role="img"
        aria-label={`${split.supportedStores} of ${split.claimedStores} stores fully evidenced`}
      >
        {cats.map((cat, i) => {
          const dim =
            focus !== null && focus !== "all" && !focus.includes(cat);
          return (
            <span
              key={i}
              className={cn(
                "aspect-square rounded-[2px] transition-all duration-500",
                colorFor(cat),
                dim && "opacity-15"
              )}
              style={{ transitionDelay: focus ? "0ms" : `${(i % 50) * 5}ms` }}
            />
          );
        })}
      </div>

      <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
        {counts.map(({ cat, n }) => (
          <span key={cat} className="flex items-center gap-1.5">
            <span className={cn("h-2 w-2 rounded-[2px]", CATEGORY_FILL[cat])} />
            {SHORT_LABEL[cat]}
            <span className="tabular-nums text-foreground">{n}</span>
          </span>
        ))}
      </div>

      <div className="grid gap-2 border-t pt-3 sm:grid-cols-2 xl:grid-cols-3">
        {sources.map((s, i) => {
          const state = step > i ? "done" : step === i ? "querying" : "pending";
          return (
            <div
              key={s.sourceId}
              onMouseEnter={() => setHover(s.sourceId)}
              onMouseLeave={() => setHover(null)}
              className={cn(
                "transition-opacity duration-300",
                state === "pending" && "opacity-40"
              )}
            >
              <SourceDocRowTrigger
                doc={buildProofSourceDoc(caseId, s.sourceId)}
                className="flex w-full items-center gap-2 rounded-lg border px-2.5 py-2 text-left hover:bg-muted/50"
              >
                <SystemMark name={s.system} className="h-4 w-4 shrink-0" />
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-xs font-medium">
                    {s.name}
                  </span>
                  <span className="block truncate text-xs text-muted-foreground">
                    {state === "done" ? s.metric ?? s.system : s.system}
                  </span>
                </span>
                {state === "querying" ? (
                  <Spinner size="sm" />
                ) : state === "done" ? (
                  s.status === "supports" ? (
                    <Check className="h-4 w-4 shrink-0 text-[var(--success)]" />
                  ) : (
                    <X
                      className={cn(
                        "h-4 w-4 shrink-0",
                        s.status === "gap" ? "text-red-600" : "text-amber-600"
                      )}
                    />
                  )
                ) : null}
              </SourceDocRowTrigger>
            </div>
          );
        })}
      </div>

      <div>
        <SourceDocTrigger
          doc={buildProofOfPerformanceDoc(caseId)}
          label="View the evidence pack"
        />
      </div>
    </div>
  );
}

/**
 * The claim as one bar: the supported share, then each reason the rest fails.
 * A three-column table carries the numbers; the full findings live in the doc.
 */
export function ExceptionSplitBar({
  split,
  caseId,
}: {
  split: Split;
  caseId: string;
}) {
  const rows = CATEGORY_ORDER.flatMap((cat) => split.byCategory[cat] ?? []);
  const total = rows.reduce((a, r) => a + r.amount, 0) || 1;
  const [grown, setGrown] = useState(0);

  useEffect(() => {
    if (grown >= rows.length) return;
    const id = setTimeout(() => setGrown((g) => g + 1), grown === 0 ? 200 : 450);
    return () => clearTimeout(id);
  }, [grown, rows.length]);

  return (
    <div className="flex flex-col gap-4 rounded-xl border bg-card p-4">
      <div className="flex items-baseline justify-between gap-3">
        <h4 className="text-sm font-semibold">
          {formatUsd(split.claimed)} claimed
        </h4>
        <span className="text-sm tabular-nums text-muted-foreground">
          <span className="font-semibold text-[var(--success)]">
            {formatUsd(split.supported)}
          </span>{" "}
          supported
        </span>
      </div>

      <div className="flex h-8 w-full gap-0.5 overflow-hidden rounded-md bg-muted">
        {rows.map((r, i) => (
          <div
            key={r.lineId}
            className={cn(
              "h-full transition-all duration-700 ease-out",
              CATEGORY_FILL[r.category]
            )}
            style={{ width: i < grown ? `${(r.amount / total) * 100}%` : "0%" }}
            title={`${PROMO_CATEGORY_LABEL[r.category]} — ${formatUsd(r.amount)}`}
          />
        ))}
      </div>

      <table className="w-full text-sm">
        <thead>
          <tr className="text-left text-xs text-muted-foreground">
            <th className="pb-2 font-normal">Reason</th>
            <th className="pb-2 text-right font-normal">Stores</th>
            <th className="pb-2 text-right font-normal">Amount</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr
              key={r.lineId}
              title={r.finding}
              className={cn(
                "border-t transition-opacity duration-500",
                i < grown ? "opacity-100" : "opacity-0"
              )}
            >
              <td className="py-2">
                <span className="flex items-center gap-2">
                  <span
                    className={cn("h-2.5 w-2.5 shrink-0 rounded-[2px]", CATEGORY_FILL[r.category])}
                  />
                  {SHORT_LABEL[r.category]}
                </span>
              </td>
              <td className="py-2 text-right tabular-nums text-muted-foreground">
                {r.stores}
              </td>
              <td
                className={cn(
                  "py-2 text-right font-medium tabular-nums",
                  r.category === "supported" && "text-[var(--success)]"
                )}
              >
                {formatUsd(r.amount)}
              </td>
            </tr>
          ))}
          <tr className="border-t font-semibold">
            <td className="pt-2">Bill back</td>
            <td className="pt-2 text-right tabular-nums text-muted-foreground">
              {split.exceptionStores}
            </td>
            <td className="pt-2 text-right tabular-nums text-amber-700">
              {formatUsd(split.billBack)}
            </td>
          </tr>
        </tbody>
      </table>

      <div>
        <SourceDocTrigger
          doc={buildStoreExceptionDoc(caseId)}
          label="View the exception list"
        />
      </div>
    </div>
  );
}
