"use client";

import { useEffect, useState } from "react";
import { Download, Filter, Landmark, Play, Search } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
} from "@/components/ui/table";
import { AgentIcon } from "@/components/agents/agent-icon";
import { Spinner } from "@/components/agents/spinner";
import { AnimatedProgress } from "@/components/agents/animated-progress";
import { CashApplicationPanel } from "@/components/mounts/cash-application/cash-application-panel";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

// Phase 1 local transcription of the minified `aU` status chip helper
// (lives in the agent-icons slice; no contract component exists for it yet).
function AgentStatusChip({
  status,
  message,
}: {
  status: "idle" | "processing" | "complete" | "error";
  message?: string;
}) {
  const config = {
    idle: {
      color: "text-muted-foreground",
      bg: "bg-muted",
      label: "Idle",
    },
    processing: {
      color: "text-[var(--info)]",
      bg: "bg-[var(--info)]/10",
      label: "Processing",
    },
    complete: {
      color: "text-[var(--success)]",
      bg: "bg-[var(--success)]/10",
      label: "Complete",
    },
    error: {
      color: "text-primary",
      bg: "bg-primary/10",
      label: "Error",
    },
  }[status];
  return (
    <div
      className={cn("flex items-center gap-2 px-3 py-1.5 rounded-full", config.bg)}
    >
      {status === "processing" && <Spinner size="sm" className={config.color} />}
      {status === "complete" && (
        <svg
          className={cn("w-4 h-4", config.color)}
          viewBox="0 0 20 20"
          fill="currentColor"
        >
          <path
            fillRule="evenodd"
            d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
            clipRule="evenodd"
          />
        </svg>
      )}
      {status === "error" && (
        <svg
          className={cn("w-4 h-4", config.color)}
          viewBox="0 0 20 20"
          fill="currentColor"
        >
          <path
            fillRule="evenodd"
            d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z"
            clipRule="evenodd"
          />
        </svg>
      )}
      {status === "idle" && (
        <div
          className={cn("w-2 h-2 rounded-full", config.color.replace("text-", "bg-"))}
        />
      )}
      <span className={cn("text-sm font-medium", config.color)}>
        {message || config.label}
      </span>
    </div>
  );
}

function orderStatusBadgeClass(status: string) {
  switch (status) {
    case "Hold":
      return "bg-primary text-primary-foreground";
    case "Blocked":
      return "bg-[var(--warning)] text-[var(--warning-foreground)]";
    case "Processing":
      return "bg-[var(--info)] text-white";
    case "Released":
    case "Fulfilled":
      return "bg-[var(--success)] text-white";
    default:
      return "bg-muted text-muted-foreground";
  }
}

function invoiceStatusBadgeClass(status: string) {
  switch (status) {
    case "Paid":
      return "bg-[var(--success)] text-white";
    case "Sent":
      return "bg-[var(--info)] text-white";
    case "Pending":
      return "bg-[var(--warning)] text-[var(--warning-foreground)]";
    case "Overdue":
      return "bg-primary text-primary-foreground";
    case "Disputed":
      return "bg-purple-500 text-white";
    default:
      return "bg-muted text-muted-foreground";
  }
}

const ORDER_ACTION_STATUSES: string[] = ["Hold", "Blocked", "Processing"];
const INVOICE_ACTION_STATUSES: string[] = ["Overdue", "Disputed", "Pending"];

export function TransactionsView({
  onProcessOrder,
}: {
  onProcessOrder: (orderId: string) => void;
}) {
  // Orders and invoices come from the store so decisions made on other pages
  // (credit-hold approvals, cash application) update this view live.
  const { allInvoices, orders, runReturnStage } = useOtcStore();
  // Land on Cash Application during a guided run so the run row is in view.
  const [activeTab, setActiveTab] = useState<"orders" | "invoices" | "cash">(
    runReturnStage === "cash_application" ? "cash" : "orders"
  );
  const [searchQuery, setSearchQuery] = useState("");
  const [needsActionOnly, setNeedsActionOnly] = useState(false);
  const [processingProgress, setProcessingProgress] = useState<
    Record<string, number>
  >({});
  const query = searchQuery.toLowerCase();
  const filteredOrders = orders
    .filter(
      (order) =>
        order.orderId.toLowerCase().includes(query) ||
        order.customerName.toLowerCase().includes(query)
    )
    .filter(
      (order) =>
        !needsActionOnly || ORDER_ACTION_STATUSES.includes(order.status)
    )
    .sort((a, b) => b.orderDate.localeCompare(a.orderDate));
  const filteredInvoices = allInvoices
    .filter(
      (invoice) =>
        invoice.invoiceId.toLowerCase().includes(query) ||
        invoice.customerName.toLowerCase().includes(query)
    )
    .filter(
      (invoice) =>
        !needsActionOnly || INVOICE_ACTION_STATUSES.includes(invoice.status)
    )
    .sort((a, b) => b.invoiceDate.localeCompare(a.invoiceDate));
  const exportCsv = () => {
    const rows: (string | number)[][] =
      activeTab === "orders"
        ? [
            ["Order ID", "Customer", "Date", "Value (USD)", "Status"],
            ...filteredOrders.map((o) => [
              o.orderId,
              o.customerName,
              o.orderDate,
              o.totalValue,
              o.status,
            ]),
          ]
        : [
            ["Invoice ID", "Customer", "Invoice date", "Due date", "Amount (USD)", "Status"],
            ...filteredInvoices.map((i) => [
              i.invoiceId,
              i.customerName,
              i.invoiceDate,
              i.dueDate,
              i.amount,
              i.status,
            ]),
          ];
    const csv = rows
      .map((r) => r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(","))
      .join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = `${activeTab === "orders" ? "sales-orders" : "invoices"}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };
  useEffect(() => {
    const interval = setInterval(() => {
      setProcessingProgress((prev) => {
        const next = { ...prev };
        Object.keys(next).forEach((key) => {
          if (next[key] < 100) {
            next[key] = Math.min(next[key] + 15 * Math.random(), 100);
          }
        });
        return next;
      });
    }, 500);
    return () => clearInterval(interval);
  }, []);
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-foreground">Transactions</h2>
          <p className="text-muted-foreground">
            Sales orders and invoices from SAP ECC, received over EDI/VAN
          </p>
        </div>
        <Button
          variant="outline"
          onClick={exportCsv}
          disabled={activeTab === "cash"}
        >
          <Download className="h-4 w-4 mr-2" />
          Export
        </Button>
      </div>
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Card className="bg-card">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <AgentIcon type="validation" size="sm" className="text-primary" />
              </div>
              <div>
                <div className="text-2xl font-bold">{orders.length}</div>
                <div className="text-xs text-muted-foreground">Total Orders</div>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-[var(--info)]/10">
                <Spinner size="sm" className="text-[var(--info)]" />
              </div>
              <div>
                <div className="text-2xl font-bold">
                  {orders.filter((order) => order.status === "Processing").length}
                </div>
                <div className="text-xs text-muted-foreground">Processing</div>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-[var(--warning)]/10">
                <AgentIcon type="credit" size="sm" className="text-[var(--warning)]" />
              </div>
              <div>
                <div className="text-2xl font-bold">
                  {
                    orders.filter(
                      (order) =>
                        order.status === "Hold" || order.status === "Blocked"
                    ).length
                  }
                </div>
                <div className="text-xs text-muted-foreground">Exceptions</div>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-[var(--success)]/10">
                <AgentIcon type="atp" size="sm" className="text-[var(--success)]" />
              </div>
              <div>
                <div className="text-2xl font-bold">
                  {orders.filter((order) => order.status === "Fulfilled").length}
                </div>
                <div className="text-xs text-muted-foreground">Fulfilled</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      <div className="flex gap-2">
        <Button
          variant={activeTab === "orders" ? "default" : "outline"}
          onClick={() => setActiveTab("orders")}
        >
          <AgentIcon type="validation" size="sm" className="mr-2" />
          Sales Orders
        </Button>
        <Button
          variant={activeTab === "invoices" ? "default" : "outline"}
          onClick={() => setActiveTab("invoices")}
        >
          <AgentIcon type="invoice" size="sm" className="mr-2" />
          Invoices
        </Button>
        <Button
          variant={activeTab === "cash" ? "default" : "outline"}
          onClick={() => setActiveTab("cash")}
        >
          <Landmark className="h-4 w-4 mr-2" />
          Cash Application
        </Button>
      </div>
      {activeTab === "cash" ? (
        <CashApplicationPanel />
      ) : (
      <Card>
        <CardContent className="px-3 pt-6 lg:px-6">
          <div className="flex gap-4 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder={`Search ${activeTab}...`}
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button
              variant={needsActionOnly ? "default" : "outline"}
              aria-pressed={needsActionOnly}
              onClick={() => setNeedsActionOnly((v) => !v)}
            >
              <Filter className="h-4 w-4 mr-2" />
              Needs action
            </Button>
          </div>
          {activeTab === "orders" ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Order ID</TableHead>
                  <TableHead className="hidden lg:table-cell">Customer</TableHead>
                  <TableHead className="hidden lg:table-cell">Date</TableHead>
                  <TableHead>Value</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="hidden xl:table-cell">Agent Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredOrders.map((order) => {
                  const isProcessing =
                    processingProgress[order.orderId] !== undefined &&
                    processingProgress[order.orderId] < 100;
                  const progress = processingProgress[order.orderId] || 0;
                  return (
                    <TableRow
                      key={order.orderId}
                      className={cn(isProcessing && "bg-[var(--info)]/5")}
                    >
                      <TableCell className="font-mono font-medium">
                        {order.orderId}
                        <div className="font-sans text-xs font-normal text-muted-foreground lg:hidden">
                          {order.customerName}
                        </div>
                      </TableCell>
                      <TableCell className="hidden lg:table-cell">{order.customerName}</TableCell>
                      <TableCell className="hidden lg:table-cell">{order.orderDate}</TableCell>
                      <TableCell className="font-medium">
                        ${order.totalValue.toLocaleString()}
                      </TableCell>
                      <TableCell>
                        <Badge className={orderStatusBadgeClass(order.status)}>
                          {order.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="hidden xl:table-cell">
                        {isProcessing ? (
                          <div className="w-32">
                            <AnimatedProgress
                              progress={progress}
                              showPercent={false}
                              color="info"
                            />
                          </div>
                        ) : order.status === "Processing" ? (
                          <AgentStatusChip
                            status="processing"
                            message="Validating..."
                          />
                        ) : order.status === "Fulfilled" ? (
                          <AgentStatusChip status="complete" message="Complete" />
                        ) : (
                          <AgentStatusChip status="idle" message="Pending" />
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          {(order.status === "Processing" ||
                            order.status === "Hold") && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                const orderId = order.orderId;
                                setProcessingProgress((prev) => ({
                                  ...prev,
                                  [orderId]: 0,
                                }));
                                setTimeout(() => {
                                  onProcessOrder?.(orderId);
                                }, 2000);
                              }}
                              disabled={isProcessing}
                            >
                              {isProcessing ? (
                                <Spinner size="sm" className="mr-1" />
                              ) : (
                                <Play className="h-4 w-4 mr-1" />
                              )}
                              Process
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Invoice ID</TableHead>
                  <TableHead className="hidden lg:table-cell">Customer</TableHead>
                  <TableHead className="hidden lg:table-cell">Invoice Date</TableHead>
                  <TableHead>Due Date</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredInvoices.map((invoice) => (
                  <TableRow key={invoice.invoiceId}>
                    <TableCell className="font-mono font-medium">
                      {invoice.invoiceId}
                      <div className="font-sans text-xs font-normal text-muted-foreground lg:hidden">
                        {invoice.customerName}
                      </div>
                    </TableCell>
                    <TableCell className="hidden lg:table-cell">{invoice.customerName}</TableCell>
                    <TableCell className="hidden lg:table-cell">{invoice.invoiceDate}</TableCell>
                    <TableCell>{invoice.dueDate}</TableCell>
                    <TableCell className="font-medium">
                      ${invoice.amount.toLocaleString()}
                    </TableCell>
                    <TableCell>
                      <Badge className={invoiceStatusBadgeClass(invoice.status)}>
                        {invoice.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
      )}
    </div>
  );
}
