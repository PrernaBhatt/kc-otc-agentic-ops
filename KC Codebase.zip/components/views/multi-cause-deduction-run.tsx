"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeft,
  Banknote,
  ChevronDown,
  CircleCheck,
  GitFork,
  Landmark,
  Mail,
  Pencil,
  Route,
  SearchCheck,
  User,
} from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import { Spinner } from "@/components/agents/spinner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { GateSignoffModal } from "@/components/shared/gate-signoff-modal";
import { findAccount } from "@/lib/data/account-owners";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { SystemBadge, SystemMark } from "@/components/shared/system-badge";
import { SourceDocTrigger } from "@/components/modals/source-doc-preview";
import { DisputeLetterComposer } from "@/components/mounts/deductions/dispute-letter-composer";
import { AgentDecision } from "@/components/mounts/deductions/agent-decision";
import { formatUsd } from "@/lib/chargeback-selectors";
import { TODAY } from "@/lib/data/clock";
import { cn } from "@/lib/utils";
import { useOtcStore } from "@/lib/store";

import {
  AiStageNarration,
  narrationDwellMs,
} from "@/components/mounts/chargebacks/ai-stage-narration";
import {
  AgentAuditTrail,
  RunStageRow,
  RUN_STAGE_BODY_CLASS,
  RUN_STAGE_CARD_CLASS,
} from "@/components/mounts/shared/run-stage-row";
import { StageProgressRail } from "@/components/mounts/shared/stage-progress-rail";
import { RunCompleteModal } from "@/components/mounts/shared/run-complete-modal";
import {
  MULTI_CAUSE_DEDUCTION,
  multiCauseApplied,
  multiCauseRouted,
  type RootCause,
} from "@/lib/data/multi-cause-deduction";
import {
  buildRemittanceDoc,
  buildCreditMemoDoc,
  buildPodDoc,
  buildPromotionDoc,
  buildRetailerLetterDoc,
  causeDoc,
  renderMultiCauseLetter,
  MULTI_CAUSE_LETTER_REF,
} from "@/lib/docs-multi-cause";

type SimStatus = "waiting" | "running" | "passed" | "needsReview";

const STAGES = [
  {
    id: "intake",
    label: "Short payment",
    heading: "Payment against the invoice bundle",
    agent: "Cash Matching Agent",
    agentType: "orchestrator",
    icon: Banknote,
    log: "Remittance matched to 12 open invoices. It is short by $140,000.",
  },
  {
    id: "split",
    label: "Root-cause split",
    heading: "One short payment, three causes",
    agent: "Deduction Classification Agent",
    agentType: "validation",
    icon: GitFork,
    log: "The $140,000 gap resolved into three distinct causes, not one residual.",
  },
  {
    id: "evidence",
    label: "Evidence",
    heading: "Evidence gathered per cause",
    agent: "Root Cause Agent",
    agentType: "document",
    icon: SearchCheck,
    log: "Each cause tied to its system of record before any value moves.",
  },
  {
    id: "apply",
    label: "Apply & route",
    heading: "Apply supported value, route the rest",
    agent: "Revenue Accounting Agent",
    agentType: "credit",
    icon: Landmark,
    log: "Cash and the existing credit applied. Two evidence-backed cases routed.",
  },
  {
    id: "letter",
    label: "Retailer response",
    heading: "Response drafted to Kroger",
    agent: "Correspondence Agent",
    agentType: "invoice",
    icon: Mail,
    log: "Response drafted for the two routed deductions. Not yet issued.",
  },
] as const;

interface AgentLog {
  id: string;
  agent: string;
  agentType: string;
  message: string;
  tone: "info" | "attention" | "success";
}

const STAGE_DWELL_MS = 4200;

const asText = (n: string | string[] | undefined) =>
  Array.isArray(n) ? n.join("\n") : (n ?? "");

/* ---------------------------------------------------------------- *
 * Cause presentation helpers
 * ---------------------------------------------------------------- */

const CAUSE_TONE: Record<
  RootCause["disposition"],
  { chip: string; label: string }
> = {
  "apply-now": {
    chip: "bg-[var(--success)]/10 text-[var(--success)]",
    label: "Apply now",
  },
  route: {
    chip: "bg-amber-50 text-amber-800 border border-amber-200",
    label: "Route as a case",
  },
};

/* ---------------------------------------------------------------- *
 * Stage visuals
 * ---------------------------------------------------------------- */

function useMounted(delayMs = 60) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    const id = setTimeout(() => setMounted(true), delayMs);
    return () => clearTimeout(id);
  }, [delayMs]);
  return mounted;
}

/** The remittance against the invoice bundle: paid vs withheld. */
function BundleShortfallBar() {
  const d = MULTI_CAUSE_DEDUCTION;
  const mounted = useMounted();
  const paidPct = (d.cashReceived / d.invoicesOpen) * 100;

  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-3 flex items-baseline justify-between gap-3">
        <h4 className="text-sm font-semibold">Payment against the invoice bundle</h4>
        <span className="whitespace-nowrap text-xs text-muted-foreground">
          {d.remittanceRef} · {d.receivedDate}
        </span>
      </div>

      <div className="flex h-14 w-full overflow-hidden rounded-lg border-2">
        <div
          className="flex items-center justify-center bg-[var(--success)]/25 transition-all duration-700 ease-out motion-reduce:transition-none"
          style={{ width: mounted ? `${paidPct}%` : "0%" }}
        >
          <span className="px-1 text-center text-sm font-semibold text-green-800 tabular-nums">
            {formatUsd(d.cashReceived)} paid
          </span>
        </div>
        <div
          className="flex flex-1 items-center justify-center transition-all duration-500 ease-out motion-reduce:transition-none"
          style={{
            opacity: mounted ? 1 : 0,
            transitionDelay: "600ms",
            backgroundImage:
              "repeating-linear-gradient(45deg, rgba(220,38,38,0.20) 0 6px, transparent 6px 12px)",
          }}
        >
          <span className="px-1 text-center text-sm font-semibold text-red-700 tabular-nums">
            {formatUsd(d.shortPay)} short
          </span>
        </div>
      </div>

      <p className="mt-2 text-xs text-muted-foreground">
        {formatUsd(d.invoicesOpen)} open across {d.invoiceCount} invoices, less{" "}
        {formatUsd(d.shortPay)} withheld, equals {formatUsd(d.cashReceived)}{" "}
        received.
      </p>

      <p className="mt-3 rounded border-l-2 border-muted-foreground/40 bg-muted/30 px-3 py-2 text-xs italic text-muted-foreground">
        &ldquo;{d.customerNote}&rdquo; — remittance note. No line-level reasons,
        no claim references.
      </p>
    </div>
  );
}

/** The $140k gap decomposed into three cause cards. */
function CauseSplitBoard({ withEvidence = false }: { withEvidence?: boolean }) {
  const d = MULTI_CAUSE_DEDUCTION;
  const mounted = useMounted();
  const total = d.shortPay;

  return (
    <div className="space-y-4">
      <div className="rounded-xl border bg-card p-4">
        <div className="mb-3 flex items-baseline justify-between gap-3">
          <h4 className="text-sm font-semibold">
            {formatUsd(total)} short, split by cause
          </h4>
          <span className="text-xs text-muted-foreground">3 causes</span>
        </div>
        <div className="flex h-8 w-full overflow-hidden rounded-lg border">
          {d.causes.map((c, i) => (
            <div
              key={c.id}
              className={cn(
                "flex items-center justify-center border-r text-xs font-semibold tabular-nums transition-all duration-700 ease-out last:border-r-0 motion-reduce:transition-none",
                c.disposition === "apply-now"
                  ? "bg-[var(--success)]/20 text-green-800"
                  : "bg-amber-100 text-amber-800"
              )}
              style={{
                width: mounted ? `${(c.amount / total) * 100}%` : "0%",
                transitionDelay: `${i * 160}ms`,
              }}
            >
              {formatUsd(c.amount)}
            </div>
          ))}
        </div>
      </div>

      <div className="grid gap-3 md:grid-cols-3">
        {d.causes.map((c, i) => (
          <div
            key={c.id}
            className="flex flex-col rounded-xl border bg-card p-4 transition-all duration-400 ease-out motion-reduce:transition-none"
            style={{
              opacity: mounted ? 1 : 0,
              transform: mounted ? "translateY(0)" : "translateY(8px)",
              transitionDelay: `${200 + i * 160}ms`,
            }}
          >
            <div className="mb-2 flex items-start justify-between gap-2">
              <span className="text-sm font-semibold text-foreground">
                {c.title}
              </span>
              <span className="shrink-0 text-sm font-bold tabular-nums">
                {formatUsd(c.amount)}
              </span>
            </div>

            <div className="mb-2 flex flex-wrap items-center gap-1.5">
              {c.systems.map((s, si) => (
                <SystemBadge
                  key={s}
                  name={s}
                  className={cn(
                    "py-0",
                    si === 0 && c.systems.length > 1 && "ring-1 ring-primary/30"
                  )}
                />
              ))}
            </div>

            <p className="mb-3 flex-1 text-xs leading-relaxed text-muted-foreground">
              {withEvidence ? c.finding : c.summary}
            </p>

            <div className="flex items-center justify-between gap-2 border-t pt-2">
              <span className="flex items-center gap-1 text-xs text-muted-foreground">
                <User className="h-3 w-3" />
                {c.owner}
              </span>
              <span className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">
                  {Math.round(c.confidence * 100)}%
                </span>
                <span
                  className={cn(
                    "whitespace-nowrap rounded-full px-2 py-0.5 text-[11px] font-medium",
                    CAUSE_TONE[c.disposition].chip
                  )}
                >
                  {CAUSE_TONE[c.disposition].label}
                </span>
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/** Evidence rows per cause, each tied to a system of record. */
function EvidenceBoard() {
  const d = MULTI_CAUSE_DEDUCTION;
  const mounted = useMounted();

  return (
    <div className="space-y-3">
      {d.causes.map((c, ci) => (
        <div
          key={c.id}
          className="rounded-xl border bg-card p-4 transition-all duration-400 ease-out motion-reduce:transition-none"
          style={{
            opacity: mounted ? 1 : 0,
            transform: mounted ? "translateY(0)" : "translateY(8px)",
            transitionDelay: `${ci * 160}ms`,
          }}
        >
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold">{c.title}</span>
              <span className="text-sm font-bold tabular-nums text-muted-foreground">
                {formatUsd(c.amount)}
              </span>
            </div>
            <span
              className={cn(
                "whitespace-nowrap rounded-full px-2 py-0.5 text-[11px] font-medium",
                CAUSE_TONE[c.disposition].chip
              )}
            >
              {CAUSE_TONE[c.disposition].label} · {c.owner}
            </span>
          </div>

          <div className="space-y-1.5">
            {c.evidence.map((e) => (
              <div
                key={e.label}
                className="flex items-start gap-2.5 rounded-lg border bg-muted/20 px-3 py-2"
              >
                <span className="mt-0.5 flex items-center gap-1.5">
                  <SystemMark name={e.system} />
                </span>
                <div className="min-w-0">
                  <p className="text-xs font-medium text-foreground">
                    {e.label}
                  </p>
                  <p className="text-xs text-muted-foreground">{e.detail}</p>
                </div>
              </div>
            ))}
          </div>

            <p className="mt-3 flex items-start gap-2 rounded-lg bg-[var(--success)]/5 px-3 py-2 text-xs text-foreground">
              <CircleCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[var(--success)]" />
              {c.finding}
            </p>

            <div className="mt-2">
              <SourceDocTrigger
                doc={causeDoc(c.kind)}
                label={`View source: ${causeDoc(c.kind).reference}`}
                variant="outline"
              />
            </div>
          </div>
        ))}
    </div>
  );
}

/** The apply-and-route ledger: what clears now, what leaves as a case. */
function ApplyLedger({
  routed,
  clearedTotal,
  decided,
  onEdit,
  confirmed,
  onConfirm,
}: {
  routed: RootCause[];
  clearedTotal: number;
  decided: boolean;
  onEdit: () => void;
  confirmed: boolean;
  onConfirm: () => void;
}) {
  const d = MULTI_CAUSE_DEDUCTION;
  const routedTotal = routed.reduce((s, c) => s + c.amount, 0);
  const creditCause = d.causes.find((c) => c.kind === "credit")!;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <div className="rounded-lg border border-[var(--success)]/30 bg-[var(--success)]/5 p-3">
          <p className="text-xs text-muted-foreground">Cleared now</p>
          <p className="text-xl font-bold tabular-nums text-green-800">
            {formatUsd(clearedTotal)}
          </p>
          <p className="mt-1 text-xs text-muted-foreground">
            cash + existing credit
          </p>
        </div>
        <div className="rounded-lg border border-amber-200 bg-amber-50/60 p-3">
          <p className="text-xs text-amber-800">Routed as cases</p>
          <p className="text-xl font-bold tabular-nums text-amber-900">
            {formatUsd(routedTotal)}
          </p>
          <p className="mt-1 text-xs text-amber-800">
            {routed.length} case{routed.length === 1 ? "" : "s"}, evidence attached
          </p>
        </div>
        <div className="rounded-lg border bg-card p-3">
          <p className="text-xs text-muted-foreground">Short payment</p>
          <p className="text-xl font-bold tabular-nums">
            {formatUsd(d.shortPay)}
          </p>
          <p className="mt-1 text-xs text-muted-foreground">total gap, 3 causes</p>
        </div>
      </div>

      <div className="rounded-xl border bg-card p-4">
        <h4 className="mb-3 text-sm font-semibold">Applied now</h4>
        <div className="space-y-2">
          <LedgerRow
            label="Cash received against the bundle"
            value={formatUsd(d.cashReceived)}
            system="HighRadius"
          />
          <LedgerRow
            label="Existing credit CM-88213 applied"
            value={formatUsd(creditCause.amount)}
            system="SAP"
          />
          <div className="flex items-center justify-between gap-3 rounded-lg bg-[var(--success)]/10 px-3 py-2.5">
            <span className="text-sm font-semibold text-green-800">
              Cleared on the invoice bundle
            </span>
            <span className="text-sm font-bold tabular-nums text-green-800">
              {formatUsd(clearedTotal)}
            </span>
          </div>
        </div>
        <p className="mt-2 text-xs text-muted-foreground">
          The credit was already issued — applying it clears the line without
          paying Kroger a second time.
        </p>
      </div>

      <div className="rounded-xl border bg-card p-4">
        <h4 className="mb-3 flex items-center gap-2 text-sm font-semibold">
          <Route className="h-4 w-4 text-muted-foreground" />
          Routed as evidence-backed cases
        </h4>
        <div className="space-y-2">
          {routed.map((c) => (
            <div
              key={c.id}
              className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-amber-200 bg-amber-50/60 px-3 py-2.5"
            >
              <div className="min-w-0">
                <p className="text-sm font-medium text-amber-900">{c.title}</p>
                <p className="flex items-center gap-1 text-xs text-amber-800">
                  <User className="h-3 w-3" />
                  {c.owner}
                  <span className="mx-1 text-amber-300">·</span>
                  {c.systems.join(", ")}
                </p>
              </div>
              <span className="text-sm font-bold tabular-nums text-amber-900">
                {formatUsd(c.amount)}
              </span>
            </div>
          ))}
          {routed.length === 0 && (
            <p className="rounded-lg border border-dashed px-3 py-2.5 text-xs text-muted-foreground">
              Nothing left open — every cause is applied now.
            </p>
          )}
          <div className="flex items-center justify-between gap-3 px-3 py-1 text-xs text-muted-foreground">
            <span>Left open, each with its evidence attached</span>
            <span className="font-semibold tabular-nums">
              {formatUsd(routedTotal)}
            </span>
          </div>
        </div>
      </div>

      {!confirmed ? (
        decided ? (
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border-2 border-amber-200 bg-amber-50/60 px-3 py-2.5">
            <p className="text-xs text-amber-900">
              Decided by you — apply {formatUsd(clearedTotal)} and route{" "}
              {formatUsd(routedTotal)} across {routed.length} case
              {routed.length === 1 ? "" : "s"}. Nothing posts until you confirm.
            </p>
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="outline"
                className="gap-1.5 whitespace-nowrap"
                onClick={onEdit}
              >
                <Pencil className="h-3.5 w-3.5" />
                Edit
              </Button>
              <Button size="sm" onClick={onConfirm} className="whitespace-nowrap">
                Apply {formatUsd(clearedTotal)} · route {routed.length}
              </Button>
            </div>
          </div>
        ) : (
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border-2 border-amber-200 bg-amber-50/60 px-3 py-2.5">
            <p className="text-xs text-amber-900">
              Awaiting your decision. Nothing is recorded until you click.
            </p>
            <div className="flex flex-wrap items-center gap-2">
              <Button
                size="sm"
                variant="outline"
                className="gap-1.5 whitespace-nowrap"
                onClick={onEdit}
              >
                <Pencil className="h-3.5 w-3.5" />
                Edit
              </Button>
              <Button size="sm" onClick={onConfirm} className="whitespace-nowrap">
                Apply {formatUsd(clearedTotal)} · route {routed.length}
              </Button>
            </div>
          </div>
        )
      ) : (
        <p className="flex items-center gap-1.5 text-xs text-[var(--success)]">
          <CircleCheck className="h-3.5 w-3.5" />
          {formatUsd(clearedTotal)} applied in SAP and HighRadius. {routed.length}{" "}
          case{routed.length === 1 ? "" : "s"} routed with evidence.
        </p>
      )}
    </div>
  );
}

function CauseDecisionEditModal({
  causes,
  decisions,
  onChange,
  onConfirm,
  onReset,
  onClose,
}: {
  causes: RootCause[];
  decisions: Record<string, RootCause["disposition"]>;
  onChange: (id: string, value: RootCause["disposition"]) => void;
  onConfirm: () => void;
  onReset: () => void;
  onClose: () => void;
}) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-6 backdrop-blur-sm"
      onClick={onClose}
      role="presentation"
    >
      <div
        className="w-full max-w-lg rounded-xl border bg-card shadow-2xl"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
        aria-label="Edit the cause split"
      >
        <div className="border-b px-5 py-3">
          <div className="text-sm font-semibold">Edit the cause split</div>
          <div className="text-xs text-muted-foreground">
            Each cause can be applied now or routed as a case, per your
            judgment.
          </div>
        </div>
        <div className="space-y-3 px-5 py-4">
          {causes.map((c) => {
            const disabled = c.kind === "credit";
            const value = decisions[c.id];
            return (
              <div
                key={c.id}
                className="flex flex-wrap items-center justify-between gap-3 rounded-lg border p-3"
              >
                <div className="min-w-0">
                  <p className="text-sm font-medium">{c.title}</p>
                  <p className="text-xs text-muted-foreground">
                    {formatUsd(c.amount)} · {c.owner}
                    {disabled ? " · dedupe, not editable" : ""}
                  </p>
                </div>
                <div className="flex shrink-0 overflow-hidden rounded-md border">
                  <button
                    type="button"
                    disabled={disabled}
                    onClick={() => onChange(c.id, "apply-now")}
                    className={cn(
                      "px-3 py-1.5 text-xs font-medium transition-colors",
                      value === "apply-now"
                        ? "bg-[var(--success)]/15 text-green-800"
                        : "bg-background text-muted-foreground hover:bg-muted",
                      disabled && "cursor-not-allowed opacity-70"
                    )}
                  >
                    Apply now
                  </button>
                  <button
                    type="button"
                    disabled={disabled}
                    onClick={() => onChange(c.id, "route")}
                    className={cn(
                      "px-3 py-1.5 text-xs font-medium transition-colors",
                      value === "route"
                        ? "bg-amber-100 text-amber-900"
                        : "bg-background text-muted-foreground hover:bg-muted",
                      disabled && "cursor-not-allowed opacity-70"
                    )}
                  >
                    Route as case
                  </button>
                </div>
              </div>
            );
          })}
        </div>
        <div className="flex items-center justify-between gap-3 border-t bg-muted/20 px-5 py-3">
          <button
            type="button"
            onClick={onReset}
            className="text-xs text-muted-foreground underline-offset-2 hover:text-foreground hover:underline"
          >
            Reset to AI recommendation
          </button>
          <Button size="sm" onClick={onConfirm} className="whitespace-nowrap">
            <CircleCheck className="h-4 w-4" />
            Confirm changes
          </Button>
        </div>
      </div>
    </div>
  );
}

function LedgerRow({
  label,
  value,
  system,
}: {
  label: string;
  value: string;
  system: string;
}) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-lg border bg-muted/20 px-3 py-2">
      <span className="flex min-w-0 items-center gap-2 text-sm text-foreground">
        <SystemMark name={system} />
        <span className="truncate">{label}</span>
      </span>
      <span className="shrink-0 text-sm font-semibold tabular-nums">
        {value}
      </span>
    </div>
  );
}

/* ---------------------------------------------------------------- *
 * The run
 * ---------------------------------------------------------------- */

export function MultiCauseDeductionRun({ onBack }: { onBack: () => void }) {
  const { resolveMultiCauseDeduction } = useOtcStore();
  const d = MULTI_CAUSE_DEDUCTION;
  const routed = useMemo(() => multiCauseRouted(d), [d]);
  const clearedTotal = multiCauseApplied(d);
  const creditCause = d.causes.find((c) => c.kind === "credit")!;

  const narration = useMemo<Record<string, string | string[]>>(
    () => ({
      intake: `Kroger paid ${formatUsd(d.cashReceived)} against ${formatUsd(
        d.invoicesOpen
      )} of open invoices. The ${formatUsd(
        d.shortPay
      )} short carries no line-level reasons — this is not one residual to write off.`,
      split: [
        `The ${formatUsd(d.shortPay)} resolves into three separate causes with separate owners.`,
        `${formatUsd(d.causes[0].amount)} is a credit already issued, ${formatUsd(
          d.causes[1].amount
        )} a promotion allowance, ${formatUsd(
          d.causes[2].amount
        )} a freight claim.`,
      ],
      evidence: `Each cause is tied to its system of record before any value moves: SAP for the credit, Vistex for the promotion, SAP and FourKites for the freight.`,
      apply: `Apply ${formatUsd(d.cashReceived)} cash and the ${formatUsd(
        d.causes[0].amount
      )} existing credit now — ${formatUsd(
        clearedTotal
      )} cleared — and open the promotion and freight pieces as evidence-backed cases.`,
      letter: `One response to Kroger covers all three: the ${formatUsd(
        d.causes[0].amount
      )} credit applied, and the ${formatUsd(
        d.shortPay - d.causes[0].amount
      )} promotion and freight items under review. Drafted for your approval before it is sent.`,
    }),
    [d, clearedTotal, routed]
  );

  const [statuses, setStatuses] = useState<Record<string, SimStatus>>(() =>
    Object.fromEntries(STAGES.map((s) => [s.id, "waiting" as SimStatus]))
  );
  const [processing, setProcessing] = useState(false);
  const [logs, setLogs] = useState<AgentLog[]>([]);
  const [openStages, setOpenStages] = useState<Set<string>>(new Set());
  const [activeStage, setActiveStage] = useState<string | null>(null);
  const [awaitingAdvance, setAwaitingAdvance] = useState(false);
  const [applied, setApplied] = useState(false);
  const [letterSent, setLetterSent] = useState(false);
  const [sentOn, setSentOn] = useState<string | undefined>(undefined);
  const [finaleDismissed, setFinaleDismissed] = useState(false);
  const [decisions, setDecisions] = useState<
    Record<string, RootCause["disposition"]>
  >(() => Object.fromEntries(d.causes.map((c) => [c.id, c.disposition])));
  const [decided, setDecided] = useState(false);
  const [applySignOpen, setApplySignOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);

  const advanceRef = useRef<(() => void) | null>(null);
  const startedRef = useRef(false);
  const appliedRef = useRef(false);
  const letterRef = useRef(false);
  const decidedRef = useRef(false);
  const cardRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const narrationRef = useRef(narration);
  narrationRef.current = narration;

  const decidedRouted = useMemo(
    () => d.causes.filter((c) => decisions[c.id] === "route"),
    [d, decisions]
  );
  const decidedApplied = useMemo(() => {
    const credit = d.causes
      .filter((c) => decisions[c.id] === "apply-now")
      .reduce((sum, c) => sum + c.amount, 0);
    return d.cashReceived + credit;
  }, [d, decisions]);

  const openStage = useCallback((stageId: string) => {
    setOpenStages(new Set([stageId]));
    setActiveStage(stageId);
  }, []);

  const addLog = useCallback((stageId: string, tone: AgentLog["tone"]) => {
    const stage = STAGES.find((s) => s.id === stageId)!;
    setLogs((prev) => [
      ...prev,
      {
        id: `${stageId}-${prev.length}`,
        agent: stage.agent,
        agentType: stage.agentType,
        message: stage.log,
        tone,
      },
    ]);
  }, []);

  const runFrom = useCallback(
    async (startId: string) => {
      setProcessing(true);
      const startAt = Math.max(
        0,
        STAGES.findIndex((s) => s.id === startId)
      );
      for (const stage of STAGES.slice(startAt)) {
        // The apply stage commits money and opens cases — it is a gate.
        if (stage.id === "apply") {
          setStatuses((prev) => ({ ...prev, apply: "needsReview" }));
          openStage("apply");
          addLog("apply", "attention");
          setProcessing(false);
          return;
        }

        // The response to Kroger is issued only on a person's approval.
        if (stage.id === "letter" && !letterRef.current) {
          setStatuses((prev) => ({ ...prev, letter: "needsReview" }));
          openStage("letter");
          addLog("letter", "attention");
          setProcessing(false);
          return;
        }

        setStatuses((prev) => ({ ...prev, [stage.id]: "running" }));
        openStage(stage.id);

        let marked = false;
        const markPassed = () => {
          if (marked) return;
          marked = true;
          setStatuses((prev) => ({ ...prev, [stage.id]: "passed" }));
          addLog(stage.id, "info");
        };
        const dwell = setTimeout(
          markPassed,
          narrationDwellMs(asText(narrationRef.current[stage.id]), STAGE_DWELL_MS)
        );

        const advanced = new Promise<void>((resolve) => {
          advanceRef.current = resolve;
        });
        setAwaitingAdvance(true);
        await advanced;
        setAwaitingAdvance(false);

        clearTimeout(dwell);
        markPassed();
      }
    },
    [addLog, openStage]
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Enter") return;
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      if (!advanceRef.current) return;
      e.preventDefault();
      const go = advanceRef.current;
      advanceRef.current = null;
      go();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    if (startedRef.current) return;
    startedRef.current = true;
    void runFrom("intake");
  }, [runFrom]);

  useEffect(() => {
    if (!activeStage) return;
    const node = cardRefs.current[activeStage];
    if (!node) return;
    const reduce =
      typeof window !== "undefined" &&
      window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    node.scrollIntoView({
      behavior: reduce ? "auto" : "smooth",
      block: "center",
    });
  }, [activeStage]);

  const confirmApply = useCallback(() => {
    if (appliedRef.current) return;
    appliedRef.current = true;
    setApplied(true);
    setStatuses((prev) => ({ ...prev, apply: "passed" }));
    addLog("apply", "success");
  }, [addLog]);

  const setCauseDecision = useCallback(
    (id: string, value: RootCause["disposition"]) => {
      setDecisions((prev) => ({ ...prev, [id]: value }));
    },
    []
  );

  const resetDecisions = useCallback(() => {
    setDecisions(
      Object.fromEntries(d.causes.map((c) => [c.id, c.disposition]))
    );
  }, [d]);

  const confirmDecisions = useCallback(() => {
    decidedRef.current = true;
    setDecided(true);
    setEditOpen(false);
  }, []);

  const sendLetter = useCallback(() => {
    if (letterRef.current) return;
    letterRef.current = true;
    setSentOn(TODAY);
    setLetterSent(true);
    setStatuses((prev) => ({ ...prev, letter: "passed" }));
    addLog("letter", "success");
    setActiveStage(null);
    resolveMultiCauseDeduction(d.caseId);
  }, [addLog, resolveMultiCauseDeduction, d.caseId]);

  // Once the posting is confirmed, draft the retailer response.
  useEffect(() => {
    if (!applied) return;
    void runFrom("letter");
  }, [applied, runFrom]);

  const reached = STAGES.filter((s) => statuses[s.id] !== "waiting").map(
    (s) => s.id
  );
  const doneCount = STAGES.filter((s) => statuses[s.id] === "passed").length;

  const renderBody = (stageId: string) => {
    switch (stageId) {
      case "intake":
        return (
          <div className="space-y-3">
            <BundleShortfallBar />
            <SourceDocTrigger
              doc={buildRemittanceDoc()}
              label={`View remittance ${d.remittanceRef}`}
            />
          </div>
        );
      case "split":
        return <CauseSplitBoard />;
      case "evidence":
        return <EvidenceBoard />;
      case "apply":
        return (
          <AgentDecision
            stepKey={`${d.caseId}:apply`}
            lines={[
              `${formatUsd(d.cashReceived)} cash and the ${formatUsd(
                creditCause.amount
              )} credit already issued can clear the bundle now.`,
              `The promotion and freight pieces need their owners' evidence before any value moves.`,
              `Decision: apply ${formatUsd(decidedApplied)}, route ${formatUsd(
                decidedRouted.reduce((s, c) => s + c.amount, 0)
              )} as ${decidedRouted.length} case${
                decidedRouted.length === 1 ? "" : "s"
              }.`,
            ]}
          >
            <ApplyLedger
              routed={decidedRouted}
              clearedTotal={decidedApplied}
              decided={decided}
              onEdit={() => setEditOpen(true)}
              confirmed={applied}
              onConfirm={() => setApplySignOpen(true)}
            />
            <GateSignoffModal
              open={applySignOpen}
              onClose={() => setApplySignOpen(false)}
              gateId={`${d.caseId}:G1`}
              title="Apply cash and route the remaining causes"
              documentNo={`${d.caseId} · application`}
              caseId={d.caseId}
              accountId={findAccount(d.customerName)?.accountId ?? ""}
              module="Deductions"
              system="SAP FSCM"
              controls={["1.4.5", "1.4.4"]}
              evidence={[
                { id: "cash", label: `Cash received ${formatUsd(d.cashReceived)}`, system: "SAP FSCM" },
                { id: "cm", label: "Credit memo CM-88213", system: "SAP S/4HANA", doc: buildCreditMemoDoc() },
                { id: "promo", label: "Promotion VX-Q3-2214", system: "Vistex", doc: buildPromotionDoc() },
                { id: "pod", label: "Proof of delivery SHP-55120", system: "SAP S/4HANA", doc: buildPodDoc() },
              ]}
              lines={[
                { label: "Applied now", amountUsd: decidedApplied, kind: "other" },
                ...decidedRouted.map((r) => ({ label: `Routed · ${r.title}`, amountUsd: r.amount, kind: "other" as const })),
              ]}
              attestation={`I approve applying ${formatUsd(decidedApplied)} on ${d.caseId} and routing the remaining causes to their owners.`}
              confirmLabel="Confirm decision"
              action={`Applied ${formatUsd(decidedApplied)}, routed ${decidedRouted.length} cause${decidedRouted.length === 1 ? "" : "s"}`}
              decision="Partially applied"
              onSigned={() => {
                setApplySignOpen(false);
                confirmApply();
              }}
            />
          </AgentDecision>
        );
      case "letter": {
        const letter = renderMultiCauseLetter();
        return (
          <DisputeLetterComposer
            letterKey={d.caseId}
            from="Order to Cash — Deduction Management <deductions@internal.example>"
            to={`${d.customerName} Accounts Payable <ap@kroger.example>`}
            subject={letter.subject}
            body={letter.body}
            attachments={[
              { doc: buildCreditMemoDoc(), label: "Credit memo CM-88213" },
              { doc: buildPromotionDoc(), label: "Promotion VX-Q3-2214" },
              { doc: buildPodDoc(), label: "Proof of delivery SHP-55120" },
              {
                doc: buildRetailerLetterDoc(letterSent),
                label: "Letter as a document",
              },
            ]}
            sent={letterSent}
            sentDate={sentOn}
            sentNote={`Issued to ${d.customerName} accounts payable. The ${formatUsd(
              creditCause.amount
            )} credit is applied; supporting backup for the remaining ${formatUsd(
              decidedRouted.reduce((s, c) => s + c.amount, 0)
            )} requested within 30 days.`}
            canSend={statuses.letter === "needsReview"}
            blockedNote="Apply the posting first."
            onSend={sendLetter}
          />
        );
      }
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <button
            type="button"
            onClick={onBack}
            className="mb-1 inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            All deductions
          </button>
          <h2 className="text-xl font-semibold">
            {d.caseId} — {d.customerName}
          </h2>
          <p className="text-sm text-muted-foreground">
            A short payment split into its root causes. Supported value is
            applied at once; everything disputable leaves as an evidence-backed
            case for its owner. The posting is approved by a person.
          </p>
        </div>
        {processing && !awaitingAdvance && (
          <span className="flex items-center gap-2 text-sm text-muted-foreground">
            <Spinner size="sm" />
            Investigation in progress
          </span>
        )}
      </div>

      <Card className="bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="flex flex-wrap items-center gap-2 text-sm font-semibold">
            <Badge variant="outline" className="whitespace-nowrap">
              {formatUsd(d.shortPay)} short on {formatUsd(d.invoicesOpen)}
            </Badge>
            <span className="text-xs font-normal text-muted-foreground">
              {doneCount}/{STAGES.length} steps cleared
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-2">
          <StageProgressRail
            stages={STAGES}
            statuses={statuses}
            openStageId={activeStage}
            onStageClick={(id) => {
              if ((reached as string[]).includes(id)) openStage(id);
            }}
          />
        </CardContent>
      </Card>

      {reached.length === 0 ? (
        <Card className="bg-card">
          <CardContent className="p-8 text-center">
            <p className="text-sm text-muted-foreground">
              Investigation starting.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-[minmax(0,1fr)_280px]">
          <div className="min-w-0 space-y-2">
            {STAGES.filter((s) => reached.includes(s.id)).map((stage) => {
              const open = openStages.has(stage.id);
              const status = statuses[stage.id];
              return (
                <Card
                  key={stage.id}
                  ref={(node) => {
                    cardRefs.current[stage.id] = node;
                  }}
                  className={RUN_STAGE_CARD_CLASS}
                >
                  <RunStageRow
                    label={stage.heading}
                    status={status}
                    expanded={open}
                    summary={stage.log}
                    onToggle={() =>
                      setOpenStages((prev) => {
                        const next = new Set(prev);
                        if (next.has(stage.id)) next.delete(stage.id);
                        else next.add(stage.id);
                        return next;
                      })}
                  />
                  {open && (
                    <div className={RUN_STAGE_BODY_CLASS}>
                      {stage.id !== "apply" && (
                        <AiStageNarration
                          key={stage.id}
                          text={narration[stage.id]}
                        />
                      )}
                      {renderBody(stage.id)}
                    </div>
                  )}
                </Card>
              );
            })}
          </div>

          <AgentAuditTrail entries={logs} />
        </div>
      )}

      {letterSent && !finaleDismissed && (
        <RunCompleteModal
          eyebrow="Short payment resolved"
          title="One payment, three causes, one clean posting"
          narrative={`${formatUsd(decidedApplied)} of the ${formatUsd(
            d.invoicesOpen
          )} bundle cleared immediately — cash plus a credit that already existed in SAP. The ${formatUsd(
            decidedRouted.reduce((s, c) => s + c.amount, 0)
          )} that is genuinely disputable left as ${decidedRouted.length} evidence-backed case${
            decidedRouted.length === 1 ? "" : "s"
          } routed to their owners, and one response letter to ${d.customerName} covers all three.`}
          stats={[
            {
              label: "Cleared now",
              value: formatUsd(decidedApplied),
              tone: "success",
            },
            {
              label: "Existing credit reused",
              value: formatUsd(creditCause.amount),
              tone: "success",
            },
            {
              label: "Routed with evidence",
              value: formatUsd(decidedRouted.reduce((s, c) => s + c.amount, 0)),
            },
            { label: "Duplicate credits issued", value: "0", tone: "success" },
          ]}
          docs={[
            { doc: buildRemittanceDoc(), label: `Remittance ${d.remittanceRef}` },
            { doc: buildCreditMemoDoc(), label: "Credit memo CM-88213" },
            { doc: buildPromotionDoc(), label: "Promotion VX-Q3-2214" },
            { doc: buildPodDoc(), label: "Proof of delivery SHP-55120" },
            {
              doc: buildRetailerLetterDoc(true),
              label: `Response letter ${MULTI_CAUSE_LETTER_REF}`,
            },
          ]}
          primaryLabel="Back to deductions"
          onPrimary={onBack}
          secondaryLabel="Review the run"
          onSecondary={() => setFinaleDismissed(true)}
        />
      )}

      {editOpen && (
        <CauseDecisionEditModal
          causes={d.causes}
          decisions={decisions}
          onChange={setCauseDecision}
          onConfirm={confirmDecisions}
          onReset={resetDecisions}
          onClose={() => setEditOpen(false)}
        />
      )}

      <KpiPanel />
    </div>
  );
}

/* ---------------------------------------------------------------- *
 * KPIs demonstrated
 * ---------------------------------------------------------------- */

function KpiPanel() {
  const items = [
    {
      title: "Root-cause split, not one residual",
      body: "The $140K gap was separated into a credit, a promotion and a freight claim — each with its own confidence, evidence and owner.",
    },
    {
      title: "Existing credit checked before new value",
      body: "SAP was searched first: a $35K credit already existed under a transposed reference, so it was applied instead of paying twice.",
    },
    {
      title: "Evidence pulled from the right system",
      body: "Vistex for the promotion fund and proof-of-performance; SAP and FourKites for the delivery and POD.",
    },
    {
      title: "Right owner for each piece",
      body: "Trade takes the promotion, Logistics the freight, Cash Application the credit — nothing sits in a generic queue.",
    },
    {
      title: "One response, evidence attached",
      body: "A single letter back to Kroger explains all three items and carries the credit memo, promotion and proof of delivery — issued only on a person's approval.",
    },
  ];

  return (
    <Card className="border-dashed bg-muted/20">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-semibold">
          KPIs demonstrated
        </CardTitle>
      </CardHeader>
      <CardContent className="grid gap-3 md:grid-cols-2">
        {items.map((it) => (
          <div key={it.title} className="flex gap-2.5">
            <CircleCheck className="mt-0.5 h-4 w-4 shrink-0 text-[var(--success)]" />
            <div className="min-w-0">
              <p className="text-xs font-semibold text-foreground">
                {it.title}
              </p>
              <p className="text-xs leading-relaxed text-muted-foreground">
                {it.body}
              </p>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
