"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeft,
  Compass,
  FileSearch,
  Landmark,
  Mail,
  PenLine,
  Scale,
  Wallet,
} from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import { Button } from "@/components/ui/button";
import { AiStageNarration } from "@/components/mounts/chargebacks/ai-stage-narration";
import { DisputeLetterComposer } from "@/components/mounts/deductions/dispute-letter-composer";
import { CauseBoard } from "@/components/mounts/billing-dispute/cause-board";
import { OriginalInvoiceLock } from "@/components/mounts/billing-dispute/original-invoice-lock";
import { PostingChecks } from "@/components/mounts/billing-dispute/posting-checks";
import { Remittance820Panel } from "@/components/mounts/billing-dispute/remittance-820-panel";
import { SettlementSplit } from "@/components/mounts/billing-dispute/settlement-split";
import { UpstreamFixPanel } from "@/components/mounts/billing-dispute/upstream-fix-panel";
import { RunAgentLog } from "@/components/mounts/shared/run-agent-log";
import { RunCompleteModal } from "@/components/mounts/shared/run-complete-modal";
import { RunStageCard, type RunStageMeta } from "@/components/mounts/shared/run-stage-card";
import { StageProgressRail } from "@/components/mounts/shared/stage-progress-rail";
import { useFollowLatest } from "@/components/mounts/shared/use-follow-latest";
import { useStagedRun } from "@/components/mounts/shared/use-staged-run";
import { ControlTags } from "@/components/shared/control-tag";
import { FillFields } from "@/components/shared/fill-fields";
import { GateSignoffModal } from "@/components/shared/gate-signoff-modal";
import { OwnerChip } from "@/components/shared/owner-chip";
import { billingDispute } from "@/lib/billing-dispute-selectors";
import { findAccount } from "@/lib/data/account-owners";
import {
  buildCauseEvidenceDoc,
  buildChargeBackDoc,
  buildCreditMemoDoc,
  buildDisputeCaseDoc,
  buildInvoiceDoc,
  buildRemittanceDoc,
  disputeLetter,
} from "@/lib/docs-billing-dispute";
import { formatUsd } from "@/lib/format";
import { useOtcStore } from "@/lib/store";

const ORDER = ["capture", "cause", "settle", "sign", "post", "upstream", "notify"] as const;
type StageId = (typeof ORDER)[number];
const GATES = ["sign"] as const satisfies readonly StageId[];
const HOLDS = ["notify"] as const satisfies readonly StageId[];

const ICONS = {
  capture: Wallet,
  cause: FileSearch,
  settle: Scale,
  sign: PenLine,
  post: Landmark,
  upstream: Compass,
  notify: Mail,
} as const;

const AGENT_TYPES: Record<StageId, string> = {
  capture: "billing",
  cause: "pricing",
  settle: "credit",
  sign: "orchestrator",
  post: "invoice",
  upstream: "orchestrator",
  notify: "document",
};

/**
 * Scenario 5: Costco short-pays a right invoice. The difference is worked as
 * an FSCM dispute on the original invoice: four causes judged, K-C-right
 * causes charged back, Costco-right causes credited, every cause sent back
 * upstream. The invoice itself is never reissued.
 */
export function BillingDisputeRun({ caseId, onBack }: { caseId: string; onBack: () => void }) {
  const { appendAudit, raiseEscalation, resolveBillingDispute } = useOtcStore();
  const figures = billingDispute(caseId);
  const account = figures ? findAccount(figures.case.accountId) : undefined;
  const ownerName = account?.owner.name ?? "";

  const [signOpen, setSignOpen] = useState(false);
  const [notified, setNotified] = useState(false);
  const [postChecked, setPostChecked] = useState(false);
  const [finaleDismissed, setFinaleDismissed] = useState(false);
  const cardRefs = useRef<Record<string, HTMLDivElement | null>>({});

  const stages: Record<StageId, RunStageMeta> = useMemo(() => {
    if (!figures) return {} as Record<StageId, RunStageMeta>;
    const c = figures.case;
    const kcCount = figures.causes.filter((x) => x.verdict === "kc").length;
    return {
      capture: { id: "capture", label: "Short-pay", heading: `Short-pay captured on ${c.invoiceId}`, agent: "Cash Application Agent", summary: `Short-paid ${formatUsd(figures.shortPaid)} on ${c.invoiceId} · dispute case opened` },
      cause: { id: "cause", label: "Root cause", heading: "Four causes checked against the systems of record", agent: "Dispute Investigation Agent", summary: `Four causes checked · K-C right on ${kcCount}, Costco on ${figures.causes.length - kcCount}` },
      settle: { id: "settle", label: "Settlement", heading: "Charge-back and credit note drafted", agent: "Dispute Resolution Agent", summary: "Charge-back and credit note drafted" },
      sign: { id: "sign", label: "Sign-off", heading: `Sign-off by ${ownerName}`, agent: `${ownerName} · Controller co-sign above limit`, summary: `Signed by ${ownerName} and L. Chen` },
      post: { id: "post", label: "Post in FSCM", heading: "Posted in FSCM against the original invoice", agent: "FSCM Posting Agent", summary: "Posted in FSCM · original invoice unchanged" },
      upstream: { id: "upstream", label: "Fix upstream", heading: "Causes sent back to Pricing and Master data", agent: "Root Cause Agent", summary: "Causes sent to Pricing and Master data" },
      notify: { id: "notify", label: "Notify Costco", heading: "Dispute response to Costco", agent: "Correspondence Agent", summary: "Costco notified with backup" },
    };
  }, [figures, ownerName]);

  const log = useCallback(
    (agent: string, action: string, extra: { controlRefs?: string[]; amountUsd?: number; evidence?: string[]; system?: string } = {}) => {
      if (!figures) return;
      appendAudit({
        caseId,
        accountId: figures.case.accountId,
        module: "Billing",
        actor: { kind: "agent", name: agent, role: `Agent · works for ${ownerName}` },
        action,
        controlRefs: extra.controlRefs ?? [],
        amountUsd: extra.amountUsd,
        evidence: extra.evidence ?? [],
        system: extra.system ?? "SAP FSCM",
      });
    },
    [appendAudit, caseId, figures, ownerName]
  );

  const onStart = useCallback(
    (id: StageId) => {
      if (!figures) return;
      const c = figures.case;
      if (id === "capture") log("Cash Application Agent", `Read EDI 820 ${c.remittanceId}: ${figures.causes.length} deduction lines on ${c.invoiceId}`, { amountUsd: figures.shortPaid, evidence: [c.remittanceId], system: "EDI 820" });
      if (id === "cause") log("Dispute Investigation Agent", "Queried SAP, PricerX, Vistex, SAP TM and Vertex for each cause", { controlRefs: ["1.7.1"], evidence: figures.causes.flatMap((x) => x.evidence) });
      if (id === "settle") log("Dispute Resolution Agent", `Drafted ${c.chargeBackId} ${formatUsd(figures.chargeBack)} and ${c.creditMemoRequestId} ${formatUsd(figures.credit)}`, { amountUsd: figures.shortPaid, evidence: [c.chargeBackId, c.creditMemoRequestId] });
      if (id === "sign") setSignOpen(true);
      if (id === "post") log("FSCM Posting Agent", `Posted ${c.creditMemoId} to ${c.invoiceId}; ${c.chargeBackId} left as residual for Collections`, { amountUsd: figures.shortPaid, evidence: [c.creditMemoId, c.chargeBackId] });
      if (id === "upstream") {
        c.upstream.forEach((u) => log("Root Cause Agent", `Created ${u.id}: ${u.title}`, { controlRefs: [u.controlRef], evidence: [u.id], system: u.system }));
        c.escalationIds.forEach((e) => raiseEscalation(e));
        log("Root Cause Agent", `Raised ${c.escalationIds.join(" and ")} to Commercial and Supply chain`, { evidence: c.escalationIds });
      }
      if (id === "notify") log("Correspondence Agent", `Drafted dispute response ${c.letterId} to Costco AP`, { evidence: [c.letterId, c.creditMemoId, c.chargeBackId], system: "Outlook" });
    },
    [figures, log, raiseEscalation]
  );

  const run = useStagedRun<StageId>({ order: ORDER, gates: GATES, holds: HOLDS, onStart });
  const passHoldRef = useRef(run.passHold);
  passHoldRef.current = run.passHold;
  const startRun = run.start;
  useEffect(() => {
    startRun("capture");
  }, [startRun]);

  const ready = useMemo(
    () => Object.fromEntries(ORDER.map((id) => [id, () => run.markReady(id)])) as Record<StageId, () => void>,
    // markReady is stable
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  useFollowLatest(() => (run.active ? cardRefs.current[run.active] ?? null : null), run.active);

  if (!figures || !account) return null;
  const c = figures.case;
  const letter = disputeLetter(caseId);
  const done = run.complete;

  const handleSend = () => {
    if (notified) return;
    setNotified(true);
    log("Correspondence Agent", `Sent ${c.letterId} to Costco AP under ${ownerName}'s signed decision`, { evidence: [c.letterId], system: "Outlook" });
    resolveBillingDispute(caseId);
    setTimeout(() => passHoldRef.current("notify"), 400);
  };

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Button variant="outline" size="sm" onClick={onBack} className="gap-1.5">
          <ArrowLeft className="h-4 w-4" /> Back to Billing
        </Button>
        <div className="flex flex-wrap items-center gap-3">
          <span className="font-mono text-base font-semibold" data-dispute-case={c.caseId}>
            {c.caseId}
          </span>
          <span className="text-sm text-muted-foreground">
            {c.customerName} · {formatUsd(figures.shortPaid)} on {c.invoiceId}
          </span>
          <OwnerChip account={c.accountId} />
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
        <span>Agents working for {ownerName.split(" ")[0]}</span>
        <span className="flex items-center -space-x-1">
          {ORDER.filter((id) => id !== "sign").map((id) => (
            <span key={id} className="rounded-full bg-background ring-2 ring-background" title={stages[id].agent}>
              <AgentIcon type={AGENT_TYPES[id]} size="sm" className="text-primary" />
            </span>
          ))}
        </span>
        <OriginalInvoiceLock invoiceId={c.invoiceId} amount={figures.invoiceTotal} periodClosedOn={c.periodClosedOn} />
      </div>

      <StageProgressRail
        stages={ORDER.map((id) => ({ id, label: stages[id].label, icon: ICONS[id] }))}
        statuses={run.statuses}
        openStageId={run.active}
        onStageClick={(id) => run.focus(id)}
      />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-[minmax(0,1fr)_300px]">
        <div className="flex min-w-0 flex-col gap-4">
          {ORDER.map((id) => {
            const status = run.statuses[id];
            if (status === "waiting") return null;
            return (
              <RunStageCard
                key={id}
                ref={(el) => {
                  cardRefs.current[id] = el;
                }}
                stage={stages[id]}
                status={status}
                open={run.open.has(id)}
                ready={run.ready.has(id)}
                canContinue={run.active === id && run.canAdvance && id !== "notify"}
                onToggle={() => run.toggle(id)}
                onContinue={run.advance}
                headerExtra={id === "sign" ? <ControlTags refs={["1.4.3", "1.4.4"]} /> : undefined}
              >
                {id === "capture" && (
                  <>
                    <AiStageNarration
                      variant="inline"
                      playKey={`${caseId}:n:capture`}
                      text={`Costco paid ${formatUsd(figures.paid)} against ${c.invoiceId} (${formatUsd(figures.invoiceTotal)}). The ${formatUsd(figures.shortPaid)} gap opens as a dispute case on the original invoice.`}
                    />
                    <Remittance820Panel figures={figures} onDone={ready.capture} />
                  </>
                )}
                {id === "cause" && (
                  <>
                    <AiStageNarration
                      variant="inline"
                      playKey={`${caseId}:n:cause`}
                      text="Each reason code is checked against the system that owns it. Price and promotion follow K-C's records; freight and tax follow Costco's agreement."
                    />
                    <CauseBoard figures={figures} onDone={ready.cause} />
                  </>
                )}
                {id === "settle" && <SettlementSplit figures={figures} onDone={ready.settle} />}
                {id === "sign" && (
                  <SignStageBody
                    signed={status === "passed"}
                    chargeBack={figures.chargeBack}
                    credit={figures.credit}
                    ownerName={ownerName}
                    onOpen={() => setSignOpen(true)}
                  />
                )}
                {id === "post" && (
                  <div className="flex flex-col gap-3">
                    <PostingChecks
                      playKey={`${caseId}:post-checks`}
                      title="Pre-posting checks"
                      checks={[
                        { label: "Settlement signed", detail: `${ownerName} and L. Chen · SOX 1.4.3 / 1.4.4` },
                        {
                          label: "Credit ties to the Costco-right causes",
                          detail: `${figures.causes.filter((x) => x.verdict === "customer").map((x) => `${x.label} ${formatUsd(x.amount)}`).join(" + ")} = ${formatUsd(figures.credit)}`,
                        },
                        { label: "Charge-back backup attached", detail: `PricerX ${c.pricerXNoteRef} · Vistex ${c.promotionRef} · POD` },
                        {
                          label: "Case balances to the short-pay",
                          detail: `${formatUsd(figures.chargeBack)} charge-back + ${formatUsd(figures.credit)} credit = ${formatUsd(figures.shortPaid)}`,
                        },
                        { label: "Original invoice untouched", detail: `${c.invoiceId} · period closed ${c.periodClosedOn} · no reversal` },
                      ]}
                      lockedLabel="Posting locked until every check passes"
                      lockedDetail={`Dispute case ${c.caseId} still open`}
                      passedLabel={`Cleared to post on ${c.invoiceId}`}
                      passedDetail="Credit memo and residual item sent to FSCM"
                      amount={formatUsd(figures.shortPaid)}
                      onAllPassed={() => setPostChecked(true)}
                    />
                    <div className={postChecked ? "animate-enter rounded-lg border" : "hidden"}>
                      <header className="border-b bg-muted/30 px-3 py-2 text-xs font-semibold text-foreground">
                        FSCM · {c.caseId}
                      </header>
                      <FillFields
                        className="px-3 py-2"
                        play={postChecked}
                        playKey={`${caseId}:post`}
                        onDone={ready.post}
                        columns={2}
                        fields={[
                          { label: "Credit memo", value: `${c.creditMemoId} posted to ${c.invoiceId}` },
                          { label: "Credit amount", value: formatUsd(figures.credit), align: "right" },
                          { label: "Residual item", value: `${c.chargeBackId} · Collections` },
                          { label: "Charge-back due", value: formatUsd(figures.chargeBack), align: "right" },
                          { label: "Cleared on invoice", value: formatUsd(figures.cleared), align: "right" },
                          { label: "Case status", value: "Resolved · partially credited", strong: true },
                        ]}
                      />
                    </div>
                    <OriginalInvoiceLock invoiceId={c.invoiceId} amount={figures.invoiceTotal} periodClosedOn={c.periodClosedOn} />
                  </div>
                )}
                {id === "upstream" && <UpstreamFixPanel figures={figures} onDone={ready.upstream} />}
                {id === "notify" && (
                  <DisputeLetterComposer
                    letterKey={`${caseId}:letter`}
                    from={`${ownerName} <${ownerName.toLowerCase().replace(/[^a-z]+/g, ".")}@kcc.example>`}
                    to="Costco Accounts Payable <ap.deductions@costco.example>"
                    subject={letter.subject}
                    body={letter.body}
                    attachments={[
                      { doc: buildCreditMemoDoc(caseId), label: `Credit memo ${c.creditMemoRequestId}` },
                      { doc: buildChargeBackDoc(caseId), label: `Charge-back ${c.chargeBackId}` },
                      { doc: buildCauseEvidenceDoc(caseId, "price"), label: `PricerX ${c.pricerXNoteRef}` },
                      { doc: buildCauseEvidenceDoc(caseId, "promotion"), label: `Vistex ${c.promotionRef}` },
                    ]}
                    sent={notified}
                    sentNote={`Sent to Costco AP with credit memo and charge-back backup.`}
                    canSend={!notified}
                    onSend={handleSend}
                    closePopup={done}
                  />
                )}
              </RunStageCard>
            );
          })}
        </div>
        <div className="lg:sticky lg:top-4 lg:self-start">
          <RunAgentLog caseId={caseId} />
        </div>
      </div>

      <GateSignoffModal
        open={signOpen}
        onClose={() => setSignOpen(false)}
        gateId={`${caseId}:G1`}
        title="Settle the Costco short-pay"
        documentNo={`${c.caseId} · settlement`}
        caseId={caseId}
        accountId={c.accountId}
        module="Billing"
        system="SAP FSCM"
        controls={["1.4.3", "1.4.4"]}
        evidence={[
          { id: "remit", label: `EDI 820 ${c.remittanceId}`, system: "SAP FSCM", doc: buildRemittanceDoc(caseId) },
          { id: "case", label: `Dispute case ${c.caseId}`, system: "SAP FSCM", doc: buildDisputeCaseDoc(caseId) },
          ...figures.causes.map((x) => ({
            id: x.key,
            label: `Backup for RC ${x.reasonCode}, ${x.reasonText.toLowerCase()}`,
            detail: x.evidence.join(", "),
            system: x.systems[0],
            doc: buildCauseEvidenceDoc(caseId, x.key),
          })),
          { id: "invoice", label: `Invoice ${c.invoiceId}`, system: "SAP S/4HANA", doc: buildInvoiceDoc(caseId) },
        ]}
        lines={[
          { label: "Credit note", amountUsd: figures.credit, kind: "credit" },
          { label: "Charge-back", amountUsd: figures.chargeBack, kind: "charge-back" },
        ]}
        attestation={`I approve credit note ${c.creditMemoRequestId} for ${formatUsd(figures.credit)} and charge-back ${c.chargeBackId} for ${formatUsd(figures.chargeBack)} on dispute case ${c.caseId}. Invoice ${c.invoiceId} stands as issued.`}
        confirmLabel="Approve settlement"
        action={`Approved settlement: credit ${formatUsd(figures.credit)}, charge-back ${formatUsd(figures.chargeBack)}`}
        decision="Partially credited"
        form={{
          formNo: "OTC-DM-12",
          formTitle: "Deduction settlement approval",
          documentNo: `STL-${c.caseId.replace(/^DC-/, "")}`,
          fields: [
            { label: "Customer / sold-to", value: `${c.customerName} · ${c.soldToId}` },
            { label: "Dispute case", value: c.caseId, mono: true },
            { label: "Invoice", value: `${c.invoiceId} · ${c.invoiceDate}` },
            { label: "Remittance (EDI 820)", value: `${c.remittanceId} · ${c.remittanceDate}` },
            { label: "Credit memo request", value: c.creditMemoRequestId, mono: true },
            { label: "Charge-back", value: c.chargeBackId, mono: true },
          ],
          table: {
            columns: [
              { key: "rc", label: "RC", mono: true },
              { key: "reason", label: "Reason" },
              { key: "determination", label: "Determination" },
              { key: "disposition", label: "Disposition" },
              { key: "amount", label: "Amount", align: "right" },
            ],
            rows: figures.causes.map((x) => ({
              rc: x.reasonCode,
              reason: x.reasonText,
              determination: x.verdict === "kc" ? "Billed correctly" : "Customer correct",
              disposition: x.verdict === "kc" ? "Charge back" : "Credit",
              amount: formatUsd(x.amount),
            })),
            total: { label: "Total deducted", value: formatUsd(figures.credit + figures.chargeBack) },
          },
          basis: `Invoice ${c.invoiceId} stands as issued. Reason codes where the customer is correct are credited through ${c.creditMemoRequestId}; reason codes where K-C billed correctly are charged back through ${c.chargeBackId} with the backup listed below.`,
        }}
        onSigned={() => {
          setSignOpen(false);
          run.passGate("sign");
        }}
      />

      {done && !finaleDismissed && (
        <RunCompleteModal
          eyebrow="Dispute resolved · invoice unchanged"
          title={`${c.caseId} settled on ${c.invoiceId}`}
          narrative={`K-C charges back ${formatUsd(figures.chargeBack)}, credits ${formatUsd(figures.credit)} where Costco was right, and sends all four causes upstream. No invoice is reissued.`}
          stats={[
            { label: "Charge-back", value: formatUsd(figures.chargeBack) },
            { label: "Credit note", value: formatUsd(figures.credit) },
            { label: "Fixes upstream", value: String(c.upstream.length), tone: "success" },
          ]}
          docs={[
            { doc: buildDisputeCaseDoc(caseId), label: `FSCM dispute case ${c.caseId}` },
            { doc: buildChargeBackDoc(caseId), label: `Charge-back ${c.chargeBackId}` },
          ]}
          primaryLabel="Back to Billing"
          onPrimary={onBack}
          secondaryLabel="Stay here"
          onSecondary={() => setFinaleDismissed(true)}
          exportCaseId={caseId}
        />
      )}
    </div>
  );
}

function SignStageBody({
  signed,
  chargeBack,
  credit,
  ownerName,
  onOpen,
}: {
  signed: boolean;
  chargeBack: number;
  credit: number;
  ownerName: string;
  onOpen: () => void;
}) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border bg-muted/20 px-4 py-3">
      <div className="text-sm text-foreground">
        Charge-back <span className="font-semibold tabular-nums">{formatUsd(chargeBack)}</span> · Credit note{" "}
        <span className="font-semibold tabular-nums">{formatUsd(credit)}</span>
        <div className="text-xs text-muted-foreground">
          {signed ? `Signed by ${ownerName} and L. Chen` : "Charge-back is above the owner limit, so the Controller co-signs."}
        </div>
      </div>
      <Button size="sm" variant={signed ? "outline" : "default"} onClick={onOpen}>
        <PenLine className="h-4 w-4" />
        {signed ? "View signatures" : "Review & sign"}
      </Button>
    </div>
  );
}
