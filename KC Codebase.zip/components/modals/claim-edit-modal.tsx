"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { CheckCircle2, GripVertical, RotateCcw, Sparkles, X } from "lucide-react";

import { Button } from "@/components/ui/button";
import { formatMoney } from "@/lib/selectors";

/**
 * The reviewer's override, taken at the approve gate of a claim run.
 *
 * Every run resolves the amount withheld into a single split — a "primary"
 * portion and its remainder. For the approve/recover runs the primary portion
 * is what we approve as a genuine trade cost; for the fund run it is the spend
 * that stays on the referenced fund. The modal edits that one scalar, and the
 * pure selectors fold it back into the postings and the retailer letter, so the
 * downstream email and credit/debit move with the slider in real time.
 *
 * Three ways to set it, all bound to the same number: one-tap AI presets, a
 * draggable split handle, and typing an exact figure into either side.
 */

export type SplitTone = "success" | "amber" | "primary" | "sky";

export interface ClaimEditPreset {
  id: string;
  label: string;
  detail: string;
  /** The primary value this preset lands on. */
  value: number;
  /** Marks the model's own recommendation. */
  ai?: boolean;
}

export interface ClaimEditModalProps {
  title: string;
  caseLabel: string;
  total: number;
  /** Current primary value (from the live assessment). */
  primaryValue: number;
  /** The model's / source recommendation the reviewer can snap back to. */
  anchorValue: number;
  leftLabel: string;
  rightLabel: string;
  leftHint: string;
  rightHint: string;
  leftTone: SplitTone;
  rightTone: SplitTone;
  /** How the model frames the current recommendation, one line. */
  aiRationale: string;
  presets: ClaimEditPreset[];
  confirmLabel?: string;
  step?: number;
  onConfirm: (primaryValue: number) => void;
  onReset: () => void;
  onClose: () => void;
}

const TONE: Record<
  SplitTone,
  { bar: string; card: string; text: string; ring: string }
> = {
  success: {
    bar: "bg-[var(--success)]/20",
    card: "border-[var(--success)]/30 bg-[var(--success)]/5",
    text: "text-[var(--success)]",
    ring: "focus-visible:ring-[var(--success)]/40",
  },
  amber: {
    bar: "bg-amber-400/25",
    card: "border-amber-300 bg-amber-50",
    text: "text-amber-700",
    ring: "focus-visible:ring-amber-400/40",
  },
  primary: {
    bar: "bg-primary/20",
    card: "border-primary/30 bg-primary/5",
    text: "text-primary",
    ring: "focus-visible:ring-primary/40",
  },
  sky: {
    bar: "bg-sky-400/25",
    card: "border-sky-300 bg-sky-50",
    text: "text-sky-700",
    ring: "focus-visible:ring-sky-400/40",
  },
};

const clampRound = (n: number, total: number) =>
  Math.max(0, Math.min(total, Math.round(n)));

export function ClaimEditModal({
  title,
  caseLabel,
  total,
  primaryValue,
  anchorValue,
  leftLabel,
  rightLabel,
  leftHint,
  rightHint,
  leftTone,
  rightTone,
  aiRationale,
  presets,
  confirmLabel = "Confirm changes",
  step = 1000,
  onConfirm,
  onReset,
  onClose,
}: ClaimEditModalProps) {
  const [mounted, setMounted] = useState(false);
  const [grown, setGrown] = useState(false);
  const [primary, setPrimary] = useState(() => clampRound(primaryValue, total));
  /** Free-text buffers so a half-typed number doesn't fight the state. */
  const [leftText, setLeftText] = useState<string | null>(null);
  const [rightText, setRightText] = useState<string | null>(null);

  const barRef = useRef<HTMLDivElement>(null);
  const draggingRef = useRef(false);

  useEffect(() => {
    setMounted(true);
    const id = setTimeout(() => setGrown(true), 60);
    return () => clearTimeout(id);
  }, []);

  const setFromPointer = useCallback(
    (clientX: number) => {
      const el = barRef.current;
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const pct = (clientX - rect.left) / rect.width;
      const raw = pct * total;
      const snapped = Math.round(raw / step) * step;
      setPrimary(clampRound(snapped, total));
    },
    [total, step]
  );

  useEffect(() => {
    if (!mounted) return;
    const move = (e: PointerEvent) => {
      if (!draggingRef.current) return;
      setFromPointer(e.clientX);
    };
    const up = () => {
      draggingRef.current = false;
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    return () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
  }, [mounted, setFromPointer]);

  if (!mounted) return null;

  const right = total - primary;
  const primaryPct = total === 0 ? 0 : (primary / total) * 100;
  const shownPct = grown ? primaryPct : (clampRound(primaryValue, total) / total) * 100;
  const atAnchor = primary === clampRound(anchorValue, total);

  const L = TONE[leftTone];
  const R = TONE[rightTone];

  const commitLeft = (raw: string) => {
    const n = Number(raw.replace(/[^0-9.]/g, ""));
    if (!Number.isNaN(n)) setPrimary(clampRound(n, total));
    setLeftText(null);
  };
  const commitRight = (raw: string) => {
    const n = Number(raw.replace(/[^0-9.]/g, ""));
    if (!Number.isNaN(n)) setPrimary(clampRound(total - n, total));
    setRightText(null);
  };

  return createPortal(
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-6 text-left"
      onClick={onClose}
    >
      <div
        className="w-full max-w-xl rounded-xl border bg-card shadow-2xl animate-modal-in"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
        aria-label={title}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b px-5 py-3">
          <div>
            <div className="text-sm font-semibold">{title}</div>
            <div className="text-xs text-muted-foreground">{caseLabel}</div>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose} aria-label="Close">
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div className="space-y-5 px-5 py-5">
          {/* AI rationale */}
          <div className="flex items-start gap-2 rounded-lg border border-primary/20 bg-primary/5 p-3 text-sm">
            <Sparkles className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
            <span className="text-muted-foreground">{aiRationale}</span>
          </div>

          {/* AI preset chips */}
          <div>
            <div className="mb-2 flex items-center gap-1.5 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
              <Sparkles className="h-3 w-3 text-primary" />
              AI suggestions — one tap
            </div>
            <div className="flex flex-wrap gap-2">
              {presets.map((p) => {
                const active = primary === clampRound(p.value, total);
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setPrimary(clampRound(p.value, total))}
                    className={`group flex flex-col items-start rounded-lg border px-3 py-2 text-left transition-colors ${
                      active
                        ? "border-primary bg-primary/10"
                        : "border-border bg-background hover:border-primary/40 hover:bg-primary/5"
                    }`}
                  >
                    <span className="flex items-center gap-1 text-xs font-semibold text-foreground">
                      {p.ai && <Sparkles className="h-3 w-3 text-primary" />}
                      {p.label}
                    </span>
                    <span className="text-[11px] text-muted-foreground">
                      {p.detail}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* The split bar with a draggable handle */}
          <div>
            <div
              ref={barRef}
              className="relative flex h-12 w-full select-none overflow-hidden rounded-lg border"
            >
              <div
                className={`flex items-center justify-start ${L.bar} ${L.text} transition-[width] duration-500 ease-out`}
                style={{ width: `${shownPct}%` }}
              >
                {primaryPct > 16 && (
                  <span className="px-2.5 text-xs font-semibold whitespace-nowrap">
                    {leftLabel}
                  </span>
                )}
              </div>
              <div
                className={`flex items-center justify-end ${R.bar} ${R.text} transition-[width] duration-500 ease-out`}
                style={{ width: `${100 - shownPct}%` }}
              >
                {100 - primaryPct > 16 && (
                  <span className="px-2.5 text-xs font-semibold whitespace-nowrap">
                    {rightLabel}
                  </span>
                )}
              </div>

              {/* Draggable divider */}
              <button
                type="button"
                aria-label={`Drag to set ${leftLabel}`}
                onPointerDown={(e) => {
                  e.preventDefault();
                  draggingRef.current = true;
                  setFromPointer(e.clientX);
                }}
                onKeyDown={(e) => {
                  if (e.key === "ArrowLeft")
                    setPrimary((v) => clampRound(v - step, total));
                  if (e.key === "ArrowRight")
                    setPrimary((v) => clampRound(v + step, total));
                }}
                className="absolute top-0 z-10 flex h-full -translate-x-1/2 cursor-ew-resize items-center justify-center transition-[left] duration-500 ease-out"
                style={{ left: `${shownPct}%` }}
              >
                <span className="flex h-8 w-5 items-center justify-center rounded-md border bg-card shadow-md">
                  <GripVertical className="h-3.5 w-3.5 text-muted-foreground" />
                </span>
              </button>
            </div>

            {/* Slider mirror for coarse dragging */}
            <input
              type="range"
              min={0}
              max={total}
              step={step}
              value={primary}
              onChange={(e) => setPrimary(clampRound(Number(e.target.value), total))}
              aria-label={`${leftLabel} amount`}
              className="mt-3 w-full cursor-pointer accent-primary"
            />
            <div className="flex items-center justify-between text-[11px] text-muted-foreground">
              <span>{formatMoney(0)}</span>
              <button
                type="button"
                onClick={() => setPrimary(clampRound(anchorValue, total))}
                className={`inline-flex items-center gap-1 rounded px-1.5 py-0.5 ${
                  atAnchor ? "text-primary" : "text-muted-foreground hover:text-primary"
                }`}
              >
                <RotateCcw className="h-3 w-3" />
                AI anchor {formatMoney(clampRound(anchorValue, total))}
              </button>
              <span>{formatMoney(total)}</span>
            </div>
          </div>

          {/* The two live amounts — typeable */}
          <div className="grid grid-cols-2 gap-3">
            <label className={`rounded-lg border p-3 ${L.card}`}>
              <div className="text-xs text-muted-foreground">{leftLabel}</div>
              <div className={`flex items-baseline ${L.text}`}>
                <span className="text-lg font-bold">$</span>
                <input
                  inputMode="numeric"
                  value={
                    leftText ?? Math.round(primary).toLocaleString("en-US")
                  }
                  onChange={(e) => setLeftText(e.target.value)}
                  onFocus={(e) => {
                    setLeftText(String(primary));
                    e.currentTarget.select();
                  }}
                  onBlur={(e) => commitLeft(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") e.currentTarget.blur();
                  }}
                  aria-label={`${leftLabel} exact amount`}
                  className={`w-full bg-transparent text-xl font-bold outline-none ${L.ring}`}
                />
              </div>
              <div className="mt-0.5 text-[11px] text-muted-foreground">
                {leftHint}
              </div>
            </label>
            <label className={`rounded-lg border p-3 ${R.card}`}>
              <div className="text-xs text-muted-foreground">{rightLabel}</div>
              <div className={`flex items-baseline ${R.text}`}>
                <span className="text-lg font-bold">$</span>
                <input
                  inputMode="numeric"
                  value={rightText ?? Math.round(right).toLocaleString("en-US")}
                  onChange={(e) => setRightText(e.target.value)}
                  onFocus={(e) => {
                    setRightText(String(right));
                    e.currentTarget.select();
                  }}
                  onBlur={(e) => commitRight(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") e.currentTarget.blur();
                  }}
                  aria-label={`${rightLabel} exact amount`}
                  className={`w-full bg-transparent text-xl font-bold outline-none ${R.ring}`}
                />
              </div>
              <div className="mt-0.5 text-[11px] text-muted-foreground">
                {rightHint}
              </div>
            </label>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between gap-3 border-t bg-muted/20 px-5 py-3">
          <button
            type="button"
            onClick={onReset}
            className="text-xs text-muted-foreground underline-offset-2 hover:text-foreground hover:underline"
          >
            Reset to AI recommendation
          </button>
          <div className="flex items-center gap-2">
            <span className="hidden text-xs text-muted-foreground sm:inline">
              Adds back to {formatMoney(total)}
            </span>
            <Button onClick={() => onConfirm(primary)} className="whitespace-nowrap">
              <CheckCircle2 className="h-4 w-4" />
              {confirmLabel}
            </Button>
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
}
