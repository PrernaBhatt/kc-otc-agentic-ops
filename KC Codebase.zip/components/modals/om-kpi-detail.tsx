"use client";

import { useEffect, type ReactNode } from "react";
import { ArrowRight, BadgeCheck, PackageCheck, ScanSearch, Timer, X } from "lucide-react";

import type { ViewId } from "@/components/layout/sidebar";
import { Tip } from "@/components/shared/floating-tip";
import { SystemMark } from "@/components/shared/system-badge";
import { Button } from "@/components/ui/button";
import {
  OM_BASE_ORDERS,
  OM_PREV_MONTH,
  OM_TREND_MONTHS,
  ORDER_TO_INVOICE,
  OTIF,
  PERFECT_ORDER,
  VALIDATION_ACCURACY,
} from "@/lib/data/om-kpis";
import { RISK_ROWS } from "@/lib/data/shipment-risk";
import { formatCount } from "@/lib/format";
import {
  kpiDeltas,
  orderToInvoiceDays,
  otifByCustomer,
  otifPct,
  perfectOrder,
  validationAccuracy,
} from "@/lib/shipment-selectors";
import { cn } from "@/lib/utils";

export type OmKpiKey = "otif" | "perfect-order" | "validation-accuracy" | "order-to-invoice";

export function DeltaChip({ delta, unit = "pts", lowerIsBetter = false }: { delta: number; unit?: string; lowerIsBetter?: boolean }) {
  const good = lowerIsBetter ? delta <= 0 : delta >= 0;
  return (
    <span
      className={cn(
        "whitespace-nowrap rounded-md px-1.5 py-0.5 text-[11px] font-semibold tabular-nums",
        good ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"
      )}
    >
      {delta > 0 ? "+" : delta < 0 ? "−" : "±"}
      {Math.abs(delta).toFixed(1)} {unit} vs {OM_PREV_MONTH}
    </span>
  );
}

function Section({ title, children, delay, action }: { title: string; children: ReactNode; delay: number; action?: ReactNode }) {
  return (
    <section className="animate-enter flex flex-col gap-3 rounded-xl border bg-card p-4" style={{ animationDelay: `${delay}ms` }}>
      <header className="flex items-center justify-between gap-2">
        <h3 className="text-sm font-semibold text-foreground">{title}</h3>
        {action}
      </header>
      {children}
    </section>
  );
}

/** Six-month bars for one or more series, scaled to [lo, hi] so small moves read. */
function TrendBars({
  series,
  lo,
  hi,
  unit,
  target,
}: {
  series: { key: string; values: number[]; tone: string }[];
  lo: number;
  hi: number;
  unit: string;
  target?: number;
}) {
  const h = (v: number) => `${Math.max(4, Math.min(100, ((v - lo) / (hi - lo)) * 100))}%`;
  return (
    <div className="flex flex-col gap-1.5">
      <div className="relative flex h-28 items-end gap-3">
        {target !== undefined && (
          <span className="pointer-events-none absolute inset-x-0 border-t border-dashed border-foreground/40" style={{ bottom: h(target) }} aria-hidden>
            <span className="absolute -top-4 right-0 text-[10px] text-muted-foreground">
              Target {target}
              {unit}
            </span>
          </span>
        )}
        {OM_TREND_MONTHS.map((m, i) => (
          <div key={m} className="flex h-full flex-1 items-end gap-0.5">
            {series.map((s, si) => (
              <Tip
                key={s.key}
                content={{ title: `${m} · ${s.key}`, value: `${s.values[i]}${unit}` }}
                className={cn("grow-y block flex-1 rounded-sm transition-opacity hover:opacity-75", s.tone)}
                style={{ height: h(s.values[i]), animationDelay: `${i * 50 + si * 20}ms` }}
              />
            ))}
          </div>
        ))}
      </div>
      <div className="flex gap-3 text-[11px] text-muted-foreground">
        {OM_TREND_MONTHS.map((m) => (
          <span key={m} className="flex-1 text-center">
            {m}
          </span>
        ))}
      </div>
      {series.length > 1 && (
        <div className="flex flex-wrap gap-3 text-[11px] text-muted-foreground">
          {series.map((s) => (
            <span key={s.key} className="flex items-center gap-1">
              <span className={cn("h-2 w-2 rounded-sm", s.tone)} aria-hidden /> {s.key}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

function ReasonList({ title, reasons }: { title: string; reasons: { label: string; orders: number }[] }) {
  const max = Math.max(...reasons.map((r) => r.orders));
  const total = reasons.reduce((a, r) => a + r.orders, 0);
  return (
    <div className="flex flex-col gap-1.5 rounded-lg bg-red-50/60 px-3 py-2">
      <span className="flex justify-between text-[11px] font-semibold text-red-700">
        <span>{title}</span>
        <span className="tabular-nums">−{formatCount(total)}</span>
      </span>
      {reasons.map((r) => (
        <Tip key={r.label} content={{ title: r.label, value: `${r.orders} orders` }} className="group flex items-center gap-2 text-[11px]">
          <span className="w-40 shrink-0 truncate text-muted-foreground group-hover:text-foreground">{r.label}</span>
          <span className="relative h-1.5 flex-1 overflow-hidden rounded-full bg-card">
            <span className="grow-x absolute inset-y-0 left-0 rounded-full bg-red-400" style={{ width: `${(r.orders / max) * 100}%` }} />
          </span>
          <span className="w-8 shrink-0 text-right tabular-nums text-foreground">{r.orders}</span>
        </Tip>
      ))}
    </div>
  );
}

function OtifBody({ onNavigate }: { onNavigate?: (v: ViewId) => void }) {
  const lossBefore = [OTIF.losses.beforeA, OTIF.losses.aToS, OTIF.losses.sToD];
  const lossTitle = ["Lost before A", "Lost A → S", "Lost S → D"];
  return (
    <>
      <Section title="A › S › D funnel" delay={60}>
        <ol className="flex flex-col gap-2">
          {OTIF.stages.map((st, i) => (
            <li key={st.key} className="flex flex-col gap-2">
              <ReasonList title={lossTitle[i]} reasons={lossBefore[i]} />
              <Tip
                content={{ title: `${st.label} · target ${st.targetPct}%`, value: `${formatCount(st.orders)} of ${formatCount(OM_BASE_ORDERS)}`, note: st.definition }}
                className="group flex items-center gap-3"
              >
                <span className="w-24 shrink-0 text-sm font-medium text-foreground">
                  <span className="font-semibold">{st.key}</span> {st.label}
                </span>
                <span className="relative h-6 flex-1 overflow-hidden rounded-md bg-muted">
                  <span
                    className={cn("grow-x absolute inset-y-0 left-0 rounded-md", st.key === "D" ? "bg-primary" : "bg-primary/50")}
                    style={{ width: `${(st.orders / OM_BASE_ORDERS) * 100}%`, animationDelay: `${i * 90}ms` }}
                  />
                </span>
                <span className="w-24 shrink-0 text-right text-sm tabular-nums">
                  <span className="font-semibold text-foreground">{otifPct[st.key]}%</span>{" "}
                  <span className={cn("text-[11px]", otifPct[st.key] >= st.targetPct ? "text-green-700" : "text-amber-700")}>/ {st.targetPct}</span>
                </span>
              </Tip>
            </li>
          ))}
        </ol>
      </Section>
      <Section title="By customer" delay={120}>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[480px] text-sm">
            <thead>
              <tr className="text-left text-[11px] uppercase tracking-wide text-muted-foreground">
                <th className="pb-2 font-medium">Customer</th>
                <th className="pb-2 text-right font-medium">Orders</th>
                <th className="pb-2 text-right font-medium">A</th>
                <th className="pb-2 text-right font-medium">S</th>
                <th className="pb-2 text-right font-medium">D</th>
                <th className="pb-2 text-right font-medium">Target D</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {otifByCustomer.map((c, i) => (
                <tr key={c.customer} className="animate-enter" style={{ animationDelay: `${160 + i * 40}ms` }}>
                  <td className="py-2">
                    <span className="flex items-center gap-2">
                      {c.customer !== "Other" && <SystemMark name={c.customer} />}
                      {c.customer}
                    </span>
                  </td>
                  <td className="py-2 text-right tabular-nums text-muted-foreground">{formatCount(c.orders)}</td>
                  <td className="py-2 text-right tabular-nums">{c.pctA.toFixed(1)}</td>
                  <td className="py-2 text-right tabular-nums">{c.pctS.toFixed(1)}</td>
                  <td className="py-2 text-right font-semibold tabular-nums">{c.pctD.toFixed(1)}</td>
                  <td className="py-2 text-right">
                    <span
                      className={cn(
                        "rounded-md px-1.5 py-0.5 text-[11px] font-semibold tabular-nums",
                        c.pctD >= c.targetPct ? "bg-green-50 text-green-700" : "bg-amber-50 text-amber-700"
                      )}
                    >
                      {c.targetPct}%
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Section>
      <Section
        title="Six-month trend"
        delay={180}
        action={
          onNavigate && (
            <Button size="sm" variant="outline" className="h-7 gap-1 text-xs" onClick={() => onNavigate("shipments")}>
              {RISK_ROWS.length} shipments at risk <ArrowRight className="h-3 w-3" aria-hidden />
            </Button>
          )
        }
      >
        <TrendBars
          lo={84}
          hi={98}
          unit="%"
          series={[
            { key: "A", values: OTIF.trendA, tone: "bg-primary/35" },
            { key: "S", values: OTIF.trendS, tone: "bg-primary/60" },
            { key: "D", values: OTIF.trendD, tone: "bg-primary" },
          ]}
        />
      </Section>
    </>
  );
}

const PO_ROUTES: Record<string, { view: ViewId; label: string }> = {
  "in-full": { view: "orders", label: "Order Management" },
  "on-time": { view: "shipments", label: "Track & Trace" },
  "dispute-free": { view: "deductions", label: "Deductions" },
  docs: { view: "billing", label: "Billing" },
  paid: { view: "collections", label: "Collections" },
};

function PerfectOrderBody({ onNavigate }: { onNavigate?: (v: ViewId) => void }) {
  const maxFail = Math.max(...perfectOrder.components.map((c) => c.failing));
  return (
    <>
      <Section title="Where perfect orders are lost" delay={60}>
        <ul className="flex flex-col divide-y">
          {perfectOrder.components.map((c, i) => {
            const route = PO_ROUTES[c.key];
            return (
              <li key={c.key} className="animate-enter grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 py-2.5 sm:grid-cols-[10rem_minmax(0,1fr)_4rem_9rem]" style={{ animationDelay: `${i * 50}ms` }}>
                <span className="flex flex-col">
                  <span className="text-sm font-medium text-foreground">{c.label}</span>
                  <span className="text-[11px] tabular-nums text-muted-foreground">{c.pct.toFixed(1)}% pass</span>
                </span>
                <Tip content={{ title: c.label, value: `${formatCount(c.failing)} orders fail`, note: c.definition }} className="relative hidden h-2 overflow-hidden rounded-full bg-muted sm:block">
                  <span className="grow-x absolute inset-y-0 left-0 rounded-full bg-red-400" style={{ width: `${(c.failing / maxFail) * 100}%` }} />
                </Tip>
                <span className="hidden text-right text-sm font-semibold tabular-nums text-red-700 sm:block">{formatCount(c.failing)}</span>
                <Button
                  size="sm"
                  variant="outline"
                  className="h-7 justify-between gap-1 text-xs"
                  onClick={() => onNavigate?.(route.view)}
                  disabled={!onNavigate}
                >
                  {route.label} <ArrowRight className="h-3 w-3" aria-hidden />
                </Button>
              </li>
            );
          })}
        </ul>
        <p className="text-xs text-muted-foreground">
          <span className="font-semibold tabular-nums text-foreground">{formatCount(PERFECT_ORDER.perfect)}</span> of{" "}
          {formatCount(OM_BASE_ORDERS)} orders pass all five.
        </p>
      </Section>
      <Section title="Six-month trend" delay={140}>
        <TrendBars lo={80} hi={92} unit="%" target={PERFECT_ORDER.targetPct} series={[{ key: "Perfect order", values: PERFECT_ORDER.trend, tone: "bg-primary" }]} />
      </Section>
    </>
  );
}

function ValidationBody({ onNavigate }: { onNavigate?: (v: ViewId) => void }) {
  const va = VALIDATION_ACCURACY;
  const stats = [
    { label: "Validated", value: va.validated },
    { label: "Auto-released", value: va.autoReleased },
    { label: "Held for review", value: va.heldForReview },
    { label: "Hold confirmed", value: va.heldConfirmed },
  ];
  const lists = [
    { title: "False holds", count: va.falseHolds, tone: "text-amber-700 bg-amber-50", rows: va.examples.falseHolds },
    { title: "Missed errors", count: va.missedErrors, tone: "text-red-700 bg-red-50", rows: va.examples.missedErrors },
  ];
  return (
    <>
      <Section title="Outcomes" delay={60}>
        <dl className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {stats.map((s, i) => (
            <div key={s.label} className="animate-enter flex flex-col rounded-lg bg-muted/40 px-3 py-2" style={{ animationDelay: `${i * 40}ms` }}>
              <dt className="text-[11px] text-muted-foreground">{s.label}</dt>
              <dd className="text-lg font-semibold tabular-nums text-foreground">{formatCount(s.value)}</dd>
            </div>
          ))}
        </dl>
      </Section>
      <Section
        title="Where the agent was wrong"
        delay={120}
        action={
          onNavigate && (
            <Button size="sm" variant="outline" className="h-7 gap-1 text-xs" onClick={() => onNavigate("credit-review")}>
              Review Order Hold <ArrowRight className="h-3 w-3" aria-hidden />
            </Button>
          )
        }
      >
        <div className="grid items-stretch gap-3 sm:grid-cols-2">
          {lists.map((l) => (
            <div key={l.title} className="flex h-full flex-col gap-2 rounded-lg border p-3">
              <span className="flex items-center justify-between text-xs font-semibold text-foreground">
                {l.title}
                <span className={cn("rounded-md px-1.5 py-0.5 tabular-nums", l.tone)}>{l.count}</span>
              </span>
              <ul className="flex flex-col divide-y">
                {l.rows.map((r) => (
                  <li key={r.orderId} className="flex flex-col gap-0.5 py-2">
                    <span className="flex items-center gap-1.5 text-xs">
                      <SystemMark name={r.customer} />
                      <span className="font-mono font-semibold text-foreground">{r.orderId}</span>
                      <span className="truncate text-muted-foreground">· {r.finding}</span>
                    </span>
                    <span className="text-xs leading-relaxed text-muted-foreground">{r.outcome}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </Section>
      <Section title="Six-month trend" delay={180}>
        <TrendBars lo={97.5} hi={99.5} unit="%" target={va.targetPct} series={[{ key: "Accuracy", values: va.trend, tone: "bg-primary" }]} />
      </Section>
    </>
  );
}

const PHASE_TONES = ["bg-primary/35", "bg-primary/55", "bg-amber-500", "bg-primary", "bg-primary/75"];

function CycleBody() {
  return (
    <>
      <Section title="Days by phase" delay={60}>
        <div className="flex h-4 gap-0.5 overflow-hidden rounded-full" role="img" aria-label="Order-to-invoice by phase">
          {ORDER_TO_INVOICE.phases.map((p, i) => (
            <Tip
              key={p.key}
              content={{ title: p.label, value: `${p.days.toFixed(1)} days`, note: `${Math.round((p.days / orderToInvoiceDays) * 100)}% of the cycle` }}
              className={cn("grow-x block h-full transition-opacity hover:opacity-75", PHASE_TONES[i])}
              style={{ flex: `${p.days} 1 0`, animationDelay: `${i * 60}ms` }}
            />
          ))}
        </div>
        <ul className="flex flex-col divide-y">
          {ORDER_TO_INVOICE.phases.map((p, i) => (
            <li key={p.key} className="animate-enter flex items-center gap-2 py-2 text-sm" style={{ animationDelay: `${i * 40}ms` }}>
              <span className={cn("h-2.5 w-2.5 shrink-0 rounded-sm", PHASE_TONES[i])} aria-hidden />
              <span className="flex-1 text-foreground">{p.label}</span>
              <span className="w-12 text-right text-xs tabular-nums text-muted-foreground">{Math.round((p.days / orderToInvoiceDays) * 100)}%</span>
              <span className="w-16 text-right font-semibold tabular-nums text-foreground">{p.days.toFixed(1)} d</span>
            </li>
          ))}
        </ul>
      </Section>
      <Section title="Six-month trend" delay={140}>
        <TrendBars lo={5} hi={8.5} unit=" d" target={ORDER_TO_INVOICE.targetDays} series={[{ key: "Cycle", values: ORDER_TO_INVOICE.trend, tone: "bg-primary" }]} />
      </Section>
    </>
  );
}

const HEAD: Record<OmKpiKey, { label: string; icon: typeof PackageCheck; value: string; target: string; met: boolean; delta: ReactNode }> = {
  otif: {
    label: "OTIF · A › S › D",
    icon: PackageCheck,
    value: `${otifPct.D}%`,
    target: `${OTIF.stages[2].targetPct}%`,
    met: otifPct.D >= OTIF.stages[2].targetPct,
    delta: <DeltaChip delta={kpiDeltas.otif} />,
  },
  "perfect-order": {
    label: "Perfect order",
    icon: BadgeCheck,
    value: `${perfectOrder.pct}%`,
    target: `${PERFECT_ORDER.targetPct}%`,
    met: perfectOrder.pct >= PERFECT_ORDER.targetPct,
    delta: <DeltaChip delta={kpiDeltas.perfectOrder} />,
  },
  "validation-accuracy": {
    label: "Order validation accuracy",
    icon: ScanSearch,
    value: `${validationAccuracy.pct}%`,
    target: `${VALIDATION_ACCURACY.targetPct.toFixed(1)}%`,
    met: validationAccuracy.pct >= VALIDATION_ACCURACY.targetPct,
    delta: <DeltaChip delta={kpiDeltas.validation} />,
  },
  "order-to-invoice": {
    label: "Order-to-invoice cycle",
    icon: Timer,
    value: `${orderToInvoiceDays} days`,
    target: `${ORDER_TO_INVOICE.targetDays.toFixed(1)} d`,
    met: orderToInvoiceDays <= ORDER_TO_INVOICE.targetDays,
    delta: <DeltaChip delta={kpiDeltas.cycleDays} unit="d" lowerIsBetter />,
  },
};

/** The detail behind one OM Command Center KPI. Esc or a click outside closes it; page scroll stays free. */
export function OmKpiDetail({ kpi, onClose, onNavigate }: { kpi: OmKpiKey; onClose: () => void; onNavigate?: (v: ViewId) => void }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const head = HEAD[kpi];
  const go = onNavigate
    ? (v: ViewId) => {
        onClose();
        onNavigate(v);
      }
    : undefined;

  return (
    <div
      className="animate-enter-fade fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-foreground/40 p-4 backdrop-blur-sm sm:items-center"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label={`${head.label} detail`}
        className="animate-enter flex max-h-[calc(100vh-2rem)] w-full max-w-3xl flex-col overflow-hidden rounded-2xl border bg-background shadow-2xl"
      >
        <header className="flex items-start justify-between gap-3 border-b bg-card px-5 py-4">
          <div className="flex flex-col gap-1">
            <span className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
              <head.icon className="h-3.5 w-3.5" aria-hidden /> {head.label}
            </span>
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-3xl font-bold tabular-nums text-foreground">{head.value}</span>
              <span
                className={cn(
                  "whitespace-nowrap rounded-md border px-1.5 py-0.5 text-[11px] font-semibold",
                  head.met ? "border-green-200 bg-green-100 text-green-700" : "border-amber-200 bg-amber-50 text-amber-700"
                )}
              >
                {head.met ? "On target" : "Below target"} · {head.target}
              </span>
              {head.delta}
            </div>
          </div>
          <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0" onClick={onClose} aria-label="Close">
            <X className="h-4 w-4" />
          </Button>
        </header>
        <div className="flex flex-col gap-4 overflow-y-auto p-5">
          {kpi === "otif" && <OtifBody onNavigate={go} />}
          {kpi === "perfect-order" && <PerfectOrderBody onNavigate={go} />}
          {kpi === "validation-accuracy" && <ValidationBody onNavigate={go} />}
          {kpi === "order-to-invoice" && <CycleBody />}
        </div>
      </div>
    </div>
  );
}
