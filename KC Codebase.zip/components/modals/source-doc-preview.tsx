"use client";

import { useEffect, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { FileText, X } from "lucide-react";

import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export interface DocMetaField {
  label: string;
  value: string;
}

export interface DocTableColumn {
  key: string;
  label: string;
  align?: "left" | "right";
}

export interface DocTableRow {
  id: string;
  cells: Record<string, ReactNode>;
}

export interface DocTotal {
  label: string;
  value: string;
  emphasis?: boolean;
}

export interface DocNoteItem {
  label: string;
  detail: string;
}

/** A named address / party block, e.g. buyer, vendor, ship-to. */
export interface DocPartyBlock {
  heading: string;
  lines: string[];
  /** Renders in the document's accent colour, like Datamoto's blue ship-to. */
  accent?: boolean;
}

/** A ruled signature line on a formal letter. */
export interface DocSignatureRow {
  label: string;
  value?: string;
}

/** A receiving-dock ink stamp, e.g. "RECEIVED" with the dock and date. */
export interface DocStamp {
  title: string;
  lines: string[];
  date: string;
  /** Exception stamps (short / damaged) print in red instead of blue. */
  tone?: "ok" | "exception";
}

/**
 * Which real-world system this document is rendered to look like. Each skin is
 * a faithful-ish reproduction of the system the field data actually comes from,
 * so a preview reads like the screen an operator would recognize.
 */
export type DocSkin =
  | "generic"
  | "sap"
  | "printed-po"
  | "pod-letter"
  | "pricerx"
  | "trade";

export interface SourceDoc {
  docId: string;
  /** Modal heading, e.g. "Purchase Order PO-88012" */
  title: string;
  /** Document type printed on the letterhead, e.g. "Purchase Order" */
  docLabel: string;
  /** Document number shown in monospace on the letterhead */
  reference?: string;
  /** Issuing organization on the letterhead */
  issuer?: string;
  /** Authentic system skin. Defaults to the generic card look. */
  skin?: DocSkin;
  /** Optional date/line shown under the letterhead on document-style skins. */
  docDate?: string;
  /** Named address / party blocks (buyer, vendor, ship-to, destination). */
  partyBlocks?: DocPartyBlock[];
  /** Ruled signature lines rendered at the foot of a formal letter. */
  signature?: DocSignatureRow[];
  /** Ink receiving stamp printed beside the signature block. */
  stamp?: DocStamp;
  meta: DocMetaField[];
  columns: DocTableColumn[];
  rows: DocTableRow[];
  totals?: DocTotal[];
  /** Short single-line caption. For multiple facts, prefer noteList so each renders as its own row. */
  footnote?: string;
  /** A per-row breakdown rendered as a label/detail list instead of one flat paragraph. */
  noteList?: DocNoteItem[];
  /** Rows tied to the business decision on the screen that opened this document */
  highlightRowIds: string[];
  /** Plain-language legend explaining why rows are highlighted */
  highlightNote?: string;
  /** Retained for data compatibility; no longer rendered. */
  aiSummary?: string;
  /** When set and rows.length exceeds this, only the first N render until "Show all" is clicked. */
  initialVisibleRows?: number;
  /** Noun used in the "Show all N ___" button, e.g. "stores", "SKUs". Defaults to "rows". */
  rowNoun?: string;
}

/* ------------------------------------------------------------------ *
 * Shared building blocks
 * ------------------------------------------------------------------ */

const HIGHLIGHT_BG = "bg-[#fdf6d3]";
// Chancery italic "pen" hand; generic `cursive` resolves to Comic Sans or similar on some OSes.
const SIGNATURE_FONT =
  '"Apple Chancery", "Monotype Corsiva", "URW Chancery L", "Z003", "Lucida Calligraphy", cursive';

interface TableClasses {
  table?: string;
  headRow: string;
  headCell: string;
  row: (highlighted: boolean) => string;
  cell: (highlighted: boolean, first: boolean) => string;
}

function SkinTable({ doc, c }: { doc: SourceDoc; c: TableClasses }) {
  return (
    <table className={cn("w-full border-collapse", c.table)}>
      <thead>
        <tr className={c.headRow}>
          {doc.columns.map((col) => (
            <th
              key={col.key}
              className={cn(c.headCell, col.align === "right" && "text-right")}
            >
              {col.label}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {doc.rows.map((row) => {
          const hl = doc.highlightRowIds.includes(row.id);
          return (
            <tr key={row.id} className={c.row(hl)}>
              {doc.columns.map((col, i) => (
                <td
                  key={col.key}
                  className={cn(
                    c.cell(hl, i === 0),
                    col.align === "right" && "text-right"
                  )}
                >
                  {row.cells[col.key]}
                </td>
              ))}
            </tr>
          );
        })}
      </tbody>
    </table>
  );
}

function MetaGrid({
  doc,
  className,
  labelClass,
  valueClass,
}: {
  doc: SourceDoc;
  className: string;
  labelClass: string;
  valueClass: string;
}) {
  if (doc.meta.length === 0) return null;
  return (
    <div className={className}>
      {doc.meta.map((field) => (
        <div key={field.label}>
          <p className={labelClass}>{field.label}</p>
          <p className={valueClass}>{field.value}</p>
        </div>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * SAP S/4HANA (Fiori object page)
 * ------------------------------------------------------------------ */

function SapBody({ doc }: { doc: SourceDoc }) {
  const table: TableClasses = {
    headRow: "border-y border-[#e5e5e5] bg-[#f7f7f7]",
    headCell:
      "px-5 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-[#6a6d70]",
    row: (hl) => cn("border-b border-[#edeff0]", hl && HIGHLIGHT_BG),
    cell: (hl, first) =>
      cn(
        "px-5 py-2.5 text-sm text-[#32363a]",
        hl && "font-semibold",
        first && hl && "border-l-4 border-[#e9730c]"
      ),
  };
  return (
    <div className="overflow-hidden rounded-md border border-[#d9d9d9] bg-white">
      <div className="flex items-center justify-between bg-[#354a5f] px-4 py-2 text-white">
        <div className="flex items-center gap-2">
          <span className="rounded-sm bg-[#1e9de3] px-1.5 py-0.5 text-[11px] font-bold tracking-tight text-white">
            SAP
          </span>
          <span className="text-sm font-medium">{doc.issuer}</span>
        </div>
        {doc.reference && (
          <span className="font-mono text-xs text-white/80">{doc.reference}</span>
        )}
      </div>

      <div className="border-b border-[#e5e5e5] px-5 py-4">
        <p className="text-[11px] uppercase tracking-wide text-[#6a6d70]">
          Object
        </p>
        <h4 className="text-lg font-semibold text-[#32363a]">{doc.docLabel}</h4>
      </div>

      <MetaGrid
        doc={doc}
        className="grid grid-cols-2 gap-4 border-b border-[#e5e5e5] px-5 py-4 md:grid-cols-4"
        labelClass="text-[11px] text-[#6a6d70]"
        valueClass="text-sm font-medium text-[#32363a]"
      />

      <SkinTable doc={doc} c={table} />

      {doc.totals && doc.totals.length > 0 && (
        <div className="space-y-1 border-t border-[#e5e5e5] px-5 py-4">
          {doc.totals.map((t) => (
            <div
              key={t.label}
              className={cn(
                "flex items-center justify-between text-sm text-[#32363a]",
                t.emphasis && "text-base font-semibold"
              )}
            >
              <span className={cn(!t.emphasis && "text-[#6a6d70]")}>
                {t.label}
              </span>
              <span>{t.value}</span>
            </div>
          ))}
        </div>
      )}

      {doc.footnote && (
        <div className="border-t border-[#e5e5e5] px-5 py-3">
          <p className="text-sm text-[#6a6d70]">{doc.footnote}</p>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Customer purchase order (printed PO document)
 * ------------------------------------------------------------------ */

function PrintedPoBody({ doc }: { doc: SourceDoc }) {
  const table: TableClasses = {
    table: "border border-[#c8c8c8]",
    headRow: "bg-[#eef1f4]",
    headCell:
      "border border-[#c8c8c8] px-3 py-1.5 text-left text-xs font-bold text-[#333]",
    row: (hl) => cn(hl && HIGHLIGHT_BG),
    cell: (hl, first) =>
      cn(
        "border border-[#c8c8c8] px-3 py-1.5 text-sm text-[#222] align-top",
        hl && "font-semibold",
        first && hl && "border-l-4 border-l-[#e9a300]"
      ),
  };
  const blocks = doc.partyBlocks ?? [];
  return (
    <div className="rounded-md border border-[#e2e2e2] bg-white px-8 py-7 shadow-sm">
      <p className="text-center text-xl font-semibold tracking-[0.2em] text-[#5b7186]">
        PURCHASE ORDER
      </p>

      <div className="mt-6 flex items-start justify-between gap-8">
        <div className="max-w-[45%]">
          <span className="inline-block rounded-sm bg-[#1c6fd6] px-3 py-1 text-base font-bold text-white">
            {doc.issuer}
          </span>
          {blocks[0] && (
            <div className="mt-3 text-xs leading-relaxed text-[#555]">
              {blocks[0].lines.map((l, i) => (
                <p key={i}>{l}</p>
              ))}
            </div>
          )}
          <div className="mt-4 text-sm text-[#333]">
            {doc.reference && (
              <p className="font-semibold">Purchase Order # {doc.reference}</p>
            )}
            {doc.docDate && <p className="text-[#555]">Order Date: {doc.docDate}</p>}
          </div>
        </div>

        <div className="max-w-[45%] space-y-4 text-sm">
          {blocks.slice(1).map((b) => (
            <div key={b.heading}>
              <p
                className={cn(
                  "font-bold",
                  b.accent ? "text-[#1c6fd6]" : "text-[#333]"
                )}
              >
                {b.heading}
              </p>
              <div
                className={cn(
                  "text-xs leading-relaxed",
                  b.accent ? "text-[#1c6fd6]" : "text-[#555]"
                )}
              >
                {b.lines.map((l, i) => (
                  <p key={i}>{l}</p>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {doc.meta.length > 0 && (
        <div className="mt-6 grid grid-cols-2 gap-x-8 gap-y-1.5 border-t border-[#e2e2e2] pt-4 md:grid-cols-4">
          {doc.meta.map((m) => (
            <div key={m.label}>
              <p className="text-[11px] uppercase tracking-wide text-[#999]">
                {m.label}
              </p>
              <p className="text-sm text-[#333]">{m.value}</p>
            </div>
          ))}
        </div>
      )}

      <div className="mt-6">
        <SkinTable doc={doc} c={table} />
      </div>

      {doc.totals && doc.totals.length > 0 && (
        <div className="mt-4 flex justify-end">
          <div className="w-72 space-y-1">
            {doc.totals.map((t) => (
              <div
                key={t.label}
                className={cn(
                  "flex items-center justify-between border-b border-[#e2e2e2] py-1 text-sm text-[#222]",
                  t.emphasis && "border-b-0 text-base font-bold"
                )}
              >
                <span className={cn(!t.emphasis && "text-[#666]")}>
                  {t.label}
                </span>
                <span>{t.value}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {doc.footnote && (
        <p className="mt-6 border-t border-[#e2e2e2] pt-3 text-xs text-[#777]">
          {doc.footnote}
        </p>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Proof of delivery (formal letter, section bars)
 * ------------------------------------------------------------------ */

function ReceivingStamp({ stamp }: { stamp: DocStamp }) {
  const ink = stamp.tone === "exception" ? "#b3261e" : "#1f4fa3";
  return (
    <div
      aria-label={`Stamp: ${stamp.title}, ${stamp.date}`}
      role="img"
      className="w-44 shrink-0 -rotate-6 select-none rounded-md border-[3px] p-1 opacity-85 mix-blend-multiply"
      style={{ borderColor: ink, color: ink }}
    >
      <div
        className="flex flex-col items-center gap-0.5 rounded-sm border px-2 py-2 text-center"
        style={{ borderColor: ink }}
      >
        <span className="text-lg font-black uppercase leading-none tracking-[0.2em]">
          {stamp.title}
        </span>
        <span
          className="my-1 w-full border-y py-0.5 font-mono text-sm font-bold tracking-wider"
          style={{ borderColor: ink }}
        >
          {stamp.date}
        </span>
        {stamp.lines.map((l) => (
          <span
            key={l}
            className="text-[10px] font-semibold uppercase leading-tight tracking-wide"
          >
            {l}
          </span>
        ))}
      </div>
    </div>
  );
}

function PodLetterBody({ doc }: { doc: SourceDoc }) {
  const NAVY = "#1a3a6b";
  return (
    <div className="rounded-md border border-[#e2e2e2] bg-white px-8 py-7 shadow-sm">
      <div
        className="flex items-end justify-between border-b-2 pb-2"
        style={{ borderColor: NAVY }}
      >
        <p
          className="text-sm font-bold uppercase tracking-wide"
          style={{ color: NAVY }}
        >
          {doc.issuer}
        </p>
        {doc.reference && (
          <span className="font-mono text-xs text-[#666]">{doc.reference}</span>
        )}
      </div>

      <h4 className="mt-4 text-lg font-semibold text-[#222]">{doc.docLabel}</h4>

      <div
        className="mt-5 px-3 py-1.5 text-xs font-bold uppercase tracking-wide text-white"
        style={{ backgroundColor: NAVY }}
      >
        Delivery details
      </div>
      <dl className="divide-y divide-[#eee]">
        {doc.meta.map((m) => (
          <div key={m.label} className="flex gap-4 px-1 py-2 text-sm">
            <dt className="w-48 shrink-0 font-semibold text-[#333]">
              {m.label}
            </dt>
            <dd className="text-[#444]">{m.value}</dd>
          </div>
        ))}
      </dl>

      <div
        className="mt-5 px-3 py-1.5 text-xs font-bold uppercase tracking-wide text-white"
        style={{ backgroundColor: NAVY }}
      >
        Delivery checks
      </div>
      <dl>
        {doc.rows.map((row) => {
          const hl = doc.highlightRowIds.includes(row.id);
          return (
            <div
              key={row.id}
              className={cn(
                "flex items-center justify-between gap-4 px-1 py-2 text-sm",
                "border-b border-[#eee] last:border-0",
                hl && cn(HIGHLIGHT_BG, "border-l-4 border-l-[#e9a300] pl-2")
              )}
            >
              <span
                className={cn("font-semibold text-[#333]", hl && "font-bold")}
              >
                {row.cells[doc.columns[0].key]}
              </span>
              <span className="text-[#444]">
                {row.cells[doc.columns[doc.columns.length - 1].key]}
              </span>
            </div>
          );
        })}
      </dl>

      {doc.partyBlocks && doc.partyBlocks.length > 0 && (
        <>
          {doc.partyBlocks.map((b) => (
            <div key={b.heading}>
              <div
                className="mt-5 px-3 py-1.5 text-xs font-bold uppercase tracking-wide text-white"
                style={{ backgroundColor: NAVY }}
              >
                {b.heading}
              </div>
              <div className="px-1 py-2 text-sm leading-relaxed text-[#444]">
                {b.lines.map((l, i) => (
                  <p key={i}>{l}</p>
                ))}
              </div>
            </div>
          ))}
        </>
      )}

      {doc.signature && doc.signature.length > 0 && (
        <>
          <div
            className="mt-5 px-3 py-1.5 text-xs font-bold uppercase tracking-wide text-white"
            style={{ backgroundColor: NAVY }}
          >
            Recipient signature
          </div>
          <div className="mt-4 flex items-center gap-6 px-1">
            <div className="flex min-w-0 flex-1 flex-col gap-6">
              {doc.signature.map((s) => (
                <div key={s.label} className="flex items-end gap-3 text-sm">
                  <span className="shrink-0 text-[#333]">{s.label}:</span>
                  <span
                    className="flex-1 border-b border-[#999] pb-0.5 text-base text-[#222]"
                    style={{ fontFamily: SIGNATURE_FONT }}
                  >
                    {s.value ?? "\u00a0"}
                  </span>
                </div>
              ))}
            </div>
            {doc.stamp && <ReceivingStamp stamp={doc.stamp} />}
          </div>
        </>
      )}

      {doc.footnote && (
        <p className="mt-6 border-t border-[#e2e2e2] pt-3 text-xs italic text-[#777]">
          {doc.footnote}
        </p>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * SaaS app screens — PricerX and trade-promotion systems
 * ------------------------------------------------------------------ */

function AppBody({ doc, accent }: { doc: SourceDoc; accent: string }) {
  const table: TableClasses = {
    headRow: "border-b",
    headCell:
      "px-4 py-2 text-left text-[11px] font-medium uppercase tracking-wide text-muted-foreground",
    row: (hl) => cn("border-b last:border-0", hl && HIGHLIGHT_BG),
    cell: (hl, first) =>
      cn(
        "px-4 py-2.5 text-sm text-foreground",
        hl && "font-semibold",
        first && hl && "border-l-4 border-l-[#e9a300]"
      ),
  };
  return (
    <div className="overflow-hidden rounded-lg border bg-white shadow-sm">
      <div
        className="flex items-center justify-between px-5 py-3"
        style={{ backgroundColor: `${accent}14` }}
      >
        <div className="flex items-center gap-2">
          <span
            className="h-6 w-6 rounded-md"
            style={{ backgroundColor: accent }}
          />
          <span className="text-sm font-bold" style={{ color: accent }}>
            {doc.issuer}
          </span>
        </div>
        {doc.reference && (
          <span
            className="rounded-full border px-2 py-0.5 font-mono text-xs"
            style={{ borderColor: `${accent}55`, color: accent }}
          >
            {doc.reference}
          </span>
        )}
      </div>

      <div className="border-b px-5 py-4">
        <h4 className="text-lg font-semibold text-foreground">{doc.docLabel}</h4>
      </div>

      <MetaGrid
        doc={doc}
        className="grid grid-cols-2 gap-4 border-b px-5 py-4 md:grid-cols-4"
        labelClass="text-[11px] text-muted-foreground"
        valueClass="text-sm font-medium text-foreground"
      />

      <SkinTable doc={doc} c={table} />

      {doc.totals && doc.totals.length > 0 && (
        <div className="space-y-1 border-t px-5 py-4">
          {doc.totals.map((t) => (
            <div
              key={t.label}
              className={cn(
                "flex items-center justify-between text-sm",
                t.emphasis && "text-base font-semibold"
              )}
            >
              <span className={cn(!t.emphasis && "text-muted-foreground")}>
                {t.label}
              </span>
              <span>{t.value}</span>
            </div>
          ))}
        </div>
      )}

      {doc.footnote && (
        <div className="border-t px-5 py-3">
          <p className="text-sm text-muted-foreground">{doc.footnote}</p>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Generic fallback (unchanged look for scenarios not yet skinned)
 * ------------------------------------------------------------------ */

function GenericBody({
  doc,
  expanded,
  setExpanded,
}: {
  doc: SourceDoc;
  expanded: boolean;
  setExpanded: (fn: (v: boolean) => boolean) => void;
}) {
  const collapsible =
    typeof doc.initialVisibleRows === "number" &&
    doc.rows.length > doc.initialVisibleRows;
  const visibleRows =
    collapsible && !expanded
      ? doc.rows.slice(0, doc.initialVisibleRows)
      : doc.rows;
  const rowNoun = doc.rowNoun ?? "rows";
  return (
    <div className="rounded-lg border bg-card shadow-sm">
      <div className="flex items-start justify-between border-b px-6 py-5">
        <div>
          <p className="text-xs uppercase tracking-wide text-muted-foreground">
            {doc.issuer ?? "Source Document"}
          </p>
          <p className="text-xl font-bold">{doc.docLabel}</p>
        </div>
        {doc.reference && (
          <p className="font-mono text-sm text-muted-foreground">
            {doc.reference}
          </p>
        )}
      </div>

      <MetaGrid
        doc={doc}
        className="grid grid-cols-2 gap-4 border-b px-6 py-4 md:grid-cols-4"
        labelClass="text-xs text-muted-foreground"
        valueClass="text-sm font-medium"
      />

      <div className="px-2 py-2">
        <table className="w-full border-collapse">
          <thead>
            <tr className="border-b">
              {doc.columns.map((col) => (
                <th
                  key={col.key}
                  className={cn(
                    "px-4 py-2 text-left text-sm font-medium text-muted-foreground",
                    col.align === "right" && "text-right"
                  )}
                >
                  {col.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {visibleRows.map((row) => {
              const highlighted = doc.highlightRowIds.includes(row.id);
              return (
                <tr
                  key={row.id}
                  className={cn(
                    "border-b last:border-0",
                    highlighted &&
                      "border-l-4 border-l-amber-500 bg-yellow-100"
                  )}
                >
                  {doc.columns.map((col) => (
                    <td
                      key={col.key}
                      className={cn(
                        "px-4 py-2.5 text-sm",
                        col.align === "right" && "text-right",
                        highlighted && "font-medium"
                      )}
                    >
                      {row.cells[col.key]}
                    </td>
                  ))}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {collapsible && (
        <div className="flex items-center justify-between border-t px-6 py-3">
          <p className="text-xs text-muted-foreground">
            Showing {visibleRows.length} of {doc.rows.length} {rowNoun}
          </p>
          <Button
            variant="ghost"
            size="sm"
            className="h-auto px-2 py-1 text-xs font-medium"
            onClick={() => setExpanded((v) => !v)}
          >
            {expanded ? "Show fewer" : `Show all ${doc.rows.length} ${rowNoun}`}
          </Button>
        </div>
      )}

      {doc.totals && doc.totals.length > 0 && (
        <div className="space-y-1 border-t px-6 py-4">
          {doc.totals.map((total) => (
            <div
              key={total.label}
              className={cn(
                "flex items-center justify-between text-sm",
                total.emphasis && "text-base font-semibold"
              )}
            >
              <span className={cn(!total.emphasis && "text-muted-foreground")}>
                {total.label}
              </span>
              <span>{total.value}</span>
            </div>
          ))}
        </div>
      )}

      {doc.noteList && doc.noteList.length > 0 ? (
        <div className="space-y-2 border-t px-6 py-3">
          {doc.noteList.map((item, i) => (
            <div key={i} className="flex gap-3 text-sm leading-relaxed">
              <span className="w-32 shrink-0 font-medium text-foreground">
                {item.label}
              </span>
              <span className="text-muted-foreground">{item.detail}</span>
            </div>
          ))}
        </div>
      ) : (
        doc.footnote && (
          <div className="border-t px-6 py-3">
            <p className="text-sm text-muted-foreground">{doc.footnote}</p>
          </div>
        )
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Modal shell
 * ------------------------------------------------------------------ */

export function SourceDocPreview({
  doc,
  onClose,
}: {
  doc: SourceDoc;
  onClose: () => void;
}) {
  const [mounted, setMounted] = useState(false);
  const [expanded, setExpanded] = useState(false);
  useEffect(() => setMounted(true), []);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);
  if (!mounted) return null;

  const skin = doc.skin ?? "generic";

  let body: ReactNode;
  switch (skin) {
    case "sap":
      body = <SapBody doc={doc} />;
      break;
    case "printed-po":
      body = <PrintedPoBody doc={doc} />;
      break;
    case "pod-letter":
      body = <PodLetterBody doc={doc} />;
      break;
    case "pricerx":
      body = <AppBody doc={doc} accent="#4f46e5" />;
      break;
    case "trade":
      body = <AppBody doc={doc} accent="#047857" />;
      break;
    default:
      body = (
        <GenericBody doc={doc} expanded={expanded} setExpanded={setExpanded} />
      );
  }

  // Portaled to <body> so the modal never inherits text alignment or
  // stacking context from the table cell that opened it.
  return createPortal(
    <div
      className="fixed inset-0 z-[80] flex items-center justify-center bg-black/60 p-6 text-left backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label={doc.title}
        className="flex max-h-[85vh] w-full max-w-3xl flex-col rounded-xl border bg-white shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b px-6 py-4">
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            <h3 className="text-lg font-semibold">{doc.title}</h3>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose} aria-label="Close">
            <X className="h-5 w-5" />
          </Button>
        </div>

        <div className="space-y-5 overflow-y-auto px-6 py-5">
          {body}

          {doc.highlightRowIds.length > 0 && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span className="inline-block h-3 w-3 rounded-sm border border-amber-200 border-l-2 border-l-amber-500 bg-yellow-100" />
              {doc.highlightNote ??
                "Highlighted rows are the lines this screen's decision is based on."}
            </div>
          )}
        </div>
      </div>
    </div>,
    document.body
  );
}

export function SourceDocTrigger({
  doc,
  label = "View source document",
  variant = "outline",
  size = "sm",
  className,
}: {
  doc: SourceDoc;
  label?: string;
  variant?: "outline" | "ghost" | "default" | "secondary";
  size?: "sm" | "default";
  className?: string;
}) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button
        variant={variant}
        size={size}
        className={cn("whitespace-nowrap", className)}
        onClick={() => setOpen(true)}
      >
        <FileText className="h-4 w-4" />
        {label}
      </Button>
      {open && <SourceDocPreview doc={doc} onClose={() => setOpen(false)} />}
    </>
  );
}

/**
 * Wraps arbitrary row content (a card, a list item) so the whole thing opens
 * a source document — for lists where every row is its own file, not just
 * a single labeled button.
 */
export function SourceDocRowTrigger({
  doc,
  children,
  className,
}: {
  doc: SourceDoc;
  children: ReactNode;
  className?: string;
}) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className={cn(
          "w-full rounded-lg text-left transition-colors hover:brightness-[0.97] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
          className
        )}
      >
        {children}
      </button>
      {open && <SourceDocPreview doc={doc} onClose={() => setOpen(false)} />}
    </>
  );
}
