"use client";

import { useEffect } from "react";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";

export interface KpiDetailRow {
  metric: string;
  value: string;
  status: string;
}

export interface KpiDetailData {
  label: string;
  value: string;
  details: KpiDetailRow[];
}

export function KpiDetailModal({
  kpi,
  onClose,
}: {
  kpi: KpiDetailData;
  onClose: () => void;
}) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label={`${kpi.label} details`}
        className="bg-gradient-to-br from-white via-gray-50 to-gray-100 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 rounded-2xl shadow-2xl max-w-md w-full border border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-primary/10 to-primary/5">
          <h3 className="font-bold text-lg text-foreground dark:text-white">{kpi.label} Details</h3>
          <button
            onClick={onClose}
            aria-label="Close"
            className="p-2 text-foreground dark:text-white hover:bg-white/50 dark:hover:bg-black/30 rounded-lg transition-all"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="p-6">
          <div className="text-4xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent mb-6">
            {kpi.value}
          </div>
          <div className="space-y-3">
            {kpi.details.map((detail, index) => (
              <div
                key={index}
                className="flex items-center justify-between py-3 px-4 rounded-lg bg-white/60 dark:bg-black/20 border border-gray-200 dark:border-gray-700 hover:shadow-md transition-all"
              >
                <span className="text-sm font-medium text-muted-foreground dark:text-gray-300">{detail.metric}</span>
                <div className="flex items-center gap-3">
                  <span className="font-semibold text-foreground dark:text-white">{detail.value}</span>
                  <span
                    className={cn(
                      "text-xs px-3 py-1 rounded-full font-medium",
                      detail.status === "Good"
                        ? "bg-gradient-to-r from-green-100 to-emerald-100 text-green-700 dark:from-green-900 dark:to-emerald-900 dark:text-green-300"
                        : detail.status === "Warning"
                          ? "bg-gradient-to-r from-yellow-100 to-amber-100 text-yellow-700 dark:from-yellow-900 dark:to-amber-900 dark:text-yellow-300"
                          : "bg-gradient-to-r from-red-100 to-rose-100 text-red-700 dark:from-red-900 dark:to-rose-900 dark:text-red-300"
                    )}
                  >
                    {detail.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
