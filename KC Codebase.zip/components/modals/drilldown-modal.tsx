"use client";

import { X } from "lucide-react";

export function DrilldownModal({
  title,
  data,
  onClose,
}: {
  title: string;
  data: Record<string, string | number>[];
  onClose: () => void;
}) {
  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gradient-to-br from-white via-gray-50 to-gray-100 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 rounded-2xl shadow-2xl max-w-2xl w-full max-h-[80vh] overflow-hidden border border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-primary/10 to-primary/5">
          <h3 className="font-bold text-lg text-foreground dark:text-white">{title}</h3>
          <button
            onClick={onClose}
            aria-label="Close"
            className="p-2 text-foreground dark:text-white hover:bg-white/50 dark:hover:bg-black/30 rounded-lg transition-all"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="p-6 overflow-auto max-h-[60vh]">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-200 dark:border-gray-700">
                {Object.keys(data[0] || {}).map((key) => (
                  <th
                    key={key}
                    className="text-left p-3 font-semibold text-muted-foreground dark:text-gray-300 bg-gray-50 dark:bg-gray-800/50"
                  >
                    {key.charAt(0).toUpperCase() + key.slice(1)}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {data.map((row, rowIndex) => (
                <tr
                  key={rowIndex}
                  className="border-b border-gray-100 dark:border-gray-800 hover:bg-gradient-to-r hover:from-primary/5 hover:to-transparent transition-all"
                >
                  {Object.values(row).map((value, cellIndex) => (
                    <td key={cellIndex} className="p-3 text-foreground dark:text-white font-medium">
                      {typeof value === "number" ? value.toLocaleString() : String(value)}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
