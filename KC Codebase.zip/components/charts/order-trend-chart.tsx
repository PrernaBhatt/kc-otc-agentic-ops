"use client";

import { useState } from "react";
import { ChevronRight } from "lucide-react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DrilldownModal } from "@/components/modals/drilldown-modal";
import { orderVolumeTrend } from "@/lib/data";

export function OrderTrendChart() {
  const [showDrilldown, setShowDrilldown] = useState(false);

  return (
    <>
      <Card className="bg-gradient-to-br from-white via-gray-50 to-white dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 shadow-md border-gray-200 dark:border-gray-700 dark:text-white">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-semibold">Order Processing Trend</CardTitle>
            <button
              onClick={() => setShowDrilldown(true)}
              className="text-xs text-primary flex items-center hover:underline"
            >
              Drill Down <ChevronRight className="h-3 w-3" />
            </button>
          </div>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={orderVolumeTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e6e6e6" />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} stroke="#989898" interval={0} />
              <YAxis tick={{ fontSize: 11 }} stroke="#989898" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "white",
                  border: "1px solid #e6e6e6",
                  borderRadius: "8px",
                  fontSize: "12px",
                }}
              />
              <Area
                type="monotone"
                dataKey="automated"
                stackId="1"
                stroke="#4a9232"
                fill="#4a9232"
                fillOpacity={0.6}
                name="Automated"
              />
              <Area
                type="monotone"
                dataKey="manual"
                stackId="1"
                stroke="#f59e0b"
                fill="#f59e0b"
                fillOpacity={0.6}
                name="Manual"
              />
            </AreaChart>
          </ResponsiveContainer>
          <div className="flex items-center justify-center gap-4 mt-2 text-xs">
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 rounded bg-[#4a9232]" />
              <span className="text-muted-foreground">Automated</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 rounded bg-[#f59e0b]" />
              <span className="text-muted-foreground">Manual</span>
            </div>
          </div>
        </CardContent>
      </Card>
      {showDrilldown && (
        <DrilldownModal
          title="Order Processing Details"
          data={orderVolumeTrend.map((point) => ({
            Month: point.month,
            "Total Orders": point.orders,
            Automated: point.automated,
            Manual: point.manual,
            "Automation %": `${((point.automated / point.orders) * 100).toFixed(1)}%`,
          }))}
          onClose={() => setShowDrilldown(false)}
        />
      )}
    </>
  );
}
