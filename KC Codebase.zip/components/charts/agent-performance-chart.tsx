"use client";

import { useState } from "react";
import { ChevronRight } from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DrilldownModal } from "@/components/modals/drilldown-modal";
import { agentPerformance } from "@/lib/data";

export function AgentPerformanceChart() {
  const [showDrilldown, setShowDrilldown] = useState(false);

  return (
    <>
      <Card className="bg-gradient-to-br from-white via-gray-50 to-white dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 shadow-md border-gray-200 dark:border-gray-700 dark:text-white">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-semibold">AI Agent Performance</CardTitle>
            <button
              onClick={() => setShowDrilldown(true)}
              className="text-xs text-primary flex items-center hover:underline"
            >
              Drill Down <ChevronRight className="h-3 w-3" />
            </button>
          </div>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={agentPerformance} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#e6e6e6" />
              <XAxis type="number" tick={{ fontSize: 11 }} stroke="#989898" ticks={[0, 85, 170, 255, 340]} interval={0} />
              <YAxis
                dataKey="agent"
                type="category"
                tick={{ fontSize: 10 }}
                width={70}
                stroke="#989898"
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "white",
                  border: "1px solid #e6e6e6",
                  borderRadius: "8px",
                  fontSize: "12px",
                }}
              />
              <Bar dataKey="processed" fill="#e6e6e6" name="Processed" radius={[0, 4, 4, 0]} />
              <Bar dataKey="success" fill="#4a9232" name="Successful" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
      {showDrilldown && (
        <DrilldownModal
          title="Agent Performance Details"
          data={agentPerformance.map((entry) => ({
            Agent: entry.agent,
            Processed: entry.processed,
            Successful: entry.success,
            "Success Rate": `${((entry.success / entry.processed) * 100).toFixed(1)}%`,
            Failed: entry.processed - entry.success,
          }))}
          onClose={() => setShowDrilldown(false)}
        />
      )}
    </>
  );
}
