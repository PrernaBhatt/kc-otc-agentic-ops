"use client";

import { useState } from "react";
import { ChevronRight } from "lucide-react";
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DrilldownModal } from "@/components/modals/drilldown-modal";
import { exceptionBreakdown } from "@/lib/data";

export function ExceptionBreakdownChart() {
  const [showDrilldown, setShowDrilldown] = useState(false);
  const total = exceptionBreakdown.reduce((sum, entry) => sum + entry.value, 0);

  return (
    <>
      <Card className="bg-gradient-to-br from-white via-gray-50 to-white dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 shadow-md border-gray-200 dark:border-gray-700 dark:text-white">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-semibold">Exception Breakdown</CardTitle>
            <button
              onClick={() => setShowDrilldown(true)}
              className="text-xs text-primary flex items-center hover:underline"
            >
              Drill Down <ChevronRight className="h-3 w-3" />
            </button>
          </div>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                isAnimationActive={true}
                animationDuration={1000}
                animationBegin={0}
                data={exceptionBreakdown}
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={75}
                paddingAngle={2}
                dataKey="value"
              >
                {exceptionBreakdown.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: "white",
                  border: "1px solid #e6e6e6",
                  borderRadius: "8px",
                  fontSize: "12px",
                }}
                formatter={(value) => [
                  `${value} (${((Number(value) / total) * 100).toFixed(0)}%)`,
                  "",
                ]}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex flex-wrap justify-center gap-2 mt-2">
            {exceptionBreakdown.map((entry) => (
              <div key={entry.name} className="flex items-center gap-1 text-xs">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }} />
                <span className="text-muted-foreground">{entry.name}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      {showDrilldown && (
        <DrilldownModal
          title="Exception Details"
          data={exceptionBreakdown.map((entry) => ({
            Type: entry.name,
            Count: entry.value,
            Percentage: `${((entry.value / total) * 100).toFixed(1)}%`,
            Status: entry.value > 20 ? "High" : entry.value > 15 ? "Medium" : "Low",
          }))}
          onClose={() => setShowDrilldown(false)}
        />
      )}
    </>
  );
}
