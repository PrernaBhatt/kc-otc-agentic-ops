"use client";

import { useState } from "react";
import { ChevronRight, TrendingDown, TrendingUp } from "lucide-react";
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DrilldownModal } from "@/components/modals/drilldown-modal";
import { dsoTrend } from "@/lib/data";

export function DsoTrendChart() {
  const [showDrilldown, setShowDrilldown] = useState(false);
  const latest = dsoTrend[dsoTrend.length - 1];
  const previous = dsoTrend[dsoTrend.length - 2];
  const change = latest.dso - previous.dso;

  return (
    <>
      <Card className="bg-gradient-to-br from-white via-gray-50 to-white dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 shadow-md border-gray-200 dark:border-gray-700 dark:text-white">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CardTitle className="text-sm font-semibold">DSO Trend</CardTitle>
              <Badge
                variant="outline"
                className={change < 0 ? "text-[var(--success)]" : "text-primary"}
              >
                {change < 0 ? (
                  <TrendingDown className="h-3 w-3 mr-1" />
                ) : (
                  <TrendingUp className="h-3 w-3 mr-1" />
                )}
                {Math.abs(change)} days
              </Badge>
            </div>
            <button
              onClick={() => setShowDrilldown(true)}
              className="text-xs text-primary flex items-center hover:underline"
            >
              Drill Down <ChevronRight className="h-3 w-3" />
            </button>
          </div>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={dsoTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e6e6e6" />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} stroke="#989898" interval={0} />
              <YAxis domain={[30, 50]} tick={{ fontSize: 11 }} stroke="#989898" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "white",
                  border: "1px solid #e6e6e6",
                  borderRadius: "8px",
                  fontSize: "12px",
                }}
              />
              <Line
                type="monotone"
                dataKey="dso"
                stroke="#d10000"
                strokeWidth={2}
                dot={{ fill: "#d10000", strokeWidth: 2 }}
                name="Actual DSO"
              />
              <Line
                type="monotone"
                dataKey="target"
                stroke="#4a9232"
                strokeWidth={2}
                strokeDasharray="5 5"
                dot={false}
                name="Target"
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
      {showDrilldown && (
        <DrilldownModal
          title="DSO Analysis"
          data={dsoTrend.map((point) => ({
            Month: point.month,
            "Actual DSO": `${point.dso} days`,
            Target: `${point.target} days`,
            Variance: `${point.dso - point.target} days`,
            Status: point.dso <= point.target ? "On Target" : "Above Target",
          }))}
          onClose={() => setShowDrilldown(false)}
        />
      )}
    </>
  );
}
