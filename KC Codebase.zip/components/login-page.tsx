"use client";

import { useState } from "react";
import Image from "next/image";
import { CircleAlert, Lock, User } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export function LoginPage({ onLogin }: { onLogin: () => void }) {
  const [username, setUsername] = useState("agenticuser");
  const [password, setPassword] = useState("otcworkspace");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSubmitting(true);
    setTimeout(() => {
      if (
        (username === "agenticuser" || username === "") &&
        (password === "otcworkspace" || password === "")
      ) {
        onLogin();
      } else {
        setError("Invalid username or password");
        setSubmitting(false);
      }
    }, 500);
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-black flex">
      <div className="relative z-10 flex min-h-screen w-full md:w-[30%] items-center justify-center px-4 py-8 bg-black">
        <div className="w-full max-w-md">
          <div className="rounded-xl border border-white/15 bg-black/80 backdrop-blur-sm shadow-2xl">
            <div className="p-8 space-y-6">
              <div className="text-center space-y-2">
                <h1 className="text-3xl font-bold text-white">Welcome Back</h1>
                <p className="text-slate-300">
                  Sign in to access the Order to Cash Workspace
                </p>
              </div>
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="space-y-2">
                  <Label
                    htmlFor="username"
                    className="text-slate-200 text-sm font-medium"
                  >
                    Username
                  </Label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                    <Input
                      id="username"
                      type="text"
                      placeholder="Enter your username"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      className="pl-10 bg-zinc-900/50 border-zinc-800 text-white placeholder:text-slate-500 focus:border-[#1868a5] focus:ring-[#1868a5]/30 h-11"
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label
                    htmlFor="password"
                    className="text-slate-200 text-sm font-medium"
                  >
                    Password
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                    <Input
                      id="password"
                      type="password"
                      placeholder="Enter your password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-10 bg-zinc-900/50 border-zinc-800 text-white placeholder:text-slate-500 focus:border-[#1868a5] focus:ring-[#1868a5]/30 h-11"
                      required
                    />
                  </div>
                </div>
                {error && (
                  <div className="flex items-center gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20">
                    <CircleAlert className="h-4 w-4 text-red-400 flex-shrink-0" />
                    <p className="text-sm text-red-400">{error}</p>
                  </div>
                )}
                <Button
                  type="submit"
                  disabled={submitting}
                  className="w-full h-11 bg-primary text-primary-foreground font-medium"
                >
                  {submitting ? "Signing in..." : "Sign In"}
                </Button>
              </form>
            </div>
            <div className="px-8 py-4 border-t border-white/5 bg-black/60">
              <p className="text-center text-xs text-slate-400">
                Agentic AI — Order to Cash Workspace
              </p>
            </div>
          </div>
          <p className="mt-6 text-center text-sm text-slate-400">
            Powered by TCS Manufacturing AI Axis
          </p>
        </div>
      </div>
      <div className="hidden md:block relative w-[70%] min-h-screen">
        <Image
          src="/images/logistics-bg.jpg"
          alt="Distribution centre with AI automation"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/60 to-transparent" />
      </div>
    </div>
  );
}
