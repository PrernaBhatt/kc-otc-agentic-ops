"use client";

import { useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  Bell,
  Bot,
  CircleAlert,
  CircleCheck,
  ClipboardCheck,
  Clock,
  DollarSign,
  FileCheck,
  Mail,
  MessageSquare,
  Package,
  Truck,
  Zap,
} from "lucide-react";

import {
  SourceDocTrigger,
  type SourceDoc,
} from "@/components/modals/source-doc-preview";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { stockPositions } from "@/lib/data/inventory";
import { findShipmentByOrder } from "@/lib/data/shipments";
import {
  buildInvoiceDoc,
  buildPodDoc,
  buildSalesOrderDoc,
  buildStockLedgerDoc,
} from "@/lib/docs";
import { formatMoney } from "@/lib/selectors";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

type FulfillmentStepStatus = "pending" | "running" | "complete";

interface FulfillmentStep {
  id: number;
  name: string;
  agent: string;
  icon: React.ReactNode;
  status: FulfillmentStepStatus;
  details: string[];
  systemIntegrations: string[];
}

interface AuditEntry {
  id: string;
  timestamp: string;
  agent: string;
  action: string;
  reasoning: string;
  integration?: string;
  status: "success" | "running" | "pending";
}

/** The order this post-approval ceremony fulfills (storyline anchor). */
const DEFAULT_ORDER_ID = "SO-710245";
/** Existing open invoice for the same customer, monitored by the dunning setup. */
const DUNNING_INVOICE_ID = "INV-12345";

/** "2026-08-25" → "Jan 25" for plain-language delivery promises. */
function formatShortDate(isoDate: string): string {
  const [year, month, day] = isoDate.split("-").map(Number);
  return new Date(year, month - 1, day).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
  });
}

export function FulfillmentFlow({
  orderId,
  onBack,
  onComplete,
}: {
  orderId?: string;
  onBack: () => void;
  onComplete: (orderId?: string) => void;
}) {
  const [currentStep, setCurrentStep] = useState(0);
  const [visibleSteps, setVisibleSteps] = useState<number[]>([]);
  const [auditTrail, setAuditTrail] = useState<AuditEntry[]>([]);
  const [showDunning, setShowDunning] = useState(false);
  const stepsScrollRef = useRef<HTMLDivElement>(null);
  const auditScrollRef = useRef<HTMLDivElement>(null);

  // Canonical data: the order comes from the shared store so status and
  // totals stay in sync with every other surface; the shipment is the
  // canonical SHP-004 planning record for this order.
  const { orders, allInvoices } = useOtcStore();
  const trackedOrderId = orderId ?? DEFAULT_ORDER_ID;
  const order = orders.find((o) => o.orderId === trackedOrderId);
  const shipment = findShipmentByOrder(trackedOrderId);
  const dunningInvoice = allInvoices.find(
    (inv) => inv.invoiceId === DUNNING_INVOICE_ID,
  );

  const lineCount = order?.lineItems.length ?? 0;
  const totalUnits =
    order?.lineItems.reduce((sum, line) => sum + line.qty, 0) ?? 0;

  const initialSteps: FulfillmentStep[] = [
    {
      id: 0,
      name: "Availability & Allocation",
      agent: "ATP Agent",
      icon: <ClipboardCheck className="h-5 w-5" />,
      status: "pending",
      details: [
        `Stock check passed for all ${lineCount} lines`,
        "Allocation reserved from warehouse",
        `Reserved for order: ${totalUnits.toLocaleString()} units`,
        "Allocation confirmed",
      ],
      systemIntegrations: [
        "Warehouse Management System",
        "Inventory Management System",
      ],
    },
    {
      id: 1,
      name: "Order Release",
      agent: "Order Management Agent",
      icon: <Package className="h-5 w-5" />,
      status: "pending",
      details: [
        `Release order ${trackedOrderId} from credit hold`,
        "Conditional release terms met: 20% prepayment confirmed",
        "Release approved by Credit Manager",
        "Send to warehouse fulfillment queue",
      ],
      systemIntegrations: [
        "Order Management System",
        "Credit Management System",
      ],
    },
    {
      id: 2,
      name: "Shipment Planning",
      agent: "Logistics Agent",
      icon: <Truck className="h-5 w-5" />,
      status: "pending",
      details: shipment
        ? [
            "Calculate optimal shipping route",
            `Carrier booked: ${shipment.carrier}`,
            `Estimated delivery: ${formatShortDate(shipment.promisedDate)} — the promised date`,
            `Shipment record ${shipment.shipmentId} created`,
          ]
        : [
            "Calculate optimal shipping route",
            "Carrier booking in progress",
            "Estimated delivery pending confirmation",
            "Create shipment record",
          ],
      systemIntegrations: [
        "Transportation Management System",
        "Carrier Booking System",
      ],
    },
    {
      id: 3,
      name: "Delivery Documentation",
      agent: "Document Agent",
      icon: <FileCheck className="h-5 w-5" />,
      status: "pending",
      details: [
        "Create packing list",
        "Prepare shipping labels",
        "Send documents to customer portal",
        "Queue order for billing after delivery confirmation",
      ],
      systemIntegrations: [
        "Document Management System",
        "Customer Portal",
      ],
    },
    {
      id: 4,
      name: "Payment Terms Setup",
      agent: "Dunning Agent",
      icon: <DollarSign className="h-5 w-5" />,
      status: "pending",
      details: [
        "Set up proactive payment reminders",
        "Schedule early reminders 7, 3, and 1 days before due date",
        "Configure promise-to-pay capture",
        "Activate monitoring for on-time payment",
      ],
      systemIntegrations: [
        "Payment Gateway",
        "Payment Reminder Platform",
        "Email Service",
      ],
    },
  ];

  // Source documents backing each step — rebuilt from live store/data each
  // render so the modal always shows current values.
  const orderSkus = order?.lineItems.map((line) => line.sku) ?? [];
  const matchingPositions = stockPositions.filter((p) =>
    orderSkus.includes(p.sku),
  );
  const stockLedgerDoc =
    matchingPositions.length > 0
      ? buildStockLedgerDoc(
          matchingPositions,
          matchingPositions.map((p) => p.sku),
          { orderId: trackedOrderId },
        )
      : buildStockLedgerDoc(stockPositions, [], {
          orderId: trackedOrderId,
          recommendation: `Stock reserved for all ${lineCount} lines on this order.`,
        });

  const stepDocs: Record<number, { doc: SourceDoc; label: string }> = {
    0: { doc: stockLedgerDoc, label: "View stock ledger" },
  };
  if (order) {
    stepDocs[1] = { doc: buildSalesOrderDoc(order), label: "View sales order" };
  }
  if (shipment) {
    stepDocs[2] = { doc: buildPodDoc(shipment), label: "View shipment record" };
  }
  if (dunningInvoice) {
    stepDocs[4] = { doc: buildInvoiceDoc(dunningInvoice), label: "View invoice" };
  }

  const [steps, setSteps] = useState<FulfillmentStep[]>(initialSteps);

  useEffect(() => {
    if (auditScrollRef.current) {
      auditScrollRef.current.scrollTop = auditScrollRef.current.scrollHeight;
    }
  }, [auditTrail]);

  useEffect(() => {
    if (stepsScrollRef.current) {
      stepsScrollRef.current.scrollTop = stepsScrollRef.current.scrollHeight;
    }
  }, [visibleSteps]);

  useEffect(() => {
    if (currentStep >= initialSteps.length) {
      setTimeout(() => {
        setShowDunning(true);
        const entry: AuditEntry = {
          id: `audit-dunning-${Date.now()}`,
          timestamp: new Date().toISOString(),
          agent: "Proactive Dunning Agent",
          action: "Early Payment Nudge Strategy Activated",
          reasoning:
            "To keep future processing touchless and avoid new holds, customer will receive proactive reminders to pay on time. This prevents credit issues and maintains smooth order flow.",
          integration: "Payment Reminder Platform + Email Service",
          status: "success",
        };
        setAuditTrail((prev) => [...prev, entry]);
        if (onComplete) {
          setTimeout(() => onComplete(orderId), 2000);
        }
      }, 1000);
      return;
    }
    setSteps((prev) =>
      prev.map((step, index) => ({
        ...step,
        status:
          index === currentStep
            ? "running"
            : index < currentStep
              ? "complete"
              : "pending",
      })),
    );
    const startEntry: AuditEntry = {
      id: `audit-start-${currentStep}-${Date.now()}`,
      timestamp: new Date().toISOString(),
      agent: initialSteps[currentStep].agent,
      action: `Starting ${initialSteps[currentStep].name}`,
      reasoning: `Initiating ${initialSteps[currentStep].name} to progress order fulfillment`,
      integration: initialSteps[currentStep].systemIntegrations[0],
      status: "running",
    };
    setAuditTrail((prev) => [...prev, startEntry]);
    setTimeout(() => {
      setVisibleSteps((prev) => [...prev, currentStep]);
    }, 500);
    initialSteps[currentStep].details.forEach((detail, index) => {
      setTimeout(() => {
        const detailEntry: AuditEntry = {
          id: `audit-detail-${currentStep}-${index}-${Date.now()}`,
          timestamp: new Date().toISOString(),
          agent: initialSteps[currentStep].agent,
          action: detail,
          reasoning: `Executing step ${index + 1} of ${initialSteps[currentStep].name} process`,
          integration:
            initialSteps[currentStep].systemIntegrations[
              index % initialSteps[currentStep].systemIntegrations.length
            ],
          status: "running",
        };
        setAuditTrail((prev) => [...prev, detailEntry]);
      }, 1000 + 800 * index);
    });
    setTimeout(() => {
      setSteps((prev) =>
        prev.map((step, index) => ({
          ...step,
          status: index === currentStep ? "complete" : step.status,
        })),
      );
      const completeEntry: AuditEntry = {
        id: `audit-complete-${currentStep}-${Date.now()}`,
        timestamp: new Date().toISOString(),
        agent: initialSteps[currentStep].agent,
        action: `${initialSteps[currentStep].name} Completed Successfully`,
        reasoning: "All checks passed. Order progressing to next stage.",
        status: "success",
      };
      setAuditTrail((prev) => [...prev, completeEntry]);
      setCurrentStep((prev) => prev + 1);
    }, 1000 + 800 * initialSteps[currentStep].details.length + 500);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentStep]);

  const progress = ((currentStep + 1) / initialSteps.length) * 100;

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-card border-b sticky top-0 z-10">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between mb-3">
            <Button variant="ghost" size="sm" onClick={onBack} className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Dashboard
            </Button>
            <Badge variant="secondary" className="gap-1">
              <Clock className="h-3 w-3" />
              Started {new Date().toLocaleTimeString()}
            </Badge>
          </div>
          <div className="space-y-3">
            <div>
              <h1 className="text-lg font-bold text-foreground">
                Fulfillment Progress
              </h1>
              <p className="text-sm text-muted-foreground">
                Order {trackedOrderId}
                {order ? ` - ${order.customerName}` : ""}
              </p>
            </div>
            <div className="grid grid-cols-4 gap-4">
              <div className="bg-muted/30 rounded-lg p-3">
                <div className="text-xs text-muted-foreground mb-1">
                  Order Value
                </div>
                <div className="text-sm font-semibold">
                  {order ? formatMoney(order.totalValue) : "—"}
                </div>
              </div>
              <div className="bg-muted/30 rounded-lg p-3">
                <div className="text-xs text-muted-foreground mb-1">
                  Decision
                </div>
                <div className="text-sm font-semibold text-green-600">
                  Conditional Release (20% prepay)
                </div>
              </div>
              <div className="bg-muted/30 rounded-lg p-3">
                <div className="text-xs text-muted-foreground mb-1">
                  Credit Manager
                </div>
                <div className="text-sm font-semibold">Approved</div>
              </div>
              <div className="bg-muted/30 rounded-lg p-3">
                <div className="text-xs text-muted-foreground mb-1">Status</div>
                <div className="text-sm font-semibold text-blue-600">
                  {order?.status ?? "Processing"}
                </div>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-xs text-muted-foreground mb-2">
                <span>Overall Progress</span>
                <span>{Math.round(progress)}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          </div>
        </div>
      </div>
      <div className="flex h-[calc(100vh-280px)]">
        <div className="flex-1 p-6 flex flex-col min-w-0">
          <div className="mb-6 bg-card rounded-lg border p-4">
            <div className="flex items-center justify-between gap-2">
              {steps.map((step, index) => (
                <div key={step.id} className="flex items-center flex-1">
                  <div className="flex flex-col items-center gap-2">
                    <div
                      className={cn(
                        "w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all",
                        step.status === "complete" &&
                          "bg-green-500 border-green-500 text-white",
                        step.status === "running" &&
                          "bg-blue-500 border-blue-500 text-white animate-pulse",
                        step.status === "pending" &&
                          "bg-muted border-muted-foreground/20 text-muted-foreground",
                      )}
                    >
                      {step.status === "complete" ? (
                        <CircleCheck className="h-5 w-5" />
                      ) : (
                        step.icon
                      )}
                    </div>
                    <div className="text-center">
                      <div className="text-xs font-medium whitespace-nowrap">
                        {step.name}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {step.agent}
                      </div>
                    </div>
                  </div>
                  {index < steps.length - 1 && (
                    <div
                      className={cn(
                        "flex-1 h-0.5 mx-2 transition-all",
                        step.status === "complete" ? "bg-green-500" : "bg-muted",
                      )}
                    />
                  )}
                </div>
              ))}
            </div>
          </div>
          <div
            ref={stepsScrollRef}
            className="flex-1 overflow-y-auto space-y-4 min-h-0"
          >
            {visibleSteps.map((stepIndex) => (
              <Card
                key={stepIndex}
                className={cn(
                  "animate-in fade-in slide-in-from-bottom-4 duration-500",
                  "border-l-4 border-l-blue-500",
                )}
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                        {steps[stepIndex].icon}
                      </div>
                      <div>
                        <CardTitle className="text-base">
                          {steps[stepIndex].name}
                        </CardTitle>
                        <CardDescription className="text-xs">
                          {steps[stepIndex].agent}
                        </CardDescription>
                      </div>
                    </div>
                    {steps[stepIndex].status === "complete" && (
                      <Badge
                        variant="secondary"
                        className="bg-green-100 text-green-700"
                      >
                        <CircleCheck className="h-3 w-3 mr-1" />
                        Complete
                      </Badge>
                    )}
                    {steps[stepIndex].status === "running" && (
                      <Badge
                        variant="secondary"
                        className="bg-blue-100 text-blue-700"
                      >
                        <Clock className="h-3 w-3 mr-1" />
                        Running
                      </Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-2 gap-x-4 gap-y-2">
                    {steps[stepIndex].details.map((detail, index) => (
                      <div
                        key={index}
                        className="flex items-start gap-2 text-sm"
                      >
                        <CircleCheck className="h-4 w-4 text-green-500 shrink-0 mt-0.5" />
                        <span className="text-muted-foreground">{detail}</span>
                      </div>
                    ))}
                  </div>
                  {stepDocs[stepIndex] && (
                    <div>
                      <SourceDocTrigger
                        doc={stepDocs[stepIndex].doc}
                        label={stepDocs[stepIndex].label}
                      />
                    </div>
                  )}
                  <div className="pt-3 border-t">
                    <div className="text-xs font-medium text-muted-foreground mb-2">
                      System Integrations
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {steps[stepIndex].systemIntegrations.map(
                        (integration, index) => (
                          <Badge
                            key={index}
                            variant="outline"
                            className="text-xs"
                          >
                            <Zap className="h-3 w-3 mr-1" />
                            {integration}
                          </Badge>
                        ),
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
            {showDunning && (
              <Card className="animate-in fade-in slide-in-from-bottom-4 duration-500 border-l-4 border-l-orange-500">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center">
                      <Bell className="h-5 w-5 text-orange-600" />
                    </div>
                    <div>
                      <CardTitle className="text-base">
                        Proactive Dunning Strategy Activated
                      </CardTitle>
                      <CardDescription className="text-xs">
                        Smart Payment Reminders
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                    <div className="flex items-start gap-3">
                      <CircleAlert className="h-5 w-5 text-orange-600 shrink-0" />
                      <div>
                        <div className="font-medium text-sm text-orange-900 mb-1">
                          Early Payment Nudge Message
                        </div>
                        <p className="text-sm text-orange-800">
                          To keep future processing touchless and avoid new
                          holds, please ensure timely payment for this order.
                          Our proactive system will send friendly reminders at
                          key milestones to help you stay on track.
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="text-xs font-medium text-muted-foreground">
                      Scheduled Nudges
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center gap-3 text-sm">
                        <Mail className="h-4 w-4 text-blue-500" />
                        <span className="flex-1">
                          Email reminder 7 days before due date
                        </span>
                        <Badge variant="outline" className="text-xs">
                          Scheduled
                        </Badge>
                      </div>
                      <div className="flex items-center gap-3 text-sm">
                        <MessageSquare className="h-4 w-4 text-green-500" />
                        <span className="flex-1">
                          SMS reminder 3 days before due date
                        </span>
                        <Badge variant="outline" className="text-xs">
                          Scheduled
                        </Badge>
                      </div>
                      <div className="flex items-center gap-3 text-sm">
                        <Bell className="h-4 w-4 text-orange-500" />
                        <span className="flex-1">
                          Portal notification 1 day before due date
                        </span>
                        <Badge variant="outline" className="text-xs">
                          Scheduled
                        </Badge>
                      </div>
                    </div>
                  </div>
                  {dunningInvoice && (
                    <div className="flex items-center gap-3">
                      <SourceDocTrigger
                        doc={buildInvoiceDoc(dunningInvoice)}
                        label="View invoice"
                      />
                      <span className="text-xs text-muted-foreground">
                        Open invoice {dunningInvoice.invoiceId} for{" "}
                        {dunningInvoice.customerName} is covered by the same
                        reminder plan.
                      </span>
                    </div>
                  )}
                  <div className="pt-3 border-t">
                    <div className="text-xs font-medium text-muted-foreground mb-2">
                      Benefits
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="bg-muted/30 rounded p-2">
                        <div className="text-xs text-muted-foreground">
                          Reduces Late Payments
                        </div>
                        <div className="text-sm font-semibold">-35%</div>
                      </div>
                      <div className="bg-muted/30 rounded p-2">
                        <div className="text-xs text-muted-foreground">
                          Prevents Credit Holds
                        </div>
                        <div className="text-sm font-semibold">-60%</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
        <div className="w-96 border-l bg-muted/10 flex flex-col">
          <div className="p-4 border-b bg-card">
            <h3 className="font-semibold text-sm">AI Agent Audit Trail</h3>
            <p className="text-xs text-muted-foreground mt-1">
              Real-time reasoning and actions
            </p>
          </div>
          <div
            ref={auditScrollRef}
            className="flex-1 overflow-y-auto p-4 space-y-3 min-h-0"
          >
            {auditTrail.map((entry) => (
              <div
                key={entry.id}
                className={cn(
                  "bg-card rounded-lg p-3 border-l-2 animate-in fade-in slide-in-from-right-2 duration-300",
                  entry.status === "success" && "border-l-green-500",
                  entry.status === "running" && "border-l-blue-500",
                  entry.status === "pending" && "border-l-gray-300",
                )}
              >
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <Bot className="h-4 w-4 text-blue-600" />
                    <span className="text-xs font-medium">{entry.agent}</span>
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {new Date(entry.timestamp).toLocaleTimeString()}
                  </span>
                </div>
                <div className="text-xs font-medium mb-1">{entry.action}</div>
                <div className="text-xs text-muted-foreground mb-2">
                  {entry.reasoning}
                </div>
                {entry.integration && (
                  <Badge variant="outline" className="text-xs">
                    <Zap className="h-3 w-3 mr-1" />
                    {entry.integration}
                  </Badge>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
