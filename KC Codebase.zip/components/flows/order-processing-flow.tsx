"use client";

import { useEffect, useRef, useState } from "react";
import { Spinner } from "@/components/agents/spinner";
import {
  Check,
  ChevronLeft,
  CircleAlert,
  CircleCheck,
  CircleX,
  Clock,
} from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { customers } from "@/lib/data";
import type { Customer, Order } from "@/lib/data";
import { useOtcStore } from "@/lib/store";

// The hero credit-hold order is owned by the guided run, so this flow never
// mutates its store record.
const GUIDED_RUN_ORDER_ID = "SO-710245";

type ProcessingStepStatus = "pending" | "processing" | "complete" | "blocked";

interface ProcessingStep {
  id: number;
  name: string;
  persona: string;
  description: string;
  status: ProcessingStepStatus;
  details: {
    checks?: string[];
    outputs?: string[];
    policies?: string[];
  };
}

interface AuditEntry {
  timestamp: string;
  step: string;
  action: string;
  status: "success" | "warning" | "error";
}

const usd = (n: number) => `$${n.toLocaleString("en-US")}`;

function buildSteps(order: Order, customer: Customer | undefined) {
  const limit = customer?.creditLimit ?? 0;
  const exposure = customer?.currentExposure ?? 0;
  const totalExposure = exposure + order.totalValue;
  const overLimit = totalExposure > limit;
  const prepayment = Math.round(order.totalValue * 0.2);
  const steps: ProcessingStep[] = [
    {
      id: 1,
      name: "Order Data Validation",
      persona: "Order Entry Associate",
      description:
        "Autonomous agent validates customer details, order items, and business rules",
      status: "pending",
      details: {
        checks: [
          "Customer ID verified in master data",
          "Item SKUs validated in catalog",
          "Quantities within allowed limits",
          "Delivery date validated",
          "Payment terms checked",
        ],
        outputs: [
          `Customer: ${order.customerName} (${customer?.creditRating ?? "n/a"})`,
          `Credit limit: ${usd(limit)}`,
          `Current exposure: ${usd(exposure)}`,
          `Order total: ${usd(order.totalValue)}`,
          `${order.lineItems.length} line items sellable`,
        ],
      },
    },
    {
      id: 2,
      name: "Pricing Agent",
      persona: "Commercial Team",
      description: "Apply pricing rules, discounts, rebates, and tax calculations",
      status: "pending",
      details: {
        checks: [
          "Base price from contract",
          "Volume discounts applied",
          "Currency conversion rules",
          "Tax calculations (GST/VAT)",
          "Promotional offers validated",
        ],
        outputs: [
          "Prices match contract terms",
          `${order.lineItems.length} lines priced correctly`,
          "Tax validation complete",
          `Order value: ${usd(order.totalValue)}`,
        ],
      },
    },
    {
      id: 3,
      name: "Credit Risk Evaluation",
      persona: "Credit Control Team",
      description:
        "Evaluate credit exposure and determine if order can be approved",
      status: "pending",
      details: {
        checks: [
          `Current exposure: ${usd(exposure)}`,
          `New order value: ${usd(order.totalValue)}`,
          `Total exposure: ${usd(totalExposure)}`,
          `Credit limit: ${usd(limit)}`,
        ],
        outputs: overLimit
          ? [
              "Credit exposure exceeds limit",
              `Exceeded by: ${usd(totalExposure - limit)}`,
              "Order placed on CREDIT HOLD",
              "Notification sent to Credit Team",
            ]
          : [
              "Within credit limit",
              `Headroom after order: ${usd(limit - totalExposure)}`,
              "Credit approved automatically",
            ],
      },
    },
    {
      id: 4,
      name: "Minimum Order Check",
      persona: "Order Management Team",
      description: "Check minimum order quantity requirements for cost efficiency",
      status: "pending",
      details: {
        checks: order.lineItems.map(
          (line, i) => `Line ${i + 1}: ${line.qty.toLocaleString("en-US")} units · ${line.sku}`
        ),
        outputs: [
          "All line items meet the minimum order quantity",
          "No minimum-order blocks detected",
        ],
      },
    },
    {
      id: 5,
      name: "Human-in-the-Loop Decision",
      persona: "Credit Control Team",
      description: overLimit
        ? "Credit team reviews AI recommendations and makes final decision"
        : "No human decision needed: the order is within its credit limit",
      status: "pending",
      details: overLimit
        ? {
            policies: [
              `Option A: Conditional Release (20% prepayment, ${usd(prepayment)})`,
              "Option B: Split Shipment (50/50 with COD)",
              "Option C: Hard Hold (Full prepayment)",
            ],
            outputs: [
              "Approved: Option A, Conditional Release",
              `LTV Score: ${customer?.ltvScore ?? "n/a"}`,
              `Churn Risk: ${customer?.churnRiskScore ?? "n/a"}`,
              `Relationship Tier: ${customer?.relationshipTier ?? "n/a"}`,
            ],
          }
        : { outputs: ["Released without manual touch"] },
    },
    {
      id: 6,
      name: "Availability & Allocation",
      persona: "Inventory Planner",
      description: "Check inventory availability and schedule fulfillment",
      status: "pending",
      details: {
        checks: [
          "Query real-time stock levels",
          "Check reserved vs available stock",
          "Calculate ATP for requested date",
          "Determine best fulfillment warehouse",
        ],
        outputs: [
          "All items available in stock",
          "Warehouse: Distribution Center 1",
          "Order ready for fulfillment",
        ],
      },
    },
  ];
  return { steps, overLimit, prepayment };
}

export function OrderProcessingFlow({
  order,
  onBack,
  onComplete,
}: {
  order: Order;
  onBack: () => void;
  onComplete: (orderId: string) => void;
}) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isRunning, setIsRunning] = useState(true);
  const [visibleSteps, setVisibleSteps] = useState<number[]>([]);
  const [auditTrail, setAuditTrail] = useState<AuditEntry[]>([]);
  const cardsScrollRef = useRef<HTMLDivElement>(null);
  const auditScrollRef = useRef<HTMLDivElement>(null);
  const [plan] = useState(() =>
    buildSteps(
      order,
      customers.find((c) => c.customerId === order.customerId)
    )
  );
  const { overLimit, prepayment } = plan;
  const { approveCreditHold, updateOrderStatus } = useOtcStore();
  const ownsRecord = order.orderId !== GUIDED_RUN_ORDER_ID;
  const [steps, setSteps] = useState<ProcessingStep[]>(plan.steps);
  const [isDone, setIsDone] = useState(false);
  const finishTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(
    () => () => {
      if (finishTimerRef.current) clearTimeout(finishTimerRef.current);
    },
    []
  );

  useEffect(() => {
    if (cardsScrollRef.current) {
      setTimeout(() => {
        cardsScrollRef.current?.scrollTo({
          top: cardsScrollRef.current.scrollHeight,
          behavior: "smooth",
        });
      }, 100);
    }
  }, [visibleSteps]);

  useEffect(() => {
    if (auditScrollRef.current) {
      setTimeout(() => {
        auditScrollRef.current?.scrollTo({
          top: auditScrollRef.current.scrollHeight,
          behavior: "smooth",
        });
      }, 100);
    }
  }, [auditTrail]);

  useEffect(() => {
    if (!isRunning) return;
    const timer = setTimeout(
      () => {
        if (currentStep < plan.steps.length) {
          setVisibleSteps((prev) => [...new Set([...prev, currentStep])]);
          setSteps((prev) =>
            prev.map((step, index) => ({
              ...step,
              status:
                index === currentStep
                  ? "processing"
                  : index < currentStep
                    ? "complete"
                    : step.status,
            })),
          );
          const step = plan.steps[currentStep];
          setAuditTrail((prev) => [
            ...prev,
            {
              timestamp: new Date().toLocaleTimeString(),
              step: step.name,
              action: `Started ${step.name}`,
              status: "success",
            },
          ]);
          finishTimerRef.current = setTimeout(() => {
            setSteps((prev) =>
              prev.map((s, index) => ({
                ...s,
                status:
                  index === currentStep
                    ? currentStep === 2 && overLimit
                      ? "blocked"
                      : "complete"
                    : index < currentStep
                      ? "complete"
                      : s.status,
              })),
            );
            setAuditTrail((prev) => [
              ...prev,
              {
                timestamp: new Date().toLocaleTimeString(),
                step: step.name,
                action:
                  currentStep === 2 && overLimit
                    ? "Credit hold applied, awaiting decision"
                    : `Completed ${step.name}`,
                status: currentStep === 2 && overLimit ? "warning" : "success",
              },
            ]);
            if (currentStep === 2 && overLimit) {
              setIsRunning(false);
            } else if (currentStep < plan.steps.length - 1) {
              setCurrentStep((prev) => prev + 1);
            } else {
              setIsRunning(false);
              setIsDone(true);
              if (ownsRecord) updateOrderStatus(order.orderId, "Fulfilled", null);
            }
          }, 3500);
        }
      },
      currentStep === 0 ? 800 : 4500,
    );
    return () => clearTimeout(timer);
  }, [currentStep, isRunning, plan, overLimit, ownsRecord, order.orderId, updateOrderStatus]);

  const handleApprove = () => {
    if (ownsRecord) approveCreditHold(order.orderId);
    setAuditTrail((prev) => [
      ...prev,
      {
        timestamp: new Date().toLocaleTimeString(),
        step: "Credit Control",
        action: `Approved Option A: conditional release, ${usd(prepayment)} prepayment`,
        status: "success",
      },
    ]);
    setSteps((prev) =>
      prev.map((step, index) => ({
        ...step,
        status: index === 2 ? "complete" : step.status,
      })),
    );
    setCurrentStep(3);
    setIsRunning(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              if (isDone) onComplete(order.orderId);
              onBack();
            }}
            className="gap-2"
          >
            <ChevronLeft className="h-4 w-4" />
            Back to Orders
          </Button>
          <div>
            <h2 className="text-2xl font-bold text-foreground">
              Order Processing Flow
            </h2>
            <p className="text-muted-foreground">
              Order {order.orderId} • {order.customerName}
            </p>
          </div>
        </div>
        <Badge
          variant={order.status === "Hold" ? "destructive" : "default"}
          className="text-sm"
        >
          {order.status}
        </Badge>
      </div>
      <Card className="p-6 bg-card overflow-x-auto">
        <div className="flex min-w-[640px] items-center justify-between">
          {steps.map((step, index) => (
            <div key={step.id} className="flex items-center flex-1">
              <div className="flex flex-col items-center gap-2">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all ${
                    step.status === "complete"
                      ? "bg-green-500 border-green-500 text-white"
                      : step.status === "processing"
                        ? "bg-blue-500 border-blue-500 text-white animate-pulse"
                        : step.status === "blocked"
                          ? "bg-amber-500 border-amber-500 text-white"
                          : "bg-background border-border text-muted-foreground"
                  }`}
                >
                  {step.status === "complete" ? (
                    <Check className="h-5 w-5" />
                  ) : step.status === "processing" ? (
                    <Clock className="h-5 w-5" />
                  ) : step.status === "blocked" ? (
                    <CircleAlert className="h-5 w-5" />
                  ) : (
                    <span>{step.id}</span>
                  )}
                </div>
                <div className="text-xs text-center max-w-[100px]">
                  <div className="font-medium">{step.name}</div>
                  <div className="text-muted-foreground text-[10px]">
                    {step.persona}
                  </div>
                </div>
              </div>
              {index < steps.length - 1 && (
                <div
                  className={`flex-1 h-0.5 mx-2 transition-all ${
                    steps[index + 1].status === "complete" ||
                    steps[index + 1].status === "processing" ||
                    steps[index + 1].status === "blocked"
                      ? "bg-green-500"
                      : "bg-border"
                  }`}
                />
              )}
            </div>
          ))}
        </div>
      </Card>
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="flex min-w-0 flex-col lg:col-span-2">
          <div
            ref={cardsScrollRef}
            className="flex-1 overflow-y-auto pr-2 space-y-4 max-h-[600px]"
          >
            {steps.map((step, index) =>
              visibleSteps.includes(index) ? (
                <Card
                  key={step.id}
                  className={`p-6 transition-all animate-in fade-in slide-in-from-bottom-4 duration-500 ${
                    step.status === "processing"
                      ? "border-blue-500 border-2 shadow-lg"
                      : step.status === "blocked"
                        ? "border-amber-500 border-2 shadow-lg"
                        : step.status === "complete"
                          ? "border-green-500 border"
                          : "opacity-60"
                  }`}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          step.status === "complete"
                            ? "bg-green-100 text-green-700"
                            : step.status === "processing"
                              ? "bg-blue-100 text-blue-700"
                              : step.status === "blocked"
                                ? "bg-amber-100 text-amber-700"
                                : "bg-gray-100 text-gray-700"
                        }`}
                      >
                        {step.status === "complete" ? (
                          <CircleCheck className="h-4 w-4" />
                        ) : step.status === "processing" ? (
                          <Spinner size="sm" />
                        ) : step.status === "blocked" ? (
                          <CircleAlert className="h-4 w-4" />
                        ) : (
                          <span className="text-xs font-semibold">
                            {step.id}
                          </span>
                        )}
                      </div>
                      <div>
                        <h3 className="font-semibold text-foreground">
                          {step.name}
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          {step.persona}
                        </p>
                      </div>
                    </div>
                    <Badge
                      variant={
                        step.status === "complete"
                          ? "default"
                          : step.status === "processing"
                            ? "secondary"
                            : step.status === "blocked"
                              ? "destructive"
                              : "outline"
                      }
                    >
                      {step.status}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-4">
                    {step.description}
                  </p>
                  {step.details && (
                    <div className="space-y-3">
                      {step.details.checks && (
                        <div>
                          <h4 className="text-sm font-medium mb-2">
                            Validation Checks
                          </h4>
                          <ul className="space-y-1">
                            {step.details.checks.map((check, checkIndex) => (
                              <li
                                key={checkIndex}
                                className="text-sm text-muted-foreground flex items-start gap-2"
                              >
                                <span className="text-green-600 mt-0.5">✓</span>
                                {check}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                      {step.details.outputs && (
                        <div>
                          <h4 className="text-sm font-medium mb-2">Outputs</h4>
                          <ul className="space-y-1">
                            {step.details.outputs.map((output, outputIndex) => (
                              <li
                                key={outputIndex}
                                className={`text-sm flex items-start gap-2 ${
                                  output.includes("HOLD") ||
                                  output.includes("exceeds")
                                    ? "text-amber-600 font-medium"
                                    : "text-muted-foreground"
                                }`}
                              >
                                {output.includes("HOLD") ||
                                output.includes("exceeds") ? (
                                  <CircleAlert className="h-4 w-4 mt-0.5 flex-shrink-0" />
                                ) : (
                                  <span className="text-blue-600 mt-0.5">
                                    →
                                  </span>
                                )}
                                {output}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                      {step.details.policies && (
                        <div>
                          <h4 className="text-sm font-medium mb-2">
                            Decision Options (Golden Trio)
                          </h4>
                          <ul className="space-y-1">
                            {step.details.policies.map(
                              (policy, policyIndex) => (
                                <li
                                  key={policyIndex}
                                  className="text-sm text-muted-foreground flex items-start gap-2"
                                >
                                  <span className="text-blue-600 mt-0.5">
                                    •
                                  </span>
                                  {policy}
                                </li>
                              ),
                            )}
                          </ul>
                        </div>
                      )}
                    </div>
                  )}
                  {step.status === "blocked" && step.id === 3 && (
                    <div className="mt-4 pt-4 border-t">
                      <Button
                        onClick={handleApprove}
                        className="w-full bg-primary hover:bg-primary/90"
                      >
                        Approve Option A: Conditional Release ({usd(prepayment)} prepayment)
                      </Button>
                    </div>
                  )}
                </Card>
              ) : null,
            )}
            {isDone && (
              <Card className="p-6 border-green-500 border-2 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center bg-green-100 text-green-700">
                    <CircleCheck className="h-4 w-4" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-foreground">
                      {order.orderId} released to fulfillment
                    </h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {overLimit
                        ? `Released on conditional terms with a ${usd(prepayment)} prepayment, then allocated from Distribution Center 1.`
                        : "Cleared every check without a manual touch and allocated from Distribution Center 1."}
                    </p>
                  </div>
                </div>
                <Button
                  className="mt-4 w-full"
                  onClick={() => {
                    onComplete(order.orderId);
                    onBack();
                  }}
                >
                  Back to Orders
                </Button>
              </Card>
            )}
          </div>
        </div>
        <div>
          <Card className="p-4 h-80 flex flex-col lg:h-[600px]">
            <h3 className="font-semibold mb-4 text-foreground">Audit Trail</h3>
            <div
              ref={auditScrollRef}
              className="flex-1 overflow-y-auto space-y-3"
            >
              {auditTrail.map((entry, index) => (
                <div
                  key={index}
                  className="border-l-2 border-border pl-3 pb-3 last:pb-0"
                >
                  <div className="flex items-start gap-2">
                    <div
                      className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 ${
                        entry.status === "success"
                          ? "bg-green-100 text-green-700"
                          : entry.status === "warning"
                            ? "bg-amber-100 text-amber-700"
                            : "bg-red-100 text-red-700"
                      }`}
                    >
                      {entry.status === "success" ? (
                        <CircleCheck className="h-3 w-3" />
                      ) : entry.status === "warning" ? (
                        <CircleAlert className="h-3 w-3" />
                      ) : (
                        <CircleX className="h-3 w-3" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-muted-foreground">
                        {entry.timestamp}
                      </p>
                      <p className="text-xs font-medium text-foreground">
                        {entry.step}
                      </p>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {entry.action}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
