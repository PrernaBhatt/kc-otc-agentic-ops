"use client";

import {
  Activity,
  CircleAlert,
  DollarSign,
  FileText,
  Landmark,
  LayoutDashboard,
  MessageSquare,
  Package,
  Scale,
  Shield,
  ShieldCheck,
  Truck,
  Undo2,
  Users,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export type ViewId =
  | "dashboard"
  | "credit-review"
  | "orders"
  | "shipments"
  | "transactions"
  | "exceptions"
  | "copilot"
  | "agents"
  | "billing"
  | "cash-application"
  | "collections"
  | "chargebacks"
  | "deductions"
  | "accounts"
  | "audit";

type NavItem = {
  id: ViewId;
  label: string;
  icon: typeof LayoutDashboard;
  children?: NavItem[];
};

const NAV_ITEMS: NavItem[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "accounts", label: "Accounts", icon: Users },
  {
    id: "orders",
    label: "Order Management",
    icon: Package,
    children: [
      { id: "credit-review", label: "Review Order Hold", icon: Shield },
      { id: "shipments", label: "Track & Trace", icon: Truck },
    ],
  },
  { id: "billing", label: "Billing", icon: FileText },
  { id: "deductions", label: "Deductions", icon: Scale },
  { id: "chargebacks", label: "Chargebacks", icon: Undo2 },
  { id: "collections", label: "Collections", icon: DollarSign },
  { id: "cash-application", label: "Cash Application", icon: Landmark },
  { id: "transactions", label: "Transactions", icon: FileText },
  { id: "exceptions", label: "Exceptions", icon: CircleAlert },
  { id: "copilot", label: "Co-Pilot", icon: MessageSquare },
  { id: "agents", label: "Agent Activity", icon: Activity },
  { id: "audit", label: "Audit trail", icon: ShieldCheck },
];

function NavButton({
  item,
  active,
  sub = false,
  onSelect,
}: {
  item: NavItem;
  active: boolean;
  sub?: boolean;
  onSelect: (view: ViewId) => void;
}) {
  const Icon = item.icon;
  return (
    <Button
      variant="ghost"
      aria-current={active ? "page" : undefined}
      className={cn(
        "w-full justify-start rounded-lg text-left overflow-hidden",
        sub ? "h-8 gap-2.5 px-3 font-normal" : "gap-3 font-medium",
        active
          ? "bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground"
          : "text-[var(--sidebar-foreground)] hover:bg-[var(--sidebar-accent)]"
      )}
      onClick={() => onSelect(item.id)}
    >
      <Icon className={cn("flex-shrink-0", sub ? "h-3.5 w-3.5" : "h-4 w-4")} />
      <span className="text-sm truncate">{item.label}</span>
    </Button>
  );
}

export function Sidebar({
  activeView,
  onViewChange,
}: {
  activeView: ViewId;
  onViewChange: (view: ViewId) => void;
}) {
  return (
    <aside className="sticky top-14 h-[calc(100vh-3.5rem)] w-60 flex-shrink-0 border-r bg-[var(--sidebar)] overflow-y-auto">
      <div className="flex flex-col h-full py-4 px-3">
        <nav>
          <ul className="flex flex-col gap-1">
            {NAV_ITEMS.map((item) => (
              <li key={item.id} className="flex flex-col gap-1">
                <NavButton
                  item={item}
                  active={activeView === item.id}
                  onSelect={onViewChange}
                />
                {item.children && (
                  <ul
                    aria-label={`${item.label} sub-pages`}
                    className="ml-5 flex flex-col gap-1 border-l border-[var(--sidebar-border)] pl-2"
                  >
                    {item.children.map((child) => (
                      <li key={child.id}>
                        <NavButton
                          item={child}
                          sub
                          active={activeView === child.id}
                          onSelect={onViewChange}
                        />
                      </li>
                    ))}
                  </ul>
                )}
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </aside>
  );
}
