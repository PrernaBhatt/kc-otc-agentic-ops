"use client";

import { Bell, Bot, LogOut, Search, Settings } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";

export function Header({ onLogout }: { onLogout: () => void }) {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-[var(--header-bg)] border-[var(--header-bg)]">
      <div className="flex h-14 items-center justify-between px-6">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded bg-[#3c93cb]">
              <Bot className="h-5 w-5 text-white" />
            </div>
            <div className="flex items-center gap-2">
              <span className="text-base font-normal text-[var(--header-foreground)]">
                Order to Cash Workspace
              </span>
              <Badge
                variant="outline"
                className="bg-[var(--header-bg)] text-[var(--header-foreground)] border-[var(--header-foreground)]/30 text-xs"
              >
                v2.4.3
              </Badge>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative hidden md:block">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--header-foreground)]/50" />
            <Input
              placeholder="Search requests, SKUs, vendors..."
              className="w-96 pl-10 bg-[var(--header-bg)] border-[var(--header-foreground)]/20 text-[var(--header-foreground)] placeholder:text-[var(--header-foreground)]/50"
            />
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="relative text-[var(--header-foreground)] hover:bg-[var(--header-foreground)]/10"
          >
            <Bell className="h-5 w-5" />
            <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-[var(--tangerine)] text-[9px] font-medium text-[var(--tangerine-foreground)]">
              4
            </span>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="text-[var(--header-foreground)] hover:bg-[var(--header-foreground)]/10"
          >
            <Settings className="h-5 w-5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={onLogout}
            aria-label="Sign out"
            className="text-[var(--header-foreground)] hover:bg-[var(--header-foreground)]/10"
          >
            <LogOut className="h-5 w-5" />
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                className="flex items-center gap-2 text-[var(--header-foreground)] hover:bg-[var(--header-foreground)]/10 h-8 px-2"
              >
                <div className="flex h-7 w-7 items-center justify-center rounded-full bg-primary text-primary-foreground text-sm font-semibold">
                  A
                </div>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>Profile</DropdownMenuItem>
              <DropdownMenuItem>Preferences</DropdownMenuItem>
              <DropdownMenuItem onClick={onLogout}>Sign Out</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      <div className="h-0.5 w-full bg-[var(--tangerine)]" />
    </header>
  );
}
