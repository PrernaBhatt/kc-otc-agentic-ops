"use client";

import { useState } from "react";
import { MessageSquare } from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import { endToEndWorkflow } from "@/components/agents/workflow-definitions";
import {
  SourceDocTrigger,
  type SourceDoc,
} from "@/components/modals/source-doc-preview";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { stockPositions } from "@/lib/data/inventory";
import { orders } from "@/lib/data/orders";
import { anomalyPo, findInboundPo } from "@/lib/data/pipeline-orders";
import { recallNotices } from "@/lib/data/regulatory";
import { allShipments } from "@/lib/data/shipments";
import {
  buildAgingReportDoc,
  buildBankStatementDoc,
  buildBillingReportDoc,
  buildClaimDoc,
  buildInboundPoDoc,
  buildPodDoc,
  buildRecallNoticeDoc,
  buildStockLedgerDoc,
} from "@/lib/docs";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

type StageStatus = "complete" | "active" | "pending";

/**
 * The ten agents grouped by the workflow that owns them. Customer Service sits
 * in two groups on purpose — the same team answers order questions and works
 * disputes.
 */
const AGENT_GROUPS: { label: string; stageIds: string[] }[] = [
  {
    label: "Order Management",
    stageIds: [
      "po_intake",
      "po_understanding",
      "regulatory",
      "fulfillment",
      "pod",
      "service_hub",
    ],
  },
  { label: "Billing", stageIds: ["billing"] },
  { label: "Cash Application", stageIds: ["cash_application"] },
  { label: "Disputes & Deductions", stageIds: ["deductions", "service_hub"] },
  { label: "Collections", stageIds: ["collections"] },
];

function StatusDot({ status }: { status: StageStatus }) {
  return (
    <span
      className={cn(
        "h-2 w-2 rounded-full",
        status === "complete" && "bg-[var(--success)]",
        status === "active" && "bg-primary animate-pulse",
        status === "pending" && "bg-muted-foreground/30"
      )}
    />
  );
}

/**
 * Agent orchestration strip — merges the ten-stage workflow MAP and the live
 * activity FEED into one horizontal row. Each node shows its live status; the
 * selected node expands its input / what it does / output, the sample
 * document, and its recent activity timeline (the folded-in feed). One row,
 * everything else on click.
 */
export function EndToEndWorkflowCard() {
  const { receipts, deductionCases, allInvoices, billedOrderIds } =
    useOtcStore();
  const firstActive =
    endToEndWorkflow.find((s) => s.status === "active")?.id ??
    endToEndWorkflow[0].id;
  const [selected, setSelected] = useState<string>(firstActive);

  const regulatedPo = findInboundPo("SO-710262");
  const podShipment = allShipments.find((s) => s.shipmentId === "SHP-001");
  const billingRows = allShipments
    .filter((s) => s.status === "Delivered" && s.deliveredDate)
    .flatMap((shipment) => {
      const order = orders.find((o) => o.orderId === shipment.orderId);
      if (!order) return [];
      return [
        {
          orderId: order.orderId,
          customerName: order.customerName,
          deliveredDate: shipment.deliveredDate as string,
          amount: order.totalValue,
          invoiced:
            allInvoices.some((inv) => inv.orderId === order.orderId) ||
            billedOrderIds.has(order.orderId),
        },
      ];
    });

  const stageDocs: Record<string, SourceDoc | undefined> = {
    po_intake: regulatedPo
      ? buildInboundPoDoc(regulatedPo, "extraction")
      : undefined,
    po_understanding: buildInboundPoDoc(anomalyPo, "extraction"),
    regulatory: buildRecallNoticeDoc(recallNotices[0]),
    fulfillment: buildStockLedgerDoc(stockPositions, ["SKU-K110", "SKU-K220"], {
      orderId: "SO-710262",
    }),
    pod: podShipment ? buildPodDoc(podShipment) : undefined,
    billing: buildBillingReportDoc(billingRows),
    cash_application: buildBankStatementDoc(receipts),
    deductions: deductionCases[0] ? buildClaimDoc(deductionCases[0]) : undefined,
    collections: buildAgingReportDoc(allInvoices),
  };

  const step = endToEndWorkflow.find((s) => s.id === selected)!;
  const doc = stageDocs[selected];

  const activeCount = endToEndWorkflow.filter(
    (s) => s.status === "active"
  ).length;

  return (
    <Card className="bg-card">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <AgentIcon type="orchestrator" size="sm" className="text-primary" />
            Agent Orchestration
          </CardTitle>
          <Badge variant="outline" className="whitespace-nowrap gap-1.5">
            <StatusDot status="active" />
            {activeCount} agents working now
          </Badge>
        </div>
        <p className="text-sm text-muted-foreground">
          Ten agents grouped by the workflow that owns them — live status across
          the order-to-cash flow. Select a stage for its activity and the
          document it produces.
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Live agent nodes, clustered under the workflow that owns them */}
        <div className="flex items-stretch gap-3">
          {AGENT_GROUPS.map((group) => (
            <div
              key={group.label}
              className="flex min-w-0 flex-col overflow-hidden rounded-xl border-2 bg-muted/40 shadow-sm"
              style={{ flex: `${group.stageIds.length} 1 0%` }}
            >
              {/* Fixed height so a wrapped label still aligns every node row */}
              <div className="flex min-h-[2.5rem] items-center justify-center border-b-2 bg-muted px-1.5 py-1 text-center text-[11px] font-semibold uppercase leading-tight tracking-wide text-muted-foreground">
                {group.label}
              </div>
              <div className="flex flex-1 items-stretch gap-1.5 p-2">
                {group.stageIds.map((stageId) => {
                  const s = endToEndWorkflow.find((w) => w.id === stageId);
                  if (!s) return null;
                  const isSelected = selected === s.id;
                  return (
                    <button
                      key={`${group.label}-${s.id}`}
                      type="button"
                      onClick={() => setSelected(s.id)}
                      title={`${s.agent} — ${s.latest}`}
                      className={cn(
                        "flex flex-1 min-w-0 cursor-pointer flex-col items-center justify-start gap-1.5 rounded-md border px-1 pt-2.5 pb-2 text-center transition-all",
                        isSelected
                          ? "border-primary bg-primary/5 ring-1 ring-primary/40"
                          : "border-border bg-card hover:border-primary/40"
                      )}
                    >
                      <div className="relative">
                        <div
                          className={cn(
                            "flex h-9 w-9 items-center justify-center rounded-full",
                            isSelected
                              ? "bg-primary text-primary-foreground"
                              : "bg-primary/10 text-primary"
                          )}
                        >
                          <AgentIcon type={s.agentType} size="sm" />
                        </div>
                        <span className="absolute -right-0.5 -top-0.5 rounded-full bg-card p-0.5">
                          <StatusDot status={s.status} />
                        </span>
                      </div>
                      <span className="flex min-h-[26px] items-center text-[11px] font-medium leading-tight text-foreground">
                        {s.stage}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Selected stage: detail + folded-in activity feed */}
        <div className="rounded-lg border bg-muted/20 p-4">
          <div className="flex items-center justify-between gap-2 mb-3">
            <div className="flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-primary">
                <AgentIcon type={step.agentType} size="sm" />
              </div>
              <div>
                <div className="text-sm font-semibold text-foreground flex items-center gap-2">
                  {step.agent}
                  <Badge
                    variant="outline"
                    className={cn(
                      "gap-1 text-[10px] capitalize",
                      step.status === "active" &&
                        "border-primary/40 text-primary",
                      step.status === "complete" &&
                        "border-[var(--success)]/40 text-[var(--success)]"
                    )}
                  >
                    <StatusDot status={step.status} />
                    {step.status}
                  </Badge>
                </div>
                <div className="text-xs text-muted-foreground">
                  {step.persona}
                </div>
              </div>
            </div>
            {doc ? (
              <SourceDocTrigger doc={doc} label="View sample output" />
            ) : (
              <Badge
                variant="outline"
                className="gap-1 whitespace-nowrap border-primary/40 bg-primary/5 text-primary"
              >
                <MessageSquare className="h-3 w-3" />
                Handled in the Query Hub
              </Badge>
            )}
          </div>

          <div className="grid gap-3 md:grid-cols-3">
            <div className="rounded-md bg-background p-3">
              <div className="text-xs font-semibold text-muted-foreground mb-1">
                Reads (input)
              </div>
              <p className="text-sm text-foreground">{step.input}</p>
            </div>
            <div className="rounded-md bg-background p-3">
              <div className="text-xs font-semibold text-muted-foreground mb-1">
                What it does
              </div>
              <p className="text-sm text-foreground">{step.description}</p>
            </div>
            <div className="rounded-md bg-background p-3">
              <div className="text-xs font-semibold text-muted-foreground mb-1">
                Produces (output)
              </div>
              <p className="text-sm text-foreground">{step.expectedOutput}</p>
            </div>
          </div>

          {/* Folded-in live activity for this stage */}
          <div className="mt-3 border-t pt-3">
            <div className="text-xs font-semibold text-muted-foreground mb-2">
              Recent activity
            </div>
            <div className="space-y-2">
              {step.recentActivity.map((a, i) => (
                <div key={i} className="flex items-center gap-2 text-sm">
                  <StatusDot status={a.status} />
                  <span className="font-mono text-xs text-muted-foreground tabular-nums w-10 shrink-0">
                    {a.time}
                  </span>
                  <span className="text-foreground">{a.text}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
