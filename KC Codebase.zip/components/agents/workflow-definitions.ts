export interface WorkflowStepDefinition {
  id: number;
  agent: string;
  agentType: string;
  persona: string;
  description: string;
  policies: string[];
  validations: string[];
  expectedOutput: string;
}

export const orderWorkflow: WorkflowStepDefinition[] = [
  {
    id: 1,
    agent: "PO Validation Agent",
    agentType: "validation",
    persona: "Order Management Team - Order Entry Associate",
    description:
      "Detect a new request arriving through any channel (customer portal, email, electronic order feed, or customer service entry)",
    policies: [
      "Capture Customer Details",
      "Capture Order Details",
      "Capture Additional Info",
    ],
    validations: [
      "Check mandatory fields (Order ID, Customer ID, Item SKU, Quantity)",
      "Validate the customer exists in our records",
      "Validate Item SKU exists in catalog",
      "Check Quantity against allowed limits",
    ],
    expectedOutput:
      "Customer Info validated, Order details verified, Item codes exist in product master",
  },
  {
    id: 2,
    agent: "Pricing Agent",
    agentType: "pricing",
    persona: "Order Management Team - Commercial Team",
    description:
      "Apply correct pricing, discounts, rebates, and payment terms based on contractual agreements",
    policies: [
      "Pricing Rules: Apply base price, currency conversion, tax rules",
      "Discount Policies: Promotional, seasonal, loyalty-based",
    ],
    validations: [
      "Apply volume-based discounts correctly",
      "Ensure currency conversion rules applied",
      "Validate tax inclusion/exclusion settings",
      "Detect anomalies in pricing using AI",
    ],
    expectedOutput:
      "Price per item matches contract, Discounts/promotions applied correctly",
  },
  {
    id: 3,
    agent: "Credit Check Agent",
    agentType: "credit",
    persona: "Order Management Team",
    description:
      "Credit risk evaluation to ensure orders accepted only from customers meeting financial risk criteria",
    policies: [
      "Customer Credit Limit check",
      "Outstanding Balance review",
      "Payment Terms validation",
    ],
    validations: [
      "Credit Exposure = Outstanding Receivables + Open Sales Orders + New Order Value",
      "If Credit Exposure ≤ Credit Limit → Approve order",
      "If Credit Exposure > Credit Limit → Place order on Credit Hold",
    ],
    expectedOutput:
      "Order Blocked - Credit HOLD (Exposure exceeds limit by $110K)",
  },
  {
    id: 4,
    agent: "Minimum Order Agent",
    agentType: "validation",
    persona: "Order Management Team - Credit Analyst",
    description:
      "Make sure the order meets the minimum order quantity that keeps production, packaging and logistics cost-efficient",
    policies: [
      "Minimum order quantity check against the product master",
      "Operational cost control",
    ],
    validations: [
      "Check the ordered quantity against the minimum order quantity",
      "If the quantity is below the minimum, hold the order",
      "Trigger notification for exception handling",
    ],
    expectedOutput: "Order quantity checked against the minimum order quantity",
  },
  {
    id: 5,
    agent: "Human Review",
    agentType: "orchestrator",
    persona: "Credit Control Team",
    description: "Human review for unblocking blocked sales orders",
    policies: [
      "Credit review and limit adjustment",
      "Minimum order exception approval",
    ],
    validations: [
      "Review customer financial standing",
      "Decide to increase credit limit or override",
      "Special customer request evaluation",
    ],
    expectedOutput:
      "UnBlocking of Sales Order, Agentic workflows for proactive customer updates",
  },
  {
    id: 6,
    agent: "Availability & Allocation Agent",
    agentType: "atp",
    persona: "Sales Order Fulfillment - Inventory Planner",
    description:
      "Check stock to confirm the products are available and can be fulfilled accurately",
    policies: ["Availability calculated from live stock", "Warehouse optimization"],
    validations: [
      "Query Inventory: Check real-time stock levels across warehouses",
      "Availability: current stock, inbound supply, outbound commitments",
      "Allocation based on priority rules (customer tier, service level, order type)",
    ],
    expectedOutput:
      "Required quantity available, Stock allocated, Delivery date determined",
  },
];

export const billingWorkflow: WorkflowStepDefinition[] = [
  {
    id: 1,
    agent: "Report Extraction Agent",
    agentType: "extraction",
    persona: "Billing Analyst",
    description:
      "Extract eligible billing report based on trigger post order delivery",
    policies: ["Order delivered within PO Limits"],
    validations: [
      "Validate proof of delivery against the sales order",
      "Sales order line items — product code and quantity match",
      "Route order to OM for validation failures",
    ],
    expectedOutput: "Validation Pass - SO vs order delivered matched",
  },
  {
    id: 2,
    agent: "PO Validation Agent",
    agentType: "po",
    persona: "Billing Analyst",
    description: "Validation of delivered order based on PO",
    policies: ["PO validation with Order Delivered & Sales order"],
    validations: [
      "Delivered to right customer, Bill-to, Ship-to",
      "Service/Product included - Quantity, unit price, Total Gross value",
      "Right tax % considered",
      "Pay terms and freight charges validated",
    ],
    expectedOutput: "Validation Pass - Scenario meeting required criteria",
  },
  {
    id: 3,
    agent: "Contract Validation Agent",
    agentType: "contract",
    persona: "Billing Analyst",
    description: "Validation of delivered order based on Contract",
    policies: ["Contract validation with Order Delivered & Sales order"],
    validations: [
      "Pricing elements based on product categories",
      "Applicable discounts - Promotions, trade discounts, rebates",
      "Validity date of pricing agreements",
    ],
    expectedOutput: "Validation Pass - Contract pricing verified",
  },
  {
    id: 4,
    agent: "Document Extraction Agent",
    agentType: "document",
    persona: "Billing Analyst",
    description: "Verify availability of supporting documents for billing",
    policies: ["Validation of required documents critical for invoice delivery"],
    validations: [
      "Check PO document availability",
      "Verify Proof of delivery",
      "Confirm special exception communications",
    ],
    expectedOutput: "All required documents available",
  },
  {
    id: 5,
    agent: "Billing Generation Agent",
    agentType: "invoice",
    persona: "Billing Analyst",
    description: "Generate invoice as per guidelines & schedules",
    policies: ["Invoice generation guidelines", "Billing schedule compliance"],
    validations: [
      "Invoice number generated",
      "All line items included",
      "Tax calculations verified",
    ],
    expectedOutput: "Invoice INV-12345 generated successfully",
  },
  {
    id: 6,
    agent: "Invoice Delivery Agent",
    agentType: "delivery",
    persona: "Billing Analyst",
    description:
      "Send invoice and supporting documents via agreed delivery mode",
    policies: [
      "Preferred channel from customer master",
      "Portal login and upload",
    ],
    validations: [
      "Send invoice via email/portal",
      "Upload supporting documents",
      "Confirm delivery receipt",
    ],
    expectedOutput: "Invoice delivered to customer portal successfully",
  },
];

/**
 * One step of the ten-stage end-to-end master workflow. Step ids match the
 * Order Management pipeline stage ids so the master card and the pipeline
 * always describe the same journey.
 */
export interface EndToEndActivity {
  time: string;
  text: string;
  status: "complete" | "active" | "pending";
}

export interface EndToEndStepDefinition {
  id: string;
  /** Short label under the node (2-3 words). */
  stage: string;
  agent: string;
  agentType: string;
  persona: string;
  /** Live status of this stage-agent, shown as the node dot. */
  status: "complete" | "active" | "pending";
  /** One-line latest action shown under the node (the folded-in feed). */
  latest: string;
  /** What the agent reads. */
  input: string;
  description: string;
  expectedOutput: string;
  /** Recent activity log for this stage (the folded-in Agent Activity Feed). */
  recentActivity: EndToEndActivity[];
}

export const endToEndWorkflow: EndToEndStepDefinition[] = [
  {
    id: "po_intake",
    stage: "PO Intake",
    agent: "PO Intake Agent",
    agentType: "po",
    persona: "Order Management Team",
    input:
      "Incoming purchase orders from the customer portal, email inbox, and electronic order feed",
    description:
      "Watch every channel and log each incoming purchase order the moment it arrives",
    expectedOutput: "The customer's purchase order as it was received",
    status: "complete",
    latest: "Logged PO-NBS-3321 from the customer portal",
    recentActivity: [
      { time: "08:12", text: "Detected new order on the customer portal", status: "complete" },
      { time: "08:12", text: "Logged purchase order PO-NBS-3321", status: "complete" },
    ],
  },
  {
    id: "po_understanding",
    stage: "PO Validation",
    agent: "PO Validation Agent",
    agentType: "extraction",
    persona: "Order Management Team",
    input: "The received purchase order and our customer, product and price records",
    description:
      "Read the purchase order, extract customer, products, quantities and prices, and flag anything that does not match our records",
    expectedOutput:
      "The purchase order with extracted fields and attention flags",
    status: "active",
    latest: "Flagged an 8% price gap on PO-HPB-8843",
    recentActivity: [
      { time: "08:14", text: "Extracted customer, products and quantities", status: "complete" },
      { time: "08:14", text: "Flagged unit price 8% above contract — routed to review", status: "active" },
    ],
  },
  {
    id: "regulatory",
    stage: "Regulatory Checks",
    agent: "Regulatory Check Agent",
    agentType: "validation",
    persona: "Quality & Compliance Manager",
    input: "The order lines, quality hold notices, allocation limits and customer licenses",
    description:
      "Check every order line for quality holds, allocation limits and customer licenses — a human decides every hold",
    expectedOutput: "The quality hold notice behind a stopped order",
    status: "active",
    latest: "Quality hold on SO-710262 — awaiting decision",
    recentActivity: [
      { time: "08:15", text: "Checked all lines for holds and licenses", status: "complete" },
      { time: "08:15", text: "Quality hold on lot LOT-88412 — decision pending", status: "active" },
    ],
  },
  {
    id: "fulfillment",
    stage: "Fulfillment",
    agent: "Fulfillment Agent",
    agentType: "atp",
    persona: "Logistics Team",
    input: "Warehouse stock positions and the order's requested quantities",
    description:
      "Check warehouse stock, propose the allocation for the order, and book the carrier once a human approves",
    expectedOutput: "The stock and allocation ledger for the order's products",
    status: "pending",
    latest: "Ready to allocate once the hold clears",
    recentActivity: [
      { time: "—", text: "Waiting on the regulatory decision", status: "pending" },
    ],
  },
  {
    id: "pod",
    stage: "POD",
    agent: "POD Validation Agent",
    agentType: "delivery",
    persona: "Logistics Team",
    input: "The shipment's carrier milestones and the delivery signature",
    description:
      "Follow the shipment's carrier milestones and capture the signed proof of delivery when the goods arrive",
    expectedOutput: "The signed proof of delivery from the carrier",
    status: "complete",
    latest: "Captured signed delivery for SO-710248",
    recentActivity: [
      { time: "11:20", text: "Followed carrier milestones to delivery", status: "complete" },
      { time: "11:20", text: "Captured signed proof of delivery", status: "complete" },
    ],
  },
  {
    id: "billing",
    stage: "Billing",
    agent: "Billing Agent",
    agentType: "billing",
    persona: "Billing Analyst",
    input: "Delivered orders and their proof of delivery",
    description:
      "List every delivered order that still needs an invoice and prepare each invoice for a human to approve and issue",
    expectedOutput: "The eligible billing report of delivered orders",
    status: "active",
    latest: "2 delivered orders awaiting an invoice",
    recentActivity: [
      { time: "12:03", text: "Listed delivered orders needing an invoice", status: "complete" },
      { time: "12:03", text: "Prepared drafts — awaiting human approval", status: "active" },
    ],
  },
  {
    id: "service_hub",
    stage: "Customer Service",
    agent: "Query Triage Agent",
    agentType: "orchestrator",
    persona: "Customer Service",
    input: "Incoming customer questions across email, portal and phone",
    description:
      "Read every incoming customer question, classify it, and route it to the owning team with a drafted reply for approval",
    expectedOutput:
      "The customer's question with a drafted reply, handled in the Query Hub",
    status: "active",
    latest: "7 customer questions triaged and drafted",
    recentActivity: [
      { time: "08:40", text: "Classified and routed 7 questions", status: "complete" },
      { time: "08:40", text: "Drafted replies — awaiting approval", status: "active" },
    ],
  },
  {
    id: "cash_application",
    stage: "Cash Application",
    agent: "Cash Application Agent",
    agentType: "credit",
    persona: "Billing Analyst",
    input: "The daily bank statement file and the open invoice list",
    description:
      "Read the daily bank statement and propose a match from every payment to the right customer invoice for approval",
    expectedOutput: "The daily bank statement with the payments to apply",
    status: "active",
    latest: "Proposed matches for 3 of 4 payments",
    recentActivity: [
      { time: "09:00", text: "Read the daily bank statement", status: "complete" },
      { time: "09:00", text: "Proposed invoice matches — awaiting approval", status: "active" },
    ],
  },
  {
    id: "deductions",
    stage: "Deductions",
    agent: "Deduction Agent",
    agentType: "document",
    persona: "Customer Service",
    input: "Short payments, debit memos and the supporting claim documents",
    description:
      "Open a case for every short payment or debit memo, collect the evidence, and recommend a resolution for a human decision",
    expectedOutput: "The customer's claim file behind the deduction case",
    status: "active",
    latest: "Built claim file for short-pay DED-001",
    recentActivity: [
      { time: "09:05", text: "Opened a case for the short payment", status: "complete" },
      { time: "09:05", text: "Collected evidence — recommendation ready", status: "active" },
    ],
  },
  {
    id: "collections",
    stage: "Collections",
    agent: "Collections Agent",
    agentType: "dunning",
    persona: "Collections Specialist",
    input: "Overdue invoices, customer risk scores and payment history",
    description:
      "Rank overdue invoices by value, lateness and customer risk, and draft payment reminders for human review",
    expectedOutput: "The receivables aging report that drives the worklist",
    status: "active",
    latest: "Ranked the overdue worklist by risk",
    recentActivity: [
      { time: "09:10", text: "Refreshed aging and ranked overdue invoices", status: "complete" },
      { time: "09:10", text: "Drafted reminders — awaiting review", status: "active" },
    ],
  },
];

export const cashCollectionsWorkflow: WorkflowStepDefinition[] = [
  {
    id: 1,
    agent: "Cash Application Agent",
    agentType: "billing",
    persona: "Billing Analyst",
    description:
      "Read the daily bank statement file and match each payment to the right customer invoice",
    policies: [
      "Match payments using the remittance details the customer sends",
      "Every proposed match needs a human approval before it is applied",
    ],
    validations: [
      "Compare payment amount and reference against open invoices",
      "Flag short payments and hand the gap over as a deduction case",
      "Park payments with no invoice reference as unapplied cash",
    ],
    expectedOutput:
      "Payment matches proposed with confidence scores — awaiting approval",
  },
  {
    id: 2,
    agent: "Deduction Agent",
    agentType: "document",
    persona: "Customer Service",
    description:
      "Build a case file for every short payment or customer debit memo, with a suggested reason",
    policies: [
      "Collect the invoice, delivery record, and customer claim as evidence",
      "Suggest a reason code with a confidence score",
    ],
    validations: [
      "Check the claim against the delivery record and supporting photos",
      "Confirm whether an agreement covers the claimed amount",
      "Route the case to the right team for a human decision",
    ],
    expectedOutput:
      "Deduction case ready with evidence and a recommended resolution",
  },
  {
    id: 3,
    agent: "Collections Agent",
    agentType: "dunning",
    persona: "Collections Specialist",
    description:
      "Rank overdue invoices by value, lateness, and customer risk, and draft a reminder for each",
    policies: [
      "Work the highest-priority balances first",
      "Drafted reminders go out only after human review",
    ],
    validations: [
      "Skip balances that are disputed or tied to an open deduction case",
      "Track every promise to pay and flag it if the date passes",
      "Suggest the next best step for each overdue invoice",
    ],
    expectedOutput:
      "Prioritized worklist with drafted reminders — awaiting review",
  },
  {
    id: 4,
    agent: "Provision Agent",
    agentType: "credit",
    persona: "Controller",
    description:
      "Calculate the bad debt reserve from how old each unpaid invoice is, plus known problem balances",
    policies: [
      "Apply an expected-loss rate to each age group of invoices",
      "Reserve disputed balances in full",
    ],
    validations: [
      "Recalculate the reserve whenever an invoice is paid or resolved",
      "Compare the required reserve to the balance already on the books",
      "Send the adjustment to the Controller for approval",
    ],
    expectedOutput:
      "Required reserve calculated — adjustment awaiting Controller approval",
  },
  {
    id: 5,
    agent: "Revenue Agent",
    agentType: "contract",
    persona: "Revenue Accountant",
    description:
      "Track which sales can be counted as revenue now and which must wait for delivery",
    policies: [
      "Count product revenue only when delivery is confirmed",
      "Spread service revenue over the months it covers",
    ],
    validations: [
      "Watch deliveries promised near month end for cut-off risk",
      "Hold back revenue for orders that have not been delivered",
      "Set aside contract rebates on every recognized sale",
    ],
    expectedOutput:
      "Recognition schedule current — one delivery near month end being watched",
  },
  {
    id: 6,
    agent: "Query Triage Agent",
    agentType: "delivery",
    persona: "Customer Service",
    description:
      "Read every incoming customer question, classify it, and route it to the right team with a drafted reply",
    policies: [
      "Sort each question into one of seven topics with a confidence score",
      "Drafted replies go out only after a human approves them",
    ],
    validations: [
      "Identify the customer, order, or invoice the question is about",
      "Assign the owning team and a response-time target",
      "Draft a reply from the same records the screens show",
    ],
    expectedOutput:
      "Questions classified and routed with drafted replies — awaiting approval",
  },
];

/**
 * Wholesaler chargeback validation. Five checks run on their own; the run
 * stops at the settlement decision and does not move until a person clicks.
 */
export const chargebackWorkflow: WorkflowStepDefinition[] = [
  {
    id: 1,
    agent: "Claim Intake Agent",
    agentType: "orchestrator",
    persona: "Contract Compliance - Claims Analyst",
    description:
      "Read the claim the wholesaler filed and identify the three parties behind it: us, the wholesaler, and the project they resold to",
    policies: [
      "Capture claim header and lines",
      "Identify the wholesaler and the end customer",
      "Establish the claim window",
    ],
    validations: [
      "Check the claim names a product we sell",
      "Check the wholesaler is a licensed distributor",
      "Check the claim window is closed",
    ],
    expectedOutput: "Claim read, parties identified, ready to validate",
  },
  {
    id: 2,
    agent: "Customer Eligibility Agent",
    agentType: "validation",
    persona: "Contract Compliance - Contract Administrator",
    description:
      "Check the project on the claim is actually covered by the contract the claim cites",
    policies: [
      "Test membership against the cited roster",
      "Look for a sibling site in the same owner group",
      "Find the contract the project is genuinely on",
    ],
    validations: [
      "Project appears on the cited roster on the claim date",
      "Membership is still in force",
      "The project has no competing agreement",
    ],
    expectedOutput:
      "Eligibility confirmed, or the correct contract identified instead",
  },
  {
    id: 3,
    agent: "Contract Pricing Agent",
    agentType: "pricing",
    persona: "Contract Compliance - Pricing Analyst",
    description:
      "Find the one price record in force for that project on that date, and compare it with what the claim used",
    policies: [
      "Pick the record by effective date, not by newest or cheapest",
      "Require a signed approval reference behind any price",
    ],
    validations: [
      "Claimed price matches an approved record for this project",
      "The record was in force across the claim window",
      "Any difference is quantified per unit",
    ],
    expectedOutput: "Approved price established and the difference measured",
  },
  {
    id: 4,
    agent: "Duplicate Screening Agent",
    agentType: "document",
    persona: "Contract Compliance - Claims Analyst",
    description:
      "Screen the claim against everything already settled for this wholesaler",
    policies: [
      "Compare wholesaler, project, product, window, units and amount",
      "Treat a confirmed duplicate as a rejection, not a risk score",
    ],
    validations: [
      "No settled claim matches on the identifying fields",
      "Nothing else in the same submission is a known duplicate",
    ],
    expectedOutput: "Duplicates identified and flagged for outright rejection",
  },
  {
    id: 5,
    agent: "Invoice Trace Agent",
    agentType: "atp",
    persona: "Order Management - Fulfilment Analyst",
    description:
      "Sum what we actually invoiced and delivered to that project inside the claim window",
    policies: [
      "Count only invoices dated inside the window",
      "Require a delivery record behind every invoice",
    ],
    validations: [
      "Claimed units are covered by invoices and deliveries",
      "Claimed units sit within what could physically have shipped",
    ],
    expectedOutput: "Supportable units established, unaccounted units isolated",
  },
  {
    id: 6,
    agent: "Settlement Recommendation Agent",
    agentType: "credit",
    persona: "Contract Compliance - Controller",
    description:
      "Put the evidence together into a recommended split and hand the decision to a person",
    policies: [
      "Separate the price finding from the quantity finding",
      "Never settle without a human decision",
    ],
    validations: [
      "The split adds back to the amount claimed",
      "Every rejected dollar has a named reason and a document behind it",
    ],
    expectedOutput:
      "Recommended settlement presented — waiting for a person to decide",
  },
  {
    id: 7,
    agent: "Settlement Agent",
    agentType: "invoice",
    persona: "Contract Compliance - Claims Analyst",
    description:
      "Record the decision, raise the credit note and hold payment on the rejected amount",
    policies: [
      "Post only what a person approved",
      "Attach the reason split to the rejection",
    ],
    validations: [
      "Credit note raised for the approved amount only",
      "Payment hold placed where the decision asked for one",
    ],
    expectedOutput: "Decision recorded, credit note issued, evidence retained",
  },
];

/**
 * Short-pay and deduction recovery. Three checks run on their own, then the
 * case stops twice: once to choose an action, once before anything is sent.
 */
export const deductionRecoveryWorkflow: WorkflowStepDefinition[] = [
  {
    id: 1,
    agent: "Cash Matching Agent",
    agentType: "orchestrator",
    persona: "Cash Application - Analyst",
    description:
      "Match the payment to the invoice and measure how far short it came in",
    policies: [
      "Reconcile invoice less withheld against the amount paid",
      "Quote the customer's own note verbatim",
    ],
    validations: [
      "The three figures reconcile",
      "The remittance names an invoice we recognise",
    ],
    expectedOutput: "Short payment confirmed and quantified",
  },
  {
    id: 2,
    agent: "Deduction Classification Agent",
    agentType: "validation",
    persona: "Trade Finance - Deduction Analyst",
    description:
      "Work out what kind of deduction this is by eliminating the readings that do not fit",
    policies: [
      "Test every candidate reason against the evidence",
      "Record why each one was ruled out",
    ],
    validations: [
      "Delivery records checked before ruling out a shortage",
      "Price records checked before ruling out a pricing claim",
      "Promotion agreements checked before ruling out an allowance",
    ],
    expectedOutput: "Reason established, with the eliminations behind it",
  },
  {
    id: 3,
    agent: "Root Cause Agent",
    agentType: "document",
    persona: "Trade Finance - Deduction Analyst",
    description:
      "Trace the deduction back to what caused it, and test whether the amounts match",
    policies: [
      "Follow the amount, not the description",
      "Link the case to the source claim",
    ],
    validations: [
      "The amount withheld matches the amount rejected",
      "The customer's note names the source claim",
    ],
    expectedOutput: "Root cause established and linked to its source",
  },
  {
    id: 4,
    agent: "Recovery Agent",
    agentType: "credit",
    persona: "Trade Finance - Credit Manager",
    description:
      "Rank the ways of dealing with it by what comes back against what it costs the relationship",
    policies: [
      "Show expected recovery and relationship cost together",
      "Recommend, never choose",
    ],
    validations: [
      "Every option carries an expected recovery figure",
      "Nothing is written until a person picks one",
    ],
    expectedOutput: "Options ranked — waiting for a person to choose",
  },
  {
    id: 5,
    agent: "Correspondence Agent",
    agentType: "invoice",
    persona: "Trade Finance - Deduction Analyst",
    description:
      "Draft the dispute letter from the evidence, ready for a person to edit and approve",
    policies: [
      "Every figure in the letter comes from the records",
      "Attach the evidence the letter cites",
    ],
    validations: [
      "The letter cites the claim, the rejection, the price record and the remittance",
      "Nothing is sent without an explicit approval",
    ],
    expectedOutput: "Letter drafted with evidence attached — nothing sent yet",
  },
  {
    id: 6,
    agent: "Recovery Agent",
    agentType: "dunning",
    persona: "Trade Finance - Credit Manager",
    description:
      "Send the approved letter, move the case into recovery and keep the evidence attached",
    policies: [
      "Send only what a person approved",
      "Record the repayment window on the case",
    ],
    validations: [
      "Letter sent with all cited documents",
      "Case status reflects the chosen action",
    ],
    expectedOutput: "Letter sent and the case moved into recovery",
  },
];
