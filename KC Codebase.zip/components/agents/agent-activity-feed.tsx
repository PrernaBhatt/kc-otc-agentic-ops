"use client";

import { CircleAlert, CircleCheck } from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import { Spinner } from "@/components/agents/spinner";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { AgentActivity } from "@/lib/data";
import { cn } from "@/lib/utils";

const agentColorMap: Record<string, { color: string }> = {
  orchestrator: { color: "bg-primary text-primary-foreground" },
  credit: { color: "bg-[var(--info)] text-white" },
  pricing: { color: "bg-[var(--success)] text-white" },
  ltv: { color: "bg-purple-500 text-white" },
  dunning: { color: "bg-[var(--warning)] text-[var(--warning-foreground)]" },
  validation: { color: "bg-[var(--success)] text-white" },
  billing: { color: "bg-teal-500 text-white" },
  atp: { color: "bg-cyan-500 text-white" },
};

export function AgentActivityFeed({
  activities,
}: {
  activities: AgentActivity[];
}) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <AgentIcon type="orchestrator" size="sm" className="text-primary" />
          Agent Activity Feed
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity, index) => {
            const agentColor =
              agentColorMap[activity.agentType] || agentColorMap.orchestrator;
            return (
              <div key={activity.id} className="flex gap-3">
                <div className="relative flex flex-col items-center">
                  <div
                    className={cn(
                      "flex h-10 w-10 items-center justify-center rounded-full",
                      agentColor.color
                    )}
                  >
                    {activity.status === "processing" ? (
                      <Spinner size="sm" className="text-white" />
                    ) : (
                      <AgentIcon
                        type={activity.agentType}
                        size="sm"
                        className="text-white"
                      />
                    )}
                  </div>
                  {index < activities.length - 1 && (
                    <div className="w-0.5 flex-1 bg-border mt-2" />
                  )}
                </div>
                <div className="flex-1 pb-4">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-medium text-sm">
                      {activity.agentName}
                    </span>
                    <Badge
                      variant={
                        activity.status === "complete"
                          ? "default"
                          : activity.status === "processing"
                            ? "secondary"
                            : "destructive"
                      }
                      className={cn(
                        "text-xs",
                        activity.status === "complete" &&
                          "bg-[var(--success)] text-white",
                        activity.status === "processing" &&
                          "bg-[var(--info)] text-white"
                      )}
                    >
                      {activity.status === "processing" && (
                        <Spinner size="sm" className="mr-1" />
                      )}
                      {activity.status === "complete" && (
                        <CircleCheck className="h-3 w-3 mr-1" />
                      )}
                      {(activity.status as string) === "error" && (
                        <CircleAlert className="h-3 w-3 mr-1" />
                      )}
                      {activity.status}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {activity.message}
                  </p>
                  <span className="text-xs text-muted-foreground/70">
                    {new Date(activity.timestamp).toLocaleTimeString()}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
