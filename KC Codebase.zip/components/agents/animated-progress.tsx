"use client";

import { cn } from "@/lib/utils";

export function AnimatedProgress({
  progress,
  label,
  showPercent = true,
  color = "primary",
  animated = true,
}: {
  progress: number;
  label?: string;
  showPercent?: boolean;
  color?: "primary" | "success" | "warning" | "info";
  animated?: boolean;
}) {
  return (
    <div className="w-full">
      {(label || showPercent) && (
        <div className="flex justify-between items-center mb-1">
          {label && <span className="text-sm text-muted-foreground">{label}</span>}
          {showPercent && (
            <span className="text-sm font-medium">{Math.round(progress)}%</span>
          )}
        </div>
      )}
      <div className="h-2 bg-muted rounded-full overflow-hidden">
        <div
          className={cn(
            "h-full rounded-full transition-all duration-500",
            {
              primary: "bg-primary",
              success: "bg-[var(--success)]",
              warning: "bg-[var(--warning)]",
              info: "bg-[var(--info)]",
            }[color],
            animated && "relative overflow-hidden"
          )}
          style={{ width: `${progress}%` }}
        >
          {animated && progress < 100 && (
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-shimmer" />
          )}
        </div>
      </div>
    </div>
  );
}
