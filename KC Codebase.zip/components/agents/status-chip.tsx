"use client";

import { cn } from "@/lib/utils";
import { Spinner } from "@/components/agents/spinner";

export function StatusChip({
  status,
  message,
}: {
  status: "idle" | "processing" | "complete" | "error";
  message?: string;
}) {
  const config = {
    idle: {
      color: "text-muted-foreground",
      bg: "bg-muted",
      label: "Idle",
    },
    processing: {
      color: "text-[var(--info)]",
      bg: "bg-[var(--info)]/10",
      label: "Processing",
    },
    complete: {
      color: "text-[var(--success)]",
      bg: "bg-[var(--success)]/10",
      label: "Complete",
    },
    error: {
      color: "text-primary",
      bg: "bg-primary/10",
      label: "Error",
    },
  }[status];

  return (
    <div className={cn("flex items-center gap-2 px-3 py-1.5 rounded-full", config.bg)}>
      {status === "processing" && <Spinner size="sm" className={config.color} />}
      {status === "complete" && (
        <svg className={cn("w-4 h-4", config.color)} viewBox="0 0 20 20" fill="currentColor">
          <path
            fillRule="evenodd"
            d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
            clipRule="evenodd"
          />
        </svg>
      )}
      {status === "error" && (
        <svg className={cn("w-4 h-4", config.color)} viewBox="0 0 20 20" fill="currentColor">
          <path
            fillRule="evenodd"
            d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z"
            clipRule="evenodd"
          />
        </svg>
      )}
      {status === "idle" && (
        <div className={cn("w-2 h-2 rounded-full", config.color.replace("text-", "bg-"))} />
      )}
      <span className={cn("text-sm font-medium", config.color)}>{message || config.label}</span>
    </div>
  );
}
