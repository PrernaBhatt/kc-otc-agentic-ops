"use client";

import type { ReactElement } from "react";
import { cn } from "@/lib/utils";

export function AgentIcon({
  type,
  size = "md",
  animated = false,
  className,
}: {
  type: string;
  size?: "sm" | "md" | "lg";
  animated?: boolean;
  className?: string;
}) {
  const iconClass = cn(
    {
      sm: "w-6 h-6",
      md: "w-8 h-8",
      lg: "w-12 h-12",
    }[size],
    animated && "animate-pulse",
    className
  );

  const icons: Record<string, ReactElement> = {
    orchestrator: (
      <svg className={iconClass} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="24" cy="24" r="20" fill="currentColor" fillOpacity="0.1" stroke="currentColor" strokeWidth="2" />
        <circle cx="24" cy="14" r="4" fill="currentColor" />
        <circle cx="14" cy="30" r="4" fill="currentColor" />
        <circle cx="34" cy="30" r="4" fill="currentColor" />
        <path d="M24 18V22M18 28L21 25M30 28L27 25" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        <circle cx="24" cy="24" r="3" fill="currentColor" />
      </svg>
    ),
    credit: (
      <svg className={iconClass} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="6" y="12" width="36" height="24" rx="4" fill="currentColor" fillOpacity="0.1" stroke="currentColor" strokeWidth="2" />
        <rect x="6" y="18" width="36" height="6" fill="currentColor" />
        <circle cx="34" cy="28" r="4" fill="currentColor" fillOpacity="0.5" />
        <circle cx="30" cy="28" r="4" fill="currentColor" />
      </svg>
    ),
    pricing: (
      <svg className={iconClass} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="24" cy="24" r="18" fill="currentColor" fillOpacity="0.1" stroke="currentColor" strokeWidth="2" />
        <text x="24" y="30" textAnchor="middle" fill="currentColor" fontSize="18" fontWeight="bold">
          $
        </text>
      </svg>
    ),
    ltv: (
      <svg className={iconClass} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="8" y="8" width="32" height="32" rx="4" fill="currentColor" fillOpacity="0.1" stroke="currentColor" strokeWidth="2" />
        <path d="M14 32L20 24L26 28L34 16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        <circle cx="34" cy="16" r="3" fill="currentColor" />
      </svg>
    ),
    dunning: (
      <svg className={iconClass} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path
          d="M8 12H40V36C40 38.2091 38.2091 40 36 40H12C9.79086 40 8 38.2091 8 36V12Z"
          fill="currentColor"
          fillOpacity="0.1"
          stroke="currentColor"
          strokeWidth="2"
        />
        <path d="M8 12L24 24L40 12" stroke="currentColor" strokeWidth="2" />
        <circle cx="36" cy="12" r="6" fill="#d10000" stroke="white" strokeWidth="2" />
        <text x="36" y="15" textAnchor="middle" fill="white" fontSize="8" fontWeight="bold">
          !
        </text>
      </svg>
    ),
    validation: (
      <svg className={iconClass} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="8" y="8" width="32" height="32" rx="4" fill="currentColor" fillOpacity="0.1" stroke="currentColor" strokeWidth="2" />
        <path d="M16 24L22 30L32 18" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
    billing: (
      <svg className={iconClass} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="10" y="6" width="28" height="36" rx="2" fill="currentColor" fillOpacity="0.1" stroke="currentColor" strokeWidth="2" />
        <line x1="16" y1="14" x2="32" y2="14" stroke="currentColor" strokeWidth="2" />
        <line x1="16" y1="22" x2="32" y2="22" stroke="currentColor" strokeWidth="2" />
        <line x1="16" y1="30" x2="26" y2="30" stroke="currentColor" strokeWidth="2" />
        <rect x="26" y="32" width="10" height="6" rx="1" fill="currentColor" />
      </svg>
    ),
    atp: (
      <svg className={iconClass} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="6" y="20" width="36" height="22" rx="2" fill="currentColor" fillOpacity="0.1" stroke="currentColor" strokeWidth="2" />
        <path d="M14 20V12C14 9.79086 15.7909 8 18 8H30C32.2091 8 34 9.79086 34 12V20" stroke="currentColor" strokeWidth="2" />
        <rect x="12" y="26" width="8" height="8" rx="1" fill="currentColor" />
        <rect x="24" y="26" width="8" height="8" rx="1" fill="currentColor" />
      </svg>
    ),
    extraction: (
      <svg className={iconClass} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="8" y="6" width="24" height="32" rx="2" fill="currentColor" fillOpacity="0.1" stroke="currentColor" strokeWidth="2" />
        <path d="M32 18L40 24L32 30V18Z" fill="currentColor" />
        <line x1="14" y1="14" x2="26" y2="14" stroke="currentColor" strokeWidth="2" />
        <line x1="14" y1="22" x2="26" y2="22" stroke="currentColor" strokeWidth="2" />
      </svg>
    ),
    po: (
      <svg className={iconClass} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="6" y="8" width="28" height="32" rx="2" fill="currentColor" fillOpacity="0.1" stroke="currentColor" strokeWidth="2" />
        <rect x="22" y="20" width="20" height="20" rx="2" fill="currentColor" fillOpacity="0.2" stroke="currentColor" strokeWidth="2" />
        <path d="M28 30L32 34L40 26" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      </svg>
    ),
    contract: (
      <svg className={iconClass} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="8" y="6" width="32" height="36" rx="2" fill="currentColor" fillOpacity="0.1" stroke="currentColor" strokeWidth="2" />
        <path d="M16 32C20 28 28 28 32 32" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        <circle cx="24" cy="18" r="6" fill="currentColor" fillOpacity="0.3" stroke="currentColor" strokeWidth="2" />
      </svg>
    ),
    document: (
      <svg className={iconClass} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path
          d="M10 8H30L38 16V40C38 41.1046 37.1046 42 36 42H10C8.89543 42 8 41.1046 8 40V10C8 8.89543 8.89543 8 10 8Z"
          fill="currentColor"
          fillOpacity="0.1"
          stroke="currentColor"
          strokeWidth="2"
        />
        <path d="M30 8V16H38" stroke="currentColor" strokeWidth="2" />
        <line x1="14" y1="24" x2="32" y2="24" stroke="currentColor" strokeWidth="2" />
        <line x1="14" y1="32" x2="28" y2="32" stroke="currentColor" strokeWidth="2" />
      </svg>
    ),
    invoice: (
      <svg className={iconClass} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="8" y="4" width="32" height="40" rx="2" fill="currentColor" fillOpacity="0.1" stroke="currentColor" strokeWidth="2" />
        <line x1="14" y1="12" x2="34" y2="12" stroke="currentColor" strokeWidth="2" />
        <line x1="14" y1="20" x2="28" y2="20" stroke="currentColor" strokeWidth="1.5" />
        <line x1="14" y1="26" x2="28" y2="26" stroke="currentColor" strokeWidth="1.5" />
        <rect x="24" y="32" width="10" height="8" rx="1" fill="currentColor" />
        <text x="29" y="38" textAnchor="middle" fill="white" fontSize="6" fontWeight="bold">
          $
        </text>
      </svg>
    ),
    delivery: (
      <svg className={iconClass} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="4" y="14" width="28" height="20" rx="2" fill="currentColor" fillOpacity="0.1" stroke="currentColor" strokeWidth="2" />
        <path d="M32 18H40L44 26V34H32V18Z" fill="currentColor" fillOpacity="0.2" stroke="currentColor" strokeWidth="2" />
        <circle cx="14" cy="38" r="4" fill="currentColor" />
        <circle cx="38" cy="38" r="4" fill="currentColor" />
      </svg>
    ),
  };

  return icons[type] || icons.orchestrator;
}
