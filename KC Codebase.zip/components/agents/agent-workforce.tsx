"use client";

import { UserCheck } from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  workforceGroups,
  workforceTotals as totals,
  type WorkforceAgent,
} from "@/lib/data/agent-workforce";

/**
 * Who the agents are, what they answer to and what they do — the full roster,
 * grouped by the workflow that owns each one.
 *
 * The roster is derived from the workflow definitions, so an agent added to a
 * workflow turns up here without this file changing.
 */
function AgentCard({ agent }: { agent: WorkforceAgent }) {
  return (
    <div className="flex h-full flex-col rounded-lg border p-4">
      <div className="flex items-start gap-3">
        <AgentIcon
          type={agent.glyph}
          size="md"
          className="flex-shrink-0 text-[var(--primary)]"
        />
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold text-foreground">{agent.name}</p>
          <p className="mt-0.5 text-[13px] leading-snug text-muted-foreground">
            {agent.role}
          </p>
        </div>
      </div>

      <div className="mt-3 flex flex-wrap gap-1.5">
        {agent.chips.map((chip) => (
          <Badge
            key={chip}
            variant="secondary"
            className="whitespace-nowrap text-[11px]"
          >
            {chip}
          </Badge>
        ))}
        {agent.alsoIn.length > 0 && (
          <Badge
            variant="outline"
            className="whitespace-nowrap text-[11px] text-muted-foreground"
          >
            Shared with {agent.alsoIn.join(" · ")}
          </Badge>
        )}
      </div>

      <ul className="mt-3 space-y-1.5">
        {agent.keyActions.map((action) => (
          <li
            key={action}
            className="flex items-start gap-2 text-[13px] leading-snug text-muted-foreground"
          >
            <span className="mt-1.5 h-1 w-1 flex-shrink-0 rounded-full bg-muted-foreground/60" />
            {action}
          </li>
        ))}
      </ul>
    </div>
  );
}

export function AgentWorkforce() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-3">
        <Card className="py-5">
          <CardContent>
            <p className="text-[13px] text-muted-foreground">
              Agents on this workspace
            </p>
            <p className="mt-1 text-3xl font-bold tabular-nums text-foreground">
              {totals.agentCount}
            </p>
            <p className="mt-1 text-[12px] text-muted-foreground">
              Across {totals.groupCount} areas of the workspace
            </p>
          </CardContent>
        </Card>

        <Card className="py-5">
          <CardContent>
            <p className="text-[13px] text-muted-foreground">
              Steps carried without a person
            </p>
            <p className="mt-1 text-3xl font-bold tabular-nums text-[var(--success)]">
              {totals.agentSteps}
              <span className="text-lg font-semibold text-muted-foreground">
                {" "}
                of {totals.totalSteps}
              </span>
            </p>
            <p className="mt-1 text-[12px] text-muted-foreground">
              Every step defined across the workflows
            </p>
          </CardContent>
        </Card>

        <Card className="py-5">
          <CardContent>
            <p className="text-[13px] text-muted-foreground">
              Decision points with people
            </p>
            <p className="mt-1 flex items-baseline gap-2 text-3xl font-bold tabular-nums text-foreground">
              {totals.humanGates}
              <UserCheck className="h-5 w-5 text-muted-foreground" />
            </p>
            <p className="mt-1 text-[12px] text-muted-foreground">
              {totals.humanGates - totals.draftedToRelease} case gates ·{" "}
              {totals.draftedToRelease} drafted letters to release
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>The agent workforce</CardTitle>
        </CardHeader>
        <CardContent className="space-y-8">
          {workforceGroups.map((group) => (
            <div key={group.id}>
              <div className="mb-3 flex items-baseline gap-3">
                <h3 className="text-sm font-semibold text-foreground">
                  {group.label}
                </h3>
                <span className="text-xs tabular-nums text-muted-foreground">
                  {group.agents.length} agent
                  {group.agents.length === 1 ? "" : "s"} · seen on {group.seenOn}
                </span>
              </div>
              <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3 xl:items-stretch">
                {group.agents.map((agent) => (
                  <AgentCard key={agent.name} agent={agent} />
                ))}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
