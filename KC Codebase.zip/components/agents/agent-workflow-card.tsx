"use client";

import { useEffect, useState } from "react";
import { ArrowRight, CircleCheck } from "lucide-react";

import { AgentIcon } from "@/components/agents/agent-icon";
import { AnimatedProgress } from "@/components/agents/animated-progress";
import { Spinner } from "@/components/agents/spinner";
import {
  orderWorkflow,
  billingWorkflow,
  cashCollectionsWorkflow,
  chargebackWorkflow,
  deductionRecoveryWorkflow,
} from "@/components/agents/workflow-definitions";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { cn } from "@/lib/utils";

type StepStatus = "complete" | "processing" | "idle";

/** Each workflow card opens the workspace that runs it. */
const WORKFLOW_META = {
  order: {
    title: "Order Management Workflow",
    page: "Order Management",
    steps: orderWorkflow,
  },
  billing: { title: "Billing Workflow", page: "Billing", steps: billingWorkflow },
  cash: {
    title: "Cash & Collections Workflow",
    page: "Collections",
    steps: cashCollectionsWorkflow,
  },
  chargeback: {
    title: "Chargeback Validation Workflow",
    page: "Chargebacks",
    steps: chargebackWorkflow,
  },
  deduction: {
    title: "Deduction Recovery Workflow",
    page: "Deductions",
    steps: deductionRecoveryWorkflow,
  },
} as const;

export function AgentWorkflowCard({
  type,
  activeStep = 0,
  showDetails = true,
  onOpen,
}: {
  type: "order" | "billing" | "cash" | "chargeback" | "deduction";
  activeStep: number;
  showDetails?: boolean;
  onOpen?: () => void;
}) {
  const meta = WORKFLOW_META[type];
  const workflow = meta.steps;
  const [processingStep, setProcessingStep] = useState(-1);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);

  useEffect(() => {
    if (activeStep > 0 && !completedSteps.includes(activeStep)) {
      setProcessingStep(activeStep);
      const timer = setTimeout(() => {
        setCompletedSteps((prev) => [...prev, activeStep]);
        setProcessingStep(-1);
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [activeStep, completedSteps]);

  const getStepStatus = (stepId: number): StepStatus =>
    completedSteps.includes(stepId)
      ? "complete"
      : processingStep === stepId
        ? "processing"
        : "idle";

  return (
    <Card
      className={cn(
        "bg-card flex h-full flex-col",
        onOpen &&
          "cursor-pointer transition-all hover:border-primary/50 hover:shadow-md"
      )}
      onClick={onOpen}
      role={onOpen ? "button" : undefined}
      tabIndex={onOpen ? 0 : undefined}
      onKeyDown={
        onOpen
          ? (e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                onOpen();
              }
            }
          : undefined
      }
    >
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <AgentIcon type="orchestrator" size="sm" className="text-primary" />
            {meta.title}
          </CardTitle>
          <Badge variant="outline" className="gap-1">
            {completedSteps.length}/{workflow.length} Complete
          </Badge>
        </div>
        <AnimatedProgress
          progress={(completedSteps.length / workflow.length) * 100}
          color={completedSteps.length === workflow.length ? "success" : "primary"}
        />
      </CardHeader>
      <CardContent className="flex flex-1 flex-col space-y-3">
        {workflow.map((step, index) => {
          const status = getStepStatus(step.id);
          const isActive = activeStep === step.id;
          return (
            <div
              key={step.id}
              className={cn(
                "relative flex gap-3 p-3 rounded-lg transition-all",
                isActive && "bg-primary/5 ring-1 ring-primary/20",
                status === "complete" && "bg-[var(--success)]/5",
                status === "processing" && "bg-[var(--info)]/5",
              )}
            >
              {index < workflow.length - 1 && (
                <div
                  className={cn(
                    "absolute left-[1.65rem] top-14 w-0.5 h-[calc(100%-2rem)]",
                    status === "complete" ? "bg-[var(--success)]" : "bg-muted",
                  )}
                />
              )}
              <div
                className={cn(
                  "relative flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center",
                  status === "complete" && "bg-[var(--success)] text-white",
                  status === "processing" && "bg-[var(--info)] text-white",
                  status === "idle" && "bg-muted text-muted-foreground",
                )}
              >
                {status === "processing" ? (
                  <Spinner size="sm" className="text-white" />
                ) : status === "complete" ? (
                  <CircleCheck className="w-4 h-4" />
                ) : (
                  <AgentIcon type={step.agentType} size="sm" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-medium text-sm text-foreground truncate">
                    {step.agent}
                  </span>
                  {status === "processing" && (
                    <Badge className="bg-[var(--info)] text-white text-xs">
                      Processing
                    </Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground line-clamp-2">
                  {step.description}
                </p>
                {showDetails && (isActive || status === "complete") && (
                  <div className="mt-2 space-y-1">
                    <div className="text-xs text-muted-foreground">
                      <span className="font-medium">Persona:</span>{" "}
                      {step.persona}
                    </div>
                    {status === "complete" && (
                      <div className="flex items-center gap-1 text-xs text-[var(--success)]">
                        <CircleCheck className="w-3 h-3" />
                        {step.expectedOutput}
                      </div>
                    )}
                  </div>
                )}
              </div>
              <div className="flex-shrink-0 text-xs text-muted-foreground">
                Step {step.id}
              </div>
            </div>
          );
        })}
        {onOpen && (
          <div className="mt-auto flex items-center justify-end gap-1.5 border-t pt-3 text-sm font-medium text-primary">
            Open {meta.page}
            <ArrowRight className="h-4 w-4" />
          </div>
        )}
      </CardContent>
    </Card>
  );
}
