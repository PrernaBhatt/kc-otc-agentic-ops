"use client";

import { cn } from "@/lib/utils";

const SIZES = {
  sm: { box: "h-4 w-4 border-[1.5px] [--halo:3px]", dot: "h-1.5 w-1.5" },
  md: { box: "h-6 w-6 border-2 [--halo:5px]", dot: "h-2 w-2" },
  lg: { box: "h-8 w-8 border-2 [--halo:7px]", dot: "h-2.5 w-2.5" },
} as const;

/**
 * The live-step mark: a ring with a steady centre dot and a breathing halo,
 * drawn in currentColor so it reads on any surface, including filled buttons.
 */
export function Spinner({
  size = "md",
  className,
}: {
  size?: "sm" | "md" | "lg";
  className?: string;
}) {
  const s = SIZES[size];
  return (
    <span
      aria-hidden="true"
      className={cn(
        // shrink-0 + self-center keep the mark centred on the text line and
        // unsquashed by long sibling text, as the old spinner did.
        "step-halo step-halo-current inline-flex shrink-0 items-center justify-center self-center rounded-full border-current align-middle",
        s.box,
        className
      )}
    >
      <span className={cn("rounded-full bg-current", s.dot)} />
    </span>
  );
}
