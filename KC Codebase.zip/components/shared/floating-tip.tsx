"use client";

import {
  useCallback,
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
  type CSSProperties,
  type ReactNode,
} from "react";
import { createPortal } from "react-dom";

import { cn } from "@/lib/utils";

export type TipSide = "top" | "bottom" | "left" | "right";
export type TipContent = {
  title: ReactNode;
  value?: ReactNode;
  note?: ReactNode;
  swatch?: string;
};

const GAP = 8;
const EDGE = 8;
const FLIP: Record<TipSide, TipSide> = {
  top: "bottom",
  bottom: "top",
  left: "right",
  right: "left",
};

type Placed = { x: number; y: number; side: TipSide; arrow: number };

/** Holds the hovered rect; scrolling drops it so the tip never floats away from its anchor. */
export function useTipAnchor() {
  const [anchor, setAnchor] = useState<DOMRect | null>(null);
  const hide = useCallback(() => setAnchor(null), []);
  useEffect(() => {
    if (!anchor) return;
    window.addEventListener("scroll", hide, { capture: true, passive: true });
    return () => window.removeEventListener("scroll", hide, { capture: true });
  }, [anchor, hide]);
  return { anchor, show: setAnchor, hide };
}

/** Fixed-position tip on the body. Prefers `side` and flips to stay on screen. */
export function FloatingTip({
  anchor,
  side = "top",
  content,
}: {
  anchor: DOMRect | null;
  side?: TipSide;
  content: TipContent | null;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState<Placed | null>(null);

  useLayoutEffect(() => {
    if (!anchor || !ref.current) {
      setPos(null);
      return;
    }
    const { width: w, height: h } = ref.current.getBoundingClientRect();
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const fits: Record<TipSide, boolean> = {
      top: anchor.top - h - GAP >= EDGE,
      bottom: anchor.bottom + h + GAP <= vh - EDGE,
      left: anchor.left - w - GAP >= EDGE,
      right: anchor.right + w + GAP <= vw - EDGE,
    };
    const s: TipSide = fits[side] ? side : fits[FLIP[side]] ? FLIP[side] : fits.top ? "top" : "bottom";
    const vertical = s === "top" || s === "bottom";
    const rawX = vertical
      ? anchor.left + anchor.width / 2 - w / 2
      : s === "left"
        ? anchor.left - w - GAP
        : anchor.right + GAP;
    const rawY = vertical
      ? s === "top"
        ? anchor.top - h - GAP
        : anchor.bottom + GAP
      : anchor.top + anchor.height / 2 - h / 2;
    const x = Math.min(Math.max(rawX, EDGE), vw - w - EDGE);
    const y = Math.min(Math.max(rawY, EDGE), vh - h - EDGE);
    const arrow = vertical
      ? Math.min(Math.max(anchor.left + anchor.width / 2 - x, 12), w - 12)
      : Math.min(Math.max(anchor.top + anchor.height / 2 - y, 10), h - 10);
    setPos({ x, y, side: s, arrow });
  }, [anchor, side]);

  if (!anchor || !content || typeof document === "undefined") return null;

  const style: CSSProperties = {
    left: pos?.x ?? -9999,
    top: pos?.y ?? -9999,
    visibility: pos ? "visible" : "hidden",
  };
  const vertical = pos?.side === "top" || pos?.side === "bottom";
  const arrowStyle: CSSProperties = vertical
    ? { left: pos?.arrow, [pos?.side === "top" ? "bottom" : "top"]: -4, marginLeft: -4 }
    : { top: pos?.arrow, [pos?.side === "left" ? "right" : "left"]: -4, marginTop: -4 };

  return createPortal(
    <div ref={ref} role="tooltip" className="pointer-events-none fixed z-[70]" style={style}>
      <div className="animate-enter-fade relative flex max-w-64 min-w-32 flex-col gap-0.5 rounded-lg bg-foreground px-3 py-2 text-background shadow-lg">
        <span className="flex items-center gap-1.5 text-[11px] font-medium leading-tight text-background/70">
          {content.swatch && (
            <span
              className={cn("size-2 shrink-0 rounded-[2px]", content.swatch)}
              aria-hidden
            />
          )}
          {content.title}
        </span>
        {content.value !== undefined && (
          <span className="text-sm font-semibold leading-tight tabular-nums">{content.value}</span>
        )}
        {content.note && (
          <span className="text-xs leading-snug text-background/85">{content.note}</span>
        )}
        <span className="absolute size-2 rotate-45 bg-foreground" style={arrowStyle} aria-hidden />
      </div>
    </div>,
    document.body
  );
}

/** A hover target that floats its own tip. */
export function Tip({
  content,
  side = "top",
  className,
  style,
  children,
  focusable = false,
  label,
}: {
  content: TipContent;
  side?: TipSide;
  className?: string;
  style?: CSSProperties;
  children?: ReactNode;
  focusable?: boolean;
  label?: string;
}) {
  const { anchor, show, hide } = useTipAnchor();
  return (
    <>
      <span
        className={className}
        style={style}
        tabIndex={focusable ? 0 : undefined}
        aria-label={label}
        onPointerEnter={(e) => show(e.currentTarget.getBoundingClientRect())}
        onPointerLeave={hide}
        onFocus={focusable ? (e) => show(e.currentTarget.getBoundingClientRect()) : undefined}
        onBlur={focusable ? hide : undefined}
      >
        {children}
      </span>
      <FloatingTip anchor={anchor} side={side} content={content} />
    </>
  );
}
