"use client";

import { useEffect, useRef, useState } from "react";

import { cn } from "@/lib/utils";

function prefersReducedMotion() {
  return (
    typeof window !== "undefined" &&
    window.matchMedia?.("(prefers-reduced-motion: reduce)").matches
  );
}

/**
 * Types a string in, char by char, then stops. The untyped rest holds its
 * place invisibly, so a value sits in its final box from the first character
 * and always fills left to right, even in right-aligned amount columns.
 */
export function TypedText({
  text,
  charMs = 14,
  maxMs,
  delayMs = 0,
  instant = false,
  caret = true,
  onDone,
  className,
}: {
  text: string;
  charMs?: number;
  maxMs?: number;
  delayMs?: number;
  instant?: boolean;
  caret?: boolean;
  onDone?: () => void;
  className?: string;
}) {
  const [count, setCount] = useState(instant ? text.length : 0);
  const doneRef = useRef(onDone);
  doneRef.current = onDone;

  useEffect(() => {
    if (instant || prefersReducedMotion()) {
      setCount(text.length);
      doneRef.current?.();
      return;
    }
    setCount(0);
    const per = maxMs ? Math.min(charMs, maxMs / Math.max(1, text.length)) : charMs;
    const total = per * text.length;
    let interval = 0;
    const timer = window.setTimeout(() => {
      const started = Date.now();
      interval = window.setInterval(() => {
        const elapsed = Date.now() - started;
        const n = Math.min(text.length, Math.ceil(elapsed / per));
        setCount(n);
        if (elapsed >= total) {
          window.clearInterval(interval);
          setCount(text.length);
          doneRef.current?.();
        }
      }, 16);
    }, delayMs);
    return () => {
      window.clearTimeout(timer);
      window.clearInterval(interval);
    };
  }, [text, charMs, maxMs, delayMs, instant]);

  const typing = count < text.length;
  return (
    <span className={cn(className)} aria-label={text}>
      <span aria-hidden>{text.slice(0, count)}</span>
      {caret && typing && count > 0 && <span className="ai-caret -mr-px" aria-hidden />}
      {typing && (
        <span aria-hidden className="invisible">
          {text.slice(count)}
        </span>
      )}
    </span>
  );
}
