"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";

import { TypedText } from "@/components/shared/typed-text";
import { cn } from "@/lib/utils";

const played = new Set<string>();

export interface FillField {
  label: string;
  value: string;
  align?: "left" | "right";
  mono?: boolean;
  strong?: boolean;
}

/**
 * What an agent writes: a blank template whose slots type in one after the
 * other, left to right. The optional stamp lands only after the last value.
 */
export function FillFields({
  fields,
  play = true,
  playKey,
  charMs = 16,
  columns = 1,
  stamp,
  onDone,
  className,
}: {
  fields: FillField[];
  play?: boolean;
  playKey?: string;
  charMs?: number;
  columns?: 1 | 2;
  stamp?: ReactNode;
  onDone?: () => void;
  className?: string;
}) {
  const instant = !!playKey && played.has(playKey);
  const [index, setIndex] = useState(instant ? fields.length : 0);
  const doneRef = useRef(onDone);
  doneRef.current = onDone;
  const finished = index >= fields.length;

  useEffect(() => {
    if (!finished) return;
    if (playKey) played.add(playKey);
    doneRef.current?.();
  }, [finished, playKey]);

  return (
    <div className={cn("flex flex-col gap-3", className)}>
      <dl className={cn("grid gap-x-6", columns === 2 ? "sm:grid-cols-2" : "grid-cols-1")}>
        {fields.map((f, i) => {
          const active = play && i === index;
          const filled = i < index;
          return (
            <div
              key={f.label}
              className="flex items-baseline justify-between gap-3 border-b border-dashed py-1.5 text-xs"
            >
              <dt className="shrink-0 text-muted-foreground">{f.label}</dt>
              <dd
                className={cn(
                  "min-w-0 text-foreground",
                  f.align === "right" && "tabular-nums",
                  f.mono && "font-mono",
                  f.strong && "font-semibold"
                )}
              >
                {filled ? (
                  f.value
                ) : active ? (
                  <TypedText
                    key={`${f.label}:${f.value}`}
                    text={f.value}
                    charMs={charMs}
                    onDone={() => setIndex((n) => Math.max(n, i + 1))}
                  />
                ) : (
                  <span className="invisible">{f.value}</span>
                )}
              </dd>
            </div>
          );
        })}
      </dl>
      {stamp && finished && <div className="animate-enter-fade step-pop self-start">{stamp}</div>}
    </div>
  );
}
