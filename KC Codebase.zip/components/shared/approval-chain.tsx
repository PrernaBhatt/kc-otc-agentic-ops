"use client";

import { Check } from "lucide-react";

import { cn } from "@/lib/utils";

export type ChainState = "done" | "active" | "waiting";

export interface ChainNode {
  id: string;
  label: string;
  sub?: string;
  state: ChainState;
}

/**
 * A left-to-right approval or status chain. Finished nodes pop their check,
 * the live node breathes, waiting nodes stay outlined.
 */
export function ApprovalChain({
  nodes,
  className,
  size = "md",
}: {
  nodes: ChainNode[];
  className?: string;
  size?: "sm" | "md";
}) {
  return (
    <ol className={cn("flex items-start", className)}>
      {nodes.map((n, i) => {
        const last = i === nodes.length - 1;
        return (
          <li key={n.id} className={cn("flex min-w-0 items-start", !last && "flex-1")}>
            <div className="flex min-w-0 flex-col items-center gap-1 text-center">
              <span
                className={cn(
                  "flex shrink-0 items-center justify-center rounded-full border-2",
                  size === "md" ? "h-6 w-6" : "h-4 w-4",
                  n.state === "done" && "step-pop border-[var(--success)] bg-[var(--success)] text-[var(--success-foreground)]",
                  n.state === "active" && "step-halo border-primary bg-background",
                  n.state === "waiting" && "border-border bg-background"
                )}
                style={n.state === "active" ? ({ "--halo": "4px" } as React.CSSProperties) : undefined}
              >
                {n.state === "done" && (
                  <Check className={size === "md" ? "h-3.5 w-3.5" : "h-2.5 w-2.5"} strokeWidth={3} />
                )}
                {n.state === "active" && (
                  <span className={cn("rounded-full bg-primary", size === "md" ? "h-2 w-2" : "h-1.5 w-1.5")} />
                )}
              </span>
              <span
                className={cn(
                  "max-w-24 truncate font-medium",
                  size === "md" ? "text-[11px]" : "text-[10px]",
                  n.state === "waiting" ? "text-muted-foreground" : "text-foreground"
                )}
              >
                {n.label}
              </span>
              {n.sub && (
                <span className="max-w-24 truncate text-[10px] text-muted-foreground">{n.sub}</span>
              )}
            </div>
            {!last && (
              <span
                aria-hidden
                className={cn(
                  "mx-1 h-0.5 flex-1 rounded-full",
                  size === "md" ? "mt-3" : "mt-2",
                  n.state === "done" ? "bg-[var(--success)]" : "bg-border"
                )}
              />
            )}
          </li>
        );
      })}
    </ol>
  );
}
