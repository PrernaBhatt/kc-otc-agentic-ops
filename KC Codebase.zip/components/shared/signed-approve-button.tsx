"use client";

import { useState, type ReactNode } from "react";
import { PenLine } from "lucide-react";

import { Button } from "@/components/ui/button";
import { ControlTags } from "@/components/shared/control-tag";
import {
  GateSignoffModal,
  type GateEvidence,
  type GateLine,
} from "@/components/shared/gate-signoff-modal";

/**
 * Drop-in replacement for an existing gate's approve button: shows the SOX
 * refs beside it and opens the shared sign-off; `onSigned` fires only after
 * every signer has signed and the audit entries are written.
 */
export function SignedApproveButton({
  children,
  variant = "default",
  gateId,
  title,
  caseId,
  accountId,
  module,
  system,
  controls,
  evidence,
  lines,
  materialityUsd,
  attestation,
  action,
  decision,
  onSigned,
}: {
  children: ReactNode;
  variant?: "default" | "destructive";
  gateId: string;
  title: string;
  caseId: string;
  accountId: string;
  module: string;
  system: string;
  controls: string[];
  evidence: GateEvidence[];
  lines?: GateLine[];
  materialityUsd?: number;
  attestation: string;
  action: string;
  decision: string;
  onSigned: () => void;
}) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <ControlTags refs={controls} />
      <Button size="sm" variant={variant} className="whitespace-nowrap" onClick={() => setOpen(true)}>
        <PenLine className="h-3.5 w-3.5" />
        {children}
      </Button>
      <GateSignoffModal
        open={open}
        onClose={() => setOpen(false)}
        gateId={gateId}
        title={title}
        documentNo={`${caseId} · decision`}
        caseId={caseId}
        accountId={accountId}
        module={module}
        system={system}
        controls={controls}
        evidence={evidence}
        lines={lines}
        materialityUsd={materialityUsd}
        attestation={attestation}
        confirmLabel="Confirm decision"
        action={action}
        decision={decision}
        onSigned={() => {
          setOpen(false);
          onSigned();
        }}
      />
    </>
  );
}
