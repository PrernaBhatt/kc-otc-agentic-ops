import { cn } from "@/lib/utils";

/** The result of an agent check. Never a tick: a check passes or flags. */
export function CheckChip({
  result,
  children,
  className,
}: {
  result: "pass" | "flag";
  children?: React.ReactNode;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex shrink-0 items-center gap-1 whitespace-nowrap rounded-md border px-1.5 py-0.5 text-[11px] font-semibold",
        result === "pass"
          ? "border-green-200 bg-green-100 text-green-700"
          : "border-red-200 bg-red-50 text-red-700",
        className
      )}
    >
      {result === "pass" ? "Pass" : "Flag"}
      {children && <span className="font-medium">· {children}</span>}
    </span>
  );
}
