"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";
import { CircleCheck } from "lucide-react";

import { Spinner } from "@/components/agents/spinner";
import { SystemMark } from "@/components/shared/system-badge";
import { cn } from "@/lib/utils";

const played = new Set<string>();

export interface TickItem {
  id: string;
  label: ReactNode;
  detail?: ReactNode;
  system?: string;
  trailing?: ReactNode;
}

/**
 * What an agent reads: each source ticks in line by line (spinner, then a
 * check). Inputs only; never use this for something the agent wrote.
 */
export function TickList({
  items,
  stepMs = 520,
  playKey,
  onDone,
  className,
}: {
  items: TickItem[];
  stepMs?: number;
  playKey?: string;
  onDone?: () => void;
  className?: string;
}) {
  const instant = !!playKey && played.has(playKey);
  const [done, setDone] = useState(instant ? items.length : 0);
  const doneRef = useRef(onDone);
  doneRef.current = onDone;

  useEffect(() => {
    if (done >= items.length) {
      if (playKey) played.add(playKey);
      doneRef.current?.();
      return;
    }
    const reduce = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    const t = setTimeout(() => setDone((d) => (reduce ? items.length : d + 1)), reduce ? 0 : stepMs);
    return () => clearTimeout(t);
  }, [done, items.length, stepMs, playKey]);

  return (
    <ul className={cn("flex flex-col", className)} aria-live="polite">
      {items.map((item, i) => {
        if (i > done) return null;
        const ticked = i < done;
        return (
          <li
            key={item.id}
            className="animate-enter-fade flex items-start gap-2.5 border-t py-2 first:border-t-0"
          >
            <span className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center">
              {ticked ? (
                <CircleCheck className="step-pop h-4 w-4 text-[var(--success)]" />
              ) : (
                <Spinner size="sm" className="text-primary" />
              )}
            </span>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5 text-sm text-foreground">
                {item.system && <SystemMark name={item.system} />}
                <span className="min-w-0 truncate">{item.label}</span>
              </div>
              {item.detail && (
                <div className="text-xs leading-relaxed text-muted-foreground">{item.detail}</div>
              )}
            </div>
            {item.trailing && ticked && <div className="shrink-0">{item.trailing}</div>}
          </li>
        );
      })}
    </ul>
  );
}
