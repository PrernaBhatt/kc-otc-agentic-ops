"use client";

import { useEffect, useMemo, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { CircleCheck, FileText, PenLine, X } from "lucide-react";

import { Button } from "@/components/ui/button";
import { SourceDocTrigger, type SourceDoc } from "@/components/modals/source-doc-preview";
import { ApprovalChain, type ChainNode } from "@/components/shared/approval-chain";
import {
  FORM_NAVY,
  FormCheckbox,
  FormFieldGrid,
  FormLineTable,
  FormSection,
  type GateForm,
} from "@/components/shared/approval-form";
import { ControlTags } from "@/components/shared/control-tag";
import { SignaturePad } from "@/components/shared/signature-pad";
import { CONTROLLER, findAccount } from "@/lib/data/account-owners";
import { runStamp, signatureHash, type AuditSignature } from "@/lib/audit";
import { formatUsd } from "@/lib/format";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

export interface GateSigner {
  name: string;
  role: string;
}

export interface GateLine {
  label: string;
  amountUsd: number;
  kind: "credit" | "charge-back" | "other";
}

export interface GateEvidence {
  id: string;
  label: string;
  detail?: string;
  system?: string;
  doc?: SourceDoc;
}

export interface GateOption {
  id: string;
  label: string;
  detail?: string;
  recommended?: boolean;
}

export interface GateSignResult {
  signatures: AuditSignature[];
  optionId?: string;
}

/**
 * The one sign-off surface for every human gate. It shows the SOX controls
 * the decision evidences, the account owner who decides, the evidence the
 * agents gathered, the owner's delegated limits and, above a limit, a
 * Controller co-sign. Nothing confirms until every signer has signed; the
 * signatures and an audit entry per signer are written on confirm.
 */
export function GateSignoffModal({
  open,
  onClose,
  gateId,
  title,
  documentNo,
  caseId,
  accountId,
  module,
  system,
  controls,
  evidence,
  lines = [],
  options,
  defaultOptionId,
  materialityUsd,
  signers: signersOverride,
  attestation,
  confirmLabel,
  action,
  decision,
  form,
  children,
  onSigned,
}: {
  form?: GateForm;
  open: boolean;
  onClose: () => void;
  gateId: string;
  title: string;
  documentNo: string;
  caseId: string;
  accountId: string;
  module: string;
  system: string;
  controls: string[];
  evidence: GateEvidence[];
  lines?: GateLine[];
  options?: GateOption[];
  defaultOptionId?: string;
  materialityUsd?: number;
  signers?: GateSigner[];
  attestation: string;
  confirmLabel: string;
  action: string;
  decision: string | ((optionId?: string) => string);
  children?: ReactNode;
  onSigned: (result: GateSignResult) => void;
}) {
  const { signGate, appendAudit, signatures } = useOtcStore();
  const account = findAccount(accountId);
  const [mounted, setMounted] = useState(false);
  const [optionId, setOptionId] = useState<string | undefined>(
    defaultOptionId ?? options?.find((o) => o.recommended)?.id
  );
  const [collected, setCollected] = useState<AuditSignature[]>([]);
  const [method, setMethod] = useState<"drawn" | "typed">("drawn");
  const [ink, setInk] = useState<string | null>(null);
  const [typed, setTyped] = useState("");

  useEffect(() => setMounted(true), []);

  const creditTotal = lines.filter((l) => l.kind === "credit").reduce((s, l) => s + l.amountUsd, 0);
  const chargeBackTotal = lines
    .filter((l) => l.kind === "charge-back")
    .reduce((s, l) => s + l.amountUsd, 0);
  const limits = account?.delegatedLimits;
  const creditOver = !!limits && creditTotal > limits.creditNoteUsd;
  const chargeBackOver = !!limits && chargeBackTotal > limits.chargeBackUsd;

  const signers: GateSigner[] = useMemo(() => {
    if (signersOverride) return signersOverride;
    const owner = account ? [{ name: account.owner.name, role: account.owner.role }] : [];
    return creditOver || chargeBackOver
      ? [...owner, { name: CONTROLLER.name, role: CONTROLLER.role }]
      : owner;
  }, [signersOverride, account, creditOver, chargeBackOver]);

  const existing = signatures[gateId];
  const allSigned = collected.length >= signers.length;
  const current = signers[collected.length];

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open || !mounted) return null;

  const linesTotal = lines.reduce((s, l) => s + l.amountUsd, 0);
  const formSpec: GateForm = form ?? {
    formNo: `OTC-${module.slice(0, 3).toUpperCase()}-01`,
    formTitle: title,
    fields: [
      { label: "Customer", value: account?.accountName ?? accountId },
      { label: "Account owner", value: account ? `${account.owner.name}, ${account.owner.role}` : "-" },
      { label: "Case reference", value: caseId, mono: true },
      { label: "System of record", value: system },
    ],
    table:
      lines.length > 0
        ? {
            columns: [
              { key: "item", label: "Item" },
              { key: "type", label: "Type" },
              { key: "amount", label: "Amount", align: "right" },
            ],
            rows: lines.map((l) => ({
              item: l.label,
              type: l.kind === "credit" ? "Credit note" : l.kind === "charge-back" ? "Charge-back" : "Other",
              amount: formatUsd(l.amountUsd),
            })),
            total: lines.length > 1 ? { label: "Total", value: formatUsd(linesTotal) } : undefined,
          }
        : undefined,
  };
  const showLimits = (materialityUsd !== undefined || creditTotal > 0 || chargeBackTotal > 0) && !!limits;
  const sectionOrder = [
    "request",
    formSpec.table && "table",
    formSpec.basis && "basis",
    options && options.length > 0 && "disposition",
    showLimits && "authority",
    "attachments",
    "approval",
  ].filter(Boolean) as string[];
  const sectionNo = (key: string) => sectionOrder.indexOf(key) + 1;
  const formDate = runStamp().slice(0, 10);
  const lastDocSegment = documentNo.split(" · ").pop() ?? "";
  const printedDocNo =
    formSpec.documentNo ?? (/\d/.test(lastDocSegment) && lastDocSegment !== caseId ? lastDocSegment : `APR-${caseId}`);

  const canSignCurrent = method === "drawn" ? !!ink : typed.trim().length >= 3;

  const signCurrent = () => {
    if (!current || !canSignCurrent) return;
    const signedAt = runStamp();
    const sig: AuditSignature = {
      method,
      signer: current.name,
      role: current.role,
      signedAt,
      hash: signatureHash(current.name, signedAt, gateId, ink ?? typed),
      image: method === "drawn" ? ink ?? undefined : undefined,
      typed: method === "typed" ? typed.trim() : undefined,
    };
    setCollected((prev) => [...prev, sig]);
    setInk(null);
    setTyped("");
  };

  const confirm = () => {
    if (!allSigned || existing) return;
    const decisionText = typeof decision === "function" ? decision(optionId) : decision;
    const amount = lines.reduce((s, l) => s + l.amountUsd, 0) || undefined;
    signGate(gateId, collected);
    collected.forEach((sig, i) => {
      appendAudit({
        caseId,
        accountId,
        module,
        actor: { kind: "person", name: sig.signer, role: sig.role },
        action: i === 0 ? action : `Co-signed: ${action}`,
        controlRefs: controls,
        amountUsd: amount,
        decision: decisionText,
        evidence: evidence.map((e) => e.label),
        signature: sig,
        system,
      });
    });
    onSigned({ signatures: collected, optionId });
  };

  const chainNodes: ChainNode[] = signers.map((s, i) => ({
    id: s.name,
    label: s.name,
    sub: i === 0 ? s.role : `${s.role} co-sign`,
    state: i < collected.length ? "done" : i === collected.length ? "active" : "waiting",
  }));

  return createPortal(
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm animate-enter-fade"
      onKeyDownCapture={(e) => {
        if (e.key === "Enter") e.stopPropagation();
      }}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby={`${gateId}-title`}
        data-gate={gateId}
        className="animate-modal-in flex max-h-[92vh] w-full max-w-3xl flex-col overflow-hidden rounded-xl border bg-background shadow-2xl"
      >
        <div className="flex items-center justify-between gap-3 border-b px-5 py-3">
          <div className="flex min-w-0 items-center gap-2">
            <FileText className="h-4 w-4 shrink-0 text-muted-foreground" />
            <span className="truncate font-mono text-xs text-muted-foreground">{documentNo}</span>
            <ControlTags refs={controls} interactive={false} />
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-md p-1 text-muted-foreground hover:bg-muted hover:text-foreground"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="min-h-0 flex-1 overflow-y-auto bg-muted/40 px-6 py-6">
          <article
            className="animate-enter mx-auto flex max-w-2xl flex-col gap-5 rounded-sm border border-[#e2e2e2] bg-white px-8 py-7 text-[#222] shadow-md"
            data-form={formSpec.formNo}
          >
            <header className="flex flex-col gap-4">
              <div className="flex items-end justify-between gap-4 border-b-2 pb-2" style={{ borderColor: FORM_NAVY }}>
                <div className="min-w-0">
                  <p className="text-sm font-bold uppercase tracking-wide" style={{ color: FORM_NAVY }}>
                    {formSpec.issuer ?? "K-C North America"}
                  </p>
                  <p className="text-[11px] text-[#666]">Order to Cash · {module}</p>
                </div>
                <div className="text-right font-mono text-[11px] leading-tight text-[#666]">
                  <p>Form {formSpec.formNo}</p>
                  <p>Rev. 01/2026</p>
                </div>
              </div>
              <div className="flex flex-wrap items-end justify-between gap-3">
                <h2
                  id={`${gateId}-title`}
                  className="text-base font-bold uppercase tracking-[0.12em] text-[#222] text-balance"
                >
                  {formSpec.formTitle}
                </h2>
                <dl className="flex gap-5 text-[11px]">
                  {[
                    { label: "Document no.", value: printedDocNo },
                    { label: "Date", value: formDate },
                    { label: "Control", value: controls.map((ref) => `SOX ${ref}`).join(", ") },
                  ].map((m) => (
                    <div key={m.label}>
                      <dt className="uppercase tracking-wide text-[#999]">{m.label}</dt>
                      <dd className="font-mono text-[#333]">{m.value}</dd>
                    </div>
                  ))}
                </dl>
              </div>
            </header>

            <FormSection no={1} title="Request details">
              <FormFieldGrid fields={formSpec.fields} />
            </FormSection>

            {formSpec.table && (
              <FormSection no={sectionNo("table")} title="Line detail">
                <FormLineTable table={formSpec.table} />
              </FormSection>
            )}

            {formSpec.basis && (
              <FormSection no={sectionNo("basis")} title="Basis for decision">
                <p className="text-xs leading-relaxed text-[#333]">{formSpec.basis}</p>
              </FormSection>
            )}

            {children}

            {options && options.length > 0 && (
              <FormSection no={sectionNo("disposition")} title="Disposition">
                <div role="radiogroup" className="flex flex-col">
                  {options.map((o) => {
                    const selected = optionId === o.id;
                    return (
                      <button
                        key={o.id}
                        type="button"
                        role="radio"
                        aria-checked={selected}
                        disabled={!!existing}
                        onClick={() => setOptionId(o.id)}
                        className="flex items-start gap-2.5 border-b border-[#eee] py-2 text-left last:border-b-0 hover:bg-[#f7f8fa]"
                      >
                        <FormCheckbox checked={selected} />
                        <span className="min-w-0">
                          <span className="block text-sm font-semibold text-[#222]">
                            {o.label}
                            {o.recommended && <span className="font-normal text-[#777]"> (recommended)</span>}
                          </span>
                          {o.detail && <span className="block text-xs text-[#555]">{o.detail}</span>}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </FormSection>
            )}

            {showLimits && limits && (
              <FormSection no={sectionNo("authority")} title="Authority check">
                <table className="w-full border-collapse border border-[#c8c8c8] text-xs">
                  <thead>
                    <tr className="bg-[#eef1f4] text-left text-[#333]">
                      <th className="border border-[#c8c8c8] px-2 py-1.5 font-bold">Limit</th>
                      <th className="border border-[#c8c8c8] px-2 py-1.5 text-right font-bold">Amount</th>
                      <th className="border border-[#c8c8c8] px-2 py-1.5 text-right font-bold">Limit value</th>
                      <th className="border border-[#c8c8c8] px-2 py-1.5 font-bold">Result</th>
                    </tr>
                  </thead>
                  <tbody>
                    {materialityUsd !== undefined && (
                      <LimitRow
                        label="Materiality threshold"
                        amount={lines.reduce((s, l) => s + l.amountUsd, 0)}
                        limit={materialityUsd}
                        overText="Above · signature required"
                        underText="Below"
                      />
                    )}
                    {creditTotal > 0 && (
                      <LimitRow
                        label="Credit notes · owner limit"
                        amount={creditTotal}
                        limit={limits.creditNoteUsd}
                        overText="Above · Controller co-sign"
                        underText="Within owner limit"
                      />
                    )}
                    {chargeBackTotal > 0 && (
                      <LimitRow
                        label="Charge-backs · owner limit"
                        amount={chargeBackTotal}
                        limit={limits.chargeBackUsd}
                        overText="Above · Controller co-sign"
                        underText="Within owner limit"
                      />
                    )}
                  </tbody>
                </table>
              </FormSection>
            )}

            <FormSection no={sectionNo("attachments")} title="Supporting documents">
              <ol className="flex flex-col text-xs">
                {evidence.map((e, i) => (
                  <li
                    key={e.id}
                    className="animate-enter-fade flex items-start justify-between gap-3 border-b border-[#eee] py-1.5 last:border-b-0"
                    style={{ animationDelay: `${i * 60}ms` }}
                  >
                    <span className="min-w-0">
                      <span className="font-mono text-[#777]">Att. {String.fromCharCode(65 + i)}</span>
                      <span className="ml-2 text-[#222]">{e.label}</span>
                      {e.system && <span className="text-[#777]"> · {e.system}</span>}
                      {e.detail && <span className="block pl-12 text-[#666]">{e.detail}</span>}
                    </span>
                    {e.doc && <SourceDocTrigger doc={e.doc} label="Open" className="h-6 shrink-0 px-1.5 text-[11px]" />}
                  </li>
                ))}
              </ol>
            </FormSection>

            <FormSection no={sectionNo("approval")} title="Approval">
              <div className="flex flex-col gap-4">
                <p className="text-xs leading-relaxed text-[#333]">{attestation}</p>
                {signers.length > 1 && <ApprovalChain nodes={chainNodes} className="px-2" />}

                <div className="grid gap-x-6 gap-y-4 sm:grid-cols-2">
                  {signers.map((s, i) => (
                    <SignatureBlock
                      key={s.name}
                      signer={s}
                      caption={i === 0 ? "Approved by" : "Co-signed by"}
                      sig={(existing ?? collected).find((x) => x.signer === s.name)}
                    />
                  ))}
                </div>

              {!existing && current && (
                <div className="flex flex-col gap-2 rounded-lg border p-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs text-foreground">
                      Sign as <span className="font-semibold">{current.name}</span>
                      <span className="text-muted-foreground">, {current.role}</span>
                    </span>
                    <div className="flex rounded-md border p-0.5 text-[11px]" role="tablist">
                      {(["drawn", "typed"] as const).map((m) => (
                        <button
                          key={m}
                          type="button"
                          role="tab"
                          aria-selected={method === m}
                          onClick={() => setMethod(m)}
                          className={cn(
                            "rounded px-2 py-0.5 font-medium",
                            method === m ? "bg-primary text-primary-foreground" : "text-muted-foreground"
                          )}
                        >
                          {m === "drawn" ? "Draw" : "Type"}
                        </button>
                      ))}
                    </div>
                  </div>
                  {method === "drawn" ? (
                    <SignaturePad key={current.name} onChange={setInk} canvasClassName="h-24" />
                  ) : (
                    <input
                      value={typed}
                      onChange={(e) => setTyped(e.target.value)}
                      placeholder={current.name}
                      aria-label={`Type signature for ${current.name}`}
                      className="h-14 rounded-md border bg-background px-3 font-serif text-2xl italic text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    />
                  )}
                  <div className="flex justify-end">
                    <Button size="sm" variant="outline" disabled={!canSignCurrent} onClick={signCurrent}>
                      <PenLine className="h-3.5 w-3.5" />
                      Sign as {current.name}
                    </Button>
                  </div>
                </div>
              )}
              </div>
            </FormSection>

            <footer className="flex justify-between gap-3 border-t border-[#e2e2e2] pt-2 text-[10px] text-[#999]">
              <span>K-C internal · retained with {caseId} under SOX record retention</span>
              <span>Page 1 of 1</span>
            </footer>
          </article>
        </div>

        <div className="flex items-center justify-between gap-2 border-t bg-background px-5 py-3">
          <span className="text-[11px] text-muted-foreground">
            {existing
              ? "Signed · written to the audit trail"
              : allSigned
                ? "All signatures captured"
                : `${collected.length} of ${signers.length} signatures`}
          </span>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" onClick={onClose}>
              {existing ? "Close" : "Cancel"}
            </Button>
            {!existing && (
              <Button size="sm" disabled={!allSigned} onClick={confirm}>
                <CircleCheck className="h-4 w-4" />
                {confirmLabel}
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
}

function LimitRow({
  label,
  amount,
  limit,
  overText,
  underText,
}: {
  label: string;
  amount: number;
  limit: number;
  overText: string;
  underText: string;
}) {
  const over = amount > limit;
  return (
    <tr className="text-[#222]">
      <td className="border border-[#c8c8c8] px-2 py-1.5">{label}</td>
      <td className="border border-[#c8c8c8] px-2 py-1.5 text-right tabular-nums">{formatUsd(amount)}</td>
      <td className="border border-[#c8c8c8] px-2 py-1.5 text-right tabular-nums">{formatUsd(limit)}</td>
      <td className={cn("border border-[#c8c8c8] px-2 py-1.5", over && "font-semibold")}>
        {over ? overText : underText}
      </td>
    </tr>
  );
}

/** A ruled signature block: ink above the line, then name, title and date printed beneath. */
function SignatureBlock({
  signer,
  caption,
  sig,
}: {
  signer: GateSigner;
  caption: string;
  sig?: AuditSignature;
}) {
  return (
    <div className="flex flex-col gap-1 text-xs" data-signed={sig ? "true" : undefined}>
      <span className="text-[10px] uppercase tracking-wide text-[#777]">{caption}</span>
      <div className="flex h-12 items-end border-b border-[#666]">
        {sig?.image ? (
          // eslint-disable-next-line @next/next/no-img-element -- signature ink is a data URL
          <img src={sig.image} alt={`Signature of ${sig.signer}`} className="animate-enter-fade h-11 w-40 object-contain object-left" />
        ) : sig?.typed ? (
          <span className="animate-enter-fade truncate font-serif text-xl italic text-[#1a3a6b]">{sig.typed}</span>
        ) : null}
      </div>
      <dl className="grid grid-cols-[auto_1fr] gap-x-2 text-[11px] leading-snug">
        <dt className="text-[#777]">Name</dt>
        <dd className="text-[#222]">{signer.name}</dd>
        <dt className="text-[#777]">Title</dt>
        <dd className="text-[#222]">{signer.role}</dd>
        <dt className="text-[#777]">Date</dt>
        <dd className="font-mono text-[#222]">{sig ? sig.signedAt.slice(0, 16).replace("T", " ") + " UTC" : "\u00a0"}</dd>
        {sig && (
          <>
            <dt className="text-[#777]">Ref.</dt>
            <dd className="font-mono text-[#555]">{sig.hash.slice(0, 12)}</dd>
          </>
        )}
      </dl>
    </div>
  );
}
