"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";

import { Spinner } from "@/components/agents/spinner";
import { SystemMark } from "@/components/shared/system-badge";
import { TypedText } from "@/components/shared/typed-text";
import { cn } from "@/lib/utils";

const played = new Set<string>();

export interface StagedChange {
  key: string;
  label: string;
  code?: string;
  from: string;
  to: string;
  /** Kept as is; shown without a strike. */
  unchanged?: boolean;
}

/**
 * What an agent writes back to a system of record: one field per row, the
 * old value struck in red and the new one typed in green, left to right.
 * The footer lands once the last row has been written.
 */
export function StagedChangeTable({
  title,
  system,
  rows,
  footer,
  footerTrailing,
  playKey,
  onDone,
}: {
  title: string;
  system: string;
  rows: StagedChange[];
  footer: ReactNode;
  footerTrailing?: ReactNode;
  playKey: string;
  onDone?: () => void;
}) {
  const instant = played.has(playKey);
  const [index, setIndex] = useState(instant ? rows.length : 0);
  const finished = index >= rows.length;
  const doneRef = useRef(onDone);
  doneRef.current = onDone;

  useEffect(() => {
    if (!finished) return;
    played.add(playKey);
    doneRef.current?.();
  }, [finished, playKey]);

  useEffect(() => {
    if (finished || !rows[index]?.unchanged) return;
    const t = window.setTimeout(() => setIndex((n) => Math.max(n, index + 1)), 420);
    return () => window.clearTimeout(t);
  }, [finished, index, rows]);

  return (
    <div className="overflow-hidden rounded-lg border" data-staged-change={playKey}>
      <div className="flex items-center justify-between gap-2 border-b bg-muted/30 px-4 py-2.5">
        <div className="flex min-w-0 items-center gap-2">
          <SystemMark name={system} className="h-4 w-4" />
          <span className="truncate text-xs font-semibold text-foreground">{title}</span>
        </div>
        <span className="shrink-0 text-[11px] text-muted-foreground">
          {finished ? "Written" : "Writing…"}
        </span>
      </div>
      <table className="w-full border-collapse text-sm">
        <thead>
          <tr className="border-b text-left text-[11px] text-muted-foreground">
            <th className="px-3 py-2 font-medium">Field</th>
            <th className="px-3 py-2 font-medium">Was</th>
            <th className="px-3 py-2 font-medium">Now</th>
            <th className="w-20 px-3 py-2 font-medium">
              <span className="sr-only">Status</span>
            </th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => {
            const written = i < index;
            const writing = i === index && !finished;
            return (
              <tr
                key={r.key}
                data-change-row={r.key}
                className={cn(
                  "border-t transition-colors duration-500 first:border-t-0",
                  writing && "bg-primary/5",
                  !written && !writing && "opacity-40"
                )}
              >
                <td className="px-3 py-2.5 align-middle">
                  {r.code && <div className="font-mono text-[11px] text-muted-foreground">{r.code}</div>}
                  <div className="text-foreground">{r.label}</div>
                </td>
                <td
                  className={cn(
                    "px-3 py-2.5 align-middle tabular-nums",
                    r.unchanged ? "text-muted-foreground" : "text-red-600 line-through"
                  )}
                >
                  {r.from}
                </td>
                <td
                  className={cn(
                    "px-3 py-2.5 align-middle font-medium tabular-nums",
                    r.unchanged ? "text-foreground" : "text-emerald-600"
                  )}
                >
                  {written || r.unchanged ? (
                    r.to
                  ) : writing ? (
                    <TypedText
                      text={r.to}
                      charMs={22}
                      onDone={() => setIndex((n) => Math.max(n, i + 1))}
                    />
                  ) : (
                    <span className="invisible">{r.to}</span>
                  )}
                </td>
                <td className="px-3 py-2.5 text-right align-middle">
                  {writing ? (
                    <Spinner size="sm" className="ml-auto text-primary" />
                  ) : written ? (
                    <span className="animate-enter-fade text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                      {r.unchanged ? "Kept" : "Updated"}
                    </span>
                  ) : null}
                </td>
              </tr>
            );
          })}
        </tbody>
        {finished && (
          <tfoot>
            <tr className="animate-enter-fade border-t bg-muted/30">
              <td colSpan={3} className="px-3 py-2.5 text-xs font-semibold text-foreground">
                {footer}
              </td>
              <td className="px-3 py-2.5 text-right">{footerTrailing}</td>
            </tr>
          </tfoot>
        )}
      </table>
    </div>
  );
}
