"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Eraser } from "lucide-react";

import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

/** Enough ink that a stray click doesn't count as a signature. */
const MIN_INK_PX = 60;

/**
 * A freehand signature field. Press and drag with a mouse, pen or finger to
 * sign; the parent receives a PNG data URL once there is enough ink.
 */
export function SignaturePad({
  onChange,
  disabled,
  className,
  canvasClassName,
}: {
  onChange: (dataUrl: string | null) => void;
  disabled?: boolean;
  className?: string;
  canvasClassName?: string;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const drawingRef = useRef(false);
  const lastRef = useRef<{ x: number; y: number } | null>(null);
  const inkRef = useRef(0);
  const [hasInk, setHasInk] = useState(false);

  const setupCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.round(rect.width * dpr);
    canvas.height = Math.round(rect.height * dpr);
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.lineWidth = 2.2;
    ctx.strokeStyle = getComputedStyle(canvas).color;
  }, []);

  useEffect(() => {
    setupCanvas();
  }, [setupCanvas]);

  const point = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
  };

  const handleDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (disabled) return;
    // Re-measure on the first stroke in case the field was laid out mid-animation.
    if (inkRef.current === 0) setupCanvas();
    e.currentTarget.setPointerCapture(e.pointerId);
    drawingRef.current = true;
    const p = point(e);
    lastRef.current = p;
    const ctx = e.currentTarget.getContext("2d");
    if (ctx) {
      ctx.beginPath();
      ctx.arc(p.x, p.y, 1.1, 0, Math.PI * 2);
      ctx.fillStyle = ctx.strokeStyle;
      ctx.fill();
    }
  };

  const handleMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!drawingRef.current || disabled) return;
    const ctx = e.currentTarget.getContext("2d");
    const last = lastRef.current;
    if (!ctx || !last) return;
    const p = point(e);
    const mid = { x: (last.x + p.x) / 2, y: (last.y + p.y) / 2 };
    ctx.beginPath();
    ctx.moveTo(last.x, last.y);
    ctx.quadraticCurveTo(last.x, last.y, mid.x, mid.y);
    ctx.lineTo(p.x, p.y);
    ctx.stroke();
    inkRef.current += Math.hypot(p.x - last.x, p.y - last.y);
    lastRef.current = p;
    if (!hasInk && inkRef.current >= MIN_INK_PX) setHasInk(true);
  };

  const handleUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!drawingRef.current) return;
    drawingRef.current = false;
    lastRef.current = null;
    if (inkRef.current >= MIN_INK_PX) {
      onChange(e.currentTarget.toDataURL("image/png"));
    }
  };

  const clear = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    ctx?.clearRect(0, 0, canvas.width, canvas.height);
    inkRef.current = 0;
    setHasInk(false);
    onChange(null);
  };

  return (
    <div className={cn("space-y-1.5", className)}>
      <div
        className={cn(
          "relative rounded-md border border-dashed bg-background",
          disabled ? "border-border" : "border-primary/40"
        )}
      >
        <canvas
          ref={canvasRef}
          aria-label="Signature field. Press and drag to sign."
          role="img"
          onPointerDown={handleDown}
          onPointerMove={handleMove}
          onPointerUp={handleUp}
          onPointerCancel={handleUp}
          className={cn(
            "block w-full touch-none text-foreground",
            canvasClassName ?? "h-32",
            disabled ? "cursor-default" : "cursor-crosshair"
          )}
        />
        {!hasInk && !disabled && (
          <span className="pointer-events-none absolute inset-0 flex items-center justify-center text-xs text-muted-foreground">
            Press and drag to sign
          </span>
        )}
        <div className="pointer-events-none absolute inset-x-4 bottom-6 border-b border-muted-foreground/30" />
        <span className="pointer-events-none absolute bottom-1.5 left-4 text-[10px] uppercase tracking-wide text-muted-foreground">
          Signature
        </span>
      </div>
      {!disabled && (
        <div className="flex justify-end">
          <Button
            type="button"
            size="sm"
            variant="ghost"
            onClick={clear}
            disabled={!hasInk}
            className="h-7 gap-1.5 px-2 text-xs"
          >
            <Eraser className="h-3.5 w-3.5" /> Clear
          </Button>
        </div>
      )}
    </div>
  );
}
