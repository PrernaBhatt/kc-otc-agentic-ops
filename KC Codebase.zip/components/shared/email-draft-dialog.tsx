"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import {
  CalendarClock,
  Eye,
  Paperclip,
  Pencil,
  Send,
  Sparkles,
  X,
} from "lucide-react";
import { PdfViewer } from "@/components/shared/pdf-viewer";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { EMAIL_DRAFT_MS, useTypewriter } from "@/lib/hooks/use-typewriter";

/**
 * The single email-drafting surface used everywhere in the demo an agent
 * proposes outbound correspondence. The body streams in character by
 * character like a live model completion, then hands control to the
 * reviewer: send it, discard it, or schedule a follow-up. Modeled after the
 * email agent card in agentic-lien-automation.
 */

type Attachment = {
  name: string;
  meta: string;
  /** A4 pages of the file; when set, the attachment opens in the PDF viewer. */
  pages?: ReactNode[];
};

export function EmailDraftDialog({
  to,
  toOrg,
  cc,
  subject,
  body,
  attachment,
  sentLabel,
  onSend,
  onClose,
  onFollowUp,
}: {
  to: string;
  toOrg?: string;
  cc?: string;
  subject: string;
  body: string;
  attachment?: Attachment;
  sentLabel?: string;
  onSend: () => void;
  onClose: () => void;
  onFollowUp?: () => void;
}) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const { visible, done } = useTypewriter(body, EMAIL_DRAFT_MS);
  const [sent, setSent] = useState(false);
  const [editing, setEditing] = useState(false);
  const [editedSubject, setEditedSubject] = useState(subject);
  const [editedBody, setEditedBody] = useState(body);
  const [previewOpen, setPreviewOpen] = useState(false);
  const bodyRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (editing) bodyRef.current?.focus();
  }, [editing]);

  useEffect(() => {
    // The attachment viewer sits above this dialog and owns Escape while open.
    if (previewOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.stopPropagation();
        onClose();
      }
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [onClose, previewOpen]);

  if (!mounted) return null;

  const dialog = createPortal(
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4"
      onClick={onClose}
    >
      <div
        className="flex max-h-[85vh] w-full max-w-lg flex-col overflow-hidden rounded-xl border bg-card shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3 border-b p-4">
          <div className="flex items-start gap-3">
            <span className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-lg bg-orange-500/15">
              <Sparkles className="h-4.5 w-4.5 text-orange-500" />
            </span>
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                Email agent · draft
              </p>
              <h3 className="text-base font-semibold">
                {sent
                  ? "Sent"
                  : !done
                    ? "Drafting…"
                    : editing
                      ? "Editing draft"
                      : "Ready to send"}
              </h3>
            </div>
          </div>
          <div className="flex items-center gap-1">
            {done && !sent && (
              <button
                type="button"
                onClick={() => setEditing((e) => !e)}
                className={`flex items-center gap-1 rounded-md px-2 py-1 text-xs font-medium ${
                  editing
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:bg-muted"
                }`}
              >
                <Pencil className="h-3.5 w-3.5" />
                {editing ? "Done" : "Edit"}
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="rounded-md p-1 text-muted-foreground hover:bg-muted"
              aria-label="Close"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        <div className="flex-1 space-y-3 overflow-y-auto p-4">
          <div className="space-y-2 rounded-lg bg-muted/40 px-3 py-2.5">
            <div className="flex items-baseline gap-2 text-sm">
              <span className="w-16 flex-shrink-0 text-xs text-muted-foreground">
                To
              </span>
              <span className="font-medium">
                {to}
                {toOrg ? (
                  <span className="text-muted-foreground"> · {toOrg}</span>
                ) : null}
              </span>
            </div>
            {cc ? (
              <div className="flex items-baseline gap-2 text-sm">
                <span className="w-16 flex-shrink-0 text-xs text-muted-foreground">
                  Cc
                </span>
                <span className="font-medium">{cc}</span>
              </div>
            ) : null}
            <div className="flex items-baseline gap-2 text-sm">
              <span className="w-16 flex-shrink-0 text-xs text-muted-foreground">
                Subject
              </span>
              {editing ? (
                <input
                  value={editedSubject}
                  onChange={(e) => setEditedSubject(e.target.value)}
                  className="flex-1 rounded-md border bg-background px-2 py-1 text-sm font-medium outline-none focus:ring-1 focus:ring-primary"
                />
              ) : (
                <span className="font-medium">{editedSubject}</span>
              )}
            </div>
          </div>

          {editing ? (
            <Textarea
              ref={bodyRef}
              value={editedBody}
              onChange={(e) => setEditedBody(e.target.value)}
              className="min-h-48 resize-none border bg-background p-3.5 text-sm leading-relaxed"
            />
          ) : (
            <div className="rounded-md border bg-background p-3.5 text-sm leading-relaxed">
              <p className="whitespace-pre-wrap text-foreground">
                {done ? editedBody : visible}
                {!done && (
                  <span className="ml-0.5 inline-block h-3.5 w-[2px] -translate-y-0.5 align-middle bg-primary animate-caret-blink" />
                )}
              </p>
            </div>
          )}

          {attachment && done && !editing && attachment.pages ? (
            <button
              type="button"
              onClick={() => setPreviewOpen(true)}
              className="animate-enter flex w-full items-center justify-between gap-2 rounded-md border bg-muted/30 px-3 py-2 text-left transition-colors hover:bg-muted/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              <span className="flex items-center gap-2 text-sm">
                <Paperclip className="h-4 w-4 flex-shrink-0 text-muted-foreground" />
                <span>
                  <span className="font-medium">{attachment.name}</span>
                  <span className="text-muted-foreground"> · {attachment.meta}</span>
                </span>
              </span>
              <span className="flex flex-shrink-0 items-center gap-1 text-xs font-medium text-primary">
                <Eye className="h-3.5 w-3.5" />
                Preview
              </span>
            </button>
          ) : attachment && done && !editing ? (
            <div className="flex items-center justify-between gap-2 rounded-md border bg-muted/30 px-3 py-2">
              <span className="flex items-center gap-2 text-sm">
                <Paperclip className="h-4 w-4 flex-shrink-0 text-muted-foreground" />
                <span>
                  <span className="font-medium">{attachment.name}</span>
                  <span className="text-muted-foreground"> · {attachment.meta}</span>
                </span>
              </span>
            </div>
          ) : null}
        </div>

        <div className="flex items-center justify-end gap-2 border-t p-4">
          {sent ? (
            <Button size="sm" disabled>
              <Send className="h-4 w-4" />
              {sentLabel ?? "Sent"}
            </Button>
          ) : (
            <>
              <Button variant="outline" size="sm" onClick={onClose}>
                Discard
              </Button>
              {onFollowUp && (
                <Button variant="outline" size="sm" onClick={onFollowUp}>
                  <CalendarClock className="h-4 w-4" />
                  Follow-up
                </Button>
              )}
              <Button
                size="sm"
                disabled={!done || editing}
                onClick={() => {
                  setSent(true);
                  onSend();
                }}
              >
                <Send className="h-4 w-4" />
                Send
              </Button>
            </>
          )}
        </div>
      </div>
    </div>,
    document.body
  );

  // A sibling of the dialog, not a child, so clicks in the viewer never
  // bubble to the draft's backdrop and close it.
  return (
    <>
      {dialog}
      {previewOpen && attachment?.pages && (
        <PdfViewer fileName={attachment.name} pages={attachment.pages} onClose={() => setPreviewOpen(false)} />
      )}
    </>
  );
}
