import type { ReactNode } from "react";

import { cn } from "@/lib/utils";

/** Ink colour shared with the formal letter skins in source-doc-preview. */
export const FORM_NAVY = "#1a3a6b";

export interface GateFormField {
  label: string;
  value: string;
  mono?: boolean;
}

export interface GateFormColumn {
  key: string;
  label: string;
  align?: "right";
  mono?: boolean;
}

export interface GateFormTable {
  columns: GateFormColumn[];
  rows: Record<string, string>[];
  total?: { label: string; value: string };
}

/** The printed approval form a gate signs: fields, line detail and the basis for the decision. */
export interface GateForm {
  formNo: string;
  formTitle: string;
  /** Printed document number; defaults to the decision ID in the modal's documentNo. */
  documentNo?: string;
  issuer?: string;
  fields: GateFormField[];
  table?: GateFormTable;
  basis?: string;
}

export function FormSection({ no, title, children }: { no: number; title: string; children: ReactNode }) {
  return (
    <section className="flex flex-col">
      <div
        className="px-3 py-1.5 text-[11px] font-bold uppercase tracking-wide text-white"
        style={{ backgroundColor: FORM_NAVY }}
      >
        {no}. {title}
      </div>
      <div className="pt-2">{children}</div>
    </section>
  );
}

export function FormFieldGrid({ fields }: { fields: GateFormField[] }) {
  return (
    <dl className="grid grid-cols-1 border-l border-t border-[#c8c8c8] sm:grid-cols-2">
      {fields.map((f) => (
        <div key={f.label} className="flex flex-col border-b border-r border-[#c8c8c8] px-2.5 py-1.5">
          <dt className="text-[10px] uppercase tracking-wide text-[#777]">{f.label}</dt>
          <dd className={cn("text-sm text-[#222]", f.mono && "font-mono text-[13px]")}>{f.value}</dd>
        </div>
      ))}
    </dl>
  );
}

export function FormLineTable({ table }: { table: GateFormTable }) {
  return (
    <table className="w-full border-collapse border border-[#c8c8c8] text-xs">
      <thead>
        <tr className="bg-[#eef1f4]">
          {table.columns.map((col) => (
            <th
              key={col.key}
              className={cn(
                "border border-[#c8c8c8] px-2 py-1.5 font-bold text-[#333]",
                col.align === "right" ? "text-right" : "text-left"
              )}
            >
              {col.label}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {table.rows.map((row, i) => (
          <tr key={i}>
            {table.columns.map((col) => (
              <td
                key={col.key}
                className={cn(
                  "border border-[#c8c8c8] px-2 py-1.5 align-top text-[#222]",
                  col.align === "right" && "text-right tabular-nums",
                  col.mono && "font-mono text-[11px]"
                )}
              >
                {row[col.key]}
              </td>
            ))}
          </tr>
        ))}
      </tbody>
      {table.total && (
        <tfoot>
          <tr>
            <td
              colSpan={table.columns.length - 1}
              className="border border-[#c8c8c8] px-2 py-1.5 text-right font-bold text-[#222]"
            >
              {table.total.label}
            </td>
            <td className="border border-[#c8c8c8] px-2 py-1.5 text-right font-bold tabular-nums text-[#222]">
              {table.total.value}
            </td>
          </tr>
        </tfoot>
      )}
    </table>
  );
}

/** A paper-form tick box: an empty square, or a square marked with an X. */
export function FormCheckbox({ checked }: { checked: boolean }) {
  return (
    <span
      aria-hidden
      className="relative mt-0.5 inline-flex h-3.5 w-3.5 shrink-0 items-center justify-center border border-[#333] bg-white text-[11px] font-bold leading-none"
      style={{ color: FORM_NAVY }}
    >
      {checked ? "X" : ""}
    </span>
  );
}
