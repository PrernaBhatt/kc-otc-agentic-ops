"use client";

import { ShieldCheck } from "lucide-react";

import { FloatingTip, useTipAnchor } from "@/components/shared/floating-tip";
import { findControl } from "@/lib/data/sox-controls";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

/**
 * A SOX control reference chip ("SOX 1.4.3"). Hover shows the control, its
 * owner and the evidence it needs; click opens the Audit trail filtered to it.
 */
export function ControlTag({
  controlRef,
  className,
  interactive = true,
}: {
  controlRef: string;
  className?: string;
  interactive?: boolean;
}) {
  const { requestNav } = useOtcStore();
  const { anchor, show, hide } = useTipAnchor();
  const control = findControl(controlRef);
  if (!control) return null;

  const chip = (
    <>
      <ShieldCheck className="h-3 w-3 shrink-0" aria-hidden />
      SOX {control.ref}
    </>
  );
  const base = cn(
    "inline-flex shrink-0 items-center gap-1 whitespace-nowrap rounded-full border border-primary/30 bg-primary/5 px-2 py-0.5 text-[11px] font-medium text-primary",
    className
  );

  return (
    <>
      {interactive ? (
        <button
          type="button"
          data-control-ref={control.ref}
          className={cn(base, "transition-colors hover:bg-primary/10")}
          onClick={(e) => {
            e.stopPropagation();
            hide();
            requestNav({ view: "audit", audit: { controlRef: control.ref } });
          }}
          onPointerEnter={(e) => show(e.currentTarget.getBoundingClientRect())}
          onPointerLeave={hide}
          onFocus={(e) => show(e.currentTarget.getBoundingClientRect())}
          onBlur={hide}
          aria-label={`SOX control ${control.ref}: ${control.name}. Open in audit trail`}
        >
          {chip}
        </button>
      ) : (
        <span
          data-control-ref={control.ref}
          className={base}
          onPointerEnter={(e) => show(e.currentTarget.getBoundingClientRect())}
          onPointerLeave={hide}
        >
          {chip}
        </span>
      )}
      <FloatingTip
        anchor={anchor}
        content={{
          title: `${control.family} · ${control.owner}`,
          value: control.name,
          note: `Evidence: ${control.evidenceRequired.join(", ")}`,
        }}
      />
    </>
  );
}

export function ControlTags({
  refs,
  className,
  interactive,
}: {
  refs: string[];
  className?: string;
  interactive?: boolean;
}) {
  return (
    <span className={cn("inline-flex flex-wrap items-center gap-1", className)}>
      {refs.map((r) => (
        <ControlTag key={r} controlRef={r} interactive={interactive} />
      ))}
    </span>
  );
}
