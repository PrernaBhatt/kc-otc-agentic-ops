"use client";

import { useEffect, useLayoutEffect, useRef, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { FileText, X, ZoomIn, ZoomOut } from "lucide-react";

import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

/** A4 at 96 dpi. Pages are laid out at this size, then scaled to the view. */
export const A4 = { w: 794, h: 1123 } as const;
const PAGE_GAP = 20;
const MIN_ZOOM = 0.5;
const MAX_ZOOM = 2;

/**
 * Browser-style PDF viewer: dark toolbar, grey canvas, A4 pages stacked with a
 * page counter and zoom. Each page is a fixed 794 × 1123 layout so the
 * document reads exactly like the printed file at any zoom.
 */
export function PdfViewer({
  fileName,
  pages,
  onClose,
}: {
  fileName: string;
  pages: ReactNode[];
  onClose: () => void;
}) {
  const [mounted, setMounted] = useState(false);
  const [fit, setFit] = useState(1);
  const [zoom, setZoom] = useState<number | null>(null);
  const [page, setPage] = useState(0);
  const scrollRef = useRef<HTMLDivElement>(null);
  const scale = zoom ?? fit;

  useEffect(() => setMounted(true), []);

  useLayoutEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const measure = () => setFit(Math.min(1, (el.clientWidth - 48) / A4.w));
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, [mounted]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.stopPropagation();
        onClose();
      }
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [onClose]);

  const onScroll = () => {
    const el = scrollRef.current;
    if (!el) return;
    const step = A4.h * scale + PAGE_GAP;
    setPage(Math.min(pages.length - 1, Math.max(0, Math.round(el.scrollTop / step))));
  };

  const stepZoom = (delta: number) =>
    setZoom(Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, Math.round((scale + delta) * 10) / 10)));

  if (!mounted) return null;

  return createPortal(
    <div className="fixed inset-0 z-[90] flex items-center justify-center bg-black/60 p-3 text-left md:p-8" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-label={fileName}
        className="animate-enter flex h-full w-full max-w-5xl flex-col overflow-hidden rounded-xl bg-[#525659] shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex h-12 shrink-0 items-center gap-3 bg-[#323639] px-3 text-[#f1f1f1]">
          <span className="flex min-w-0 flex-1 items-center gap-2">
            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded bg-[#e5252a]">
              <FileText className="h-3.5 w-3.5" aria-hidden />
            </span>
            <span className="truncate text-sm font-medium">{fileName}</span>
          </span>

          <span className="hidden text-sm tabular-nums sm:inline" aria-live="polite">
            <span className="rounded bg-[#191b1c] px-2 py-0.5">{page + 1}</span>
            <span className="text-[#bdc1c6]"> / {pages.length}</span>
          </span>

          <span className="mx-1 hidden h-5 w-px bg-[#5f6368] sm:block" aria-hidden />

          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => stepZoom(-0.1)}
              disabled={scale <= MIN_ZOOM}
              className="rounded-full p-1.5 hover:bg-[#4a4d51] disabled:opacity-40"
              aria-label="Zoom out"
            >
              <ZoomOut className="h-4 w-4" />
            </button>
            <span className="w-12 rounded bg-[#191b1c] py-0.5 text-center text-xs tabular-nums">
              {Math.round(scale * 100)}%
            </span>
            <button
              type="button"
              onClick={() => stepZoom(0.1)}
              disabled={scale >= MAX_ZOOM}
              className="rounded-full p-1.5 hover:bg-[#4a4d51] disabled:opacity-40"
              aria-label="Zoom in"
            >
              <ZoomIn className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={() => setZoom(null)}
              className={cn(
                "rounded-md px-2 py-1 text-xs font-medium hover:bg-[#4a4d51]",
                zoom === null && "bg-[#4a4d51]"
              )}
              aria-pressed={zoom === null}
            >
              Fit
            </button>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="ml-1 rounded-full p-1.5 hover:bg-[#4a4d51]"
            aria-label="Close preview"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div ref={scrollRef} onScroll={onScroll} className="flex-1 overflow-auto">
          <div className="flex min-w-fit flex-col items-center px-6 py-6" style={{ gap: PAGE_GAP }}>
            {pages.map((content, i) => (
              <div
                key={i}
                className="animate-enter shrink-0 overflow-hidden bg-[#ffffff] shadow-[0_2px_8px_rgba(0,0,0,0.45)]"
                style={{ width: A4.w * scale, height: A4.h * scale, animationDelay: `${i * 120}ms` }}
                aria-label={`Page ${i + 1} of ${pages.length}`}
                role="region"
              >
                <div style={{ width: A4.w, height: A4.h, transform: `scale(${scale})`, transformOrigin: "top left" }}>
                  {content}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
}

/** Button that opens a PDF in the viewer, e.g. a source document on a run step. */
export function PdfTrigger({
  fileName,
  pages,
  label,
  className,
}: {
  fileName: string;
  pages: () => ReactNode[];
  label: string;
  className?: string;
}) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button variant="outline" size="sm" className={cn("whitespace-nowrap", className)} onClick={() => setOpen(true)}>
        <FileText className="h-4 w-4" />
        {label}
      </Button>
      {open && <PdfViewer fileName={fileName} pages={pages()} onClose={() => setOpen(false)} />}
    </>
  );
}
