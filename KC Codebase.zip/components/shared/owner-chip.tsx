"use client";

import { findAccount, type Person } from "@/lib/data/account-owners";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

export function PersonAvatar({
  person,
  size = "sm",
  className,
}: {
  person: Pick<Person, "initials" | "name">;
  size?: "xs" | "sm" | "md";
  className?: string;
}) {
  return (
    <span
      aria-hidden
      className={cn(
        "inline-flex shrink-0 items-center justify-center rounded-full bg-primary/10 font-semibold text-primary",
        size === "xs" && "h-4 w-4 text-[8px]",
        size === "sm" && "h-5 w-5 text-[9px]",
        size === "md" && "h-8 w-8 text-xs",
        className
      )}
    >
      {person.initials}
    </span>
  );
}

/**
 * The customer's account owner. Click opens Accounts with that customer
 * selected. `account` takes an account id or any customer name.
 */
export function OwnerChip({
  account,
  variant = "full",
  className,
}: {
  account: string;
  variant?: "full" | "compact";
  className?: string;
}) {
  const { requestNav } = useOtcStore();
  const a = findAccount(account);
  if (!a) return null;

  return (
    <button
      type="button"
      data-owner={a.owner.ownerId}
      data-account={a.accountId}
      onClick={(e) => {
        e.stopPropagation();
        requestNav({ view: "accounts", accountId: a.accountId });
      }}
      className={cn(
        "inline-flex min-w-0 shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full border bg-background py-0.5 pl-0.5 pr-2 text-[11px] text-foreground transition-colors hover:bg-muted/60",
        className
      )}
      aria-label={`${a.owner.name}, ${a.shortName} owner. Open account`}
    >
      <PersonAvatar person={a.owner} />
      <span className="font-medium">{a.owner.name}</span>
      {variant === "full" && (
        <span className="text-muted-foreground">{a.shortName} owner</span>
      )}
    </button>
  );
}
