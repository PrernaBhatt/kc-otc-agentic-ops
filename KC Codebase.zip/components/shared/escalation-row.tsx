"use client";

import { ArrowUpRight } from "lucide-react";

import { ApprovalChain } from "@/components/shared/approval-chain";
import { ESCALATION_STATUSES, type Escalation } from "@/lib/data/escalations";
import { escalationAgeDays, isEscalationOverdue } from "@/lib/escalation-selectors";
import { formatUsd } from "@/lib/format";
import { useOtcStore } from "@/lib/store";
import { cn } from "@/lib/utils";

/** Status chain nodes for an escalation: Raised → Acknowledged → Actioned → Closed. */
export function escalationChainNodes(e: Escalation) {
  const idx = ESCALATION_STATUSES.indexOf(e.status);
  return e.chain.map((s, i) => ({
    id: s.status,
    label: s.status,
    sub: s.at ? s.at.slice(5) : undefined,
    state: (i <= idx ? "done" : i === idx + 1 ? "active" : "waiting") as "done" | "active" | "waiting",
  }));
}

/** A compact, tracked escalation: team, subject, SLA bar and status chain. Click opens Accounts. */
export function EscalationRow({ escalation: e, compact = false }: { escalation: Escalation; compact?: boolean }) {
  const { requestNav, freshEscalations } = useOtcStore();
  const age = escalationAgeDays(e);
  const overdue = isEscalationOverdue(e);
  const pct = Math.min(100, (age / e.slaDays) * 100);
  const fresh = freshEscalations.includes(e.id);

  return (
    <button
      type="button"
      data-escalation-id={e.id}
      data-escalation-status={e.status}
      data-overdue={overdue ? "true" : undefined}
      onClick={() => requestNav({ view: "accounts", accountId: e.accountIds[0] })}
      className={cn(
        "animate-enter-fade flex w-full flex-col gap-2 rounded-lg border p-3 text-left transition-colors hover:bg-muted/40",
        fresh && "step-halo [--halo:4px]"
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-muted-foreground">
            <span className="font-mono">{e.id}</span>
            <span>·</span>
            <span className="font-medium text-foreground">
              {e.team} · {e.unit}
            </span>
          </div>
          <div className="mt-0.5 text-sm font-medium text-foreground text-pretty">{e.subject}</div>
        </div>
        <div className="flex shrink-0 flex-col items-end gap-1">
          <span className="text-sm font-semibold tabular-nums text-foreground">{formatUsd(e.amountUsd ?? 0)}</span>
          <span
            className={cn(
              "rounded-full px-2 py-0.5 text-[10px] font-medium",
              overdue ? "bg-red-50 text-red-700" : "bg-muted text-muted-foreground"
            )}
          >
            {overdue ? "Overdue" : e.status}
          </span>
        </div>
      </div>
      <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
        <span className="shrink-0 tabular-nums">
          Day {age} / SLA {e.slaDays}
        </span>
        <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-muted">
          <span
            className={cn("grow-x block h-full rounded-full", overdue ? "bg-red-500" : "bg-primary")}
            style={{ width: `${Math.max(pct, 3)}%` }}
          />
        </span>
        <ArrowUpRight className="h-3.5 w-3.5 shrink-0" aria-hidden />
      </div>
      {!compact && <ApprovalChain nodes={escalationChainNodes(e)} size="sm" />}
    </button>
  );
}
