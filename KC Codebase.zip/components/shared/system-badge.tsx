import { ClipboardList, Megaphone, RefreshCw, SearchCheck } from "lucide-react"
import type { LucideIcon } from "lucide-react"

import { cn } from "@/lib/utils"

/**
 * A single, shared way to render an external system / ERP / trade-system tag
 * across the whole workspace.
 *
 * - Systems with a clean, freely-usable official mark (SAP family, ServiceNow)
 *   render that mark. The SVGs live in /public/logos and were pulled from
 *   theSVG.org — the brand marks remain trademarks of their owners.
 * - Systems whose logos are trademark-restricted or are internal to this
 *   program (Vistex, Promax, PricerX, CAS) render a brand-colored monogram tile.
 * - Generic capability categories ("Trade Promotion Management",
 *   "Post-audit provider", …) render a semantic icon rather than a fake logo.
 */

type LogoMark =
  | { kind: "svg"; src: string; alt: string }
  | { kind: "mono"; letters: string; bg: string; fg: string }
  | { kind: "icon"; Icon: LucideIcon }

function resolveMark(name: string): LogoMark {
  const key = name.toLowerCase()

  // SAP and every SAP-family engine (S/4HANA, ECC, SAP AR/FI/Dispute Mgmt).
  if (/\bsap\b|s\/?4\s?hana|\becc\b/.test(key)) {
    return { kind: "svg", src: "/logos/sap.svg", alt: "SAP" }
  }
  // ServiceNow (theSVG slug is "now").
  if (/service\s?now|\bnow\b/.test(key)) {
    return { kind: "svg", src: "/logos/servicenow.svg", alt: "ServiceNow" }
  }
  if (/vertex/.test(key)) {
    return { kind: "svg", src: "/brand/systems/vertex.png", alt: "Vertex" }
  }
  // Trademark-restricted / internal systems → brand-colored monogram.
  if (/vistex/.test(key)) {
    return { kind: "mono", letters: "V", bg: "#0a5cb8", fg: "#ffffff" }
  }
  if (/promax/.test(key)) {
    return { kind: "mono", letters: "P", bg: "#1f9e8e", fg: "#ffffff" }
  }
  if (/pricer/.test(key)) {
    return { kind: "mono", letters: "Px", bg: "#6d28d9", fg: "#ffffff" }
  }
  if (/\bcas\b/.test(key)) {
    return { kind: "mono", letters: "C", bg: "#475569", fg: "#ffffff" }
  }
  if (/four\s?kites/.test(key)) {
    return { kind: "svg", src: "/brand/systems/fourkites.png", alt: "FourKites" }
  }
  // Retailer scheduling portals carry the retailer's own mark (site favicon).
  if (/walmart/.test(key)) {
    return { kind: "svg", src: "/brand/systems/walmart.png", alt: "Walmart" }
  }
  if (/kroger/.test(key)) {
    return { kind: "svg", src: "/brand/systems/kroger.jpg", alt: "Kroger" }
  }
  if (/costco/.test(key)) {
    return { kind: "svg", src: "/brand/systems/costco.png", alt: "Costco" }
  }
  if (/\btarget\b/.test(key)) {
    return { kind: "svg", src: "/brand/systems/target.png", alt: "Target" }
  }
  if (/high\s?radius/.test(key)) {
    return { kind: "mono", letters: "HR", bg: "#f26a21", fg: "#ffffff" }
  }
  // Generic capability categories → semantic icon, not a fabricated logo.
  if (/trade promotion|tpm\b/.test(key)) {
    return { kind: "icon", Icon: Megaphone }
  }
  if (/post-?audit/.test(key)) {
    return { kind: "icon", Icon: SearchCheck }
  }
  if (/exchange|backup pack|data feed/.test(key)) {
    return { kind: "icon", Icon: RefreshCw }
  }
  if (/claims? platform|claims?\b/.test(key)) {
    return { kind: "icon", Icon: ClipboardList }
  }
  // Last resort: first two significant letters on a neutral tile.
  const letters = name.replace(/[^a-zA-Z0-9]/g, "").slice(0, 2).toUpperCase() || "?"
  return { kind: "mono", letters, bg: "#334155", fg: "#ffffff" }
}

export function SystemMark({
  name,
  className,
}: {
  name: string
  className?: string
}) {
  const mark = resolveMark(name)

  if (mark.kind === "svg") {
    return (
      // eslint-disable-next-line @next/next/no-img-element -- brand mark, not an optimizable asset
      <img
        src={mark.src || "/placeholder.svg"}
        alt={mark.alt}
        className={cn("h-3.5 w-3.5 shrink-0 object-contain", className)}
      />
    )
  }

  if (mark.kind === "icon") {
    const { Icon } = mark
    return (
      <Icon
        aria-label={name}
        className={cn("h-3.5 w-3.5 shrink-0 text-muted-foreground", className)}
      />
    )
  }

  return (
    <span
      aria-hidden
      className={cn(
        "grid h-3.5 w-3.5 shrink-0 place-items-center rounded-[3px] text-[7px] font-bold leading-none",
        className
      )}
      style={{ backgroundColor: mark.bg, color: mark.fg }}
    >
      {mark.letters}
    </span>
  )
}

export function SystemBadge({
  name,
  className,
  markClassName,
}: {
  name: string
  className?: string
  markClassName?: string
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 whitespace-nowrap rounded-full border bg-background px-2 py-0.5 text-xs font-medium text-foreground",
        className
      )}
    >
      <SystemMark name={name} className={markClassName} />
      {name}
    </span>
  )
}
