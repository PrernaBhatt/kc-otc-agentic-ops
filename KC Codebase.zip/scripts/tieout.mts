// PRD 01 §14: figure tie-outs, copy greps and structure checks. Runs before `next build`.
import { readFileSync, readdirSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { fileURLToPath } from "node:url";
import { createJiti } from "jiti";

const root = fileURLToPath(new URL("..", import.meta.url));
const jiti = createJiti(import.meta.url, { alias: { "@": root }, interopDefault: true });
const failures: string[] = [];

function check(label: string, ok: boolean) {
  if (!ok) failures.push(label);
}

async function load<T>(path: string): Promise<T> {
  return (await jiti.import(join(root, path))) as T;
}

// §12.1 Billing dispute SO-710269
const { billingDispute } = await load<typeof import("../lib/billing-dispute-selectors")>("lib/billing-dispute-selectors.ts");
const bd = billingDispute("DC-710269");
check("12.1 dispute case exists", !!bd);
if (bd) {
  check("12.1 short-pay 188,000", bd.shortPaid === 188_000);
  check("12.1 charge-back 150,000", bd.chargeBack === 150_000);
  check("12.1 credit 38,000", bd.credit === 38_000);
  check("12.1 charge-back + credit = short-pay", bd.chargeBack + bd.credit === bd.shortPaid);
  check("12.1 invoice - paid = short-pay", bd.invoiceTotal - bd.paid === bd.shortPaid);
}

// §12.2 Target SO-710249
const { pricingHoldCase, pricingHoldTotals } = await load<typeof import("../lib/data/pipeline-orders")>("lib/data/pipeline-orders.ts");
check("12.2 PO total 220,740", pricingHoldTotals.poTotal === 220_740);
check("12.2 contract total 220,000", pricingHoldTotals.contractTotal === 220_000);
check("12.2 variance 740", pricingHoldTotals.variance === 740);
check("12.2 variance above tolerance", pricingHoldTotals.variance > pricingHoldCase.tolerancePerOrderUsd);

// §12.3 Non-trade batch NT-2026-W44
const { batchTotals } = await load<typeof import("../lib/non-trade-selectors")>("lib/non-trade-selectors.ts");
check("12.3 total 312 / 486,400", batchTotals.total.count === 312 && batchTotals.total.usd === 486_400);
check("12.3 valid 204 / 198,400", batchTotals.valid.count === 204 && batchTotals.valid.usd === 198_400);
check("12.3 invalid 96 / 251,600", batchTotals.invalid.count === 96 && batchTotals.invalid.usd === 251_600);
check("12.3 exception 12 / 36,400", batchTotals.exception.count === 12 && batchTotals.exception.usd === 36_400);

// §12.4 Accounts
const { workloadTotals, agentShare } = await load<typeof import("../lib/account-selectors")>("lib/account-selectors.ts");
check("12.4 items 1,284", workloadTotals.items === 1_284);
check("12.4 agents 1,236", workloadTotals.agents === 1_236);
check("12.4 owner 48", workloadTotals.owner === 48);
check("12.4 share 96%", agentShare === 96);

// §10 Invoice-to-cash
const { invoiceToCashFor, rightFirstTimePct } = await load<typeof import("../lib/data/invoice-to-cash")>("lib/data/invoice-to-cash.ts");
const costco = invoiceToCashFor("SO-710260");
check("10.2 INV-710260 due 2026-09-28", costco?.invoiceId === "INV-710260" && costco.dueDate === "2026-09-28");
check("10.3 right-first-time 97.6%", rightFirstTimePct === 97.6);

// PRD 02 §6 OM KPIs, OTIF at risk and the three shipment runs. The selectors
// assert every equation at import, so a broken figure fails here first.
try {
  const s = await load<typeof import("../lib/shipment-selectors")>("lib/shipment-selectors.ts");
  check("02 OTIF A/S/D 96.8 / 93.4 / 89.6", s.otifPct.A === 96.8 && s.otifPct.S === 93.4 && s.otifPct.D === 89.6);
  check("02 OTIF A ≥ S ≥ D", s.otifPct.A >= s.otifPct.S && s.otifPct.S >= s.otifPct.D);
  check("02 perfect order 85.6", s.perfectOrder.pct === 85.6);
  check("02 validation accuracy 99.1", s.validationAccuracy.pct === 99.1);
  check("02 order-to-invoice 6.4 days", s.orderToInvoiceDays === 6.4);
  check("02 risk board 7 = 4 pre + 3 post, 3 need action", s.riskSummary.total === 7 && s.riskSummary.pre === 4 && s.riskSummary.post === 3 && s.riskSummary.needAction === 3);
  check("02 high-risk value 396,600", s.riskSummary.highValueUsd === 396_600);
  check("02 Run A slot inside window and replan needed", s.appointmentRun.slotInsideWindow && s.appointmentRun.needsReplan);
  check("02 Run B premium 1,740 / fine 2,964 / net 1,224", s.premiumFreight.premiumUsd === 1_740 && s.premiumFreight.fineUsd === 2_964 && s.premiumFreight.netUsd === 1_224);
  check("02 Run B premium within limit", s.premiumFreight.withinLimit);
  check("02 Run C misses 3 → 1, route 2 recommended", s.milkRunSummary.missesBefore === 3 && s.milkRunSummary.missesAfter === 1 && s.recommendedRoute.id === "r2");
  // v2: predictive ETA, Track & Trace, 7-day forecast, KPI deltas
  check("02v2 Run C predicted stop risk 99 / 97 / 96", s.milkRunPrediction.map((p) => p.riskPct).join("/") === "99/97/96");
  check("02v2 Track & Trace 24 loads = 9 pre + 8 in transit + 7 delivered", s.loadSummary.total === 24 && s.loadSummary.pre === 9 && s.loadSummary.transit === 8 && s.loadSummary.delivered === 7);
  check("02v2 every at-risk shipment is a Track & Trace load", s.loadSummary.atRisk === s.riskSummary.total);
  const untreated = s.otifForecast({});
  const decided = s.otifForecast({ "SHP-58201": "x", "SHP-58207": "x", "MR-58212": "x" });
  check("02v2 7-day OTIF D forecast 88.0 → 88.4, 4 orders recovered", untreated.pct === 88.0 && decided.pct === 88.4 && decided.recovered === 4);
  check("02v2 KPI deltas vs Jul", s.kpiDeltas.otif === 0.7 && s.kpiDeltas.perfectOrder === 0.6 && s.kpiDeltas.validation === 0.1 && s.kpiDeltas.cycleDays === -0.2);
} catch (e) {
  failures.push(`02 shipment figures: ${(e as Error).message}`);
}

// v2 single clock: no trend or label runs past the Command Center's "as of" month (Aug 2026)
const omKpis = readFileSync(join(root, "lib/data/om-kpis.ts"), "utf8");
check("02v2 OM trends end in Aug", /OM_TREND_MONTHS = \["Mar", "Apr", "May", "Jun", "Jul", "Aug"\]/.test(omKpis));

// §14.4 copy greps over app code
function walk(dir: string, out: string[] = []) {
  for (const name of readdirSync(dir)) {
    const p = join(dir, name);
    if (statSync(p).isDirectory()) walk(p, out);
    else if (/\.(ts|tsx)$/.test(name)) out.push(p);
  }
  return out;
}
const files = ["app", "components", "lib"].flatMap((d) => walk(join(root, d)));
const banned: [string, RegExp][] = [
  ["proceed with PO pricing", /proceed(ing)? (with|at) PO pricing/i],
  ["recovers $188,000", /recovers \$188,000/i],
  ["Ridgeway", /Ridgeway/],
  ["reissue as an action", /\breissue (the |a |an )?invoice\b|\bReissue\b(?! *0)/],
  ["Outside GBS scope", /Outside GBS scope/i],
  ["Logistics handoff", /Logistics handoff/i],
  ["Back to Shipments", /Back to Shipments/],
];
for (const f of files) {
  const text = readFileSync(f, "utf8");
  for (const [label, re] of banned) {
    if (re.test(text)) failures.push(`14.4 "${label}" found in ${relative(root, f)}`);
  }
}

// §14.4 every gate component carries a ControlTag / controls list
const gateFiles = files.filter((f) => /GateSignoffModal/.test(readFileSync(f, "utf8")) && !f.endsWith("gate-signoff-modal.tsx"));
for (const f of gateFiles) {
  const text = readFileSync(f, "utf8");
  check(`14.4 gate without control in ${relative(root, f)}`, /controls=\{|ControlTag/.test(text));
}

// §14.5 structure
const omv = readFileSync(join(root, "components/views/order-management-view.tsx"), "utf8");
const simBlock = omv.match(/const SIM_STAGES: SimStage\[\] = \[([\s\S]*?)\];/)?.[1] ?? "";
const simIds = (simBlock.match(/\{ id: "([^"]+)"/g) ?? []).map((m) => m.slice(7, -1));
check("02v2 order run has 11 stages (Target), 9 touchless (Costco)", simIds.length === 11 && simIds.filter((id) => id !== "pricing" && id !== "regulatory").length === 9);
check("02v2 order thread: confirmed → shipment plan → appointment → delivery", simIds.slice(-4).join(" ") === "confirmed shipment_plan appointment delivery");
check("02 order run has no handoff / carrier stage", !/id: "(handoff|carrier)"/.test(simBlock));
const stageCount = (path: string) => {
  const src = readFileSync(join(root, path), "utf8");
  const order = src.match(/const ORDER[^=]*=\s*\[([^\]]*)\]/)?.[1] ?? "";
  const gates = src.match(/const GATES[^=]*=\s*\[([^\]]*)\]/)?.[1] ?? "";
  return { stages: (order.match(/"/g) ?? []).length / 2, gates: (gates.match(/"/g) ?? []).length / 2, src };
};
check("14.5 billing dispute rail has 7 stages", stageCount("components/views/billing-dispute-run.tsx").stages === 7);
const runA = stageCount("components/views/appointment-slot-run.tsx");
check("02 Run A has 5 stages and no gate", runA.stages === 5 && runA.gates === 0 && !/GateSignoffModal/.test(runA.src));
for (const [label, path, control] of [
  ["Run B", "components/views/premium-freight-run.tsx", "1.2.1"],
  ["Run C", "components/views/milk-run-reroute-run.tsx", "1.2.2"],
] as const) {
  const r = stageCount(path);
  check(`02 ${label} has 5 stages and 1 gate`, r.stages === 5 && r.gates === 1);
  check(`02 ${label} gate carries control ${control}`, r.src.includes(`"${control}"`));
}

if (failures.length) {
  console.error(`tie-out failed (${failures.length}):\n- ${failures.join("\n- ")}`);
  process.exit(1);
}
console.log("tie-out passed: §12 figures, copy greps and run structure all tie.");
