import type { Metadata } from "next";
import { Inter, Geist_Mono } from "next/font/google";
import { Toaster } from "sonner";
import "./globals.css";

/**
 * the workspace sets its type in Helvetica Now Text (Monotype, licensed — it cannot
 * be embedded here). Helvetica Neue is the closest match already present on
 * macOS, so it leads the stack in globals.css; Inter is loaded here as the
 * webfont fallback for machines without it. The the workspace feel comes mostly from
 * the tracking, not from the glyphs.
 */
const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Order to Cash Workspace",
  description:
    "Distributor claim validation, deduction recovery and gross-to-net accounting",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${inter.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="min-h-full flex flex-col">
        {children}
        <Toaster position="bottom-right" />
      </body>
    </html>
  );
}
