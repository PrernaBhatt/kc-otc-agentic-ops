"use client";

import { Activity, useEffect, useState, type ComponentType } from "react";

import { Header } from "@/components/layout/header";
import { Sidebar, type ViewId } from "@/components/layout/sidebar";
import { LoginPage } from "@/components/login-page";
import { DashboardView } from "@/components/views/dashboard-view";
import { CreditReviewView } from "@/components/views/credit-review-view";
import { ShipmentsView } from "@/components/views/shipments-view";
import { OrderManagementView } from "@/components/views/order-management-view";
import { TransactionsView } from "@/components/views/transactions-view";
import { ExceptionsView } from "@/components/views/exceptions-view";
import { CopilotView } from "@/components/views/copilot-view";
import { BillingView } from "@/components/views/billing-view";
import { CashApplicationView } from "@/components/views/cash-application-view";
import { CollectionsView } from "@/components/views/collections-view";
import { ChargebacksView } from "@/components/views/chargebacks-view";
import { DeductionsView } from "@/components/views/deductions-view";
import { AuditView } from "@/components/views/audit-view";
import { AccountsView } from "@/components/views/accounts-view";
import { AgentWorkflowCard } from "@/components/agents/agent-workflow-card";

import { AgentWorkforce } from "@/components/agents/agent-workforce";
import { EndToEndWorkflowCard } from "@/components/agents/end-to-end-workflow-card";
import { FulfillmentFlow } from "@/components/flows/fulfillment-flow";
import { OrderProcessingFlow } from "@/components/flows/order-processing-flow";
import { orders } from "@/lib/data";
import { OtcStoreProvider, useOtcStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

/** Labels for the downstream stages the guided run jumps out to resolve. */
const RUN_STAGE_LABELS: Record<string, string> = {
  service_hub: "Customer Service Hub",
  cash_application: "Cash Application",
  deductions: "Deductions",
  collections: "Collections",
};

/**
 * The item this order needs handled on the page it jumped to — the "matching
 * row" for the run order (SO-xxxxxx) on the Customer Service Hub, Cash
 * Application, Deductions or Collections page. Resolving it records the stage
 * done and returns to the workspace in one click.
 */
/**
 * While a guided Order-Management run has sent the human to a downstream page
 * to resolve a stage, this banner sits at the top of that page so they can jump
 * straight back to the workspace — which then records the stage as resolved and
 * keeps the run going.
 */
function BackToWorkspaceBanner({
  onReturn,
}: {
  onReturn: () => void;
}) {
  const { runReturnStage } = useOtcStore();
  if (!runReturnStage) return null;
  return (
    <div className="mb-6 flex items-center justify-between gap-3 rounded-lg border border-primary/30 bg-primary/5 px-4 py-2.5 animate-enter">
      <span className="text-sm text-foreground">
        Resolving{" "}
        <span className="font-semibold">
          {RUN_STAGE_LABELS[runReturnStage] ?? runReturnStage}
        </span>{" "}
        for the guided run — resolve it here, then head back.
      </span>
      <Button size="sm" onClick={onReturn} className="whitespace-nowrap">
        <ArrowLeft className="h-4 w-4" />
        Back to workspace
      </Button>
    </div>
  );
}

export default function Home() {
  return (
    <OtcStoreProvider>
      <OtcApp />
    </OtcStoreProvider>
  );
}

function OtcApp() {
  const {
    completeStageReturn,
    runOrderId,
    runReturnStage,
    allInvoices,
    markInvoicePaid,
    returnRequested,
    consumeReturnRequest,
    navIntent,
    consumeNav,
  } = useOtcStore();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeView, setActiveView] = useState<ViewId>("dashboard");
  const [processingOrderId, setProcessingOrderId] = useState<string | null>(
    null
  );
  const [, setCompletedOrders] = useState<Set<string>>(new Set());
  const [showFulfillment, setShowFulfillment] = useState(false);
  const [resolvingOrderId, setResolvingOrderId] = useState<string | null>(null);
  const [exceptionsSubView, setExceptionsSubView] = useState<
    "exceptions" | "credit-review" | "fulfillment"
  >("exceptions");
  const [resolvedOrderIds, setResolvedOrderIds] = useState<string[]>([]);
  const [visitedViews, setVisitedViews] = useState<ViewId[]>([]);
  if (isLoggedIn && !visitedViews.includes(activeView)) {
    setVisitedViews([...visitedViews, activeView]);
  }

  const handleBackFromProcessing = () => setProcessingOrderId(null);
  const handleProcessingComplete = (orderId: string) =>
    setCompletedOrders((prev) => new Set(prev).add(orderId));
  const handleProcessOrder = (orderId: string) => setProcessingOrderId(orderId);
  const handleNavigateToFulfillment = () => {
    if (resolvingOrderId) {
      setExceptionsSubView("fulfillment");
    } else {
      setShowFulfillment(true);
    }
  };
  const handleFulfillmentBack = () => {
    setShowFulfillment(false);
    setActiveView("dashboard");
  };
  const handleResolveWithAI = (orderId: string) => {
    setResolvingOrderId(orderId);
    setExceptionsSubView("credit-review");
  };
  const handleExceptionsSubBack = () => {
    setResolvingOrderId(null);
    setExceptionsSubView("exceptions");
  };
  const handleExceptionsFulfillmentComplete = (orderId?: string) => {
    if (orderId) setResolvedOrderIds((prev) => [...prev, orderId]);
    setResolvingOrderId(null);
    setExceptionsSubView("exceptions");
  };
  const handleLogout = () => {
    setIsLoggedIn(false);
    setActiveView("dashboard");
    setProcessingOrderId(null);
    setCompletedOrders(new Set());
    setShowFulfillment(false);
    setVisitedViews([]);
  };
  const handleViewChange = (view: ViewId) => {
    setActiveView(view);
    setProcessingOrderId(null);
    setShowFulfillment(false);
    if (view !== "exceptions") {
      setResolvingOrderId(null);
      setExceptionsSubView("exceptions");
    }
  };
  const handleDashboardNavigate = (view: ViewId, orderId?: string) => {
    setActiveView(view);
    if (orderId) setProcessingOrderId(orderId);
  };
  const handleReturnToWorkspace = () => {
    completeStageReturn();
    setActiveView("orders");
  };
  // A run row on a downstream page (Cash Application receipt, deduction case,
  // query, worklist entry) asked to resolve its stage and return: run the real
  // action for that stage, then walk back to the workspace.
  useEffect(() => {
    if (!returnRequested) return;
    const inv = allInvoices.find((i) => i.orderId === runOrderId);
    if (runReturnStage === "cash_application" && inv) {
      markInvoicePaid(inv.invoiceId);
    }
    completeStageReturn();
    setActiveView("orders");
    consumeReturnRequest();
  }, [
    returnRequested,
    runReturnStage,
    runOrderId,
    allInvoices,
    markInvoicePaid,
    completeStageReturn,
    consumeReturnRequest,
  ]);

  // A chip, rail or tag elsewhere asked to open another page (Accounts, Audit
  // trail, a module with a case); its filters already sit in the store.
  useEffect(() => {
    if (!navIntent) return;
    setActiveView(navIntent.view);
    setProcessingOrderId(null);
    setShowFulfillment(false);
    if (navIntent.view !== "exceptions") {
      setResolvingOrderId(null);
      setExceptionsSubView("exceptions");
    }
    consumeNav();
  }, [navIntent, consumeNav]);

  if (!isLoggedIn) {
    return <LoginPage onLogin={() => setIsLoggedIn(true)} />;
  }

  if (showFulfillment) {
    return (
      <div className="min-h-screen bg-background">
        <Header onLogout={handleLogout} />
        <div className="flex">
          <Sidebar activeView={activeView} onViewChange={handleViewChange} />
          <main className="flex-1 min-w-0">
            <FulfillmentFlow
              onBack={handleFulfillmentBack}
              onComplete={() => handleFulfillmentBack()}
            />
          </main>
        </div>
      </div>
    );
  }

  const renderOverlay = () => {
    if (activeView === "exceptions" && resolvingOrderId) {
      if (exceptionsSubView === "credit-review") {
        return (
          <CreditReviewView
            focusOrderId={resolvingOrderId}
            onNavigateToFulfillment={handleNavigateToFulfillment}
            onBack={handleExceptionsSubBack}
          />
        );
      }
      if (exceptionsSubView === "fulfillment") {
        return (
          <FulfillmentFlow
            orderId={resolvingOrderId}
            onBack={handleExceptionsSubBack}
            onComplete={handleExceptionsFulfillmentComplete}
          />
        );
      }
    }
    if (processingOrderId) {
      const order = orders.find((o) => o.orderId === processingOrderId);
      if (order) {
        return (
          <OrderProcessingFlow
            order={order}
            onBack={handleBackFromProcessing}
            onComplete={handleProcessingComplete}
          />
        );
      }
    }
    return null;
  };

  const renderView = (view: ViewId) => {
    switch (view) {
      case "dashboard":
        return <DashboardView onNavigate={handleDashboardNavigate} />;
      case "shipments":
        return <ShipmentsView />;
      case "credit-review":
        return (
          <CreditReviewView
            onNavigateToFulfillment={handleNavigateToFulfillment}
          />
        );
      case "orders":
        return <OrderManagementView onNavigate={handleDashboardNavigate} />;
      case "transactions":
        return <TransactionsView onProcessOrder={handleProcessOrder} />;
      case "exceptions":
        return (
          <ExceptionsView
            onResolveWithAI={handleResolveWithAI}
            completedOrderIds={resolvedOrderIds}
          />
        );
      case "copilot":
        return <CopilotView />;
      case "agents":
        return (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-foreground">
                Agent Activity
              </h2>
              <p className="text-muted-foreground">
                The agents on this workspace, their systems and their workload
              </p>
            </div>
            <AgentWorkforce />
            <div className="grid items-stretch lg:grid-cols-2 xl:grid-cols-3 gap-6">
              <AgentWorkflowCard
                type="order"
                activeStep={3}
                showDetails
                onOpen={() => setActiveView("orders")}
              />
              <AgentWorkflowCard
                type="billing"
                activeStep={2}
                showDetails
                onOpen={() => setActiveView("billing")}
              />
              <AgentWorkflowCard
                type="cash"
                activeStep={2}
                showDetails
                onOpen={() => setActiveView("collections")}
              />
              <AgentWorkflowCard
                type="chargeback"
                activeStep={6}
                showDetails
                onOpen={() => setActiveView("chargebacks")}
              />
              <AgentWorkflowCard
                type="deduction"
                activeStep={3}
                showDetails
                onOpen={() => setActiveView("deductions")}
              />
            </div>
            <EndToEndWorkflowCard />
          </div>
        );
      case "billing":
        return <BillingView />;
      case "cash-application":
        return <CashApplicationView />;
      case "collections":
        return <CollectionsView />;
      case "chargebacks":
        return <ChargebacksView />;
      case "deductions":
        return (
          <DeductionsView
            onNavigateToCashApplication={() =>
              setActiveView("cash-application")
            }
          />
        );
      case "audit":
        return <AuditView />;
      case "accounts":
        return <AccountsView />;
      default:
        return <DashboardView onNavigate={handleDashboardNavigate} />;
    }
  };

  const overlay = renderOverlay();

  return (
    <div className="min-h-screen bg-background">
      <Header onLogout={handleLogout} />
      <div className="flex">
        <Sidebar activeView={activeView} onViewChange={handleViewChange} />
        <main className="flex-1 min-w-0 p-8">
          {activeView !== "orders" && runReturnStage && (
            <BackToWorkspaceBanner onReturn={handleReturnToWorkspace} />
          )}
          {overlay}
          {/* Visited pages stay mounted but hidden, so a run keeps its progress
              when the presenter follows a chip or link to another page and back. */}
          {visitedViews.map((view) => (
            <Activity key={view} mode={!overlay && view === activeView ? "visible" : "hidden"}>
              {renderView(view)}
            </Activity>
          ))}
        </main>
      </div>
    </div>
  );
}
