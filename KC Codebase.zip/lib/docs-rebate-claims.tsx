/**
 * Source documents for Scenario 3 — growth rebate recalculation.
 *
 * Same rule as the other doc builders: every field is read from the same
 * record the screen reads, so a document can never disagree with the
 * assessment that opened it.
 */

import type { SourceDoc } from "@/components/modals/source-doc-preview";
import { findRebateClaimCase } from "./data/rebate-claims";
import {
  rebateClaimAssessment,
  renderRebateClaimLetter,
} from "./rebate-claim-selectors";

const ISSUER = "Order to Cash Workspace";
const usd = (n: number) => `$${n.toLocaleString("en-US")}`;
const pct1 = (n: number) => `${n.toLocaleString("en-US")}%`;

/* ------------------------------------------------------------------ *
 * The rebate claim, as the retailer sent it
 * ------------------------------------------------------------------ */

export function buildRebateDeductionDoc(caseId: string): SourceDoc {
  const c = findRebateClaimCase(caseId)!;
  const claimed = c.invoiceAmount - c.amountPaid;

  return {
    docId: `rebate-deduction-${caseId}`,
    title: `Growth rebate claim ${caseId}`,
    docLabel: "Deduction backup",
    reference: c.claimRef,
    issuer: c.customerName,
    meta: [
      { label: "Invoice", value: c.invoiceId },
      { label: "Received", value: c.receivedDate },
      { label: "Reason code", value: c.reasonCode },
      { label: "Program", value: c.program.programId },
    ],
    columns: [
      { key: "item", label: "As claimed" },
      { key: "value", label: "Value", align: "right" },
    ],
    rows: [
      { id: "basis", cells: { item: "Sales basis", value: c.retailerClaim.basis } },
      { id: "gross", cells: { item: "Gross sales (as claimed)", value: usd(c.retailerClaim.grossSales) } },
      { id: "growth", cells: { item: "Growth claimed", value: pct1(c.retailerClaim.claimedGrowthPct) } },
      { id: "tier", cells: { item: "Tier claimed", value: pct1(c.retailerClaim.claimedTierPct) } },
    ],
    totals: [{ label: "Rebate claimed", value: usd(claimed), emphasis: true }],
    footnote: `Remittance note: "${c.customerNote}"`,
    highlightRowIds: ["basis", "tier"],
    highlightNote:
      "Two assumptions drive the overstatement: gross (not net eligible) sales, and the pre-amendment 3% tier.",
    aiSummary: `${c.customerName} withheld ${usd(claimed)} for a ${pct1(c.retailerClaim.claimedTierPct)} growth rebate, worked out on ${usd(c.retailerClaim.grossSales)} of gross sales across the retailer and its affiliates. The signed agreement measures the rebate differently, so it has to be re-run on the contract basis.`,
  };
}

/* ------------------------------------------------------------------ *
 * The signed agreement, as amended
 * ------------------------------------------------------------------ */

export function buildAgreementDoc(caseId: string): SourceDoc {
  const a = rebateClaimAssessment(caseId)!;
  const c = a.case;

  return {
    docId: `rebate-agreement-${caseId}`,
    title: `Rebate agreement ${c.program.agreementRef} (amended)`,
    docLabel: "Signed agreement",
    reference: c.program.amendmentRef,
    issuer: ISSUER,
    meta: [
      { label: "Agreement", value: c.program.agreementRef },
      { label: "Amendment", value: c.program.amendmentRef },
      { label: "Amended on", value: c.program.amendmentDate },
      { label: "Period", value: `${c.program.periodStart} to ${c.program.periodEnd}` },
    ],
    columns: [
      { key: "tier", label: "Tier" },
      { key: "threshold", label: "Min net growth", align: "right" },
      { key: "rate", label: "Rate", align: "right" },
    ],
    rows: c.tierTable.map((t) => ({
      id: t.tierId,
      cells: {
        tier: t.label,
        threshold: t.minGrowthPct >= 999 ? "removed" : pct1(t.minGrowthPct),
        rate: pct1(t.ratePct),
      },
    })),
    totals: [
      { label: "Attained tier (contract basis)", value: pct1(a.attainedTier.ratePct), emphasis: true },
    ],
    footnote: c.program.amendmentNote,
    highlightRowIds: c.tierTable
      .filter((t) => t.ratePct === a.attainedTier.ratePct || t.minGrowthPct >= 999)
      .map((t) => t.tierId),
    highlightNote:
      "Amendment A2 removed the 3% tier and set the top rate at 2%. Net eligible growth attains Tier 2.",
    aiSummary: `The signed agreement, amended by ${c.program.amendmentRef} on ${c.program.amendmentDate}, caps the rebate at 2% and excludes the Professional wiper range. Net eligible growth of ${pct1(a.netGrowthPct)} attains Tier 2 at ${pct1(a.attainedTier.ratePct)} — not the 3% the retailer billed.`,
  };
}

/* ------------------------------------------------------------------ *
 * Gross → net eligible sales build-up
 * ------------------------------------------------------------------ */

export function buildBasisDoc(caseId: string): SourceDoc {
  const a = rebateClaimAssessment(caseId)!;
  const c = a.case;

  return {
    docId: `rebate-basis-${caseId}`,
    title: `Net eligible sales build-up — ${c.program.programId}`,
    docLabel: "Sales basis",
    reference: c.program.programId,
    issuer: ISSUER,
    meta: [
      { label: "Gross (claimed)", value: usd(c.retailerClaim.grossSales) },
      { label: "Net eligible", value: usd(a.netEligibleSales) },
      { label: "Baseline", value: usd(c.program.baselineNetSales) },
      { label: "Net growth", value: pct1(a.netGrowthPct) },
    ],
    columns: [
      { key: "label", label: "Line" },
      { key: "amount", label: "Amount", align: "right" },
    ],
    rows: c.basisBuildUp.map((l) => ({
      id: l.lineId,
      cells: {
        label: l.label,
        amount: `${l.isDeduction ? "−" : ""}${usd(l.amount)}`,
      },
    })),
    totals: [
      { label: "Net eligible sales", value: usd(a.netEligibleSales), emphasis: true },
    ],
    noteList: c.basisBuildUp.map((l) => ({ label: l.label, detail: l.note })),
    highlightRowIds: c.basisBuildUp.filter((l) => l.isDeduction).map((l) => l.lineId),
    highlightNote:
      "Every deduction is a contract requirement the gross claim ignored: non-contracted entities, excluded SKUs, returns, credits, freight and tax.",
    aiSummary: `Starting from ${usd(c.retailerClaim.grossSales)} gross, the contract strips out non-contracted entities, excluded wipers, returns, credits, freight and tax — leaving ${usd(a.netEligibleSales)} of net eligible sales, ${pct1(a.netGrowthPct)} above baseline.`,
  };
}

/* ------------------------------------------------------------------ *
 * A single buying entity, as its own eligibility record — each entity
 * is checked against the agreement's Schedule A independently, so each
 * gets its own 1:1 file rather than a shared summary.
 * ------------------------------------------------------------------ */

export function buildEntityDoc(caseId: string, entityId: string): SourceDoc {
  const c = findRebateClaimCase(caseId)!;
  const e = c.entities.find((x) => x.entityId === entityId) ?? c.entities[0];

  return {
    docId: `rebate-entity-${caseId}-${e.entityId}`,
    title: `Buying entity — ${e.name}`,
    docLabel: "Entity eligibility record",
    reference: c.program.agreementRef,
    issuer: ISSUER,
    meta: [
      { label: "Entity", value: e.name },
      { label: "Relationship", value: e.relationship },
      { label: "Eligible", value: e.eligible ? "Yes — Schedule A" : "No" },
      { label: "Net eligible sales", value: usd(e.netEligibleSales) },
    ],
    columns: [
      { key: "item", label: "Item" },
      { key: "value", label: "", align: "left" },
    ],
    rows: [
      { id: "relationship", cells: { item: "Relationship to signatory", value: e.relationship } },
      { id: "sales", cells: { item: "Net eligible sales", value: usd(e.netEligibleSales) } },
      { id: "note", cells: { item: "Eligibility finding", value: e.note } },
    ],
    totals: [{ label: "Net eligible sales", value: usd(e.netEligibleSales), emphasis: true }],
    footnote: `Checked against ${c.program.agreementRef}, Schedule A (contracted buying entities).`,
    highlightRowIds: ["note"],
    highlightNote: e.note,
    aiSummary: e.eligible
      ? `${e.name} is named in Schedule A as a contracted buying entity. Its ${usd(e.netEligibleSales)} of net eligible sales counts toward the rebate base.`
      : `${e.name} is ${e.relationship.toLowerCase()} — not a contracted buying entity under ${c.program.agreementRef}. Its ${usd(e.netEligibleSales)} of sales is excluded from the rebate base.`,
  };
}

/* ------------------------------------------------------------------ *
 * A single product group, as its own eligibility record
 * ------------------------------------------------------------------ */

export function buildProductGroupDoc(caseId: string, groupId: string): SourceDoc {
  const c = findRebateClaimCase(caseId)!;
  const p = c.productGroups.find((x) => x.groupId === groupId) ?? c.productGroups[0];

  return {
    docId: `rebate-product-${caseId}-${p.groupId}`,
    title: `Product group — ${p.label}`,
    docLabel: "Product eligibility record",
    reference: c.program.amendmentRef,
    issuer: ISSUER,
    meta: [
      { label: "Product group", value: p.label },
      { label: "Eligible", value: p.eligible ? "Yes" : "No — excluded" },
      { label: "Net eligible sales", value: usd(p.netEligibleSales) },
      { label: "Agreement", value: c.program.agreementRef },
    ],
    columns: [
      { key: "item", label: "Item" },
      { key: "value", label: "", align: "left" },
    ],
    rows: [
      { id: "sales", cells: { item: "Net eligible sales", value: usd(p.netEligibleSales) } },
      { id: "note", cells: { item: "Eligibility finding", value: p.note } },
    ],
    totals: [{ label: "Net eligible sales", value: usd(p.netEligibleSales), emphasis: true }],
    footnote: `Checked against ${c.program.agreementRef} as amended by ${c.program.amendmentRef}.`,
    highlightRowIds: ["note"],
    highlightNote: p.note,
    aiSummary: p.eligible
      ? `${p.label} is an eligible range under the agreement. Its ${usd(p.netEligibleSales)} of net eligible sales counts toward the rebate base.`
      : `${p.label} is excluded — ${p.note} Its ${usd(p.netEligibleSales)} of sales does not count toward the rebate base.`,
  };
}

/* ------------------------------------------------------------------ *
 * The variance breakdown, driver by driver
 * ------------------------------------------------------------------ */

export function buildVarianceDoc(caseId: string): SourceDoc {
  const a = rebateClaimAssessment(caseId)!;
  const c = a.case;

  return {
    docId: `rebate-variance-${caseId}`,
    title: `Rebate variance — ${caseId}`,
    docLabel: "Variance breakdown",
    reference: c.claimRef,
    issuer: ISSUER,
    meta: [
      { label: "Claimed", value: usd(a.claimed) },
      { label: "Validated", value: usd(a.validated) },
      { label: "Unsupported", value: usd(a.unsupported) },
      { label: "Tier", value: `${pct1(a.claimedTierPct)} → ${pct1(a.attainedTier.ratePct)}` },
    ],
    columns: [
      { key: "driver", label: "Variance driver" },
      { key: "amount", label: "Amount", align: "right" },
    ],
    rows: c.varianceDrivers.map((d) => ({
      id: d.driverId,
      cells: { driver: d.label, amount: usd(d.amount) },
    })),
    totals: [
      { label: "Validated rebate", value: usd(a.validated) },
      { label: "Unsupported", value: usd(a.unsupported), emphasis: true },
    ],
    noteList: c.varianceDrivers.map((d) => ({ label: d.label, detail: d.detail })),
    highlightRowIds: c.varianceDrivers.map((d) => d.driverId),
    highlightNote:
      "The four drivers close the whole gap between the $500,000 claimed and the $335,000 validated.",
    aiSummary: `Of ${usd(a.claimed)} claimed, ${usd(a.unsupported)} is unsupported across four drivers — gross-to-net, non-contracted entities, excluded products and the 3%→2% rate. The validated rebate is ${usd(a.validated)}.`,
  };
}

/* ------------------------------------------------------------------ *
 * The retailer response letter, as a document
 * ------------------------------------------------------------------ */

export function buildRebateLetterDoc(caseId: string, sent: boolean): SourceDoc {
  const a = rebateClaimAssessment(caseId)!;
  const c = a.case;
  const letter = renderRebateClaimLetter(caseId)!;

  return {
    docId: `rebate-letter-${caseId}`,
    title: `Retailer response ${c.responseLetter.letterRef}`,
    docLabel: "Deduction response letter",
    reference: c.responseLetter.letterRef,
    issuer: ISSUER,
    meta: [
      { label: "To", value: c.responseLetter.to },
      { label: "From", value: c.responseLetter.from },
      { label: "Status", value: sent ? "Issued" : "Draft — not yet sent" },
      { label: "Validated", value: usd(a.validated) },
    ],
    columns: [
      { key: "item", label: "Correspondence" },
      { key: "value", label: "", align: "left" },
    ],
    rows: [
      { id: "subject", cells: { item: "Subject", value: letter.subject } },
      { id: "body", cells: { item: "Body", value: letter.body } },
    ],
    highlightRowIds: ["body"],
    highlightNote: sent
      ? "Issued to the retailer with the calculation, eligibility and amended rate table attached."
      : "Drafted from the recalculation. A person approves it before it is sent.",
    aiSummary: `The response approves ${usd(a.validated)} on the contract basis and declines the remaining ${usd(a.unsupported)}, explaining each of the four variance drivers, with the calculation and the amended agreement attached.`,
  };
}
