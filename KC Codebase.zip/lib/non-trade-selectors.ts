/**
 * Tie-outs for NT-2026-W44 (PRD §12.3). Every row sums to its category, every
 * column sums to its outcome, and the grand total is 312 claims / $486,400.
 * A broken figure throws at import, so a bad edit cannot reach the demo.
 */

import {
  NON_TRADE_BATCH,
  SPLIT_OUT_CLAIMS,
  type CountValue,
  type NonTradeCategory,
  type NonTradeOutcome,
} from "./data/non-trade-batch";

const OUTCOMES: NonTradeOutcome[] = ["valid", "invalid", "exception"];

function add(a: CountValue, b: CountValue): CountValue {
  return { count: a.count + b.count, usd: a.usd + b.usd };
}
const ZERO: CountValue = { count: 0, usd: 0 };

function assert(cond: boolean, msg: string) {
  if (!cond) throw new Error(`[non-trade tie-out] ${msg}`);
}

const b = NON_TRADE_BATCH;

for (const row of b.categories) {
  const sum = OUTCOMES.reduce((s, o) => add(s, row[o]), ZERO);
  assert(sum.count === row.total.count && sum.usd === row.total.usd, `${row.key} row`);
  const splits = SPLIT_OUT_CLAIMS.filter((c) => c.category === row.key);
  assert(splits.length === row.exception.count, `${row.key} split-out count`);
  assert(splits.reduce((s, c) => s + c.usd, 0) === row.exception.usd, `${row.key} split-out value`);
}

export const batchTotals = {
  total: b.categories.reduce((s, r) => add(s, r.total), ZERO),
  valid: b.categories.reduce((s, r) => add(s, r.valid), ZERO),
  invalid: b.categories.reduce((s, r) => add(s, r.invalid), ZERO),
  exception: b.categories.reduce((s, r) => add(s, r.exception), ZERO),
};

assert(batchTotals.total.count === 312 && batchTotals.total.usd === 486_400, "grand total");
assert(
  batchTotals.valid.count + batchTotals.invalid.count + batchTotals.exception.count === 312,
  "outcome counts"
);
assert(
  batchTotals.valid.usd + batchTotals.invalid.usd + batchTotals.exception.usd === 486_400,
  "outcome values"
);
assert(
  b.sources.reduce((s, x) => s + x.claims, 0) === 312 &&
    b.sources.reduce((s, x) => s + x.usd, 0) === 486_400,
  "sources"
);
const shortage = b.categories.find((c) => c.key === "shortage")!;
assert(
  shortage.valid.count === b.signal.validShortages && shortage.valid.usd === b.signal.usd,
  "supply-chain signal"
);

export const closedByPolicy = batchTotals.valid.count + batchTotals.invalid.count;

export function categoryLabel(key: NonTradeCategory): string {
  return b.categories.find((c) => c.key === key)?.label ?? key;
}

export function splitOutClaim(id: string) {
  return SPLIT_OUT_CLAIMS.find((c) => c.id === id);
}

/** Compliance exceptions for the co-signing account fold into its open escalation. */
export const mergedComplianceUsd = SPLIT_OUT_CLAIMS.filter(
  (c) => c.category === "compliance" && c.accountId === b.coSignAccountId
).reduce((s, c) => s + c.usd, 0);
