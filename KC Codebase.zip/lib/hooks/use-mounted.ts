"use client";

import { useEffect, useState } from "react";

/** Flips to true shortly after mount so CSS transitions can play from their start state. */
export function useMounted(delayMs = 60) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    const id = setTimeout(() => setMounted(true), delayMs);
    return () => clearTimeout(id);
  }, [delayMs]);
  return mounted;
}
