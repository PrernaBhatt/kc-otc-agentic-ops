"use client";

import { useEffect, useState } from "react";

/** Per-character interval for every AI-drafted email, matched to the deduction dispute letter. */
export const EMAIL_DRAFT_MS = 4;

/**
 * One-shot character-by-character reveal. Gated: once the full text has been
 * revealed it never restarts for the same hook instance — key the consuming
 * component by document id to retype for a different document.
 */
export function useTypewriter(text: string, speed = 18) {
  const [count, setCount] = useState(0);
  const done = count >= text.length;

  useEffect(() => {
    if (done) return;
    const id = setInterval(
      () => setCount((c) => Math.min(c + 1, text.length)),
      speed
    );
    return () => clearInterval(id);
  }, [text, done, speed]);

  return { visible: text.slice(0, count), done };
}
