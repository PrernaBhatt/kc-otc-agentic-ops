/**
 * Source-of-truth document builders. Every preview modal in the app renders a
 * document built here, from the SAME data/store the screens read — so a
 * document can never disagree with the screen that opened it.
 */
import type { SourceDoc } from "@/components/modals/source-doc-preview";
import { TODAY, daysPastDue } from "@/lib/data/clock";
import type { DeductionCase } from "@/lib/data/deductions";
import type { InboundPo } from "@/lib/data/pipeline-orders";
import type { BankReceipt } from "@/lib/data/receipts";
import type { RecallNotice } from "@/lib/data/regulatory";
import type { RevRecContract, RevRecObligation } from "@/lib/data/revrec";
import type { Shipment } from "@/lib/data/shipments";
import type { Invoice, Order } from "@/lib/data/types";
import {
  bucketSummaries,
  formatMoney,
  provisionSummary,
  agingRows,
} from "@/lib/selectors";
import { specificReserves } from "@/lib/data/provisions";

const ISSUER = "Order to Cash Workspace";

export function buildInboundPoDoc(
  po: InboundPo,
  mode: "extraction" | "regulatory"
): SourceDoc {
  const total = po.lines.reduce((s, l) => s + l.lineValue, 0);
  const regulatoryLine = po.lines.find((l) => l.lot === "LOT-88412");
  return {
    docId: `${po.poNumber}-${mode}`,
    title: `Purchase Order ${po.poNumber}`,
    docLabel: "Purchase Order",
    reference: po.poNumber,
    issuer: po.customerName,
    meta: [
      { label: "Received via", value: po.channel },
      { label: "Received at", value: po.receivedAt },
      { label: "Payment terms", value: po.paymentTerms },
      { label: "Requested delivery", value: po.requestedDelivery },
    ],
    columns: [
      { key: "product", label: "Product" },
      { key: "qty", label: "Quantity", align: "right" },
      { key: "price", label: "Unit price", align: "right" },
      { key: "value", label: "Line total", align: "right" },
    ],
    rows: po.lines.map((l) => ({
      id: l.lineId,
      cells: {
        product: `${l.productName}${l.lot ? ` — lot ${l.lot}` : ""}`,
        qty: l.qty.toLocaleString(),
        price: formatMoney(l.unitPrice),
        value: formatMoney(l.lineValue),
      },
    })),
    totals: [
      { label: "Purchase order total", value: formatMoney(total), emphasis: true },
    ],
    highlightRowIds:
      mode === "regulatory" && regulatoryLine
        ? [regulatoryLine.lineId]
        : po.lines.map((l) => l.lineId),
    highlightNote:
      mode === "regulatory"
        ? "The highlighted line is allocated to a lot that is under quality hold."
        : "Highlighted lines are the ones the AI read and matched against the catalog and contract.",
    aiSummary:
      mode === "regulatory"
        ? `This purchase order from ${po.customerName} totals ${formatMoney(total)} across ${po.lines.length} lines. The incontinence briefs line references lot LOT-88412, which is under a quality hold, so the order cannot ship as entered. Recommended path: switch the line to cleared lot LOT-88907 and release, or hold the full order until the quality review closes.`
        : `I read this ${formatMoney(total)} purchase order from ${po.customerName} received through the ${po.channel.toLowerCase()}. The customer, both products, quantities, and contract prices all matched our records, so the order was created automatically and moved into the pipeline.`,
  };
}

export function buildSalesOrderDoc(order: Order): SourceDoc {
  return {
    docId: `so-${order.orderId}`,
    title: `Sales Order ${order.orderId}`,
    docLabel: "Sales Order Confirmation",
    reference: order.orderId,
    issuer: ISSUER,
    meta: [
      { label: "Customer", value: order.customerName },
      { label: "Order date", value: order.orderDate },
      { label: "Status", value: order.status },
      { label: "Hold reason", value: order.holdReason ?? "None" },
    ],
    columns: [
      { key: "product", label: "Product" },
      { key: "qty", label: "Quantity", align: "right" },
      { key: "price", label: "Unit price", align: "right" },
      { key: "value", label: "Line total", align: "right" },
    ],
    rows: order.lineItems.map((l) => ({
      id: l.orderLineId,
      cells: {
        product: l.productName,
        qty: l.qty.toLocaleString(),
        price: formatMoney(l.unitPrice),
        value: formatMoney(l.lineValue),
      },
    })),
    totals: [
      {
        label: "Order total",
        value: formatMoney(order.totalValue),
        emphasis: true,
      },
    ],
    highlightRowIds: [],
    aiSummary: `Sales order ${order.orderId} for ${order.customerName} totals ${formatMoney(order.totalValue)} across ${order.lineItems.length} lines and is currently in "${order.status}" status.${order.holdReason ? ` It is held for a ${order.holdReason.toLowerCase()} reason and needs a human decision before it can move on.` : ""}`,
  };
}

export function buildBankStatementDoc(
  receipts: BankReceipt[],
  highlightReceiptId?: string
): SourceDoc {
  const total = receipts.reduce((s, r) => s + r.amount, 0);
  const unapplied = receipts.filter((r) => r.status !== "Applied");
  return {
    docId: `bank-statement-${highlightReceiptId ?? "all"}`,
    title: "Bank Statement — August 20, 2026",
    docLabel: "Bank Statement",
    reference: "Account ****4417",
    issuer: "First Meridian Bank",
    meta: [
      { label: "Statement date", value: TODAY },
      { label: "Payments received", value: String(receipts.length) },
      { label: "Total received", value: formatMoney(total) },
      {
        label: "Still to apply",
        value: formatMoney(unapplied.reduce((s, r) => s + r.amount, 0)),
      },
    ],
    columns: [
      { key: "date", label: "Date" },
      { key: "payer", label: "Payer" },
      { key: "ref", label: "Reference" },
      { key: "amount", label: "Amount", align: "right" },
      { key: "status", label: "Status" },
    ],
    rows: receipts.map((r) => ({
      id: r.receiptId,
      cells: {
        date: r.receivedDate,
        payer: r.payerName,
        ref: r.remittanceReference ?? "— none —",
        amount: formatMoney(r.amount),
        status: r.status,
      },
    })),
    totals: [
      { label: "Total received", value: formatMoney(total), emphasis: true },
    ],
    highlightRowIds: highlightReceiptId
      ? [highlightReceiptId]
      : unapplied.map((r) => r.receiptId),
    highlightNote: highlightReceiptId
      ? "The highlighted payment is the one this matching decision is about."
      : "Highlighted payments still need to be applied to an invoice.",
    aiSummary: `The bank file for ${TODAY} contains ${receipts.length} incoming payments totaling ${formatMoney(total)}. ${unapplied.length} of them still need to be applied. One payment is short of its invoice by $3,000 with a damage claim noted, and one arrived without any invoice reference — both are routed to the exception queue with a suggested next step.`,
  };
}

export function buildRemittanceDoc(receipt: BankReceipt): SourceDoc {
  return {
    docId: `remit-${receipt.receiptId}`,
    title: `Remittance Advice — ${receipt.payerName}`,
    docLabel: "Remittance Advice",
    reference: receipt.receiptId,
    issuer: receipt.payerName,
    meta: [
      { label: "Payment date", value: receipt.receivedDate },
      { label: "Amount paid", value: formatMoney(receipt.amount) },
      {
        label: "Invoice referenced",
        value: receipt.remittanceReference ?? "None given",
      },
      { label: "Match confidence", value: `${Math.round((receipt.matchConfidence ?? 0) * 100)}%` },
    ],
    columns: [
      { key: "field", label: "Detail" },
      { key: "value", label: "Value" },
    ],
    rows: [
      {
        id: "note",
        cells: {
          field: "Customer note",
          value: receipt.remittanceNote ?? "—",
        },
      },
      {
        id: "match",
        cells: {
          field: "Proposed match",
          value: receipt.proposedInvoiceId
            ? `${receipt.proposedInvoiceId} (${receipt.matchType})`
            : "No match yet",
        },
      },
      ...(receipt.shortPayAmount
        ? [
            {
              id: "short",
              cells: {
                field: "Short-paid amount",
                value: formatMoney(receipt.shortPayAmount),
              },
            },
          ]
        : []),
    ],
    highlightRowIds: receipt.shortPayAmount ? ["short"] : ["match"],
    highlightNote: receipt.shortPayAmount
      ? "The short-paid amount becomes a deduction case for investigation."
      : "This is the match the AI proposes for your approval.",
    aiSummary: receipt.shortPayAmount
      ? `${receipt.payerName} paid ${formatMoney(receipt.amount)} against invoice ${receipt.proposedInvoiceId}, which is ${formatMoney(receipt.shortPayAmount)} short. The customer's note mentions a damage claim, so applying this payment will open a deduction case with the claim attached for investigation.`
      : `${receipt.payerName} paid ${formatMoney(receipt.amount)}${receipt.proposedInvoiceId ? ` and the details line up with invoice ${receipt.proposedInvoiceId} (${(receipt.matchType || "").toLowerCase()})` : " without an invoice reference"}. ${receipt.proposedInvoiceId ? "One click applies it and clears the invoice." : "I suggest confirming the payer's account before applying it anywhere."}`,
  };
}

export function buildInvoiceDoc(
  invoice: Invoice,
  opts?: { highlight?: boolean; note?: string }
): SourceDoc {
  const late = daysPastDue(invoice.dueDate);
  return {
    docId: `inv-${invoice.invoiceId}`,
    title: `Invoice ${invoice.invoiceId}`,
    docLabel: "Customer Invoice",
    reference: invoice.invoiceId,
    issuer: ISSUER,
    meta: [
      { label: "Customer", value: invoice.customerName },
      { label: "Invoice date", value: invoice.invoiceDate },
      { label: "Due date", value: invoice.dueDate },
      { label: "Status", value: invoice.status },
    ],
    columns: [
      { key: "field", label: "Detail" },
      { key: "value", label: "Value", align: "right" },
    ],
    rows: [
      {
        id: "amount",
        cells: { field: "Invoice amount", value: formatMoney(invoice.amount) },
      },
      {
        id: "order",
        cells: { field: "Related sales order", value: invoice.orderId },
      },
      {
        id: "aging",
        cells: {
          field: "Days past due",
          value: late > 0 ? `${late} days late` : "Not yet due",
        },
      },
    ],
    highlightRowIds: opts?.highlight === false ? [] : late > 0 ? ["aging"] : ["amount"],
    highlightNote: opts?.note,
    aiSummary: `Invoice ${invoice.invoiceId} bills ${invoice.customerName} ${formatMoney(invoice.amount)}, due ${invoice.dueDate}. ${late > 0 ? `It is ${late} days past due and is being worked in collections.` : `It is not yet due.`}`,
  };
}

const DESTINATIONS: Record<string, { dock: string; lines: string[] }> = {
  "Costco Wholesale Corp.": {
    dock: "Costco Depot #C-114",
    lines: ["Costco Depot #C-114", "14001 Valley Blvd", "City of Industry, CA 91746", "United States"],
  },
  "Walmart Inc.": {
    dock: "Walmart DC #6094",
    lines: ["Walmart Distribution Center #6094", "3801 E Kiehl Ave", "Sherwood, AR 72120", "United States"],
  },
  "Tesco PLC": {
    dock: "Tesco DC Daventry",
    lines: ["Tesco Distribution Centre", "Royal Oak Way South", "Daventry NN11 8NU", "United Kingdom"],
  },
  "Woolworths Group": {
    dock: "Woolworths DC Moorebank",
    lines: ["Woolworths Regional DC", "1 Moorebank Ave", "Moorebank NSW 2170", "Australia"],
  },
};

function destinationFor(customerName: string) {
  return (
    DESTINATIONS[customerName] ?? {
      dock: `${customerName} DC`,
      lines: [`${customerName} — Receiving Dock`, "United States"],
    }
  );
}

/** "R. Alvarez, Receiving Supervisor" -> name + title; a bare title gets a stand-in name. */
function splitSigner(signedBy: string) {
  const [name, ...rest] = signedBy.split(",").map((s) => s.trim());
  if (rest.length === 0) return { name: "D. Moreno", title: name };
  return { name, title: rest.join(", ") };
}

export function buildPodDoc(shipment: Shipment): SourceDoc {
  const delivered = shipment.status === "Delivered";
  const dest = destinationFor(shipment.customerName);
  const signer = shipment.podSignedBy ? splitSigner(shipment.podSignedBy) : undefined;
  const deliveryNo = `DN-${shipment.shipmentId.replace("SHP-", "")}`;
  const signedAt = shipment.milestones[shipment.milestones.length - 1];

  return {
    docId: `pod-${shipment.shipmentId}`,
    title: `Delivery ${deliveryNo}`,
    docLabel: "Proof of delivery",
    reference: deliveryNo,
    issuer: "SAP Logistics Execution — Proof of Delivery",
    skin: "pod-letter",
    docDate: shipment.deliveredDate,
    meta: [
      { label: "Delivery number", value: deliveryNo },
      { label: "Sales order", value: shipment.orderId },
      { label: "Carrier", value: shipment.carrier },
      { label: "Shipment", value: shipment.shipmentId },
      { label: "Promised date", value: shipment.promisedDate },
      { label: "Delivered", value: shipment.deliveredDate ?? "Not yet delivered" },
      { label: "Recipient name", value: `Receiving — ${dest.dock}` },
      {
        label: "Status",
        value: delivered
          ? "Delivered complete, no discrepancy"
          : shipment.status === "Delayed"
            ? `Delayed ${shipment.delayDays ?? ""} days — ${shipment.delayReason ?? "in transit"}`
            : shipment.status,
      },
    ],
    columns: [
      { key: "item", label: "Check" },
      { key: "value", label: "Result", align: "right" },
    ],
    rows: [
      { id: "qty", cells: { item: "Quantity shipped vs. ordered", value: delivered ? "Match" : "Pending receipt" } },
      { id: "damage", cells: { item: "Damage / shortage claims", value: delivered ? "None" : "—" } },
      { id: "temp", cells: { item: "Temperature / seal integrity", value: delivered ? "Within tolerance" : "—" } },
      { id: "pod", cells: { item: "Signed proof of delivery on file", value: delivered ? "Yes" : "No" } },
    ],
    partyBlocks: [{ heading: "Destination delivery address", lines: dest.lines }],
    signature: [
      { label: "Signature of recipient", value: signer?.name },
      { label: "Printed name / title", value: signer ? `${signer.name} — ${signer.title}` : undefined },
      { label: "Date received", value: shipment.deliveredDate },
    ],
    stamp:
      delivered && shipment.deliveredDate
        ? {
            title: "Received",
            date: shipment.deliveredDate,
            lines: [dest.dock, signedAt?.timestamp.split(" ")[1] ? `Time ${signedAt.timestamp.split(" ")[1]}` : "Goods in", "In good order"],
          }
        : undefined,
    footnote: delivered
      ? "The signed delivery confirmation is what allows billing to proceed."
      : "Not yet delivered — the signature block is filled in by the receiving dock on arrival.",
    highlightRowIds: [],
    aiSummary:
      shipment.status === "Delivered"
        ? `Shipment ${shipment.shipmentId} for order ${shipment.orderId} was delivered on ${shipment.deliveredDate} and signed for by ${shipment.podSignedBy}. With delivery confirmed, the order is cleared for invoicing.`
        : shipment.status === "Delayed"
          ? `Shipment ${shipment.shipmentId} is running ${shipment.delayDays} days late (${shipment.delayReason?.toLowerCase()}). The revised delivery promise is being tracked hourly and the customer has been notified.`
          : `Shipment ${shipment.shipmentId} is planned with ${shipment.carrier}, promised for ${shipment.promisedDate}. Stock is allocated and the carrier is booked.`,
  };
}

export function buildRecallNoticeDoc(notice: RecallNotice): SourceDoc {
  return {
    docId: `recall-${notice.id}`,
    title: `Quality Hold Notice ${notice.id}`,
    docLabel: "Quality Hold Notice",
    reference: notice.id,
    issuer: "Quality Assurance",
    meta: [
      { label: "Issued", value: notice.issuedDate },
      { label: "Status", value: notice.status },
      { label: "Product", value: "Adult Incontinence Briefs - Heavy" },
      { label: "Lot", value: notice.lot },
    ],
    columns: [
      { key: "field", label: "Detail" },
      { key: "value", label: "Value" },
    ],
    rows: [
      { id: "lot", cells: { field: "Affected lot", value: notice.lot } },
      { id: "reason", cells: { field: "Reason", value: notice.reason } },
      {
        id: "action",
        cells: {
          field: "Required action",
          value:
            "Do not ship this lot. Orders referencing it must be substituted or held.",
        },
      },
    ],
    highlightRowIds: ["lot", "action"],
    highlightNote:
      "Any order line allocated to this lot is stopped at the Regulatory Check stage.",
    aiSummary: `Quality Assurance placed lot ${notice.lot} of Adult Incontinence Briefs - Heavy on hold on ${notice.issuedDate} because of a supplier packaging defect under investigation. One open order references this lot and is waiting for a human decision: substitute the cleared lot or hold the order.`,
  };
}

export function buildAgingReportDoc(allInvoices: Invoice[]): SourceDoc {
  const rows = agingRows(allInvoices).sort((a, b) => b.daysLate - a.daysLate);
  const total = rows.reduce((s, r) => s + r.invoice.amount, 0);
  return {
    docId: "aging-report",
    title: "Receivables Aging Report",
    docLabel: "Receivables Aging Report",
    reference: `As of ${TODAY}`,
    issuer: ISSUER,
    meta: [
      { label: "Open invoices", value: String(rows.length) },
      { label: "Open balance", value: formatMoney(total) },
      {
        label: "Past due",
        value: formatMoney(
          rows.filter((r) => r.daysLate > 0).reduce((s, r) => s + r.invoice.amount, 0)
        ),
      },
      { label: "Report date", value: TODAY },
    ],
    columns: [
      { key: "invoice", label: "Invoice" },
      { key: "customer", label: "Customer" },
      { key: "due", label: "Due date" },
      { key: "late", label: "Days late", align: "right" },
      { key: "amount", label: "Amount", align: "right" },
    ],
    rows: rows.map((r) => ({
      id: r.invoice.invoiceId,
      cells: {
        invoice: r.invoice.invoiceId,
        customer: r.invoice.customerName,
        due: r.invoice.dueDate,
        late: r.daysLate > 0 ? String(r.daysLate) : "—",
        amount: formatMoney(r.invoice.amount),
      },
    })),
    totals: [{ label: "Total open receivables", value: formatMoney(total), emphasis: true }],
    highlightRowIds: rows.filter((r) => r.daysLate > 60).map((r) => r.invoice.invoiceId),
    highlightNote: "Highlighted invoices are more than 60 days late and drive most of the reserve.",
    aiSummary: `Open receivables stand at ${formatMoney(total)} across ${rows.length} invoices. ${rows.filter((r) => r.daysLate > 0).length} are past due, and the two oldest balances are the main drivers of the bad-debt reserve. Paying or resolving any invoice updates this report, the provision, and the collections worklist together.`,
  };
}

export function buildProvisionDoc(allInvoices: Invoice[]): SourceDoc {
  const buckets = bucketSummaries(allInvoices);
  const summary = provisionSummary(allInvoices);
  return {
    docId: "provision-calc",
    title: "Bad Debt Provision Calculation",
    docLabel: "Provision Calculation Sheet",
    reference: `Period ending August 2026`,
    issuer: "Finance — Credit Risk",
    meta: [
      { label: "Required reserve", value: formatMoney(summary.requiredAllowance) },
      { label: "Reserve on books", value: formatMoney(summary.existingAllowance) },
      { label: "Adjustment needed", value: formatMoney(summary.topUp) },
      { label: "Approver", value: "Controller" },
    ],
    columns: [
      { key: "bucket", label: "Age group" },
      { key: "balance", label: "Balance", align: "right" },
      { key: "rate", label: "Loss rate", align: "right" },
      { key: "reserve", label: "Reserve", align: "right" },
    ],
    rows: [
      ...buckets.map((b) => ({
        id: b.bucket,
        cells: {
          bucket: b.bucket,
          balance: formatMoney(b.balance),
          rate: `${Math.round(b.lossRate * 100)}%`,
          reserve: formatMoney(b.rateReserve),
        },
      })),
      ...specificReserves.map((s) => ({
        id: `specific-${s.invoiceId}`,
        cells: {
          bucket: `Specific reserve — ${s.invoiceId} (${s.customerName})`,
          balance: formatMoney(s.amount),
          rate: "100%",
          reserve: formatMoney(s.amount),
        },
      })),
    ],
    totals: [
      { label: "Rate-based reserve", value: formatMoney(summary.rateReserveTotal) },
      { label: "Specific reserves", value: formatMoney(summary.specificReserveTotal) },
      { label: "Required reserve", value: formatMoney(summary.requiredAllowance), emphasis: true },
      { label: "Adjustment to record", value: formatMoney(summary.topUp), emphasis: true },
    ],
    highlightRowIds: [
      ...specificReserves.map((s) => `specific-${s.invoiceId}`),
      "Over 90 days late",
    ],
    highlightNote: "Highlighted lines are the biggest drivers of this month's reserve.",
    aiSummary: `The receivables book needs a reserve of ${formatMoney(summary.requiredAllowance)}: ${formatMoney(summary.rateReserveTotal)} from age-based loss rates plus ${formatMoney(summary.specificReserveTotal)} reserved in full for the disputed TechPro balance. With ${formatMoney(summary.existingAllowance)} already on the books, this month's adjustment is ${formatMoney(summary.topUp)}. It is ready for the Controller's approval, and the numbers move automatically as invoices get paid or resolved.`,
  };
}

export function buildContractDoc(contract: RevRecContract): SourceDoc {
  return {
    docId: `contract-${contract.contractId}`,
    title: `Contract Summary ${contract.contractId}`,
    docLabel: "Contract Summary",
    reference: contract.contractId,
    issuer: ISSUER,
    meta: [
      { label: "Customer", value: contract.customerName },
      { label: "Payment terms", value: contract.paymentTerms },
      { label: "Delivery terms", value: contract.deliveryTerms },
      { label: "Volume rebate", value: `${contract.rebatePercent}%` },
    ],
    columns: [
      { key: "field", label: "Term" },
      { key: "value", label: "Detail" },
    ],
    rows: [
      { id: "terms", cells: { field: "Ownership transfer", value: contract.deliveryTerms } },
      { id: "rebate", cells: { field: "Rebate", value: `${contract.rebatePercent}% of recognized sales, accrued monthly` } },
      { id: "notes", cells: { field: "Notes", value: contract.notes } },
    ],
    highlightRowIds: contract.rebatePercent > 0 ? ["rebate", "terms"] : ["terms"],
    highlightNote: "These terms decide when revenue is recognized and what is set aside.",
    aiSummary: `${contract.customerName}'s agreement recognizes revenue when goods are delivered${contract.rebatePercent > 0 ? ` and sets aside a ${contract.rebatePercent}% volume rebate on every recognized sale` : ""}. ${contract.notes}`,
  };
}

export function buildRevRecScheduleDoc(
  obligations: RevRecObligation[]
): SourceDoc {
  const recognized = obligations.filter((o) => o.status === "Recognized");
  const total = obligations.reduce((s, o) => s + o.allocatedAmount, 0);
  return {
    docId: "revrec-schedule",
    title: "Revenue Recognition Schedule — August 2026",
    docLabel: "Revenue Recognition Schedule",
    reference: "Period ending August 2026",
    issuer: "Finance — Revenue Accounting",
    meta: [
      { label: "Obligations tracked", value: String(obligations.length) },
      {
        label: "Recognized",
        value: formatMoney(recognized.reduce((s, o) => s + o.allocatedAmount, 0)),
      },
      {
        label: "Deferred",
        value: formatMoney(
          obligations
            .filter((o) => o.status === "Deferred")
            .reduce((s, o) => s + o.allocatedAmount, 0)
        ),
      },
      { label: "Total under contract", value: formatMoney(total) },
    ],
    columns: [
      { key: "obligation", label: "Obligation" },
      { key: "trigger", label: "Recognized when" },
      { key: "amount", label: "Amount", align: "right" },
      { key: "status", label: "Status" },
    ],
    rows: obligations.map((o) => ({
      id: o.id,
      cells: {
        obligation: `${o.orderId} — ${o.description}`,
        trigger: o.trigger,
        amount: formatMoney(o.allocatedAmount),
        status: o.status,
      },
    })),
    highlightRowIds: obligations
      .filter((o) => o.status === "Deferred")
      .map((o) => o.id),
    highlightNote:
      "Highlighted amounts stay deferred until their trigger happens — that is the cut-off check.",
    aiSummary: `Of ${formatMoney(total)} under contract this period, ${formatMoney(recognized.reduce((s, o) => s + o.allocatedAmount, 0))} is recognized (delivery confirmed) and the rest stays deferred. The undelivered $340,000 order is promised for Jan 24 — if delivery slips past month end, it must not be recognized this period. Delivery confirmations update this schedule automatically.`,
  };
}

export function buildStockLedgerDoc(
  positions: import("@/lib/data/inventory").StockPosition[],
  highlightSkus: string[],
  context?: { orderId?: string; recommendation?: string }
): SourceDoc {
  return {
    docId: `stock-ledger-${context?.orderId ?? "all"}`,
    title: "Stock & Allocation Ledger",
    docLabel: "Stock & Allocation Ledger",
    reference: `As of ${TODAY}`,
    issuer: "Supply Chain — Inventory Control",
    meta: [
      { label: "Products tracked", value: String(positions.length) },
      {
        label: "For order",
        value: context?.orderId ?? "Full catalog view",
      },
      { label: "Ledger date", value: TODAY },
      { label: "Source", value: "Warehouse system" },
    ],
    columns: [
      { key: "product", label: "Product" },
      { key: "available", label: "Available", align: "right" },
      { key: "reserved", label: "Reserved", align: "right" },
      { key: "allocation", label: "Monthly allocation used", align: "right" },
    ],
    rows: positions.map((p) => ({
      id: p.sku,
      cells: {
        product: p.productName,
        available: p.availableUnits.toLocaleString(),
        reserved: p.reservedUnits.toLocaleString(),
        allocation:
          p.allocationUsedUnits !== undefined
            ? `${p.allocationUsedUnits.toLocaleString()} used`
            : "Not allocation-controlled",
      },
    })),
    highlightRowIds: highlightSkus,
    highlightNote:
      "Highlighted products are the ones on the order being allocated.",
    aiSummary:
      context?.recommendation ??
      "Stock positions are current as of today. Highlighted lines show the products this order needs; available stock covers the requested quantities, so the allocation can be approved.",
  };
}

export function buildBillingReportDoc(
  rows: {
    orderId: string;
    customerName: string;
    deliveredDate: string;
    amount: number;
    invoiced: boolean;
  }[]
): SourceDoc {
  const awaiting = rows.filter((r) => !r.invoiced);
  return {
    docId: "eligible-billing-report",
    title: "Eligible Billing Report",
    docLabel: "Eligible Billing Report",
    reference: `As of ${TODAY}`,
    issuer: "Finance — Billing",
    meta: [
      { label: "Delivered orders", value: String(rows.length) },
      { label: "Pending invoice", value: String(awaiting.length) },
      {
        label: "Value pending invoice",
        value: formatMoney(awaiting.reduce((s, r) => s + r.amount, 0)),
      },
      { label: "Report date", value: TODAY },
    ],
    columns: [
      { key: "order", label: "Order" },
      { key: "customer", label: "Customer" },
      { key: "delivered", label: "Delivered" },
      { key: "amount", label: "Amount", align: "right" },
      { key: "status", label: "Invoice status" },
    ],
    rows: rows.map((r) => ({
      id: r.orderId,
      cells: {
        order: r.orderId,
        customer: r.customerName,
        delivered: r.deliveredDate,
        amount: formatMoney(r.amount),
        status: r.invoiced ? "Invoiced" : "Pending invoice",
      },
    })),
    highlightRowIds: awaiting.map((r) => r.orderId),
    highlightNote:
      "Highlighted orders are delivered but not yet invoiced — they are what the billing run picks up.",
    aiSummary: `${rows.length} orders have confirmed deliveries. ${awaiting.length} still need an invoice, worth ${formatMoney(awaiting.reduce((s, r) => s + r.amount, 0))} in unbilled revenue. Each one is queued in the billing pipeline with its delivery proof attached — approving the generated invoices clears this report and the month-end billing completeness check together.`,
  };
}

export function buildClaimDoc(deduction: DeductionCase): SourceDoc {
  return {
    docId: `claim-${deduction.deductionId}`,
    title: `${deduction.source} — ${deduction.deductionId}`,
    docLabel: deduction.source === "Short payment" ? "Customer Claim" : "Customer Debit Memo",
    reference: deduction.deductionId,
    issuer: deduction.customerName,
    meta: [
      { label: "Invoice", value: deduction.invoiceId },
      { label: "Amount", value: formatMoney(deduction.amount) },
      { label: "Likely reason", value: deduction.reasonCode },
      { label: "Routed to", value: deduction.routedTo },
    ],
    columns: [
      { key: "item", label: "Supporting document" },
      { key: "status", label: "Status" },
    ],
    rows: deduction.evidence.map((ev) => ({
      id: ev.id,
      cells: {
        item: ev.label,
        status: ev.available ? "On file" : "Requested — not yet received",
      },
    })),
    totals: [
      { label: "Amount in question", value: formatMoney(deduction.amount), emphasis: true },
    ],
    highlightRowIds: deduction.evidence.filter((ev) => !ev.available).map((ev) => ev.id),
    highlightNote: "Highlighted documents are still missing and block final resolution.",
    aiSummary: `${deduction.rootCauseFinding} ${deduction.aiRecommendation}`,
  };
}
