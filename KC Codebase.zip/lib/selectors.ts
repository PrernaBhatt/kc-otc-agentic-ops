import { daysPastDue } from "./data/clock";
import { customers } from "./data/customers";
import type { BankReceipt } from "./data/receipts";
import type { DeductionCase } from "./data/deductions";
import type { Invoice, Order } from "./data/types";
import type { PromiseToPay } from "./data/collections";
import { contraRevenueItems, type RevRecObligation } from "./data/revrec";
import {
  existingAllowanceBalance,
  lossRateBands,
  specificReserves,
  type LossRateBand,
} from "./data/provisions";
import {
  arRegions,
  businessUnits,
  defaultBusinessUnit,
  invoiceBusinessUnit,
} from "./data/segments";

/** Payment propensity per customer — the same numbers the dunning workbench shows. */
export const paymentPropensity: Record<string, number> = {
  "CUST-001": 0.75,
  "CUST-002": 0.85,
  "CUST-003": 0.64,
};

export interface AgingRow {
  invoice: Invoice;
  daysLate: number;
  bucket: LossRateBand["bucket"];
}

export function bucketFor(daysLate: number): LossRateBand["bucket"] {
  const band = lossRateBands.find(
    (b) => daysLate >= b.minDays && (b.maxDays === null || daysLate <= b.maxDays)
  );
  return band ? band.bucket : "Over 90 days late";
}

/** Open (unpaid) invoices with aging metadata. */
export function agingRows(allInvoices: Invoice[]): AgingRow[] {
  return allInvoices
    .filter((inv) => inv.status !== "Paid")
    .map((invoice) => {
      const daysLate = Math.max(0, daysPastDue(invoice.dueDate));
      return { invoice, daysLate, bucket: bucketFor(daysLate) };
    });
}

export function openReceivablesTotal(allInvoices: Invoice[]): number {
  return agingRows(allInvoices).reduce((sum, r) => sum + r.invoice.amount, 0);
}

export interface BucketSummary {
  bucket: LossRateBand["bucket"];
  lossRate: number;
  balance: number;
  rateReserve: number;
  invoiceIds: string[];
}

/** Aging buckets with rate-based reserves — the provision calculation sheet. */
export function bucketSummaries(allInvoices: Invoice[]): BucketSummary[] {
  const rows = agingRows(allInvoices);
  return lossRateBands.map((band) => {
    const inBucket = rows.filter((r) => r.bucket === band.bucket);
    const balance = inBucket.reduce((sum, r) => sum + r.invoice.amount, 0);
    const specificsInBucket = new Set(specificReserves.map((s) => s.invoiceId));
    const rateBase = inBucket
      .filter((r) => !specificsInBucket.has(r.invoice.invoiceId))
      .reduce((sum, r) => sum + r.invoice.amount, 0);
    return {
      bucket: band.bucket,
      lossRate: band.lossRate,
      balance,
      rateReserve: Math.round(rateBase * band.lossRate),
      invoiceIds: inBucket.map((r) => r.invoice.invoiceId),
    };
  });
}

export interface ProvisionSummary {
  rateReserveTotal: number;
  specificReserveTotal: number;
  requiredAllowance: number;
  existingAllowance: number;
  topUp: number;
}

export function provisionSummary(allInvoices: Invoice[]): ProvisionSummary {
  const openIds = new Set(
    agingRows(allInvoices).map((r) => r.invoice.invoiceId)
  );
  const rateReserveTotal = bucketSummaries(allInvoices).reduce(
    (sum, b) => sum + b.rateReserve,
    0
  );
  const specificReserveTotal = specificReserves
    .filter((s) => openIds.has(s.invoiceId))
    .reduce((sum, s) => sum + s.amount, 0);
  const requiredAllowance = rateReserveTotal + specificReserveTotal;
  return {
    rateReserveTotal,
    specificReserveTotal,
    requiredAllowance,
    existingAllowance: existingAllowanceBalance,
    topUp: requiredAllowance - existingAllowanceBalance,
  };
}

export interface ArDistribution {
  units: string[];
  regions: string[];
  /** matrix[unitIndex][regionIndex] = open balance for that cell. */
  matrix: number[][];
  unitTotals: number[];
  regionTotals: number[];
  maxCell: number;
  total: number;
}

/**
 * Open receivables cross-tabbed by business unit (rows) and geography
 * (columns). Derived from the same open-invoice set as the aging table, so the
 * grand total always equals open receivables and moves when an invoice is paid.
 */
export function arDistribution(allInvoices: Invoice[]): ArDistribution {
  const units: string[] = [...businessUnits];
  const regions: string[] = [...arRegions];
  const regionByCustomer: Record<string, string> = {};
  customers.forEach((c) => {
    regionByCustomer[c.customerId] = c.region;
  });

  const matrix = units.map(() => regions.map(() => 0));
  agingRows(allInvoices).forEach(({ invoice }) => {
    const unit = invoiceBusinessUnit[invoice.invoiceId] ?? defaultBusinessUnit;
    const region = regionByCustomer[invoice.customerId] ?? regions[0];
    const ui = units.indexOf(unit);
    const ri = regions.indexOf(region);
    if (ui >= 0 && ri >= 0) matrix[ui][ri] += invoice.amount;
  });

  const unitTotals = matrix.map((row) => row.reduce((s, v) => s + v, 0));
  const regionTotals = regions.map((_, ri) =>
    units.reduce((s, _u, ui) => s + matrix[ui][ri], 0)
  );
  const maxCell = Math.max(1, ...matrix.flat());
  const total = unitTotals.reduce((s, v) => s + v, 0);
  return { units, regions, matrix, unitTotals, regionTotals, maxCell, total };
}

/** Total cash received but not yet applied to an invoice. */
export function unappliedCashTotal(receipts: BankReceipt[]): number {
  return receipts
    .filter((r) => r.status !== "Applied")
    .reduce((sum, r) => sum + r.amount, 0);
}

export function openDeductions(cases: DeductionCase[]): DeductionCase[] {
  return cases.filter((d) => d.status !== "Resolved");
}

/** Expected cash in the next 30 days: open promises + propensity-weighted current invoices. */
export function cashForecast30d(
  allInvoices: Invoice[],
  ptps: PromiseToPay[]
): number {
  const promised = ptps
    .filter((p) => p.status === "Open")
    .reduce((sum, p) => sum + p.amount, 0);
  const promisedInvoiceIds = new Set(
    ptps.filter((p) => p.status === "Open").map((p) => p.invoiceId)
  );
  const currentExpected = agingRows(allInvoices)
    .filter(
      (r) => r.daysLate === 0 && !promisedInvoiceIds.has(r.invoice.invoiceId)
    )
    .reduce(
      (sum, r) =>
        sum +
        r.invoice.amount * (paymentPropensity[r.invoice.customerId] ?? 0.7),
      0
    );
  return Math.round(promised + currentExpected);
}

export interface WorklistEntry {
  invoice: Invoice;
  daysLate: number;
  bucket: LossRateBand["bucket"];
  riskScore: number;
  priority: number;
  flag?: string;
  nextAction: string;
}

/** Ranked collections worklist: value x lateness x customer risk. */
export function collectionsWorklist(
  allInvoices: Invoice[],
  ptps: PromiseToPay[],
  cases: DeductionCase[]
): WorklistEntry[] {
  const churn: Record<string, number> = {
    "CUST-001": 0.15,
    "CUST-002": 0.08,
    "CUST-003": 0.22,
  };
  return agingRows(allInvoices)
    .filter((r) => r.daysLate > 0)
    .map((r) => {
      const risk = churn[r.invoice.customerId] ?? 0.15;
      const ptp = ptps.find(
        (p) => p.invoiceId === r.invoice.invoiceId && p.status === "Open"
      );
      const deduction = cases.find(
        (d) => d.invoiceId === r.invoice.invoiceId && d.status !== "Resolved"
      );
      const resolvedDeduction = cases.find(
        (d) => d.invoiceId === r.invoice.invoiceId && d.status === "Resolved"
      );
      const disputed = specificReserves.some(
        (s) => s.invoiceId === r.invoice.invoiceId
      );
      let nextAction = "Send payment reminder";
      let flag: string | undefined;
      if (ptp) {
        nextAction = `Promise to pay captured for ${ptp.promisedDate} — follow up if missed`;
        flag = "Promise to pay";
      } else if (disputed) {
        nextAction = "Escalate to legal review — balance disputed";
        flag = "Disputed";
      } else if (deduction) {
        nextAction = `Resolve deduction case ${deduction.deductionId} first`;
        flag = "Deduction open";
      } else if (resolvedDeduction) {
        nextAction =
          "Send final settlement confirmation — deduction resolved, collection strategy updated";
        flag = "Deduction resolved";
      } else if (r.daysLate > 60) {
        nextAction = "Escalate to finance leadership";
      } else {
        nextAction = "Call customer and ask for a payment commitment";
      }
      return {
        invoice: r.invoice,
        daysLate: r.daysLate,
        bucket: r.bucket,
        riskScore: risk,
        priority: Math.round(
          (r.invoice.amount / 1000) * (1 + r.daysLate / 30) * (1 + risk)
        ),
        flag,
        nextAction,
      };
    })
    .sort((a, b) => b.priority - a.priority);
}

export interface ContraRevenueLine {
  key: string;
  label: string;
  rate: number;
  amount: number;
  note: string;
}

/**
 * Recognized revenue this period, the deferred balance, and the variable
 * consideration set aside — each contra item broken out and derived from
 * recognized revenue under the master agreement so it all co-moves.
 */
export function revRecSummary(obligations: RevRecObligation[]) {
  const recognized = obligations
    .filter((o) => o.status === "Recognized")
    .reduce((sum, o) => sum + o.allocatedAmount, 0);
  const deferred = obligations
    .filter((o) => o.status === "Deferred")
    .reduce((sum, o) => sum + o.allocatedAmount, 0);
  const recognizedUnderAgreement = obligations
    .filter((o) => o.status === "Recognized" && o.contractId === "CTR-HPB-2024")
    .reduce((sum, o) => sum + o.allocatedAmount, 0);

  const contra: ContraRevenueLine[] = contraRevenueItems.map((item) => ({
    key: item.key,
    label: item.label,
    rate: item.rate,
    amount: Math.round(recognizedUnderAgreement * item.rate),
    note: item.note,
  }));
  const contraTotal = contra.reduce((sum, c) => sum + c.amount, 0);
  const rebateAccrual = contra.find((c) => c.key === "rebate")?.amount ?? 0;
  const netRevenue = recognized - contraTotal;

  return {
    recognized,
    deferred,
    recognizedUnderAgreement,
    rebateAccrual,
    contra,
    contraTotal,
    netRevenue,
  };
}

/** Delivered orders that have no invoice yet (billing completeness check). */
export function shippedNotInvoiced(
  ordersList: Order[],
  allInvoices: Invoice[],
  billedOrderIds: Set<string>,
  deliveredOrderIds: Set<string>
): Order[] {
  const invoicedOrders = new Set(allInvoices.map((i) => i.orderId));
  return ordersList.filter(
    (o) =>
      deliveredOrderIds.has(o.orderId) &&
      !invoicedOrders.has(o.orderId) &&
      !billedOrderIds.has(o.orderId)
  );
}

export function formatMoney(value: number): string {
  return `$${value.toLocaleString("en-US")}`;
}

export function formatMoneyCompact(value: number): string {
  if (Math.abs(value) >= 1000000)
    return `$${(value / 1000000).toFixed(1)}M`;
  if (Math.abs(value) >= 1000) return `$${(value / 1000).toFixed(1)}K`;
  return `$${value.toLocaleString("en-US")}`;
}
