/**
 * The reconciliation behind Scenario 3 — growth rebate recalculation.
 *
 * Invariants the screen leans on, none of them stored as a conclusion:
 *   1. validated + Σ(variance drivers) === claimed
 *      If the drivers do not close the gap between the claim and the validated
 *      rebate, the recalculation is not defensible and must not claim to be.
 *   2. attained tier = highest tier whose minGrowthPct <= net eligible growth
 *      The 2% on the screen is derived by testing the recomputed growth against
 *      the amended tier table, so it can never drift from the evidence.
 *   3. net eligible sales = gross - Σ(contract deductions)
 *      The build-up is summed from its own lines.
 */

import {
  findRebateClaimCase,
  type RebateClaimCase,
  type RebateVarianceDriver,
  type RebateTier,
} from "./data/rebate-claims";
import type { ClaimEdit } from "./claim-edit";

export interface RebateClaimAssessment {
  case: RebateClaimCase;
  /** The whole amount withheld on the invoice. */
  claimed: number;
  /** The rebate we validate on the contract basis. */
  validated: number;
  /** What we decline and ask back. */
  unsupported: number;
  /** Net eligible sales, summed from the build-up. */
  netEligibleSales: number;
  /** Growth of net eligible sales over the contract baseline, %. */
  netGrowthPct: number;
  /** The tier attained on the contract basis, derived against the amended table. */
  attainedTier: RebateTier;
  /** The tier the retailer billed at. */
  claimedTierPct: number;
  /** validated + Σ(drivers) === claimed. */
  reconciles: boolean;
  drivers: RebateVarianceDriver[];
  /** Total dollar gap explained by the drivers. */
  driverTotal: number;
}

const round1 = (n: number) => Math.round(n * 10) / 10;

export function rebateClaimAssessment(
  caseId: string,
  edit?: ClaimEdit
): RebateClaimAssessment | null {
  const c = findRebateClaimCase(caseId);
  if (!c) return null;

  const claimed = c.invoiceAmount - c.amountPaid;

  // Net eligible sales from the build-up: gross less every contract deduction.
  const gross = c.basisBuildUp.find((l) => !l.isDeduction)?.amount ?? 0;
  const deductions = c.basisBuildUp
    .filter((l) => l.isDeduction)
    .reduce((s, l) => s + l.amount, 0);
  const netEligibleSales = gross - deductions;

  const baseline = c.program.baselineNetSales;
  const netGrowthPct = round1(((netEligibleSales - baseline) / baseline) * 100);

  // Attained tier: the highest tier whose threshold the growth clears.
  const attainedTier = [...c.tierTable]
    .sort((a, b) => a.minGrowthPct - b.minGrowthPct)
    .reduce(
      (best, t) => (netGrowthPct >= t.minGrowthPct ? t : best),
      c.tierTable[0]
    );

  const driverTotal = c.varianceDrivers.reduce((s, d) => s + d.amount, 0);
  // A reviewer can move how much of the claim is validated as a real rebate;
  // the remainder is what we decline and ask back.
  const validated =
    edit?.approvedAmount != null
      ? Math.max(0, Math.min(Math.round(edit.approvedAmount), claimed))
      : claimed - driverTotal;
  const unsupported = claimed - validated;

  const reconciles = validated + unsupported === claimed;

  if (process.env.NODE_ENV !== "production" && !edit) {
    if (validated + driverTotal !== claimed)
      console.error(
        `[rebate claim] ${caseId}: validated + drivers does not equal the amount withheld`,
        { claimed, validated, driverTotal }
      );
  }

  return {
    case: c,
    claimed,
    validated,
    unsupported,
    netEligibleSales,
    netGrowthPct,
    attainedTier,
    claimedTierPct: c.retailerClaim.claimedTierPct,
    reconciles,
    drivers: c.varianceDrivers,
    driverTotal,
  };
}

/* ------------------------------------------------------------------ *
 * What it does to the books
 * ------------------------------------------------------------------ */

export interface RebateClaimAccounting {
  /** Only the validated rebate is a real trade cost; the rest is not. */
  gtnImpact: number;
  /** The unsupported part is declined and the receivable stands. */
  recoveryRequired: number;
  /** The accrual is trued up to the validated figure. */
  accrualTrueUp: number;
  lines: {
    lineNumber: number;
    glAccount: string;
    accountName: string;
    plainName: string;
    debit?: number;
    credit?: number;
  }[];
}

/**
 * Partial approval. The validated rebate ($335k) is a genuine trade-spend cost
 * and settles against the deduction; the unsupported $165k is not a cost — the
 * receivable is reinstated and repayment requested. The accrual, which had been
 * carried at the claimed rate, is released down to the validated figure.
 */
export function rebateClaimAccounting(
  caseId: string,
  edit?: ClaimEdit
): RebateClaimAccounting | null {
  const a = rebateClaimAssessment(caseId, edit);
  if (!a) return null;

  return {
    gtnImpact: a.validated,
    recoveryRequired: a.unsupported,
    accrualTrueUp: a.unsupported,
    lines: [
      {
        lineNumber: 10,
        glAccount: "455200",
        accountName: "Trade spend — growth rebate",
        plainName: `Validated rebate settled — ${a.case.customerName}`,
        debit: a.validated,
      },
      {
        lineNumber: 20,
        glAccount: "121500",
        accountName: "Deduction clearing — retail channel",
        plainName: `Receivable reinstated — unsupported rebate`,
        debit: a.unsupported,
      },
      {
        lineNumber: 30,
        glAccount: "229300",
        accountName: "Trade promotion accrual",
        plainName: `Accrual trued up to validated rebate`,
        credit: a.claimed,
      },
    ],
  };
}

/* ------------------------------------------------------------------ *
 * The retailer response
 * ------------------------------------------------------------------ */

export function renderRebateClaimLetter(
  caseId: string,
  edit?: ClaimEdit
): { subject: string; body: string } | null {
  const a = rebateClaimAssessment(caseId, edit);
  if (!a) return null;
  const c = a.case;
  const usd = (n: number) => `$${n.toLocaleString("en-US")}`;

  const tokens: Record<string, string> = {
    remittanceId: c.remittanceId,
    receivedDate: c.receivedDate,
    claimed: usd(a.claimed),
    invoiceId: c.invoiceId,
    claimRef: c.claimRef,
    programId: c.program.programId,
    amendmentRef: c.program.amendmentRef,
    amendmentDate: c.program.amendmentDate,
    netEligibleSales: usd(a.netEligibleSales),
    baseline: usd(c.program.baselineNetSales),
    validatedRebate: usd(a.validated),
    unsupported: usd(a.unsupported),
    from: c.responseLetter.from,
  };

  const fill = (t: string) =>
    t.replace(/\{(\w+)\}/g, (whole, key: string) => tokens[key] ?? whole);

  return {
    subject: fill(c.responseLetter.subjectTemplate),
    body: fill(c.responseLetter.bodyTemplate),
  };
}

export const REBATE_VARIANCE_LABEL: Record<string, string> = {
  "gross-to-net": "Gross-to-net",
  "ineligible-entities": "Ineligible entities",
  "excluded-products": "Excluded products",
  "tier-rate": "Rate / tier",
};
