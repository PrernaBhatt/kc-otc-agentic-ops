/**
 * Source documents for the Costco invoice dispute. Every field is read from
 * the case record and the dispute selector, so a document can never
 * disagree with the stage that opened it.
 */

import type { SourceDoc } from "@/components/modals/source-doc-preview";
import { billingDispute } from "./billing-dispute-selectors";
import { findAccount } from "./data/account-owners";
import type { DisputeCauseKey } from "./data/billing-disputes";
import { formatUsd } from "./format";

/* ------------------------------------------------------------------ *
 * Presentational reference data. None of it feeds the selector math.
 * ------------------------------------------------------------------ */

const SELLER_LINES = [
  "K-C North America",
  "Order-to-Cash · Global Business Services",
  "351 Phelps Drive, Irving, TX 75038",
];
const COSTCO_AP = [
  "Costco Wholesale Corp.",
  "Accounts Payable · Deductions",
  "999 Lake Drive, Issaquah, WA 98027",
];
const COSTCO_HQ = [
  "Costco Wholesale Corporation",
  "999 Lake Drive",
  "Issaquah, WA 98027",
  "United States",
];
const COSTCO_DC = [
  "Costco Depot #C-114",
  "14001 Valley Blvd",
  "City of Industry, CA 91746",
  "United States",
];

const CARRIER = { name: "Meridian Freight Lines", scac: "MFLX", pro: "MFLX-771-540192" };

/** The order quantity split over two SKUs; the lines always sum to the case quantity. */
function orderLines(qty: number) {
  const a = Math.round(qty * 0.6);
  return [
    { sku: "SKU-T410", desc: "Bath Tissue, Ultra Soft · 30 double rolls", qty: a },
    { sku: "SKU-T415", desc: "Paper Towels, Select-A-Size · 12 rolls", qty: qty - a },
  ];
}

/** SAP TM freight settlement lines; they sum to the billed freight. */
function freightLines(total: number) {
  const fuel = Math.round(total * 0.16);
  const accessorial = 1_600;
  return [
    { id: "linehaul", code: "LHL", item: "Linehaul, FTL dock-to-dock", value: total - fuel - accessorial },
    { id: "fuel", code: "FSC", item: "Fuel surcharge", value: fuel },
    { id: "acc", code: "ACC", item: "Accessorials · liftgate, appointment", value: accessorial },
  ];
}

function fig(caseId: string) {
  const f = billingDispute(caseId);
  if (!f) throw new Error(`Unknown dispute case ${caseId}`);
  return f;
}

const usd3 = (n: number) => `$${n.toFixed(3)}`;

/* ------------------------------------------------------------------ *
 * Billing record: the original invoice and its SAP conditions
 * ------------------------------------------------------------------ */

export function buildInvoiceDoc(caseId: string): SourceDoc {
  const f = fig(caseId);
  const c = f.case;
  return {
    docId: `invoice-${c.invoiceId}`,
    title: `Invoice ${c.invoiceId}`,
    docLabel: `SAP S/4HANA billing document · sales order ${c.orderId}`,
    reference: c.invoiceId,
    issuer: "SAP S/4HANA · Sales & Distribution (VA03 / VF03)",
    skin: "sap",
    meta: [
      { label: "Payer", value: `${c.customerName} (${c.soldToId})` },
      { label: "Sales order", value: c.orderId },
      { label: "Customer PO", value: c.poNumber },
      { label: "Delivery", value: `${c.deliveryRef} · ${c.deliveryDate}` },
      { label: "Sales area", value: "3000 / 10 / 00" },
      { label: "Plant", value: "2100 · Ontario CA DC" },
      { label: "Pricing date", value: c.deliveryDate },
      { label: "Billing date", value: c.invoiceDate },
      { label: "Terms", value: `${c.paymentTerms} · due ${c.dueDate}` },
      { label: "Posting period", value: `09 / 2026 · closed ${c.periodClosedOn}` },
    ],
    columns: [
      { key: "ctyp", label: "CnTy" },
      { key: "item", label: "Condition description" },
      { key: "rate", label: "Rate", align: "right" },
      { key: "value", label: "Condition value", align: "right" },
    ],
    rows: [
      { id: "qty", cells: { ctyp: "—", item: "Billed quantity", rate: "—", value: `${c.qty.toLocaleString()} units` } },
      { id: "price", cells: { ctyp: "PR00", item: `Base price · ${c.pricerXNoteRef}`, rate: usd3(c.sapUnitPrice), value: formatUsd(f.merchandise) } },
      { id: "promo", cells: { ctyp: "ZPRM", item: c.promotionName, rate: "0.000", value: `Not applied · ended ${c.promotionExpiredOn}` } },
      { id: "freight", cells: { ctyp: "ZFRT", item: c.sapFreightCondition, rate: "—", value: formatUsd(c.freightBilled) } },
      { id: "tax", cells: { ctyp: "MWST", item: `Output tax · ${c.taxJurisdiction} · ship-to ${c.sapTaxClass}`, rate: "—", value: formatUsd(c.taxBilled) } },
    ],
    totals: [
      { label: "Net value (PR00 × quantity)", value: formatUsd(f.merchandise) },
      { label: "Freight and tax", value: formatUsd(c.freightBilled + c.taxBilled) },
      { label: "Invoice total", value: formatUsd(f.invoiceTotal), emphasis: true },
    ],
    footnote: `Original invoice. Not reissued: the September period closed on ${c.periodClosedOn}.`,
    highlightRowIds: ["price", "freight", "tax"],
    highlightNote: "Price and promotion are billed right. Freight and tax come from ship-to master data the dispute checks.",
  };
}

/* ------------------------------------------------------------------ *
 * What Costco paid: 820 remittance and Costco's own PO
 * ------------------------------------------------------------------ */

export function buildRemittanceDoc(caseId: string): SourceDoc {
  const f = fig(caseId);
  const c = f.case;
  return {
    docId: `remit-${c.remittanceId}`,
    title: `EDI 820 remittance ${c.remittanceId}`,
    docLabel: "EDI 820 payment order / remittance advice",
    reference: c.remittanceId,
    issuer: "Costco Wholesale Corp. · AP via EDI",
    meta: [
      { label: "BPR · payment", value: `${formatUsd(f.paid)} · ${c.paymentRef}` },
      { label: "Payment date", value: c.remittanceDate },
      { label: "RMR · invoice", value: `${c.invoiceId} · billed ${formatUsd(f.invoiceTotal)}` },
      { label: "REF · PO", value: c.poNumber },
      { label: "Deduction lines", value: `${f.causes.length} ADX segments` },
    ],
    columns: [
      { key: "seg", label: "Segment" },
      { key: "code", label: "Costco code" },
      { key: "text", label: "Reason" },
      { key: "amount", label: "Amount", align: "right" },
    ],
    rows: f.causes.map((x) => ({
      id: x.key,
      cells: { seg: "ADX", code: x.reasonCode, text: x.reasonText, amount: `−${formatUsd(x.amount)}` },
    })),
    totals: [
      { label: "Invoice", value: formatUsd(f.invoiceTotal) },
      { label: "Deducted", value: `−${formatUsd(f.shortPaid)}` },
      { label: "Paid", value: formatUsd(f.paid), emphasis: true },
    ],
    highlightRowIds: f.causes.map((x) => x.key),
    highlightNote: "Each ADX line becomes one reason on the dispute case.",
  };
}

export function buildCustomerPoDoc(caseId: string): SourceDoc {
  const f = fig(caseId);
  const c = f.case;
  const subtotal = c.poUnitPrice * c.qty;
  const allowance = c.promotionUnitAllowance * c.qty;
  return {
    docId: `po-${c.poNumber}`,
    title: `Purchase order ${c.poNumber}`,
    docLabel: "Customer purchase order",
    reference: c.poNumber,
    issuer: c.customerName,
    skin: "printed-po",
    docDate: "Sep 12, 2026",
    partyBlocks: [
      { heading: "Buyer", lines: COSTCO_HQ },
      { heading: "Vendor", lines: SELLER_LINES },
      { heading: "Shipping Address", lines: COSTCO_DC, accent: true },
    ],
    meta: [
      { label: "Sales order", value: c.orderId },
      { label: "Vendor no.", value: c.soldToId },
      { label: "Payment terms", value: c.paymentTerms },
      { label: "Incoterms", value: "FOB destination" },
    ],
    columns: [
      { key: "sn", label: "SN" },
      { key: "code", label: "Item Code" },
      { key: "item", label: "Description" },
      { key: "qty", label: "Qty", align: "right" },
      { key: "price", label: "Unit Price", align: "right" },
      { key: "value", label: "Line Total", align: "right" },
    ],
    rows: orderLines(c.qty).map((l, i) => ({
      id: `line-${i + 1}`,
      cells: {
        sn: String(i + 1),
        code: l.sku,
        item: l.desc,
        qty: l.qty.toLocaleString(),
        price: usd3(c.poUnitPrice),
        value: formatUsd(c.poUnitPrice * l.qty),
      },
    })),
    totals: [
      { label: "Sub Total", value: formatUsd(subtotal) },
      { label: c.promotionName, value: `−${formatUsd(allowance)}` },
      { label: "Freight (agreed cap)", value: formatUsd(c.freightCapPerLoad) },
      { label: "Sales tax", value: "Exempt · resale" },
      { label: "Total in USD", value: formatUsd(subtotal - allowance + c.freightCapPerLoad), emphasis: true },
    ],
    footnote: `Costco paid exactly this total (${formatUsd(f.paid)}) on ${c.remittanceId}. It was raised after the ${c.priceCatalogRef} price catalog was acknowledged.`,
    highlightRowIds: ["line-1", "line-2"],
    highlightNote: `Lines still at ${usd3(c.poUnitPrice)} and an expired Q2 allowance deducted. Freight at the cap and no tax are correct.`,
  };
}

/* ------------------------------------------------------------------ *
 * Delivery: proof that the shipment is complete and when it landed
 * ------------------------------------------------------------------ */

export function buildDeliveryDoc(caseId: string): SourceDoc {
  const f = fig(caseId);
  const c = f.case;
  return {
    docId: `pod-${c.deliveryRef}`,
    title: `Delivery ${c.deliveryRef}`,
    docLabel: "Proof of delivery",
    reference: c.deliveryRef,
    issuer: "SAP Logistics Execution · Proof of Delivery",
    skin: "pod-letter",
    docDate: c.deliveryDate,
    meta: [
      { label: "Delivery number", value: c.deliveryRef },
      { label: "Sales order", value: c.orderId },
      { label: "Customer PO", value: c.poNumber },
      { label: "Carrier", value: `${CARRIER.name} (SCAC ${CARRIER.scac})` },
      { label: "Service level", value: "FTL, dock-to-dock" },
      { label: "Pro / tracking", value: CARRIER.pro },
      { label: "Delivered", value: c.deliveryDate },
      { label: "Weight", value: "41,600 lb (18,870 kg)" },
      { label: "Handling units", value: "26 pallets" },
      { label: "Recipient name", value: "Receiving · Costco Depot #C-114" },
      { label: "Status", value: "Delivered complete, no discrepancy" },
    ],
    columns: [
      { key: "item", label: "Check" },
      { key: "value", label: "Result", align: "right" },
    ],
    rows: [
      { id: "qty", cells: { item: "Quantity shipped vs. ordered", value: `Match · ${c.qty.toLocaleString()} / ${c.qty.toLocaleString()}` } },
      { id: "damage", cells: { item: "Damage / shortage claims", value: "None" } },
      { id: "seal", cells: { item: "Seal integrity", value: "Intact" } },
      { id: "date", cells: { item: `Delivered vs. ${c.promotionName} window`, value: `${c.deliveryDate} · after ${c.promotionExpiredOn}` } },
      { id: "pod", cells: { item: "Signed proof of delivery on file", value: "Yes" } },
    ],
    partyBlocks: [{ heading: "Destination delivery address", lines: COSTCO_DC }],
    signature: [
      { label: "Signature of recipient", value: "K. Alvarez" },
      { label: "Printed name / title", value: "K. Alvarez · Receiving Lead" },
      { label: "Date received", value: c.deliveryDate },
    ],
    stamp: {
      title: "Received",
      date: c.deliveryDate,
      lines: ["Costco Depot #C-114", "26 pallets", "In good order"],
    },
    footnote: "Delivered complete, so none of the four deductions is a shortage or damage claim.",
    highlightRowIds: ["qty", "date"],
    highlightNote: `Delivered ${c.deliveryDate}, after the Q2 promotion closed. This is the backup for ADX 17.`,
  };
}

/* ------------------------------------------------------------------ *
 * Price: PricerX approval and the EDI 832 that told Costco
 * ------------------------------------------------------------------ */

export function buildPricerXNoteDoc(caseId: string): SourceDoc {
  const f = fig(caseId);
  const c = f.case;
  const price = f.causes.find((x) => x.key === "price")!;
  return {
    docId: `pricerx-${c.pricerXNoteRef}`,
    title: `PricerX note ${c.pricerXNoteRef}`,
    docLabel: "PricerX approved pricing note",
    reference: c.pricerXNoteRef,
    issuer: "PricerX · Revenue Management",
    skin: "pricerx",
    meta: [
      { label: "Note", value: c.pricerXNoteRef },
      { label: "Customer", value: `${c.customerName} (${c.soldToId})` },
      { label: "Approved on", value: c.pricerXApprovedOn },
      { label: "Approver", value: "D. Okafor · Pricing Director" },
      { label: "Effective", value: "2026-09-01" },
      { label: "Valid through", value: "2026-12-31" },
      { label: "Published", value: `${c.priceCatalogRef} · ${c.priceCatalogSentOn}` },
      { label: "Note status", value: "Active" },
    ],
    columns: [
      { key: "item", label: "Field" },
      { key: "value", label: "Value", align: "right" },
    ],
    rows: [
      { id: "prior", cells: { item: "Prior net unit price", value: usd3(c.poUnitPrice) } },
      { id: "approved", cells: { item: "Approved net unit price", value: usd3(c.sapUnitPrice) } },
      { id: "sap", cells: { item: `SAP PR00 on ${c.invoiceId}`, value: `${usd3(c.sapUnitPrice)} · agrees` } },
      { id: "po", cells: { item: `Price on Costco ${c.poNumber}`, value: usd3(c.poUnitPrice) } },
      { id: "gap", cells: { item: `Short × ${c.qty.toLocaleString()} units`, value: formatUsd(price.amount) } },
    ],
    footnote: "PricerX and SAP agree. Costco's PO carries the prior price.",
    highlightRowIds: ["approved", "po"],
    highlightNote: "The approved price K-C is owed. This is the backup for ADX 04.",
  };
}

export function buildPriceCatalogDoc(caseId: string): SourceDoc {
  const f = fig(caseId);
  const c = f.case;
  return {
    docId: `edi832-${c.priceCatalogRef}`,
    title: c.priceCatalogRef,
    docLabel: "EDI 832 price/sales catalog with 997 acknowledgment",
    reference: c.priceCatalogRef.replace("EDI 832 ", ""),
    issuer: "K-C EDI gateway · Costco trading partner",
    meta: [
      { label: "Sender", value: "K-C North America (ISA 006900 KCNA)" },
      { label: "Receiver", value: "Costco Wholesale (ISA 01 COSTCOAP)" },
      { label: "Sent", value: `${c.priceCatalogSentOn} 14:12` },
      { label: "Price source", value: c.pricerXNoteRef },
      { label: "997 functional ack", value: `${c.priceCatalogSentOn} 14:19 · AK5 A (accepted)` },
      { label: "Effective", value: "2026-09-01" },
    ],
    columns: [
      { key: "seg", label: "LIN" },
      { key: "item", label: "Item" },
      { key: "old", label: "Prior", align: "right" },
      { key: "new", label: "New (CTP)", align: "right" },
    ],
    rows: orderLines(c.qty).map((l, i) => ({
      id: `lin-${i + 1}`,
      cells: { seg: String(i + 1).padStart(3, "0"), item: `${l.sku} · ${l.desc}`, old: usd3(c.poUnitPrice), new: usd3(c.sapUnitPrice) },
    })),
    footnote: `Costco accepted this catalog on ${c.priceCatalogSentOn}, before ${c.poNumber} was raised.`,
    highlightRowIds: ["lin-1", "lin-2"],
    highlightNote: "Costco was notified and acknowledged the new price.",
  };
}

/* ------------------------------------------------------------------ *
 * Promotion: Vistex event terms
 * ------------------------------------------------------------------ */

export function buildPromotionDoc(caseId: string): SourceDoc {
  const f = fig(caseId);
  const c = f.case;
  const promo = f.causes.find((x) => x.key === "promotion")!;
  return {
    docId: `vistex-${c.promotionRef}`,
    title: `Vistex event ${c.promotionRef}`,
    docLabel: "Vistex trade promotion agreement",
    reference: c.promotionRef,
    issuer: "Vistex · Trade Promotion Management",
    skin: "trade",
    meta: [
      { label: "Agreement", value: c.promotionRef },
      { label: "Promotion", value: c.promotionName },
      { label: "Rebate type", value: "Off-invoice allowance, per unit" },
      { label: "Eligibility window", value: c.promotionWindow },
      { label: "Funding owner", value: "Trade Promotion · Costco team" },
      { label: "Status", value: `Closed ${c.promotionExpiredOn}` },
    ],
    columns: [
      { key: "item", label: "Term" },
      { key: "value", label: "Agreed", align: "right" },
    ],
    rows: [
      { id: "eligible", cells: { item: "Eligible customer", value: `${c.customerName} (${c.soldToId})` } },
      { id: "product", cells: { item: "Eligible products", value: "Bath tissue and towel family (SKU-T4xx)" } },
      { id: "allowance", cells: { item: "Allowance per unit", value: usd3(c.promotionUnitAllowance) } },
      { id: "window", cells: { item: "Eligibility window", value: c.promotionWindow } },
      { id: "delivered", cells: { item: `${c.orderId} delivered`, value: `${c.deliveryDate} · outside window` } },
    ],
    totals: [{ label: `Deducted by Costco × ${c.qty.toLocaleString()}`, value: formatUsd(promo.amount), emphasis: true }],
    footnote: `The promotion closed on ${c.promotionExpiredOn}; ${c.deliveryRef} delivered on ${c.deliveryDate}.`,
    highlightRowIds: ["window", "delivered"],
    highlightNote: "A Q2 allowance cannot apply to a Q3 delivery. This is the backup for ADX 17.",
  };
}

/* ------------------------------------------------------------------ *
 * Freight: Costco's vendor agreement and K-C's SAP TM settlement
 * ------------------------------------------------------------------ */

export function buildVendorAgreementDoc(caseId: string): SourceDoc {
  const f = fig(caseId);
  const c = f.case;
  const freight = f.causes.find((x) => x.key === "freight")!;
  return {
    docId: `vendor-agreement-${caseId}`,
    title: c.vendorAgreementRef,
    docLabel: "Vendor agreement · freight terms",
    reference: c.vendorAgreementRef,
    issuer: "Costco Wholesale Corp. · Supplier terms",
    partyBlocks: [
      { heading: "Buyer", lines: COSTCO_HQ },
      { heading: "Supplier", lines: SELLER_LINES },
    ],
    meta: [
      { label: "Agreement", value: "Costco Vendor Agreement · rev. 2026-01" },
      { label: "Clause", value: "§7.2 Prepaid freight, depot deliveries" },
      { label: "Term", value: "2026-01-01 to 2027-12-31" },
      { label: "Applies to", value: "All CA depot ship-tos incl. #C-114" },
    ],
    columns: [
      { key: "field", label: "Term" },
      { key: "value", label: "Value", align: "right" },
    ],
    rows: [
      { id: "cap", cells: { field: "Freight charged per load, maximum", value: formatUsd(c.freightCapPerLoad) } },
      { id: "basis", cells: { field: "Excess over cap", value: "Borne by supplier" } },
      { id: "billed", cells: { field: `Freight billed on ${c.invoiceId}`, value: formatUsd(c.freightBilled) } },
      { id: "finding", cells: { field: "Billed above cap", value: formatUsd(freight.amount) } },
    ],
    footnote: "Costco is right on this line. K-C credits the excess.",
    highlightRowIds: ["cap", "finding"],
    highlightNote: "The agreed cap. SAP still bills this ship-to at actual cost.",
  };
}

export function buildFreightSettlementDoc(caseId: string): SourceDoc {
  const f = fig(caseId);
  const c = f.case;
  const freight = f.causes.find((x) => x.key === "freight")!;
  return {
    docId: `tm-${caseId}`,
    title: `Freight settlement FSD-${c.deliveryRef.replace("DN-", "")}`,
    docLabel: `SAP TM freight settlement · ${c.deliveryRef}`,
    reference: `FSD-${c.deliveryRef.replace("DN-", "")}`,
    issuer: "SAP Transportation Management",
    skin: "sap",
    meta: [
      { label: "Freight order", value: `FO-${c.deliveryRef.replace("DN-", "")}` },
      { label: "Delivery", value: c.deliveryRef },
      { label: "Carrier", value: `${CARRIER.name} (${CARRIER.scac})` },
      { label: "Settled", value: "2026-09-21 · carrier invoice paid" },
      { label: "Ship-to freight condition", value: c.sapFreightCondition },
      { label: "Passed to billing", value: `ZFRT on ${c.invoiceId}` },
    ],
    columns: [
      { key: "code", label: "Charge" },
      { key: "item", label: "Description" },
      { key: "value", label: "Amount", align: "right" },
    ],
    rows: [
      ...freightLines(c.freightBilled).map((l) => ({
        id: l.id,
        cells: { code: l.code, item: l.item, value: formatUsd(l.value) },
      })),
      { id: "cap", cells: { code: "—", item: `Cap per ${c.vendorAgreementRef}`, value: formatUsd(c.freightCapPerLoad) } },
    ],
    totals: [
      { label: "Settled and billed to Costco", value: formatUsd(c.freightBilled) },
      { label: "Above the agreed cap", value: formatUsd(freight.amount), emphasis: true },
    ],
    footnote: "The ship-to condition passes actual cost through. It goes to Master data as an MDG change request.",
    highlightRowIds: ["cap"],
  };
}

/* ------------------------------------------------------------------ *
 * Tax: Costco's resale certificate and Vertex's determination
 * ------------------------------------------------------------------ */

export function buildResaleCertificateDoc(caseId: string): SourceDoc {
  const f = fig(caseId);
  const c = f.case;
  return {
    docId: `cert-${c.exemptionCertificate}`,
    title: `Resale certificate ${c.exemptionCertificate}`,
    docLabel: "California resale certificate (CDTFA-230)",
    reference: c.exemptionCertificate,
    issuer: `${c.taxJurisdiction} CDTFA · resale certificate`,
    partyBlocks: [
      { heading: "Purchaser", lines: COSTCO_HQ },
      { heading: "Seller", lines: SELLER_LINES },
    ],
    meta: [
      { label: "Seller's permit (purchaser)", value: "SR KH 100-482117" },
      { label: "Property purchased", value: "Paper and tissue products for resale" },
      { label: "Locations covered", value: "All CA distribution centers incl. #C-114" },
      { label: "Issued", value: "2025-07-01" },
      { label: "Valid to", value: c.exemptionValidTo },
      { label: "Signed by", value: "R. Matsuda · Tax Manager, Costco" },
    ],
    columns: [
      { key: "field", label: "Check" },
      { key: "value", label: "Result", align: "right" },
    ],
    rows: [
      { id: "valid", cells: { field: `Valid on ${c.invoiceDate}`, value: "Yes" } },
      { id: "shipto", cells: { field: "Covers ship-to Depot #C-114", value: "Yes" } },
      { id: "finding", cells: { field: `Tax billed on ${c.invoiceId}`, value: `${formatUsd(c.taxBilled)} · not owed` } },
    ],
    footnote: "Costco is right on this line. K-C credits the tax.",
    highlightRowIds: ["valid", "finding"],
  };
}

export function buildTaxDeterminationDoc(caseId: string): SourceDoc {
  const f = fig(caseId);
  const c = f.case;
  return {
    docId: `vertex-${caseId}`,
    title: `Vertex tax determination · ${c.invoiceId}`,
    docLabel: "Vertex O Series tax journal",
    reference: `VTX-${c.invoiceId.replace("INV-", "")}`,
    issuer: "Vertex O Series · called from SAP billing",
    skin: "sap",
    meta: [
      { label: "Document", value: `${c.invoiceId} · ${c.invoiceDate}` },
      { label: "Jurisdiction", value: `${c.taxJurisdiction} · Los Angeles County` },
      { label: "Ship-to tax class (SAP)", value: c.sapTaxClass },
      { label: "Certificate linked to ship-to", value: "None" },
    ],
    columns: [
      { key: "field", label: "Step" },
      { key: "value", label: "Result", align: "right" },
    ],
    rows: [
      { id: "class", cells: { field: "Customer class sent by SAP", value: c.sapTaxClass } },
      { id: "cert", cells: { field: "Exemption certificate lookup", value: "Not linked to ship-to" } },
      { id: "tax", cells: { field: "Output tax calculated", value: formatUsd(c.taxBilled) } },
    ],
    footnote: `${c.exemptionCertificate} is on file but not linked to this ship-to. It goes to Master data as an MDG change request.`,
    highlightRowIds: ["class", "cert"],
  };
}

/* ------------------------------------------------------------------ *
 * Evidence per cause, in the order the case record lists it
 * ------------------------------------------------------------------ */

const EVIDENCE_BUILDERS: Record<DisputeCauseKey, { short: string; build: (caseId: string) => SourceDoc }[]> = {
  price: [
    { short: "PricerX", build: buildPricerXNoteDoc },
    { short: "EDI 832", build: buildPriceCatalogDoc },
    { short: "PO", build: buildCustomerPoDoc },
  ],
  promotion: [
    { short: "Vistex", build: buildPromotionDoc },
    { short: "POD", build: buildDeliveryDoc },
  ],
  freight: [
    { short: "Agreement", build: buildVendorAgreementDoc },
    { short: "SAP TM", build: buildFreightSettlementDoc },
  ],
  tax: [
    { short: "Certificate", build: buildResaleCertificateDoc },
    { short: "Vertex", build: buildTaxDeterminationDoc },
  ],
};

export interface CauseEvidence {
  label: string;
  short: string;
  doc: SourceDoc;
}

export function causeEvidence(caseId: string, key: DisputeCauseKey): CauseEvidence[] {
  const cause = fig(caseId).causes.find((x) => x.key === key)!;
  return EVIDENCE_BUILDERS[key].map((e, i) => ({
    label: cause.evidence[i] ?? e.short,
    short: e.short,
    doc: e.build(caseId),
  }));
}

/** The lead document for a cause. */
export function buildCauseEvidenceDoc(caseId: string, key: DisputeCauseKey): SourceDoc {
  return EVIDENCE_BUILDERS[key][0].build(caseId);
}

/* ------------------------------------------------------------------ *
 * Dispute case and settlement outputs
 * ------------------------------------------------------------------ */

export function buildDisputeCaseDoc(caseId: string): SourceDoc {
  const f = fig(caseId);
  const c = f.case;
  const owner = findAccount(c.accountId)?.owner.name ?? "";
  return {
    docId: `fscm-${c.caseId}`,
    title: `FSCM dispute case ${c.caseId}`,
    docLabel: "SAP FSCM Dispute Management (UDM_DISPUTE)",
    reference: c.caseId,
    issuer: "SAP S/4HANA · FSCM",
    skin: "sap",
    meta: [
      { label: "Customer", value: `${c.customerName} (${c.soldToId})` },
      { label: "Original invoice", value: `${c.invoiceId} · ${formatUsd(f.invoiceTotal)}` },
      { label: "Remittance", value: `${c.remittanceId} · ${formatUsd(f.paid)}` },
      { label: "Disputed amount", value: formatUsd(f.shortPaid) },
      { label: "Coordinator", value: owner },
      { label: "Residual item", value: `${formatUsd(f.shortPaid)} open on ${c.invoiceId}` },
    ],
    columns: [
      { key: "reason", label: "Reason" },
      { key: "code", label: "Code" },
      { key: "verdict", label: "Finding" },
      { key: "amount", label: "Amount", align: "right" },
    ],
    rows: f.causes.map((x) => ({
      id: x.key,
      cells: {
        reason: x.label,
        code: x.reasonCode,
        verdict: x.verdict === "kc" ? "K-C right · charge back" : "Costco right · credit",
        amount: formatUsd(x.amount),
      },
    })),
    totals: [
      { label: "Charge-back", value: formatUsd(f.chargeBack) },
      { label: "Credit note", value: formatUsd(f.credit) },
      { label: "Disputed", value: formatUsd(f.shortPaid), emphasis: true },
    ],
    highlightRowIds: [],
  };
}

export function buildCreditMemoDoc(caseId: string): SourceDoc {
  const f = fig(caseId);
  const c = f.case;
  const lines = f.causes.filter((x) => x.verdict === "customer");
  return {
    docId: `cmr-${c.creditMemoRequestId}`,
    title: `Credit memo request ${c.creditMemoRequestId}`,
    docLabel: "SAP credit memo request (order type G2)",
    reference: c.creditMemoRequestId,
    issuer: "SAP S/4HANA · Sales",
    skin: "sap",
    meta: [
      { label: "Reference invoice", value: c.invoiceId },
      { label: "Dispute case", value: c.caseId },
      { label: "Credit memo", value: c.creditMemoId },
      { label: "Billing block", value: "Released on approval" },
    ],
    columns: [
      { key: "reason", label: "Reason" },
      { key: "backup", label: "Backup" },
      { key: "amount", label: "Amount", align: "right" },
    ],
    rows: lines.map((x) => ({
      id: x.key,
      cells: { reason: `${x.reasonCode} · ${x.reasonText}`, backup: x.evidence.join(", "), amount: formatUsd(x.amount) },
    })),
    totals: [{ label: "Credit to Costco", value: formatUsd(f.credit), emphasis: true }],
    highlightRowIds: [],
  };
}

export function buildChargeBackDoc(caseId: string): SourceDoc {
  const f = fig(caseId);
  const c = f.case;
  const lines = f.causes.filter((x) => x.verdict === "kc");
  return {
    docId: `chb-${c.chargeBackId}`,
    title: `Charge-back notice ${c.chargeBackId}`,
    docLabel: "Deduction charge-back with backup",
    reference: c.chargeBackId,
    issuer: "K-C North America · Credit & Deductions",
    partyBlocks: [
      { heading: "From", lines: SELLER_LINES },
      { heading: "To", lines: COSTCO_AP, accent: true },
    ],
    meta: [
      { label: "Original invoice", value: `${c.invoiceId} · ${c.invoiceDate}` },
      { label: "Customer PO", value: c.poNumber },
      { label: "Remittance", value: `${c.remittanceId} · ${c.remittanceDate}` },
      { label: "Dispute case", value: c.caseId },
    ],
    columns: [
      { key: "reason", label: "Deduction line" },
      { key: "backup", label: "Backup" },
      { key: "amount", label: "Amount", align: "right" },
    ],
    rows: lines.map((x) => ({
      id: x.key,
      cells: { reason: `${x.reasonCode} · ${x.reasonText}`, backup: x.evidence.join(", "), amount: formatUsd(x.amount) },
    })),
    totals: [{ label: "Due from Costco", value: formatUsd(f.chargeBack), emphasis: true }],
    highlightRowIds: [],
  };
}

export function buildUpstreamDoc(caseId: string, fixId: string): SourceDoc {
  const f = fig(caseId);
  const fix = f.case.upstream.find((u) => u.id === fixId)!;
  const cause = f.causes.find((x) => x.key === fix.cause)!;
  return {
    docId: `upstream-${fix.id}`,
    title: `${fix.kind === "mdg-cr" ? "MDG change request" : "Pricing task"} ${fix.id}`,
    docLabel: fix.kind === "mdg-cr" ? "SAP MDG · Customer change request" : `${fix.system} · Pricing task`,
    reference: fix.id,
    issuer: fix.kind === "mdg-cr" ? "SAP Master Data Governance" : fix.system,
    skin: fix.kind === "mdg-cr" ? "sap" : fix.system === "Vistex" ? "trade" : "pricerx",
    meta: [
      { label: "Customer", value: `${f.case.customerName} (${f.case.soldToId})` },
      { label: "Source case", value: `${f.case.caseId} · ${cause.label}` },
      { label: "Assigned to", value: fix.assignee },
      { label: "Status", value: fix.status },
    ],
    columns: [
      { key: "field", label: "Change" },
      { key: "value", label: "Value", align: "right" },
    ],
    rows: [
      { id: "change", cells: { field: fix.title, value: fix.change } },
      { id: "evidence", cells: { field: "Evidence", value: cause.evidence.join(", ") } },
      { id: "impact", cells: { field: "Value at stake on this case", value: formatUsd(cause.amount) } },
    ],
    highlightRowIds: ["change"],
  };
}

export function disputeLetter(caseId: string) {
  const f = fig(caseId);
  const c = f.case;
  const owner = findAccount(c.accountId)?.owner.name ?? "";
  const kc = f.causes.filter((x) => x.verdict === "kc");
  const cust = f.causes.filter((x) => x.verdict === "customer");
  return {
    subject: `Dispute ${c.caseId} · ${c.invoiceId} (PO ${c.poNumber})`,
    body: `Dear Costco Accounts Payable,

Remittance ${c.remittanceId} paid ${formatUsd(f.paid)} against invoice ${c.invoiceId} (${formatUsd(f.invoiceTotal)}), leaving ${formatUsd(f.shortPaid)} deducted across ${f.causes.length} lines. We reviewed each line on dispute case ${c.caseId}.

Credited to your account (${c.creditMemoId}, ${formatUsd(f.credit)}):
${cust.map((x) => `- ${x.reasonCode} ${x.reasonText}: ${formatUsd(x.amount)}. ${x.finding}`).join("\n")}

Charged back (${c.chargeBackId}, ${formatUsd(f.chargeBack)}), backup attached:
${kc.map((x) => `- ${x.reasonCode} ${x.reasonText}: ${formatUsd(x.amount)}. ${x.finding}`).join("\n")}

Invoice ${c.invoiceId} stands as issued. Please remit ${formatUsd(f.chargeBack)} referencing ${c.chargeBackId}, and update your item file to price revision ${c.pricerXNoteRef}.

Regards,
${owner}
Costco account owner, K-C North America`,
  };
}
