/**
 * Accounts page math. Open work per account combines the live run state
 * (billing disputes, trade and non-trade deductions) with the static open
 * items in account-work.ts. Workload figures tie out to PRD §12.4.
 */

import type { ViewId } from "@/components/layout/sidebar";
import { accountAgents, staticOpenWork } from "./data/account-work";
import { accountOwners, findAccount, type Region } from "./data/account-owners";
import { billingDisputeCases } from "./data/billing-disputes";
import type { Escalation } from "./data/escalations";
import { dupClaimCases } from "./data/dup-claims";
import { fundClaimCases } from "./data/fund-claims";
import { MULTI_CAUSE_DEDUCTION } from "./data/multi-cause-deduction";
import { SPLIT_OUT_CLAIMS } from "./data/non-trade-batch";
import { promoClaimCases } from "./data/promo-claims";
import { rebateClaimCases } from "./data/rebate-claims";
import { billingDispute } from "./billing-dispute-selectors";
import { dupClaimAssessment } from "./dup-claim-selectors";
import { escalationAgeDays, isEscalationOverdue } from "./escalation-selectors";
import { fundClaimAssessment } from "./fund-claim-selectors";
import { promoClaimSplit } from "./promo-claim-selectors";
import { rebateClaimAssessment } from "./rebate-claim-selectors";
import { shortPaySplit } from "./short-pay-selectors";
import type { DeductionLane } from "./store";

function assert(cond: boolean, msg: string) {
  if (!cond) throw new Error(`[accounts tie-out] ${msg}`);
}

export const workloadTotals = {
  agents: accountOwners.reduce((s, a) => s + a.workload.agents, 0),
  owner: accountOwners.reduce((s, a) => s + a.workload.owner, 0),
  get items() {
    return this.agents + this.owner;
  },
};
assert(workloadTotals.agents === 1_236, "agent items");
assert(workloadTotals.owner === 48, "owner items");
assert(workloadTotals.items === 1_284, "total items");
for (const a of accountOwners) {
  const agents = accountAgents[a.accountId] ?? [];
  assert(agents.length === a.agentsActive, `${a.shortName} agents active`);
  assert(agents.reduce((s, x) => s + x.itemsThisWeek, 0) === a.workload.agents, `${a.shortName} agent items`);
}

export const agentShare = Math.round((workloadTotals.agents / workloadTotals.items) * 100);

export interface AccountLiveState {
  resolvedPromoClaims: string[];
  resolvedDupClaims: string[];
  resolvedRebateClaims: string[];
  resolvedFundClaims: string[];
  resolvedBillingDisputes: string[];
  resolvedShortPays: string[];
  resolvedMultiCauseDeductions: string[];
  nonTradeBatchPosted: boolean;
  resolvedSplitOuts: Record<string, string>;
  escalations: Escalation[];
  channelCases: { deductionId: string; customerName: string; amount: number; status: string }[];
}

export interface OpenWorkItem {
  key: string;
  label: string;
  count: number;
  usd: number;
  view: ViewId;
  lane?: DeductionLane;
  caseId?: string;
}

const idFor = (name: string) => findAccount(name)?.accountId;

export function accountOpenWork(accountId: string, s: AccountLiveState): OpenWorkItem[] {
  const st = staticOpenWork[accountId];

  const billing = billingDisputeCases.filter(
    (c) => c.accountId === accountId && !s.resolvedBillingDisputes.includes(c.caseId)
  );

  const trade = [
    ...promoClaimCases
      .filter((c) => idFor(c.customerName) === accountId && !s.resolvedPromoClaims.includes(c.caseId))
      .map((c) => ({ id: c.caseId, usd: promoClaimSplit(c.caseId)?.claimed ?? 0 })),
    ...dupClaimCases
      .filter((c) => idFor(c.customerName) === accountId && !s.resolvedDupClaims.includes(c.caseId))
      .map((c) => ({ id: c.caseId, usd: dupClaimAssessment(c.caseId)?.claimed ?? 0 })),
    ...rebateClaimCases
      .filter((c) => idFor(c.customerName) === accountId && !s.resolvedRebateClaims.includes(c.caseId))
      .map((c) => ({ id: c.caseId, usd: rebateClaimAssessment(c.caseId)?.claimed ?? 0 })),
    ...fundClaimCases
      .filter((c) => idFor(c.customerName) === accountId && !s.resolvedFundClaims.includes(c.caseId))
      .map((c) => ({ id: c.caseId, usd: fundClaimAssessment(c.caseId)?.claimed ?? 0 })),
  ];

  const sp = shortPaySplit("DED-SP-002");
  const mc = MULTI_CAUSE_DEDUCTION;
  const nonTrade = [
    ...(s.nonTradeBatchPosted
      ? SPLIT_OUT_CLAIMS.filter((c) => c.accountId === accountId && !s.resolvedSplitOuts[c.id]).map((c) => ({
          id: c.id,
          usd: c.usd,
        }))
      : []),
    ...(sp && idFor(sp.case.customerName) === accountId && !s.resolvedShortPays.includes(sp.case.caseId)
      ? [{ id: sp.case.caseId, usd: sp.shortPay }]
      : []),
    ...(idFor(mc.customerName) === accountId && !s.resolvedMultiCauseDeductions.includes(mc.caseId)
      ? [{ id: mc.caseId, usd: mc.shortPay }]
      : []),
    ...s.channelCases
      .filter((d) => idFor(d.customerName) === accountId && d.status !== "Resolved")
      .map((d) => ({ id: d.deductionId, usd: d.amount })),
  ];

  const items: OpenWorkItem[] = [
    { key: "orders", label: "Orders", count: st?.orders.count ?? 0, usd: st?.orders.usd ?? 0, view: "orders" },
    {
      key: "billing",
      label: "Billing disputes",
      count: billing.length,
      usd: billing.reduce((sum, c) => sum + (billingDispute(c.caseId)?.shortPaid ?? 0), 0),
      view: "billing",
      caseId: billing[0]?.caseId,
    },
    {
      key: "trade",
      label: "Deductions · Trade",
      count: trade.length,
      usd: trade.reduce((sum, x) => sum + x.usd, 0),
      view: "deductions",
      lane: "trade",
      caseId: trade.length === 1 ? trade[0].id : undefined,
    },
    {
      key: "non-trade",
      label: "Deductions · Non-trade",
      count: nonTrade.length,
      usd: nonTrade.reduce((sum, x) => sum + x.usd, 0),
      view: "deductions",
      lane: "non-trade",
    },
    { key: "collections", label: "Collections", count: st?.collections.count ?? 0, usd: st?.collections.usd ?? 0, view: "collections" },
    { key: "cash", label: "Cash application", count: st?.cash.count ?? 0, usd: st?.cash.usd ?? 0, view: "cash-application" },
  ];
  return items;
}

export interface AccountRow {
  accountId: string;
  name: string;
  shortName: string;
  region: Region;
  ownerName: string;
  ownerInitials: string;
  orders: number;
  billing: number;
  deductions: number;
  atRiskUsd: number;
  openEscalations: number;
  overdueEscalations: number;
  oldestDays: number;
  agentsActive: number;
}

export function accountEscalations(accountId: string, all: Escalation[]): Escalation[] {
  return all.filter((e) => e.accountIds.includes(accountId));
}

export function accountRows(s: AccountLiveState): AccountRow[] {
  return accountOwners.map((a) => {
    const work = accountOpenWork(a.accountId, s);
    const by = (k: string) => work.find((w) => w.key === k)?.count ?? 0;
    const esc = accountEscalations(a.accountId, s.escalations).filter((e) => e.status !== "Closed");
    return {
      accountId: a.accountId,
      name: a.accountName,
      shortName: a.shortName,
      region: a.region,
      ownerName: a.owner.name,
      ownerInitials: a.owner.initials,
      orders: by("orders"),
      billing: by("billing"),
      deductions: by("trade") + by("non-trade"),
      atRiskUsd: work.reduce((sum, w) => sum + w.usd, 0),
      openEscalations: esc.length,
      overdueEscalations: esc.filter(isEscalationOverdue).length,
      oldestDays: Math.max(staticOpenWork[a.accountId]?.oldestDays ?? 0, ...esc.map(escalationAgeDays)),
      agentsActive: a.agentsActive,
    };
  });
}

export const REGIONS: Region[] = ["North America", "EMEA", "APAC"];

export function regionCounts() {
  return REGIONS.map((r) => ({ region: r, count: accountOwners.filter((a) => a.region === r).length }));
}
