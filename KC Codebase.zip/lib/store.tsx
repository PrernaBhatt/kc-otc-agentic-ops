"use client";

import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";

import { TODAY, daysAfterToday } from "./data/clock";
import { invoices as seedInvoices } from "./data/invoices";
import { orders as seedOrders } from "./data/orders";
import { invoiceToCashFor } from "./data/invoice-to-cash";
import { exceptions as seedExceptions } from "./data/exceptions";
import { agedInvoices } from "./data/receivables";
import { bankReceipts as seedReceipts } from "./data/receipts";
import { deductions as seedDeductions } from "./data/deductions";
import { promisesToPay as seedPtps } from "./data/collections";
import { revRecObligations as seedObligations } from "./data/revrec";
import { customerQueries as seedQueries } from "./data/queries";
import { provisionApproval as seedApproval } from "./data/provisions";
import { channelDeductions as seedChannelDeductions } from "./data/channel-deductions";
import type { ExceptionRecord, Invoice, Order, OrderStatus } from "./data/types";
import type { BankReceipt } from "./data/receipts";
import type { DeductionCase } from "./data/deductions";
import type { PromiseToPay } from "./data/collections";
import type { RevRecObligation } from "./data/revrec";
import type { CustomerQuery } from "./data/queries";
import type { ClaimEdit } from "./claim-edit";
import { auditSeed } from "./data/audit-seed";
import { runStamp, type AuditEntry, type AuditInput, type AuditSignature } from "./audit";
import type {
  Escalation,
  EscalationStatus,
  RunEscalationId,
} from "./data/escalations";
import { buildRunEscalation, initialEscalations } from "./escalation-selectors";
import { RUN_DATE } from "./data/clock";
import type { ViewId } from "@/components/layout/sidebar";

export type DeductionLane = "trade" | "non-trade";

export interface AuditPreset {
  controlRef?: string;
  accountId?: string;
  caseId?: string;
}

export interface NavIntent {
  view: ViewId;
  accountId?: string;
  audit?: AuditPreset;
  lane?: DeductionLane;
  caseId?: string;
}

export interface OtcState {
  /** All orders — every page reads order status from here so changes propagate. */
  orders: Order[];
  /** All order exceptions — resolving one updates every surface that lists it. */
  exceptions: ExceptionRecord[];
  /** Full AR subledger: recent invoices + older aged invoices. */
  allInvoices: Invoice[];
  receipts: BankReceipt[];
  deductionCases: DeductionCase[];
  ptps: PromiseToPay[];
  obligations: RevRecObligation[];
  queries: CustomerQuery[];
  provisionStatus: "Awaiting approval" | "Approved";
  provisionApprover: string;
  /** Orders whose regulatory hold has been released by a human decision. */
  releasedRegulatoryOrders: Set<string>;
  /** Billing pipeline items completed in this session (clears close checklist). */
  billedOrderIds: Set<string>;
  /**
   * The guided Order-Management run: which order is being walked stage by
   * stage, which downstream stages have been resolved on their own page, and
   * (while off in another page) which stage the human went to resolve. Held
   * here so it survives navigating away to a downstream page and back.
   */
  runOrderId: string | null;
  runResolvedStages: string[];
  runReturnStage: string | null;
  /** True right after returning from a downstream page, so the workspace resumes. */
  runResumePending: boolean;
  /** Orders that have finished all ten stages — kept so the pipeline card reads 100%. */
  completedRunOrders: string[];
  /** A downstream page's run row asked to resolve the stage and return. */
  returnRequested: boolean;

  /* ---- Revenue protection. Deliberately held apart from the receivables
     arrays above: channel claims run to a different scale, and letting them
     into allInvoices would move the ageing buckets, the bad-debt provision,
     the collections worklist and the period-end close all at once. ---- */

  /** Chargeback claims a person has decided on in this session. */
  claimDecisions: ClaimDecision[];
  /** The channel short-pay cases the Deductions page works. */
  channelDeductionCases: DeductionCase[];
  /** Short-pay cases whose run has been completed. */
  resolvedShortPays: string[];
  /** Promotion-claim cases whose run has been completed. */
  resolvedPromoClaims: string[];
  resolvePromoClaim: (caseId: string) => void;
  /** Duplicate-claim cases whose run has been completed. */
  resolvedDupClaims: string[];
  resolveDupClaim: (caseId: string) => void;
  /** Growth-rebate cases whose run has been completed. */
  resolvedRebateClaims: string[];
  resolveRebateClaim: (caseId: string) => void;
  /** Fund-allocation cases whose run has been completed. */
  resolvedFundClaims: string[];
  resolveFundClaim: (caseId: string) => void;
  /** Multi-cause short-pay cases whose run has been completed. */
  resolvedMultiCauseDeductions: string[];
  resolveMultiCauseDeduction: (caseId: string) => void;
  /** FSCM invoice disputes whose run has been completed. */
  resolvedBillingDisputes: string[];
  resolveBillingDispute: (caseId: string) => void;

  /* ---- Governance: audit, escalations, signatures, cross-page navigation ---- */

  auditLog: AuditEntry[];
  appendAudit: (input: AuditInput) => void;
  escalations: Escalation[];
  /** Escalations raised during this session, newest first (drives one-off halos). */
  freshEscalations: string[];
  raiseEscalation: (id: RunEscalationId) => void;
  advanceEscalation: (id: string, status: EscalationStatus, by: string) => void;
  nudgeEscalation: (id: string, by: string) => void;
  signatures: Record<string, AuditSignature[]>;
  signGate: (gateId: string, sigs: AuditSignature[]) => void;
  navIntent: NavIntent | null;
  requestNav: (intent: NavIntent) => void;
  consumeNav: () => void;
  focusAccountId: string | null;
  /** A case a page should open on arrival (set by cross-page navigation). */
  pendingCaseId: string | null;
  consumePendingCase: () => void;
  auditPreset: AuditPreset | null;
  clearAuditPreset: () => void;
  deductionLane: DeductionLane;
  setDeductionLane: (lane: DeductionLane) => void;
  /** The non-trade batch has been signed and posted. */
  nonTradeBatchPosted: boolean;
  postNonTradeBatch: () => void;
  /** OTIF-at-risk shipments an agent run has resolved, keyed by case with the outcome line. */
  resolvedShipments: Record<string, string>;
  resolveShipment: (caseId: string, outcome: string) => void;
  /** Split-out non-trade exceptions a person has decided. */
  resolvedSplitOuts: Record<string, "credit" | "charge-back">;
  resolveSplitOut: (id: string, outcome: "credit" | "charge-back") => void;
  /** Target SO-710249 billed at contract price after the owner signed. */
  targetBilledAtContract: boolean;
  billTargetAtContract: () => void;
  /** Reserve entries a person has posted. */
  postedJournalEntries: string[];
  /** Reversal requests raised against a posted entry. */
  reversalRequests: ReversalRequest[];
  /**
   * Reviewer overrides of a claim decision, keyed by caseId. When present, the
   * claim selectors fold this split back in, so the posting, the gross-to-net
   * impact and the retailer letter all recompute from the reviewer's number.
   */
  claimEdits: Record<string, ClaimEdit>;
  /** Cash application payments a person has approved and posted to SAP. */
  postedCashPayments: string[];
  /**
   * Cash-application deduction lines (by lineId) that have been opened as
   * cases, either one at a time or as a batch. This is the one record of
   * "case opened" both the cash-application workbench and the Deductions
   * queue read from, so a case opened in one place is visible in the other.
   */
  openedCashDeductionCases: string[];
  openCashDeductionCase: (lineId: string) => void;
  openCashDeductionCases: (lineIds: string[]) => void;
}

/** A human decision on a wholesaler chargeback claim. */
export interface ClaimDecision {
  claimId: string;
  outcome: "Approved" | "Approved in part" | "Rejected";
  approvedAmount: number;
  rejectedAmount: number;
  priceRejectAmount: number;
  quantityRejectAmount: number;
  paymentBlockPlaced: boolean;
  creditNoteId: string;
  decidedAt: string;
}

export interface ReversalRequest {
  entryId: string;
  reasonCode: string;
  note: string;
  requestedAt: string;
}

export interface OtcActions {
  /**
   * Human approval of a credit-hold decision: releases the order
   * (Hold → Processing) and resolves its Credit Hold exception everywhere.
   */
  approveCreditHold: (orderId: string) => void;
  /** Generic order status change, propagated to every page. */
  updateOrderStatus: (orderId: string, status: OrderStatus, holdReason?: string | null) => void;
  /** Resolve an exception by id (all pages listing it update). */
  resolveException: (exceptionId: string) => void;
  /** Apply an AI-proposed receipt match: receipt → Applied, invoice → Paid. */
  applyReceipt: (receiptId: string) => void;
  resolveDeduction: (deductionId: string, resolution: string) => void;
  approveProvision: () => void;
  releaseRegulatoryHold: (orderId: string, decision: string) => void;
  markOrderBilled: (orderId: string) => void;
  /** Human-approved invoice issue: creates the invoice record and marks the order billed. */
  /** Pass the invoice id from the invoice-to-cash clock for scenario orders. */
  issueInvoice: (orderId: string, fixedInvoiceId?: string) => void;
  sendQueryReply: (queryId: string) => void;
  capturePtp: (ptp: PromiseToPay) => void;
  /** Record a direct payment against an invoice: invoice → Paid everywhere. */
  markInvoicePaid: (invoiceId: string) => void;
  /** Begin a guided run for an order (resets any resolved/return state). */
  startRun: (orderId: string) => void;
  /** Mark that the human left the workspace to resolve `stage` on its page. */
  beginStageReturn: (stage: string) => void;
  /** Back in the workspace: record the return stage as resolved and clear it. */
  completeStageReturn: () => void;
  /** Workspace consumed the resume signal (prevents re-resuming). */
  consumeResume: () => void;
  /** Mark an order's guided run finished (all ten stages green). */
  markRunComplete: (orderId: string) => void;
  /** A run row on a downstream page asks the app to resolve the stage and return. */
  requestReturn: () => void;
  /** App consumed the return request. */
  consumeReturnRequest: () => void;
  /** End the run and clear the active-run state (keeps completed history). */
  endRun: () => void;

  /**
   * Human decision on a chargeback claim. Records the settlement split and
   * generates the credit note. Idempotent — a second click on the same claim
   * changes nothing.
   */
  recordClaimDecision: (
    input: Omit<ClaimDecision, "creditNoteId" | "decidedAt">
  ) => void;
  /** The human's pick at the deduction recovery gate. Nothing is sent yet. */
  chooseRecovery: (deductionId: string, option: string) => void;
  /** Human-approved dispute letter: this is the only thing that sends it. */
  sendDisputeLetter: (deductionId: string) => void;
  /** Close a channel deduction with the human's chosen resolution. */
  resolveChannelDeduction: (deductionId: string, resolution: string) => void;
  resolveShortPay: (caseId: string) => void;
  /** Human-approved posting of the reserve adjustment. Idempotent. */
  postReserveAdjustment: (entryId: string) => void;
  /** Raise a reversal request. Does not reverse anything on its own. */
  requestEntryReversal: (
    entryId: string,
    reasonCode: string,
    note: string
  ) => void;
  /**
   * Record (or clear, with null) a reviewer's manual split for a claim. The
   * claim selectors read this, so the posting, gross-to-net and letter all
   * recompute from the reviewer's figure.
   */
  setClaimEdit: (caseId: string, edit: ClaimEdit | null) => void;
  /** Human approval to post a cash application payment's resolution to SAP. */
  postCashPayment: (paymentId: string) => void;
}

const OtcStoreContext = createContext<(OtcState & OtcActions) | null>(null);

export function OtcStoreProvider({ children }: { children: ReactNode }) {
  const [orders, setOrders] = useState<Order[]>(seedOrders);
  const [exceptions, setExceptions] =
    useState<ExceptionRecord[]>(seedExceptions);
  const [allInvoices, setAllInvoices] = useState<Invoice[]>([
    ...seedInvoices,
    ...agedInvoices,
  ]);
  const [receipts, setReceipts] = useState<BankReceipt[]>(seedReceipts);
  const [deductionCases, setDeductionCases] =
    useState<DeductionCase[]>(seedDeductions);
  const [ptps, setPtps] = useState<PromiseToPay[]>(seedPtps);
  const [obligations] = useState<RevRecObligation[]>(seedObligations);
  const [queries, setQueries] = useState<CustomerQuery[]>(seedQueries);
  const [provisionStatus, setProvisionStatus] = useState<
    "Awaiting approval" | "Approved"
  >(seedApproval.status);
  const [releasedRegulatoryOrders, setReleasedRegulatoryOrders] = useState<
    Set<string>
  >(new Set());
  const [billedOrderIds, setBilledOrderIds] = useState<Set<string>>(new Set());
  const [claimDecisions, setClaimDecisions] = useState<ClaimDecision[]>([]);
  const [channelDeductionCases, setChannelDeductionCases] = useState<
    DeductionCase[]
  >(seedChannelDeductions);
  const [postedJournalEntries, setPostedJournalEntries] = useState<string[]>([]);
  const [reversalRequests, setReversalRequests] = useState<ReversalRequest[]>(
    []
  );

  const recordClaimDecision = useCallback(
    (input: Omit<ClaimDecision, "creditNoteId" | "decidedAt">) => {
      setClaimDecisions((prev) => {
        if (prev.some((d) => d.claimId === input.claimId)) return prev;
        const highest = prev.reduce(
          (max, d) => Math.max(max, parseInt(d.creditNoteId.replace("CN-", ""), 10)),
          2000
        );
        return [
          ...prev,
          { ...input, creditNoteId: `CN-${highest + 1}`, decidedAt: TODAY },
        ];
      });
    },
    []
  );

  const chooseRecovery = useCallback((deductionId: string, option: string) => {
    setChannelDeductionCases((prev) =>
      prev.map((d) =>
        d.deductionId === deductionId ? { ...d, chosenRecovery: option } : d
      )
    );
  }, []);

  const sendDisputeLetter = useCallback((deductionId: string) => {
    setChannelDeductionCases((prev) =>
      prev.map((d) =>
        d.deductionId === deductionId && d.disputeStatus !== "Sent"
          ? {
              ...d,
              disputeStatus: "Sent" as const,
              disputeSentDate: TODAY,
              status: "In Progress" as const,
            }
          : d
      )
    );
  }, []);

  const resolveChannelDeduction = useCallback(
    (deductionId: string, resolution: string) => {
      setChannelDeductionCases((prev) =>
        prev.map((d) =>
          d.deductionId === deductionId
            ? { ...d, status: "Resolved" as const, resolution }
            : d
        )
      );
    },
    []
  );

  const [resolvedShortPays, setResolvedShortPays] = useState<string[]>([]);
  const resolveShortPay = useCallback((caseId: string) => {
    setResolvedShortPays((prev) =>
      prev.includes(caseId) ? prev : [...prev, caseId]
    );
  }, []);

  const [resolvedPromoClaims, setResolvedPromoClaims] = useState<string[]>([]);
  const resolvePromoClaim = useCallback((caseId: string) => {
    setResolvedPromoClaims((prev) =>
      prev.includes(caseId) ? prev : [...prev, caseId]
    );
  }, []);

  const [resolvedDupClaims, setResolvedDupClaims] = useState<string[]>([]);
  const resolveDupClaim = useCallback((caseId: string) => {
    setResolvedDupClaims((prev) =>
      prev.includes(caseId) ? prev : [...prev, caseId]
    );
  }, []);

  const [resolvedRebateClaims, setResolvedRebateClaims] = useState<string[]>([]);
  const resolveRebateClaim = useCallback((caseId: string) => {
    setResolvedRebateClaims((prev) =>
      prev.includes(caseId) ? prev : [...prev, caseId]
    );
  }, []);

  const [resolvedFundClaims, setResolvedFundClaims] = useState<string[]>([]);
  const resolveFundClaim = useCallback((caseId: string) => {
    setResolvedFundClaims((prev) =>
      prev.includes(caseId) ? prev : [...prev, caseId]
    );
  }, []);

  const [resolvedMultiCauseDeductions, setResolvedMultiCauseDeductions] =
    useState<string[]>([]);
  const resolveMultiCauseDeduction = useCallback((caseId: string) => {
    setResolvedMultiCauseDeductions((prev) =>
      prev.includes(caseId) ? prev : [...prev, caseId]
    );
  }, []);

  const [resolvedBillingDisputes, setResolvedBillingDisputes] = useState<string[]>([]);
  const resolveBillingDispute = useCallback((caseId: string) => {
    setResolvedBillingDisputes((prev) =>
      prev.includes(caseId) ? prev : [...prev, caseId]
    );
  }, []);

  const [auditLog, setAuditLog] = useState<AuditEntry[]>(auditSeed);
  const auditCounterRef = useRef(auditSeed.length);
  const appendAudit = useCallback((input: AuditInput) => {
    auditCounterRef.current += 1;
    const entryId = `AUD-${40100 + auditCounterRef.current}`;
    setAuditLog((prev) => [
      ...prev,
      { ...input, entryId, at: input.at ?? runStamp() },
    ]);
  }, []);

  const [escalations, setEscalations] = useState<Escalation[]>(initialEscalations);
  const [freshEscalations, setFreshEscalations] = useState<string[]>([]);
  const raiseEscalation = useCallback((id: RunEscalationId) => {
    setEscalations((prev) =>
      prev.some((e) => e.id === id) ? prev : [buildRunEscalation(id), ...prev]
    );
    setFreshEscalations((prev) => (prev.includes(id) ? prev : [id, ...prev]));
  }, []);
  const advanceEscalation = useCallback(
    (id: string, status: EscalationStatus, by: string) => {
      setEscalations((prev) =>
        prev.map((e) =>
          e.id === id
            ? {
                ...e,
                status,
                chain: e.chain.map((s) =>
                  s.status === status && !s.at ? { ...s, at: RUN_DATE, by } : s
                ),
              }
            : e
        )
      );
    },
    []
  );
  const nudgeEscalation = useCallback((id: string, by: string) => {
    setEscalations((prev) =>
      prev.map((e) =>
        e.id === id
          ? {
              ...e,
              nudges: [
                ...e.nudges,
                { at: RUN_DATE, kind: "manual" as const, note: `Nudge sent to ${e.unit}`, by },
              ],
            }
          : e
      )
    );
  }, []);

  const [signatures, setSignatures] = useState<Record<string, AuditSignature[]>>({});
  const signGate = useCallback((gateId: string, sigs: AuditSignature[]) => {
    setSignatures((prev) => (prev[gateId] ? prev : { ...prev, [gateId]: sigs }));
  }, []);

  const [navIntent, setNavIntent] = useState<NavIntent | null>(null);
  const [focusAccountId, setFocusAccountId] = useState<string | null>(null);
  const [auditPreset, setAuditPreset] = useState<AuditPreset | null>(null);
  const [deductionLane, setDeductionLane] = useState<DeductionLane>("trade");
  const [pendingCaseId, setPendingCaseId] = useState<string | null>(null);
  const consumePendingCase = useCallback(() => setPendingCaseId(null), []);
  const requestNav = useCallback((intent: NavIntent) => {
    if (intent.accountId) setFocusAccountId(intent.accountId);
    setPendingCaseId(intent.caseId ?? null);
    if (intent.audit) setAuditPreset(intent.audit);
    if (intent.lane) setDeductionLane(intent.lane);
    setNavIntent(intent);
  }, []);
  const consumeNav = useCallback(() => setNavIntent(null), []);
  const clearAuditPreset = useCallback(() => setAuditPreset(null), []);

  const [nonTradeBatchPosted, setNonTradeBatchPosted] = useState(false);
  const postNonTradeBatch = useCallback(() => setNonTradeBatchPosted(true), []);
  const [resolvedShipments, setResolvedShipments] = useState<Record<string, string>>({});
  const resolveShipment = useCallback((caseId: string, outcome: string) => {
    setResolvedShipments((prev) => (prev[caseId] ? prev : { ...prev, [caseId]: outcome }));
  }, []);
  const [resolvedSplitOuts, setResolvedSplitOuts] = useState<
    Record<string, "credit" | "charge-back">
  >({});
  const resolveSplitOut = useCallback(
    (id: string, outcome: "credit" | "charge-back") => {
      setResolvedSplitOuts((prev) => (prev[id] ? prev : { ...prev, [id]: outcome }));
    },
    []
  );
  const [targetBilledAtContract, setTargetBilledAtContract] = useState(false);
  const billTargetAtContract = useCallback(() => setTargetBilledAtContract(true), []);

  const postReserveAdjustment = useCallback((entryId: string) => {
    setPostedJournalEntries((prev) =>
      prev.includes(entryId) ? prev : [...prev, entryId]
    );
  }, []);

  const requestEntryReversal = useCallback(
    (entryId: string, reasonCode: string, note: string) => {
      setReversalRequests((prev) =>
        prev.some((r) => r.entryId === entryId)
          ? prev
          : [...prev, { entryId, reasonCode, note, requestedAt: TODAY }]
      );
    },
    []
  );

  const [claimEdits, setClaimEdits] = useState<Record<string, ClaimEdit>>({});
  const setClaimEdit = useCallback(
    (caseId: string, edit: ClaimEdit | null) => {
      setClaimEdits((prev) => {
        if (edit === null) {
          if (!(caseId in prev)) return prev;
          const next = { ...prev };
          delete next[caseId];
          return next;
        }
        return { ...prev, [caseId]: edit };
      });
    },
    []
  );

  const [postedCashPayments, setPostedCashPayments] = useState<string[]>([]);
  const postCashPayment = useCallback((paymentId: string) => {
    setPostedCashPayments((prev) =>
      prev.includes(paymentId) ? prev : [...prev, paymentId]
    );
  }, []);

  const [openedCashDeductionCases, setOpenedCashDeductionCases] = useState<
    string[]
  >([]);
  const openCashDeductionCase = useCallback((lineId: string) => {
    setOpenedCashDeductionCases((prev) =>
      prev.includes(lineId) ? prev : [...prev, lineId]
    );
  }, []);
  const openCashDeductionCases = useCallback((lineIds: string[]) => {
    setOpenedCashDeductionCases((prev) => {
      const additions = lineIds.filter((id) => !prev.includes(id));
      return additions.length ? [...prev, ...additions] : prev;
    });
  }, []);

  const updateOrderStatus = useCallback(
    (orderId: string, status: OrderStatus, holdReason?: string | null) => {
      setOrders((prev) =>
        prev.map((o) =>
          o.orderId === orderId
            ? {
                ...o,
                status,
                holdReason:
                  holdReason === undefined ? o.holdReason : holdReason,
              }
            : o
        )
      );
    },
    []
  );

  const resolveException = useCallback((exceptionId: string) => {
    setExceptions((prev) =>
      prev.map((e) =>
        e.id === exceptionId ? { ...e, status: "Resolved" as const } : e
      )
    );
  }, []);

  const approveCreditHold = useCallback((orderId: string) => {
    setOrders((prev) =>
      prev.map((o) =>
        o.orderId === orderId
          ? { ...o, status: "Processing" as const, holdReason: null }
          : o
      )
    );
    setExceptions((prev) =>
      prev.map((e) =>
        e.orderId === orderId && e.type === "Credit Hold"
          ? { ...e, status: "Resolved" as const }
          : e
      )
    );
  }, []);

  const applyReceipt = useCallback((receiptId: string) => {
    setReceipts((prev) =>
      prev.map((r) =>
        r.receiptId === receiptId ? { ...r, status: "Applied" as const } : r
      )
    );
    setAllInvoices((prev) => {
      const receipt = seedReceipts.find((r) => r.receiptId === receiptId);
      if (!receipt?.proposedInvoiceId) return prev;
      return prev.map((inv) =>
        inv.invoiceId === receipt.proposedInvoiceId
          ? { ...inv, status: "Paid" as const }
          : inv
      );
    });
  }, []);

  const resolveDeduction = useCallback(
    (deductionId: string, resolution: string) => {
      setDeductionCases((prev) =>
        prev.map((d) =>
          d.deductionId === deductionId
            ? { ...d, status: "Resolved" as const, resolution }
            : d
        )
      );
    },
    []
  );

  const approveProvision = useCallback(() => {
    setProvisionStatus("Approved");
  }, []);

  const releaseRegulatoryHold = useCallback(
    (orderId: string, _decision: string) => {
      void _decision;
      setReleasedRegulatoryOrders((prev) => new Set(prev).add(orderId));
    },
    []
  );

  const markOrderBilled = useCallback((orderId: string) => {
    setBilledOrderIds((prev) => new Set(prev).add(orderId));
  }, []);

  const issueInvoice = useCallback((orderId: string, fixedInvoiceId?: string) => {
    setAllInvoices((prev) => {
      if (prev.some((inv) => inv.orderId === orderId)) return prev;
      const order = seedOrders.find((o) => o.orderId === orderId);
      if (!order) return prev;
      const i2c = fixedInvoiceId ? invoiceToCashFor(orderId) : null;
      const maxId = Math.max(
        ...prev
          .map((inv) => parseInt(inv.invoiceId.replace("INV-", ""), 10))
          .filter((n) => n < 100_000)
      );
      return [
        ...prev,
        {
          invoiceId: fixedInvoiceId ?? `INV-${maxId + 1}`,
          orderId: order.orderId,
          customerId: order.customerId,
          customerName: order.customerName,
          invoiceDate: i2c?.invoiceDate ?? TODAY,
          dueDate: i2c?.dueDate ?? daysAfterToday(30),
          amount: i2c?.amountUsd ?? order.totalValue,
          status: "Sent" as const,
        },
      ];
    });
    setBilledOrderIds((prev) => new Set(prev).add(orderId));
  }, []);

  const sendQueryReply = useCallback((queryId: string) => {
    setQueries((prev) =>
      prev.map((query) =>
        query.queryId === queryId
          ? { ...query, status: "Sent" as const }
          : query
      )
    );
  }, []);

  const capturePtp = useCallback((ptp: PromiseToPay) => {
    setPtps((prev) => [...prev, ptp]);
  }, []);

  const markInvoicePaid = useCallback((invoiceId: string) => {
    setAllInvoices((prev) =>
      prev.map((invoice) =>
        invoice.invoiceId === invoiceId
          ? { ...invoice, status: "Paid" as const }
          : invoice
      )
    );
  }, []);

  const [runOrderId, setRunOrderId] = useState<string | null>(null);
  const [runResolvedStages, setRunResolvedStages] = useState<string[]>([]);
  const [runReturnStage, setRunReturnStage] = useState<string | null>(null);
  const [runResumePending, setRunResumePending] = useState(false);
  const [completedRunOrders, setCompletedRunOrders] = useState<string[]>([]);
  const [returnRequested, setReturnRequested] = useState(false);

  const startRun = useCallback((orderId: string) => {
    setRunOrderId(orderId);
    setRunResolvedStages([]);
    setRunReturnStage(null);
    setRunResumePending(false);
  }, []);
  const beginStageReturn = useCallback((stage: string) => {
    setRunReturnStage(stage);
  }, []);
  const completeStageReturn = useCallback(() => {
    setRunReturnStage((stage) => {
      if (stage) {
        setRunResolvedStages((prev) =>
          prev.includes(stage) ? prev : [...prev, stage]
        );
      }
      return null;
    });
    setRunResumePending(true);
  }, []);
  const consumeResume = useCallback(() => setRunResumePending(false), []);
  const markRunComplete = useCallback((orderId: string) => {
    setCompletedRunOrders((prev) =>
      prev.includes(orderId) ? prev : [...prev, orderId]
    );
  }, []);
  const requestReturn = useCallback(() => setReturnRequested(true), []);
  const consumeReturnRequest = useCallback(
    () => setReturnRequested(false),
    []
  );
  const endRun = useCallback(() => {
    setRunOrderId(null);
    setRunResolvedStages([]);
    setRunReturnStage(null);
    setRunResumePending(false);
  }, []);

  const value = useMemo(
    () => ({
      orders,
      exceptions,
      approveCreditHold,
      updateOrderStatus,
      resolveException,
      allInvoices,
      receipts,
      deductionCases,
      ptps,
      obligations,
      queries,
      provisionStatus,
      provisionApprover: seedApproval.approver,
      releasedRegulatoryOrders,
      billedOrderIds,
      runOrderId,
      runResolvedStages,
      runReturnStage,
      runResumePending,
      completedRunOrders,
      returnRequested,
      claimDecisions,
      channelDeductionCases,
      resolvedShortPays,
      resolvedPromoClaims,
      resolvedDupClaims,
      resolvedRebateClaims,
      resolvedFundClaims,
      resolvedMultiCauseDeductions,
      resolveMultiCauseDeduction,
      resolvedBillingDisputes,
      auditLog,
      appendAudit,
      escalations,
      freshEscalations,
      raiseEscalation,
      advanceEscalation,
      nudgeEscalation,
      signatures,
      signGate,
      navIntent,
      requestNav,
      consumeNav,
      focusAccountId,
      pendingCaseId,
      consumePendingCase,
      auditPreset,
      clearAuditPreset,
      deductionLane,
      setDeductionLane,
      nonTradeBatchPosted,
      postNonTradeBatch,
      resolvedShipments,
      resolveShipment,
      resolvedSplitOuts,
      resolveSplitOut,
      targetBilledAtContract,
      billTargetAtContract,
      postedJournalEntries,
      reversalRequests,
      claimEdits,
      recordClaimDecision,
      chooseRecovery,
      sendDisputeLetter,
      resolveChannelDeduction,
      resolveShortPay,
      resolvePromoClaim,
      resolveDupClaim,
      resolveRebateClaim,
      resolveFundClaim,
      resolveBillingDispute,
      postReserveAdjustment,
      requestEntryReversal,
      setClaimEdit,
      applyReceipt,
      resolveDeduction,
      approveProvision,
      releaseRegulatoryHold,
      markOrderBilled,
      issueInvoice,
      sendQueryReply,
      capturePtp,
      markInvoicePaid,
      startRun,
      beginStageReturn,
      completeStageReturn,
      consumeResume,
      markRunComplete,
      requestReturn,
      consumeReturnRequest,
      endRun,
      postedCashPayments,
      postCashPayment,
      openedCashDeductionCases,
      openCashDeductionCase,
      openCashDeductionCases,
    }),
    [
      orders,
      exceptions,
      approveCreditHold,
      updateOrderStatus,
      resolveException,
      allInvoices,
      receipts,
      deductionCases,
      ptps,
      obligations,
      queries,
      provisionStatus,
      releasedRegulatoryOrders,
      billedOrderIds,
      runOrderId,
      runResolvedStages,
      runReturnStage,
      runResumePending,
      completedRunOrders,
      returnRequested,
      claimDecisions,
      channelDeductionCases,
      resolvedShortPays,
      resolvedPromoClaims,
      resolvedDupClaims,
      resolvedRebateClaims,
      resolvedFundClaims,
      resolvedMultiCauseDeductions,
      resolveMultiCauseDeduction,
      resolvedBillingDisputes,
      auditLog,
      appendAudit,
      escalations,
      freshEscalations,
      raiseEscalation,
      advanceEscalation,
      nudgeEscalation,
      signatures,
      signGate,
      navIntent,
      requestNav,
      consumeNav,
      focusAccountId,
      pendingCaseId,
      consumePendingCase,
      auditPreset,
      clearAuditPreset,
      deductionLane,
      setDeductionLane,
      nonTradeBatchPosted,
      postNonTradeBatch,
      resolvedShipments,
      resolveShipment,
      resolvedSplitOuts,
      resolveSplitOut,
      targetBilledAtContract,
      billTargetAtContract,
      postedJournalEntries,
      reversalRequests,
      claimEdits,
      recordClaimDecision,
      chooseRecovery,
      sendDisputeLetter,
      resolveChannelDeduction,
      resolveShortPay,
      resolvePromoClaim,
      resolveDupClaim,
      resolveRebateClaim,
      resolveFundClaim,
      resolveBillingDispute,
      postReserveAdjustment,
      requestEntryReversal,
      setClaimEdit,
      applyReceipt,
      resolveDeduction,
      approveProvision,
      releaseRegulatoryHold,
      markOrderBilled,
      issueInvoice,
      sendQueryReply,
      capturePtp,
      markInvoicePaid,
      startRun,
      beginStageReturn,
      completeStageReturn,
      consumeResume,
      markRunComplete,
      requestReturn,
      consumeReturnRequest,
      endRun,
      postedCashPayments,
      postCashPayment,
      openedCashDeductionCases,
      openCashDeductionCase,
      openCashDeductionCases,
    ]
  );

  return (
    <OtcStoreContext.Provider value={value}>
      {children}
    </OtcStoreContext.Provider>
  );
}

export function useOtcStore() {
  const ctx = useContext(OtcStoreContext);
  if (!ctx) {
    throw new Error("useOtcStore must be used inside OtcStoreProvider");
  }
  return ctx;
}
