/**
 * Every figure the Chargebacks page displays, derived here and nowhere else.
 *
 * ATTRIBUTION ORDER IS LOAD-BEARING. Unsupported value is walked QUANTITY
 * FIRST - undocumented units are removed at the adjustment the wholesaler
 * claimed - and only then is the price corrected on the units that survive.
 * Walking price first totals the same but splits the causes differently
 * ($800,000 / $400,000 instead of $480,000 / $720,000), so the order is fixed
 * here and printed on the screen that shows the split.
 */

import { findProduct } from "./data/products";
import { distributorNetPrice } from "./data/channel-agreements";
import {
  activityFor,
  type ClaimPeriodActivityRow,
} from "./data/claim-period-activity";
import {
  allocationCeilingUnits,
  effectivePriceRecord,
  findClaimPeriod,
  periodMonths,
  priceRecordsFor,
  type ClaimPeriod,
  type ContractPriceRecord,
} from "./data/contract-pricing";
import {
  findDistributor,
  findEndCustomer,
  findRoster,
  isOnRoster,
  rosterFor,
  rosterMembers,
  type ContractRoster,
  type EndCustomer,
} from "./data/distributors";
import { customers } from "./data/customers";
import {
  chargebackClaims,
  findClaim,
  findSettledClaim,
  settledClaims,
  type ChargebackClaim,
  type ChargebackClaimLine,
  type RiskDimensionScore,
  type SettledClaim,
} from "./data/chargebacks";
import { monthlyAllocationCapUnits } from "./data/inventory";
import {
  findClaimSubmission,
  type ClaimSubmission,
  type ClaimSubmissionLine,
} from "./data/claim-submission";
import { daysBetween } from "./data/clock";

export const UNSUPPORTED_WALK_ORDER = ["quantity", "price"] as const;

export const UNSUPPORTED_WALK_NOTE =
  "Undocumented units are removed first, at the adjustment the wholesaler claimed. The price is then corrected on the units that remain.";

/* ------------------------------------------------------------------ *
 * Who the project is
 * ------------------------------------------------------------------ */

export interface RosterCheck {
  citedRoster?: ContractRoster;
  members: { endCustomer: EndCustomer; effectiveFrom: string }[];
  claimedEndCustomer?: EndCustomer;
  onCitedRoster: boolean;
  /** A project in the same owner group that IS on the cited roster. */
  siblingOnRoster?: EndCustomer;
  homeRoster?: ContractRoster;
  homePriceRecord?: ContractPriceRecord;
}

export function rosterCheck(claimId: string): RosterCheck {
  const claim = findClaim(claimId);
  const line = claim?.lines[0];
  const period = claim ? findClaimPeriod(claim.periodId) : undefined;
  if (!claim || !line || !period) {
    return { members: [], onCitedRoster: false };
  }

  const citedRoster = findRoster(line.citedRosterId);
  const claimedEndCustomer = findEndCustomer(line.endCustomerId);
  const members = rosterMembers(line.citedRosterId).map((m) => ({
    endCustomer: m.endCustomer,
    effectiveFrom: m.membership.effectiveFrom,
  }));

  const onCitedRoster = isOnRoster(
    line.citedRosterId,
    line.endCustomerId,
    period.to
  );

  const siblingOnRoster = claimedEndCustomer
    ? members.find(
        (m) =>
          m.endCustomer.ownerGroup === claimedEndCustomer.ownerGroup &&
          m.endCustomer.endCustomerId !== claimedEndCustomer.endCustomerId
      )?.endCustomer
    : undefined;

  const homeRoster = rosterFor(line.endCustomerId, period.to);
  const homePriceRecord = homeRoster
    ? effectivePriceRecord(line.sku, homeRoster.contractId, period.to)
    : undefined;

  return {
    citedRoster,
    members,
    claimedEndCustomer,
    onCitedRoster,
    siblingOnRoster,
    homeRoster,
    homePriceRecord,
  };
}

/* ------------------------------------------------------------------ *
 * How many units we can actually account for
 * ------------------------------------------------------------------ */

export interface ClaimPeriodUnits {
  period?: ClaimPeriod;
  inPeriodRows: ClaimPeriodActivityRow[];
  excludedRows: ClaimPeriodActivityRow[];
  supportedUnits: number;
  excludedUnits: number;
}

export function claimPeriodUnits(claimId: string): ClaimPeriodUnits {
  const claim = findClaim(claimId);
  const line = claim?.lines[0];
  const period = claim ? findClaimPeriod(claim.periodId) : undefined;
  if (!claim || !line || !period) {
    return {
      inPeriodRows: [],
      excludedRows: [],
      supportedUnits: 0,
      excludedUnits: 0,
    };
  }

  const rows = activityFor(claim.distributorId, line.endCustomerId, line.sku);
  const inPeriodRows = rows.filter(
    (r) => r.invoiceDate >= period.from && r.invoiceDate <= period.to
  );
  const excludedRows = rows.filter(
    (r) => r.invoiceDate < period.from || r.invoiceDate > period.to
  );

  return {
    period,
    inPeriodRows,
    excludedRows,
    supportedUnits: inPeriodRows.reduce((sum, r) => sum + r.units, 0),
    excludedUnits: excludedRows.reduce((sum, r) => sum + r.units, 0),
  };
}

export interface AllocationCeiling {
  months: number;
  capPerMonth: number;
  ceilingUnits: number;
  claimedUnits: number;
  exceedsBy: number;
  exceeds: boolean;
  label: string;
}

/**
 * The most units that could physically have reached one wholesaler in the
 * claim window. An upper bound only - it says nothing about how much of the
 * monthly limit was actually used.
 */
export function allocationCeiling(claimId: string): AllocationCeiling | null {
  const claim = findClaim(claimId);
  const line = claim?.lines[0];
  const period = claim ? findClaimPeriod(claim.periodId) : undefined;
  if (!claim || !line || !period) return null;

  const product = findProduct(line.sku);
  if (!product?.allocationControlled) return null;

  const months = periodMonths(period);
  const ceilingUnits = allocationCeilingUnits(period);
  const exceedsBy = Math.max(0, line.claimedUnits - ceilingUnits);

  return {
    months,
    capPerMonth: monthlyAllocationCapUnits,
    ceilingUnits,
    claimedUnits: line.claimedUnits,
    exceedsBy,
    exceeds: exceedsBy > 0,
    label: `${months} months at a ${monthlyAllocationCapUnits.toLocaleString()}-unit monthly limit`,
  };
}

/* ------------------------------------------------------------------ *
 * The money
 * ------------------------------------------------------------------ */

export interface ClaimLineMath {
  line: ChargebackClaimLine;
  listPrice: number;
  approvedContractPrice: number;
  approvedPriceRecord?: ContractPriceRecord;
  claimedContractPrice: number;
  approvedAdjustment: number;
  claimedAdjustment: number;
  unsupportedRateDelta: number;
  pctBelowApproved: number;
  claimedUnits: number;
  supportedUnits: number;
  unitsException: number;
  claimedAmount: number;
  supportableAmount: number;
  unsupportedAmount: number;
  /** Walked first: units with no paperwork, at the claimed adjustment. */
  quantityComponent: number;
  /** Walked second: price correction on the units that survived. */
  priceComponent: number;
}

export function claimLineMath(claimId: string): ClaimLineMath | null {
  const claim = findClaim(claimId);
  const line = claim?.lines[0];
  if (!claim || !line) return null;

  const product = findProduct(line.sku);
  const check = rosterCheck(claimId);
  const approvedPriceRecord = check.homePriceRecord;
  if (!product || !approvedPriceRecord) return null;

  // What the wholesaler ACTUALLY paid us, from the distribution agreement -
  // not the product list price. A wholesaler never buys at list, so a list
  // price in this subtraction inflates the claim and every figure below it.
  const listPrice = distributorNetPrice(line.sku);
  const approvedContractPrice = approvedPriceRecord.contractPrice;
  const claimedContractPrice = line.claimedContractPrice;

  const approvedAdjustment = listPrice - approvedContractPrice;
  const claimedAdjustment = listPrice - claimedContractPrice;
  const unsupportedRateDelta = approvedContractPrice - claimedContractPrice;

  const claimedUnits = line.claimedUnits;
  const supportedUnits = claimPeriodUnits(claimId).supportedUnits;
  const unitsException = Math.max(0, claimedUnits - supportedUnits);

  const claimedAmount = claimedUnits * claimedAdjustment;
  const supportableAmount = supportedUnits * approvedAdjustment;
  const unsupportedAmount = claimedAmount - supportableAmount;

  // Quantity is walked first — see UNSUPPORTED_WALK_ORDER.
  const quantityComponent = unitsException * claimedAdjustment;
  const priceComponent = supportedUnits * unsupportedRateDelta;

  const math: ClaimLineMath = {
    line,
    listPrice,
    approvedContractPrice,
    approvedPriceRecord,
    claimedContractPrice,
    approvedAdjustment,
    claimedAdjustment,
    unsupportedRateDelta,
    pctBelowApproved:
      approvedContractPrice === 0
        ? 0
        : unsupportedRateDelta / approvedContractPrice,
    claimedUnits,
    supportedUnits,
    unitsException,
    claimedAmount,
    supportableAmount,
    unsupportedAmount,
    quantityComponent,
    priceComponent,
  };

  if (
    process.env.NODE_ENV !== "production" &&
    math.quantityComponent + math.priceComponent !== math.unsupportedAmount
  ) {
    console.error(
      `[chargeback] ${claimId}: the unsupported walk does not tie out`,
      math
    );
  }

  return math;
}

/** The rungs of the price bridge, list price down to what was claimed. */
export interface PriceLadderRung {
  key: "wac" | "approvedAdjustment" | "approved";
  label: string;
  value: number;
  kind: "anchor" | "supportedStep" | "unsupportedStep";
  evidence: { ref: string; label: string } | null;
  /**
   * How to fill the bar. "split" divides it at the adjustment: the part the
   * wholesaler reclaims above, the part the project pays below - so the whole
   * chargeback reads off one column.
   */
  fill: "split" | "reclaimed" | "project";
  /** For "split", the share reclaimed, 0-1. */
  reclaimedShare?: number;
}

export function priceLadder(claimId: string): PriceLadderRung[] {
  const math = claimLineMath(claimId);
  const check = rosterCheck(claimId);
  if (!math) return [];

  // Three columns, not five. The list price left the model, and the last two
  // rungs described a price gap that no longer exists now that the project is
  // entitled to the price it was charged.
  return [
    {
      key: "wac",
      label: "Price invoiced to the wholesaler",
      value: math.listPrice,
      kind: "anchor",
      evidence: {
        ref: math.line.sku,
        label: "Distribution agreement with this wholesaler",
      },
      fill: "split",
      reclaimedShare:
        math.listPrice === 0 ? 0 : math.approvedAdjustment / math.listPrice,
    },
    {
      key: "approvedAdjustment",
      label: "Contract adjustment we approved",
      value: math.approvedAdjustment,
      kind: "supportedStep",
      evidence: math.approvedPriceRecord
        ? {
            ref: math.approvedPriceRecord.priceRecordId,
            label: `${math.approvedPriceRecord.approvalRef}, in force from ${math.approvedPriceRecord.effectiveFrom}`,
          }
        : null,
      fill: "reclaimed",
    },
    {
      key: "approved",
      label: "Price the project pays",
      value: math.approvedContractPrice,
      kind: "anchor",
      evidence: check.citedRoster
        ? { ref: check.citedRoster.contractId, label: check.citedRoster.label }
        : null,
      fill: "project",
    },
  ];
}

/* ------------------------------------------------------------------ *
 * The score
 * ------------------------------------------------------------------ */

export interface ClaimRiskScore {
  dimensions: RiskDimensionScore[];
  weightedTotal: number;
  score: number;
  weightsSum: number;
  /** How far the evidence supports the recommendation, 0-100. */
  confidencePercent: number;
  vetoed: boolean;
  vetoReason?: string;
}

export function claimRiskScore(claimId: string): ClaimRiskScore {
  const claim = findClaim(claimId);
  if (!claim) {
    return {
      dimensions: [],
      weightedTotal: 0,
      score: 0,
      weightsSum: 0,
      confidencePercent: 0,
      vetoed: false,
    };
  }

  const weightedTotal = claim.dimensions.reduce(
    (sum, d) => sum + d.weight * d.score,
    0
  );
  const weightsSum = claim.dimensions.reduce((sum, d) => sum + d.weight, 0);

  return {
    dimensions: claim.dimensions,
    weightedTotal,
    // A confirmed duplicate is maximal exception severity by rule. Scoring it
    // through the weights returns about 30, which reads as low risk on a claim
    // that must be rejected outright.
    score: claim.duplicateVeto ? 100 : Math.round(weightedTotal),
    weightsSum,
    confidencePercent: Math.round(claim.aiConfidence * 100),
    vetoed: claim.duplicateVeto,
    vetoReason: claim.duplicateVeto
      ? `Already settled as ${claim.duplicateOfClaimId} — a confirmed duplicate is rejected outright, not scored.`
      : undefined,
  };
}

/* ------------------------------------------------------------------ *
 * What the AI recommends the human do
 * ------------------------------------------------------------------ */

export interface RecommendedSettlement {
  approveAmount: number;
  rejectAmount: number;
  priceComponent: number;
  quantityComponent: number;
  claimedTotal: number;
  placePaymentBlock: boolean;
  label: string;
}

export function recommendedSettlement(
  claimId: string
): RecommendedSettlement | null {
  const claim = findClaim(claimId);
  const math = claimLineMath(claimId);
  if (!claim || !math) return null;

  if (claim.duplicateVeto) {
    return {
      approveAmount: 0,
      rejectAmount: math.claimedAmount,
      priceComponent: 0,
      quantityComponent: 0,
      claimedTotal: math.claimedAmount,
      placePaymentBlock: false,
      label: "Reject in full — already settled",
    };
  }

  return {
    approveAmount: math.supportableAmount,
    rejectAmount: math.unsupportedAmount,
    priceComponent: math.priceComponent,
    quantityComponent: math.quantityComponent,
    claimedTotal: math.claimedAmount,
    placePaymentBlock: math.unsupportedAmount > 0,
    label:
      math.unsupportedAmount > 0 ? "Approve in part" : "Approve the full claim",
  };
}

/* ------------------------------------------------------------------ *
 * What paying it would do to the price we report
 * ------------------------------------------------------------------ */

/* ------------------------------------------------------------------ *
 * Duplicate screening
 * ------------------------------------------------------------------ */

export interface DuplicateComparison {
  candidate: ChargebackClaim;
  settled: SettledClaim;
  fields: {
    label: string;
    candidateValue: string;
    settledValue: string;
    match: boolean;
  }[];
  matchConfidence: number;
  daysSinceSettled: number;
}

export function duplicateComparison(
  claimId: string
): DuplicateComparison | null {
  const candidate = findClaim(claimId);
  if (!candidate?.duplicateOfClaimId) return null;
  const settled = findSettledClaim(candidate.duplicateOfClaimId);
  const line = candidate.lines[0];
  if (!settled || !line) return null;

  const settledAmount = settled.settledAmount;
  const candidateMath = claimLineMath(claimId);

  const fields = [
    {
      label: "Claim number",
      candidateValue: candidate.claimId,
      settledValue: settled.claimId,
      match: false,
    },
    {
      label: "Wholesaler",
      // The trading name, never the internal distributor id.
      candidateValue: distributorName(candidate.distributorId),
      settledValue: distributorName(settled.distributorId),
      match: candidate.distributorId === settled.distributorId,
    },
    {
      label: "End customer",
      candidateValue: findEndCustomer(line.endCustomerId)?.name ?? "—",
      settledValue: findEndCustomer(settled.endCustomerId)?.name ?? "—",
      match: line.endCustomerId === settled.endCustomerId,
    },
    {
      label: "Product",
      candidateValue: line.productName,
      settledValue: findProduct(settled.sku)?.name ?? settled.sku,
      match: line.sku === settled.sku,
    },
    {
      label: "Claim window",
      candidateValue: findClaimPeriod(candidate.periodId)?.label ?? "—",
      settledValue: findClaimPeriod(settled.periodId)?.label ?? "—",
      match: candidate.periodId === settled.periodId,
    },
    {
      label: "Units",
      candidateValue: line.claimedUnits.toLocaleString(),
      settledValue: settled.units.toLocaleString(),
      match: line.claimedUnits === settled.units,
    },
    {
      label: "Amount",
      candidateValue: formatUsd(candidateMath?.claimedAmount ?? 0),
      settledValue: formatUsd(settledAmount),
      match: candidateMath?.claimedAmount === settledAmount,
    },
  ];

  return {
    candidate,
    settled,
    fields,
    matchConfidence: candidate.matchConfidence ?? 0,
    daysSinceSettled: daysBetween(settled.settledDate),
  };
}

/* ------------------------------------------------------------------ *
 * The queue
 * ------------------------------------------------------------------ */

export interface ClaimQueueRow {
  claimId: string;
  wholesaler: string;
  endCustomer: string;
  product: string;
  claimedAmount: number;
  supportableAmount: number;
  /** The composite, or null where no score applies (duplicates, settled). */
  score: number | null;
  /** Why the claim scores as it does, in one phrase. */
  reason: string;
  vetoed: boolean;
  status: ClaimQueueStatus;
  decided: boolean;
}

/** The findings driving a claim's score, as a single phrase for the queue. */
function queueReason(claim: ChargebackClaim): string {
  if (claim.duplicateVeto) {
    return `Already settled as ${claim.duplicateOfClaimId}`;
  }
  const material = claim.dimensions.filter((d) => d.score >= 70);
  if (material.length === 0) return "Within tolerance — routine review";

  const names: Record<RiskDimensionScore["key"], string> = {
    eligibility: "project not on the cited contract",
    pricing: "price below the approved record",
    duplicate: "submission integrity",
    quantity: "units without delivery records",
  };
  const listed = material.slice(0, 2).map((d) => names[d.key]);
  const rest = material.length - listed.length;
  const phrase = listed.join(", ") + (rest > 0 ? `, +${rest} more` : "");
  return phrase.charAt(0).toUpperCase() + phrase.slice(1);
}

export type ClaimQueueStatus = "Waiting on you" | "Decided" | "Settled";

/**
 * The wholesaler's trading name. Read from the customer master rather than
 * restated, so it stays in step with every other page.
 */
export function distributorName(distributorId: string): string {
  const distributor = findDistributor(distributorId);
  if (!distributor) return distributorId;
  return (
    customers.find((c) => c.customerId === distributor.customerId)?.name ??
    distributorId
  );
}

export function claimQueueRows(
  decidedClaimIds: string[] = []
): ClaimQueueRow[] {
  const open: ClaimQueueRow[] = chargebackClaims.map((claim) => {
    const line = claim.lines[0];
    const math = claimLineMath(claim.claimId);
    const decided = decidedClaimIds.includes(claim.claimId);
    return {
      claimId: claim.claimId,
      wholesaler: distributorName(claim.distributorId),
      endCustomer: findEndCustomer(line.endCustomerId)?.name ?? "—",
      product: line.productName,
      claimedAmount: math?.claimedAmount ?? 0,
      supportableAmount: claim.duplicateVeto
        ? 0
        : (math?.supportableAmount ?? 0),
      // A duplicate is vetoed, not scored — printing 0 would read as low risk.
      score: claimRiskScore(claim.claimId).score,
      reason: queueReason(claim),
      vetoed: claim.duplicateVeto,
      status: decided ? "Decided" : "Waiting on you",
      decided,
    };
  });

  const settled: ClaimQueueRow[] = settledClaims.map((s) => ({
    claimId: s.claimId,
    wholesaler: distributorName(s.distributorId),
    endCustomer: findEndCustomer(s.endCustomerId)?.name ?? "—",
    product: findProduct(s.sku)?.name ?? s.sku,
    claimedAmount: s.settledAmount,
    supportableAmount: s.settledAmount,
    score: null,
    reason: `Settled ${s.settledDate}`,
    vetoed: false,
    status: "Settled",
    decided: true,
  }));

  return [...open, ...settled];
}

export interface ChargebackQueueSummary {
  claimsWaiting: number;
  valueClaimed: number;
  valueSupportable: number;
  valueNotSupported: number;
}

export function chargebackQueueSummary(
  decidedClaimIds: string[] = []
): ChargebackQueueSummary {
  const waiting = chargebackClaims.filter(
    (c) => !decidedClaimIds.includes(c.claimId)
  );

  const valueClaimed = waiting.reduce(
    (sum, c) => sum + (claimLineMath(c.claimId)?.claimedAmount ?? 0),
    0
  );
  const valueSupportable = waiting.reduce(
    (sum, c) =>
      sum + (c.duplicateVeto ? 0 : (claimLineMath(c.claimId)?.supportableAmount ?? 0)),
    0
  );

  return {
    claimsWaiting: waiting.length,
    valueClaimed,
    valueSupportable,
    valueNotSupported: valueClaimed - valueSupportable,
  };
}

/* ------------------------------------------------------------------ *
 * Formatting
 * ------------------------------------------------------------------ */

/** Whole dollars, no cents — claim values are always round here. */
export function formatUsd(value: number): string {
  return `$${Math.round(value).toLocaleString("en-US")}`;
}

/** Per-unit prices, always two decimals. */
export function formatUnitPrice(value: number): string {
  return `$${value.toFixed(2)}`;
}

/** Millions to one decimal, so a zero balance reads "$0.0M" rather than "$0". */
export function formatMoneyMillions(value: number): string {
  return `$${(value / 1_000_000).toFixed(1)}M`;
}

export { priceRecordsFor };

/* ------------------------------------------------------------------ *
 * The submission the wholesaler sent
 * ------------------------------------------------------------------ */

export interface ClaimSubmissionTotals {
  submission?: ClaimSubmission;
  lines: ClaimSubmissionLine[];
  /** Lines a shipment of ours accounts for. Established at the volume stage. */
  supportedLines: ClaimSubmissionLine[];
  unsupportedLines: ClaimSubmissionLine[];
  totalUnits: number;
  supportedUnits: number;
  unsupportedUnits: number;
  totalClaimed: number;
}

/**
 * Sums over the resale lines the wholesaler filed.
 *
 * The units and the total on the intake panel ARE these sums, so the document
 * a client opens and the figure printed beside it cannot drift apart. Every
 * relationship is asserted rather than assumed, because a submission that does
 * not reconcile is the one thing this document must never be.
 */
export function claimSubmissionTotals(claimId: string): ClaimSubmissionTotals {
  const submission = findClaimSubmission(claimId);
  const lines = submission?.lines ?? [];
  const supportedLines = lines.filter((l) => l.supportedByInvoiceRef !== null);
  const unsupportedLines = lines.filter((l) => l.supportedByInvoiceRef === null);

  const sumUnits = (rows: ClaimSubmissionLine[]) =>
    rows.reduce((sum, l) => sum + l.units, 0);

  const math = claimLineMath(claimId);
  const totals: ClaimSubmissionTotals = {
    submission,
    lines,
    supportedLines,
    unsupportedLines,
    totalUnits: sumUnits(lines),
    supportedUnits: sumUnits(supportedLines),
    unsupportedUnits: sumUnits(unsupportedLines),
    totalClaimed: lines.reduce(
      (sum, l) => sum + l.units * ((math?.listPrice ?? 0) - l.resalePrice),
      0
    ),
  };

  if (process.env.NODE_ENV !== "production" && submission && math) {
    const activityRefs = new Set(
      claimPeriodUnits(claimId).inPeriodRows.map((r) => r.invoiceRef)
    );
    const fail = (msg: string, detail: unknown) =>
      console.error(`[chargeback] ${claimId} submission: ${msg}`, detail);

    if (totals.totalUnits !== math.claimedUnits)
      fail("line units do not sum to the units claimed", {
        lines: totals.totalUnits,
        claimed: math.claimedUnits,
      });
    if (totals.supportedUnits !== math.supportedUnits)
      fail("supported lines do not sum to the units we invoiced", {
        lines: totals.supportedUnits,
        invoiced: math.supportedUnits,
      });
    if (totals.unsupportedUnits !== math.unitsException)
      fail("unsupported lines do not sum to the quantity exception", {
        lines: totals.unsupportedUnits,
        exception: math.unitsException,
      });
    if (totals.totalClaimed !== math.claimedAmount)
      fail("line value does not sum to the amount claimed", {
        lines: totals.totalClaimed,
        claimed: math.claimedAmount,
      });
    for (const l of lines) {
      if (l.resalePrice !== math.claimedContractPrice)
        fail(`${l.lineRef} carries a price the claim does not`, l.resalePrice);
      if (l.supportedByInvoiceRef && !activityRefs.has(l.supportedByInvoiceRef))
        fail(`${l.lineRef} cites an invoice outside the claim window`, l);
    }
  }

  return totals;
}

/* ------------------------------------------------------------------ *
 * What the AI says at each stage
 * ------------------------------------------------------------------ */

/**
 * One short line per stage, derived rather than written.
 *
 * The previous lines ran 170-330 characters and read as paragraphs; a reviewer
 * scanning a rail wants the finding, not an explanation of it. Each line is
 * now a single statement built from the same figures the panel below it shows,
 * so a change to a price or a quantity moves the sentence with it and the two
 * can never disagree.
 */
export function stageNarration(
  claimId: string,
  stageId: string
): string | string[] {
  const claim = findClaim(claimId);
  const math = claimLineMath(claimId);
  if (!claim || !math) return "";

  const units = (n: number) => n.toLocaleString("en-US");

  if (claim.duplicateVeto) {
    const twin = claim.duplicateOfClaimId ?? "a settled claim";
    switch (stageId) {
      case "claim_intake":
        return `Claim received: ${formatUsd(math.claimedAmount)}. Matches a settled claim.`;
      case "duplicate_check":
        return `Identical to ${twin} on every field but the claim number.`;
      case "decision":
        return `Reject in full — already settled under ${twin}.`;
      default:
        return "";
    }
  }

  const settlement = recommendedSettlement(claimId);
  const check = rosterCheck(claimId);
  const project = check.claimedEndCustomer?.name ?? "the end buyer";
  const wholesaler = distributorName(claim.distributorId);
  const contract = claim.lines[0].citedContractId;

  // Name the subject. A line that says "the project" or "the contract cited"
  // makes the reader look it up; naming it lands the point in one read.
  switch (stageId) {
    case "claim_intake":
      return `${wholesaler} claims a chargeback of ${formatUsd(math.claimedAmount)} on ${units(math.claimedUnits)} units.`;
    case "customer_check":
      return check.onCitedRoster
        ? `End buyer ${project} is on the roster of contract ${contract}.`
        : `End buyer ${project} is not on the roster of contract ${contract}.`;
    case "price_check":
      return math.unsupportedRateDelta === 0
        ? `Claimed ${formatUnitPrice(math.claimedContractPrice)} matches contract ${contract}.`
        : `Claimed ${formatUnitPrice(math.claimedContractPrice)} is ${formatUnitPrice(math.unsupportedRateDelta)} under contract ${contract}.`;
    case "duplicate_check": {
      const screen = duplicateScreen(claimId);
      return screen
        ? `${screen.priorCount} prior claims from ${wholesaler} for ${project}. This is not a duplicate claim.`
        : `No settled claim covers this payment.`;
    }
    case "volume_check": {
      // Two findings, and they are independent: one counts what we can
      // document, the other what could physically have shipped. Folding the
      // ceiling into a separate amber callout buried the second one.
      const ceiling = allocationCeiling(claimId);
      const points = [
        `${units(math.unitsException)} of ${units(math.claimedUnits)} units have no invoice or proof of delivery.`,
      ];
      if (ceiling?.exceeds) {
        points.push(
          `A ${units(ceiling.capPerMonth)}-unit monthly limit over ${ceiling.months} months caps this window at ${units(ceiling.ceilingUnits)}. The claim exceeds that ceiling by ${units(ceiling.exceedsBy)} units.`
        );
      }
      return points;
    }
    case "decision":
      return settlement
        ? `AI recommends to approve ${formatUsd(settlement.approveAmount)}, and reject ${formatUsd(settlement.rejectAmount)}.`
        : "";
    case "settlement":
      return `Credit note raised for ${formatUsd(math.supportableAmount)}. ${formatUsd(math.unsupportedAmount)} held.`;
    default:
      return "";
  }
}

/* ------------------------------------------------------------------ *
 * Duplicate screening
 * ------------------------------------------------------------------ */

export interface DuplicateScreenRow {
  claimId: string;
  period: string;
  units: number;
  amount: number;
  settledOn: string | null;
  invoiceRefs: string[];
  isCandidate: boolean;
}

/**
 * One field, across the claim under review and every prior claim.
 * `same` is true when every claim carries the same value.
 */
export interface DuplicateScreenField {
  label: string;
  /** One entry per claim. Each entry may itself be several lines. */
  values: string[][];
  same: boolean;
}

export interface DuplicateScreen {
  /** Column headers: the claim under review first, then the settled ones. */
  claimIds: string[];
  settledOn: (string | null)[];
  /** Field rows, the matching ones first. */
  fields: DuplicateScreenField[];
  rows: DuplicateScreenRow[];
  priorCount: number;
  /** True when no prior claim covers the same window. */
  distinct: boolean;
}

/**
 * Is this claim a second bite at a payment already settled?
 *
 * A wholesaler that supplies a project claims every quarter, so the same
 * wholesaler, project and product recurring is the NORMAL case - flagging it
 * would flag every honest claim. The screen therefore has to establish the
 * opposite: that the period, the invoices and the volumes are different, and
 * so the money being claimed has not been paid before.
 */
export function duplicateScreen(claimId: string): DuplicateScreen | null {
  const claim = findClaim(claimId);
  const line = claim?.lines[0];
  const math = claimLineMath(claimId);
  if (!claim || !line || !math) return null;

  const priors = settledClaims
    .filter(
      (c) =>
        c.distributorId === claim.distributorId &&
        c.endCustomerId === line.endCustomerId &&
        c.sku === line.sku
    )
    .sort((a, b) => b.settledDate.localeCompare(a.settledDate));

  const rows: DuplicateScreenRow[] = [
    {
      claimId: claim.claimId,
      period: findClaimPeriod(claim.periodId)?.label ?? "—",
      units: math.claimedUnits,
      amount: math.claimedAmount,
      settledOn: null,
      invoiceRefs: claimPeriodUnits(claimId).inPeriodRows.map(
        (r) => r.invoiceRef
      ),
      isCandidate: true,
    },
    ...priors.map((c) => ({
      claimId: c.claimId,
      period: findClaimPeriod(c.periodId)?.label ?? "—",
      units: c.units,
      amount: c.settledAmount,
      settledOn: c.settledDate,
      invoiceRefs: c.invoiceRefs ?? [],
      isCandidate: false,
    })),
  ];

  const periodsOverlap = priors.some((c) => c.periodId === claim.periodId);
  const invoiceRefs = claimPeriodUnits(claimId).inPeriodRows.map(
    (r) => r.invoiceRef
  );


  const one = (v: string) => rows.map(() => [v]);
  const per = (fn: (r: DuplicateScreenRow) => string) =>
    rows.map((r) => [fn(r)]);

  const fieldRows: DuplicateScreenField[] = [
    { label: "Wholesaler", values: one(distributorName(claim.distributorId)), same: true },
    {
      label: "End customer",
      values: one(findEndCustomer(line.endCustomerId)?.name ?? "—"),
      same: true,
    },
    { label: "Product", values: one(line.productName), same: true },
    {
      label: "Claim window",
      values: per((r) => r.period),
      same: new Set(rows.map((r) => r.period)).size === 1,
    },
    {
      label: "Units claimed",
      values: per((r) => r.units.toLocaleString("en-US")),
      same: new Set(rows.map((r) => r.units)).size === 1,
    },
    {
      label: "Amount",
      values: per((r) => formatUsd(r.amount)),
      same: new Set(rows.map((r) => r.amount)).size === 1,
    },
    {
      label: "Invoices",
      values: rows.map((r) => r.invoiceRefs),
      same: false,
    },
  ];

  return {
    claimIds: rows.map((r) => r.claimId),
    settledOn: rows.map((r) => r.settledOn),
    fields: fieldRows,
    rows,
    priorCount: priors.length,
    distinct: !periodsOverlap,
  };
}
