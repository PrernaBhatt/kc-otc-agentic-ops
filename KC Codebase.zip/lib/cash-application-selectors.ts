/**
 * Every figure the Cash Application page displays, derived here from
 * lib/data/cash-application.ts and nowhere else.
 *
 * A category total (matched / credits / deductions / unidentified) is always
 * the sum of that type's lines on the payment, never a number typed
 * separately — so the four totals are guaranteed to add back up to the
 * payment amount, which is the whole point of the scenario: nothing is lost
 * between the bank statement and the posted result.
 */

import { cashPayments, findCashPayment, type CashPayment, type RemittanceLine, type RemittanceLineType } from "./data/cash-application";
import { formatUsd } from "./chargeback-selectors";

/* ------------------------------------------------------------------ *
 * Category totals for one payment
 * ------------------------------------------------------------------ */

export interface PaymentResolution {
  matched: number;
  credits: number;
  deductions: number;
  unidentified: number;
  /** Documents behind the payment, aggregate rows counted at full size. */
  totalDocuments: number;
  /** Documents fully classified (matched, credited or deducted). */
  resolvedDocuments: number;
  deductionCount: number;
}

function lineSpan(line: RemittanceLine): number {
  return line.isAggregate ? line.aggregateCount ?? 1 : 1;
}

function sumByType(lines: RemittanceLine[], type: RemittanceLineType): number {
  return lines
    .filter((l) => l.type === type)
    .reduce((sum, l) => sum + l.amount, 0);
}

export function paymentResolution(payment: CashPayment): PaymentResolution {
  const { lines } = payment;
  const totalDocuments = lines.reduce((sum, l) => sum + lineSpan(l), 0);
  const unidentifiedDocuments = lines
    .filter((l) => l.type === "unidentified")
    .reduce((sum, l) => sum + lineSpan(l), 0);

  return {
    matched: sumByType(lines, "invoice"),
    credits: sumByType(lines, "credit"),
    deductions: sumByType(lines, "deduction"),
    unidentified: sumByType(lines, "unidentified"),
    totalDocuments,
    resolvedDocuments: totalDocuments - unidentifiedDocuments,
    deductionCount: lines.filter((l) => l.type === "deduction").length,
  };
}

/* ------------------------------------------------------------------ *
 * The queue
 * ------------------------------------------------------------------ */

/** Indicative rate used only to aggregate a EUR receipt into the USD tiles. */
export const EUR_USD = 1.08;

/** Money in a specific currency — the queue mixes USD and EUR receipts. */
export function formatMoney(amount: number, currency: "USD" | "EUR" = "USD"): string {
  const symbol = currency === "EUR" ? "€" : "$";
  return `${symbol}${Math.round(amount).toLocaleString("en-US")}`;
}

export interface PaymentQueueRow {
  paymentId: string;
  customer: string;
  receivedDate: string;
  /** Receipt amount rendered in its own currency. */
  amountDisplay: string;
  /** USD-equivalent used for the summary tiles only. */
  amountUsd: number;
  /** "164", "Not received", … */
  remittanceDisplay: string;
  /** "23 / 23", "— / 23", … */
  resolvedDisplay: string;
  /** Exception amount in its own currency, or "—". */
  exceptionDisplay: string;
  /** USD-equivalent of the exception, for the summary tiles. */
  exceptionUsd: number;
  status: "Review" | "Posted" | "Cleared";
}

export function paymentQueueRows(postedPaymentIds: string[] = []): PaymentQueueRow[] {
  return cashPayments.map((payment) => {
    const resolution = paymentResolution(payment);
    const posted = postedPaymentIds.includes(payment.paymentId);
    const status: PaymentQueueRow["status"] =
      payment.status === "Cleared" ? "Cleared" : posted ? "Posted" : "Review";

    const base = {
      paymentId: payment.paymentId,
      customer: payment.customer,
      receivedDate: payment.receivedDate,
      status,
    };

    if (payment.kind === "unidentified-payer" && payment.unidentifiedPayer) {
      const c = payment.unidentifiedPayer;
      const held = posted ? 0 : payment.amount;
      return {
        ...base,
        amountDisplay: formatMoney(payment.amount, "USD"),
        amountUsd: payment.amount,
        remittanceDisplay: "Not received",
        resolvedDisplay: posted
          ? `${c.candidateInvoices} / ${c.candidateInvoices}`
          : `— / ${c.candidateInvoices}`,
        exceptionDisplay: held > 0 ? formatMoney(held, "USD") : "—",
        exceptionUsd: held,
      };
    }

    if (payment.kind === "cross-entity" && payment.crossEntity) {
      const ce = payment.crossEntity;
      const totalInvoices = ce.legs.reduce((s, l) => s + l.invoices, 0);
      const clearNow = ce.legs
        .filter((l) => l.action === "clear-now")
        .reduce((s, l) => s + l.invoices, 0);
      const pendingEur =
        ce.legs
          .filter((l) => l.action === "approve-transfer")
          .reduce((s, l) => s + l.eurValue, 0) + ce.fxDifference;
      const exceptionEur = posted ? 0 : pendingEur;
      return {
        ...base,
        amountDisplay: formatMoney(payment.amount, "EUR"),
        amountUsd: payment.usdEquivalent ?? payment.amount,
        remittanceDisplay: String(payment.remittanceItemCount),
        resolvedDisplay: posted
          ? `${totalInvoices} / ${totalInvoices}`
          : `${clearNow} / ${totalInvoices}`,
        exceptionDisplay: exceptionEur > 0 ? formatMoney(exceptionEur, "EUR") : "—",
        exceptionUsd: exceptionEur * EUR_USD,
      };
    }

    // Default remittance flow.
    return {
      ...base,
      amountDisplay: formatMoney(payment.amount, "USD"),
      amountUsd: payment.amount,
      remittanceDisplay: String(payment.remittanceItemCount),
      resolvedDisplay: `${resolution.resolvedDocuments} / ${resolution.totalDocuments}`,
      exceptionDisplay:
        resolution.unidentified > 0 ? formatMoney(resolution.unidentified, "USD") : "—",
      exceptionUsd: resolution.unidentified,
    };
  });
}

export interface PaymentQueueSummary {
  paymentsAwaiting: number;
  incomingCash: number;
  autoMatched: number;
  exceptionValue: number;
}

export function paymentQueueSummary(postedPaymentIds: string[] = []): PaymentQueueSummary {
  const rows = paymentQueueRows(postedPaymentIds);
  return {
    paymentsAwaiting: rows.filter((r) => r.status === "Review").length,
    incomingCash: rows.reduce((sum, r) => sum + r.amountUsd, 0),
    autoMatched: rows.reduce(
      (sum, r) => sum + (r.amountUsd - r.exceptionUsd),
      0
    ),
    exceptionValue: rows.reduce((sum, r) => sum + r.exceptionUsd, 0),
  };
}

/* ------------------------------------------------------------------ *
 * A single line's story, for the evidence panel
 * ------------------------------------------------------------------ */

export function lineTypeLabel(type: RemittanceLineType): string {
  switch (type) {
    case "invoice":
      return "Invoice";
    case "credit":
      return "Credit";
    case "deduction":
      return "Deduction";
    case "unidentified":
      return "Unidentified";
  }
}

export { findCashPayment, formatUsd as formatCashUsd };
