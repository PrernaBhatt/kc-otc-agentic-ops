/**
 * Everything the Deductions page displays, derived once.
 *
 * The dispute letter in particular is rendered here from a token template, so
 * the letter on screen, the letter in the textarea and the letter in the
 * source document are literally the same string. A number cannot appear in one
 * and not the others.
 */

import { claimLineMath, formatUnitPrice, formatUsd } from "./chargeback-selectors";
import { findClaim } from "./data/chargebacks";
import {
  findChannelInvoice,
  remittanceFor,
  type ChannelInvoice,
  type ChannelRemittance,
} from "./data/channel-deductions";
import { daysBetween } from "./data/clock";
import type { DeductionCase } from "./data/deductions";

/**
 * When the chargeback claim was rejected. Used when the visitor lands on the
 * Deductions page without running the Chargebacks flow first; if they did run
 * it, the store's decision date is passed in instead.
 */
export const CLAIM_REJECTED_ON = "2026-08-15";

/* ------------------------------------------------------------------ *
 * The short payment
 * ------------------------------------------------------------------ */

export interface ShortPayPosition {
  invoice?: ChannelInvoice;
  remittance?: ChannelRemittance;
  invoiced: number;
  paid: number;
  withheld: number;
  /** invoiced - withheld === paid. Asserted, not assumed. */
  reconciles: boolean;
  withheldPercent: number;
}

export function shortPayPosition(deduction: DeductionCase): ShortPayPosition {
  const invoice = findChannelInvoice(deduction.invoiceId);
  const remittance = remittanceFor(deduction.invoiceId);

  const invoiced = invoice?.amount ?? 0;
  const paid = remittance?.amountPaid ?? 0;
  const withheld = remittance?.amountWithheld ?? 0;
  const reconciles = invoiced - withheld === paid;

  if (process.env.NODE_ENV !== "production" && invoice && remittance && !reconciles) {
    console.error(
      `[deduction] ${deduction.deductionId}: invoiced - withheld does not equal paid`,
      { invoiced, withheld, paid }
    );
  }

  return {
    invoice,
    remittance,
    invoiced,
    paid,
    withheld,
    reconciles,
    withheldPercent: invoiced === 0 ? 0 : withheld / invoiced,
  };
}

/* ------------------------------------------------------------------ *
 * The link back to the rejected claim
 * ------------------------------------------------------------------ */

export interface ClaimRecoilLink {
  claimId?: string;
  claimAmount: number;
  rejectedAmount: number;
  deductionAmount: number;
  /** The finding: the amount taken equals the amount rejected, to the dollar. */
  matchesExactly: boolean;
  /**
   * Days from the rejection being issued to the money being taken - measured
   * against the remittance date, NOT today. The deduction happened when the
   * payment arrived; the clock moving on afterwards does not change that.
   */
  daysToDeduction: number;
  deductionTakenOn: string;
  rejectionDate: string;
  sameCustomer: boolean;
  /**
   * False for this case, and deliberately so: the wholesaler's note names no
   * claim, so the link has to be established from evidence. See
   * claimMatchSignals below, which is what actually does it.
   */
  noteNamesTheClaim: boolean;
}

export function claimRecoilLink(
  deduction: DeductionCase,
  rejectionDate: string = CLAIM_REJECTED_ON
): ClaimRecoilLink | null {
  if (!deduction.linkedClaimId) return null;
  const claim = findClaim(deduction.linkedClaimId);
  const math = claimLineMath(deduction.linkedClaimId);
  if (!claim || !math) return null;

  const remittance = remittanceFor(deduction.invoiceId);
  const takenOn = remittance?.receivedDate ?? rejectionDate;

  return {
    claimId: claim.claimId,
    claimAmount: math.claimedAmount,
    rejectedAmount: math.unsupportedAmount,
    deductionAmount: deduction.amount,
    matchesExactly: math.unsupportedAmount === deduction.amount,
    daysToDeduction: daysBetween(rejectionDate, takenOn),
    deductionTakenOn: takenOn,
    rejectionDate,
    sameCustomer: true,
    noteNamesTheClaim: Boolean(
      remittance?.customerNote.includes(claim.claimId)
    ),
  };
}

/* ------------------------------------------------------------------ *
 * How the claim was identified
 * ------------------------------------------------------------------ */

export interface MatchSignal {
  label: string;
  finding: string;
  /** Whether this signal points at the claim. All three must hold. */
  holds: boolean;
}

/**
 * The three independent facts that identify which claim a deduction came from.
 *
 * The wholesaler's remittance note names nothing, so none of this is read off
 * the paperwork. Each signal is weak alone - amounts coincide, wholesalers pay
 * often - and conclusive together. This is the derivation the classification
 * and root-cause stages both rest on.
 */
export function claimMatchSignals(
  deduction: DeductionCase,
  rejectionDate: string = CLAIM_REJECTED_ON
): MatchSignal[] {
  const link = claimRecoilLink(deduction, rejectionDate);
  if (!link) return [];

  return [
    {
      label: "Amount",
      finding: `${formatUsd(link.deductionAmount)} withheld matches no invoice line, credit note or promotion agreement, and equals the ${formatUsd(link.rejectedAmount)} rejected on claim ${link.claimId} to the dollar.`,
      holds: link.matchesExactly,
    },
    {
      label: "Counterparty",
      finding: `The wholesaler that withheld the payment is the wholesaler that filed claim ${link.claimId}.`,
      holds: link.sameCustomer,
    },
    {
      label: "Timing",
      finding: `The money was taken on ${link.deductionTakenOn}, ${link.daysToDeduction} days after the rejection was issued on ${link.rejectionDate}.`,
      holds: link.daysToDeduction >= 0 && link.daysToDeduction <= 30,
    },
  ];
}

/* ------------------------------------------------------------------ *
 * The dispute letter
 * ------------------------------------------------------------------ */

export interface RenderedLetter {
  subject: string;
  body: string;
}

export function renderDisputeLetter(
  deduction: DeductionCase,
  rejectionDate: string = CLAIM_REJECTED_ON
): RenderedLetter | null {
  const template = deduction.disputeLetter;
  if (!template || !deduction.linkedClaimId) return null;

  const math = claimLineMath(deduction.linkedClaimId);
  const position = shortPayPosition(deduction);
  if (!math) return null;

  const tokens: Record<string, string> = {
    amount: formatUsd(deduction.amount),
    invoiceId: deduction.invoiceId,
    invoiceAmount: formatUsd(position.invoiced),
    amountPaid: formatUsd(position.paid),
    remittanceId: position.remittance?.remittanceId ?? "—",
    receivedDate: position.remittance?.receivedDate ?? "—",
    claimId: deduction.linkedClaimId,
    rejectionDate,
    quantityAmount: formatUsd(math.quantityComponent),
    priceAmount: formatUsd(math.priceComponent),
    approvedAmount: formatUsd(math.supportableAmount),
    supportedUnits: math.supportedUnits.toLocaleString("en-US"),
    claimedUnits: math.claimedUnits.toLocaleString("en-US"),
    approvedPrice: formatUnitPrice(math.approvedContractPrice),
    claimedPrice: formatUnitPrice(math.claimedContractPrice),
    from: template.from,
  };

  const fill = (text: string) =>
    text.replace(/\{(\w+)\}/g, (whole, key: string) => tokens[key] ?? whole);

  return {
    subject: fill(template.subjectTemplate),
    body: fill(template.bodyTemplate),
  };
}

/* ------------------------------------------------------------------ *
 * Classification
 * ------------------------------------------------------------------ */

export interface ClassificationStep {
  label: string;
  eliminated: boolean;
  why: string;
}

/**
 * The reason codes the AI considered, in elimination order, ending on the one
 * it settled on. The eliminations are the explanation - a bare label with a
 * confidence percentage explains nothing.
 */
export function classificationTrail(
  deduction: DeductionCase
): ClassificationStep[] {
  const ruledOut = (deduction.rejectedReadings ?? []).map((r) => ({
    label: r.label,
    eliminated: true,
    why: r.why,
  }));

  return [
    ...ruledOut,
    {
      label: deduction.reasonCode,
      eliminated: false,
      why: deduction.rootCauseFinding,
    },
  ];
}

/* ------------------------------------------------------------------ *
 * Recovery options
 * ------------------------------------------------------------------ */

export interface RecoveryOption {
  label: string;
  recommended: boolean;
  expectedRecovery: number;
  relationshipCost: "Low" | "Medium" | "High";
  note: string;
}

export function recoveryOptions(deduction: DeductionCase): RecoveryOption[] {
  const full = deduction.amount;
  const recommended = new Set(deduction.recommendedOptions ?? []);

  const shape: Record<
    string,
    { recovery: number; cost: RecoveryOption["relationshipCost"]; note: string }
  > = {
    "Request repayment": {
      recovery: full,
      cost: "Medium",
      note: "Request repayment in full, with the rejection evidence attached.",
    },
    "Rebill the customer": {
      recovery: full,
      cost: "High",
      note: "Raise a new invoice for the amount withheld. Recovers the full amount at the highest relationship cost.",
    },
    "Issue credit memo": {
      recovery: 0,
      cost: "Low",
      note: "Accept the deduction and close the case. Concedes the full amount.",
    },
    "Write off": {
      recovery: 0,
      cost: "Low",
      note: "Absorb the amount as a loss. Requires approval above the write-off limit.",
    },
    "Internal chargeback": {
      recovery: 0,
      cost: "Low",
      note: "Reallocate the cost to the business unit that owns the contract. Recovers nothing from the customer.",
    },
  };

  return deduction.resolutionOptions.map((label) => {
    const s = shape[label] ?? {
      recovery: 0,
      cost: "Low" as const,
      note: "",
    };
    return {
      label,
      recommended: recommended.has(label),
      expectedRecovery: s.recovery,
      relationshipCost: s.cost,
      note: s.note,
    };
  });
}

/* ------------------------------------------------------------------ *
 * What a recovery choice actually commits to
 * ------------------------------------------------------------------ */

export interface RecoveryImpact {
  option: string;
  recommended: boolean;
  recovered: number;
  conceded: number;
  /** What is still owed to us once this action is taken. */
  receivableAfter: number;
  accounting: string;
  approval: string;
  relationshipCost: RecoveryOption["relationshipCost"];
  recommendedOption: string;
  /** Negative when the chosen action recovers less than the recommendation. */
  deltaVsRecommended: number;
  aiView: string;
}

/**
 * The consequence of one recovery choice, stated before it is taken.
 *
 * A ranked list tells a person which option scores best. It does not tell them
 * what happens when they click, what posts to the ledger, whose approval it
 * needs, or what they give up by departing from the recommendation. That is
 * what this returns, and it is why the choice goes through a confirmation.
 */
export function recoveryImpact(
  deduction: DeductionCase,
  optionLabel: string
): RecoveryImpact | null {
  const options = recoveryOptions(deduction);
  const chosen = options.find((o) => o.label === optionLabel);
  if (!chosen) return null;

  const recommended =
    options.find((o) => o.recommended) ?? options[0];
  const conceded = deduction.amount - chosen.expectedRecovery;

  const treatment: Record<
    string,
    { accounting: string; approval: string; receivableAfter: number }
  > = {
    "Request repayment": {
      accounting:
        "No entry is posted. The amount stays on the books as a receivable until it is repaid.",
      approval: "Trade Finance",
      receivableAfter: deduction.amount,
    },
    "Rebill the customer": {
      accounting:
        "A new invoice replaces the withheld amount and payment terms restart from the invoice date.",
      approval: "Trade Finance and Commercial Finance",
      receivableAfter: deduction.amount,
    },
    "Issue credit memo": {
      accounting:
        "A credit note writes the receivable down against chargeback expense. The amount leaves the books permanently.",
      approval: "Controller",
      receivableAfter: 0,
    },
    "Write off": {
      accounting:
        "The receivable is written down against bad debt expense. The amount leaves the books permanently.",
      approval: "Controller — above the standard write-off limit",
      receivableAfter: 0,
    },
    "Internal chargeback": {
      accounting:
        "The receivable is cleared and the cost is reallocated to the business unit that owns the contract. Nothing is collected from the customer.",
      approval: "Controller and the contract-owning business unit",
      receivableAfter: 0,
    },
  };

  const t = treatment[optionLabel] ?? {
    accounting: "—",
    approval: "Controller",
    receivableAfter: chosen.expectedRecovery,
  };

  const delta = chosen.expectedRecovery - recommended.expectedRecovery;

  const aiView = chosen.recommended
    ? deduction.aiRecommendation
    : delta < 0
      ? `The recommendation is supported by the evidence: the claim was tested against the contract price record and the delivery history before rejection, no further evidence has been submitted since, and no credit note authorises the amount withheld.`
      : `This collects the same amount as the recommended action, at ${chosen.relationshipCost.toLowerCase()} relationship cost rather than ${recommended.relationshipCost.toLowerCase()}.`;

  return {
    option: chosen.label,
    recommended: chosen.recommended,
    recovered: chosen.expectedRecovery,
    conceded,
    receivableAfter: t.receivableAfter,
    accounting: t.accounting,
    approval: t.approval,
    relationshipCost: chosen.relationshipCost,
    recommendedOption: recommended.label,
    deltaVsRecommended: delta,
    aiView,
  };
}

/* ------------------------------------------------------------------ *
 * What a deduction does to gross-to-net
 * ------------------------------------------------------------------ */

export interface DeductionAccounting {
  /** The part that is a genuine chargeback and draws on the reserve. */
  gtnImpact: number;
  reserveUtilised: number;
  /** The part that is not, and stays a receivable. */
  recoveryRequired: number;
  receivableStillCollectible: number;
  /** Empty when nothing is valid: no entry arises. */
  lines: {
    lineNumber: number;
    glAccount: string;
    accountName: string;
    plainName: string;
    debit?: number;
    credit?: number;
  }[];
  /** Why the split falls where it does. */
  basis: string;
}

/**
 * The argument this case exists to make: a deduction is not a cost because the
 * customer took it.
 *
 * DED-CB-001 is the extreme reading. Every dollar of it was rejected on the
 * claim, so none of it is a chargeback we owe: gross-to-net moves not at all,
 * no reserve is drawn, and the whole amount stays a receivable. The short-pay
 * case is the same test with a different answer, and the pair is the point —
 * the AI decides the split each time rather than booking the deduction.
 */
export function deductionAccounting(
  deduction: DeductionCase
): DeductionAccounting | null {
  if (!deduction.linkedClaimId) return null;
  const math = claimLineMath(deduction.linkedClaimId);
  if (!math) return null;

  // Nothing here was approved on the claim, so nothing here is a giveback.
  const gtnImpact = 0;

  if (process.env.NODE_ENV !== "production" && gtnImpact + deduction.amount !== deduction.amount) {
    console.error(
      `[deduction] ${deduction.deductionId}: the split does not sum to the amount withheld`
    );
  }

  return {
    gtnImpact,
    reserveUtilised: gtnImpact,
    recoveryRequired: deduction.amount,
    receivableStillCollectible: deduction.amount,
    lines: [],
    basis: `Every dollar withheld was rejected on claim ${deduction.linkedClaimId}. None of it is a chargeback we owe, so no reserve is drawn and nothing reaches contra revenue.`,
  };
}
