/**
 * Filtering and KPI math for the Audit trail page. The page, the rail and both
 * export formats all read the list these selectors return.
 */

import type { AuditActorKind, AuditEntry } from "./audit";
import { findAccount } from "./data/account-owners";
import { RUN_DATE, daysBetween } from "./data/clock";
import { findControl, soxControls, type ControlFamily } from "./data/sox-controls";

export type SinceFilter = "all" | "7" | "30";

export interface AuditFilter {
  family: "all" | ControlFamily;
  controlRef: string;
  accountId: string;
  actor: "all" | AuditActorKind;
  module: string;
  since: SinceFilter;
  query: string;
}

export const EMPTY_AUDIT_FILTER: AuditFilter = {
  family: "all",
  controlRef: "all",
  accountId: "all",
  actor: "all",
  module: "all",
  since: "all",
  query: "",
};

export function sortNewestFirst(entries: AuditEntry[]): AuditEntry[] {
  return [...entries].sort((a, b) =>
    a.at === b.at ? b.entryId.localeCompare(a.entryId) : b.at.localeCompare(a.at)
  );
}

export function filterAudit(entries: AuditEntry[], f: AuditFilter): AuditEntry[] {
  const q = f.query.trim().toLowerCase();
  return entries.filter((e) => {
    if (f.family !== "all" && !e.controlRefs.some((r) => findControl(r)?.family === f.family)) {
      return false;
    }
    if (f.controlRef !== "all" && !e.controlRefs.includes(f.controlRef)) return false;
    if (f.accountId !== "all" && e.accountId !== f.accountId) return false;
    if (f.actor !== "all" && e.actor.kind !== f.actor) return false;
    if (f.module !== "all" && e.module !== f.module) return false;
    if (f.since !== "all" && daysBetween(e.at.slice(0, 10), RUN_DATE) > Number(f.since)) {
      return false;
    }
    if (q) {
      const account = findAccount(e.accountId);
      const hay = [
        e.entryId,
        e.caseId,
        e.action,
        e.actor.name,
        e.system,
        e.decision ?? "",
        account?.accountName ?? "",
        ...e.controlRefs,
        ...e.evidence,
      ]
        .join(" ")
        .toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });
}

export function auditModules(entries: AuditEntry[]): string[] {
  return [...new Set(entries.map((e) => e.module))].sort();
}

const DAY_MS = 86_400_000;

function weekStart(iso: string): number {
  const d = Date.parse(`${iso.slice(0, 10)}T00:00:00Z`);
  const dow = (new Date(d).getUTCDay() + 6) % 7;
  return d - dow * DAY_MS;
}

function shortDate(ms: number): string {
  return new Date(ms).toLocaleDateString("en-US", { month: "short", day: "numeric", timeZone: "UTC" });
}

export interface AuditKpis {
  total: number;
  weeks: { label: string; count: number }[];
  people: number;
  agents: number;
  controls: { ref: string; name: string; count: number }[];
  evidenced: number;
  signed: number;
  unsigned: number;
  signers: { name: string; count: number }[];
}

export function auditKpis(entries: AuditEntry[]): AuditKpis {
  const first = entries.length
    ? Math.min(...entries.map((e) => weekStart(e.at)))
    : weekStart(RUN_DATE);
  const last = weekStart(RUN_DATE);
  const weeks: AuditKpis["weeks"] = [];
  for (let w = first; w <= last; w += 7 * DAY_MS) {
    weeks.push({
      label: `Week of ${shortDate(w)}`,
      count: entries.filter((e) => weekStart(e.at) === w).length,
    });
  }

  const controls = soxControls.map((c) => ({
    ref: c.ref,
    name: c.name,
    count: entries.filter((e) => e.controlRefs.includes(c.ref)).length,
  }));

  const signerCounts = new Map<string, number>();
  for (const e of entries) {
    if (e.signature) signerCounts.set(e.signature.signer, (signerCounts.get(e.signature.signer) ?? 0) + 1);
  }

  return {
    total: entries.length,
    weeks: weeks.slice(-8),
    people: entries.filter((e) => e.actor.kind === "person").length,
    agents: entries.filter((e) => e.actor.kind === "agent").length,
    controls,
    evidenced: controls.filter((c) => c.count > 0).length,
    signed: entries.filter((e) => e.signature).length,
    unsigned: entries.filter((e) => e.actor.kind === "person" && !e.signature).length,
    signers: [...signerCounts.entries()]
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count),
  };
}

export interface EvidenceCheck {
  required: string;
  status: "pass" | "flag";
  matched?: string;
}

/** What counts as each kind of required evidence, matched against document labels. */
const EVIDENCE_MATCHERS: Record<string, RegExp> = {
  "Contract price record": /contract|ctr-|pricerx|pr00/i,
  "Customer PO": /\bpo\b|purchase order|edi 850/i,
  "MDG change request": /mdg|change request/i,
  "Source agreement": /agreement|contract/i,
  "Data steward approval": /steward|approval/i,
  "Credit memo request": /credit memo|credit note|\bcm-/i,
  "Root-cause evidence": /\bpod\b|proof of delivery|tms|carrier|damage|asn|vendor agreement|settlement|price file/i,
  "Charge-back notice": /charge-?back|notice|letter|pxn-/i,
  "Contract or POD evidence": /contract|agreement|\bpod\b|proof of delivery|pricerx|asn|appointment/i,
  "Batch rule set": /rule/i,
  "Validation matrix": /matrix/i,
  "TPM event record": /vistex event|tpm|cas deal|vx-/i,
  "Deal sheet": /deal|vx-/i,
  "Fund balance": /fund/i,
  "Accrual entry": /accrual|je-/i,
  "Proof of performance": /proof of performance|scan|photo/i,
  "Promotion agreement": /promotion|vistex event|retailer event|agreement|vx-/i,
  "Rebate agreement": /rebate|agreement/i,
  "Volume statement": /volume|net sales|statement|tier/i,
  "Duplicate screen result": /duplicate|\bclaim\b|screen/i,
  "Prior settlement": /settle|\bcm-/i,
};

/**
 * Matches each control's required evidence against everything attached on the
 * same case, so a gate is evidenced by the documents its agent steps read.
 */
export function evidenceChecks(
  entry: AuditEntry,
  all: AuditEntry[] = [entry]
): { ref: string; checks: EvidenceCheck[] }[] {
  const caseEvidence = [
    ...new Set(all.filter((e) => e.caseId === entry.caseId).flatMap((e) => e.evidence)),
  ];
  return entry.controlRefs.map((ref) => {
    const control = findControl(ref);
    const checks = (control?.evidenceRequired ?? []).map((required): EvidenceCheck => {
      if (/signature/i.test(required)) {
        return entry.signature
          ? { required, status: "pass", matched: `${entry.signature.signer} · ${entry.signature.method}` }
          : entry.actor.kind === "agent"
            ? { required, status: "pass", matched: "Agent step · person signs at the gate" }
            : { required, status: "flag" };
      }
      const matcher = EVIDENCE_MATCHERS[required];
      const matched = matcher ? caseEvidence.find((ev) => matcher.test(ev)) : undefined;
      return matched ? { required, status: "pass", matched } : { required, status: "flag" };
    });
    return { ref, checks };
  });
}
