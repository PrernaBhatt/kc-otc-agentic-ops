/**
 * Source documents for Scenario 2 — duplicate / resubmitted claim.
 *
 * Same rule as the other doc builders: every field is read from the same
 * record the screen reads, so a document can never disagree with the
 * assessment that opened it.
 */

import type { SourceDoc } from "@/components/modals/source-doc-preview";
import { findDupClaimCase } from "./data/dup-claims";
import {
  dupClaimAssessment,
  renderDupClaimLetter,
  DUP_CATEGORY_LABEL,
  LINEAGE_KIND_LABEL,
} from "./dup-claim-selectors";

const ISSUER = "Order to Cash Workspace";
const usd = (n: number) => `$${n.toLocaleString("en-US")}`;

/* ------------------------------------------------------------------ *
 * The resubmitted deduction, as the recovery firm sent it
 * ------------------------------------------------------------------ */

export function buildDupDeductionDoc(caseId: string): SourceDoc {
  const c = findDupClaimCase(caseId)!;
  const claimed = c.invoiceAmount - c.amountPaid;

  return {
    docId: `dup-deduction-${caseId}`,
    title: `Resubmitted deduction ${caseId}`,
    docLabel: "Deduction backup",
    reference: c.resubmittedClaimRef,
    issuer: c.customerName,
    meta: [
      { label: "Invoice", value: c.invoiceId },
      { label: "Received", value: c.receivedDate },
      { label: "Reason code", value: c.resubmittedReasonCode },
      { label: "Submitted by", value: c.postAuditProvider },
    ],
    columns: [
      { key: "item", label: "As deducted" },
      { key: "value", label: "Value", align: "right" },
    ],
    rows: [
      { id: "invoice", cells: { item: "Invoice amount", value: usd(c.invoiceAmount) } },
      { id: "paid", cells: { item: "Amount paid", value: usd(c.amountPaid) } },
      { id: "ref", cells: { item: "Post-audit reference", value: c.resubmittedClaimRef } },
      { id: "reason", cells: { item: "Stated reason code", value: c.resubmittedReasonCode } },
      { id: "event", cells: { item: "Event described", value: "Autumn baby care feature & display" } },
    ],
    totals: [{ label: "Deduction taken", value: usd(claimed), emphasis: true }],
    footnote: `Remittance note: "${c.customerNote}"`,
    highlightRowIds: ["ref", "reason"],
    highlightNote:
      "A new post-audit reference and a changed reason code — the reason a plain exact-match control never fires on this claim.",
    aiSummary: `${c.customerName}'s post-audit firm re-deducted ${usd(claimed)} on ${c.invoiceId} under reference ${c.resubmittedClaimRef} ("${c.resubmittedReasonCode}"). The reference, reason code, invoice and date are all new, so it has to be matched on similarity to the event it actually belongs to.`,
  };
}

/* ------------------------------------------------------------------ *
 * The similarity match — the identity dimensions, scored
 * ------------------------------------------------------------------ */

export function buildSimilarityMatchDoc(caseId: string): SourceDoc {
  const a = dupClaimAssessment(caseId)!;
  const c = a.case;
  const pct = (n: number) => `${Math.round(n * 100)}%`;

  return {
    docId: `dup-similarity-${caseId}`,
    title: `Similarity match — ${c.resubmittedClaimRef} to ${c.originalClaimRef}`,
    docLabel: "Similarity assessment",
    reference: c.promotion.promotionId,
    issuer: ISSUER,
    meta: [
      { label: "Resubmission", value: c.resubmittedClaimRef },
      { label: "Original claim", value: c.originalClaimRef },
      { label: "Promotion", value: c.promotion.promotionId },
      { label: "Confidence", value: pct(a.duplicateConfidence) },
    ],
    columns: [
      { key: "dimension", label: "Dimension" },
      { key: "match", label: "Match", align: "right" },
      { key: "weight", label: "Weight", align: "right" },
    ],
    rows: c.signals.map((s) => ({
      id: s.signalId,
      cells: {
        dimension: s.dimension,
        match: pct(s.matchScore),
        weight: `${s.weight}`,
      },
    })),
    totals: [
      { label: "Duplicate confidence", value: pct(a.duplicateConfidence), emphasis: true },
    ],
    noteList: c.signals.map((s) => ({ label: s.dimension, detail: s.note })),
    highlightRowIds: c.signals.filter((s) => s.matchScore === 1).map((s) => s.signalId),
    highlightNote:
      "Four identity dimensions match exactly; only the underlying invoice set was partly swapped. The confidence is the weighted average of these scores.",
    aiSummary: `Matched on similarity, not references. The promotion, window, SKUs and store footprint are identical to ${c.originalClaimRef}; only three of five invoices carry across. Weighted, that is ${pct(a.duplicateConfidence)} confidence this is the same event.`,
  };
}

/* ------------------------------------------------------------------ *
 * The full claim-and-settlement lineage
 * ------------------------------------------------------------------ */

export function buildLineageDoc(caseId: string): SourceDoc {
  const a = dupClaimAssessment(caseId)!;
  const c = a.case;

  return {
    docId: `dup-lineage-${caseId}`,
    title: `Claim & settlement lineage — ${c.promotion.promotionId}`,
    docLabel: "Lineage",
    reference: c.originalClaimRef,
    issuer: ISSUER,
    meta: [
      { label: "Promotion", value: c.promotion.promotionId },
      { label: "Original claim", value: c.originalClaimRef },
      { label: "Settled", value: usd(a.previouslySettled) },
      { label: "Rejected", value: usd(a.previouslyRejected) },
    ],
    columns: [
      { key: "date", label: "Date" },
      { key: "event", label: "Event" },
      { key: "ref", label: "Reference" },
      { key: "amount", label: "Amount", align: "right" },
    ],
    rows: c.lineage.map((n) => ({
      id: n.nodeId,
      cells: {
        date: n.date,
        event: `${LINEAGE_KIND_LABEL[n.kind] ?? n.kind} — ${n.title}`,
        ref: n.ref,
        amount: n.amount != null ? usd(n.amount) : "—",
      },
    })),
    noteList: c.lineage.map((n) => ({ label: `${n.date} — ${n.title}`, detail: n.detail })),
    highlightRowIds: c.lineage
      .filter((n) => n.kind === "credit" || n.kind === "rejection" || n.kind === "resubmission")
      .map((n) => n.nodeId),
    highlightNote:
      "The credit memo and the rejection between them account for the whole original claim — leaving nothing for the resubmission to recover.",
    aiSummary: `The event was already dealt with: ${usd(a.previouslySettled)} settled by credit memo on ${a.byCategory["previously-settled"][0]?.priorDate}, ${usd(a.previouslyRejected)} rejected with a recorded reason two days later. The ${usd(a.claimed)} resubmission arrives eleven months on with no new evidence.`,
  };
}

/* ------------------------------------------------------------------ *
 * A single lineage node, as its own source system record — each node in
 * the timeline is a real document in a different system (TPM, claims
 * platform, SAP, the post-audit provider), so each is its own 1:1 file.
 * ------------------------------------------------------------------ */

const LINEAGE_NODE_SYSTEM_LABEL: Record<string, string> = {
  promotion: "Trade Promotion Management record",
  claim: "Claims platform record",
  credit: "SAP credit memo",
  rejection: "Claims platform rejection notice",
  resubmission: "Post-audit provider claim packet",
};

export function buildLineageNodeDoc(caseId: string, nodeId: string): SourceDoc {
  const c = findDupClaimCase(caseId)!;
  const n = c.lineage.find((x) => x.nodeId === nodeId) ?? c.lineage[0];
  const idx = c.lineage.findIndex((x) => x.nodeId === n.nodeId);
  const prior = idx > 0 ? c.lineage[idx - 1] : undefined;

  return {
    docId: `dup-lineage-node-${caseId}-${n.nodeId}`,
    title: n.title,
    docLabel: LINEAGE_NODE_SYSTEM_LABEL[n.kind] ?? "Lineage record",
    reference: n.ref,
    issuer: n.system,
    meta: [
      { label: "Date", value: n.date },
      { label: "Reference", value: n.ref },
      { label: "System", value: n.system },
      { label: "Amount", value: n.amount != null ? usd(n.amount) : "—" },
    ],
    columns: [
      { key: "item", label: "Record detail" },
      { key: "value", label: "", align: "left" },
    ],
    rows: [
      { id: "kind", cells: { item: "Record type", value: LINEAGE_NODE_SYSTEM_LABEL[n.kind] ?? n.kind } },
      { id: "detail", cells: { item: "Detail", value: n.detail } },
      ...(prior
        ? [{ id: "prior", cells: { item: "Follows", value: `${prior.title} (${prior.ref}, ${prior.date})` } }]
        : []),
    ],
    totals: n.amount != null ? [{ label: "Amount", value: usd(n.amount), emphasis: true }] : undefined,
    footnote: `Position ${idx + 1} of ${c.lineage.length} in the claim-and-settlement lineage for promotion ${c.promotion.promotionId}.`,
    highlightRowIds: ["detail"],
    highlightNote: n.detail,
    aiSummary: `${n.system} record ${n.ref}, dated ${n.date}${n.amount != null ? ` for ${usd(n.amount)}` : ""}: ${n.detail}`,
  };
}

/* ------------------------------------------------------------------ *
 * The duplicate breakdown, tied to prior settlement
 * ------------------------------------------------------------------ */

export function buildDuplicateBreakdownDoc(caseId: string): SourceDoc {
  const a = dupClaimAssessment(caseId)!;
  const c = a.case;

  return {
    docId: `dup-breakdown-${caseId}`,
    title: `Duplicate breakdown — ${caseId}`,
    docLabel: "Duplicate assessment",
    reference: c.resubmittedClaimRef,
    issuer: ISSUER,
    meta: [
      { label: "Re-deducted", value: usd(a.claimed) },
      { label: "Previously settled", value: usd(a.previouslySettled) },
      { label: "Previously rejected", value: usd(a.previouslyRejected) },
      { label: "Genuinely new", value: usd(a.genuinelyNew) },
    ],
    columns: [
      { key: "part", label: "Part of the claim" },
      { key: "prior", label: "Already dealt with by" },
      { key: "amount", label: "Amount", align: "right" },
    ],
    rows: c.components.map((x) => ({
      id: x.componentId,
      cells: {
        part: DUP_CATEGORY_LABEL[x.category],
        prior: `${x.priorRef} · ${x.priorDate}`,
        amount: usd(x.amount),
      },
    })),
    totals: [
      { label: "Duplicate value", value: usd(a.duplicateValue), emphasis: true },
      { label: "Genuinely new", value: usd(a.genuinelyNew) },
    ],
    noteList: c.components.map((x) => ({ label: DUP_CATEGORY_LABEL[x.category], detail: x.finding })),
    highlightRowIds: c.components.map((x) => x.componentId),
    highlightNote:
      "Every dollar of the resubmission maps to value already settled or already rejected. Nothing is genuinely new.",
    aiSummary: `Of ${usd(a.claimed)} re-deducted, ${usd(a.previouslySettled)} was already paid by credit memo and ${usd(a.previouslyRejected)} was already rejected — ${usd(a.genuinelyNew)} is genuinely new. The claim is a duplicate in full.`,
  };
}

/* ------------------------------------------------------------------ *
 * The retailer response letter, as a document
 * ------------------------------------------------------------------ */

export function buildDupLetterDoc(caseId: string, sent: boolean): SourceDoc {
  const a = dupClaimAssessment(caseId)!;
  const c = a.case;
  const letter = renderDupClaimLetter(caseId)!;

  return {
    docId: `dup-letter-${caseId}`,
    title: `Retailer response ${c.responseLetter.letterRef}`,
    docLabel: "Deduction response letter",
    reference: c.responseLetter.letterRef,
    issuer: ISSUER,
    meta: [
      { label: "To", value: c.responseLetter.to },
      { label: "From", value: c.responseLetter.from },
      { label: "Status", value: sent ? "Issued" : "Draft — not yet sent" },
      { label: "Repayment", value: usd(a.claimed) },
    ],
    columns: [
      { key: "item", label: "Correspondence" },
      { key: "value", label: "", align: "left" },
    ],
    rows: [
      { id: "subject", cells: { item: "Subject", value: letter.subject } },
      { id: "body", cells: { item: "Body", value: letter.body } },
    ],
    highlightRowIds: ["body"],
    highlightNote: sent
      ? "Issued to the retailer's post-audit firm with the full lineage attached."
      : "Drafted from the lineage. A person approves it before it is sent.",
    aiSummary: `The response declines the ${usd(a.claimed)} in full, citing the credit memo that settled ${usd(a.previouslySettled)} and the recorded rejection of ${usd(a.previouslyRejected)}, with the claim-and-settlement lineage attached.`,
  };
}
