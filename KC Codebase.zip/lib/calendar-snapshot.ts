import { APPOINTMENT_CASE as a, RDC_6094_SNAPSHOT as s } from "@/lib/data/shipment-risk";
import { appointmentRun } from "@/lib/shipment-selectors";

function assert(cond: unknown, msg: string): asserts cond {
  if (!cond) throw new Error(`[calendar-snapshot] ${msg}`);
}

const DAY_MS = 86_400_000;

function addMinutes(hm: string, minutes: number) {
  const [h, m] = hm.split(":").map(Number);
  const total = (h * 60 + m + minutes) % (24 * 60);
  return `${String(Math.floor(total / 60)).padStart(2, "0")}:${String(total % 60).padStart(2, "0")}`;
}

export interface SnapshotSlot {
  key: string;
  weekday: string;
  date: string;
  /** "Mon 08-24" */
  dayShort: string;
  time: string;
  window: string;
  doors: string;
  capacity: number;
  booked: number;
  open: number;
  inWindow: boolean;
  /** Whole days after the MABD; 0 inside the window. */
  daysAfterMabd: number;
}

export interface SnapshotDay {
  weekday: string;
  date: string;
  dayShort: string;
  inWindow: boolean;
  isMabd: boolean;
  slots: SnapshotSlot[];
}

export const snapshotDays: SnapshotDay[] = a.calendar.map((d) => {
  const [weekday, date] = d.date.split(" ");
  const dayShort = `${weekday} ${date.slice(5)}`;
  const inWindow = date >= a.otifWindow.from && date <= a.otifWindow.mabd;
  const daysAfterMabd = Math.max(0, Math.round((Date.parse(date) - Date.parse(a.otifWindow.mabd)) / DAY_MS));
  return {
    weekday,
    date,
    dayShort,
    inWindow,
    isMabd: date === a.otifWindow.mabd,
    slots: d.slots.map((slot) => {
      const key = `${d.date} ${slot.time}`;
      const dock = s.slotDoors[slot.time];
      assert(dock, `no dock capacity for ${slot.time}`);
      const open = s.openDoors[key] ?? 0;
      assert((slot.state === "open") === open > 0, `${key} state vs open doors`);
      return {
        key,
        weekday,
        date,
        dayShort,
        time: slot.time,
        window: `${slot.time}–${addMinutes(slot.time, s.slotMinutes)}`,
        doors: dock.doors,
        capacity: dock.capacity,
        booked: dock.capacity - open,
        open,
        inWindow,
        daysAfterMabd,
      };
    }),
  };
});

export const snapshotSlots = snapshotDays.flatMap((d) => d.slots);
export const snapshotTimes = a.calendar[0].slots.map((slot) => slot.time);

const inWindowSlots = snapshotSlots.filter((slot) => slot.inWindow);
const openSlots = snapshotSlots.filter((slot) => slot.open > 0);
const firstOpen = openSlots[0];

export const snapshotSummary = {
  inWindowSlots: inWindowSlots.length,
  inWindowDoors: inWindowSlots.reduce((n, slot) => n + slot.capacity, 0),
  openInWindow: inWindowSlots.filter((slot) => slot.open > 0).length,
  openSlotsAfter: openSlots.filter((slot) => !slot.inWindow).length,
  openDoorsAfter: openSlots.reduce((n, slot) => n + slot.open, 0),
  firstOpen,
  firstOpenLabel: `${firstOpen.dayShort} ${firstOpen.time}`,
  daysAfterMabd: firstOpen.daysAfterMabd,
  period: `${snapshotDays[0].dayShort} – ${snapshotDays[snapshotDays.length - 1].dayShort}`,
};

for (const key of Object.keys(s.openDoors)) {
  assert(snapshotSlots.some((slot) => slot.key === key), `open-door key ${key} not on the calendar`);
}
assert(snapshotSummary.openInWindow === 0, "no open slot inside the window");
assert(
  `${firstOpen.weekday} ${firstOpen.time}` === appointmentRun.firstOpenAfterMabd,
  "first open slot matches the run"
);
