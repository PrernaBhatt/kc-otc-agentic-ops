/**
 * The reserve position, the accounting entry, and the ledger movement.
 *
 * The true-up amount appears exactly once in the codebase, as a subtraction in
 * lib/data/journal-entries.ts. The KPI tile, the balance beam, the beam's
 * tilt, both ledger rungs, the arc label and the entry document all read it
 * from here. `reconcilesWithEntry` turns that into something visible on screen
 * rather than a comment nobody checks.
 */

import {
  ledgerOpeningBalances,
  reserveModel,
  type JournalEntry,
  type JournalLine,
  type ReserveModel,
} from "./data/journal-entries";
import {
  closeEvidenceBasis,
  closeEvidenceReadinessPercent,
  ebitdaBasis,
  ebitdaExposureProtected,
} from "./data/gross-to-net";
import { claimLineMath, duplicateScreen } from "./chargeback-selectors";

/* ------------------------------------------------------------------ *
 * Reserve
 * ------------------------------------------------------------------ */

export interface ReservePosition {
  booked: number;
  projected: number;
  /** The shortfall. Never typed anywhere. */
  variance: number;
  coveragePercent: number;
  accuracyPercent: number;
  basis: string;
  basisGloss: string;
  drivers: ReserveModel["drivers"];
}

export function reservePosition(
  model: ReserveModel = reserveModel
): ReservePosition {
  return {
    booked: model.bookedReserve,
    projected: model.projectedRequirement,
    variance: model.projectedRequirement - model.bookedReserve,
    coveragePercent:
      model.projectedRequirement === 0
        ? 0
        : model.bookedReserve / model.projectedRequirement,
    accuracyPercent: model.accuracyPercent,
    basis: model.basis,
    basisGloss: model.basisGloss,
    drivers: model.drivers,
  };
}

/* ------------------------------------------------------------------ *
 * The entry
 * ------------------------------------------------------------------ */

export interface JournalEntryTotals {
  debitTotal: number;
  creditTotal: number;
  difference: number;
  balanced: boolean;
}

export function journalEntryTotals(entry: JournalEntry): JournalEntryTotals {
  const debitTotal = entry.lines.reduce((sum, l) => sum + (l.debit ?? 0), 0);
  const creditTotal = entry.lines.reduce((sum, l) => sum + (l.credit ?? 0), 0);
  const difference = debitTotal - creditTotal;

  return {
    debitTotal,
    creditTotal,
    difference,
    balanced: difference === 0,
  };
}

/**
 * How far the balance beam tilts, in degrees. Driven by the numbers, so an
 * entry that does not balance stays visibly crooked instead of quietly
 * rendering level.
 */
export function beamTiltDegrees(
  totals: JournalEntryTotals,
  maxDegrees = 8
): number {
  const scale = Math.max(totals.debitTotal, totals.creditTotal, 1);
  const raw = (totals.difference / scale) * maxDegrees;
  return Math.max(-maxDegrees, Math.min(maxDegrees, raw));
}

/* ------------------------------------------------------------------ *
 * Ledger movement
 * ------------------------------------------------------------------ */

export interface LedgerMovement {
  account: string;
  accountName: string;
  plainName: string;
  opening: number;
  change: number;
  direction: "Debit" | "Credit";
  /** opening +/- change. Never typed. */
  closing: number;
}

export function ledgerMovements(
  entry: JournalEntry,
  opening: Record<string, number> = ledgerOpeningBalances
): LedgerMovement[] {
  return entry.lines.map((line: JournalLine) => {
    const isDebit = (line.debit ?? 0) > 0;
    const change = isDebit ? (line.debit ?? 0) : (line.credit ?? 0);
    const start = opening[line.glAccount] ?? 0;

    // Direction depends on what KIND of account it is, not on debit vs credit
    // alone. A liability grows on the credit side and shrinks on the debit
    // side; an expense does the reverse. Treating every posting as growth was
    // right for the reserve top-up (debit expense, credit liability - both
    // grow) and wrong for a settlement, which debits the liability to draw it
    // down and reported the balance unchanged.
    const liability = line.glAccount.startsWith("2");
    const asset = line.glAccount.startsWith("1");
    const reduces = (liability && isDebit) || (asset && !isDebit);

    return {
      account: line.glAccount,
      accountName: line.accountName,
      plainName: line.plainName,
      opening: start,
      change,
      direction: isDebit ? "Debit" : "Credit",
      closing: reduces ? start - change : start + change,
    };
  });
}

export function ledgerScaleMax(movements: LedgerMovement[]): number {
  return Math.max(...movements.map((m) => m.closing), 1);
}

/* ------------------------------------------------------------------ *
 * Outcome, and the invariant that ties the two halves together
 * ------------------------------------------------------------------ */

export interface FinancialOutcome {
  reservePosted: number;
  ebitdaProtected: number;
  ebitdaBasis: string;
  closeEvidenceReadinessPercent: number;
  closeEvidenceBasis: string;
}

export function financialOutcome(entry: JournalEntry): FinancialOutcome {
  return {
    reservePosted: journalEntryTotals(entry).debitTotal,
    ebitdaProtected: ebitdaExposureProtected,
    ebitdaBasis,
    closeEvidenceReadinessPercent,
    closeEvidenceBasis,
  };
}

/**
 * The reserve gap and the entry that corrects it must be the same number.
 * Rendered on the panel as a chip, so the check is visible rather than
 * assumed.
 */
export function reconcilesWithEntry(
  position: ReservePosition,
  totals: JournalEntryTotals
): boolean {
  return position.variance === totals.debitTotal && totals.balanced;
}

/* ------------------------------------------------------------------ *
 * What THIS claim does to the books
 * ------------------------------------------------------------------ */

export interface ClaimAccountingImpact {
  /** Set aside when the sales were invoiced: the giveback we expected. */
  provided: number;
  claimed: number;
  approved: number;
  rejected: number;
  /** approved - provided. Zero means the decision landed on the estimate. */
  varianceToProvision: number;
  /** Rejected value that never had a provision, so was never in the plan. */
  neverProvided: number;
}

/**
 * The accounting consequence of one settlement decision.
 *
 * Under ASC 606 the giveback is provided for when the sale is recognised, not
 * when the claim arrives. For this claim that provision is the 12,000 units we
 * actually invoiced at the adjustment their contract actually carries - the
 * same two figures the price and volume stages established. Settling draws
 * that provision down; the rejected value never had one behind it, which is
 * why rejecting it protects revenue rather than merely avoiding a payment.
 */
export function claimAccountingImpact(
  claimId: string,
  approved: number,
  rejected: number
): ClaimAccountingImpact | null {
  const math = claimLineMath(claimId);
  if (!math) return null;

  const provided = math.supportedUnits * math.approvedAdjustment;

  const impact: ClaimAccountingImpact = {
    provided,
    claimed: math.claimedAmount,
    approved,
    rejected,
    varianceToProvision: approved - provided,
    neverProvided: rejected,
  };

  if (process.env.NODE_ENV !== "production") {
    if (impact.approved + impact.rejected !== impact.claimed)
      console.error(
        `[chargeback] ${claimId}: approved + rejected does not equal claimed`,
        impact
      );
    if (provided !== math.supportableAmount)
      console.error(
        `[chargeback] ${claimId}: the provision and the supportable amount disagree`,
        { provided, supportable: math.supportableAmount }
      );
  }

  return impact;
}

/**
 * The settlement posting, built from the decision rather than typed.
 *
 * One entry, two lines: the provision set aside for these units is drawn down,
 * and the wholesaler's receivable is reduced by the credit note.
 */
export function claimSettlementEntry(
  claimId: string,
  approved: number,
  wholesaler: string,
  creditNoteRef: string
): JournalEntry {
  return {
    entryId: `JE-CB-${claimId}`,
    companyCode: "US10",
    companyCodeGloss: "the US operating company",
    ledger: "0L",
    ledgerGloss: "the principal ledger",
    postingPeriod: "2026-08",
    postingPeriodLabel: "August 2026 close",
    documentType: "DA",
    documentTypeGloss:
      "a customer document, because it moves a wholesaler receivable",
    documentNumber: "1900008472",
    postingDate: "2026-08-31",
    currency: "USD",
    headline: `Settle claim ${claimId} by credit note ${creditNoteRef}`,
    lines: [
      {
        lineNumber: 10,
        glAccount: "229150",
        accountName: "Chargeback reserve liability",
        plainName: "Money set aside for this claim",
        debit: approved,
      },
      {
        lineNumber: 20,
        glAccount: "121000",
        accountName: "Trade receivables — wholesale channel",
        plainName: `Owed by ${wholesaler}`,
        credit: approved,
      },
    ],
  };
}

/* ------------------------------------------------------------------ *
 * The reserve this claim draws on
 * ------------------------------------------------------------------ */

/**
 * What is set aside for chargebacks on this contract for the year.
 *
 * A per-claim opening balance made the ledger card read as though account
 * 229150 existed only for this claim. It does not: it is a programme reserve
 * that every claim on the contract draws down, which is why a settlement
 * leaves a remainder rather than emptying it. Typed once; every other figure
 * on the card is derived from the claims themselves.
 */
export const contractReserveProvision = 1_500_000;

export interface ContractReserve {
  provision: number;
  /** Consumed by claims already settled for these parties. */
  alreadyDrawn: number;
  /** What this entry takes. */
  thisEntry: number;
  remaining: number;
  usedPercent: number;
}

export function contractReserve(
  claimId: string,
  approved: number
): ContractReserve | null {
  const screen = duplicateScreen(claimId);
  if (!screen) return null;

  const alreadyDrawn = screen.rows
    .filter((r) => !r.isCandidate)
    .reduce((sum, r) => sum + r.amount, 0);

  const remaining = contractReserveProvision - alreadyDrawn - approved;

  if (process.env.NODE_ENV !== "production" && remaining < 0) {
    console.error(
      `[chargeback] ${claimId}: the contract reserve is overdrawn`,
      { provision: contractReserveProvision, alreadyDrawn, approved }
    );
  }

  return {
    provision: contractReserveProvision,
    alreadyDrawn,
    thisEntry: approved,
    remaining,
    usedPercent: (alreadyDrawn + approved) / contractReserveProvision,
  };
}
