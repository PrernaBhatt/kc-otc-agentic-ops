/**
 * The reconciliation behind Scenario 1 — incomplete proof of promotion.
 *
 * The screen never states a total; it sums the leaves. That is the whole point
 * of the case: a $250,000 claim is not "approve or reject", it is a split into
 * a supported part, three unsupported reasons and anything that still needs
 * information. If those parts do not add back to the claim, the split is wrong
 * and must not render quietly.
 */

import {
  findPromoClaimCase,
  type PromoClaimCase,
  type PromoClaimLine,
  type PromoLineCategory,
} from "./data/promo-claims";
import type { ClaimEdit } from "./claim-edit";

export interface PromoClaimSplit {
  case: PromoClaimCase;
  /** The whole amount the retailer withheld. */
  claimed: number;
  /** Eligible, in-window, evidenced. */
  supported: number;
  /** Failed a store, date or SKU test. */
  unsupported: number;
  /** Held pending more evidence — zero here, but part of the model. */
  needsInfo: number;
  /** What we ask back or bill back: unsupported + needsInfo. */
  billBack: number;
  supportedStores: number;
  exceptionStores: number;
  claimedStores: number;
  /** supported + unsupported + needsInfo === claimed. */
  reconciles: boolean;
  supportedPercent: number;
  /** Lines grouped for the exception list, unsupported first. */
  byCategory: Record<PromoLineCategory, PromoClaimLine[]>;
}

const EMPTY_GROUPS = (): Record<PromoLineCategory, PromoClaimLine[]> => ({
  supported: [],
  "not-on-event": [],
  "out-of-window": [],
  "ineligible-sku": [],
  "needs-info": [],
});

const sumBy = (
  lines: PromoClaimLine[],
  pred: (l: PromoClaimLine) => boolean,
  key: "amount" | "stores"
) => lines.filter(pred).reduce((s, l) => s + l[key], 0);

export function promoClaimSplit(
  caseId: string,
  edit?: ClaimEdit
): PromoClaimSplit | null {
  const c = findPromoClaimCase(caseId);
  if (!c) return null;

  const claimed = c.invoiceAmount - c.amountPaid;

  const baseSupported = sumBy(c.lines, (l) => l.category === "supported", "amount");
  const needsInfo = sumBy(c.lines, (l) => l.category === "needs-info", "amount");
  const baseUnsupported = sumBy(
    c.lines,
    (l) =>
      l.category === "not-on-event" ||
      l.category === "out-of-window" ||
      l.category === "ineligible-sku",
    "amount"
  );

  // A reviewer can move how much of the claim is approved as supported spend;
  // the remainder is billed back. needsInfo is held constant.
  const supported =
    edit?.approvedAmount != null
      ? Math.max(0, Math.min(Math.round(edit.approvedAmount), claimed - needsInfo))
      : baseSupported;
  const unsupported = claimed - needsInfo - supported;
  void baseUnsupported;

  const supportedStores = sumBy(
    c.lines,
    (l) => l.category === "supported",
    "stores"
  );
  const exceptionStores = sumBy(
    c.lines,
    (l) => l.category !== "supported",
    "stores"
  );

  const byCategory = c.lines.reduce((acc, l) => {
    acc[l.category].push(l);
    return acc;
  }, EMPTY_GROUPS());

  const reconciles = supported + unsupported + needsInfo === claimed;

  if (process.env.NODE_ENV !== "production" && !edit) {
    if (!reconciles)
      console.error(
        `[promo claim] ${caseId}: the split does not sum to the amount withheld`,
        { claimed, supported, unsupported, needsInfo }
      );
    if (supportedStores + exceptionStores !== c.claimedStores)
      console.error(
        `[promo claim] ${caseId}: the store counts do not sum to the billed footprint`,
        { supportedStores, exceptionStores, claimedStores: c.claimedStores }
      );
  }

  return {
    case: c,
    claimed,
    supported,
    unsupported,
    needsInfo,
    billBack: unsupported + needsInfo,
    supportedStores,
    exceptionStores,
    claimedStores: c.claimedStores,
    reconciles,
    supportedPercent: claimed === 0 ? 0 : supported / claimed,
    byCategory,
  };
}

/* ------------------------------------------------------------------ *
 * What it does to the books
 * ------------------------------------------------------------------ */

export interface PromoClaimAccounting {
  /** Only the supported part draws the trade-promotion accrual. */
  gtnImpact: number;
  accrualUtilised: number;
  accrualId: string;
  /** The unsupported part never becomes an expense; it is billed back. */
  recoveryRequired: number;
  receivableStillCollectible: number;
  lines: {
    lineNumber: number;
    glAccount: string;
    accountName: string;
    plainName: string;
    debit?: number;
    credit?: number;
  }[];
}

/**
 * The supported allowance was already accrued, so approving it draws the
 * trade-promotion accrual down — it is not new expense. The unsupported part
 * touches gross-to-net not at all: it is a receivable that stays collectible,
 * and expensing it is exactly the leakage this case exists to stop.
 */
export function promoClaimAccounting(
  caseId: string,
  edit?: ClaimEdit
): PromoClaimAccounting | null {
  const split = promoClaimSplit(caseId, edit);
  if (!split) return null;
  const p = split.case.promotion;

  return {
    gtnImpact: split.supported,
    accrualUtilised: split.supported,
    accrualId: p.accrualId,
    recoveryRequired: split.billBack,
    receivableStillCollectible: split.billBack,
    lines: [
      {
        lineNumber: 10,
        glAccount: "229300",
        accountName: "Trade promotion accrual",
        plainName: `Accrued for ${p.promotionId}`,
        debit: split.supported,
      },
      {
        lineNumber: 20,
        glAccount: "121500",
        accountName: "Deduction clearing — retail channel",
        plainName: `Owed by ${split.case.customerName}`,
        credit: split.supported,
      },
    ],
  };
}

/* ------------------------------------------------------------------ *
 * The retailer response
 * ------------------------------------------------------------------ */

export function renderPromoClaimLetter(
  caseId: string,
  edit?: ClaimEdit
): { subject: string; body: string } | null {
  const split = promoClaimSplit(caseId, edit);
  if (!split) return null;
  const c = split.case;
  const p = c.promotion;

  const usd = (n: number) => `$${n.toLocaleString("en-US")}`;
  const line = (cat: PromoLineCategory) => split.byCategory[cat][0];

  const tokens: Record<string, string> = {
    invoiceId: c.invoiceId,
    invoiceAmount: usd(c.invoiceAmount),
    remittanceId: c.remittanceId,
    receivedDate: c.receivedDate,
    amountPaid: usd(c.amountPaid),
    retailerEventRef: c.retailerEventRef,
    claimed: usd(split.claimed),
    supported: usd(split.supported),
    unsupported: usd(split.unsupported),
    supportedStores: String(split.supportedStores),
    promotionId: p.promotionId,
    promotionName: p.name,
    weeks: String(p.weeks),
    windowStart: p.windowStart,
    windowEnd: p.windowEnd,
    approvedStores: String(p.approvedStores),
    notOnEventAmount: usd(line("not-on-event")?.amount ?? 0),
    notOnEventStores: String(line("not-on-event")?.stores ?? 0),
    outOfWindowAmount: usd(line("out-of-window")?.amount ?? 0),
    outOfWindowStores: String(line("out-of-window")?.stores ?? 0),
    ineligibleSkuAmount: usd(line("ineligible-sku")?.amount ?? 0),
    from: c.responseLetter.from,
  };

  const fill = (t: string) =>
    t.replace(/\{(\w+)\}/g, (whole, key: string) => tokens[key] ?? whole);

  return {
    subject: fill(c.responseLetter.subjectTemplate),
    body: fill(c.responseLetter.bodyTemplate),
  };
}

export const PROMO_CATEGORY_LABEL: Record<PromoLineCategory, string> = {
  supported: "Supported",
  "not-on-event": "Not on approved event",
  "out-of-window": "Outside promotional window",
  "ineligible-sku": "Ineligible SKU",
  "needs-info": "Needs more information",
};
