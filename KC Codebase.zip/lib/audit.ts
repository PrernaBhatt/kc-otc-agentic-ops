/**
 * The audit record every agent step and every signed gate writes. One shape
 * feeds the Audit trail page, the run logs, and both export formats, so what
 * a person sees on screen is exactly what leaves in the CSV or PDF.
 */

import { RUN_DATE } from "./data/clock";
import { findAccount } from "./data/account-owners";
import { findControl } from "./data/sox-controls";

export type AuditActorKind = "agent" | "person";

export interface AuditActor {
  kind: AuditActorKind;
  name: string;
  role: string;
}

export interface AuditSignature {
  method: "drawn" | "typed";
  signer: string;
  role: string;
  signedAt: string;
  hash: string;
  image?: string;
  typed?: string;
}

export interface AuditEntry {
  entryId: string;
  at: string;
  caseId: string;
  accountId: string;
  module: string;
  actor: AuditActor;
  action: string;
  controlRefs: string[];
  amountUsd?: number;
  decision?: string;
  evidence: string[];
  signature?: AuditSignature;
  system: string;
}

export type AuditInput = Omit<AuditEntry, "entryId" | "at"> & { at?: string };

/** Short, stable fingerprint for a signature (display + export, not crypto). */
export function signatureHash(...parts: string[]): string {
  let h1 = 0x811c9dc5;
  let h2 = 0x01000193;
  for (const ch of parts.join("|")) {
    const c = ch.charCodeAt(0);
    h1 = Math.imul(h1 ^ c, 0x01000193) >>> 0;
    h2 = Math.imul(h2 ^ c, 0x5bd1e995) >>> 0;
  }
  return `${h1.toString(16).padStart(8, "0")}${h2.toString(16).padStart(8, "0")}`;
}

/** Session timestamps land on the run date at the current time of day. */
export function runStamp(): string {
  const now = new Date();
  const hh = String(now.getUTCHours()).padStart(2, "0");
  const mm = String(now.getUTCMinutes()).padStart(2, "0");
  const ss = String(now.getUTCSeconds()).padStart(2, "0");
  return `${RUN_DATE}T${hh}:${mm}:${ss}Z`;
}

export function formatAuditTime(iso: string): string {
  return `${iso.slice(0, 10)} ${iso.slice(11, 16)}`;
}

export const CSV_COLUMNS = [
  "entryId",
  "at",
  "caseId",
  "account",
  "module",
  "actorKind",
  "actor",
  "role",
  "action",
  "controlRef",
  "controlName",
  "amountUsd",
  "decision",
  "evidence",
  "signer",
  "signedAt",
  "signatureHash",
  "system",
] as const;

function csvCell(value: string | number | undefined): string {
  const s = value === undefined ? "" : String(value);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

export function auditToCsv(entries: AuditEntry[]): string {
  const rows = entries.map((e) =>
    [
      e.entryId,
      e.at,
      e.caseId,
      findAccount(e.accountId)?.accountName ?? e.accountId,
      e.module,
      e.actor.kind,
      e.actor.name,
      e.actor.role,
      e.action,
      e.controlRefs.join(";"),
      e.controlRefs.map((r) => findControl(r)?.name ?? "").join(";"),
      e.amountUsd,
      e.decision,
      e.evidence.join(";"),
      e.signature?.signer,
      e.signature?.signedAt,
      e.signature?.hash,
      e.system,
    ]
      .map(csvCell)
      .join(",")
  );
  return [CSV_COLUMNS.join(","), ...rows].join("\n");
}
