/**
 * Source documents for Scenario 9 — one short payment, three root causes.
 *
 * Same rule as the other doc builders: every field is read from the same
 * MULTI_CAUSE_DEDUCTION record the screens read, so a document can never
 * disagree with the split, the evidence or the letter that opened it.
 */

import type { SourceDoc } from "@/components/modals/source-doc-preview";
import { TODAY } from "@/lib/data/clock";
import {
  MULTI_CAUSE_DEDUCTION as D,
  multiCauseRouted,
  type CauseKind,
} from "@/lib/data/multi-cause-deduction";

const ISSUER = "Order to Cash Workspace";
const usd = (n: number) => `$${n.toLocaleString("en-US")}`;

const creditCause = () => D.causes.find((c) => c.kind === "credit")!;
const promoCause = () => D.causes.find((c) => c.kind === "promotion")!;
const freightCause = () => D.causes.find((c) => c.kind === "freight")!;

/* ------------------------------------------------------------------ *
 * The remittance, as Kroger sent it
 * ------------------------------------------------------------------ */

export function buildRemittanceDoc(): SourceDoc {
  return {
    docId: `remit-${D.remittanceRef}`,
    title: `Remittance advice ${D.remittanceRef}`,
    docLabel: "Remittance advice",
    reference: D.remittanceRef,
    issuer: D.customerName,
    meta: [
      { label: "Received", value: D.receivedDate },
      { label: "Invoices", value: `${D.invoiceCount} in the bundle` },
      { label: "Open balance", value: usd(D.invoicesOpen) },
      { label: "Paid", value: usd(D.cashReceived) },
    ],
    columns: [
      { key: "item", label: "As remitted" },
      { key: "value", label: "Value", align: "right" },
    ],
    rows: [
      { id: "open", cells: { item: `Invoices open (${D.invoiceCount})`, value: usd(D.invoicesOpen) } },
      { id: "paid", cells: { item: "Amount paid", value: usd(D.cashReceived) } },
      { id: "short", cells: { item: "Short paid", value: `(${usd(D.shortPay)})` } },
    ],
    totals: [{ label: "Short paid, unexplained", value: usd(D.shortPay), emphasis: true }],
    footnote: `Remittance note: "${D.customerNote}"`,
    highlightRowIds: ["short"],
    highlightNote:
      "Kroger short-paid the bundle by one lump sum with no line-level reasons and no claim references — the gap has to be decomposed before anything is written off.",
    aiSummary: `${D.customerName} paid ${usd(D.cashReceived)} against ${usd(D.invoicesOpen)} open across ${D.invoiceCount} invoices, ${usd(D.shortPay)} short. The remittance gives no reasons, so the short is split into its causes rather than booked as one residual.`,
  };
}

/* ------------------------------------------------------------------ *
 * The credit that already exists in SAP
 * ------------------------------------------------------------------ */

export function buildCreditMemoDoc(): SourceDoc {
  const c = creditCause();
  return {
    docId: "sap-credit-CM-88213",
    title: "Credit memo CM-88213",
    docLabel: "Credit memo",
    reference: "CM-88213",
    issuer: "SAP S/4HANA",
    skin: "sap",
    docDate: "Issued 2026-08-30",
    meta: [
      { label: "Customer", value: `${D.customerName} (${D.customerId})` },
      { label: "Status", value: "Open — never applied" },
      { label: "Issued", value: "2026-08-30" },
      { label: "Amount", value: usd(c.amount) },
    ],
    columns: [
      { key: "item", label: "Document" },
      { key: "detail", label: "Detail" },
      { key: "value", label: "Amount", align: "right" },
    ],
    rows: [
      {
        id: "live",
        cells: {
          item: "CM-88213",
          detail: "Live trade credit, open on the account",
          value: usd(c.amount),
        },
      },
      {
        id: "referenced",
        cells: {
          item: "CM-88123",
          detail: "Referenced by Kroger — no such document (two digits transposed)",
          value: "—",
        },
      },
      {
        id: "account",
        cells: {
          item: D.customerId,
          detail: "No second credit of this value open on the account",
          value: "—",
        },
      },
    ],
    totals: [{ label: "Existing credit to apply", value: usd(c.amount), emphasis: true }],
    highlightRowIds: ["live"],
    highlightNote:
      "The credit Kroger meant already exists as CM-88213. Applying it clears the line — issuing a new credit would pay them twice.",
    aiSummary: `SAP holds an open ${usd(c.amount)} credit CM-88213 for ${D.customerName}, issued 2026-08-30 and never applied. Kroger cited CM-88123, which does not exist — two digits are transposed. The existing credit is applied instead of cutting a new one.`,
  };
}

/* ------------------------------------------------------------------ *
 * The promotion the allowance belongs to (Vistex)
 * ------------------------------------------------------------------ */

export function buildPromotionDoc(): SourceDoc {
  const c = promoCause();
  return {
    docId: "vistex-VX-Q3-2214",
    title: "Promotion VX-Q3-2214",
    docLabel: "Trade promotion",
    reference: "VX-Q3-2214",
    issuer: "Vistex",
    skin: "trade",
    meta: [
      { label: "Customer", value: D.customerName },
      { label: "Tactic", value: "Feature & display" },
      { label: "Window", value: "2026-08-04 to 08-24" },
      { label: "Deducted", value: usd(c.amount) },
    ],
    columns: [
      { key: "item", label: "Element" },
      { key: "detail", label: "Detail", align: "right" },
    ],
    rows: [
      { id: "fund", cells: { item: "Accrued fund remaining", detail: "$92,400" } },
      { id: "deducted", cells: { item: "Deduction taken", detail: usd(c.amount) } },
      { id: "pop", cells: { item: "Proof of performance", detail: "Circular scan + store-count report" } },
      { id: "plan", cells: { item: "Plan alignment", detail: "Mirrored in Promax; CAS carries backup" } },
    ],
    totals: [{ label: "Fund remaining vs. deduction", value: `$92,400 vs ${usd(c.amount)}`, emphasis: true }],
    highlightRowIds: ["fund", "deducted"],
    highlightNote:
      "The deduction matches promotion VX-Q3-2214, which ran in the window and has fund remaining. Trade confirms eligibility before a credit is cut.",
    aiSummary: `The ${usd(c.amount)} feature-and-display deduction matches Vistex promotion VX-Q3-2214, which ran 2026-08-04 to 08-24 with $92,400 of accrued fund remaining and proof of performance on file. It routes to Trade to confirm eligibility.`,
  };
}

/* ------------------------------------------------------------------ *
 * The proof of delivery for the freight claim (SAP + FourKites)
 * ------------------------------------------------------------------ */

export function buildPodDoc(): SourceDoc {
  const c = freightCause();
  return {
    docId: "pod-SHP-55120",
    title: "Proof of delivery SHP-55120",
    docLabel: "Proof of delivery",
    reference: "SHP-55120",
    issuer: "SAP · FourKites",
    skin: "pod-letter",
    docDate: "Delivered 2026-08-19",
    meta: [
      { label: "Customer", value: D.customerName },
      { label: "Shipped", value: "12 pallets" },
      { label: "Received", value: "9 pallets" },
      { label: "Deducted", value: usd(c.amount) },
    ],
    columns: [
      { key: "item", label: "Milestone" },
      { key: "detail", label: "Record" },
    ],
    rows: [
      { id: "shipped", cells: { item: "Shipped (SAP)", detail: "12 pallets against the order" } },
      { id: "arrived", cells: { item: "Arrived (FourKites)", detail: "2026-08-19, two days past the window" } },
      { id: "temp", cells: { item: "In transit (FourKites)", detail: "One temperature excursion logged" } },
      { id: "received", cells: { item: "Received (SAP POD)", detail: "Signed for 9 pallets — three short" } },
    ],
    partyBlocks: [
      {
        heading: "Destination delivery address",
        lines: ["Kroger Distribution Center #014", "4450 Poth Rd", "Columbus, OH 43213", "United States"],
      },
    ],
    signature: [
      { label: "Signature of recipient", value: "J. Patterson" },
      { label: "Printed name / title", value: "J. Patterson — Receiving Clerk" },
      { label: "Date received", value: "2026-08-19" },
    ],
    stamp: {
      title: "Received",
      date: "2026-08-19",
      lines: ["Kroger DC #014", "Short 3 pallets", "Exception noted"],
      tone: "exception",
    },
    footnote: `Signed for 9 of 12 pallets — the shortage matches the ${usd(c.amount)} freight deduction.`,
    highlightRowIds: ["received"],
    highlightNote:
      "The POD is signed three pallets short and the load arrived late — matching the claim. Logistics confirms carrier liability before it is conceded.",
    aiSummary: `SAP and FourKites confirm delivery SHP-55120 arrived two days late and was signed three pallets short, matching the ${usd(c.amount)} freight deduction. It routes to Logistics to confirm carrier liability before any concession.`,
  };
}

/** The source document behind a given cause, for the evidence step. */
export function causeDoc(kind: CauseKind): SourceDoc {
  if (kind === "credit") return buildCreditMemoDoc();
  if (kind === "promotion") return buildPromotionDoc();
  return buildPodDoc();
}

/* ------------------------------------------------------------------ *
 * The response letter to Kroger, drafted from the split
 * ------------------------------------------------------------------ */

export const MULTI_CAUSE_LETTER_REF = "LTR-KR-4471";

export function renderMultiCauseLetter(): { subject: string; body: string } {
  const credit = creditCause();
  const promo = promoCause();
  const freight = freightCause();
  const routedTotal = multiCauseRouted(D).reduce((s, c) => s + c.amount, 0);

  const subject = `Your remittance ${D.remittanceRef} — ${usd(D.shortPay)} short payment resolved into three items`;

  const body = [
    `To the ${D.customerName} accounts payable team,`,
    ``,
    `We have reviewed the ${usd(D.shortPay)} deducted on remittance ${D.remittanceRef} and matched it to three separate items.`,
    ``,
    `1. ${usd(credit.amount)} — credit already issued. This is credit memo CM-88213, already open on your account. We have applied it and cleared the line; the reference CM-88123 on your remittance does not exist.`,
    ``,
    `2. ${usd(promo.amount)} — feature-and-display allowance. Matched to promotion VX-Q3-2214. Our trade team is confirming store and SKU eligibility against the proof of performance on file; we will issue a credit for the supported amount.`,
    ``,
    `3. ${usd(freight.amount)} — late, short delivery. Our records for delivery SHP-55120 show a late arrival signed three pallets short. Our logistics team is confirming carrier liability before this is conceded.`,
    ``,
    `The ${usd(credit.amount)} credit is applied today. For the remaining ${usd(routedTotal)}, please provide any additional backup within 30 days so we can close both items.`,
    ``,
    `Regards,`,
    `Order to Cash — Deduction Management`,
  ].join("\n");

  return { subject, body };
}

/** The response letter rendered as an attachable / archivable document. */
export function buildRetailerLetterDoc(sent: boolean): SourceDoc {
  const letter = renderMultiCauseLetter();
  const routedTotal = multiCauseRouted(D).reduce((s, c) => s + c.amount, 0);
  return {
    docId: `multi-cause-letter-${MULTI_CAUSE_LETTER_REF}`,
    title: `Retailer response ${MULTI_CAUSE_LETTER_REF}`,
    docLabel: "Deduction response letter",
    reference: MULTI_CAUSE_LETTER_REF,
    issuer: ISSUER,
    skin: "pod-letter",
    docDate: sent ? `Issued ${TODAY}` : "Draft — not yet sent",
    meta: [
      { label: "To", value: `${D.customerName} — Accounts Payable` },
      { label: "From", value: "Order to Cash — Deduction Management" },
      { label: "Status", value: sent ? "Issued" : "Draft — not yet sent" },
      { label: "Under review", value: usd(routedTotal) },
    ],
    columns: [
      { key: "item", label: "Correspondence" },
      { key: "value", label: "", align: "left" },
    ],
    rows: [
      { id: "subject", cells: { item: "Subject", value: letter.subject } },
      { id: "body", cells: { item: "Body", value: letter.body } },
    ],
    highlightRowIds: ["body"],
    highlightNote: sent
      ? "Issued to Kroger with the credit memo, promotion and proof-of-delivery attached."
      : "Drafted from the split. A person approves it before it is sent.",
    aiSummary: `The response sets out the three items behind the ${usd(D.shortPay)} short payment: the ${usd(creditCause().amount)} credit applied now, and the ${usd(routedTotal)} promotion and freight items under review, with 30 days requested for any additional backup.`,
  };
}
