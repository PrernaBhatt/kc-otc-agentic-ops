/**
 * Audit trail export: CSV (one row per entry, the same columns as the table)
 * and an A4 PDF with a control summary, the entry detail and a signature
 * block at the foot. Both read the same AuditEntry list the page shows.
 */

import { auditToCsv, formatAuditTime, signatureHash, type AuditEntry } from "./audit";
import { findAccount } from "./data/account-owners";
import { RUN_DATE } from "./data/clock";
import { findControl, soxControls } from "./data/sox-controls";
import { downloadBlob } from "./download";
import { formatUsd } from "./format";

export type AuditExportFormat = "csv" | "pdf";

export function auditExportFilename(scopeSlug: string, format: AuditExportFormat) {
  return `audit-trail_${scopeSlug}_${RUN_DATE.replace(/-/g, "")}.${format}`;
}

export interface ControlSummaryRow {
  ref: string;
  name: string;
  entries: number;
  signed: number;
  exceptions: number;
}

/** Per-control totals; an exception is a person decision without a signature. */
export function controlSummary(entries: AuditEntry[]): ControlSummaryRow[] {
  return soxControls
    .map((c) => {
      const rows = entries.filter((e) => e.controlRefs.includes(c.ref));
      return {
        ref: c.ref,
        name: c.name,
        entries: rows.length,
        signed: rows.filter((e) => e.signature).length,
        exceptions: rows.filter((e) => e.actor.kind === "person" && !e.signature).length,
      };
    })
    .filter((r) => r.entries > 0);
}

export async function exportAudit(
  entries: AuditEntry[],
  opts: { scopeLabel: string; scopeSlug: string; format: AuditExportFormat; exportedBy: string }
): Promise<{ filename: string; count: number }> {
  const filename = auditExportFilename(opts.scopeSlug, opts.format);
  if (opts.format === "csv") {
    downloadBlob(new Blob([auditToCsv(entries)], { type: "text/csv;charset=utf-8" }), filename);
    return { filename, count: entries.length };
  }

  const { jsPDF } = await import("jspdf");
  const { autoTable } = await import("jspdf-autotable");
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const pageW = doc.internal.pageSize.getWidth();
  const pageH = doc.internal.pageSize.getHeight();
  const margin = 36;
  const brand: [number, number, number] = [30, 109, 166];
  const ink: [number, number, number] = [16, 24, 32];
  const muted: [number, number, number] = [109, 110, 113];

  doc.setFillColor(...brand);
  doc.rect(0, 0, pageW, 72, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(16);
  doc.text("Audit trail export", margin, 32);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.text(
    `K-C Agentic Order to Cash · Scope: ${opts.scopeLabel} · ${entries.length} entries`,
    margin,
    50
  );
  doc.text(`Generated ${RUN_DATE} · Exported by ${opts.exportedBy}`, margin, 62);

  doc.setTextColor(...ink);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text("Controls evidenced", margin, 96);

  const summary = controlSummary(entries);
  autoTable(doc, {
    startY: 104,
    margin: { left: margin, right: margin },
    head: [["SOX", "Control", "Entries", "Signed", "Exceptions"]],
    body: summary.map((r) => [r.ref, r.name, r.entries, r.signed, r.exceptions]),
    styles: { fontSize: 8, cellPadding: 4, textColor: ink },
    headStyles: { fillColor: [240, 245, 247], textColor: ink, fontStyle: "bold" },
    columnStyles: { 2: { halign: "right" }, 3: { halign: "right" }, 4: { halign: "right" } },
  });

  const afterSummary =
    (doc as unknown as { lastAutoTable?: { finalY: number } }).lastAutoTable?.finalY ?? 140;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text("Entries", margin, afterSummary + 22);

  autoTable(doc, {
    startY: afterSummary + 30,
    margin: { left: margin, right: margin, bottom: 96 },
    head: [["Time", "Case", "Account", "Actor", "Action", "SOX", "Amount", "Signature"]],
    body: entries.map((e) => [
      formatAuditTime(e.at),
      e.caseId,
      findAccount(e.accountId)?.shortName ?? e.accountId,
      `${e.actor.name}${e.actor.kind === "agent" ? " (agent)" : ""}`,
      e.action,
      e.controlRefs.join(", "),
      e.amountUsd !== undefined ? formatUsd(e.amountUsd) : "",
      e.signature ? `${e.signature.signer} #${e.signature.hash.slice(0, 8)}` : "",
    ]),
    styles: { fontSize: 7, cellPadding: 3, textColor: ink, overflow: "linebreak" },
    headStyles: { fillColor: [240, 245, 247], textColor: ink, fontStyle: "bold" },
    columnStyles: { 0: { cellWidth: 58 }, 4: { cellWidth: 130 }, 6: { halign: "right" } },
    didDrawPage: () => {
      const page = doc.getCurrentPageInfo().pageNumber;
      doc.setFontSize(7);
      doc.setTextColor(...muted);
      doc.text(`Page ${page}`, pageW - margin, pageH - 18, { align: "right" });
    },
  });

  const exportHash = signatureHash(opts.exportedBy, RUN_DATE, String(entries.length), opts.scopeSlug);
  const footY = pageH - 80;
  doc.setDrawColor(...muted);
  doc.setLineWidth(0.5);
  doc.line(margin, footY, margin + 200, footY);
  doc.line(pageW - margin - 160, footY, pageW - margin, footY);
  doc.setFontSize(8);
  doc.setTextColor(...ink);
  doc.text(`Exported by ${opts.exportedBy}`, margin, footY + 12);
  doc.text(`Date ${RUN_DATE}`, pageW - margin - 160, footY + 12);
  doc.setTextColor(...muted);
  doc.text(
    `Export fingerprint #${exportHash} · controls ${summary.map((r) => r.ref).join(", ")}`,
    margin,
    footY + 26
  );

  downloadBlob(doc.output("blob"), filename);
  return { filename, count: entries.length };
}

export function controlName(ref: string) {
  return findControl(ref)?.name ?? ref;
}
