/**
 * Source documents for the Chargebacks and Deductions pages.
 *
 * Same rule as lib/docs.tsx: every field is read from the same records the
 * screen reads, so a document can never disagree with the screen that opened
 * it. Kept in its own file to leave lib/docs.tsx untouched.
 */

import type {
  DocTableColumn,
  SourceDoc,
} from "@/components/modals/source-doc-preview";
import {
  claimLineMath,
  claimPeriodUnits,
  claimSubmissionTotals,
  distributorName,
  duplicateScreen,
  formatUnitPrice,
  formatUsd,
  priceRecordsFor,
  recommendedSettlement,
  rosterCheck,
} from "./chargeback-selectors";
import { findClaim, findSettledClaim } from "./data/chargebacks";
import { findClaimPeriod } from "./data/contract-pricing";
import { findEndCustomer } from "./data/distributors";
import {
  channelAgreements,
  type ChannelAgreement,
} from "./data/channel-agreements";
import { renderDisputeLetter, shortPayPosition } from "./deduction-selectors";
import {
  renderShortPayLetter,
  shortPaySplit,
} from "./short-pay-selectors";
import type { JournalEntry } from "./data/journal-entries";
import {
  journalEntryTotals,
  type LedgerMovement,
} from "./journal-selectors";
import type { DeductionCase } from "./data/deductions";

const ISSUER = "Order to Cash Workspace";

/* ------------------------------------------------------------------ *
 * The claim, as the wholesaler filed it
 * ------------------------------------------------------------------ */

export function buildChargebackClaimDoc(claimId: string): SourceDoc {
  const claim = findClaim(claimId)!;
  const line = claim.lines[0];
  const math = claimLineMath(claimId);
  const period = findClaimPeriod(claim.periodId);
  const endCustomer = findEndCustomer(line.endCustomerId);

  return {
    docId: `claim-${claimId}`,
    title: `Chargeback claim ${claimId}`,
    docLabel: "Wholesaler chargeback claim",
    reference: claimId,
    issuer: ISSUER,
    meta: [
      { label: "Submitted", value: claim.submittedDate },
      { label: "Claim window", value: period?.label ?? "—" },
      { label: "End customer", value: endCustomer?.name ?? "—" },
      { label: "Contract cited", value: line.citedContractId },
    ],
    columns: [
      { key: "item", label: "As claimed" },
      { key: "value", label: "Value", align: "right" },
    ],
    rows: [
      {
        id: "product",
        cells: { item: line.productName, value: line.sku },
      },
      {
        id: "units",
        cells: {
          item: "Units claimed",
          value: line.claimedUnits.toLocaleString("en-US"),
        },
      },
      {
        id: "price",
        cells: {
          item: "Contract price stated on the claim",
          value: formatUnitPrice(line.claimedContractPrice),
        },
      },
      {
        id: "list",
        cells: {
          item: "Price invoiced to the wholesaler",
          value: formatUnitPrice(math?.listPrice ?? 0),
        },
      },
      {
        id: "perUnit",
        cells: {
          item: "Difference claimed back, per unit",
          value: formatUnitPrice(math?.claimedAdjustment ?? 0),
        },
      },
    ],
    totals: [
      {
        label: "Total claimed",
        value: formatUsd(math?.claimedAmount ?? 0),
        emphasis: true,
      },
    ],
    highlightRowIds: ["price", "units"],
    highlightNote:
      "The review turns on these two figures: the price claimed, and the number of units claimed.",
    footnote:
      "Chargeback claims settle by credit note against trade receivables, not against the customer's credit line.",
    aiSummary: `${claimId} claims ${formatUsd(math?.claimedAmount ?? 0)} against ${line.claimedUnits.toLocaleString("en-US")} units. Five checks precede settlement: project eligibility, contract price, duplicate screening, invoiced volume, and the effect on the reported price.`,
  };
}

/* ------------------------------------------------------------------ *
 * The roster the claim cites
 * ------------------------------------------------------------------ */

export function buildContractRosterDoc(claimId: string): SourceDoc {
  const check = rosterCheck(claimId);

  return {
    docId: `roster-${claimId}`,
    title: check.citedRoster?.label ?? "Contract roster",
    docLabel: "Contract roster — covered projects",
    reference: check.citedRoster?.contractId,
    issuer: check.citedRoster?.sponsor ?? ISSUER,
    meta: [
      { label: "Contract", value: check.citedRoster?.contractId ?? "—" },
      { label: "Projects covered", value: String(check.members.length) },
      {
        label: "Project on the claim",
        value: check.claimedEndCustomer?.name ?? "—",
      },
      {
        label: "On this roster",
        value: check.onCitedRoster ? "Yes" : "No",
      },
    ],
    columns: [
      { key: "project", label: "Project" },
      { key: "type", label: "Type" },
      { key: "since", label: "On the roster since", align: "right" },
    ],
    rows: check.members.map((m) => ({
      id: m.endCustomer.endCustomerId,
      cells: {
        project: m.endCustomer.name,
        type: `${m.endCustomer.projectType}, ${m.endCustomer.city} ${m.endCustomer.state}`,
        since: m.effectiveFrom,
      },
    })),
    highlightRowIds: check.onCitedRoster && check.claimedEndCustomer
      ? [check.claimedEndCustomer.endCustomerId]
      : check.siblingOnRoster
        ? [check.siblingOnRoster.endCustomerId]
        : [],
    highlightNote: check.onCitedRoster
      ? `${check.claimedEndCustomer?.name} is the project on this claim, and it is on the roster.`
      : undefined,
    aiSummary: check.onCitedRoster
      ? `${check.claimedEndCustomer?.name} appears on this roster from ${check.members.find((m) => m.endCustomer.endCustomerId === check.claimedEndCustomer?.endCustomerId)?.effectiveFrom ?? "—"}, and is entitled to ${formatUnitPrice(check.homePriceRecord?.contractPrice ?? 0)} per unit under it.`
      : `${check.claimedEndCustomer?.name} does not appear on this roster. It holds a separate agreement at ${formatUnitPrice(check.homePriceRecord?.contractPrice ?? 0)} per unit.`,
  };
}

/* ------------------------------------------------------------------ *
 * The price records
 * ------------------------------------------------------------------ */

export function buildContractPriceListDoc(claimId: string): SourceDoc {
  const claim = findClaim(claimId)!;
  const line = claim.lines[0];
  const check = rosterCheck(claimId);
  const period = findClaimPeriod(claim.periodId);
  const records = priceRecordsFor(line.sku);
  const inForceId = check.homePriceRecord?.priceRecordId;

  const statusOf = (r: (typeof records)[number]) => {
    if (r.priceRecordId === inForceId) return "In force for this project";
    if (r.rosterId === line.citedRosterId) return "Different roster";
    if (r.effectiveTo && period && r.effectiveTo < period.to) return "Expired";
    if (period && r.effectiveFrom > period.to) return "Not yet in force";
    return "Not applicable";
  };

  return {
    docId: `pricelist-${claimId}`,
    title: `Price records — ${line.productName}`,
    docLabel: "Contract price records",
    reference: line.sku,
    issuer: ISSUER,
    meta: [
      { label: "Product", value: line.productName },
      { label: "Tested on", value: period?.to ?? "—" },
      {
        label: "Price in force",
        value: formatUnitPrice(check.homePriceRecord?.contractPrice ?? 0),
      },
      { label: "Price claimed", value: formatUnitPrice(line.claimedContractPrice) },
    ],
    columns: [
      { key: "record", label: "Record" },
      { key: "contract", label: "Contract" },
      { key: "price", label: "Price", align: "right" },
      { key: "window", label: "Effective" },
      { key: "status", label: "Status" },
    ],
    rows: records.map((r) => ({
      id: r.priceRecordId,
      cells: {
        record: r.priceRecordId,
        contract: r.contractId,
        price: formatUnitPrice(r.contractPrice),
        window: `${r.effectiveFrom} → ${r.effectiveTo ?? "open"}`,
        status: statusOf(r),
      },
    })),
    highlightRowIds: [inForceId ?? "", "PR-4310"].filter(Boolean),
    highlightNote:
      "One record is the approved price for this project. The other is a valid price on a contract to which this project is not a party, and is the origin of the claimed figure.",
    aiSummary: `${inForceId} is the only record in force for this project on ${period?.to}. The ${formatUnitPrice(line.claimedContractPrice)} applied by the claim belongs to a different contract, on a roster that does not include this project.`,
  };
}

/* ------------------------------------------------------------------ *
 * The claim we already settled
 * ------------------------------------------------------------------ */

/**
 * The prior claims this one was screened against.
 *
 * It used to document a single settled twin, from a comparison that only
 * existed when a claim WAS a duplicate. The screen now runs on every claim, so
 * the document is the claim history for these two parties: one row per claim,
 * the one under review at the top, and the claim window as the field that
 * separates them.
 */
export function buildSettledClaimDoc(claimId: string): SourceDoc {
  const screen = duplicateScreen(claimId)!;
  const claim = findClaim(claimId)!;

  return {
    docId: `settled-history-${claimId}`,
    title: "Claim history for this wholesaler and project",
    docLabel: "Settled chargeback claims",
    reference: claim.lines[0].sku,
    issuer: ISSUER,
    meta: screen.fields
      .filter((f) => f.same)
      .map((f) => ({ label: f.label, value: f.values[0].join(", ") })),
    columns: [
      { key: "claim", label: "Claim" },
      { key: "window", label: "Claim window" },
      { key: "units", label: "Units", align: "right" },
      { key: "amount", label: "Amount", align: "right" },
      { key: "settled", label: "Settled", align: "right" },
    ],
    rows: screen.rows.map((r) => ({
      id: r.claimId,
      cells: {
        claim: r.claimId,
        window: r.period,
        units: r.units.toLocaleString("en-US"),
        amount: formatUsd(r.amount),
        settled: r.settledOn ?? "Under review",
      },
    })),
    totals: [
      {
        label: "Prior claims settled for these parties",
        value: String(screen.priorCount),
        emphasis: true,
      },
    ],
    highlightRowIds: [claimId],
    highlightNote:
      "The highlighted row is the claim under review. Its window does not appear on any settled claim above.",
    aiSummary: screen.distinct
      ? `${screen.priorCount} prior claims were settled for the same wholesaler, project and product, in earlier windows. None covers ${screen.rows[0].period}, so this is a different payment.`
      : `A settled claim already covers ${screen.rows[0].period}. This claim repeats a payment that has been made.`,
  };
}

/* ------------------------------------------------------------------ *
 * Our own invoice and delivery history
 * ------------------------------------------------------------------ */

export function buildClaimPeriodActivityDoc(claimId: string): SourceDoc {
  const claim = findClaim(claimId)!;
  const line = claim.lines[0];
  const units = claimPeriodUnits(claimId);
  const math = claimLineMath(claimId);
  const all = [...units.inPeriodRows, ...units.excludedRows];

  return {
    docId: `activity-${claimId}`,
    title: "Invoice and delivery history",
    docLabel: "Invoice and delivery history",
    reference: line.sku,
    issuer: ISSUER,
    meta: [
      { label: "Claim window", value: units.period?.label ?? "—" },
      { label: "Units claimed", value: line.claimedUnits.toLocaleString("en-US") },
      {
        label: "Units invoiced",
        value: units.supportedUnits.toLocaleString("en-US"),
      },
      {
        label: "Unaccounted for",
        value: (math?.unitsException ?? 0).toLocaleString("en-US"),
      },
    ],
    columns: [
      { key: "invoice", label: "Invoice" },
      { key: "date", label: "Invoice date" },
      { key: "delivery", label: "Delivery" },
      { key: "signed", label: "Signed for by" },
      { key: "units", label: "Units", align: "right" },
    ],
    rows: all.map((r) => ({
      id: r.activityId,
      cells: {
        invoice: r.invoiceRef,
        date: r.invoiceDate,
        delivery: r.deliveryRef,
        signed: r.podSignedBy,
        units: r.units.toLocaleString("en-US"),
      },
    })),
    totals: [
      {
        label: "Inside the claim window",
        value: `${units.supportedUnits.toLocaleString("en-US")} units`,
        emphasis: true,
      },
    ],
    highlightRowIds: units.inPeriodRows.map((r) => r.activityId),
    highlightNote:
      units.excludedRows.length > 0
        ? "Highlighted rows fall inside the claim window and support the claim. Rows not highlighted fall outside it and are excluded."
        : undefined,
    aiSummary: `${units.supportedUnits.toLocaleString("en-US")} units were invoiced and delivered to this project within the window, across ${units.inPeriodRows.length} invoices. The claim covers ${line.claimedUnits.toLocaleString("en-US")} units.`,
  };
}

/* ------------------------------------------------------------------ *
 * The file the wholesaler sent
 * ------------------------------------------------------------------ */

/**
 * The EDI 844 submission, in two readings.
 *
 * `matched: false` is the intake view — the eight resale lines exactly as
 * filed, with nothing marked, because at intake nothing has been tested.
 * `matched: true` is the volume-stage view — the same eight lines with the
 * shipment of ours that accounts for each, and three that have none. Showing
 * the same document twice is the point: the reader watches lines they have
 * already read acquire a verdict.
 */
export function buildClaimSubmissionDoc(
  claimId: string,
  { matched = false }: { matched?: boolean } = {}
): SourceDoc {
  const claim = findClaim(claimId)!;
  const line = claim.lines[0];
  const totals = claimSubmissionTotals(claimId);
  const math = claimLineMath(claimId);
  const period = findClaimPeriod(claim.periodId);
  const endCustomer = findEndCustomer(line.endCustomerId);
  const sub = totals.submission;

  const columns: DocTableColumn[] = [
    { key: "lineRef", label: "Line" },
    { key: "resale", label: "Wholesaler invoice to the project" },
    { key: "date", label: "Resale date" },
    { key: "units", label: "Units", align: "right" },
    { key: "price", label: "Price charged", align: "right" },
    { key: "claimed", label: "Claimed back", align: "right" },
  ];
  if (matched) {
    columns.push({ key: "match", label: "Matched shipment" });
  }

  return {
    docId: `submission-${claimId}${matched ? "-matched" : ""}`,
    title: matched
      ? "Claim submission, traced to shipment records"
      : "Chargeback claim submission",
    docLabel: sub?.transmissionType ?? "Chargeback claim submission",
    reference: sub?.submissionRef,
    issuer: `Submitted by ${distributorName(claim.distributorId)}`,
    meta: [
      { label: "Received", value: sub?.receivedOn ?? "—" },
      { label: "Claim window", value: period?.label ?? "—" },
      { label: "Resold to", value: endCustomer?.name ?? "—" },
      { label: "Contract cited", value: line.citedContractId },
      { label: "Resale lines", value: String(totals.lines.length) },
      {
        label: "Units claimed",
        value: totals.totalUnits.toLocaleString("en-US"),
      },
    ],
    columns,
    rows: totals.lines.map((l) => ({
      id: l.lineRef,
      cells: {
        lineRef: l.lineRef,
        resale: l.resaleRef,
        date: l.resaleDate,
        units: l.units.toLocaleString("en-US"),
        price: formatUnitPrice(l.resalePrice),
        claimed: formatUsd(l.units * ((math?.listPrice ?? 0) - l.resalePrice)),
        ...(matched
          ? {
              match: l.supportedByInvoiceRef ?? "No shipment",
            }
          : {}),
      },
    })),
    totals: matched
      ? [
          {
            label: "Matched to a shipment",
            value: `${totals.supportedUnits.toLocaleString("en-US")} units`,
          },
          {
            label: "No shipment record",
            value: `${totals.unsupportedUnits.toLocaleString("en-US")} units`,
            emphasis: true,
          },
        ]
      : [
          {
            label: "Total claimed",
            value: formatUsd(totals.totalClaimed),
            emphasis: true,
          },
        ],
    highlightRowIds: matched
      ? totals.unsupportedLines.map((l) => l.lineRef)
      : [],
    highlightNote: matched
      ? "Highlighted lines have no matching invoice or delivery record."
      : undefined,
    aiSummary: matched
      ? `${totals.supportedLines.length} of the ${totals.lines.length} resale lines follow a recorded shipment within days. ${totals.unsupportedLines.length} lines, covering ${totals.unsupportedUnits.toLocaleString("en-US")} units, have no shipment behind them: ${totals.unsupportedLines.map((l) => l.resaleRef).join(", ")}.`
      : `${totals.lines.length} resale lines covering ${totals.totalUnits.toLocaleString("en-US")} units, each claimed at ${formatUnitPrice(line.claimedContractPrice)} against a list price of ${formatUnitPrice(math?.listPrice ?? 0)}. The lines sum to ${formatUsd(totals.totalClaimed)}. None of it has been verified against the contract, invoice or delivery records yet.`,
  };
}

/* ------------------------------------------------------------------ *
 * The settlement the human approved
 * ------------------------------------------------------------------ */

export function buildChargebackSettlementDoc(
  claimId: string,
  creditNoteId: string,
  decidedAt: string
): SourceDoc {
  const settlement = recommendedSettlement(claimId)!;
  const math = claimLineMath(claimId)!;

  return {
    docId: `settlement-${claimId}`,
    title: `Settlement of ${claimId}`,
    docLabel: "Chargeback settlement",
    reference: creditNoteId,
    issuer: ISSUER,
    meta: [
      { label: "Decided", value: decidedAt },
      { label: "Credit note", value: creditNoteId },
      { label: "Claimed", value: formatUsd(settlement.claimedTotal) },
      { label: "Approved", value: formatUsd(settlement.approveAmount) },
    ],
    columns: [
      { key: "line", label: "Line" },
      { key: "basis", label: "Basis" },
      { key: "amount", label: "Amount", align: "right" },
    ],
    rows: [
      {
        id: "approved",
        cells: {
          line: "Approved and credited",
          basis: `${math.supportedUnits.toLocaleString("en-US")} units at ${formatUnitPrice(math.approvedContractPrice)}`,
          amount: formatUsd(settlement.approveAmount),
        },
      },
      {
        id: "rejected-quantity",
        cells: {
          line: "Rejected · no delivery record",
          basis: `${math.unitsException.toLocaleString("en-US")} units with no invoice or delivery`,
          amount: formatUsd(settlement.quantityComponent),
        },
      },
      {
        id: "rejected-price",
        cells: {
          line: "Rejected · price not approved",
          basis: `${formatUnitPrice(math.unsupportedRateDelta)} a unit below the approved price`,
          amount: formatUsd(settlement.priceComponent),
        },
      },
      {
        id: "block",
        cells: {
          line: "Payment held pending response",
          basis: settlement.placePaymentBlock ? "Placed" : "Not placed",
          amount: settlement.placePaymentBlock
            ? formatUsd(settlement.rejectAmount)
            : "—",
        },
      },
    ],
    totals: [
      { label: "Claimed", value: formatUsd(settlement.claimedTotal) },
      {
        label: "Rejected",
        value: formatUsd(settlement.rejectAmount),
        emphasis: true,
      },
    ],
    highlightRowIds: ["rejected-quantity", "rejected-price"],
    highlightNote:
      "The two rejected lines are separate findings with separate evidence. Undocumented units are removed first, at the adjustment claimed; the price is then corrected on the units that remain.",
    aiSummary: `${formatUsd(settlement.approveAmount)} was approved and ${formatUsd(settlement.rejectAmount)} rejected on ${decidedAt}. Credit note ${creditNoteId} covers the approved amount.`,
  };
}

/* ------------------------------------------------------------------ *
 * Deductions
 * ------------------------------------------------------------------ */

export function buildDisputeLetterDoc(
  deduction: DeductionCase,
  opts?: { sent?: boolean }
): SourceDoc {
  const letter = deduction.disputeLetter!;
  const math = claimLineMath(deduction.linkedClaimId!)!;
  const position = shortPayPosition(deduction);
  const rendered = renderDisputeLetter(deduction);

  return {
    docId: `dispute-${deduction.deductionId}${opts?.sent ? "-sent" : "-draft"}`,
    title: `Dispute letter ${letter.letterRef}`,
    docLabel: "Deduction dispute letter",
    reference: letter.letterRef,
    issuer: ISSUER,
    meta: [
      { label: "To", value: letter.to },
      { label: "Invoice", value: deduction.invoiceId },
      { label: "Amount disputed", value: formatUsd(deduction.amount) },
      {
        label: "Status",
        value: opts?.sent
          ? `Sent ${deduction.disputeSentDate ?? ""}`.trim()
          : "Draft — awaiting approval",
      },
    ],
    columns: [
      { key: "item", label: "Cited in the letter" },
      { key: "detail", label: "Detail" },
      { key: "status", label: "Status", align: "right" },
    ],
    rows: [
      {
        id: "claim",
        cells: {
          item: `Chargeback claim ${deduction.linkedClaimId}`,
          detail: `${formatUsd(math.claimedAmount)} claimed by ${deduction.customerName}`,
          status: "On file",
        },
      },
      {
        id: "rejection",
        cells: {
          item: "Our rejection",
          detail: `${formatUsd(math.unsupportedAmount)} rejected: ${formatUsd(math.quantityComponent)} no delivery record, ${formatUsd(math.priceComponent)} price not approved`,
          status: "Sent to the customer",
        },
      },
      {
        id: "contract",
        cells: {
          item: `Price record ${math.approvedPriceRecord?.priceRecordId}`,
          detail: `The approved price of ${formatUnitPrice(math.approvedContractPrice)} against which the claim was tested`,
          status: "On file",
        },
      },
      {
        id: "deduction",
        cells: {
          item: `Short payment on ${deduction.invoiceId}`,
          detail: `${formatUsd(position.withheld)} withheld on ${position.remittance?.receivedDate ?? "—"}`,
          status: "Confirmed by the remittance",
        },
      },
      {
        id: "authority",
        cells: {
          item: "Authority to deduct this amount",
          detail: "No approved credit note exists",
          status: "Not found",
        },
      },
    ],
    totals: [
      {
        label: "Repayment requested",
        value: formatUsd(deduction.amount),
        emphasis: true,
      },
    ],
    highlightRowIds: ["claim", "authority"],
    highlightNote:
      "The case rests on these two lines: the claim was rejected, and no authority exists for the deduction.",
    footnote:
      "Repayment requested within 30 days. Issued only on approval.",
    aiSummary: `${deduction.customerName} withheld ${formatUsd(deduction.amount)}, identical to the amount rejected on ${deduction.linkedClaimId}. No credit note authorises the deduction, and it remains due. ${rendered ? "Repayment is requested within 30 days." : ""}`,
  };
}

export function buildRemittanceAdviceDoc(deduction: DeductionCase): SourceDoc {
  const position = shortPayPosition(deduction);

  return {
    docId: `remittance-${deduction.deductionId}`,
    title: `Remittance ${position.remittance?.remittanceId}`,
    docLabel: "Customer remittance advice",
    reference: position.remittance?.remittanceId,
    issuer: deduction.customerName,
    meta: [
      { label: "Received", value: position.remittance?.receivedDate ?? "—" },
      { label: "Payer", value: position.remittance?.payerName ?? "—" },
      { label: "Invoice", value: deduction.invoiceId },
      { label: "Paid", value: formatUsd(position.paid) },
    ],
    columns: [
      { key: "line", label: "Line" },
      { key: "amount", label: "Amount", align: "right" },
    ],
    rows: [
      {
        id: "invoiced",
        cells: { line: "Invoice total", amount: formatUsd(position.invoiced) },
      },
      {
        id: "withheld",
        cells: { line: "Withheld", amount: `(${formatUsd(position.withheld)})` },
      },
      {
        id: "paid",
        cells: { line: "Paid", amount: formatUsd(position.paid) },
      },
    ],
    totals: [
      {
        label: "Invoice less withheld equals paid",
        value: position.reconciles ? "Reconciles" : "Does not reconcile",
        emphasis: true,
      },
    ],
    highlightRowIds: ["withheld"],
    highlightNote: `Remittance note: "${position.remittance?.customerNote}"`,
    aiSummary: `${deduction.customerName} remitted ${formatUsd(position.paid)} against an invoice of ${formatUsd(position.invoiced)} and withheld ${formatUsd(position.withheld)}. The remittance note cites the chargeback claim as the reason.`,
  };
}

/* ------------------------------------------------------------------ *
 * The accounting entry
 * ------------------------------------------------------------------ */

export function buildJournalEntryDoc(
  entry: JournalEntry,
  posted: boolean
): SourceDoc {
  const totals = journalEntryTotals(entry);

  return {
    docId: `journal-${entry.entryId}${posted ? "-posted" : "-draft"}`,
    title: entry.headline,
    docLabel: "Accounting entry",
    reference: posted ? entry.documentNumber : "Not yet posted",
    issuer: ISSUER,
    meta: [
      { label: "Company code", value: `${entry.companyCode} — ${entry.companyCodeGloss}` },
      { label: "Ledger", value: `${entry.ledger} — ${entry.ledgerGloss}` },
      { label: "Posting period", value: entry.postingPeriodLabel },
      {
        label: posted ? "Document number" : "Document type",
        value: posted
          ? entry.documentNumber
          : `${entry.documentType} — ${entry.documentTypeGloss}`,
      },
    ],
    columns: [
      { key: "line", label: "Line" },
      { key: "account", label: "Account" },
      { key: "debit", label: "Debit", align: "right" },
      { key: "credit", label: "Credit", align: "right" },
    ],
    rows: entry.lines.map((l) => ({
      id: String(l.lineNumber),
      cells: {
        line: String(l.lineNumber),
        account: `${l.glAccount} — ${l.plainName}`,
        debit: l.debit ? formatUsd(l.debit) : "—",
        credit: l.credit ? formatUsd(l.credit) : "—",
      },
    })),
    totals: [
      { label: "Debits", value: formatUsd(totals.debitTotal) },
      { label: "Credits", value: formatUsd(totals.creditTotal) },
      {
        label: "Difference",
        value: formatUsd(totals.difference),
        emphasis: true,
      },
    ],
    highlightRowIds: entry.lines.map((l) => String(l.lineNumber)),
    highlightNote:
      "Both lines carry the same amount in opposite directions. An entry that does not balance cannot be posted.",
    aiSummary: `The reserve is short by ${formatUsd(totals.debitTotal)}. This entry books the shortfall: the cost to the expense account, the obligation to the liability account. The entry balances${posted ? ` and was posted as document ${entry.documentNumber} on ${entry.postingDate}` : " and awaits approval"}.`,
  };
}

export function buildLedgerMovementDoc(
  entry: JournalEntry,
  movements: LedgerMovement[]
): SourceDoc {

  return {
    docId: "ledger-movement",
    title: "General ledger movement",
    docLabel: "General ledger movement",
    reference: entry.documentNumber,
    issuer: ISSUER,
    meta: [
      { label: "Period", value: entry.postingPeriodLabel },
      { label: "Posting date", value: entry.postingDate },
      { label: "Currency", value: entry.currency },
      { label: "Accounts moved", value: String(movements.length) },
    ],
    columns: [
      { key: "account", label: "Account" },
      { key: "opening", label: "Opening", align: "right" },
      { key: "movement", label: "This entry", align: "right" },
      { key: "closing", label: "Closing", align: "right" },
    ],
    rows: movements.map((m) => ({
      id: m.account,
      cells: {
        account: `${m.account} — ${m.plainName}`,
        opening: formatUsd(m.opening),
        movement: `${m.direction} ${formatUsd(m.change)}`,
        closing: formatUsd(m.closing),
      },
    })),
    highlightRowIds: movements.map((m) => m.account),
    highlightNote:
      "The same amount is posted to both accounts, one as a debit and one as a credit.",
    aiSummary: `The reserve rises to ${formatUsd(movements.find((m) => m.direction === "Credit")?.closing ?? 0)} and the programme cost for the period stands at ${formatUsd(movements.find((m) => m.direction === "Debit")?.closing ?? 0)}.`,
  };
}

/* ------------------------------------------------------------------ *
 * The three agreements the claim rests on
 * ------------------------------------------------------------------ */

/**
 * One agreement, as a document.
 *
 * The chain is three contracts and a reader cannot judge the claim without
 * seeing all three: what the wholesaler paid us, what the project paid the
 * wholesaler, and whether we ever agreed to that project price. Each opens
 * with its own clauses, because the clause is what settles the argument -
 * 4.2 on the project pricing agreement is the whole eligibility finding.
 */
export function buildAgreementDoc(agreementId: string): SourceDoc {
  const a = channelAgreements.find((x) => x.agreementId === agreementId)!;
  const linkLabel: Record<ChannelAgreement["link"], string> = {
    "mfg-wholesaler": "What the wholesaler pays us",
    "wholesaler-project": "What the project pays the wholesaler",
    "mfg-project": "What we have agreed the project may pay",
  };

  return {
    docId: `agreement-${a.agreementId}`,
    title: `${a.title} — ${a.fromName} to ${a.toName}`,
    docLabel: a.title,
    reference: a.agreementId,
    issuer: a.fromName,
    meta: [
      { label: "Between", value: `${a.fromName} and ${a.toName}` },
      { label: "Product", value: a.sku },
      { label: "Price per unit", value: formatUnitPrice(a.unitPrice) },
      { label: "Effective from", value: a.effectiveFrom },
      { label: "Signed by", value: a.signedBy },
      { label: "Establishes", value: linkLabel[a.link] },
    ],
    // The distribution agreement's clauses are long, and the shared table cell
    // carries whitespace-nowrap, so in two columns they ran off the page. It
    // renders as three paragraphs instead: one column, the clause number
    // inline, and wrapping restored locally rather than in the shared table.
    columns:
      a.link === "mfg-wholesaler"
        ? [{ key: "clause", label: "Terms" }]
        : [
            { key: "ref", label: "Clause" },
            { key: "text", label: "Terms" },
          ],
    rows: a.clauses.map((c) =>
      a.link === "mfg-wholesaler"
        ? {
            id: c.ref,
            cells: {
              clause: (
                <p className="whitespace-normal py-1 leading-relaxed">
                  <span className="mr-2 font-semibold">{c.ref}</span>
                  {c.text}
                </p>
              ),
            },
          }
        : { id: c.ref, cells: { ref: c.ref, text: c.text } }
    ),
    totals: [
      {
        label: "Price per unit under this agreement",
        value: formatUnitPrice(a.unitPrice),
        emphasis: true,
      },
    ],
    highlightRowIds: a.link === "mfg-project" ? ["4.2"] : [],
    highlightNote:
      a.link === "mfg-project"
        ? "Entitlement attaches to the project named on the roster, not to the owner group it belongs to."
        : undefined,
    aiSummary: `${a.establishes} ${formatUnitPrice(a.unitPrice)} per unit for ${a.sku}, in force from ${a.effectiveFrom}.`,
  };
}

/* ------------------------------------------------------------------ *
 * The short-pay case's evidence
 * ------------------------------------------------------------------ */

/** The payment as it arrived, against the invoice it was meant to settle. */
export function buildShortPayRemittanceDoc(caseId: string): SourceDoc {
  const split = shortPaySplit(caseId)!;
  const c = split.case;
  const usd = (n: number) => formatUsd(n);

  return {
    docId: `sp-remittance-${caseId}`,
    title: `Remittance ${c.remittanceId}`,
    docLabel: "Remittance advice",
    reference: c.remittanceId,
    issuer: c.customerName,
    meta: [
      { label: "Received", value: c.receivedDate },
      { label: "Against invoice", value: c.invoiceId },
      { label: "Invoice dated", value: c.invoiceDate },
      { label: "Paid", value: usd(c.amountPaid) },
    ],
    columns: [
      { key: "item", label: "Line" },
      { key: "amount", label: "Amount", align: "right" },
    ],
    rows: [
      {
        id: "invoice",
        cells: { item: `Invoice ${c.invoiceId}`, amount: usd(c.invoiceAmount) },
      },
      {
        id: "paid",
        cells: { item: "Settled by this remittance", amount: usd(c.amountPaid) },
      },
      {
        id: "withheld",
        cells: { item: "Withheld against chargebacks", amount: usd(split.shortPay) },
      },
    ],
    totals: [
      { label: "Short paid", value: usd(split.shortPay), emphasis: true },
    ],
    highlightRowIds: ["withheld"],
    highlightNote: `The remittance names no claim. It says only: “${c.customerNote}”`,
    aiSummary: `${c.customerName} settled ${usd(c.amountPaid)} of a ${usd(c.invoiceAmount)} invoice, withholding ${usd(split.shortPay)} against chargebacks without identifying which.`,
  };
}

/** The credit memo that makes part of the deduction a second bite. */
export function buildCreditMemoDoc(caseId: string): SourceDoc {
  const split = shortPaySplit(caseId)!;
  const cm = split.case.creditMemo;

  return {
    docId: `sp-creditmemo-${caseId}`,
    title: `Credit memo ${cm.creditMemoId}`,
    docLabel: "Credit memo",
    reference: cm.creditMemoId,
    issuer: ISSUER,
    meta: [
      { label: "Issued", value: cm.issuedOn },
      { label: "Cleared", value: cm.clearedOn },
      { label: "Against claim", value: cm.againstClaimId },
      { label: "Amount", value: formatUsd(cm.amount) },
    ],
    columns: [
      { key: "item", label: "Item" },
      { key: "value", label: "Value", align: "right" },
    ],
    rows: [
      {
        id: "claim",
        cells: { item: `Chargeback claim ${cm.againstClaimId}`, value: formatUsd(cm.amount) },
      },
      { id: "issued", cells: { item: "Credit issued", value: cm.issuedOn } },
      { id: "cleared", cells: { item: "Applied and cleared", value: cm.clearedOn } },
    ],
    totals: [
      { label: "Credited to the distributor", value: formatUsd(cm.amount), emphasis: true },
    ],
    highlightRowIds: ["cleared"],
    highlightNote:
      "The credit was applied and cleared before this remittance arrived, so the amount was already in the distributor's hands.",
    aiSummary: `${formatUsd(cm.amount)} was credited against ${cm.againstClaimId} on ${cm.issuedOn} and cleared on ${cm.clearedOn}. Deducting it again claims the same money twice.`,
  };
}

/** The claim the distributor IS entitled to deduct against. */
export function buildApprovedClaimDoc(caseId: string): SourceDoc {
  const split = shortPaySplit(caseId)!;
  const a = split.case.approvedClaim;

  return {
    docId: `sp-claim-${caseId}`,
    title: `Approved claim ${a.claimId}`,
    docLabel: "Chargeback claim — approved",
    reference: a.claimId,
    issuer: ISSUER,
    meta: [
      { label: "Approved", value: a.approvedOn },
      { label: "Units", value: a.units.toLocaleString("en-US") },
      { label: "Credit per unit", value: formatUnitPrice(a.unitCredit) },
      { label: "Amount", value: formatUsd(a.amount) },
    ],
    columns: [
      { key: "item", label: "Item" },
      { key: "value", label: "Value", align: "right" },
    ],
    rows: [
      {
        id: "units",
        cells: { item: "Units approved", value: a.units.toLocaleString("en-US") },
      },
      {
        id: "rate",
        cells: { item: "Credit per unit", value: formatUnitPrice(a.unitCredit) },
      },
      { id: "status", cells: { item: "Credit note issued", value: "Not issued" } },
    ],
    totals: [{ label: "Approved", value: formatUsd(a.amount), emphasis: true }],
    highlightRowIds: ["status"],
    highlightNote:
      "Approved but not yet credited, which is why the distributor is entitled to withhold it.",
    aiSummary: `${a.claimId} was approved on ${a.approvedOn} for ${formatUsd(a.amount)} and has not been credited. The deduction against it is valid.`,
  };
}

/** The dispute letter for the short-pay case. */
export function buildShortPayLetterDoc(caseId: string, sent: boolean): SourceDoc {
  const split = shortPaySplit(caseId)!;
  const letter = renderShortPayLetter(caseId)!;
  const c = split.case;

  return {
    docId: `sp-letter-${caseId}${sent ? "-sent" : ""}`,
    title: `Dispute letter ${c.disputeLetter.letterRef}`,
    docLabel: "Dispute correspondence",
    reference: c.disputeLetter.letterRef,
    issuer: c.disputeLetter.from,
    meta: [
      { label: "To", value: c.disputeLetter.to },
      { label: "Status", value: sent ? "Issued" : "Draft" },
      { label: "Repayment requested", value: formatUsd(split.recoverAmount) },
      { label: "Accepted", value: formatUsd(split.acceptAmount) },
    ],
    columns: [
      { key: "item", label: "Attachment" },
      { key: "ref", label: "Reference", align: "right" },
    ],
    rows: c.disputeLetter.attachments.map((a) => ({
      id: a.id,
      cells: { item: a.label, ref: a.id },
    })),
    footnote: letter.body,
    highlightRowIds: [],
    aiSummary: `The letter accepts ${formatUsd(split.acceptAmount)} and requests repayment of ${formatUsd(split.recoverAmount)}, citing the credit memo that already settled it.`,
  };
}
