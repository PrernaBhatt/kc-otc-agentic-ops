/**
 * Tie-outs for the OM Command Center and the OTIF-at-risk runs (PRD 02 §6).
 * Every rate is derived from counts, every route time from drive and unload
 * minutes. A broken figure throws at import, so a bad edit cannot reach the demo.
 */

import { PREMIUM_FREIGHT_LIMIT_USD } from "./data/account-owners";
import { OM_BASE_ORDERS, ORDER_TO_INVOICE, OTIF, OTIF_BY_CUSTOMER, PERFECT_ORDER, VALIDATION_ACCURACY } from "./data/om-kpis";
import { LOAD_MILESTONES, NETWORK_LOADS, OTIF_FORECAST, type EtaLeg, type EtaPrediction, type NetworkLoad } from "./data/loads";
import { ORDER_LOGISTICS, insideOtifWindow } from "./data/order-logistics";
import {
  APPOINTMENT_CASE,
  MILK_RUN_CASE,
  PREMIUM_CASE,
  RISK_ROWS,
  type MilkRunStop,
  type RiskLevel,
  type RiskRow,
  type RouteOption,
  type StopId,
} from "./data/shipment-risk";

function assert(cond: boolean, msg: string) {
  if (!cond) throw new Error(`[shipment tie-out] ${msg}`);
}

const pct = (n: number, d: number) => Math.round((n / d) * 1000) / 10;
const sum = (xs: number[]) => xs.reduce((s, x) => s + x, 0);

/* ---------------- time helpers ---------------- */

/** Minutes since epoch for "YYYY-MM-DD HH:MM". */
export function toMin(stamp: string) {
  const [d, t] = stamp.split(" ");
  const [y, m, day] = d.split("-").map(Number);
  const [h, min] = t.split(":").map(Number);
  return Date.UTC(y, m - 1, day, h, min) / 60_000;
}

/** Minutes of day for "HH:MM". */
export const hm = (t: string) => {
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
};

export const fmtHm = (mins: number) =>
  `${String(Math.floor(mins / 60)).padStart(2, "0")}:${String(mins % 60).padStart(2, "0")}`;

const DAY = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

/** "2026-08-25 21:30" → "Tue 08-25 21:30". */
export function shortStamp(stamp: string) {
  const [d, t] = stamp.split(" ");
  const dow = DAY[new Date(`${d}T00:00:00Z`).getUTCDay()];
  return `${dow} ${d.slice(5)} ${t}`;
}

/* ---------------- OM Command Center ---------------- */

const [stageA, stageS, stageD] = OTIF.stages;
assert(stageA.orders >= stageS.orders && stageS.orders >= stageD.orders, "OTIF A ≥ S ≥ D");
assert(OM_BASE_ORDERS - stageA.orders === sum(OTIF.losses.beforeA.map((r) => r.orders)), "OTIF losses before A");
assert(stageA.orders - stageS.orders === sum(OTIF.losses.aToS.map((r) => r.orders)), "OTIF losses A → S");
assert(stageS.orders - stageD.orders === sum(OTIF.losses.sToD.map((r) => r.orders)), "OTIF losses S → D");

export const otifPct = {
  A: pct(stageA.orders, OM_BASE_ORDERS),
  S: pct(stageS.orders, OM_BASE_ORDERS),
  D: pct(stageD.orders, OM_BASE_ORDERS),
};
assert(otifPct.A === 96.8 && otifPct.S === 93.4 && otifPct.D === 89.6, "OTIF 96.8 / 93.4 / 89.6");
assert(OTIF.trendD[OTIF.trendD.length - 1] === otifPct.D, "OTIF trend ends at D");

const comp = (k: string) => PERFECT_ORDER.components.find((c) => c.key === k)!.passing;
const inFullFail = OM_BASE_ORDERS - comp("in-full");
const onTimeFail = OM_BASE_ORDERS - comp("on-time");
assert(
  OM_BASE_ORDERS - (inFullFail + onTimeFail - PERFECT_ORDER.failBothOnTimeAndInFull) === stageD.orders,
  "on time ∩ in full = OTIF D"
);
const allFailures = sum(PERFECT_ORDER.components.map((c) => OM_BASE_ORDERS - c.passing));
assert(
  PERFECT_ORDER.perfect <= Math.min(...PERFECT_ORDER.components.map((c) => c.passing)) &&
    PERFECT_ORDER.perfect >= OM_BASE_ORDERS - allFailures &&
    PERFECT_ORDER.perfect <= stageD.orders,
  "perfect order bounded by its components"
);

export const perfectOrder = {
  pct: pct(PERFECT_ORDER.perfect, OM_BASE_ORDERS),
  components: PERFECT_ORDER.components.map((c) => ({
    ...c,
    pct: pct(c.passing, OM_BASE_ORDERS),
    failing: OM_BASE_ORDERS - c.passing,
  })),
};
assert(perfectOrder.pct === 85.6, "perfect order 85.6");
assert(
  perfectOrder.components.find((c) => c.key === "dispute-free")?.pct === 98.2,
  "dispute free counts non-trade disputes only: 98.2"
);
assert(PERFECT_ORDER.trend[PERFECT_ORDER.trend.length - 1] === perfectOrder.pct, "perfect trend ends at value");

const va = VALIDATION_ACCURACY;
assert(va.autoReleased + va.heldForReview === va.validated, "validated = released + held");
assert(va.heldConfirmed + va.falseHolds === va.heldForReview, "held = confirmed + false holds");
export const validationAccuracy = {
  correct: va.validated - va.falseHolds - va.missedErrors,
  pct: pct(va.validated - va.falseHolds - va.missedErrors, va.validated),
};
assert(validationAccuracy.pct === 99.1, "validation accuracy 99.1");
assert(va.trend[va.trend.length - 1] === validationAccuracy.pct, "validation trend ends at value");

export const orderToInvoiceDays = Math.round(sum(ORDER_TO_INVOICE.phases.map((p) => p.days)) * 10) / 10;
assert(orderToInvoiceDays === 6.4, "order-to-invoice 6.4 days");
assert(ORDER_TO_INVOICE.trend[ORDER_TO_INVOICE.trend.length - 1] === orderToInvoiceDays, "cycle trend ends at value");

/* ---------------- Happy path appointments ---------------- */

assert(insideOtifWindow(ORDER_LOGISTICS["SO-710260"].otifWindow, "Sat 2026-08-29", "06:00"), "Costco slot inside window");
assert(insideOtifWindow(ORDER_LOGISTICS["SO-710249"].otifWindow, "Fri 2026-08-28", "09:00"), "Target slot inside window");

/* ---------------- Risk board ---------------- */

export function etaInside(row: RiskRow) {
  const eta = toMin(row.track.eta);
  return eta >= toMin(row.track.windowFrom) && eta < toMin(row.track.windowTo);
}

/** Track positions as percent of the row's axis. */
export function trackPositions(row: RiskRow) {
  const from = toMin(row.track.axisFrom);
  const span = toMin(row.track.axisTo) - from;
  const at = (s: string) => Math.max(0, Math.min(100, ((toMin(s) - from) / span) * 100));
  return { windowFrom: at(row.track.windowFrom), windowTo: at(row.track.windowTo), eta: at(row.track.eta) };
}

for (const r of RISK_ROWS) {
  assert(r.level === "high" ? !etaInside(r) : etaInside(r), `${r.caseId} level matches its ETA`);
  assert(!!r.run !== !!r.watch, `${r.caseId} is either a run or watched`);
}

const LEVELS: RiskLevel[] = ["high", "medium", "low"];
export const riskSummary = {
  total: RISK_ROWS.length,
  pre: RISK_ROWS.filter((r) => r.lane === "pre").length,
  post: RISK_ROWS.filter((r) => r.lane === "post").length,
  needAction: RISK_ROWS.filter((r) => r.run).length,
  byLevel: LEVELS.map((level) => ({ level, count: RISK_ROWS.filter((r) => r.level === level).length })),
  highValueUsd: sum(RISK_ROWS.filter((r) => r.level === "high").map((r) => r.valueUsd)),
};
assert(riskSummary.total === 7 && riskSummary.pre === 4 && riskSummary.post === 3, "risk board 7 = 4 + 3");
assert(riskSummary.needAction === 3, "3 need action");
assert(riskSummary.highValueUsd === 396_600, "high-risk value 396,600");

/* ---------------- Run A ---------------- */

const a = APPOINTMENT_CASE;
const slotStart = toMin(`${a.appointment.day} ${a.appointment.from}`);
export const appointmentRun = {
  noSlotInWindow: a.calendar
    .filter((d) => d.date.split(" ")[1] <= a.otifWindow.mabd)
    .every((d) => d.slots.every((s) => s.state === "full")),
  firstOpenAfterMabd: (() => {
    const day = a.calendar.find((d) => d.slots.some((s) => s.state === "open"))!;
    return `${day.date.split(" ")[0]} ${day.slots.find((s) => s.state === "open")!.time}`;
  })(),
  slotInsideWindow: a.appointment.day >= a.otifWindow.from && a.appointment.day <= a.otifWindow.mabd,
  needsReplan: a.tmsPlan.eta.split(" ")[0] !== a.appointment.day,
};
assert(appointmentRun.noSlotInWindow, "Run A: no open slot up to MABD");
assert(appointmentRun.slotInsideWindow, "Run A: confirmed slot inside window");
assert(appointmentRun.needsReplan, "Run A: TMS ETA date differs from slot");
assert(toMin(a.replan.eta) <= slotStart, "Run A: new ETA before slot");

/* ---------------- Run B ---------------- */

const b = PREMIUM_CASE;
const opt = (id: string) => b.options.find((o) => o.id === id)!;
const windowFrom = toMin(b.appointment.from);
const windowTo = toMin(b.appointment.to);
export function optionOutcome(id: string) {
  const o = opt(id);
  const onTime = toMin(o.eta) <= windowTo;
  const inFull = o.pallets === b.pallets;
  return { onTime, inFull, pass: onTime && inFull, lateDays: onTime ? 0 : Math.ceil((toMin(o.eta) - windowFrom) / 1440) };
}
export const premiumFreight = {
  baseUsd: opt("keep").rateUsd,
  rateUsd: opt("team").rateUsd,
  premiumUsd: opt("team").rateUsd - opt("keep").rateUsd,
  fineUsd: Math.round((b.valueUsd * b.fineRatePct) / 100),
  netUsd: Math.round((b.valueUsd * b.fineRatePct) / 100) - (opt("team").rateUsd - opt("keep").rateUsd),
  withinLimit: opt("team").rateUsd - opt("keep").rateUsd <= PREMIUM_FREIGHT_LIMIT_USD,
};
assert(premiumFreight.premiumUsd === 1_740, "Run B: premium 1,740");
assert(premiumFreight.fineUsd === 2_964, "Run B: fine 2,964");
assert(premiumFreight.netUsd === 1_224, "Run B: net 1,224");
assert(premiumFreight.withinLimit, "Run B: premium within the $2,500 limit");
assert(!optionOutcome("keep").pass && optionOutcome("keep").lateDays === 1, "Run B: keep misses by 1 day");
assert(optionOutcome("team").pass, "Run B: team expedite passes");
assert(!optionOutcome("dc-atl").inFull, "Run B: DC-ATL is short");
assert(b.options.find((o) => o.recommended)?.id === "team", "Run B: team is recommended");

/* ---------------- Run C ---------------- */

const m = MILK_RUN_CASE;
const drive = (from: string, to: string) => m.driveMin[`${from}-${to}`] ?? m.driveMin[`${to}-${from}`];
export const stopById = (id: StopId) => m.stops.find((s) => s.id === id) as MilkRunStop;

export interface StopTiming {
  stop: MilkRunStop;
  arrive: number;
  depart: number;
  lateMin: number;
  miss: boolean;
}

/** Each arrival = previous departure + drive; departure = max(arrival, window open) + unload. */
export function routeTimeline(order: StopId[], departAt = m.actualDepart): StopTiming[] {
  let clock = hm(departAt);
  let at = "DC";
  return order.map((id) => {
    const stop = stopById(id);
    const arrive = clock + drive(at, id);
    const depart = Math.max(arrive, hm(stop.windowFrom)) + m.unloadMin;
    const lateMin = Math.max(0, arrive - hm(stop.windowTo));
    clock = depart;
    at = id;
    return { stop, arrive, depart, lateMin, miss: arrive > hm(stop.windowTo) };
  });
}

export const routeResults = m.routes.map((r: RouteOption) => {
  const timeline = routeTimeline(r.order);
  return { ...r, timeline, misses: timeline.filter((t) => t.miss).length };
});
export const recommendedRoute = [...routeResults].sort((x, y) => x.misses - y.misses)[0];

const fmt = (r: (typeof routeResults)[number]) => r.timeline.map((t) => fmtHm(t.arrive)).join("/");
assert(routeTimeline(m.routes[0].order, m.plannedDepart).every((t) => !t.miss), "Run C: planned run is on time");
assert(fmt(routeResults[0]) === "08:30/09:45/11:20" && routeResults[0].misses === 3, "Run C: route 1 = 3 misses");
assert(fmt(routeResults[1]) === "08:40/10:15/11:45" && routeResults[1].misses === 1, "Run C: route 2 = 1 miss");
assert(fmt(routeResults[2]) === "08:40/09:55/11:25" && routeResults[2].misses === 2, "Run C: route 3 = 2 misses");
assert(recommendedRoute.id === "r2", "Run C: fewest misses is recommended");
assert(fmtHm(routeResults[0].timeline[0].arrive) === m.fourKitesPeta.T, "Run C: FourKites PETA matches stop 1");
assert(sum(m.stops.map((s) => s.valueUsd)) === 171_400, "Run C: loads 171,400");
assert(
  RISK_ROWS.find((r) => r.caseId === m.caseId)?.valueUsd === sum(m.stops.map((s) => s.valueUsd)),
  "Run C: board value = loads"
);
const reslotArrive = recommendedRoute.timeline.find((t) => t.stop.id === m.reslot.stop)!.arrive;
assert(reslotArrive <= hm(m.reslot.window.split("–")[0]), "Run C: re-slot opens after the new arrival");

export const milkRunSummary = {
  missesBefore: routeResults[0].misses,
  missesAfter: recommendedRoute.misses,
  departLateMin: hm(m.actualDepart) - hm(m.plannedDepart),
  newArrival: fmtHm(reslotArrive),
};

/* ---------------- Predictive ETA ---------------- */

/** Abramowitz–Stegun 7.1.26: max error 1.5e-7, deterministic across runtimes. */
function erf(x: number) {
  const s = Math.sign(x);
  const t = 1 / (1 + 0.3275911 * Math.abs(x));
  const y = 1 - ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-x * x);
  return s * y;
}
const normalCdf = (z: number) => 0.5 * (1 + erf(z / Math.SQRT2));
/** p10 → p90 spans 2 × 1.2816 standard deviations. */
const P10_P90_Z = 2.563;

export interface LegPrediction {
  leg: EtaLeg;
  p50: number;
  p10: number;
  p90: number;
  riskPct: number;
  level: RiskLevel;
  /** Arrives before the window opens and waits at the gate. */
  early: boolean;
}

/** p50 = last ping + drive at lane p50 + live traffic + dwell ahead; risk = P(arrival after the window closes). */
export function predictLeg(p: EtaPrediction, leg: EtaLeg): LegPrediction {
  const p50 = hm(p.pingAt) + leg.driveMin + leg.trafficMin + leg.dwellMin;
  const sigma = (leg.earlyMin + leg.lateMin) / P10_P90_Z;
  const riskPct = Math.min(99, Math.max(1, Math.round(normalCdf((p50 - hm(leg.windowTo)) / sigma) * 100)));
  return {
    leg,
    p50,
    p10: p50 - leg.earlyMin,
    p90: p50 + leg.lateMin,
    riskPct,
    level: riskPct >= 50 ? "high" : riskPct >= 10 ? "medium" : "low",
    early: p50 < hm(leg.windowFrom),
  };
}

export const predictLoad = (l: NetworkLoad) => (l.predict ? l.predict.legs.map((leg) => predictLeg(l.predict!, leg)) : []);

const loadById = (id: string) => NETWORK_LOADS.find((l) => l.loadId === id)!;
const milkLoad = loadById(m.loadId);
const milkPred = predictLoad(milkLoad);
assert(
  milkPred.map((p) => fmtHm(p.p50)).join("/") === fmt(routeResults[0]),
  "Run C: predicted stop ETAs = current-order timeline"
);
assert(milkPred.map((p) => p.riskPct).join("/") === "99/97/96", "Run C: stop OTIF risk 99 / 97 / 96");
assert(milkPred[0].leg.fourKitesPeta === m.fourKitesPeta.T, "Run C: FourKites PETA on stop 1 only");
assert(milkLoad.predict!.pingAt === m.feed[m.feed.length - 1].at, "Run C: last ping = last FourKites event");
export const milkRunPrediction = milkPred;

for (const l of NETWORK_LOADS) {
  if (!l.predict) continue;
  const first = predictLoad(l)[0];
  assert(fmtHm(first.p50) === l.eta.slice(11), `${l.loadId}: predicted p50 = ETA`);
  if (l.etaSource === "FourKites PETA") assert(first.leg.fourKitesPeta === fmtHm(first.p50), `${l.loadId}: PETA = p50`);
  const row = RISK_ROWS.find((r) => r.caseId === l.caseId);
  if (row && row.lane === "post" && l.predict.legs.length === 1) {
    assert(first.level === row.level, `${l.loadId}: predicted risk level = board level`);
  }
}
assert(predictLoad(loadById("LD-PHX-260820-0077"))[0].riskPct === 14, "SHP-58196: OTIF risk 14%");
assert(predictLoad(loadById("LD-RNO-260820-0040"))[0].riskPct === 1, "SHP-58203: OTIF risk 1%");

/* ---------------- Track & Trace ---------------- */

export type LoadStatus = "On track" | "Watch" | "At risk" | "Delivered" | "Delivered late";

export function loadStatus(l: NetworkLoad): LoadStatus {
  if (l.stage === LOAD_MILESTONES.length - 1) {
    const at = toMin(l.eta);
    return at >= toMin(l.window.from) && at < toMin(l.window.to) ? "Delivered" : "Delivered late";
  }
  const row = RISK_ROWS.find((r) => r.caseId === l.caseId);
  if (!row) return "On track";
  return row.level === "high" ? "At risk" : "Watch";
}

export const loadSummary = {
  total: NETWORK_LOADS.length,
  pre: NETWORK_LOADS.filter((l) => l.stage <= 2).length,
  transit: NETWORK_LOADS.filter((l) => l.stage === 3 || l.stage === 4).length,
  delivered: NETWORK_LOADS.filter((l) => l.stage === 5).length,
  deliveredOnTime: NETWORK_LOADS.filter((l) => loadStatus(l) === "Delivered").length,
  atRisk: NETWORK_LOADS.filter((l) => !!l.caseId).length,
};
assert(loadSummary.total === 24 && loadSummary.pre === 9 && loadSummary.transit === 8 && loadSummary.delivered === 7, "24 loads = 9 + 8 + 7");
assert(loadSummary.deliveredOnTime === 6, "6 of 7 delivered on time today");
for (const r of RISK_ROWS) {
  const ls = NETWORK_LOADS.filter((l) => l.caseId === r.caseId);
  assert(ls.length === 1, `${r.caseId} has one load`);
  assert(ls[0].eta === r.track.eta && ls[0].window.from === r.track.windowFrom && ls[0].window.to === r.track.windowTo, `${r.caseId} load ties to board`);
  assert(ls[0].orderRef === r.orderRef && ls[0].customer === r.customer, `${r.caseId} load customer and order`);
}
for (const id of Object.keys(ORDER_LOGISTICS)) {
  const l = NETWORK_LOADS.find((x) => x.loadId === ORDER_LOGISTICS[id].tmsPlan.loadId);
  assert(!!l && l.orderRef === id, `${id}: TMS load on Track & Trace`);
}

/* ---------------- OTIF D forecast, next 7 days ---------------- */

/** Misses left on each high-risk case once its run resolves it. */
const RESIDUAL_MISSES: Record<string, number> = {
  [APPOINTMENT_CASE.caseId]: 0,
  [PREMIUM_CASE.caseId]: 0,
  [MILK_RUN_CASE.caseId]: milkRunSummary.missesAfter,
};
const highRisk = RISK_ROWS.filter((r) => r.level === "high");
assert(highRisk.every((r) => r.run && r.caseId in RESIDUAL_MISSES), "every high-risk case has a run");

export function otifForecast(resolved: Record<string, unknown>) {
  const f = OTIF_FORECAST;
  const atRiskOrders = sum(highRisk.map((r) => r.orders));
  const misses = f.baselineMisses + sum(highRisk.map((r) => (resolved[r.caseId] ? RESIDUAL_MISSES[r.caseId] : r.orders)));
  return {
    scheduled: f.scheduledOrders,
    atRiskOrders,
    watchOrders: sum(RISK_ROWS.filter((r) => r.level !== "high").map((r) => r.orders)),
    misses,
    recovered: f.baselineMisses + atRiskOrders - misses,
    pct: pct(f.scheduledOrders - misses, f.scheduledOrders),
    untreatedPct: pct(f.scheduledOrders - f.baselineMisses - atRiskOrders, f.scheduledOrders),
    bestPct: pct(f.scheduledOrders - f.baselineMisses - sum(highRisk.map((r) => RESIDUAL_MISSES[r.caseId])), f.scheduledOrders),
    targetPct: f.targetPct,
  };
}
const untreated = otifForecast({});
const allResolved = otifForecast(Object.fromEntries(highRisk.map((r) => [r.caseId, true])));
assert(sum(RISK_ROWS.map((r) => r.orders)) === 9 && untreated.atRiskOrders === 5, "7 shipments = 9 orders, 5 high risk");
assert(untreated.pct === 88.0 && untreated.untreatedPct === 88.0, "forecast untreated 88.0%");
assert(allResolved.pct === 88.4 && allResolved.recovered === 4 && allResolved.bestPct === 88.4, "forecast after the 3 runs 88.4%, 4 orders recovered");

/* ---------------- KPI deltas and detail ---------------- */

const lastDelta = (t: number[]) => Math.round((t[t.length - 1] - t[t.length - 2]) * 10) / 10;
assert(OTIF.trendA.at(-1) === otifPct.A && OTIF.trendS.at(-1) === otifPct.S && OTIF.trendD.at(-1) === otifPct.D, "OTIF trends end at the current A / S / D");
assert(OTIF.trendA.every((a, i) => a > OTIF.trendS[i] && OTIF.trendS[i] > OTIF.trendD[i]), "every month A > S > D");
assert(PERFECT_ORDER.trend.at(-1) === perfectOrder.pct, "perfect order trend ends at current");
assert(VALIDATION_ACCURACY.trend.at(-1) === validationAccuracy.pct, "validation trend ends at current");
assert(ORDER_TO_INVOICE.trend.at(-1) === orderToInvoiceDays, "cycle trend ends at current");

/** Change vs the previous 30-day period, in points (days for the cycle). */
export const kpiDeltas = {
  otif: lastDelta(OTIF.trendD),
  perfectOrder: lastDelta(PERFECT_ORDER.trend),
  validation: lastDelta(VALIDATION_ACCURACY.trend),
  cycleDays: lastDelta(ORDER_TO_INVOICE.trend),
};
assert(kpiDeltas.otif === 0.7 && kpiDeltas.perfectOrder === 0.6 && kpiDeltas.validation === 0.1 && kpiDeltas.cycleDays === -0.2, "KPI deltas vs Jul");

for (const k of ["orders", "A", "S", "D"] as const) {
  const total = sum(OTIF_BY_CUSTOMER.map((c) => c[k]));
  const want = k === "orders" ? OM_BASE_ORDERS : OTIF.stages.find((s) => s.key === k)!.orders;
  assert(total === want, `OTIF by customer: ${k} sums to ${want}`);
}
assert(OTIF_BY_CUSTOMER.every((c) => c.A >= c.S && c.S >= c.D), "each customer A >= S >= D");
export const otifByCustomer = OTIF_BY_CUSTOMER.map((c) => ({
  ...c,
  pctA: pct(c.A, c.orders),
  pctS: pct(c.S, c.orders),
  pctD: pct(c.D, c.orders),
}));
