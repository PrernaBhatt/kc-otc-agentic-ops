/**
 * Source documents for Scenario 1 — incomplete proof of promotion.
 *
 * Same rule as the other doc builders: every field is read from the same
 * record the screen reads, so a document can never disagree with the split
 * that opened it.
 */

import { SourceDocTrigger, type SourceDoc } from "@/components/modals/source-doc-preview";
import { findPromoClaimCase } from "./data/promo-claims";
import type { PromoLineCategory } from "./data/promo-claims";
import {
  findPromoClaimStoreRows,
  promoClaimSkuBreakdown,
  type PromoClaimStoreRow,
} from "./data/promo-claim-stores";
import {
  promoClaimSplit,
  renderPromoClaimLetter,
  PROMO_CATEGORY_LABEL,
} from "./promo-claim-selectors";

const ISSUER = "Order to Cash Workspace";
const usd = (n: number) => `$${n.toLocaleString("en-US")}`;

/* ------------------------------------------------------------------ *
 * The deduction, as the retailer sent it
 * ------------------------------------------------------------------ */

export function buildPromoDeductionDoc(caseId: string): SourceDoc {
  const c = findPromoClaimCase(caseId)!;
  const claimed = c.invoiceAmount - c.amountPaid;

  return {
    docId: `promo-deduction-${caseId}`,
    title: `Retailer deduction ${caseId}`,
    docLabel: "Deduction backup",
    reference: c.remittanceId,
    issuer: c.customerName,
    meta: [
      { label: "Invoice", value: c.invoiceId },
      { label: "Received", value: c.receivedDate },
      { label: "Retailer event", value: c.retailerEventRef },
      { label: "Routed to", value: c.routedTo },
    ],
    columns: [
      { key: "item", label: "As deducted" },
      { key: "value", label: "Value", align: "right" },
    ],
    rows: [
      { id: "invoice", cells: { item: "Invoice amount", value: usd(c.invoiceAmount) } },
      { id: "paid", cells: { item: "Amount paid", value: usd(c.amountPaid) } },
      {
        id: "event",
        cells: { item: "Retailer event reference", value: c.retailerEventRef },
      },
      {
        id: "tactic",
        cells: { item: "Stated tactic", value: "Feature & display allowance" },
      },
      {
        id: "stores",
        cells: {
          item: "Stores billed",
          value: (
            <SourceDocTrigger
              doc={buildStoreListDoc(caseId)}
              label={String(c.claimedStores)}
              variant="ghost"
              className="h-auto px-2 py-1 font-semibold underline"
            />
          ),
        },
      },
    ],
    totals: [{ label: "Deduction taken", value: usd(claimed), emphasis: true }],
    footnote: `Remittance note: "${c.customerNote}"`,
    highlightRowIds: ["event", "stores"],
    highlightNote:
      "The deduction carries the retailer's internal event number, not our promotion ID, and bills more stores than the approved event covered.",
    aiSummary: `${c.customerName} withheld ${usd(claimed)} on ${c.invoiceId} as a feature-and-display allowance under event ${c.retailerEventRef}. There is no promotion ID and the store count exceeds the approved event, so the claim must be matched and its proof of performance reconciled before any of it is approved.`,
  };
}

/* ------------------------------------------------------------------ *
 * The promotion agreement it belongs to, once matched
 * ------------------------------------------------------------------ */

export function buildPromotionAgreementDoc(caseId: string): SourceDoc {
  const c = findPromoClaimCase(caseId)!;
  const p = c.promotion;

  return {
    docId: `promo-agreement-${caseId}`,
    title: `Promotion agreement ${p.promotionId}`,
    docLabel: "Trade promotion agreement",
    reference: p.promotionId,
    issuer: ISSUER,
    meta: [
      { label: "Promotion", value: p.name },
      { label: "Window", value: `${p.windowStart} to ${p.windowEnd}` },
      { label: "System", value: p.tpmSystem },
      { label: "Accrual", value: p.accrualId },
    ],
    columns: [
      { key: "item", label: "Term" },
      { key: "value", label: "Agreed", align: "right" },
    ],
    rows: [
      { id: "tactic", cells: { item: "Tactic", value: p.tactic } },
      { id: "weeks", cells: { item: "Duration", value: `${p.weeks} weeks` } },
      {
        id: "stores",
        cells: { item: "Approved stores", value: String(p.approvedStores) },
      },
      { id: "rate", cells: { item: "Allowance basis", value: p.rateBasis } },
      ...p.eligibleSkus.map((s, i) => ({
        id: `sku-${i}`,
        cells: { item: `Eligible SKU ${s.sku}`, value: s.productName },
      })),
    ],
    totals: [{ label: "Accrued for the event", value: usd(p.accruedAmount), emphasis: true }],
    footnote: `Only the ${p.eligibleSkus.length} listed SKUs, ${p.approvedStores} approved stores and the ${p.windowStart}–${p.windowEnd} window may draw this allowance.`,
    highlightRowIds: ["stores", "rate", "sku-0"],
    highlightNote:
      "Approved stores, the allowance basis and the eligible SKU list are the three tests the deduction has to pass.",
    aiSummary: `Promotion ${p.promotionId} was agreed for ${p.weeks} weeks across ${p.approvedStores} approved stores at ${p.rateBasis}, on ${p.eligibleSkus.length} eligible SKUs. The retailer's deduction is tested against these terms store by store.`,
  };
}

/* ------------------------------------------------------------------ *
 * The proof-of-performance pack, gathered from several systems
 * ------------------------------------------------------------------ */

export function buildProofOfPerformanceDoc(caseId: string): SourceDoc {
  const c = findPromoClaimCase(caseId)!;

  return {
    docId: `promo-proof-${caseId}`,
    title: `Proof of performance — ${c.promotion.promotionId}`,
    docLabel: "Evidence pack",
    reference: c.retailerEventRef,
    issuer: ISSUER,
    meta: [
      { label: "Sources", value: String(c.proofSources.length) },
      { label: "Stores billed", value: String(c.claimedStores) },
      { label: "Stores evidenced", value: String(c.supportedStores) },
      { label: "Window", value: `${c.promotion.windowStart} to ${c.promotion.windowEnd}` },
    ],
    columns: [
      { key: "source", label: "Source" },
      { key: "system", label: "System" },
      { key: "status", label: "Against claim", align: "right" },
    ],
    rows: c.proofSources.map((s) => ({
      id: s.sourceId,
      cells: {
        source: s.name,
        system: s.system,
        status:
          s.status === "supports"
            ? "Supports"
            : s.status === "partial"
              ? "Partial"
              : "Gap",
      },
    })),
    highlightRowIds: c.proofSources
      .filter((s) => s.status !== "supports")
      .map((s) => s.sourceId),
    highlightNote:
      "The highlighted sources are where the evidence falls short of what was billed — the basis for the exception list.",
    aiSummary: `Proof of performance was gathered from ${c.proofSources.length} sources. Shipment history supports the event, but the approved store list, display photos, flyer dates and the agreement reveal gaps: only ${c.supportedStores} of ${c.claimedStores} billed stores are fully evidenced.`,
  };
}

/* ------------------------------------------------------------------ *
 * The store-level exception list
 * ------------------------------------------------------------------ */

export function buildStoreExceptionDoc(caseId: string): SourceDoc {
  const split = promoClaimSplit(caseId)!;
  const c = split.case;
  const exceptions = c.lines.filter((l) => l.category !== "supported");

  return {
    docId: `promo-exceptions-${caseId}`,
    title: `Store-level exception list — ${caseId}`,
    docLabel: "Exception list",
    reference: c.promotion.promotionId,
    issuer: ISSUER,
    meta: [
      { label: "Stores billed", value: String(split.claimedStores) },
      { label: "Stores supported", value: String(split.supportedStores) },
      { label: "Stores in exception", value: String(split.exceptionStores) },
      { label: "Unsupported", value: usd(split.unsupported) },
    ],
    columns: [
      { key: "reason", label: "Exception reason" },
      { key: "stores", label: "Stores", align: "right" },
      { key: "amount", label: "Amount", align: "right" },
    ],
    rows: [
      {
        id: "supported",
        cells: {
          reason: PROMO_CATEGORY_LABEL.supported,
          stores: String(split.supportedStores),
          amount: usd(split.supported),
        },
      },
      ...exceptions.map((l) => ({
        id: l.lineId,
        cells: {
          reason: PROMO_CATEGORY_LABEL[l.category],
          stores: String(l.stores),
          amount: usd(l.amount),
        },
      })),
    ],
    totals: [
      { label: "Claimed", value: usd(split.claimed) },
      { label: "Supported", value: usd(split.supported) },
      { label: "Billed back", value: usd(split.billBack), emphasis: true },
    ],
    noteList: exceptions.map((l) => ({ label: PROMO_CATEGORY_LABEL[l.category], detail: l.finding })),
    highlightRowIds: exceptions.map((l) => l.lineId),
    highlightNote:
      "Each exception line is a group of stores that failed a store, date or SKU test, with the dollars that ride on it.",
    aiSummary: `${split.supportedStores} of ${split.claimedStores} stores are supported for ${usd(split.supported)}. ${split.exceptionStores} stores fail a test — not on the approved event, dated outside the window, or an ineligible SKU — for ${usd(split.billBack)} billed back.`,
  };
}

/* ------------------------------------------------------------------ *
 * The retailer response letter, as a document
 * ------------------------------------------------------------------ */

export function buildPromoLetterDoc(caseId: string, sent: boolean): SourceDoc {
  const split = promoClaimSplit(caseId)!;
  const c = split.case;
  const letter = renderPromoClaimLetter(caseId)!;

  return {
    docId: `promo-letter-${caseId}`,
    title: `Retailer response ${c.responseLetter.letterRef}`,
    docLabel: "Deduction response letter",
    reference: c.responseLetter.letterRef,
    issuer: ISSUER,
    meta: [
      { label: "To", value: c.responseLetter.to },
      { label: "From", value: c.responseLetter.from },
      { label: "Status", value: sent ? "Issued" : "Draft — not yet sent" },
      { label: "Bill back", value: usd(split.billBack) },
    ],
    columns: [
      { key: "item", label: "Correspondence" },
      { key: "value", label: "", align: "left" },
    ],
    rows: [
      { id: "subject", cells: { item: "Subject", value: letter.subject } },
      { id: "body", cells: { item: "Body", value: letter.body } },
    ],
    highlightRowIds: ["body"],
    highlightNote: sent
      ? "Issued to the retailer with the store-level exception list attached."
      : "Drafted from the split. A person approves it before it is sent.",
    aiSummary: `The response sets out the ${usd(split.supported)} approved and the ${usd(split.billBack)} billed back, itemised by exception reason, with the store-level exception list attached.`,
  };
}

/* ------------------------------------------------------------------ *
 * The full store list — every store the retailer billed, or only the
 * ones that were approved. Same rows, same file, two filters.
 * ------------------------------------------------------------------ */

/**
 * Reorders the 500 billed stores so the first handful a reviewer sees is a
 * real mix — some approved, some in each exception reason — instead of 8
 * identical "supported" rows just because that group was generated first.
 * The remainder follows in original order behind "Show all 500 stores".
 */
function previewMixedStoreRows(
  rows: PromoClaimStoreRow[]
): PromoClaimStoreRow[] {
  const supported = rows.filter((r) => r.category === "supported").slice(0, 4);
  const exceptionCategories: PromoLineCategory[] = [
    "not-on-event",
    "not-on-event",
    "out-of-window",
    "ineligible-sku",
  ];
  const preview: PromoClaimStoreRow[] = [...supported];
  for (const cat of exceptionCategories) {
    const next = rows.find(
      (r) => r.category === cat && !preview.includes(r)
    );
    if (next) preview.push(next);
  }
  const remainder = rows.filter((r) => !preview.includes(r));
  return [...preview, ...remainder];
}

export function buildStoreListDoc(
  caseId: string,
  options?: { approvedOnly?: boolean }
): SourceDoc {
  const split = promoClaimSplit(caseId)!;
  const c = split.case;
  const approvedOnly = options?.approvedOnly ?? false;
  const allRows = findPromoClaimStoreRows(caseId);
  const rows = approvedOnly
    ? allRows.filter((r) => r.category === "supported")
    : previewMixedStoreRows(allRows);

  return {
    docId: `promo-store-list-${caseId}-${approvedOnly ? "approved" : "billed"}`,
    title: approvedOnly
      ? `Approved stores — ${caseId}`
      : `Stores billed by the retailer — ${caseId}`,
    docLabel: approvedOnly ? "Approved store list" : "Retailer-claimed store list",
    reference: c.promotion.promotionId,
    issuer: ISSUER,
    meta: approvedOnly
      ? [
          { label: "Approved stores", value: String(split.supportedStores) },
          { label: "Of stores billed", value: String(split.claimedStores) },
          { label: "Promotion", value: c.promotion.promotionId },
          { label: "Amount approved", value: usd(split.supported) },
        ]
      : [
          { label: "Stores billed", value: String(split.claimedStores) },
          { label: "Approved", value: String(split.supportedStores) },
          { label: "In exception", value: String(split.exceptionStores) },
          { label: "Retailer event", value: c.retailerEventRef },
        ],
    columns: [
      { key: "storeId", label: "Store" },
      { key: "location", label: "Location" },
      { key: "sku", label: "SKU" },
      { key: "source", label: "Source" },
      { key: "status", label: "Status", align: "right" },
    ],
    rows: rows.map((r) => ({
      id: r.storeId,
      cells: {
        storeId: r.storeId,
        location: `${r.city}, ${r.state}`,
        sku: r.sku,
        source: r.source,
        status: r.category === "supported" ? "Approved" : PROMO_CATEGORY_LABEL[r.category],
      },
    })),
    totals: approvedOnly
      ? undefined
      : [
          { label: "Billed", value: String(split.claimedStores) },
          { label: "Approved", value: String(split.supportedStores) },
          { label: "In exception", value: String(split.exceptionStores), emphasis: true },
        ],
    footnote: approvedOnly
      ? `Every row above is on the approved event list for ${c.promotion.promotionId}, in-window, on an eligible SKU, with display and scan evidence on file.`
      : `${split.exceptionStores} of ${split.claimedStores} billed stores are highlighted — they fail the approved-event, promotional-window or eligible-SKU test and are excluded from the ${usd(split.supported)} approved amount.`,
    highlightRowIds: approvedOnly
      ? []
      : rows.filter((r) => r.category !== "supported").map((r) => r.storeId),
    highlightNote: approvedOnly
      ? "All 410 stores shown here cleared every test and draw the approved allowance."
      : "Highlighted stores failed a store, date or SKU test and are billed back, not approved.",
    aiSummary: approvedOnly
      ? `${split.supportedStores} stores are approved for ${c.promotion.promotionId}. Each is on the approved event list, within the ${c.promotion.windowStart} to ${c.promotion.windowEnd} window, billed on an eligible SKU, and evidenced by a dated display photo and matching scan lift.`
      : `${c.customerName} billed ${split.claimedStores} stores against event ${c.retailerEventRef}, shown below with a mix of approved and exception stores. Reconciled against the approved store list, the promotional window and eligible SKUs, ${split.supportedStores} of ${split.claimedStores} stores are approved and ${split.exceptionStores} are in exception, split across three failure reasons.`,
    initialVisibleRows: 8,
    rowNoun: "stores",
  };
}

/* ------------------------------------------------------------------ *
 * The SKU-level rollup — every SKU billed, or only the eligible ones
 * that were approved. Same rollup, same file, two filters.
 * ------------------------------------------------------------------ */

export function buildSkuListDoc(
  caseId: string,
  options?: { approvedOnly?: boolean }
): SourceDoc {
  const split = promoClaimSplit(caseId)!;
  const c = split.case;
  const p = c.promotion;
  const approvedOnly = options?.approvedOnly ?? false;
  const skus = promoClaimSkuBreakdown(caseId).filter((s) =>
    approvedOnly ? s.eligible : true
  );
  const totalBilled = skus.reduce((s, r) => s + r.storesBilled, 0);
  const totalApproved = skus.reduce((s, r) => s + r.storesApproved, 0);

  return {
    docId: `promo-sku-list-${caseId}-${approvedOnly ? "approved" : "billed"}`,
    title: approvedOnly
      ? `Approved SKUs — ${caseId}`
      : `SKUs billed by the retailer — ${caseId}`,
    docLabel: approvedOnly ? "Eligible SKU list" : "Retailer-claimed SKU list",
    reference: p.promotionId,
    issuer: ISSUER,
    meta: approvedOnly
      ? [
          { label: "Eligible SKUs", value: String(skus.length) },
          { label: "Approved stores", value: String(totalApproved) },
          { label: "Promotion", value: p.promotionId },
          { label: "Rate basis", value: p.rateBasis },
        ]
      : [
          { label: "SKUs billed", value: String(skus.length) },
          { label: "Eligible on agreement", value: String(p.eligibleSkus.length) },
          { label: "Stores billed", value: String(totalBilled) },
          { label: "Stores approved", value: String(totalApproved) },
        ],
    columns: [
      { key: "sku", label: "SKU" },
      { key: "product", label: "Product" },
      { key: "billed", label: "Stores billed", align: "right" },
      { key: "approved", label: "Stores approved", align: "right" },
      { key: "eligible", label: "Eligible", align: "right" },
    ],
    rows: skus.map((s) => ({
      id: s.sku,
      cells: {
        sku: s.sku,
        product: s.productName,
        billed: String(s.storesBilled),
        approved: String(s.storesApproved),
        eligible: s.eligible ? "Yes" : "No",
      },
    })),
    footnote: approvedOnly
      ? `These ${skus.length} SKUs are the eligible SKUs on the ${p.promotionId} agreement.`
      : `The agreement lists ${p.eligibleSkus.length} eligible SKUs (${p.eligibleSkus.map((s) => s.sku).join(", ")}). SKU E500 was billed to the event but is not on the agreement.`,
    highlightRowIds: approvedOnly ? [] : skus.filter((s) => !s.eligible).map((s) => s.sku),
    highlightNote: approvedOnly
      ? "Every SKU shown is eligible under the promotion agreement."
      : "The highlighted SKU is not on the promotion agreement — stores billed against it cannot draw the display allowance.",
    aiSummary: approvedOnly
      ? `${skus.length} SKUs are eligible under ${p.promotionId}, together approved across ${totalApproved} stores.`
      : `${skus.length} SKUs were billed against event ${c.retailerEventRef}. ${p.eligibleSkus.length} are eligible under ${p.promotionId}; SKU E500 is not on the agreement and its stores are excluded from the approved amount.`,
    initialVisibleRows: 8,
    rowNoun: "SKUs",
  };
}

/* ------------------------------------------------------------------ *
 * The six proof-of-performance sources, each opened as its own file —
 * PS-1 through PS-5 below; PS-6 reuses the promotion agreement doc.
 * ------------------------------------------------------------------ */

/** PS-1 — Retailer POS / scan data. */
export function buildScanDataDoc(caseId: string): SourceDoc {
  const split = promoClaimSplit(caseId)!;
  const c = split.case;
  const allRows = findPromoClaimStoreRows(caseId);
  const recorded = allRows.slice(0, 420);
  const noActivity = allRows.slice(420);
  const rows = [...recorded, ...noActivity];

  return {
    docId: `promo-scan-data-${caseId}`,
    title: `Retailer POS / scan data — ${c.retailerEventRef}`,
    docLabel: "Scan lift feed",
    reference: "Retailer data exchange",
    issuer: c.customerName,
    meta: [
      { label: "Stores billed", value: String(allRows.length) },
      { label: "Scan lift recorded", value: String(recorded.length) },
      { label: "No scan activity", value: String(noActivity.length) },
      { label: "Window", value: `${c.promotion.windowStart} to ${c.promotion.windowEnd}` },
    ],
    columns: [
      { key: "storeId", label: "Store" },
      { key: "location", label: "Location" },
      { key: "sku", label: "SKU" },
      { key: "status", label: "Scan status", align: "right" },
    ],
    rows: rows.map((r, i) => ({
      id: r.storeId,
      cells: {
        storeId: r.storeId,
        location: `${r.city}, ${r.state}`,
        sku: r.sku,
        status: i < recorded.length ? "Scan lift recorded" : "No scan activity",
      },
    })),
    totals: [
      { label: "Scan lift recorded", value: String(recorded.length) },
      { label: "No scan activity", value: String(noActivity.length), emphasis: true },
    ],
    footnote:
      "Scan lift is pulled directly from the retailer's data-exchange feed for the eligible SKUs, store by store, across the six promotional weeks.",
    highlightRowIds: noActivity.map((r) => r.storeId),
    highlightNote:
      "Highlighted stores show no scan lift for the eligible SKUs anywhere in the promotional window.",
    aiSummary: `Scan lift was recorded in ${recorded.length} of ${allRows.length} billed stores across the six promotional weeks. ${noActivity.length} billed stores show no scan activity for the eligible SKUs, which is why they cannot stand alone as proof of execution.`,
    initialVisibleRows: 8,
    rowNoun: "stores",
  };
}

/** PS-2 — Shipment history (SAP). */
export function buildShipmentHistoryDoc(caseId: string): SourceDoc {
  const split = promoClaimSplit(caseId)!;
  const c = split.case;
  const p = c.promotion;
  const unitsPerStore = 24;

  return {
    docId: `promo-shipment-history-${caseId}`,
    title: `Shipment history — ${p.promotionId}`,
    docLabel: "Shipment history",
    reference: "SAP",
    issuer: ISSUER,
    meta: [
      { label: "Approved stores", value: String(p.approvedStores) },
      { label: "Eligible SKUs", value: String(p.eligibleSkus.length) },
      { label: "Window", value: `${p.windowStart} to ${p.windowEnd}` },
      { label: "Ship-ahead cutoff", value: p.windowStart },
    ],
    columns: [
      { key: "sku", label: "SKU" },
      { key: "product", label: "Product" },
      { key: "units", label: "Units shipped", align: "right" },
      { key: "shipDate", label: "Ship date", align: "right" },
    ],
    rows: p.eligibleSkus.map((s, i) => ({
      id: s.sku,
      cells: {
        sku: s.sku,
        product: s.productName,
        units: (p.approvedStores * unitsPerStore * (i + 1)).toLocaleString("en-US"),
        shipDate: "2026-02-23",
      },
    })),
    footnote: `All three eligible SKUs shipped to the ${p.approvedStores}-store approved footprint ahead of the ${p.windowStart} window open. Shipment history supports that the event could run — it does not, on its own, prove the display and feature ran in every billed store.`,
    highlightRowIds: [],
    highlightNote: "Shipment history is not highlighted — it fully supports the event and raises no exceptions.",
    aiSummary: `Eligible SKUs shipped to the approved ${p.approvedStores}-store footprint ahead of the promotional window. Shipment history supports the event ran, but it is store-blind — it cannot substitute for display or scan proof at the 500 billed stores.`,
  };
}

/** PS-3 — Approved store list (Trade Promotion Management). */
export function buildApprovedStoreListDoc(caseId: string): SourceDoc {
  const split = promoClaimSplit(caseId)!;
  const c = split.case;
  const p = c.promotion;
  const notOnEvent = findPromoClaimStoreRows(caseId).filter(
    (r) => r.category === "not-on-event"
  );

  return {
    docId: `promo-tpm-store-list-${caseId}`,
    title: `Approved event store list — ${p.promotionId}`,
    docLabel: "TPM approved store list",
    reference: p.promotionId,
    issuer: p.tpmSystem,
    meta: [
      { label: "Approved on TPM", value: String(p.approvedStores) },
      { label: "Stores billed", value: String(split.claimedStores) },
      { label: "Not on approved list", value: String(notOnEvent.length) },
      { label: "System", value: p.tpmSystem },
    ],
    columns: [
      { key: "storeId", label: "Store" },
      { key: "location", label: "Location" },
      { key: "sku", label: "SKU" },
      { key: "status", label: "TPM status", align: "right" },
    ],
    rows: notOnEvent.map((r) => ({
      id: r.storeId,
      cells: {
        storeId: r.storeId,
        location: `${r.city}, ${r.state}`,
        sku: r.sku,
        status: "Not on approved list",
      },
    })),
    footnote: `${p.tpmSystem} shows ${p.approvedStores} stores approved for ${p.promotionId}. The ${notOnEvent.length} stores below were billed by the retailer but never added to the approved event.`,
    highlightRowIds: notOnEvent.map((r) => r.storeId),
    highlightNote: "Every row here is a billed store the TPM system never approved for this event.",
    aiSummary: `${p.tpmSystem} approved ${p.approvedStores} stores for ${p.promotionId}. ${notOnEvent.length} of the ${split.claimedStores} billed stores are absent from that list, so no allowance was ever agreed for them.`,
    initialVisibleRows: 8,
    rowNoun: "stores",
  };
}

/** PS-4 — Display photographs (retailer backup pack). */
export function buildDisplayPhotoDoc(caseId: string): SourceDoc {
  const split = promoClaimSplit(caseId)!;
  const c = split.case;
  const allRows = findPromoClaimStoreRows(caseId);
  const withPhoto = allRows.filter((r) => r.category === "supported");
  const noPhoto = allRows.filter((r) => r.category !== "supported");
  const preview = [
    ...withPhoto.slice(0, 4),
    ...noPhoto.slice(0, 4),
  ];
  const remainder = allRows.filter((r) => !preview.includes(r));
  const rows = [...preview, ...remainder];

  return {
    docId: `promo-display-photos-${caseId}`,
    title: `Display photograph backup pack — ${c.retailerEventRef}`,
    docLabel: "Display photograph backup pack",
    reference: c.retailerEventRef,
    issuer: c.customerName,
    meta: [
      { label: "Stores billed", value: String(allRows.length) },
      { label: "Photos on file", value: String(withPhoto.length) },
      { label: "No photo evidence", value: String(noPhoto.length) },
      { label: "Window", value: `${c.promotion.windowStart} to ${c.promotion.windowEnd}` },
    ],
    columns: [
      { key: "storeId", label: "Store" },
      { key: "location", label: "Location" },
      { key: "sku", label: "SKU" },
      { key: "status", label: "Photo status", align: "right" },
    ],
    rows: rows.map((r) => ({
      id: r.storeId,
      cells: {
        storeId: r.storeId,
        location: `${r.city}, ${r.state}`,
        sku: r.sku,
        status: r.category === "supported" ? "Photo on file" : "No photo evidence",
      },
    })),
    totals: [
      { label: "Photos on file", value: String(withPhoto.length) },
      { label: "No photo evidence", value: String(noPhoto.length), emphasis: true },
    ],
    footnote: `Dated end-cap and display photographs were returned for ${withPhoto.length} stores. The remaining ${noPhoto.length} billed stores have no photograph in the retailer's backup pack.`,
    highlightRowIds: noPhoto.map((r) => r.storeId),
    highlightNote: "Highlighted stores have no display photograph on file for this event.",
    aiSummary: `Dated display photographs were returned for ${withPhoto.length} of ${allRows.length} billed stores. The other ${noPhoto.length} stores have no photo evidence, which is one of the reasons only ${split.supportedStores} stores are fully supported.`,
    initialVisibleRows: 8,
    rowNoun: "stores",
  };
}

/** PS-5 — Weekly flyer / advertised feature. */
export function buildFlyerDoc(caseId: string): SourceDoc {
  const split = promoClaimSplit(caseId)!;
  const c = split.case;
  const p = c.promotion;
  const allRows = findPromoClaimStoreRows(caseId);
  const onTime = allRows.filter((r) => r.category !== "out-of-window");
  const late = allRows.filter((r) => r.category === "out-of-window");
  const preview = [...onTime.slice(0, 4), ...late.slice(0, 4)];
  const remainder = allRows.filter((r) => !preview.includes(r));
  const rows = [...preview, ...remainder];

  return {
    docId: `promo-flyer-${caseId}`,
    title: `Weekly flyer / advertised feature — ${p.promotionId}`,
    docLabel: "Retailer weekly flyer backup pack",
    reference: p.promotionId,
    issuer: c.customerName,
    meta: [
      { label: "Feature ran", value: `Weeks 1-${p.weeks}` },
      { label: "Window close", value: p.windowEnd },
      { label: "Display set up on time", value: String(onTime.length) },
      { label: "Display set up late", value: String(late.length) },
    ],
    columns: [
      { key: "storeId", label: "Store" },
      { key: "location", label: "Location" },
      { key: "sku", label: "SKU" },
      { key: "status", label: "Display setup", align: "right" },
    ],
    rows: rows.map((r) => ({
      id: r.storeId,
      cells: {
        storeId: r.storeId,
        location: `${r.city}, ${r.state}`,
        sku: r.sku,
        status: r.category === "out-of-window" ? "Late — after window close" : "Within window",
      },
    })),
    footnote: `The advertised feature ran weeks 1 through ${p.weeks}, closing ${p.windowEnd}. ${late.length} stores show a display setup dated after that close.`,
    highlightRowIds: late.map((r) => r.storeId),
    highlightNote: "Highlighted stores set up their display after the promotional window had already closed.",
    aiSummary: `The weekly flyer and advertised feature ran on schedule for ${onTime.length} stores. ${late.length} stores show a display setup date after the ${p.windowEnd} window close, so that activity falls outside the agreed dates.`,
    initialVisibleRows: 8,
    rowNoun: "stores",
  };
}

/** Dispatches a proof source's sourceId to the file it actually opens. */
export function buildProofSourceDoc(caseId: string, sourceId: string): SourceDoc {
  switch (sourceId) {
    case "PS-1":
      return buildScanDataDoc(caseId);
    case "PS-2":
      return buildShipmentHistoryDoc(caseId);
    case "PS-3":
      return buildApprovedStoreListDoc(caseId);
    case "PS-4":
      return buildDisplayPhotoDoc(caseId);
    case "PS-5":
      return buildFlyerDoc(caseId);
    case "PS-6":
    default:
      return buildPromotionAgreementDoc(caseId);
  }
}
