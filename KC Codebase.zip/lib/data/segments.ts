/**
 * The "business unit" axis of the receivables view. Each open invoice rolls up
 * to a selling division; geography comes from the customer's region. Together
 * they let the bad-debt review slice AR by business unit AND geography — the
 * two dimensions the aging table (by age) and aging report (by customer) don't
 * show. Amounts are unchanged; this only labels where each balance belongs.
 */
export const businessUnits = [
  "Personal Care",
  "Family Care",
  "Professional",
] as const;

export type BusinessUnit = (typeof businessUnits)[number];

export const invoiceBusinessUnit: Record<string, BusinessUnit> = {
  "INV-12345": "Professional",
  "INV-12346": "Personal Care",
  "INV-12347": "Family Care",
  "INV-12341": "Family Care",
  "INV-12342": "Personal Care",
  "INV-12343": "Professional",
};

/** Invoices raised during the demo roll up here so the total always reconciles. */
export const defaultBusinessUnit: BusinessUnit = "Family Care";

/** Geography columns, in display order. */
export const arRegions = ["North America", "EMEA", "APAC"] as const;
