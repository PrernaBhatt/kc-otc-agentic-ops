/**
 * Scenario 2 — Duplicate or resubmitted promotion claim.
 *
 * A retailer (via a post-audit recovery firm) re-deducts $95,000 for a
 * promotional event that was already dealt with. The resubmission wears a new
 * claim number, a different reason code, a different invoice reference and a
 * new date, so a plain exact-match control never fires. But the promotion, the
 * window, the SKUs and the store footprint are the same event we already
 * settled in part and rejected in part.
 *
 * The hard part is that duplicates rarely look identical. The AI has to match
 * on similarity rather than references, rebuild the full claim-and-settlement
 * lineage, and show that every dollar of the new claim has already been given
 * commercial value (a credit memo) or already been rejected with a reason.
 *
 * Every figure below is a leaf. The selector sums the leaves, so the split can
 * never disagree with the claim it came from:
 *   previouslySettled + previouslyRejected === claimed
 *
 * The duplicate confidence is NOT stored. It is computed from the weighted
 * match signals, so the number on the screen always equals its evidence:
 *   confidence = Σ(matchScore × weight) / Σ(weight)
 */

export type DupComponentCategory = "previously-settled" | "previously-rejected";

/** One identity dimension the claim is matched on. Drives the confidence. */
export interface DupSignal {
  signalId: string;
  dimension: string;
  original: string;
  resubmitted: string;
  /** 0-1: how closely this dimension matches between the two claims. */
  matchScore: number;
  /** Relative importance of this dimension to identity. */
  weight: number;
  note: string;
}

/** One field the resubmission altered, which is why exact-match fails. */
export interface EvasionSignal {
  field: string;
  original: string;
  resubmitted: string;
  note: string;
}

/** One node in the claim-and-settlement lineage, oldest first. */
export interface LineageNode {
  nodeId: string;
  kind: "promotion" | "claim" | "credit" | "rejection" | "resubmission";
  ref: string;
  date: string;
  amount?: number;
  title: string;
  detail: string;
  system: string;
}

/** One slice of the new claim, tied to the prior event that already covered it. */
export interface DupClaimComponent {
  componentId: string;
  category: DupComponentCategory;
  label: string;
  amount: number;
  priorRef: string;
  priorDate: string;
  finding: string;
}

export interface DupClaimCase {
  caseId: string;
  distributorId: string;
  customerName: string;
  /** The invoice the resubmission was booked against. */
  invoiceId: string;
  invoiceDate: string;
  invoiceAmount: number;
  remittanceId: string;
  receivedDate: string;
  amountPaid: number;

  /** The resubmitted claim, as it arrived. */
  resubmittedClaimRef: string;
  resubmittedReasonCode: string;
  postAuditProvider: string;
  customerNote: string;
  routedTo: string;

  /** The promotion the claim belongs to. */
  promotion: {
    promotionId: string;
    name: string;
    tpmSystem: string;
    windowStart: string;
    windowEnd: string;
    weeks: number;
    stores: number;
    eligibleSkus: { sku: string; productName: string }[];
  };

  /** The original claim this one duplicates. */
  originalClaimRef: string;
  originalClaimDate: string;
  originalClaimAmount: number;

  signals: DupSignal[];
  evasionSignals: EvasionSignal[];
  lineage: LineageNode[];
  components: DupClaimComponent[];

  responseLetter: {
    letterRef: string;
    to: string;
    from: string;
    subjectTemplate: string;
    bodyTemplate: string;
  };
}

export const dupClaimCases: DupClaimCase[] = [
  {
    caseId: "DED-DUP-001",
    distributorId: "DIST-004",
    customerName: "Kroger Co.",
    invoiceId: "INV-BC-6620",
    invoiceDate: "2026-04-30",
    invoiceAmount: 820_000,
    remittanceId: "RMT-9330",
    receivedDate: "2026-08-12",
    amountPaid: 725_000,

    resubmittedClaimRef: "PA-2026-3382",
    resubmittedReasonCode: "Display allowance — unclaimed",
    postAuditProvider: "Retailer post-audit recovery firm",
    customerNote:
      "Post-audit recovery — unclaimed display allowance, autumn baby care event. Ref PA-2026-3382.",
    routedTo: "Trade Finance",

    promotion: {
      promotionId: "TPR-2025-0918",
      name: "Autumn Baby Care Feature & Display",
      tpmSystem: "Trade Promotion Management",
      windowStart: "2025-04-06",
      windowEnd: "2025-05-17",
      weeks: 6,
      stores: 460,
      eligibleSkus: [
        { sku: "D400", productName: "Baby Wipes – Refill" },
        { sku: "E500", productName: "Baby Diapers – Size 3" },
        { sku: "F600", productName: "Training Pants – 4T" },
      ],
    },

    originalClaimRef: "CLM-KR-70120",
    originalClaimDate: "2025-06-15",
    originalClaimAmount: 95_000,

    // Four dimensions match exactly; the invoice set only partly overlaps.
    // Σweight = 100; Σ(score×weight) = 25+25+20+20+6 = 96 → 96%.
    signals: [
      {
        signalId: "SIG-1",
        dimension: "Promotion event",
        original: "TPR-2025-0918",
        resubmitted: "Autumn baby care event (unreferenced)",
        matchScore: 1.0,
        weight: 25,
        note: "The resubmission names the same event in prose without citing the promotion ID.",
      },
      {
        signalId: "SIG-2",
        dimension: "Promotional window",
        original: "2025-04-06 to 2025-05-17",
        resubmitted: "2025-04-06 to 2025-05-17",
        matchScore: 1.0,
        weight: 25,
        note: "Identical six-week window.",
      },
      {
        signalId: "SIG-3",
        dimension: "Eligible SKUs",
        original: "D400, E500, F600",
        resubmitted: "D400, E500, F600",
        matchScore: 1.0,
        weight: 20,
        note: "Same three baby-care SKUs.",
      },
      {
        signalId: "SIG-4",
        dimension: "Store footprint",
        original: "460 stores",
        resubmitted: "460 stores",
        matchScore: 1.0,
        weight: 20,
        note: "Same store list as the original claim.",
      },
      {
        signalId: "SIG-5",
        dimension: "Underlying invoices",
        original: "5 invoices, spring 2025",
        resubmitted: "3 of the same 5 invoices",
        matchScore: 0.6,
        weight: 10,
        note: "Three of the five original invoices reappear; two were swapped for adjacent ones.",
      },
    ],

    evasionSignals: [
      {
        field: "Claim number",
        original: "CLM-KR-70120",
        resubmitted: "PA-2026-3382",
        note: "New post-audit reference — no link to the original claim.",
      },
      {
        field: "Reason code",
        original: "Feature allowance",
        resubmitted: "Display allowance — unclaimed",
        note: "Reason code changed so the claim reads as a different tactic.",
      },
      {
        field: "Invoice reference",
        original: "INV-BC-5501",
        resubmitted: "INV-BC-6620",
        note: "Booked against a later invoice than the original claim.",
      },
      {
        field: "Deduction date",
        original: "2025-06-15",
        resubmitted: "2026-08-12",
        note: "Resubmitted eleven months later, inside the post-audit reachback window.",
      },
      {
        field: "Document format",
        original: "Retailer claim pack",
        resubmitted: "Post-audit provider template",
        note: "Repackaged in the recovery firm's format, so line-for-line matching fails.",
      },
    ],

    lineage: [
      {
        nodeId: "LN-1",
        kind: "promotion",
        ref: "TPR-2025-0918",
        date: "2025-04-06",
        title: "Autumn Baby Care Feature & Display",
        detail: "Six-week feature & display, 460 stores, three SKUs.",
        system: "Trade Promotion Management",
      },
      {
        nodeId: "LN-2",
        kind: "claim",
        ref: "CLM-KR-70120",
        date: "2025-06-15",
        amount: 95_000,
        title: "Original retailer claim",
        detail: "$70,000 feature allowance + $25,000 no display proof.",
        system: "Claims platform — NA",
      },
      {
        nodeId: "LN-3",
        kind: "credit",
        ref: "CM-KR-4471",
        date: "2025-07-20",
        amount: 70_000,
        title: "Credit memo issued",
        detail: "Approved & settled — value already given.",
        system: "SAP",
      },
      {
        nodeId: "LN-4",
        kind: "rejection",
        ref: "CLM-KR-70120 / REJ-2211",
        date: "2025-07-22",
        amount: 25_000,
        title: "Balance rejected",
        detail: "90 stores had no photo, outside the window.",
        system: "Claims platform — NA",
      },
      {
        nodeId: "LN-5",
        kind: "resubmission",
        ref: "PA-2026-3382",
        date: "2026-08-12",
        amount: 95_000,
        title: "Post-audit resubmission",
        detail: "Full amount re-deducted under a new ref and reason.",
        system: "Post-audit provider",
      },
    ],

    components: [
      {
        componentId: "DC-1",
        category: "previously-settled",
        label: "Already settled by credit memo",
        amount: 70_000,
        priorRef: "CM-KR-4471",
        priorDate: "2025-07-20",
        finding:
          "This value was approved and paid by credit memo CM-KR-4471 on 2025-07-20. Paying it again is a double payment for the same allowance.",
      },
      {
        componentId: "DC-2",
        category: "previously-rejected",
        label: "Already rejected with a recorded reason",
        amount: 25_000,
        priorRef: "CLM-KR-70120 / REJ-2211",
        priorDate: "2025-07-22",
        finding:
          "This value was rejected on 2025-07-22 — no display proof for 90 stores, activity outside the window. No new evidence accompanies the resubmission.",
      },
    ],

    responseLetter: {
      letterRef: "RL-6620",
      to: "Kroger Co. — Post-Audit Recovery",
      from: "Trade Finance",
      subjectTemplate:
        "Rejected — duplicate of settled promotion {promotionId} (claim {resubmittedClaimRef})",
      bodyTemplate: `Dear Post-Audit Recovery team,

Remittance {remittanceId}, received {receivedDate}, withheld {claimed} against invoice {invoiceId} under your reference {resubmittedClaimRef} ("{resubmittedReasonCode}").

We matched this deduction to promotion {promotionId} ({promotionName}), the autumn baby-care feature and display event that ran from {windowStart} to {windowEnd}. Although the reference number, reason code, invoice and date differ, the event, window, SKUs and store footprint are identical to claim {originalClaimRef}, which we have already dealt with in full:

 - {settled} was approved and settled by credit memo {settledRef} on {settledDate}. Re-deducting it is a duplicate of value already given.
 - {rejected} was rejected on {rejectedDate} under {rejectedRef} — 90 stores had no display proof and fell outside the promotional window. No new evidence accompanies this resubmission.

The full claim-and-settlement lineage is attached. As the entire {claimed} has already been either settled or rejected, the deduction is declined in full and we request repayment of {claimed} within 30 days. The rejection reason has been recorded against the event to prevent further resubmission.

Yours faithfully,
{from}`,
    },
  },
];

export function findDupClaimCase(caseId: string): DupClaimCase | undefined {
  return dupClaimCases.find((c) => c.caseId === caseId);
}
