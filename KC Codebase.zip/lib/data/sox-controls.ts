/**
 * SOX control register for the billing (1.4) and trade promotion (1.7)
 * families. Every human gate in the workspace carries one or more of these
 * refs, and the audit trail evidences them. Replace the names here once
 * K-C's own register is shared; nothing else hardcodes them.
 */

export type ControlFamily = "1.2 Order fulfilment" | "1.4 Billing" | "1.7 Trade promotion";

export interface SoxControl {
  ref: string;
  family: ControlFamily;
  name: string;
  owner: string;
  evidenceRequired: string[];
  threshold?: string;
}

export const soxControls: SoxControl[] = [
  {
    ref: "1.2.1",
    family: "1.2 Order fulfilment",
    name: "Premium freight approved within delegated limit before tender",
    owner: "Transportation Manager, NA",
    evidenceRequired: ["TMS shipment plan", "Freight options", "Premium freight plan", "Approver signature"],
    threshold: "Transportation Manager limit $2,500 per shipment",
  },
  {
    ref: "1.2.2",
    family: "1.2 Order fulfilment",
    name: "Delivery plan changes approved and the customer notified before arrival",
    owner: "Transportation Manager, NA",
    evidenceRequired: ["Tracking feed", "Route options", "Approver signature", "Customer notice"],
  },
  {
    ref: "1.4.1",
    family: "1.4 Billing",
    name: "Price exceptions approved before the invoice is created",
    owner: "L. Chen · Controller",
    evidenceRequired: ["Contract price record", "Customer PO", "Owner signature"],
    threshold: "Price gap above $250 per order",
  },
  {
    ref: "1.4.2",
    family: "1.4 Billing",
    name: "Customer master changes (price, freight, tax) authorised",
    owner: "L. Chen · Controller",
    evidenceRequired: ["MDG change request", "Source agreement", "Data steward approval"],
  },
  {
    ref: "1.4.3",
    family: "1.4 Billing",
    name: "Credit notes approved within delegated limit",
    owner: "L. Chen · Controller",
    evidenceRequired: ["Credit memo request", "Root-cause evidence", "Owner signature"],
    threshold: "Owner limit $50,000; Controller co-sign above",
  },
  {
    ref: "1.4.4",
    family: "1.4 Billing",
    name: "Invalid deductions charged back with evidence",
    owner: "L. Chen · Controller",
    evidenceRequired: ["Charge-back notice", "Contract or POD evidence", "Owner signature"],
    threshold: "Owner limit $100,000; Controller co-sign above",
  },
  {
    ref: "1.4.5",
    family: "1.4 Billing",
    name: "Non-trade deductions resolved within approved tolerance",
    owner: "L. Chen · Controller",
    evidenceRequired: ["Batch rule set", "Validation matrix", "Deductions lead signature"],
  },
  {
    ref: "1.7.1",
    family: "1.7 Trade promotion",
    name: "Promotion terms and dates authorised in TPM",
    owner: "Trade Finance Director",
    evidenceRequired: ["TPM event record", "Deal sheet"],
  },
  {
    ref: "1.7.2",
    family: "1.7 Trade promotion",
    name: "Fund allocation and accrual reclass approved",
    owner: "Trade Finance Director",
    evidenceRequired: ["Fund balance", "Accrual entry", "Owner signature"],
    threshold: "Reclass above $25,000",
  },
  {
    ref: "1.7.3",
    family: "1.7 Trade promotion",
    name: "Claim settled only with proof of performance",
    owner: "Trade Finance Director",
    evidenceRequired: ["Proof of performance", "Promotion agreement", "Owner signature"],
  },
  {
    ref: "1.7.4",
    family: "1.7 Trade promotion",
    name: "Rebate tier validated against contract",
    owner: "Trade Finance Director",
    evidenceRequired: ["Rebate agreement", "Volume statement", "Owner signature"],
  },
  {
    ref: "1.7.5",
    family: "1.7 Trade promotion",
    name: "Duplicate claim screened before settlement",
    owner: "Trade Finance Director",
    evidenceRequired: ["Duplicate screen result", "Prior settlement", "Owner signature"],
  },
];

export function findControl(ref: string): SoxControl | undefined {
  return soxControls.find((c) => c.ref === ref);
}
