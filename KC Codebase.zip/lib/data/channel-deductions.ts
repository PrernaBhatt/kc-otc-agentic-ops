/**
 * The short payment that follows a rejected chargeback claim.
 *
 * When a wholesaler's claim is rejected, a common response is to take the
 * money anyway - by paying the next invoice short. That is what this file
 * holds: one channel invoice, one remittance that came in light, and the
 * deduction case it opened.
 *
 * SCOPE: these records deliberately do NOT enter allInvoices or bankReceipts
 * in lib/store.tsx. The receivables selectors, the ageing buckets, the bad
 * debt provision, the collections worklist and the period-end close all read
 * those arrays, and a $4.18M channel invoice landing among $28K-$180K named
 * accounts would move every one of them. Channel and named-account are two
 * books - see PROGRAMME_SCOPE in lib/data/gross-to-net.ts.
 */

import type { DeductionCase } from "./deductions";

/** A wholesale channel invoice. Never enters the receivables subledger. */
export interface ChannelInvoice {
  invoiceId: string;
  distributorId: string;
  customerId: string;
  customerName: string;
  invoiceDate: string;
  dueDate: string;
  amount: number;
  periodLabel: string;
}

export const channelInvoices: ChannelInvoice[] = [
  {
    invoiceId: "INV-CH-4402",
    distributorId: "DIST-001",
    customerId: "CUST-001",
    customerName: "Walmart Inc.",
    invoiceDate: "2026-04-30",
    dueDate: "2026-08-30",
    amount: 4_180_000,
    periodLabel: "April 2026 channel billing",
  },
];

export function findChannelInvoice(
  invoiceId: string
): ChannelInvoice | undefined {
  return channelInvoices.find((i) => i.invoiceId === invoiceId);
}

/** A payment that arrived light, and what the payer said about it. */
export interface ChannelRemittance {
  remittanceId: string;
  payerName: string;
  receivedDate: string;
  invoiceId: string;
  amountPaid: number;
  amountWithheld: number;
  /** The customer's own words. Quoted on screen, never paraphrased. */
  customerNote: string;
  deductionId: string;
}

export const channelRemittances: ChannelRemittance[] = [
  {
    remittanceId: "RMT-7710",
    payerName: "NORTHBRIDGE SUPPLY",
    receivedDate: "2026-08-18",
    invoiceId: "INV-CH-4402",
    amountPaid: 3_860_000,
    amountWithheld: 320_000,
    // Deliberately gives nothing away. A wholesaler taking money it is not
    // owed does not label the deduction with the claim it lost - it writes a
    // line like this one. The claim is identified by matching evidence, not by
    // reading the note, which is the point of the classification stage.
    customerNote:
      "Contract pricing adjustment per agreed terms. Balance withheld pending reconciliation.",
    deductionId: "DED-CB-001",
  },
];

export function remittanceFor(
  invoiceId: string
): ChannelRemittance | undefined {
  return channelRemittances.find((r) => r.invoiceId === invoiceId);
}

/**
 * The one deduction case this use case follows end to end.
 *
 * `amount` equals the amount rejected on claim CB-88971. That equality is the
 * whole finding, and it is asserted at runtime in lib/deduction-selectors.ts
 * rather than trusted.
 */
export const channelDeductions: DeductionCase[] = [
  {
    deductionId: "DED-CB-001",
    customerId: "CUST-001",
    customerName: "Walmart Inc.",
    invoiceId: "INV-CH-4402",
    amount: 320_000,
    source: "Short payment",
    sourceReference:
      "Remittance RMT-7710 — paid $3,860,000 against a $4,180,000 invoice",
    reasonCode: "Unauthorised chargeback",
    reasonConfidence: 0.96,
    status: "Open",
    validity: "Invalid",
    routedTo: "Trade Finance",
    linkedClaimId: "CB-88971",
    evidence: [
      {
        id: "EV-1",
        label: "Chargeback claim CB-88971 as submitted",
        available: true,
      },
      {
        id: "EV-2",
        label: "Rejection notice with the reason split",
        available: true,
      },
      {
        id: "EV-3",
        label: "Contract price record used for testing",
        available: true,
      },
      {
        id: "EV-4",
        label: "Remittance RMT-7710 and its accompanying note",
        available: true,
      },
      {
        id: "EV-5",
        label: "An approved credit note authorising this deduction",
        available: false,
      },
    ],
    rejectedReadings: [
      {
        label: "Freight damage",
        why: "No damage claim was filed against any delivery on this invoice. Adult care and feminine care cases ship on their own pallets and every one was signed for without exception noted.",
      },
      {
        label: "Promotion allowance",
        why: "No retail display allowance, co-op advertising claim or scan-back rebate covers this period or this amount.",
      },
      {
        label: "Pricing",
        why: "Invoice prices match the project price records on every line, including the quoted lines.",
      },
      {
        label: "Shortage",
        why: "Every line on the invoice was delivered and signed for.",
      },
    ],
    rootCauseFinding:
      "The remittance advice carries no claim reference. The amount withheld matches no invoice line, no credit note and no promotion agreement, but it equals the amount rejected on claim CB-88971 to the dollar, from the same wholesaler, within days of that rejection being issued. This is the rejected claim recovered by deduction rather than a new dispute.",
    aiRecommendation:
      "Request repayment in full. The claim was tested against the delivery history before being rejected in part, no further evidence has been submitted since, and no credit note authorises the deduction.",
    // Five options, but only two outcomes: recover the money or concede it.
    // Write-off and internal chargeback concede exactly as a credit memo does
    // and differ only in which internal account absorbs it — a distinction the
    // reviewer on this screen is not being asked to make.
    resolutionOptions: [
      "Request repayment",
      "Rebill the customer",
      "Issue credit memo",
    ],
    recommendedOptions: ["Request repayment"],
    disputeStatus: "Draft ready",
    disputeLetter: {
      letterRef: "DL-4471",
      to: "Walmart Inc. — Accounts Payable",
      toEmail: "ap@northbridgesupply.example",
      from: "Trade Finance",
      fromEmail: "trade.finance@internal.example",
      subjectTemplate:
        "Repayment requested — {amount} withheld on invoice {invoiceId}",
      bodyTemplate: `Dear Accounts Payable team,

Remittance {remittanceId}, received {receivedDate}, settled {amountPaid} against invoice {invoiceId} in the amount of {invoiceAmount}. {amount} was withheld.

The remittance advice carries no claim reference. The amount withheld corresponds to chargeback claim {claimId}, which was reviewed and rejected in the amount of {amount} on {rejectionDate}, on one ground:

  • {quantityAmount} relates to units for which no invoice or delivery record exists. {supportedUnits} units were invoiced and delivered to that project within the claim window; the claim covers {claimedUnits} units.

No credit note has been issued authorising the amount withheld, and it therefore remains due. We request repayment of {amount} within 30 days.

Should you hold supporting documentation not previously provided, such as a delivery record or an approved price record at {claimedPrice} covering that project, please forward it and the claim will be reassessed.

Yours faithfully,
{from}`,
      attachments: [
        {
          id: "ATT-1",
          label: "Chargeback claim CB-88971",
          docKey: "claim",
        },
        {
          id: "ATT-2",
          label: "Rejection notice with the reason split",
          docKey: "rejection",
        },
        {
          id: "ATT-3",
          label: "Contract price record PR-4471",
          docKey: "contract",
        },
        {
          id: "ATT-4",
          label: "Remittance RMT-7710",
          docKey: "remittance",
        },
      ],
    },
  },
];

/**
 * Deductions already closed on this channel. They give the overview a history
 * to sit against; only DED-CB-001 is walked end to end.
 */
export const settledChannelDeductions: {
  deductionId: string;
  customerName: string;
  invoiceId: string;
  amount: number;
  reasonCode: string;
  resolution: string;
  recovered: number;
  closedOn: string;
}[] = [
  {
    deductionId: "DED-CB-994",
    customerName: "Walmart Inc.",
    invoiceId: "INV-CH-4310",
    amount: 210_000,
    reasonCode: "Unauthorised chargeback",
    resolution: "Repaid in full",
    recovered: 210_000,
    closedOn: "2026-03-11",
  },
  {
    deductionId: "DED-CB-981",
    customerName: "Kroger Co.",
    invoiceId: "INV-CH-4266",
    amount: 96_000,
    reasonCode: "Shortage",
    resolution: "Credit memo issued",
    recovered: 0,
    closedOn: "2026-02-24",
  },
  {
    deductionId: "DED-CB-963",
    customerName: "Walmart Inc.",
    invoiceId: "INV-CH-4188",
    amount: 145_000,
    reasonCode: "Promotion allowance",
    resolution: "Repaid in full",
    recovered: 145_000,
    closedOn: "2026-01-29",
  },
];

export function findChannelDeduction(
  deductionId: string
): DeductionCase | undefined {
  return channelDeductions.find((d) => d.deductionId === deductionId);
}
