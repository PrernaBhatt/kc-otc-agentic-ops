export interface RevRecObligation {
  id: string;
  contractId: string;
  customerName: string;
  orderId: string;
  description: string;
  allocatedAmount: number;
  trigger: "On delivery" | "Over service period";
  status: "Recognized" | "Deferred";
  recognizedDate?: string;
  evidence: string;
}

export interface RevRecContract {
  contractId: string;
  customerId: string;
  customerName: string;
  paymentTerms: string;
  deliveryTerms: string;
  rebatePercent: number;
  notes: string;
}

export const revRecContracts: RevRecContract[] = [
  {
    contractId: "CTR-HPB-2024",
    customerId: "CUST-002",
    customerName: "Tesco PLC",
    paymentTerms: "Net 30",
    deliveryTerms: "Ownership transfers at delivery",
    rebatePercent: 2,
    notes:
      "Master agreement with a 2% volume rebate accrued on every recognized sale.",
  },
  {
    contractId: "CTR-NBS-2024",
    customerId: "CUST-001",
    customerName: "Walmart Inc.",
    paymentTerms: "Net 30",
    deliveryTerms: "Ownership transfers at delivery",
    rebatePercent: 0,
    notes:
      "Includes a 12-month dispenser service commitment on Professional lines, recognized over the service period.",
  },
];

/**
 * Obligations tie to real orders/shipments: SO-710248 was delivered on
 * May 17 (shipment SHP-001) so its revenue is recognized; SO-710246 has not
 * been delivered (shipment SHP-003 planned) so it stays deferred — the
 * cut-off check on the Dashboard close list watches exactly this.
 */
export const revRecObligations: RevRecObligation[] = [
  {
    id: "OBL-001",
    contractId: "CTR-HPB-2024",
    customerName: "Tesco PLC",
    orderId: "SO-710248",
    description: "Industrial Wipers - Jumbo Roll — product delivery",
    allocatedAmount: 275000,
    trigger: "On delivery",
    status: "Recognized",
    recognizedDate: "2026-08-17",
    evidence: "Delivered May 17 — proof of delivery on shipment SHP-001",
  },
  {
    id: "OBL-002",
    contractId: "CTR-HPB-2024",
    customerName: "Tesco PLC",
    orderId: "SO-710246",
    description: "Training Pants - 4T + Hard Roll Towels - White — product delivery",
    allocatedAmount: 340000,
    trigger: "On delivery",
    status: "Deferred",
    evidence: "Shipment SHP-003 planned, promised May 24 — not yet delivered",
  },
  {
    id: "OBL-003",
    contractId: "CTR-NBS-2024",
    customerName: "Walmart Inc.",
    orderId: "SO-710245",
    description: "12-month dispenser service on Hard Roll Towels - White line",
    allocatedAmount: 2750,
    trigger: "Over service period",
    status: "Deferred",
    evidence:
      "Support portion allocated from the $27,500 towel-dispenser line using its standalone price",
  },
];

/** Rebate accrual = 2% of recognized Tesco PLC revenue — derived in selectors. */
export const REBATE_NOTE =
  "Rebate accrual is 2% of recognized revenue under contract CTR-HPB-2024.";

/**
 * Variable-consideration items that reduce the recognized price to net
 * revenue. Each is a fraction of recognized revenue under the master
 * agreement, broken out instead of lumped into one "contra-revenue" line.
 * The total is capped (constrained) to the amount highly likely not to
 * reverse, per the revenue standard.
 */
export interface ContraRevenueItem {
  key: string;
  label: string;
  rate: number;
  note: string;
}

export const contraRevenueItems: ContraRevenueItem[] = [
  {
    key: "rebate",
    label: "Volume rebate",
    rate: 0.02,
    note: "2% earned as the customer hits agreed volume under the master agreement.",
  },
  {
    key: "promo",
    label: "Promotional allowances",
    rate: 0.01,
    note: "Agreed trade-promotion support expected to be claimed on this volume.",
  },
  {
    key: "loyalty",
    label: "Loyalty & growth incentives",
    rate: 0.005,
    note: "Growth-tier incentive accrued as the account approaches its target.",
  },
  {
    key: "returns",
    label: "Returns reserve",
    rate: 0.015,
    note: "Expected product returns held back from revenue until the window closes.",
  },
];

export const VARIABLE_CONSIDERATION_CONSTRAINT =
  "Variable consideration is constrained to the amount highly likely not to reverse — set-asides stay capped until the actual claims and returns land.";
