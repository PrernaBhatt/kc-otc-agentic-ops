/**
 * Canonical detail behind the Order Management pipeline cards. SO-710262 is
 * the regulated order: its pen-needle line sits on quality-held lot
 * LOT-88412, which is what stops it at the Regulatory Check stage.
 */
export interface InboundPoLine {
  lineId: string;
  sku: string;
  productName: string;
  qty: number;
  unitPrice: number;
  lineValue: number;
  lot?: string;
}

export interface InboundPo {
  poNumber: string;
  orderId: string;
  customerName: string;
  channel:
    | "Customer portal"
    | "Email"
    | "Electronic order feed"
    | "Sales Order Dashboard";
  receivedAt: string;
  paymentTerms: string;
  requestedDelivery: string;
  lines: InboundPoLine[];
  /** AI extraction results shown in the PO Validation panel */
  extraction: {
    field: string;
    value: string;
    check: "Pass" | "Attention";
    note: string;
  }[];
}

export const inboundPos: InboundPo[] = [
  {
    poNumber: "PO-NBS-3321",
    orderId: "SO-710262",
    customerName: "Walmart Inc.",
    channel: "Customer portal",
    receivedAt: "2026-08-20 07:55",
    paymentTerms: "Net 30",
    requestedDelivery: "2026-08-31",
    lines: [
      {
        lineId: "POL-1",
        sku: "SKU-K110",
        productName: "Adult Incontinence Briefs - Heavy",
        qty: 250,
        unitPrice: 150,
        lineValue: 37500,
        lot: "LOT-88412",
      },
      {
        lineId: "POL-2",
        sku: "SKU-K220",
        productName: "Feminine Care Pads - Ultra Thin",
        qty: 500,
        unitPrice: 110,
        lineValue: 55000,
      },
    ],
    extraction: [
      {
        field: "Customer",
        value: "Walmart Inc. (CUST-001)",
        check: "Pass",
        note: "Matched by portal account and bill-to address.",
      },
      {
        field: "Products",
        value: "2 lines, both found in catalog",
        check: "Pass",
        note: "Both items matched to active products at contract prices.",
      },
      {
        field: "Minimum order quantity",
        value: "250 and 500 units",
        check: "Pass",
        note: "Both lines meet the 100-unit minimum for personal care products.",
      },
      {
        field: "Contract",
        value: "Agreement CTR-NBS-2024 current",
        check: "Pass",
        note: "Prices on the purchase order match the agreed price list.",
      },
      {
        field: "Order total",
        value: "$92,500",
        check: "Pass",
        note: "Line totals add up to the purchase order total.",
      },
    ],
  },
  {
    poNumber: "PO-CWC-40218",
    orderId: "SO-710260",
    customerName: "Costco Wholesale Corp.",
    channel: "Sales Order Dashboard",
    receivedAt: "2026-08-20 06:30",
    paymentTerms: "Net 30",
    requestedDelivery: "2026-08-29",
    lines: [
      {
        lineId: "POL-1",
        sku: "SKU-F600",
        productName: "Training Pants - 4T",
        qty: 1200,
        unitPrice: 180,
        lineValue: 216000,
      },
      {
        lineId: "POL-2",
        sku: "SKU-E500",
        productName: "Baby Diapers - Size 3",
        qty: 1240,
        unitPrice: 100,
        lineValue: 124000,
      },
    ],
    extraction: [
      {
        field: "Customer details",
        value: "Costco Wholesale Corp. (CUST-005)",
        check: "Pass",
        note: "Retail Operations PO bulk-uploaded via the Sales Order Dashboard — sold-to and bill-to verified against customer master data.",
      },
      {
        field: "Duplicate sales order",
        value: "None found",
        check: "Pass",
        note: "No existing sales order carries PO-CWC-40218.",
      },
      {
        field: "Minimum order quantity",
        value: "1,200 and 1,240 cases",
        check: "Pass",
        note: "Both lines clear the minimum order quantity.",
      },
      {
        field: "Customer credit",
        value: "$1.16M of $2.0M limit",
        check: "Pass",
        note: "Open exposure plus this order stays inside the approved credit limit.",
      },
      {
        field: "Shipping address & payment terms",
        value: "Ship-to DC confirmed · Net 30",
        check: "Pass",
        note: "Ship-to matches the customer master; payment terms match agreement CTR-CWC-2026.",
      },
      {
        field: "Order total",
        value: "$340,000",
        check: "Pass",
        note: "Line totals add up to the purchase order total.",
      },
    ],
  },
];

/**
 * Scenario 2 — contract pricing mismatch. Four PO lines are priced above
 * contract (total variance $740); the PO Validation Agent places the order on
 * hold and the agent recommends billing at K-C's contract price.
 */
export interface PricingVarianceLine {
  sku: string;
  productName: string;
  qty: number;
  contractPrice: number;
  poPrice: number;
  variance: number;
}

export const PRICING_HOLD_ORDER_ID = "SO-710249";

export function isPricingHoldOrder(orderId: string) {
  return orderId === PRICING_HOLD_ORDER_ID;
}

export const pricingHoldCase = {
  orderId: PRICING_HOLD_ORDER_ID,
  poNumber: "PO-TGG-8843",
  exception: "Multiple PO-to-contract price mismatches",
  contract: "CTR-TGG-2026",
  lines: [
    { sku: "SKU-A100", productName: "Facial Tissue - 3-Ply Cube", qty: 400, contractPrice: 45, poPrice: 45.5, variance: 200 },
    { sku: "SKU-B210", productName: "Bathroom Tissue - Ultra Soft", qty: 300, contractPrice: 140, poPrice: 140.6, variance: 180 },
    { sku: "SKU-B200", productName: "Bathroom Tissue - Standard Roll", qty: 400, contractPrice: 125, poPrice: 125.5, variance: 200 },
    { sku: "SKU-C300", productName: "Paper Towels - Roll", qty: 200, contractPrice: 550, poPrice: 550.8, variance: 160 },
  ] as PricingVarianceLine[],
  totalVariance: 740,
  likelyDriver: "Recently expired pricing discrepancy window",
  driverDetail:
    "The customer's pricing discrepancy window on agreement CTR-TGG-2026 expired on 2026-08-10. The PO was raised on the prior price file, so all four lines carry the pre-update prices.",
  /** Perfect-invoice rule: a price gap above this per order is billed at K-C's price. */
  tolerancePerOrderUsd: 250,
  discrepancyRecordId: "DISC-2049",
  discrepancyReason: "Buyer price file one revision behind",
  recommendation:
    "Bill at contract price CTR-TGG-2026, notify the buyer and record the discrepancy.",
  ifBilledAtPo: "Target would deduct the $740 after the invoice.",
  buyerNote:
    "We will invoice PO-TGG-8843 at your contract prices, $220,000. Please update your price file to revision CTR-TGG-2026.",
  approver: "Jim Novak",
  buyer: { name: "Marcus Lee", role: "Buyer, Target", email: "marcus.lee@target.com" },
  accountId: "CUST-006",
  controlRef: "1.4.1",
  escalationId: "ESC-2625" as const,
  decisionId: "DEC-PRC-2049",
};

/** PO and contract totals for the Target hold (PRD §12.2). */
export const pricingHoldTotals = (() => {
  const poTotal = pricingHoldCase.lines.reduce((s, l) => s + Math.round(l.poPrice * l.qty * 100) / 100, 0);
  const contractTotal = pricingHoldCase.lines.reduce((s, l) => s + l.contractPrice * l.qty, 0);
  const variance = pricingHoldCase.lines.reduce((s, l) => s + l.variance, 0);
  if (
    Math.round(poTotal) !== 220_740 ||
    contractTotal !== 220_000 ||
    variance !== pricingHoldCase.totalVariance ||
    Math.round(poTotal - contractTotal) !== variance ||
    variance <= pricingHoldCase.tolerancePerOrderUsd
  ) {
    throw new Error("[target pricing tie-out] totals do not tie");
  }
  return { poTotal: Math.round(poTotal), contractTotal, variance };
})();

export const anomalyPo: InboundPo = {
  poNumber: "PO-TGG-8843",
  orderId: "SO-710249",
  customerName: "Target Corporation",
  channel: "Email",
  receivedAt: "2026-08-14 10:20",
  paymentTerms: "Net 30",
  requestedDelivery: "2026-08-28",
  lines: pricingHoldCase.lines.map((l, i) => ({
    lineId: `POL-${i + 1}`,
    sku: l.sku,
    productName: l.productName,
    qty: l.qty,
    unitPrice: l.poPrice,
    lineValue: Math.round(l.poPrice * l.qty * 100) / 100,
  })),
  extraction: [
    {
      field: "Customer details",
      value: "Target Corporation (CUST-006)",
      check: "Pass",
      note: "Sold-to and bill-to verified against customer master data.",
    },
    {
      field: "Products",
      value: "4 lines, all found in catalog",
      check: "Pass",
      note: "Facial tissue, two bathroom tissue lines and paper towels matched to active products.",
    },
    {
      field: "Contract price (line level)",
      value: "4 of 4 lines above contract · variance $740",
      check: "Attention",
      note: "Every PO unit price is higher than agreement CTR-TGG-2026 — PO placed on hold automatically.",
    },
    {
      field: "Minimum order quantity",
      value: "200–400 cases per line",
      check: "Pass",
      note: "Every line clears the minimum order quantity.",
    },
    {
      field: "Order total",
      value: "$220,740",
      check: "Pass",
      note: "Line totals add up to the purchase order total.",
    },
  ],
};

/** Clean inbound POs behind the three billing pipeline orders. */
export const billingPos: InboundPo[] = [
  {
    poNumber: "PO-NBS-3298",
    orderId: "SO-710270",
    customerName: "Walmart Inc.",
    channel: "Customer portal",
    receivedAt: "2026-08-12 09:05",
    paymentTerms: "Net 30",
    requestedDelivery: "2026-08-18",
    lines: [
      {
        lineId: "POL-1",
        sku: "SKU-E500",
        productName: "Baby Diapers - Size 3",
        qty: 1250,
        unitPrice: 100,
        lineValue: 125000,
      },
    ],
    extraction: [
      { field: "Customer", value: "Walmart Inc. (CUST-001)", check: "Pass", note: "Matched by portal account." },
      { field: "Products", value: "1 line, found in catalog", check: "Pass", note: "Matched at contract price." },
      { field: "Minimum order quantity", value: "1,250 units", check: "Pass", note: "Clears the minimum quantity." },
      { field: "Contract", value: "Agreement CTR-NBS-2024 current", check: "Pass", note: "Prices match the agreed price list." },
      { field: "Order total", value: "$125,000", check: "Pass", note: "Line totals add up to the purchase order total." },
    ],
  },
  {
    poNumber: "PO-HPB-7791",
    orderId: "SO-710271",
    customerName: "Tesco PLC",
    channel: "Electronic order feed",
    receivedAt: "2026-08-13 06:40",
    paymentTerms: "Net 30",
    requestedDelivery: "2026-08-19",
    lines: [
      {
        lineId: "POL-1",
        sku: "SKU-F600",
        productName: "Training Pants - 4T",
        qty: 1000,
        unitPrice: 180,
        lineValue: 180000,
      },
      {
        lineId: "POL-2",
        sku: "SKU-G700",
        productName: "Hard Roll Towels - White",
        qty: 800,
        unitPrice: 200,
        lineValue: 160000,
      },
    ],
    extraction: [
      { field: "Customer", value: "Tesco PLC (CUST-002)", check: "Pass", note: "Matched by trading partner identity." },
      { field: "Products", value: "2 lines, both found in catalog", check: "Pass", note: "Matched at master agreement prices." },
      { field: "Minimum order quantity", value: "1,000 and 800 units", check: "Pass", note: "Both lines clear the minimum quantity." },
      { field: "Contract", value: "Agreement CTR-HPB-2024 current", check: "Pass", note: "Prices match the master agreement." },
      { field: "Order total", value: "$340,000", check: "Pass", note: "Line totals add up to the purchase order total." },
    ],
  },
  {
    poNumber: "PO-VKB-1174",
    orderId: "SO-710272",
    customerName: "Woolworths Group",
    channel: "Email",
    receivedAt: "2026-08-13 11:15",
    paymentTerms: "Net 30",
    requestedDelivery: "2026-08-19",
    lines: [
      {
        lineId: "POL-1",
        sku: "SKU-I900",
        productName: "Industrial Wipers - Jumbo Roll",
        qty: 500,
        unitPrice: 550,
        lineValue: 275000,
      },
    ],
    extraction: [
      { field: "Customer", value: "Woolworths Group (CUST-003)", check: "Pass", note: "Matched by sender domain and account number." },
      { field: "Products", value: "1 line, found in catalog", check: "Pass", note: "Matched at contract price." },
      { field: "Minimum order quantity", value: "500 units", check: "Pass", note: "Clears the minimum quantity." },
      { field: "Contract", value: "Standard terms current", check: "Pass", note: "Price matches the agreed list." },
      { field: "Order total", value: "$275,000", check: "Pass", note: "Line total adds up to the purchase order total." },
    ],
  },
];

export const allInboundPos: InboundPo[] = [
  ...inboundPos,
  anomalyPo,
  ...billingPos,
];

export function findInboundPo(orderId: string): InboundPo | undefined {
  return allInboundPos.find((po) => po.orderId === orderId);
}

/**
 * Payment terms applied when an order arrives without an inbound purchase
 * order document (entered directly by the sales team). Matches the terms on
 * both inbound purchase orders above.
 */
export const standardPaymentTerms = "Net 30";

/**
 * Standard volume discount rate (pricing rule PRC-200). The same 3% rate the
 * pipeline's Pricing Breakdown card applies to the order total, so the
 * Pricing & Commercial Validation panel always ties out with it.
 */
export const volumeDiscountRate = 0.03;
