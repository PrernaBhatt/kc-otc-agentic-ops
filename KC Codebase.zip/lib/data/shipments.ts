import { TODAY } from "@/lib/data/clock";

export interface CarrierMilestone {
  id: string;
  label: string;
  timestamp: string;
  done: boolean;
}

export interface Shipment {
  shipmentId: string;
  orderId: string;
  customerName: string;
  carrier: string;
  status: "Planning" | "In Transit" | "Delayed" | "Delivered";
  promisedDate: string;
  deliveredDate?: string;
  podSignedBy?: string;
  delayDays?: number;
  delayReason?: string;
  milestones: CarrierMilestone[];
}

export const shipments: Shipment[] = [
  {
    shipmentId: "SHP-001",
    orderId: "SO-710248",
    customerName: "Tesco PLC",
    carrier: "Blue Line Freight",
    status: "Delivered",
    promisedDate: "2026-08-17",
    deliveredDate: "2026-08-17",
    podSignedBy: "R. Alvarez, Receiving Supervisor",
    milestones: [
      { id: "MS-1", label: "Picked up from warehouse", timestamp: "2026-08-15 08:40", done: true },
      { id: "MS-2", label: "Departed origin hub", timestamp: "2026-08-15 14:05", done: true },
      { id: "MS-3", label: "Arrived destination hub", timestamp: "2026-08-16 19:30", done: true },
      { id: "MS-4", label: "Out for delivery", timestamp: "2026-08-17 07:55", done: true },
      { id: "MS-5", label: "Delivered — proof of delivery signed", timestamp: "2026-08-17 11:20", done: true },
    ],
  },
  {
    shipmentId: "SHP-002",
    orderId: "SO-710247",
    customerName: "Woolworths Group",
    carrier: "Pacific Cargo Lines",
    status: "Delayed",
    promisedDate: "2026-08-16",
    delayDays: 5,
    delayReason: "Carrier capacity constraints",
    milestones: [
      { id: "MS-1", label: "Picked up from warehouse", timestamp: "2026-08-14 09:10", done: true },
      { id: "MS-2", label: "Departed origin hub", timestamp: "2026-08-14 16:45", done: true },
      { id: "MS-3", label: "Held at transfer hub — capacity constraint", timestamp: "2026-08-15 22:00", done: true },
      { id: "MS-4", label: "New arrival estimate confirmed", timestamp: "2026-08-21 09:00", done: false },
      { id: "MS-5", label: "Delivery — revised promise", timestamp: "2026-08-21 17:00", done: false },
    ],
  },
  {
    // Planned by the post-approval fulfillment flow for SO-710245
    // (conditional release) — the flow and the Fulfillment Tracking section
    // reference this same record.
    shipmentId: "SHP-004",
    orderId: "SO-710245",
    customerName: "Walmart Inc.",
    carrier: "Blue Line Freight",
    status: "Planning",
    promisedDate: "2026-08-25",
    milestones: [
      { id: "MS-1", label: "Stock allocated from warehouse", timestamp: "2026-08-20 12:50", done: true },
      { id: "MS-2", label: "Shipment planned — carrier booked", timestamp: "2026-08-20 12:53", done: true },
      { id: "MS-3", label: "Pickup scheduled", timestamp: "2026-08-22 08:00", done: false },
      { id: "MS-4", label: "In transit", timestamp: "—", done: false },
      { id: "MS-5", label: "Delivery — promised date", timestamp: "2026-08-25", done: false },
    ],
  },
  {
    shipmentId: "SHP-003",
    orderId: "SO-710246",
    customerName: "Tesco PLC",
    carrier: "Blue Line Freight",
    status: "Planning",
    promisedDate: "2026-08-24",
    milestones: [
      { id: "MS-1", label: "Stock allocated from warehouse", timestamp: "2026-08-19 15:30", done: true },
      { id: "MS-2", label: "Shipment planned — carrier booked", timestamp: "2026-08-20 10:00", done: true },
      { id: "MS-3", label: "Pickup scheduled", timestamp: "2026-08-22 08:00", done: false },
      { id: "MS-4", label: "In transit", timestamp: "—", done: false },
      { id: "MS-5", label: "Delivery — promised date", timestamp: "2026-08-24", done: false },
    ],
  },
];

/** Delivered shipments feeding the billing pipeline (BIL-001..003). */
export const billingShipments: Shipment[] = [
  {
    shipmentId: "SHP-010",
    orderId: "SO-710270",
    customerName: "Walmart Inc.",
    carrier: "Blue Line Freight",
    status: "Delivered",
    promisedDate: "2026-08-18",
    deliveredDate: "2026-08-18",
    podSignedBy: "M. Okafor, Warehouse Lead",
    milestones: [
      { id: "MS-1", label: "Picked up from warehouse", timestamp: "2026-08-16 08:15", done: true },
      { id: "MS-2", label: "Departed origin hub", timestamp: "2026-08-16 13:40", done: true },
      { id: "MS-3", label: "Arrived destination hub", timestamp: "2026-08-17 18:05", done: true },
      { id: "MS-4", label: "Out for delivery", timestamp: "2026-08-18 08:10", done: true },
      { id: "MS-5", label: "Delivered — proof of delivery signed", timestamp: "2026-08-18 10:45", done: true },
    ],
  },
  {
    shipmentId: "SHP-011",
    orderId: "SO-710271",
    customerName: "Tesco PLC",
    carrier: "Blue Line Freight",
    status: "Delivered",
    promisedDate: "2026-08-19",
    deliveredDate: "2026-08-19",
    podSignedBy: "R. Alvarez, Receiving Supervisor",
    milestones: [
      { id: "MS-1", label: "Picked up from warehouse", timestamp: "2026-08-17 09:00", done: true },
      { id: "MS-2", label: "Departed origin hub", timestamp: "2026-08-17 15:20", done: true },
      { id: "MS-3", label: "Arrived destination hub", timestamp: "2026-08-18 20:10", done: true },
      { id: "MS-4", label: "Out for delivery", timestamp: "2026-08-19 07:30", done: true },
      { id: "MS-5", label: "Delivered — proof of delivery signed", timestamp: "2026-08-19 11:05", done: true },
    ],
  },
  {
    shipmentId: "SHP-012",
    orderId: "SO-710272",
    customerName: "Woolworths Group",
    carrier: "Pacific Cargo Lines",
    status: "Delivered",
    promisedDate: "2026-08-19",
    deliveredDate: "2026-08-19",
    podSignedBy: "T. Nguyen, Goods-In Clerk",
    milestones: [
      { id: "MS-1", label: "Picked up from warehouse", timestamp: "2026-08-17 10:30", done: true },
      { id: "MS-2", label: "Departed origin hub", timestamp: "2026-08-17 17:45", done: true },
      { id: "MS-3", label: "Arrived destination hub", timestamp: "2026-08-18 22:00", done: true },
      { id: "MS-4", label: "Out for delivery", timestamp: "2026-08-19 08:20", done: true },
      { id: "MS-5", label: "Delivered — proof of delivery signed", timestamp: "2026-08-19 12:30", done: true },
    ],
  },
];

export const allShipments: Shipment[] = [...shipments, ...billingShipments];

export function findShipmentByOrder(orderId: string): Shipment | undefined {
  return allShipments.find((s) => s.orderId === orderId);
}

/**
 * A just-delivered shipment synthesized for an order with no carrier record
 * yet, so the POD stage panel, the arrival email and the run finale all read
 * from one identical delivery.
 */
export function deliveredShipmentFor(
  orderId: string,
  customerName: string
): Shipment {
  return {
    shipmentId: `SHP-${orderId.replace("SO-", "")}`,
    orderId,
    customerName,
    carrier: "Blue Line Freight",
    status: "Delivered",
    promisedDate: TODAY,
    deliveredDate: TODAY,
    podSignedBy: "Receiving Supervisor",
    milestones: [
      { id: "MS-1", label: "Picked up from warehouse", timestamp: `${TODAY} 08:20`, done: true },
      { id: "MS-2", label: "Departed origin hub", timestamp: `${TODAY} 13:10`, done: true },
      { id: "MS-3", label: "Arrived destination hub", timestamp: `${TODAY} 18:40`, done: true },
      { id: "MS-4", label: "Out for delivery", timestamp: `${TODAY} 08:05`, done: true },
      { id: "MS-5", label: "Delivered — proof of delivery signed", timestamp: `${TODAY} 11:15`, done: true },
    ],
  };
}

/** A real carrier record when one exists, otherwise the synthesized delivery. */
export function podShipmentFor(orderId: string, customerName: string): Shipment {
  return (
    findShipmentByOrder(orderId) ?? deliveredShipmentFor(orderId, customerName)
  );
}
