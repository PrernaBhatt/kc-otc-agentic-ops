/**
 * Gross-to-net programme constants.
 *
 * Gross-to-net is the gap between list price and what we actually keep after
 * every rebate, discount and chargeback the channel claims back. This file is
 * the single source for every programme-level figure on the Chargebacks page
 * and the Financial Impact panel. Nothing here is recomputed in a component.
 *
 * SCOPE, and why the numbers look nothing like the rest of the app: these are
 * channel-level figures across every wholesaler. The Orders, Billing,
 * Transactions and Collections pages show the named-account book, where a
 * single invoice is $28K-$180K. The two never share an invoice, a payment or
 * a receivables calculation - see lib/data/channel-deductions.ts.
 */

export const PROGRAMME_SCOPE =
  "Consumer & Professional wholesale channel — gross-to-net programme, all distributors · ~128,000 deductions a year";
export const OPERATIONAL_SCOPE =
  "Named account book — the orders and invoices on the operations pages, in SAP ECC";

/** Claim intake for the current programme period. */
export const claimsReceived = 14_850;
export const totalClaimValue = 268_400_000;

/** What validation found before any of it was paid. */
export const potentialOverpayment = 11_400_000;
export const duplicatesPrevented = 2_600_000;

/**
 * How claims left the validation engine. Auto-settled claims never reach a
 * person; review and hold both do. Must sum to 100.
 */
export const opsSplit = {
  autoSettledPercent: 85,
  underReviewPercent: 12,
  onHoldPercent: 3,
} as const;

/** Share of validated claims a person never had to touch. */
export const productivityImprovementPercent = 68;

/**
 * The four levers that make up gross-to-net. Chargebacks are the largest and
 * the only one this demo validates end to end; the rest are shown so the
 * chargeback figure is not mistaken for the whole programme.
 */
export interface GrossToNetLever {
  id: string;
  label: string;
  plainDescription: string;
  exposure: number;
  attention: "High" | "Medium" | "Watch";
  aiAction: string;
}

export const grossToNetLevers: GrossToNetLever[] = [
  {
    id: "chargebacks",
    label: "Chargebacks",
    plainDescription:
      "The difference between the invoiced price and the contracted resale price, claimed back by wholesalers",
    exposure: 268_400_000,
    attention: "High",
    aiAction: "Block invalid claims before they settle",
  },
  {
    id: "rebates",
    label: "Rebates",
    plainDescription: "Volume and performance amounts earned back after the sale",
    exposure: 42_800_000,
    attention: "Medium",
    aiAction: "Verify that the customer qualified",
  },
  {
    id: "discounts",
    label: "Discounts and admin fees",
    plainDescription: "Agreed deductions taken at or after invoicing",
    exposure: 18_700_000,
    attention: "Medium",
    aiAction: "Compare against the approved terms",
  },
  {
    id: "returns",
    label: "Returns and credits",
    plainDescription: "Product returned, and the credit notes raised against it",
    exposure: 9_600_000,
    attention: "Watch",
    aiAction: "Check the cut-off date and the matching credit note",
  },
];

/** Share of the period's entries that already have an evidence pack attached. */
export const closeEvidenceReadinessPercent = 98;
export const closeEvidenceBasis =
  "share of this period's gross-to-net entries with a linked evidence pack";

/**
 * Full-year exposure this reserve position takes out of the forecast. Not
 * derived from any single entry - it is a planning figure, and the basis is
 * printed next to it wherever it appears.
 */
export const ebitdaExposureProtected = 11_400_000;
export const ebitdaBasis =
  "full-year gross-to-net exposure this reserve position removes from the forecast";

/** How close last period's reserve landed to what was actually claimed. */
export const reserveAccuracyPercent = 98.4;

/** Share of the period's claim value still carrying an open question. */
export const closeRiskIndexPercent = 7;
