import type { Invoice } from "./types";

export const invoices: Invoice[] = [
  {
    invoiceId: "INV-12345",
    orderId: "SO-710240",
    customerId: "CUST-001",
    customerName: "Walmart Inc.",
    invoiceDate: "2026-08-10",
    dueDate: "2026-06-09",
    amount: 95000,
    status: "Pending",
  },
  {
    invoiceId: "INV-12346",
    orderId: "SO-710241",
    customerId: "CUST-002",
    customerName: "Tesco PLC",
    invoiceDate: "2026-08-08",
    dueDate: "2026-06-07",
    amount: 180000,
    status: "Sent",
  },
  {
    invoiceId: "INV-12347",
    orderId: "SO-710242",
    customerId: "CUST-003",
    customerName: "Woolworths Group",
    invoiceDate: "2026-03-21",
    dueDate: "2026-04-20",
    amount: 42000,
    status: "Overdue",
  },
  {
    invoiceId: "INV-12348",
    orderId: "SO-710243",
    customerId: "CUST-001",
    customerName: "Walmart Inc.",
    invoiceDate: "2026-08-12",
    dueDate: "2026-06-11",
    amount: 67500,
    status: "Paid",
  },
];
