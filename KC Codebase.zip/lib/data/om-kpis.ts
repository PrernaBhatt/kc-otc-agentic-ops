import { I2C_KPIS } from "./invoice-to-cash";

/**
 * OM Command Center metrics, last 30 days. Every rate is a count over the
 * same base: the orders invoiced in the period (one invoice per order), so
 * OTIF, perfect order and right-first-time billing tie to each other.
 */

export const OM_PERIOD = "Last 30 days";
/** The Command Center reads as of this moment; no trend runs past it. */
export const OM_AS_OF = { iso: "2026-08-20", label: "As of Thu 2026-08-20 08:20" };
/** Six 30-day periods, each named by the month it closes in; Aug is the current one. */
export const OM_TREND_MONTHS = ["Mar", "Apr", "May", "Jun", "Jul", "Aug"] as const;
export const OM_PREV_MONTH = OM_TREND_MONTHS[OM_TREND_MONTHS.length - 2];

export const OM_BASE_ORDERS = I2C_KPIS.invoicesIssued;

export interface CountedReason {
  label: string;
  orders: number;
}

export interface OtifStage {
  key: "A" | "S" | "D";
  label: string;
  definition: string;
  orders: number;
  targetPct: number;
}

export const OTIF = {
  stages: [
    {
      key: "A",
      label: "Available",
      definition: "Picked, packed and ready at the DC in the window and in full",
      orders: 4_075,
      targetPct: 98,
    },
    {
      key: "S",
      label: "Shipped",
      definition: "Left the DC in the agreed window and in full",
      orders: 3_932,
      targetPct: 95,
    },
    {
      key: "D",
      label: "Delivered",
      definition: "Arrived inside the customer window and in full",
      orders: 3_772,
      targetPct: 92,
    },
  ] as OtifStage[],
  /** Orders lost before A, between A and S, and between S and D, by cause. */
  losses: {
    beforeA: [
      { label: "Stock short at the DC", orders: 92 },
      { label: "Quality hold", orders: 43 },
    ] as CountedReason[],
    aToS: [
      { label: "Carrier tender rejected", orders: 61 },
      { label: "Load planning slip", orders: 48 },
      { label: "Late pick at the DC", orders: 34 },
    ] as CountedReason[],
    sToD: [
      { label: "Transit delay", orders: 88 },
      { label: "Appointment missed", orders: 47 },
      { label: "Rejected at receiving", orders: 25 },
    ] as CountedReason[],
  },
  trendA: [95.1, 95.6, 95.9, 96.2, 96.5, 96.8],
  trendS: [91.2, 91.9, 92.3, 92.7, 93.0, 93.4],
  trendD: [86.1, 87.0, 87.3, 88.2, 88.9, 89.6],
};

export interface CustomerOtif {
  customer: string;
  orders: number;
  A: number;
  S: number;
  D: number;
  /** The customer's own OTIF D target from its supplier agreement. */
  targetPct: number;
}

/** Same orders as OTIF.stages, split by customer; rows sum to the stage totals. */
export const OTIF_BY_CUSTOMER: CustomerOtif[] = [
  { customer: "Walmart", orders: 1_520, A: 1_478, S: 1_430, D: 1_374, targetPct: 95 },
  { customer: "Target", orders: 980, A: 951, S: 917, D: 879, targetPct: 93 },
  { customer: "Costco", orders: 760, A: 734, S: 708, D: 680, targetPct: 92 },
  { customer: "Kroger", orders: 640, A: 615, S: 592, D: 566, targetPct: 92 },
  { customer: "Other", orders: 310, A: 297, S: 285, D: 273, targetPct: 90 },
];

export interface PerfectOrderComponent {
  key: "in-full" | "on-time" | "dispute-free" | "docs" | "paid";
  label: string;
  definition: string;
  passing: number;
}

export const PERFECT_ORDER = {
  components: [
    { key: "in-full", label: "Order complete", definition: "Delivered in full, every line complete", passing: 4_126 },
    { key: "on-time", label: "Delivered on time", definition: "Delivered inside the customer window", passing: 3_840 },
    {
      key: "dispute-free",
      label: "Dispute free",
      definition: "No non-trade dispute raised against the invoice",
      passing: I2C_KPIS.invoicesIssued - I2C_KPIS.invoicesDisputedNonTrade,
    },
    { key: "docs", label: "Docs correct", definition: "No documentation error recorded: ASN, BOL and invoice match the order", passing: 4_168 },
    { key: "paid", label: "Invoice paid in full", definition: "Invoice paid with no short-pay", passing: 4_042 },
  ] as PerfectOrderComponent[],
  /** Orders that fail on time and in full together. */
  failBothOnTimeAndInFull: 16,
  /** Orders that pass all five components. */
  perfect: 3_602,
  targetPct: 90,
  trend: [82.4, 83.1, 83.9, 84.5, 85.0, 85.6],
};

export const VALIDATION_ACCURACY = {
  validated: 4_380,
  autoReleased: 3_986,
  heldForReview: 394,
  /** Held orders where a person confirmed the agent's finding. */
  heldConfirmed: 367,
  /** Held orders that turned out fine. */
  falseHolds: 27,
  /** Released orders corrected later in billing. */
  missedErrors: 12,
  targetPct: 99,
  trend: [98.2, 98.5, 98.7, 98.8, 99.0, 99.1],
  examples: {
    falseHolds: [
      { orderId: "SO-710231", customer: "Kroger", finding: "Price 2.1% under list on line 3", outcome: "Released unchanged: promo price on the Kroger deal sheet" },
      { orderId: "SO-710238", customer: "Target", finding: "Ship-to DC T-3809 not on master", outcome: "Released: DC added to master data the same day" },
    ],
    missedErrors: [
      { orderId: "SO-710219", customer: "Walmart", finding: "Released", outcome: "Case pack 12 billed as 10, corrected in billing" },
      { orderId: "SO-710226", customer: "Costco", finding: "Released", outcome: "Unit EA billed as CS, corrected in billing" },
    ],
  },
};

export interface CyclePhase {
  key: string;
  label: string;
  days: number;
}

export const ORDER_TO_INVOICE = {
  phases: [
    { key: "entry", label: "Entry & validation", days: 0.2 },
    { key: "allocation", label: "Allocation & confirmation", days: 0.6 },
    { key: "planning", label: "Planning & appointment", days: 2.1 },
    { key: "transit", label: "Transit & POD", days: 3.0 },
    { key: "invoice", label: "POD to invoice", days: 0.5 },
  ] as CyclePhase[],
  targetDays: 6.0,
  trend: [8.1, 7.6, 7.2, 6.9, 6.6, 6.4],
};
