/**
 * Scenario 5 — Costco short-pays an invoice that was billed right.
 *
 * INV-710269 went out at K-C's price (the perfect invoice). Costco paid it
 * against its own PO and short-paid $188,000 across four reason codes. K-C
 * never reissues an invoice once a deduction exists (the September period is
 * closed for tax), so the gap is worked as an SAP FSCM dispute case on the
 * original invoice: each cause is judged, K-C-right causes are charged back,
 * Costco-right causes are credited, and every cause is sent back upstream to
 * Pricing or Master data so it does not recur. Every figure on screen comes
 * from this record through billing-dispute-selectors.ts.
 */

export type DisputeCauseKey = "price" | "promotion" | "freight" | "tax";
export type DisputeVerdict = "kc" | "customer";

export interface DisputeCause {
  key: DisputeCauseKey;
  label: string;
  /** The reason code Costco put on the 820 deduction line. */
  reasonCode: string;
  reasonText: string;
  verdict: DisputeVerdict;
  /** What K-C billed vs. what Costco paid against, in words. */
  kcSide: string;
  customerSide: string;
  finding: string;
  evidence: string[];
  systems: string[];
  routeTo: "Pricing" | "Master data";
  controlRef?: string;
}

export interface UpstreamFix {
  id: string;
  kind: "pricing-task" | "mdg-cr";
  team: "Pricing" | "Master data";
  system: string;
  cause: DisputeCauseKey;
  title: string;
  change: string;
  /** The wrong value the fix removes and the value it puts in its place. */
  from: string;
  to: string;
  assignee: string;
  status: string;
  controlRef: string;
}

export interface BillingDisputeCase {
  caseId: string;
  accountId: string;
  orderId: string;
  poNumber: string;
  customerName: string;
  soldToId: string;
  qty: number;

  invoiceId: string;
  invoiceDate: string;
  dueDate: string;
  paymentTerms: string;
  /** September is closed for tax; the invoice cannot be reissued. */
  periodClosedOn: string;

  remittanceId: string;
  remittanceDate: string;
  paymentRef: string;

  deliveryRef: string;
  deliveryDate: string;

  sapUnitPrice: number;
  pricerXNoteRef: string;
  pricerXApprovedOn: string;
  priceCatalogRef: string;
  priceCatalogSentOn: string;
  poUnitPrice: number;

  promotionSystem: "Vistex";
  promotionRef: string;
  promotionName: string;
  promotionUnitAllowance: number;
  promotionWindow: string;
  promotionExpiredOn: string;

  freightBilled: number;
  freightCapPerLoad: number;
  vendorAgreementRef: string;
  sapFreightCondition: string;

  taxBilled: number;
  taxJurisdiction: string;
  exemptionCertificate: string;
  exemptionValidTo: string;
  sapTaxClass: string;

  creditMemoRequestId: string;
  creditMemoId: string;
  chargeBackId: string;
  letterId: string;

  causes: DisputeCause[];
  upstream: UpstreamFix[];
  escalationIds: ("ESC-2621" | "ESC-2622")[];
}

export const billingDisputeCases: BillingDisputeCase[] = [
  {
    caseId: "DC-710269",
    accountId: "CUST-005",
    orderId: "SO-710269",
    poNumber: "PO-88213",
    customerName: "Costco Wholesale Corp.",
    soldToId: "0010045821",
    qty: 40_000,

    invoiceId: "INV-710269",
    invoiceDate: "2026-09-18",
    dueDate: "2026-10-18",
    paymentTerms: "Net 30",
    periodClosedOn: "2026-10-06",

    remittanceId: "RMT-CWC-1016",
    remittanceDate: "2026-10-16",
    paymentRef: "ACH 4471-2290",

    deliveryRef: "DN-540192",
    deliveryDate: "2026-09-18",

    sapUnitPrice: 31.0,
    pricerXNoteRef: "PXN-22841",
    pricerXApprovedOn: "2026-08-29",
    priceCatalogRef: "EDI 832 PC-CWC-0830",
    priceCatalogSentOn: "2026-08-30",
    poUnitPrice: 28.625,

    promotionSystem: "Vistex",
    promotionRef: "VISTEX-EVT-33920",
    promotionName: "Q2 Volume Growth Rebate",
    promotionUnitAllowance: 1.375,
    promotionWindow: "2026-04-01 to 2026-06-30",
    promotionExpiredOn: "2026-06-30",

    freightBilled: 43_000,
    freightCapPerLoad: 15_000,
    vendorAgreementRef: "Costco Vendor Agreement §7.2",
    sapFreightCondition: "ZFRT · actual pass-through",

    taxBilled: 10_000,
    taxJurisdiction: "California",
    exemptionCertificate: "CERT-CA-77120",
    exemptionValidTo: "2027-06-30",
    sapTaxClass: "Taxable (1)",

    creditMemoRequestId: "CMR-710269",
    creditMemoId: "CM-710269",
    chargeBackId: "CHB-710269",
    letterId: "LTR-710269",

    causes: [
      {
        key: "price",
        label: "Price",
        reasonCode: "04",
        reasonText: "Price discrepancy",
        verdict: "kc",
        kcSide: "$31.000 / unit",
        customerSide: "$28.625 / unit",
        finding: "PricerX approved $31.00 on Aug 29 and the EDI 832 was acknowledged; Costco paid from an old item file.",
        evidence: ["PricerX PXN-22841", "EDI 832 + 997 ack", "PO-88213"],
        systems: ["SAP S/4HANA", "PricerX"],
        routeTo: "Pricing",
      },
      {
        key: "promotion",
        label: "Promotion",
        reasonCode: "17",
        reasonText: "Promotional allowance",
        verdict: "kc",
        kcSide: "Not applicable",
        customerSide: "−$1.375 / unit",
        finding: "The Q2 Volume Growth Rebate ended Jun 30; this order delivered Sep 18.",
        evidence: ["Vistex VISTEX-EVT-33920", "POD DN-540192"],
        systems: ["Vistex"],
        routeTo: "Pricing",
        controlRef: "1.7.1",
      },
      {
        key: "freight",
        label: "Freight",
        reasonCode: "22",
        reasonText: "Freight over agreed rate",
        verdict: "customer",
        kcSide: "$43,000 actual",
        customerSide: "$15,000 cap / load",
        finding: "The vendor agreement caps freight at $15,000 per load; SAP still bills this ship-to at actual cost.",
        evidence: ["Costco Vendor Agreement §7.2", "SAP TM freight settlement"],
        systems: ["SAP S/4HANA", "SAP TM"],
        routeTo: "Master data",
      },
      {
        key: "tax",
        label: "Tax",
        reasonCode: "31",
        reasonText: "Tax not applicable",
        verdict: "customer",
        kcSide: "$10,000 CA tax",
        customerSide: "Resale exempt",
        finding: "Costco's CA resale certificate is valid to Jun 2027; SAP still classes the ship-to as taxable.",
        evidence: ["Certificate CERT-CA-77120", "Vertex tax determination"],
        systems: ["Vertex", "SAP S/4HANA"],
        routeTo: "Master data",
      },
    ],

    upstream: [
      {
        id: "PRC-TSK-3307",
        kind: "pricing-task",
        team: "Pricing",
        system: "PricerX",
        cause: "price",
        title: "Confirm Costco item file carries PXN-22841",
        change: "Buyer item file $28.625 → $31.000",
        from: "$28.625 / unit",
        to: "$31.000 / unit",
        assignee: "Revenue Management",
        status: "Open · due in 10 days",
        controlRef: "1.4.1",
      },
      {
        id: "PRC-TSK-3308",
        kind: "pricing-task",
        team: "Pricing",
        system: "Vistex",
        cause: "promotion",
        title: "Add promotion end date to Costco deal sheet",
        change: "VISTEX-EVT-33920 end 2026-06-30 on deal sheet",
        from: "No end date",
        to: "Ends 2026-06-30",
        assignee: "Trade Promotion",
        status: "Open · due in 10 days",
        controlRef: "1.4.1",
      },
      {
        id: "MDG-CR-58120",
        kind: "mdg-cr",
        team: "Master data",
        system: "SAP MDG",
        cause: "freight",
        title: "Ship-to freight condition to capped rate",
        change: "ZFRT actual pass-through → capped $15,000 / load",
        from: "$43,000 actual",
        to: "$15,000 cap / load",
        assignee: "Customer master data steward",
        status: "Submitted · awaits approval in MDG",
        controlRef: "1.4.2",
      },
      {
        id: "MDG-CR-58121",
        kind: "mdg-cr",
        team: "Master data",
        system: "SAP MDG",
        cause: "tax",
        title: "Ship-to tax classification to exempt",
        change: "Taxable (1) → Exempt (0), cert CERT-CA-77120",
        from: "Taxable (1)",
        to: "Exempt (0)",
        assignee: "Customer master data steward",
        status: "Submitted · awaits approval in MDG",
        controlRef: "1.4.2",
      },
    ],
    escalationIds: ["ESC-2621", "ESC-2622"],
  },
];

export function findBillingDisputeCase(caseId: string): BillingDisputeCase | undefined {
  return billingDisputeCases.find((c) => c.caseId === caseId);
}
