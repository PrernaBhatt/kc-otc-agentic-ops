import type { ExceptionRecord } from "./types";

export interface RecallNotice {
  id: string;
  sku: string;
  lot: string;
  status: "Quality Hold" | "Released" | "Recalled";
  reason: string;
  issuedDate: string;
}

export interface RegulatoryCheckItem {
  id: string;
  question: string;
  result: "Pass" | "Fail" | "Attention";
  finding: string;
}

export interface OrderRegulatoryReview {
  orderId: string;
  overall: "Pass" | "Hold";
  checks: RegulatoryCheckItem[];
  affectedLot?: string;
  substituteLot?: string;
}

export const recallNotices: RecallNotice[] = [
  {
    id: "RCL-2025-003",
    sku: "SKU-K110",
    lot: "LOT-88412",
    status: "Quality Hold",
    reason:
      "Supplier absorbent-core material lot failed skin-safety content verification (ISO 10993 biocompatibility). Lot must not ship until the quality review closes.",
    issuedDate: "2026-08-18",
  },
];

/**
 * Regulatory review for order SO-710262 (Walmart Inc., $92,500): the
 * incontinence briefs line references quality-held lot LOT-88412, so the order stops at
 * the Regulatory Check stage and raises a Quality Hold exception.
 */
export const regulatoryReviews: OrderRegulatoryReview[] = [
  {
    orderId: "SO-710262",
    overall: "Hold",
    affectedLot: "LOT-88412",
    substituteLot: "LOT-88907",
    checks: [
      {
        id: "REG-1",
        question: "Is any product on this order regulated?",
        result: "Attention",
        finding:
          "2 of 2 lines are regulated products (Adult Incontinence Briefs - Heavy, Feminine Care Pads - Ultra Thin).",
      },
      {
        id: "REG-2",
        question: "Is any line under a recall or quality hold?",
        result: "Fail",
        finding:
          "The incontinence briefs line is allocated to lot LOT-88412, which is under quality hold (notice RCL-2025-003).",
      },
      {
        id: "REG-3",
        question: "Is any product allocation-controlled?",
        result: "Pass",
        finding:
          "Incontinence briefs are allocation-controlled: 250 units requested, 3,150 of 5,000 monthly units still available.",
      },
      {
        id: "REG-4",
        question: "Is the customer licensed to receive these products?",
        result: "Pass",
        finding: "Distributor license on file for Walmart Inc. is current.",
      },
    ],
  },
  {
    orderId: "SO-710260",
    overall: "Pass",
    checks: [
      {
        id: "REG-1",
        question: "Is any product on this order regulated?",
        result: "Pass",
        finding: "No regulated products on this order.",
      },
      {
        id: "REG-2",
        question: "Is any line under a recall or quality hold?",
        result: "Pass",
        finding: "No lines reference a held or recalled lot.",
      },
      {
        id: "REG-3",
        question: "Is any product allocation-controlled?",
        result: "Pass",
        finding: "No allocation-controlled products on this order.",
      },
      {
        id: "REG-4",
        question: "Is the customer licensed to receive these products?",
        result: "Pass",
        finding: "No license requirement for this product mix.",
      },
    ],
  },
];

/** The order held at the Regulatory Check stage; released via Review Order Hold. */
export const REGULATED_ORDER_ID = "SO-710262";

export interface RegulatoryDecisionOption {
  id: string;
  name: string;
  type: "Balanced" | "Conservative";
  recommended: boolean;
  confidence: number;
  conditions: string[];
}

/**
 * Human-in-the-loop decision options for the SO-710262 quality hold. The AI
 * recommends the substitution; the Quality & Compliance Manager decides.
 */
export const regulatoryDecisionOptions: RegulatoryDecisionOption[] = [
  {
    id: "substitute-lot",
    name: "Substitute cleared lot LOT-88907 and release",
    type: "Balanced",
    recommended: true,
    confidence: 0.91,
    conditions: [
      "Cleared lot LOT-88907 has enough stock to cover all 250 brief units",
      "Order ships complete with no change to the promised delivery date",
      "Substitution is recorded on the quality file for lot traceability",
    ],
  },
  {
    id: "release-toilet-line",
    name: "Release only the pads line, hold the briefs",
    type: "Conservative",
    recommended: false,
    confidence: 0.84,
    conditions: [
      "Feminine care pads line ships now",
      "Incontinence briefs line waits until the quality review closes",
      "Customer is notified of the split delivery",
    ],
  },
  {
    id: "hold-entire-order",
    name: "Hold entire order until quality review closes",
    type: "Conservative",
    recommended: false,
    confidence: 0.95,
    conditions: [
      "Nothing ships until Quality Assurance closes the review",
      "Customer is notified of the delay",
      "Order is re-checked automatically when the review closes",
    ],
  },
];

/** Guardrail chips shown on the quality hold decision panel. */
export const regulatoryGuardrails = [
  "Quality policy enforced",
  "Allocation limit respected",
  "License verified",
];

/**
 * Quality Hold exception raised when SO-710262 stops at the regulatory
 * check. It is resolved in Review Order Hold, so the Exceptions screen
 * links there instead of resolving in place.
 */
export const qualityHoldException: ExceptionRecord = {
  id: "EXC-005",
  type: "Quality Hold",
  orderId: REGULATED_ORDER_ID,
  customerId: "CUST-001",
  customerName: "Walmart Inc.",
  description:
    "Incontinence briefs line references quality-held lot LOT-88412 — order stopped at regulatory check.",
  severity: "High",
  status: "Open",
  createdAt: "2026-08-20T07:58:00Z",
  assignedTo: "Quality & Compliance Manager",
};
