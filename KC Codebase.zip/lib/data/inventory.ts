/**
 * Stock and allocation position per SKU. SKU-K110's allocation numbers MUST
 * stay consistent with the regulatory check finding for SO-710262:
 * 250 units requested, 3,150 of 5,000 monthly units still available.
 */
export interface StockPosition {
  sku: string;
  productName: string;
  availableUnits: number;
  reservedUnits: number;
  /** Units already shipped against this month's allocation (allocation-controlled SKUs) */
  allocationUsedUnits?: number;
}

export const stockPositions: StockPosition[] = [
  {
    sku: "SKU-K110",
    productName: "Adult Incontinence Briefs - Heavy",
    availableUnits: 4200,
    reservedUnits: 850,
    allocationUsedUnits: 1850,
  },
  {
    sku: "SKU-K220",
    productName: "Feminine Care Pads - Ultra Thin",
    availableUnits: 6800,
    reservedUnits: 1200,
  },
  {
    sku: "SKU-F600",
    productName: "Training Pants - 4T",
    availableUnits: 2400,
    reservedUnits: 1200,
  },
  {
    sku: "SKU-G700",
    productName: "Hard Roll Towels - White",
    availableUnits: 1500,
    reservedUnits: 620,
  },
  {
    sku: "SKU-H800",
    productName: "Disinfecting Wet Wipes - Bucket",
    availableUnits: 320,
    reservedUnits: 80,
  },
  {
    sku: "SKU-I900",
    productName: "Industrial Wipers - Jumbo Roll",
    availableUnits: 900,
    reservedUnits: 0,
  },
  {
    sku: "SKU-A100",
    productName: "Facial Tissue - 3-Ply Cube",
    availableUnits: 3200,
    reservedUnits: 600,
  },
  {
    sku: "SKU-B210",
    productName: "Bathroom Tissue - Ultra Soft",
    availableUnits: 1800,
    reservedUnits: 400,
  },
  {
    sku: "SKU-B200",
    productName: "Bathroom Tissue - Standard Roll",
    availableUnits: 2600,
    reservedUnits: 500,
  },
  {
    sku: "SKU-C300",
    productName: "Paper Towels - Roll",
    availableUnits: 1100,
    reservedUnits: 250,
  },
];

export function findStock(sku: string): StockPosition | undefined {
  return stockPositions.find((s) => s.sku === sku);
}

/**
 * Monthly allocation cap for allocation-controlled SKUs (SKU-K110). Seed
 * constant kept here so the Inventory Allocation panel and the regulatory
 * finding always tie out: 1,850 used + 3,150 still available = 5,000.
 */
export const monthlyAllocationCapUnits = 5000;
