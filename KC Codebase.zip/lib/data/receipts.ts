export type ReceiptStatus = "Applied" | "Match Proposed" | "Unidentified";

export type MatchType =
  | "Exact match"
  | "Partial payment"
  | "Many-to-one"
  | "No match yet";

export interface BankReceipt {
  receiptId: string;
  bankStatementId: string;
  receivedDate: string;
  payerName: string;
  amount: number;
  remittanceReference: string | null;
  remittanceNote?: string;
  status: ReceiptStatus;
  matchType: MatchType;
  /** Invoice the AI proposes (or has applied) this receipt against */
  proposedInvoiceId?: string;
  /** Confidence of the AI match proposal (0-1) */
  matchConfidence?: number;
  /** Short-pay gap vs the proposed invoice, if any */
  shortPayAmount?: number;
  /** Deduction case created for the short-pay gap */
  deductionId?: string;
}

export const BANK_STATEMENT_ID = "Bank statement file — August 20, 2026";

/**
 * Receipts whose AI match proposal is at or above this confidence count as
 * auto-matched in the Cash Application header strip.
 */
export const AUTO_MATCH_CONFIDENCE_THRESHOLD = 0.9;

/**
 * Cash Application source data. RCPT-9001 is already applied (it is why
 * INV-12348 shows Paid). Applying RCPT-9002 flips INV-12346 to Paid.
 * RCPT-9003 short-pays INV-12347 by $3,000 and creates deduction DED-001.
 * RCPT-9004 has no reference — unapplied cash until resolved.
 */
export const bankReceipts: BankReceipt[] = [
  {
    receiptId: "RCPT-9001",
    bankStatementId: BANK_STATEMENT_ID,
    receivedDate: "2026-08-18",
    payerName: "NORTHBRIDGE SUPPLY LLC",
    amount: 67500,
    remittanceReference: "INV-12348",
    remittanceNote: "Payment in full, early settlement",
    status: "Applied",
    matchType: "Exact match",
    proposedInvoiceId: "INV-12348",
    matchConfidence: 0.99,
  },
  {
    receiptId: "RCPT-9002",
    bankStatementId: BANK_STATEMENT_ID,
    receivedDate: "2026-08-20",
    payerName: "HARBOR POINT BLDRS",
    amount: 180000,
    remittanceReference: "INV 12346",
    remittanceNote: "Electronic remittance advice attached",
    status: "Match Proposed",
    matchType: "Exact match",
    proposedInvoiceId: "INV-12346",
    matchConfidence: 0.97,
  },
  {
    receiptId: "RCPT-9003",
    bankStatementId: BANK_STATEMENT_ID,
    receivedDate: "2026-08-20",
    payerName: "WOOLWORTHS GROUP",
    amount: 39000,
    remittanceReference: "INV-12347",
    remittanceNote: "Short paid — freight damage claim CLM-301",
    status: "Match Proposed",
    matchType: "Partial payment",
    proposedInvoiceId: "INV-12347",
    matchConfidence: 0.93,
    shortPayAmount: 3000,
    deductionId: "DED-001",
  },
  {
    receiptId: "RCPT-9004",
    bankStatementId: BANK_STATEMENT_ID,
    receivedDate: "2026-08-20",
    payerName: "HARBOR POINT HOLDINGS",
    amount: 25000,
    remittanceReference: null,
    remittanceNote: "No invoice reference on payment",
    status: "Unidentified",
    matchType: "No match yet",
    matchConfidence: 0.41,
  },
];
