/**
 * The three agreements a chargeback rests on.
 *
 * A wholesaler does not buy at list price. It buys under a distribution
 * agreement at a distributor net price, resells to an institutional buyer at a
 * contracted price, and reclaims the difference from us. Three separate
 * documents make that difference claimable, and each one answers a different
 * question:
 *
 *   A  MFG to wholesaler     $100   what the wholesaler actually paid us
 *   B  wholesaler to buyer    $60   what the buyer actually paid them
 *   C  MFG to buyer (contract) $60   whether WE agreed the buyer gets $60
 *
 * B alone proves nothing against us: a wholesaler may sell at any price it
 * likes and that is its own commercial decision. Only C turns the $40 gap into
 * an obligation, which is why the eligibility check tests membership of C's
 * roster rather than the existence of B.
 *
 * The distributor net price lives HERE and not on the product, because
 * it is negotiated per distributor. The product's list price is a different
 * figure for a different audience and is left alone.
 */

export type AgreementParty = "Manufacturer" | "Wholesaler" | "Project";

export interface ChannelAgreement {
  agreementId: string;
  /** Which of the three links in the chain this document covers. */
  link: "mfg-wholesaler" | "wholesaler-project" | "mfg-project";
  title: string;
  from: AgreementParty;
  to: AgreementParty;
  fromName: string;
  toName: string;
  sku: string;
  unitPrice: number;
  effectiveFrom: string;
  effectiveTo: string | null;
  signedBy: string;
  /** What this document establishes, in one line. */
  establishes: string;
  clauses: { ref: string; text: string }[];
}

export const channelAgreements: ChannelAgreement[] = [
  {
    agreementId: "DA-NBS-2025-11",
    link: "mfg-wholesaler",
    title: "Distribution agreement",
    from: "Manufacturer",
    to: "Wholesaler",
    fromName: "Order to Cash Workspace",
    toName: "Walmart Inc.",
    sku: "SKU-K110",
    unitPrice: 100,
    effectiveFrom: "2025-11-01",
    effectiveTo: null,
    signedBy: "Commercial Finance",
    establishes: "What the wholesaler pays us per unit.",
    clauses: [
      {
        ref: "3.1",
        text: "Product is invoiced to the distributor at the distributor net price set out in Schedule A, being $100.00 per unit for SKU-K110.",
      },
      {
        ref: "7.2",
        text: "Where the distributor resells to an end customer holding a manufacturer contract, the distributor may reclaim the difference between the distributor net price and that contract price.",
      },
      {
        ref: "7.4",
        text: "A claim under 7.2 must identify the end customer, the contract relied upon, and the invoices evidencing the resale.",
      },
    ],
  },
  {
    agreementId: "SA-NLK-2026-02",
    link: "wholesaler-project",
    title: "Supply agreement",
    from: "Wholesaler",
    to: "Project",
    fromName: "Walmart Inc.",
    toName: "Regional Medical Center — North Campus",
    sku: "SKU-K110",
    unitPrice: 60,
    effectiveFrom: "2026-02-01",
    effectiveTo: null,
    signedBy: "Walmart Inc. — Contracts",
    establishes: "What the buyer pays the wholesaler per unit.",
    clauses: [
      {
        ref: "2.1",
        text: "Supplier shall invoice the customer at $60.00 per unit for SKU-K110 for the term of this agreement.",
      },
      {
        ref: "2.3",
        text: "Pricing under this agreement is set by the supplier and does not bind any manufacturer.",
      },
    ],
  },
  {
    agreementId: "CTR-NBA-2201",
    link: "mfg-project",
    title: "Project pricing agreement",
    from: "Manufacturer",
    to: "Project",
    fromName: "Order to Cash Workspace",
    toName: "Northeast institutional buyers — roster members",
    sku: "SKU-K110",
    unitPrice: 60,
    effectiveFrom: "2025-07-01",
    effectiveTo: null,
    signedBy: "Contract Compliance",
    establishes:
      "Which buyers we have agreed may buy at $60.00. Membership is by roster.",
    clauses: [
      {
        ref: "4.1",
        text: "Projects listed on the current roster may acquire SKU-K110 at $60.00 per unit through an authorised distributor.",
      },
      {
        ref: "4.2",
        text: "Entitlement attaches to the project named on the roster and does not extend to affiliates, subsidiaries or other sites within the same owner group.",
      },
      {
        ref: "4.5",
        text: "The roster in force on the last day of the claim period governs eligibility for that period.",
      },
    ],
  },
  /* The other products in the queue. Only the distribution agreement is
     modelled for these: they are queue context, not walked end to end, but a
     claim on them still needs a distributor net price or its arithmetic
     runs off a zero. */
  {
    agreementId: "DA-NBS-2025-11-M220",
    link: "mfg-wholesaler",
    title: "Distribution agreement",
    from: "Manufacturer",
    to: "Wholesaler",
    fromName: "Order to Cash Workspace",
    toName: "Walmart Inc.",
    sku: "SKU-K220",
    unitPrice: 85,
    effectiveFrom: "2025-11-01",
    effectiveTo: null,
    signedBy: "Commercial Finance",
    establishes: "What the wholesaler pays us per unit.",
    clauses: [
      {
        ref: "3.1",
        text: "Product is invoiced to the distributor at $85.00 per unit for SKU-K220.",
      },
    ],
  },
  {
    agreementId: "DA-LHG-2025-09-M330",
    link: "mfg-wholesaler",
    title: "Distribution agreement",
    from: "Manufacturer",
    to: "Wholesaler",
    fromName: "Order to Cash Workspace",
    toName: "Kroger Co.",
    sku: "SKU-K330",
    unitPrice: 65,
    effectiveFrom: "2025-09-01",
    effectiveTo: null,
    signedBy: "Commercial Finance",
    establishes: "What the wholesaler pays us per unit.",
    clauses: [
      {
        ref: "3.1",
        text: "Product is invoiced to the distributor at $65.00 per unit for SKU-K330.",
      },
    ],
  },
];

export function agreementFor(
  link: ChannelAgreement["link"],
  sku: string
): ChannelAgreement | undefined {
  return channelAgreements.find((a) => a.link === link && a.sku === sku);
}

/**
 * What the wholesaler paid us per unit — the top of the chargeback subtraction.
 * A missing agreement returns 0 rather than silently borrowing a list price.
 */
export function distributorNetPrice(sku: string): number {
  const agreement = agreementFor("mfg-wholesaler", sku);
  if (!agreement) {
    // Falling back to 0 made every downstream figure negative and the pages
    // rendered them without complaint. A missing agreement is a data gap.
    if (process.env.NODE_ENV !== "production") {
      console.error(
        `[chargeback] no distribution agreement for ${sku}; the claim arithmetic has no acquisition cost`
      );
    }
    return 0;
  }
  return agreement.unitPrice;
}

/** The three agreements behind a claim, in the order the money moves. */
export function chargebackAgreementChain(sku: string): ChannelAgreement[] {
  const order: ChannelAgreement["link"][] = [
    "mfg-wholesaler",
    "wholesaler-project",
    "mfg-project",
  ];
  return order
    .map((link) => agreementFor(link, sku))
    .filter((a): a is ChannelAgreement => Boolean(a));
}

/** Short label for a document trigger: who to whom, at what price. */
export function agreementTriggerLabel(a: ChannelAgreement): string {
  const parties: Record<ChannelAgreement["link"], string> = {
    "mfg-wholesaler": "Us to the wholesaler",
    "wholesaler-project": "Wholesaler to the buyer",
    "mfg-project": "Us to the buyer",
  };
  return `${parties[a.link]} — $${a.unitPrice.toFixed(2)}`;
}
