import type {
  AgentPerformancePoint,
  DsoPoint,
  ExceptionBreakdownPoint,
  OrderVolumePoint,
} from "./types";

export const orderVolumeTrend: OrderVolumePoint[] = [
  { month: "Mar", orders: 245, automated: 198, manual: 47 },
  { month: "Apr", orders: 267, automated: 221, manual: 46 },
  { month: "May", orders: 289, automated: 248, manual: 41 },
  { month: "Jun", orders: 312, automated: 275, manual: 37 },
  { month: "Jul", orders: 298, automated: 268, manual: 30 },
  { month: "Aug", orders: 324, automated: 295, manual: 29 },
];

export const exceptionBreakdown: ExceptionBreakdownPoint[] = [
  { name: "Credit Hold", value: 35, color: "#d10000" },
  { name: "Pricing Mismatch", value: 22, color: "#f59e0b" },
  { name: "Document Missing", value: 18, color: "#1868a5" },
  { name: "Delivery Delay", value: 15, color: "#002e49" },
  { name: "ATP Failure", value: 10, color: "#989898" },
];

export const dsoTrend: DsoPoint[] = [
  { month: "Mar", dso: 45, target: 40 },
  { month: "Apr", dso: 43, target: 40 },
  { month: "May", dso: 41, target: 40 },
  { month: "Jun", dso: 40, target: 40 },
  { month: "Jul", dso: 39, target: 40 },
  { month: "Aug", dso: 38, target: 40 },
];

export const agentPerformance: AgentPerformancePoint[] = [
  { agent: "Credit Risk", processed: 156, success: 149 },
  { agent: "Pricing", processed: 289, success: 285 },
  { agent: "Validation", processed: 324, success: 318 },
  { agent: "Billing", processed: 198, success: 195 },
  { agent: "Collections", processed: 87, success: 82 },
];
