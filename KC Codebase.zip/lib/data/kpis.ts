export const kpis = {
  loopOrdersPercent: 94.2,
  loopLinesPercent: 96.8,
  creditHoldCount: 12,
  avgHoldDuration: 4.2,
  dsoValue: 38,
  dsoDelta: -2.5,
  otif: 87.3,
  promiseHonoredPercent: 91.5,
  exceptionsCount: 24,
  exceptionsReduction: 15,
  orderCycleTime: 2.3,
  invoiceAccuracy: 98.5,
  collectionEffectiveness: 94.2,
  perfectOrderRate: 91.8,
  orderFillRate: 96.4,
  billingCycleTime: 1.8,
  disputeRate: 2.1,
  automationRate: 89,
  touchlessOrderRate: 78.5,
  revenueAtRisk: 485000,
};

export type Kpis = typeof kpis;
