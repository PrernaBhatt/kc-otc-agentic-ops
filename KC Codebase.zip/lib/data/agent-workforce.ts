/**
 * The complete agent roster — every agent the workspace puts on screen.
 *
 * Two sources, for a reason:
 *
 *   DERIVED  The six workflow definitions and the credit-hold activity feed
 *            are exported data, so the roster reads them directly. Add an
 *            agent to a workflow and it appears here on its own.
 *
 *   LISTED   The fulfilment flow and the two deduction run engines build
 *            their steps inside the component, from live order data, so they
 *            cannot be imported. Those agents are written out below with the
 *            file that owns them named against each one. If you rename an
 *            agent there, rename it here too.
 *
 * An agent that runs in more than one place is shown once, under the first
 * group it appears in, and carries a chip naming the others.
 */

import {
  billingWorkflow,
  cashCollectionsWorkflow,
  chargebackWorkflow,
  deductionRecoveryWorkflow,
  endToEndWorkflow,
  orderWorkflow,
} from "@/components/agents/workflow-definitions";
import { agentActivities } from "./activities";

export interface WorkforceAgent {
  name: string;
  glyph: string;
  /** One line a business reader understands without help. */
  role: string;
  /** The human role it works for, or the systems it reads. */
  chips: string[];
  keyActions: string[];
  /** Other places this same agent runs. */
  alsoIn: string[];
}

export interface WorkforceGroup {
  id: string;
  label: string;
  /** Where in the workspace these agents are seen working. */
  seenOn: string;
  agents: WorkforceAgent[];
}

/* ------------------------------------------------------------------ *
 * Derived: the six workflow definitions
 * ------------------------------------------------------------------ */

interface RosterStep {
  agent: string;
  agentType: string;
  persona: string;
  description: string;
  actions: string[];
}

function normalise(steps: readonly unknown[]): RosterStep[] {
  return (steps as Record<string, unknown>[]).map((s) => ({
    agent: String(s.agent ?? ""),
    agentType: String(s.agentType ?? "orchestrator"),
    persona: String(s.persona ?? ""),
    description: String(s.description ?? ""),
    // The two step shapes describe their work differently: the workflow cards
    // carry policies, the end-to-end thread carries what it reads and produces.
    actions: Array.isArray(s.policies)
      ? (s.policies as string[])
      : [s.input, s.expectedOutput].filter(Boolean).map(String),
  }));
}

/** Not an agent — it is the step where the workspace stops for a person. */
const HUMAN_STEP = "Human Review";

const DERIVED_GROUPS = [
  {
    id: "order",
    label: "Order Management",
    seenOn: "Order Management",
    steps: normalise(orderWorkflow),
  },
  {
    id: "billing",
    label: "Billing",
    seenOn: "Billing",
    steps: normalise(billingWorkflow),
  },
  {
    id: "cash",
    label: "Cash & Collections",
    seenOn: "Collections",
    steps: normalise(cashCollectionsWorkflow),
  },
  {
    id: "chargeback",
    label: "Chargeback Validation",
    seenOn: "Chargebacks",
    steps: normalise(chargebackWorkflow),
  },
  {
    id: "deduction",
    label: "Deduction Recovery",
    seenOn: "Deductions",
    steps: normalise(deductionRecoveryWorkflow),
  },
] as const;

/**
 * The end-to-end thread is a way of drawing the workspace, not a place agents
 * live. Every one of its steps is shown on the page of the flow it belongs to
 * — PO Intake appears in the Order Management audit trail, Billing in the
 * billing run — so its steps are routed into those groups rather than forming
 * a group of their own. Agents it shares with another workflow are already
 * deduplicated and never reach this map.
 */
const THREAD_HOME: Record<string, string> = {
  "PO Intake Agent": "order",
  "Regulatory Check Agent": "order",
  "Fulfillment Agent": "order",
  "POD Validation Agent": "order",
  "Billing Agent": "billing",
};

/* ------------------------------------------------------------------ *
 * Derived: the credit-hold activity feed on Review Order Hold
 * ------------------------------------------------------------------ */

const CREDIT_ROLES: Record<string, string> = {
  "OTC Orchestrator":
    "Opens the credit hold, calls the other agents in turn and assembles the options.",
  "Credit Risk Agent":
    "Scores the exposure behind a held order against the customer's limit.",
  "Pricing & Policy Agent":
    "Confirms the order prices, taxes and contract terms before anything is released.",
  "Customer LTV Agent":
    "Weighs what the relationship is worth against the risk of holding the order.",
};

const creditAgents: WorkforceAgent[] = [];
agentActivities.forEach((a) => {
  const existing = creditAgents.find((c) => c.name === a.agentName);
  if (existing) {
    if (!existing.keyActions.includes(a.message)) {
      existing.keyActions.push(a.message);
    }
    return;
  }
  creditAgents.push({
    name: a.agentName,
    glyph: a.agentType,
    role: CREDIT_ROLES[a.agentName] ?? "",
    chips: ["Credit Management System"],
    keyActions: [a.message],
    alsoIn: [],
  });
});

/* ------------------------------------------------------------------ *
 * Listed: agents whose steps are built inside a component
 * ------------------------------------------------------------------ */

/** Source: components/flows/fulfillment-flow.tsx */
const fulfilmentAgents: WorkforceAgent[] = [
  {
    name: "ATP Agent",
    glyph: "atp",
    role: "Checks stock covers every line and reserves the allocation.",
    chips: ["Warehouse Management System", "Inventory Management System"],
    keyActions: [
      "Runs the stock check across every line on the order",
      "Reserves the allocation from the warehouse",
      "Confirms the reservation before the order is released",
    ],
    alsoIn: [],
  },
  {
    name: "Order Management Agent",
    glyph: "po",
    role: "Releases the order once the hold conditions have actually been met.",
    chips: ["Order Management System", "Credit Management System"],
    keyActions: [
      "Checks the conditional release terms were met",
      "Records the Credit Manager's approval",
      "Sends the order to the warehouse fulfilment queue",
    ],
    alsoIn: [],
  },
  {
    name: "Logistics Agent",
    glyph: "delivery",
    role: "Plans the shipment, books the carrier and sets the promised date.",
    chips: ["Transportation Management System", "Carrier Booking System"],
    keyActions: [
      "Calculates the shipping route",
      "Books the carrier and records the shipment",
      "Sets the estimated delivery against the promised date",
    ],
    alsoIn: [],
  },
  {
    name: "Document Agent",
    glyph: "document",
    role: "Produces the paperwork that travels with the goods.",
    chips: ["Document Management System", "Customer Portal"],
    keyActions: [
      "Creates the packing list and shipping labels",
      "Sends the documents to the customer portal",
      "Queues the order for billing once delivery is confirmed",
    ],
    alsoIn: [],
  },
  {
    name: "Dunning Agent",
    glyph: "dunning",
    role: "Sets the payment reminders up before the invoice is even due.",
    chips: ["Payment Reminder Platform"],
    keyActions: [
      "Schedules reminders 7, 3 and 1 days before the due date",
      "Configures promise-to-pay capture",
      "Starts monitoring for on-time payment",
    ],
    alsoIn: [],
  },
  {
    name: "Proactive Dunning Agent",
    glyph: "dunning",
    role: "Nudges for early payment so the next order stays out of a hold.",
    chips: ["Payment Reminder Platform", "Email Service"],
    keyActions: [
      "Activates the early-payment nudge once fulfilment completes",
      "Keeps future processing touchless by heading off new holds",
    ],
    alsoIn: [],
  },
];

/** Source: components/views/short-pay-run.tsx and deductions-view.tsx */
const runEngineAgents: WorkforceAgent[] = [
  {
    name: "Deduction Matching Agent",
    glyph: "validation",
    role: "Splits a short payment against the claims and credits behind it.",
    chips: ["Trade Finance - Deduction Analyst"],
    keyActions: [
      "Matches each part of the deduction to a claim or a credit memo",
      "Separates the part we owe from the part already credited",
      "Shows which part is valid before anyone answers it",
    ],
    alsoIn: [],
  },
  {
    name: "Revenue Accounting Agent",
    glyph: "invoice",
    role: "Decides what a deduction costs the books once it is settled.",
    chips: ["SAP ECC", "Revenue Accountant"],
    keyActions: [
      "Separates a gross-to-net cost from a collectible receivable",
      "Draws only the valid part against the reserve",
      "Keeps the rest out of contra revenue",
    ],
    alsoIn: [],
  },
];

/**
 * Exceptions are not a workflow. Anything that stops anywhere in the thread
 * surfaces there, so one agent works across all of them rather than owning a
 * lane of its own.
 *
 * Source: components/views/exceptions-view.tsx
 */
const crossCuttingAgents: WorkforceAgent[] = [
  {
    name: "Exception Resolution Agent",
    glyph: "validation",
    role: "Reads anything that stopped, works out why, and proposes the way out.",
    chips: ["Every stage of the thread", "ServiceNow"],
    keyActions: [
      "Picks up holds, delays, price gaps and missing documents alike",
      "Reads the records behind the stop rather than the ticket text",
      "Proposes a resolution and names the owner who decides it",
    ],
    alsoIn: [],
  },
];

/**
 * Source: components/views/{appointment-slot,premium-freight,milk-run-reroute}-run.tsx
 * and the Appointment stage of the order run.
 */
const logisticsAgents: WorkforceAgent[] = [
  {
    name: "Appointment Scheduling Agent",
    glyph: "delivery",
    role: "Books the retailer receiving slot inside the OTIF window and blocks the calendar.",
    chips: ["SAP TM", "Retailer scheduling portals"],
    keyActions: [
      "Reads the TMS plan for the expected delivery",
      "Books the first open slot inside the OTIF window",
      "Asks the buyer for a slot when the calendar is full",
    ],
    alsoIn: ["Order run"],
  },
  {
    name: "Freight Planning Agent",
    glyph: "atp",
    role: "Predicts a late load before it ships and prices the way to keep it on time.",
    chips: ["SAP TM", "Transportation Manager"],
    keyActions: [
      "Flags TMS plans that cannot meet the window",
      "Writes the premium freight plan for approval",
      "Pushes the approved change back to TMS",
    ],
    alsoIn: [],
  },
  {
    name: "Track and Trace Agent",
    glyph: "orchestrator",
    role: "Follows loads in transit and reroutes a late milk run to keep the most stops on time.",
    chips: ["FourKites", "Transportation Manager"],
    keyActions: [
      "Predicts arrival per stop when the feed has none",
      "Compares route orders by OTIF misses",
      "Notifies the customer before a late arrival",
    ],
    alsoIn: [],
  },
];

/* ------------------------------------------------------------------ *
 * Fold them together
 * ------------------------------------------------------------------ */

function buildRoster(): WorkforceGroup[] {
  const seen = new Map<string, WorkforceAgent>();
  const groups: WorkforceGroup[] = [];

  const place = (
    id: string,
    label: string,
    seenOn: string,
    agents: WorkforceAgent[]
  ) => {
    const kept: WorkforceAgent[] = [];
    agents.forEach((agent) => {
      if (!agent.name || agent.name === HUMAN_STEP) return;
      const existing = seen.get(agent.name);
      if (existing) {
        if (!existing.alsoIn.includes(label)) existing.alsoIn.push(label);
        return;
      }
      seen.set(agent.name, agent);
      kept.push(agent);
    });
    if (kept.length) groups.push({ id, label, seenOn, agents: kept });
  };

  const threadSteps = normalise(endToEndWorkflow);

  DERIVED_GROUPS.forEach((g) => {
    const own = [
      ...g.steps,
      ...threadSteps.filter((t) => THREAD_HOME[t.agent] === g.id),
    ];
    place(
      g.id,
      g.label,
      g.seenOn,
      own.map((s) => ({
        name: s.agent,
        glyph: s.agentType,
        role: s.description,
        chips: s.persona ? [s.persona] : [],
        keyActions: s.actions.slice(0, 3),
        alsoIn: [],
      }))
    );
  });

  place("credit", "Credit hold review", "Review Order Hold", creditAgents);
  place("fulfilment", "Fulfilment", "the order fulfilment run", fulfilmentAgents);
  place("logistics", "OTIF at risk", "Track & Trace", logisticsAgents);
  place("runs", "Deduction run engines", "Deductions", runEngineAgents);
  place("cross", "Across the workspace", "Exceptions", crossCuttingAgents);

  return groups;
}

export const workforceGroups: WorkforceGroup[] = buildRoster();

export const workforceAgents: WorkforceAgent[] = workforceGroups.flatMap(
  (g) => g.agents
);

const allSteps = [
  ...DERIVED_GROUPS.flatMap((g) => g.steps),
  ...normalise(endToEndWorkflow),
];
const humanSteps = allSteps.filter((s) => s.agent === HUMAN_STEP).length;

export const workforceTotals = {
  /** Distinct agents the workspace runs. */
  agentCount: workforceAgents.length,
  /** Areas of the workspace they are grouped into. */
  groupCount: workforceGroups.length,
  /** Workflow steps carried without a person, against every step defined. */
  agentSteps: allSteps.length - humanSteps,
  totalSteps: allSteps.length,
  /** Steps that stop for a person across the walked cases. */
  humanGates: 8,
  draftedToRelease: 2,
};
