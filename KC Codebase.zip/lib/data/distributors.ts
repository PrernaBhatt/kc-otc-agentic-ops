/**
 * Wholesalers, the projects they sell on to, and which contract roster each
 * project belongs to.
 *
 * A chargeback is a three-party arrangement: we invoice a wholesaler at list
 * price, the wholesaler resells to an institutional buyer (a hospital system,
 * school district, senior-living network, and the like) at a contracted price,
 * and then claims the difference back from us. Validating a claim means
 * checking the buyer is actually covered by the contract the claim cites.
 *
 * The Distributor record is a ROLE OVERLAY on an existing Customer. It never
 * restates a Customer field - name, credit limit and exposure stay in
 * lib/data/customers.ts, which nine other pages read.
 */

/** Wholesaler role overlay on an existing Customer. */
export interface Distributor {
  distributorId: string;
  /** Foreign key into lib/data/customers.ts */
  customerId: string;
  distributorLicenseRef: string;
  /** Where the license was verified - cites the regulatory register. */
  licenseEvidence: string;
  submissionChannel: "Chargeback portal" | "Electronic claim feed" | "Email";
}

export const distributors: Distributor[] = [
  {
    distributorId: "DIST-001",
    customerId: "CUST-001",
    distributorLicenseRef: "DAA-NE-33418",
    licenseEvidence:
      "Regulatory check REG-4 — distributor license on file is current",
    submissionChannel: "Chargeback portal",
  },
  {
    distributorId: "DIST-004",
    customerId: "CUST-004",
    distributorLicenseRef: "DAA-NE-51902",
    licenseEvidence:
      "Regulatory check REG-4 — distributor license on file is current",
    submissionChannel: "Electronic claim feed",
  },
];

export function findDistributor(distributorId: string): Distributor | undefined {
  return distributors.find((d) => d.distributorId === distributorId);
}

/** An institutional buyer the wholesaler sells on to. */
export interface EndCustomer {
  endCustomerId: string;
  name: string;
  projectType: "Healthcare" | "Education" | "Long-term care" | "Government" | "Hospitality";
  city: string;
  state: string;
  /**
   * Parent owner group. This is how the AI spots that the buyer on the
   * claim is a sibling of one that IS on the cited roster - the most common
   * honest cause of a wrong-roster claim.
   */
  ownerGroup: string;
}

export const endCustomers: EndCustomer[] = [
  {
    endCustomerId: "END-NLK-ENDO",
    name: "Regional Medical Center — North Campus",
    projectType: "Healthcare",
    city: "Minneapolis",
    state: "MN",
    ownerGroup: "Regional Medical Center",
  },
  {
    endCustomerId: "END-NLK-GEN",
    name: "Regional Medical Center — West Campus",
    projectType: "Healthcare",
    city: "Minneapolis",
    state: "MN",
    ownerGroup: "Regional Medical Center",
  },
  {
    endCustomerId: "END-CEDAR",
    name: "Duluth Public School District",
    projectType: "Education",
    city: "Duluth",
    state: "MN",
    ownerGroup: "Duluth Public Schools",
  },
  {
    endCustomerId: "END-PRAIRIE",
    name: "Fargo State University Dining Services",
    projectType: "Education",
    city: "Fargo",
    state: "ND",
    ownerGroup: "Fargo State University System",
  },
  {
    endCustomerId: "END-AUBIN",
    name: "Eau Claire Senior Living Network",
    projectType: "Long-term care",
    city: "Eau Claire",
    state: "WI",
    ownerGroup: "Eau Claire Senior Care Group",
  },
  {
    endCustomerId: "END-HALVERSON",
    name: "Rochester Veterans Medical Center",
    projectType: "Government",
    city: "Rochester",
    state: "MN",
    ownerGroup: "Veterans Health Administration",
  },
  {
    endCustomerId: "END-TWORIVERS",
    name: "Green Bay Convention Center",
    projectType: "Hospitality",
    city: "Green Bay",
    state: "WI",
    ownerGroup: "Green Bay Hospitality Group",
  },
  {
    endCustomerId: "END-FAIRMONT",
    name: "Madison Community Hospital",
    projectType: "Healthcare",
    city: "Madison",
    state: "WI",
    ownerGroup: "Madison Community Health",
  },
];

export function findEndCustomer(id: string): EndCustomer | undefined {
  return endCustomers.find((e) => e.endCustomerId === id);
}

/** The list of projects a contract's prices apply to. */
export interface ContractRoster {
  rosterId: string;
  contractId: string;
  label: string;
  sponsor: string;
}

export const contractRosters: ContractRoster[] = [
  {
    rosterId: "ROSTER-NBA",
    contractId: "CTR-NBA-2201",
    label: "Northeast institutional pricing roster",
    sponsor: "Northeast Group Purchasing Organization",
  },
  {
    rosterId: "ROSTER-NLK",
    contractId: "CTR-NLK-2026",
    label: "Regional Medical Center direct agreement",
    sponsor: "Direct — no buying group",
  },
  {
    rosterId: "ROSTER-MW",
    contractId: "CTR-MW-2205",
    label: "Midwest institutional roster",
    sponsor: "Midwest Group Purchasing Organization",
  },
];

export function findRoster(rosterId: string): ContractRoster | undefined {
  return contractRosters.find((r) => r.rosterId === rosterId);
}

/**
 * Which projects are on which roster, and from when.
 *
 * END-NLK-ENDO IS on ROSTER-NBA, so the claim cites the right contract and
 * the eligibility stage passes. The flow was simplified to one finding: the
 * project is entitled to the price it was given, and what fails is the
 * volume - 8,000 of the 20,000 units claimed were never invoiced or
 * delivered. Two failures competing for attention made the run harder to
 * follow than the single one that decides it.
 */
export interface RosterMembership {
  membershipId: string;
  rosterId: string;
  endCustomerId: string;
  effectiveFrom: string;
  effectiveTo: string | null;
}

export const rosterMemberships: RosterMembership[] = [
  {
    membershipId: "RM-2101",
    rosterId: "ROSTER-NBA",
    endCustomerId: "END-NLK-GEN",
    effectiveFrom: "2023-11-15",
    effectiveTo: null,
  },
  {
    membershipId: "RM-2118",
    rosterId: "ROSTER-NBA",
    endCustomerId: "END-CEDAR",
    effectiveFrom: "2024-01-08",
    effectiveTo: null,
  },
  {
    membershipId: "RM-2144",
    rosterId: "ROSTER-NBA",
    endCustomerId: "END-PRAIRIE",
    effectiveFrom: "2024-06-01",
    effectiveTo: null,
  },
  {
    membershipId: "RM-2170",
    rosterId: "ROSTER-NBA",
    endCustomerId: "END-AUBIN",
    effectiveFrom: "2025-02-17",
    effectiveTo: null,
  },
  {
    membershipId: "RM-2192",
    rosterId: "ROSTER-NBA",
    endCustomerId: "END-HALVERSON",
    effectiveFrom: "2025-05-05",
    effectiveTo: null,
  },
  {
    membershipId: "RM-2206",
    rosterId: "ROSTER-NBA",
    endCustomerId: "END-TWORIVERS",
    effectiveFrom: "2025-09-01",
    effectiveTo: null,
  },
  {
    membershipId: "RM-2231",
    rosterId: "ROSTER-NBA",
    endCustomerId: "END-NLK-ENDO",
    effectiveFrom: "2025-12-01",
    effectiveTo: null,
  },
  {
    membershipId: "RM-2402",
    rosterId: "ROSTER-MW",
    endCustomerId: "END-FAIRMONT",
    effectiveFrom: "2024-09-12",
    effectiveTo: null,
  },
];

/** Projects on a roster, in the order they joined. */
export function rosterMembers(rosterId: string): {
  membership: RosterMembership;
  endCustomer: EndCustomer;
}[] {
  return rosterMemberships
    .filter((m) => m.rosterId === rosterId)
    .map((membership) => ({
      membership,
      endCustomer: findEndCustomer(membership.endCustomerId)!,
    }))
    .filter((row) => Boolean(row.endCustomer));
}

/** Whether a project is on a given roster on a given date. */
export function isOnRoster(
  rosterId: string,
  endCustomerId: string,
  onDate: string
): boolean {
  return rosterMemberships.some(
    (m) =>
      m.rosterId === rosterId &&
      m.endCustomerId === endCustomerId &&
      m.effectiveFrom <= onDate &&
      (m.effectiveTo === null || m.effectiveTo >= onDate)
  );
}

/** The roster a project IS on, if any — used to find the right contract. */
export function rosterFor(
  endCustomerId: string,
  onDate: string
): ContractRoster | undefined {
  const membership = rosterMemberships.find(
    (m) =>
      m.endCustomerId === endCustomerId &&
      m.effectiveFrom <= onDate &&
      (m.effectiveTo === null || m.effectiveTo >= onDate)
  );
  return membership ? findRoster(membership.rosterId) : undefined;
}
