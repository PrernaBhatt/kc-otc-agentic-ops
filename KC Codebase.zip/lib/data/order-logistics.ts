/**
 * What the logistics agents read and write on the touchless order runs.
 * TMS owns route, load and carrier (Shipment planning); the Appointment
 * Scheduling Agent books a slot the customer's OTIF rule accepts; the Track
 * and Trace Agent follows the load from staged to signed POD.
 */

export const TMS_SYSTEM = "SAP TM";

export interface TmsPlan {
  loadId: string;
  route: string;
  load: string;
  carrier: string;
  pickup: string;
  /** Expected delivery from the TMS plan, "Sat 2026-08-29 05:30". */
  eta: string;
}

export interface OtifWindow {
  /** ISO day the window applies to. */
  date: string;
  from: string;
  to: string;
  label: string;
  rule: string;
}

/** The customer's own OTIF rule: which arrival days count as on time. */
export interface OtifPolicy {
  basis: "requested date" | "MABD";
  earlyDays: number;
  lateDays: number;
  rule: string;
}

export interface RoutePlan {
  origin: string;
  destination: string;
  miles: number;
  driveMin: number;
}

export interface LoadPlan {
  pallets: number;
  palletPositions: number;
  weightLb: number;
  maxWeightLb: number;
  equipment: string;
}

export interface TenderRecord {
  carrier: string;
  rateUsd: number;
  acceptedAt: string;
}

export interface DeliveryTrack {
  available: { at: string; detail: string };
  shipped: { at: string; detail: string; bol: string };
  ping: { at: string; position: string; milesLeft: number; peta: string };
  arrived: string;
  pod: { at: string; signer: string; received: string };
}

export interface OrderLogistics {
  tmsPlan: TmsPlan;
  otifWindow: OtifWindow;
  otifPolicy: OtifPolicy;
  routePlan: RoutePlan;
  loadPlan: LoadPlan;
  tender: TenderRecord;
  delivery: DeliveryTrack;
  confirmationDocNo: string;
}

export const ORDER_LOGISTICS: Record<string, OrderLogistics> = {
  "SO-710260": {
    tmsPlan: {
      loadId: "LD-ONT-260828-0417",
      route: "DC-ONT Ontario, CA → Costco Depot #C-114, City of Industry, CA · 24 mi",
      load: "26 pallets · 18,400 lb · 53' dry van",
      carrier: "Blue Line Freight · BLFT",
      pickup: "Fri 2026-08-28 16:00",
      eta: "Sat 2026-08-29 05:30",
    },
    otifWindow: {
      date: "2026-08-29",
      from: "05:00",
      to: "15:00",
      label: "Sat 2026-08-29 · 05:00–15:00",
      rule: "Costco OTIF: arrive on the requested date, inside receiving hours",
    },
    otifPolicy: {
      basis: "requested date",
      earlyDays: 0,
      lateDays: 0,
      rule: "Costco OTIF: arrive on the requested date · 0 days early · 0 days late",
    },
    routePlan: {
      origin: "DC-ONT Ontario, CA",
      destination: "Costco Depot #C-114, City of Industry, CA",
      miles: 24,
      driveMin: 35,
    },
    loadPlan: {
      pallets: 26,
      palletPositions: 30,
      weightLb: 18_400,
      maxWeightLb: 45_000,
      equipment: "53' dry van",
    },
    tender: { carrier: "Blue Line Freight · BLFT", rateUsd: 1_840, acceptedAt: "2026-08-20 06:39" },
    delivery: {
      available: { at: "2026-08-28 13:10", detail: "26 of 26 pallets picked and staged at door 7" },
      shipped: { at: "2026-08-28 16:02", detail: "Loaded, sealed and gated out of DC-ONT", bol: "BOL-0417-260828" },
      ping: { at: "2026-08-29 05:21", position: "CA-60 E near Pomona", milesLeft: 9, peta: "05:52" },
      arrived: "2026-08-29 05:54",
      pod: { at: "2026-08-29 07:42", signer: "R. Alvarez, Receiving", received: "26 of 26 pallets · no OS&D" },
    },
    confirmationDocNo: "APPT-C114-58213",
  },
  "SO-710249": {
    tmsPlan: {
      loadId: "LD-ONT-260828-0388",
      route: "DC-ONT Ontario, CA → Target DC T-0553, Fontana, CA · 13 mi",
      load: "22 pallets · 15,900 lb · 53' dry van",
      carrier: "Blue Line Freight · BLFT",
      pickup: "Fri 2026-08-28 07:45",
      eta: "Fri 2026-08-28 08:30",
    },
    otifWindow: {
      date: "2026-08-28",
      from: "04:00",
      to: "20:00",
      label: "Fri 2026-08-28 · 04:00–20:00",
      rule: "Target OTIF: arrive on the requested date, inside receiving hours",
    },
    otifPolicy: {
      basis: "requested date",
      earlyDays: 0,
      lateDays: 0,
      rule: "Target OTIF: arrive on the requested date · 0 days early · 0 days late",
    },
    routePlan: {
      origin: "DC-ONT Ontario, CA",
      destination: "Target DC T-0553, Fontana, CA",
      miles: 13,
      driveMin: 25,
    },
    loadPlan: {
      pallets: 22,
      palletPositions: 30,
      weightLb: 15_900,
      maxWeightLb: 45_000,
      equipment: "53' dry van",
    },
    tender: { carrier: "Blue Line Freight · BLFT", rateUsd: 1_460, acceptedAt: "2026-08-14 10:50" },
    delivery: {
      available: { at: "2026-08-28 05:50", detail: "22 of 22 pallets picked and staged at door 3" },
      shipped: { at: "2026-08-28 07:47", detail: "Loaded, sealed and gated out of DC-ONT", bol: "BOL-0388-260828" },
      ping: { at: "2026-08-28 08:12", position: "I-10 E near Fontana", milesLeft: 4, peta: "08:28" },
      arrived: "2026-08-28 08:29",
      pod: { at: "2026-08-28 09:46", signer: "D. Nguyen, Inbound", received: "22 of 22 pallets · no OS&D" },
    },
    confirmationDocNo: "APPT-T0553-77410",
  },
};

export function orderLogistics(orderId: string): OrderLogistics | undefined {
  return ORDER_LOGISTICS[orderId];
}

/** "Sat 2026-08-29" + "06:00" falls inside the window. */
export function insideOtifWindow(w: OtifWindow, dayLabel: string, time: string) {
  const iso = dayLabel.split(" ").find((p) => /^\d{4}-\d{2}-\d{2}$/.test(p));
  return iso === w.date && time >= w.from && time < w.to;
}

/** Whole days a calendar day sits before (−) or after (+) the window day. */
export function daysFromWindow(w: OtifWindow, dayLabel: string) {
  const iso = dayLabel.split(" ").find((p) => /^\d{4}-\d{2}-\d{2}$/.test(p)) ?? w.date;
  return Math.round((Date.parse(`${iso}T00:00:00Z`) - Date.parse(`${w.date}T00:00:00Z`)) / 86_400_000);
}

/** The customer's OTIF verdict for an arrival on this calendar day. */
export function otifVerdict(l: OrderLogistics, dayLabel: string): "inside" | "early" | "late" {
  const d = daysFromWindow(l.otifWindow, dayLabel);
  if (d < -l.otifPolicy.earlyDays) return "early";
  if (d > l.otifPolicy.lateDays) return "late";
  return "inside";
}

export const cubePct = (p: LoadPlan) => Math.round((p.pallets / p.palletPositions) * 100);
export const weightPct = (p: LoadPlan) => Math.round((p.weightLb / p.maxWeightLb) * 100);
