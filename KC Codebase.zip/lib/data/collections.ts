export interface PromiseToPay {
  ptpId: string;
  customerId: string;
  customerName: string;
  invoiceId: string;
  amount: number;
  promisedDate: string;
  status: "Open" | "Honored" | "Broken";
  capturedOn: string;
}

export interface EscalationRule {
  id: string;
  trigger: string;
  escalateTo: string;
}

export const promisesToPay: PromiseToPay[] = [
  {
    ptpId: "PTP-001",
    customerId: "CUST-002",
    customerName: "Tesco PLC",
    invoiceId: "INV-12341",
    amount: 85000,
    promisedDate: "2026-08-28",
    status: "Open",
    capturedOn: "2026-08-17",
  },
  {
    ptpId: "PTP-002",
    customerId: "CUST-001",
    customerName: "Walmart Inc.",
    invoiceId: "INV-12348",
    amount: 67500,
    promisedDate: "2026-08-19",
    status: "Honored",
    capturedOn: "2026-08-10",
  },
];

export const escalationRules: EscalationRule[] = [
  {
    id: "ESC-1",
    trigger: "Invoice value above $50,000 and more than 60 days late",
    escalateTo: "Finance leadership",
  },
  {
    id: "ESC-2",
    trigger: "Disputed balance more than 90 days late",
    escalateTo: "Legal review",
  },
  {
    id: "ESC-3",
    trigger: "Broken promise to pay",
    escalateTo: "Credit Manager",
  },
];
