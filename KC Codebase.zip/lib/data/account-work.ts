/**
 * The work behind each account owner: the agents doing it this week and the
 * open items outside the runs (orders, collections, cash application). Agent
 * counts tie out to `workload.agents` in account-owners.ts.
 */

export interface AccountAgent {
  name: string;
  glyph: string;
  doing: string;
  itemsThisWeek: number;
  lastActionAt: string;
}

export interface StaticOpenWork {
  orders: { count: number; usd: number };
  collections: { count: number; usd: number };
  cash: { count: number; usd: number };
  oldestDays: number;
}

export const accountAgents: Record<string, AccountAgent[]> = {
  "CUST-001": [
    { name: "Order Management Agent", glyph: "orchestrator", doing: "Releasing EDI 850 orders to delivery", itemsThisWeek: 112, lastActionAt: "09:42" },
    { name: "Cash Application Agent", glyph: "billing", doing: "Matching Retail Link remittances", itemsThisWeek: 86, lastActionAt: "09:38" },
    { name: "Deduction Classification Agent", glyph: "validation", doing: "Classifying non-trade claims", itemsThisWeek: 64, lastActionAt: "09:31" },
    { name: "Promotion Validation Agent", glyph: "pricing", doing: "Checking proof of performance", itemsThisWeek: 48, lastActionAt: "09:12" },
    { name: "Evidence Matching Agent", glyph: "document", doing: "Pulling POD and ASN for OTIF fines", itemsThisWeek: 42, lastActionAt: "08:57" },
    { name: "Fund Allocation Agent", glyph: "credit", doing: "Reconciling Q3 promotion funds", itemsThisWeek: 26, lastActionAt: "08:40" },
    { name: "Dunning Agent", glyph: "invoice", doing: "Sending day-5 reminders", itemsThisWeek: 20, lastActionAt: "08:15" },
  ],
  "CUST-005": [
    { name: "Order Management Agent", glyph: "orchestrator", doing: "Running touchless order checks", itemsThisWeek: 94, lastActionAt: "09:44" },
    { name: "Cash Application Agent", glyph: "billing", doing: "Reading EDI 820 remittances", itemsThisWeek: 61, lastActionAt: "09:36" },
    { name: "Dispute Investigation Agent", glyph: "pricing", doing: "Judging short-pay causes", itemsThisWeek: 38, lastActionAt: "09:20" },
    { name: "Pricing Validation Agent", glyph: "validation", doing: "Comparing PricerX to the item file", itemsThisWeek: 36, lastActionAt: "09:05" },
    { name: "FSCM Posting Agent", glyph: "invoice", doing: "Posting credit memos and residuals", itemsThisWeek: 28, lastActionAt: "08:52" },
    { name: "Appointment Scheduling Agent", glyph: "delivery", doing: "Booking slots inside OTIF windows", itemsThisWeek: 20, lastActionAt: "08:30" },
  ],
  "CUST-006": [
    { name: "Order Management Agent", glyph: "orchestrator", doing: "Releasing Partners Online orders", itemsThisWeek: 71, lastActionAt: "09:40" },
    { name: "Pricing Validation Agent", glyph: "validation", doing: "Checking PO prices against contract", itemsThisWeek: 44, lastActionAt: "09:28" },
    { name: "Cash Application Agent", glyph: "billing", doing: "Applying weekly remittance", itemsThisWeek: 39, lastActionAt: "09:10" },
    { name: "Deduction Classification Agent", glyph: "pricing", doing: "Classifying compliance fines", itemsThisWeek: 24, lastActionAt: "08:48" },
    { name: "Dunning Agent", glyph: "invoice", doing: "Following up past-due invoices", itemsThisWeek: 14, lastActionAt: "08:20" },
  ],
  "CUST-004": [
    { name: "Order Management Agent", glyph: "orchestrator", doing: "Releasing EDI 850 orders", itemsThisWeek: 58, lastActionAt: "09:41" },
    { name: "Cash Application Agent", glyph: "billing", doing: "Splitting short payments by cause", itemsThisWeek: 42, lastActionAt: "09:30" },
    { name: "Deduction Matching Agent", glyph: "validation", doing: "Matching credits to deductions", itemsThisWeek: 33, lastActionAt: "09:14" },
    { name: "Duplicate Screening Agent", glyph: "document", doing: "Screening post-audit claims", itemsThisWeek: 21, lastActionAt: "08:55" },
    { name: "Evidence Matching Agent", glyph: "credit", doing: "Pulling carrier claims", itemsThisWeek: 16, lastActionAt: "08:33" },
  ],
  "CUST-002": [
    { name: "Order Management Agent", glyph: "orchestrator", doing: "Releasing EDIFACT orders", itemsThisWeek: 46, lastActionAt: "09:22" },
    { name: "Rebate Validation Agent", glyph: "pricing", doing: "Re-running the growth rebate tier", itemsThisWeek: 31, lastActionAt: "09:02" },
    { name: "Cash Application Agent", glyph: "billing", doing: "Applying BACS receipts", itemsThisWeek: 27, lastActionAt: "08:47" },
    { name: "Dunning Agent", glyph: "invoice", doing: "Sending statement reminders", itemsThisWeek: 15, lastActionAt: "08:10" },
  ],
  "CUST-003": [
    { name: "Order Management Agent", glyph: "orchestrator", doing: "Releasing AU orders", itemsThisWeek: 29, lastActionAt: "09:18" },
    { name: "Promotion Validation Agent", glyph: "pricing", doing: "Waiting on proof of performance", itemsThisWeek: 22, lastActionAt: "08:58" },
    { name: "Cash Application Agent", glyph: "billing", doing: "Applying AUD remittances", itemsThisWeek: 18, lastActionAt: "08:41" },
    { name: "Dunning Agent", glyph: "invoice", doing: "Chasing aged trade claims", itemsThisWeek: 11, lastActionAt: "08:05" },
  ],
};

export const staticOpenWork: Record<string, StaticOpenWork> = {
  "CUST-001": { orders: { count: 3, usd: 412_000 }, collections: { count: 2, usd: 96_400 }, cash: { count: 1, usd: 38_200 }, oldestDays: 18 },
  "CUST-005": { orders: { count: 1, usd: 286_500 }, collections: { count: 1, usd: 54_000 }, cash: { count: 0, usd: 0 }, oldestDays: 12 },
  "CUST-006": { orders: { count: 1, usd: 220_740 }, collections: { count: 1, usd: 31_800 }, cash: { count: 1, usd: 12_400 }, oldestDays: 9 },
  "CUST-004": { orders: { count: 1, usd: 148_000 }, collections: { count: 1, usd: 22_600 }, cash: { count: 0, usd: 0 }, oldestDays: 14 },
  "CUST-002": { orders: { count: 1, usd: 96_000 }, collections: { count: 2, usd: 61_200 }, cash: { count: 0, usd: 0 }, oldestDays: 21 },
  "CUST-003": { orders: { count: 1, usd: 74_300 }, collections: { count: 1, usd: 28_900 }, cash: { count: 0, usd: 0 }, oldestDays: 47 },
};
