import type { Invoice } from "./types";

/**
 * Older open invoices that extend the aging ladder beyond the four recent
 * invoices shown in Transactions. Together: invoices + agedInvoices is the
 * full AR subledger used by aging, collections worklist, and the provision.
 *
 * NOTE (documented data fix): the compiled demo showed INV-12347 as
 * "Overdue" with a future due date — the canonical layer keeps the status
 * and the aging math consistent instead.
 */
export const agedInvoices: Invoice[] = [
  {
    invoiceId: "INV-12341",
    orderId: "SO-710236",
    customerId: "CUST-002",
    customerName: "Tesco PLC",
    invoiceDate: "2026-03-06",
    dueDate: "2026-04-05",
    amount: 85000,
    status: "Overdue",
  },
  {
    invoiceId: "INV-12342",
    orderId: "SO-710233",
    customerId: "CUST-001",
    customerName: "Walmart Inc.",
    invoiceDate: "2026-02-04",
    dueDate: "2026-03-06",
    amount: 56000,
    status: "Overdue",
  },
  {
    invoiceId: "INV-12343",
    orderId: "SO-710228",
    customerId: "CUST-003",
    customerName: "Woolworths Group",
    invoiceDate: "2026-01-10",
    dueDate: "2026-02-09",
    amount: 28000,
    status: "Overdue",
  },
];
