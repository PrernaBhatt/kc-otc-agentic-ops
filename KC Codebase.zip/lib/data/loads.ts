/**
 * Track & Trace: every load the agents follow, as of the Command Center clock.
 * Loads tied to an OTIF-at-risk case reuse that case's customer, site, window
 * and ETA from shipment-risk.ts. In-transit loads carry the inputs of the
 * agent's predictive ETA; p50, band and OTIF risk are derived in
 * lib/shipment-selectors.ts and asserted there.
 */

export const LOAD_MILESTONES = ["Planned", "Picking", "Available", "Shipped", "In transit", "Delivered"] as const;
export type LoadMilestone = (typeof LOAD_MILESTONES)[number];

export type EtaSource = "TMS plan" | "FourKites PETA" | "Agent ETA" | "POD";

/** One destination the prediction runs for. Drive, traffic and dwell are cumulative from the last ping. */
export interface EtaLeg {
  stop: string;
  customer: string;
  site: string;
  windowFrom: string;
  windowTo: string;
  miles: number;
  /** Drive minutes left at this lane's 90-day p50 speed. */
  driveMin: number;
  trafficMin: number;
  trafficNote: string;
  dwellMin: number;
  dwellNote: string;
  /** Minutes before / after p50 that bound 80% of arrivals on this lane. */
  earlyMin: number;
  lateMin: number;
  /** FourKites' own predictive ETA, when it gives one for this stop. */
  fourKitesPeta?: string;
}

export interface EtaPrediction {
  date: string;
  pingAt: string;
  position: string;
  hosLeftMin: number;
  legs: EtaLeg[];
}

export interface NetworkLoad {
  loadId: string;
  /** OTIF-at-risk case this load belongs to, if any. */
  caseId?: string;
  customer: string;
  site: string;
  orderRef: string;
  carrier: string;
  origin: string;
  /** Index into LOAD_MILESTONES of the last milestone reached. */
  stage: number;
  /** Time each reached milestone happened, "Thu 07:10". */
  times: string[];
  window: { from: string; to: string; label: string };
  eta: string;
  etaLabel: string;
  etaSource: EtaSource;
  predict?: EtaPrediction;
}

const BLFT = "Blue Line Freight · BLFT";
const PCCR = "Pacific Coast Carriers · PCCR";
const SMLG = "Summit Logistics · SMLG";

export const NETWORK_LOADS: NetworkLoad[] = [
  /* ---------- pre-shipment ---------- */
  {
    loadId: "LD-ONT-260824-0912",
    caseId: "SHP-58201",
    customer: "Walmart",
    site: "RDC 6094, Buckeye, AZ",
    orderRef: "SO-710264",
    carrier: BLFT,
    origin: "DC-ONT",
    stage: 0,
    times: ["Thu 06:02"],
    window: { from: "2026-08-24 00:00", to: "2026-08-27 00:00", label: "Mon 08-24 → MABD Wed 08-26" },
    eta: "2026-08-27 06:00",
    etaLabel: "First slot Thu 06:00",
    etaSource: "TMS plan",
  },
  {
    loadId: "LD-DAL-260825-0233",
    caseId: "SHP-58207",
    customer: "Kroger",
    site: "DC 024, Forest Park, GA",
    orderRef: "SO-710265",
    carrier: PCCR,
    origin: "DC-DAL",
    stage: 0,
    times: ["Thu 07:44"],
    window: { from: "2026-08-26 08:00", to: "2026-08-26 09:00", label: "Wed 08:00–09:00" },
    eta: "2026-08-27 06:00",
    etaLabel: "Replan Thu 06:00",
    etaSource: "TMS plan",
  },
  {
    loadId: "LD-DAL-260821-0145",
    caseId: "SHP-58214",
    customer: "Target",
    site: "DC T-3809, Midway, GA",
    orderRef: "SO-710268",
    carrier: SMLG,
    origin: "DC-DAL",
    stage: 1,
    times: ["Wed 15:20", "Thu 06:30"],
    window: { from: "2026-08-21 14:00", to: "2026-08-21 16:00", label: "Fri 14:00–16:00" },
    eta: "2026-08-21 15:20",
    etaLabel: "Fri 15:20",
    etaSource: "TMS plan",
  },
  {
    loadId: "LD-SAC-260822-0061",
    caseId: "SHP-58219",
    customer: "Costco",
    site: "Depot C-207, Tracy, CA",
    orderRef: "SO-710269",
    carrier: BLFT,
    origin: "DC-SAC",
    stage: 1,
    times: ["Wed 11:05", "Thu 05:40"],
    window: { from: "2026-08-22 06:00", to: "2026-08-22 08:00", label: "Sat 06:00–08:00" },
    eta: "2026-08-22 06:40",
    etaLabel: "Sat 06:40",
    etaSource: "TMS plan",
  },
  {
    loadId: "LD-ONT-260828-0417",
    customer: "Costco",
    site: "Depot #C-114, City of Industry, CA",
    orderRef: "SO-710260",
    carrier: BLFT,
    origin: "DC-ONT",
    stage: 0,
    times: ["Thu 06:39"],
    window: { from: "2026-08-29 06:00", to: "2026-08-29 08:00", label: "Sat 08-29 06:00–08:00" },
    eta: "2026-08-29 05:30",
    etaLabel: "Sat 08-29 05:30",
    etaSource: "TMS plan",
  },
  {
    loadId: "LD-ONT-260828-0388",
    customer: "Target",
    site: "DC T-0553, Fontana, CA",
    orderRef: "SO-710249",
    carrier: BLFT,
    origin: "DC-ONT",
    stage: 0,
    times: ["Fri 08-14 10:50"],
    window: { from: "2026-08-28 09:00", to: "2026-08-28 11:00", label: "Fri 08-28 09:00–11:00" },
    eta: "2026-08-28 08:30",
    etaLabel: "Fri 08-28 08:30",
    etaSource: "TMS plan",
  },
  {
    loadId: "LD-ONT-260821-0150",
    customer: "Kroger",
    site: "DC Riverside, CA",
    orderRef: "SO-710287",
    carrier: PCCR,
    origin: "DC-ONT",
    stage: 2,
    times: ["Wed 09:10", "Thu 04:30", "Thu 07:55"],
    window: { from: "2026-08-21 07:00", to: "2026-08-21 08:00", label: "Fri 07:00–08:00" },
    eta: "2026-08-21 07:10",
    etaLabel: "Fri 07:10",
    etaSource: "TMS plan",
  },
  {
    loadId: "LD-ONT-260821-0152",
    customer: "Walmart",
    site: "DC 6031, Mira Loma, CA",
    orderRef: "SO-710288",
    carrier: BLFT,
    origin: "DC-ONT",
    stage: 1,
    times: ["Wed 10:25", "Thu 07:15"],
    window: { from: "2026-08-21 09:00", to: "2026-08-21 11:00", label: "Fri 09:00–11:00" },
    eta: "2026-08-21 09:40",
    etaLabel: "Fri 09:40",
    etaSource: "TMS plan",
  },
  {
    loadId: "LD-ONT-260821-0158",
    customer: "Costco",
    site: "Depot #C-114, City of Industry, CA",
    orderRef: "SO-710273",
    carrier: BLFT,
    origin: "DC-ONT",
    stage: 2,
    times: ["Wed 12:40", "Thu 03:50", "Thu 07:20"],
    window: { from: "2026-08-21 06:00", to: "2026-08-21 08:00", label: "Fri 06:00–08:00" },
    eta: "2026-08-21 06:20",
    etaLabel: "Fri 06:20",
    etaSource: "TMS plan",
  },

  /* ---------- in transit ---------- */
  {
    loadId: "LD-ONT-260820-0102",
    caseId: "MR-58212",
    customer: "Target · Kroger · Costco",
    site: "Milk run, 3 stops",
    orderRef: "3 orders",
    carrier: BLFT,
    origin: "DC-ONT",
    stage: 4,
    times: ["Wed 14:10", "Thu 04:05", "Thu 06:10", "Thu 08:05", "Thu 08:18"],
    window: { from: "2026-08-20 07:00", to: "2026-08-20 08:00", label: "Stop 1 · 07:00–08:00" },
    eta: "2026-08-20 08:30",
    etaLabel: "Stop 1 · 08:30",
    etaSource: "Agent ETA",
    predict: {
      date: "2026-08-20",
      pingAt: "08:18",
      position: "I-10 W near Fontana",
      hosLeftMin: 580,
      legs: [
        { stop: "T", customer: "Target", site: "DC T-0553, Fontana", windowFrom: "07:00", windowTo: "08:00", miles: 6, driveMin: 10, trafficMin: 2, trafficNote: "Merge at Sierra Ave", dwellMin: 0, dwellNote: "No stop before", earlyMin: 4, lateMin: 4, fourKitesPeta: "08:30" },
        { stop: "K", customer: "Kroger", site: "DC Riverside", windowFrom: "08:30", windowTo: "09:30", miles: 21, driveMin: 40, trafficMin: 2, trafficNote: "Merge at Sierra Ave", dwellMin: 45, dwellNote: "Unload at Target, 90-day p50", earlyMin: 8, lateMin: 12 },
        { stop: "C", customer: "Costco", site: "Depot #C-114, City of Industry", windowFrom: "10:00", windowTo: "11:00", miles: 59, driveMin: 90, trafficMin: 2, trafficNote: "Merge at Sierra Ave", dwellMin: 90, dwellNote: "Unload at Target and Kroger, 90-day p50", earlyMin: 12, lateMin: 18 },
      ],
    },
  },
  {
    loadId: "LD-PHX-260820-0077",
    caseId: "SHP-58196",
    customer: "Walmart",
    site: "DC 7035, Fontana, CA",
    orderRef: "SO-710255",
    carrier: SMLG,
    origin: "DC-PHX",
    stage: 4,
    times: ["Tue 16:30", "Wed 22:10", "Thu 02:40", "Thu 04:05", "Thu 08:12"],
    window: { from: "2026-08-20 13:00", to: "2026-08-20 15:00", label: "Today 13:00–15:00" },
    eta: "2026-08-20 14:30",
    etaLabel: "14:30",
    etaSource: "Agent ETA",
    predict: {
      date: "2026-08-20",
      pingAt: "08:12",
      position: "I-10 W near Quartzsite, AZ",
      hosLeftMin: 110,
      legs: [
        { stop: "1", customer: "Walmart", site: "DC 7035, Fontana", windowFrom: "13:00", windowTo: "15:00", miles: 267, driveMin: 308, trafficMin: 40, trafficNote: "Slowdown on I-10 near Banning", dwellMin: 30, dwellNote: "HOS 30-min break due before arrival", earlyMin: 10, lateMin: 60, fourKitesPeta: "14:00" },
      ],
    },
  },
  {
    loadId: "LD-RNO-260820-0040",
    caseId: "SHP-58203",
    customer: "Kroger",
    site: "DC 018, Portland, OR",
    orderRef: "SO-710257",
    carrier: PCCR,
    origin: "DC-RNO",
    stage: 4,
    times: ["Tue 11:00", "Wed 20:15", "Wed 23:30", "Thu 01:10", "Thu 07:55"],
    window: { from: "2026-08-20 16:00", to: "2026-08-20 18:00", label: "Today 16:00–18:00" },
    eta: "2026-08-20 16:30",
    etaLabel: "16:30",
    etaSource: "Agent ETA",
    predict: {
      date: "2026-08-20",
      pingAt: "07:55",
      position: "I-5 N near Redding, CA",
      hosLeftMin: 420,
      legs: [
        { stop: "1", customer: "Kroger", site: "DC 018, Portland", windowFrom: "16:00", windowTo: "18:00", miles: 405, driveMin: 467, trafficMin: 8, trafficNote: "Road works near Medford", dwellMin: 40, dwellNote: "Fuel and 30-min HOS break", earlyMin: 15, lateMin: 35 },
      ],
    },
  },
  {
    loadId: "LD-ONT-260820-0110",
    customer: "Walmart",
    site: "DC 6031, Mira Loma, CA",
    orderRef: "SO-710274",
    carrier: BLFT,
    origin: "DC-ONT",
    stage: 4,
    times: ["Wed 13:15", "Thu 04:20", "Thu 06:45", "Thu 07:58", "Thu 08:10"],
    window: { from: "2026-08-20 08:00", to: "2026-08-20 10:00", label: "Today 08:00–10:00" },
    eta: "2026-08-20 08:25",
    etaLabel: "08:25",
    etaSource: "FourKites PETA",
    predict: {
      date: "2026-08-20",
      pingAt: "08:10",
      position: "CA-60 W near Mira Loma",
      hosLeftMin: 640,
      legs: [
        { stop: "1", customer: "Walmart", site: "DC 6031, Mira Loma", windowFrom: "08:00", windowTo: "10:00", miles: 9, driveMin: 15, trafficMin: 0, trafficNote: "Clear", dwellMin: 0, dwellNote: "No stop before", earlyMin: 3, lateMin: 5, fourKitesPeta: "08:25" },
      ],
    },
  },
  {
    loadId: "LD-ONT-260820-0114",
    customer: "Target",
    site: "DC T-0553, Fontana, CA",
    orderRef: "SO-710275",
    carrier: BLFT,
    origin: "DC-ONT",
    stage: 3,
    times: ["Wed 13:40", "Thu 05:05", "Thu 07:30", "Thu 08:14"],
    window: { from: "2026-08-20 09:00", to: "2026-08-20 11:00", label: "Today 09:00–11:00" },
    eta: "2026-08-20 08:40",
    etaLabel: "08:40",
    etaSource: "FourKites PETA",
    predict: {
      date: "2026-08-20",
      pingAt: "08:16",
      position: "Gated out of DC-ONT",
      hosLeftMin: 660,
      legs: [
        { stop: "1", customer: "Target", site: "DC T-0553, Fontana", windowFrom: "09:00", windowTo: "11:00", miles: 12, driveMin: 22, trafficMin: 2, trafficNote: "Merge at Sierra Ave", dwellMin: 0, dwellNote: "No stop before", earlyMin: 4, lateMin: 6, fourKitesPeta: "08:40" },
      ],
    },
  },
  {
    loadId: "LD-DAL-260820-0091",
    customer: "Kroger",
    site: "DC Houston, TX",
    orderRef: "SO-710276",
    carrier: SMLG,
    origin: "DC-DAL",
    stage: 4,
    times: ["Wed 09:30", "Wed 23:50", "Thu 03:15", "Thu 05:20", "Thu 08:05"],
    window: { from: "2026-08-20 10:00", to: "2026-08-20 12:00", label: "Today 10:00–12:00" },
    eta: "2026-08-20 11:05",
    etaLabel: "11:05",
    etaSource: "FourKites PETA",
    predict: {
      date: "2026-08-20",
      pingAt: "08:05",
      position: "I-45 S near Centerville, TX",
      hosLeftMin: 470,
      legs: [
        { stop: "1", customer: "Kroger", site: "DC Houston", windowFrom: "10:00", windowTo: "12:00", miles: 158, driveMin: 172, trafficMin: 8, trafficNote: "Rush hour north of Houston", dwellMin: 0, dwellNote: "No stop before", earlyMin: 8, lateMin: 15, fourKitesPeta: "11:05" },
      ],
    },
  },
  {
    loadId: "LD-SAC-260820-0052",
    customer: "Costco",
    site: "Depot C-207, Tracy, CA",
    orderRef: "SO-710277",
    carrier: BLFT,
    origin: "DC-SAC",
    stage: 4,
    times: ["Wed 12:10", "Thu 03:30", "Thu 06:40", "Thu 07:52", "Thu 08:02"],
    window: { from: "2026-08-20 08:00", to: "2026-08-20 10:00", label: "Today 08:00–10:00" },
    eta: "2026-08-20 09:10",
    etaLabel: "09:10",
    etaSource: "FourKites PETA",
    predict: {
      date: "2026-08-20",
      pingAt: "08:02",
      position: "I-5 S near Elk Grove",
      hosLeftMin: 600,
      legs: [
        { stop: "1", customer: "Costco", site: "Depot C-207, Tracy", windowFrom: "08:00", windowTo: "10:00", miles: 52, driveMin: 60, trafficMin: 8, trafficNote: "Slow traffic near Stockton", dwellMin: 0, dwellNote: "No stop before", earlyMin: 6, lateMin: 10, fourKitesPeta: "09:10" },
      ],
    },
  },
  {
    loadId: "LD-RNO-260820-0035",
    customer: "Target",
    site: "DC T-0579, Woodland, CA",
    orderRef: "SO-710278",
    carrier: PCCR,
    origin: "DC-RNO",
    stage: 4,
    times: ["Wed 10:45", "Thu 02:20", "Thu 05:30", "Thu 07:35", "Thu 08:10"],
    window: { from: "2026-08-20 10:00", to: "2026-08-20 12:00", label: "Today 10:00–12:00" },
    eta: "2026-08-20 10:25",
    etaLabel: "10:25",
    etaSource: "FourKites PETA",
    predict: {
      date: "2026-08-20",
      pingAt: "08:10",
      position: "I-80 W near Truckee",
      hosLeftMin: 560,
      legs: [
        { stop: "1", customer: "Target", site: "DC T-0579, Woodland", windowFrom: "10:00", windowTo: "12:00", miles: 118, driveMin: 129, trafficMin: 6, trafficNote: "Chain control lifted at Donner", dwellMin: 0, dwellNote: "No stop before", earlyMin: 8, lateMin: 14, fourKitesPeta: "10:25" },
      ],
    },
  },

  /* ---------- delivered today ---------- */
  {
    loadId: "LD-ONT-260820-0098",
    customer: "Costco",
    site: "Depot #C-114, City of Industry, CA",
    orderRef: "SO-710279",
    carrier: BLFT,
    origin: "DC-ONT",
    stage: 5,
    times: ["Wed 11:30", "Wed 22:40", "Thu 03:55", "Thu 05:20", "Thu 05:22", "Thu 06:12"],
    window: { from: "2026-08-20 06:00", to: "2026-08-20 08:00", label: "Today 06:00–08:00" },
    eta: "2026-08-20 06:12",
    etaLabel: "06:12",
    etaSource: "POD",
  },
  {
    loadId: "LD-ONT-260820-0095",
    customer: "Walmart",
    site: "DC 7035, Fontana, CA",
    orderRef: "SO-710280",
    carrier: BLFT,
    origin: "DC-ONT",
    stage: 5,
    times: ["Wed 10:50", "Wed 21:30", "Thu 03:10", "Thu 05:15", "Thu 05:17", "Thu 05:48"],
    window: { from: "2026-08-20 05:00", to: "2026-08-20 07:00", label: "Today 05:00–07:00" },
    eta: "2026-08-20 05:48",
    etaLabel: "05:48",
    etaSource: "POD",
  },
  {
    loadId: "LD-DAL-260819-0201",
    customer: "Kroger",
    site: "DC 024, Forest Park, GA",
    orderRef: "SO-710266",
    carrier: SMLG,
    origin: "DC-DAL",
    stage: 5,
    times: ["Mon 14:20", "Tue 18:10", "Tue 22:45", "Wed 05:30", "Wed 05:35", "Thu 07:30"],
    window: { from: "2026-08-20 07:00", to: "2026-08-20 09:00", label: "Today 07:00–09:00" },
    eta: "2026-08-20 07:30",
    etaLabel: "07:30",
    etaSource: "POD",
  },
  {
    loadId: "LD-ONT-260820-0089",
    customer: "Target",
    site: "DC T-0553, Fontana, CA",
    orderRef: "SO-710284",
    carrier: BLFT,
    origin: "DC-ONT",
    stage: 5,
    times: ["Wed 09:40", "Wed 23:15", "Thu 04:35", "Thu 06:20", "Thu 06:22", "Thu 06:55"],
    window: { from: "2026-08-20 06:00", to: "2026-08-20 08:00", label: "Today 06:00–08:00" },
    eta: "2026-08-20 06:55",
    etaLabel: "06:55",
    etaSource: "POD",
  },
  {
    loadId: "LD-RNO-260819-0188",
    customer: "Walmart",
    site: "RDC 6094, Buckeye, AZ",
    orderRef: "SO-710267",
    carrier: PCCR,
    origin: "DC-RNO",
    stage: 5,
    times: ["Mon 16:05", "Tue 20:30", "Wed 01:50", "Wed 06:40", "Wed 06:45", "Thu 07:52"],
    window: { from: "2026-08-20 06:00", to: "2026-08-20 07:00", label: "Today 06:00–07:00" },
    eta: "2026-08-20 07:52",
    etaLabel: "07:52",
    etaSource: "POD",
  },
  {
    loadId: "LD-SAC-260820-0047",
    customer: "Costco",
    site: "Depot C-207, Tracy, CA",
    orderRef: "SO-710285",
    carrier: BLFT,
    origin: "DC-SAC",
    stage: 5,
    times: ["Wed 10:15", "Wed 22:05", "Thu 03:40", "Thu 05:50", "Thu 05:52", "Thu 07:05"],
    window: { from: "2026-08-20 06:00", to: "2026-08-20 08:00", label: "Today 06:00–08:00" },
    eta: "2026-08-20 07:05",
    etaLabel: "07:05",
    etaSource: "POD",
  },
  {
    loadId: "LD-DAL-260820-0084",
    customer: "Target",
    site: "DC T-3809, Midway, GA",
    orderRef: "SO-710286",
    carrier: SMLG,
    origin: "DC-DAL",
    stage: 5,
    times: ["Mon 13:30", "Tue 17:20", "Tue 21:40", "Wed 04:10", "Wed 04:15", "Thu 08:02"],
    window: { from: "2026-08-20 07:00", to: "2026-08-20 09:00", label: "Today 07:00–09:00" },
    eta: "2026-08-20 08:02",
    etaLabel: "08:02",
    etaSource: "POD",
  },
];

/* ------------------------------------------------------------------ *
 * OTIF D forecast · orders scheduled to deliver in the next 7 days
 * ------------------------------------------------------------------ */

export const OTIF_FORECAST = {
  horizonDays: 7,
  scheduledOrders: 980,
  /** Misses the lane history predicts on orders outside today's risk board. */
  baselineMisses: 113,
  targetPct: 92,
};
