/**
 * Loss-rate assumptions per aging bucket, adjusted for current and expected
 * risk conditions. The provision itself is DERIVED in lib/selectors.ts from
 * the open invoice set — paying an invoice moves the provision.
 */
export interface LossRateBand {
  bucket: "Not yet due" | "1-30 days late" | "31-60 days late" | "61-90 days late" | "Over 90 days late";
  minDays: number;
  maxDays: number | null;
  lossRate: number;
  rationale: string;
}

export const lossRateBands: LossRateBand[] = [
  {
    bucket: "Not yet due",
    minDays: -3650,
    maxDays: 0,
    lossRate: 0.01,
    rationale: "Base expected-loss rate on current receivables.",
  },
  {
    bucket: "1-30 days late",
    minDays: 1,
    maxDays: 30,
    lossRate: 0.03,
    rationale: "Slightly elevated risk once an invoice slips past due.",
  },
  {
    bucket: "31-60 days late",
    minDays: 31,
    maxDays: 60,
    lossRate: 0.08,
    rationale: "Collection success falls sharply in the second month.",
  },
  {
    bucket: "61-90 days late",
    minDays: 61,
    maxDays: 90,
    lossRate: 0.2,
    rationale: "Historical recovery below 80% at this age.",
  },
  {
    bucket: "Over 90 days late",
    minDays: 91,
    maxDays: null,
    lossRate: 0.5,
    rationale: "Half of balances this old are historically not recovered.",
  },
];

export interface SpecificReserve {
  invoiceId: string;
  customerName: string;
  amount: number;
  reason: string;
}

export const specificReserves: SpecificReserve[] = [
  {
    invoiceId: "INV-12343",
    customerName: "Woolworths Group",
    amount: 28000,
    reason:
      "Balance is disputed and in legal review — reserved in full until the dispute resolves.",
  },
];

/** Allowance balance already on the books before this month's review. */
export const existingAllowanceBalance = 42500;

export interface ProvisionApproval {
  approver: string;
  role: string;
  status: "Awaiting approval" | "Approved";
}

export const provisionApproval: ProvisionApproval = {
  approver: "L. Chen",
  role: "Controller",
  status: "Awaiting approval",
};

/**
 * Write-off approval authority: write-offs against the reserve up to this
 * amount need Controller approval; anything above it also needs CFO approval.
 */
export const writeOffControllerLimit = 25000;
