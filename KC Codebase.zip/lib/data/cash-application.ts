/**
 * Cash application: incoming customer payments, the remittance advice that
 * came with each one, and how AI resolved every line against SAP.
 *
 * Scenario 6 (Walmart, PAY-32001) is the demo case: one payment covering
 * invoices, credits and deductions together, where the retailer's own
 * document numbers don't match SAP directly. The four category totals below
 * are fixed by design and must keep summing to the payment amount:
 *
 *   Matched & ready to clear   $3,090,000   (invoices)
 *   Valid credits applied         $65,000
 *   Deductions opened as cases     $38,000
 *   Unidentified residual           $7,000
 *   ------------------------------------------
 *   Incoming payment            $3,200,000
 *
 * Most of the 164 remittance items are represented by an aggregate row
 * ("141 more invoices...") rather than listed individually — a production
 * remittance workbench shows the lines that need a human's attention and
 * rolls the rest into a batch total, which is also why `aggregateCount`
 * exists: it lets the queue report a true document count (164) without the
 * page rendering 164 rows.
 */

/**
 * The dollar variance allowed on an amount-date, combined-shipment or
 * aggregate match before it drops out of auto-post and needs a human to
 * clear it — separate from the 85% confidence threshold below, which scores
 * how sure the match is, not how far off the money is.
 */
export const AMOUNT_MATCH_TOLERANCE_USD = 250;

export type RemittanceLineType = "invoice" | "credit" | "deduction" | "unidentified";

/** How the AI resolved an invoice or credit line to a SAP document. */
export type MatchStrategy =
  | "reference"
  | "amount-date"
  | "combined-shipment"
  | "credit-memo";

/** A document the AI weighed for the unidentified residual and set aside. */
export interface ResidualCandidate {
  label: string;
  detail: string;
  confidence: number;
}

export interface RemittanceLine {
  lineId: string;
  /** The retailer's own document reference, as printed on the remittance. */
  customerRef: string;
  /** The SAP document this was matched to. Absent for the unidentified line. */
  sapDocument?: string;
  type: RemittanceLineType;
  amount: number;
  /** AI match confidence, 0-100. */
  confidence: number;
  /** Short label for the table: "Clear", "Apply credit", "Open case", "Review". */
  decision: string;
  recommendedAction: string;
  evidence: string[];
  /** For deductions: the reason the AI attributes the short-pay to. */
  reasonCode?: string;
  /** For deductions: the system the case should route to. */
  caseSystem?: string;
  /** For invoices/credits: how the AI resolved the line to a SAP document. */
  matchStrategy?: MatchStrategy;
  /**
   * For amount-date, combined-shipment or aggregate matches: the dollar
   * variance between the remittance amount and the SAP open item, measured
   * against the $250-per-line amount-matching tolerance. Populated whenever
   * the match relied on more than an exact reference hit, so the tolerance
   * this scenario calls for has a concrete number behind it, not just a
   * confidence score.
   */
  toleranceNote?: string;
  /** For deductions: the team that owns the case once opened. */
  routeTeam?: string;
  /** For deductions: SLA to resolve the case, in business days. */
  slaDays?: number;
  /** For the unidentified line: documents the AI weighed and set aside. */
  candidates?: ResidualCandidate[];
  /** For combined-shipment matches: the SAP invoices one remittance line clears. */
  splitInto?: { sapDocument: string; amount: number }[];
  /** For deductions the AI won't open unaided: what a person has to judge. */
  reviewReason?: string;
  /** This row stands in for several identical-outcome documents. */
  isAggregate?: boolean;
  aggregateCount?: number;
}

/**
 * Which workbench a payment drives. The default remittance flow (Ingest →
 * Match → Resolve → Post) covers PAY-32001. The two scenario flows below are
 * genuinely different problems, so they have their own tailored workbenches:
 *
 *  - "unidentified-payer" — cash arrived before the remittance and the payer
 *    is a treasury centre, not the customer (Scenario 7).
 *  - "cross-entity" — one receipt settles invoices across two K-C legal
 *    entities in two currencies (Scenario 8).
 */
export type CashPaymentKind =
  | "remittance"
  | "unidentified-payer"
  | "cross-entity";

/** One customer account the AI believes a treasury-centre payment belongs to. */
export interface PayerCandidateAccount {
  /** SAP sold-to / account number. */
  account: string;
  /** Human-readable sold-to name. */
  soldTo: string;
  openInvoices: number;
  openValue: number;
  /** Share of the receipt the AI attributes to this account, 0-100. */
  share: number;
}

/** Scenario 7 — cash before remittance, payer is not the customer. */
export interface UnidentifiedPayerCase {
  /** The paying party on the bank statement (a treasury centre, not a sold-to). */
  payerName: string;
  /** The shortened, partial reference the bank narrative carried. */
  bankNarrative: string;
  /** Payer-to-customer match confidence, 0-100. Below auto-post → assisted review. */
  matchConfidence: number;
  /** Candidate open invoices identified across the linked accounts. */
  candidateInvoices: number;
  candidateAccounts: PayerCandidateAccount[];
  /** How the AI worked out the likely accounts. */
  reasoning: string[];
  /** Where the remittance request is raised. */
  requestSystem: string;
  /** Matching engine that reprocesses the receipt once the remittance lands. */
  matchEngine: string;
  /** Document-reading engine used on the remittance when it arrives. */
  parseEngine: string;
  /** What happens once the remittance is received and the receipt reprocesses. */
  reprocess: {
    remittanceItems: number;
    clearedValue: number;
    accountsCleared: string;
  };
}

/** One legal entity's slice of a cross-entity receipt (Scenario 8). */
export interface EntityLeg {
  entity: string;
  companyCode: string;
  erp: string;
  currency: "USD" | "EUR";
  /** Open value in this leg's own billing currency. */
  nativeValue: number;
  /** EUR-equivalent of that value, so the legs sum back to the EUR receipt. */
  eurValue: number;
  invoices: number;
  /** Whether this leg clears automatically or needs cross-entity approval. */
  action: "clear-now" | "approve-transfer";
}

/** Scenario 8 — one payment across two entities and two currencies. */
export interface CrossEntityCase {
  payerGroup: string;
  /** The company code / bank account the funds actually landed in. */
  bankEntity: string;
  legs: EntityLeg[];
  /** Expected FX + bank-charge residual, in EUR. */
  fxDifference: number;
  fxNote: string;
  /** How the paying group was tied to the sold-to accounts. */
  hierarchy: string[];
  /** Who signs off the cross-entity transfer. */
  approvalRoute: string;
  matchEngine: string;
}

export interface CashPayment {
  paymentId: string;
  customer: string;
  receivedDate: string;
  amount: number;
  /** True count of remittance lines behind this payment (invoices + credits + deductions + unidentified). */
  remittanceItemCount: number;
  erpSystems: string[];
  lines: RemittanceLine[];
  status: "Review" | "Cleared";
  postedDate?: string;
  /** Which workbench flow this payment drives. Defaults to the remittance flow. */
  kind?: CashPaymentKind;
  /** Settlement currency of the receipt. Defaults to USD. */
  currency?: "USD" | "EUR";
  /** USD-equivalent of a non-USD receipt, for book-wide aggregation only. */
  usdEquivalent?: number;
  /** Scenario 7 payload. */
  unidentifiedPayer?: UnidentifiedPayerCase;
  /** Scenario 8 payload. */
  crossEntity?: CrossEntityCase;
}

export const cashPayments: CashPayment[] = [
  {
    paymentId: "PAY-32001",
    customer: "Walmart Inc.",
    receivedDate: "2026-09-24",
    amount: 3_200_000,
    remittanceItemCount: 164,
    erpSystems: ["S/4HANA", "ECC"],
    status: "Review",
    lines: [
      // ---- Invoices: 5 sample lines + 1 aggregate = $3,090,000 -----------
      {
        lineId: "RL-1",
        customerRef: "WM-88219",
        sapDocument: "9000845621",
        type: "invoice",
        amount: 84_200,
        confidence: 99,
        decision: "Clear",
        recommendedAction: "Clear against SAP 9000845621",
        matchStrategy: "amount-date",
        evidence: [
          "Customer: Walmart Inc. — exact match",
          "Amount: $84,200 — exact match to SAP open item",
          "Invoice date: Sep 18 — within remittance date range",
          "Shipment reference SH-88219 matched to the delivery cited on the invoice",
          "Direct invoice number reference: not present on the remittance",
        ],
      },
      {
        lineId: "RL-2",
        customerRef: "WM-88231",
        sapDocument: "9000845712",
        type: "invoice",
        amount: 121_400,
        confidence: 97,
        decision: "Clear",
        recommendedAction: "Clear against SAP 9000845712",
        matchStrategy: "reference",
        evidence: [
          "Customer: Walmart Inc. — exact match",
          "Amount: $121,400 — exact match to SAP open item",
          "Invoice date: Sep 19 — within remittance date range",
          "PO reference PO-44928 matched to the order behind the invoice",
        ],
      },
      {
        lineId: "RL-3",
        customerRef: "WM-88244",
        sapDocument: "9000845820",
        type: "invoice",
        amount: 96_800,
        confidence: 98,
        decision: "Clear",
        recommendedAction: "Clear against SAP 9000845820",
        matchStrategy: "amount-date",
        evidence: [
          "Customer: Walmart Inc. — exact match",
          "Amount: $96,800 — exact match to SAP open item",
          "Shipment reference SH-88244 matched to the delivery cited on the invoice",
        ],
      },
      {
        lineId: "RL-4",
        customerRef: "WM-88266",
        sapDocument: "9000845901",
        type: "invoice",
        amount: 142_300,
        confidence: 96,
        decision: "Clear",
        recommendedAction: "Clear against SAP 9000845901",
        matchStrategy: "combined-shipment",
        toleranceNote:
          "$142,300 combined shipment vs. $142,180 across the two SAP invoices — $120 variance, within the $250 amount-matching tolerance",
        splitInto: [
          { sapDocument: "9000845901", amount: 86_450 },
          { sapDocument: "9000845902", amount: 55_730 },
        ],
        evidence: [
          "Customer: Walmart Inc. — exact match",
          "Retailer reference is a combined shipment number covering two SAP invoices; both fall within tolerance",
          "Combined amount is $120 off the two invoices' total — inside the $250 per-line tolerance, so both post",
        ],
      },
      {
        lineId: "RL-5",
        customerRef: "WM-88279",
        sapDocument: "9000846013",
        type: "invoice",
        amount: 77_900,
        confidence: 99,
        decision: "Clear",
        recommendedAction: "Clear against SAP 9000846013",
        matchStrategy: "amount-date",
        evidence: [
          "Customer: Walmart Inc. — exact match",
          "Amount: $77,900 — exact match to SAP open item",
          "Invoice date: Sep 20 — within remittance date range",
        ],
      },
      {
        lineId: "RL-6",
        customerRef: "141 more Walmart invoices",
        type: "invoice",
        amount: 2_567_400,
        confidence: 97,
        decision: "Clear",
        recommendedAction: "Clear in batch against 140 SAP open items",
        matchStrategy: "amount-date",
        toleranceNote:
          "Average variance $38 per line, largest single variance $210 — all within the $250 amount-matching tolerance",
        evidence: [
          "Each line matched on customer, amount and date within tolerance",
          "Reference format is the retailer's shipment number in every case, not the SAP invoice number",
          "Average match confidence 97% — all above the 85% auto-post threshold",
          "Average amount variance $38, largest $210 — all within the $250 tolerance",
        ],
        isAggregate: true,
        aggregateCount: 140,
      },
      // ---- Credits: 3 sample lines + 1 aggregate = $65,000 --------------
      {
        lineId: "RL-7",
        customerRef: "CR-19382",
        sapDocument: "710002193",
        type: "credit",
        amount: 15_000,
        confidence: 99,
        decision: "Apply credit",
        recommendedAction: "Apply against SAP credit memo 710002193",
        matchStrategy: "credit-memo",
        evidence: [
          "Customer: Walmart Inc. — exact match",
          "Amount: $15,000 — exact match to an approved, open credit memo",
          "Credit memo status: Approved, issued Aug 29",
        ],
      },
      {
        lineId: "RL-8",
        customerRef: "CR-19407",
        sapDocument: "710002240",
        type: "credit",
        amount: 22_500,
        confidence: 98,
        decision: "Apply credit",
        recommendedAction: "Apply against SAP credit memo 710002240",
        matchStrategy: "credit-memo",
        evidence: [
          "Customer: Walmart Inc. — exact match",
          "Amount: $22,500 — exact match to an approved, open credit memo",
        ],
      },
      {
        lineId: "RL-9",
        customerRef: "CR-19431",
        sapDocument: "710002298",
        type: "credit",
        amount: 9_800,
        confidence: 99,
        decision: "Apply credit",
        recommendedAction: "Apply against SAP credit memo 710002298",
        matchStrategy: "credit-memo",
        evidence: [
          "Customer: Walmart Inc. — exact match",
          "Amount: $9,800 — exact match to an approved, open credit memo",
        ],
      },
      {
        lineId: "RL-10",
        customerRef: "8 more credit memos",
        type: "credit",
        amount: 17_700,
        confidence: 98,
        decision: "Apply credit",
        recommendedAction: "Apply in batch against 8 approved SAP credit memos",
        matchStrategy: "credit-memo",
        evidence: [
          "Each credit memo is Approved and open in SAP",
          "Amount matches exactly in every case",
        ],
        isAggregate: true,
        aggregateCount: 8,
      },
      // ---- Deductions: all 7 lines, listed individually = $38,000 ------
      {
        lineId: "RL-11",
        customerRef: "SH-28821",
        type: "deduction",
        amount: 8_000,
        confidence: 94,
        decision: "Open case",
        recommendedAction: "Open a deduction case and route to Trade Finance",
        reasonCode: "Promotion deduction",
        caseSystem: "VISTEX",
        routeTeam: "Trade Finance",
        slaDays: 5,
        evidence: [
          "Short-paid against invoice 9000845990 by $8,000",
          "Promotion PR-3821 found active in VISTEX for this customer and period",
          "Deducted amount matches the promotion's approved funding rate",
        ],
      },
      {
        lineId: "RL-12",
        customerRef: "SH-28830",
        type: "deduction",
        amount: 6_200,
        confidence: 91,
        decision: "Open case",
        recommendedAction: "Open a deduction case and route to Transportation",
        reasonCode: "Freight deduction",
        caseSystem: "CAS",
        routeTeam: "Transportation",
        slaDays: 7,
        evidence: [
          "Short-paid against invoice 9000846041 by $6,200",
          "Retailer cites a freight allowance not reflected on the invoice",
          "Freight & tax record shows a rate variance in the same range",
        ],
      },
      {
        lineId: "RL-13",
        customerRef: "SH-28844",
        type: "deduction",
        amount: 5_500,
        confidence: 88,
        decision: "Open case",
        recommendedAction: "Open a deduction case and route to Claims",
        reasonCode: "Damaged goods claim",
        caseSystem: "ServiceNow",
        routeTeam: "Claims",
        slaDays: 10,
        reviewReason:
          "Damage claim cited, but no proof-of-delivery exception is on file — open the case with a POD request, or dispute it back to Walmart.",
        evidence: [
          "Short-paid against invoice 9000846078 by $5,500",
          "Retailer's remittance note cites a damage claim reference",
          "No matching proof-of-delivery exception on file yet — case will request one",
        ],
      },
      {
        lineId: "RL-14",
        customerRef: "SH-28855",
        type: "deduction",
        amount: 4_800,
        confidence: 92,
        decision: "Open case",
        recommendedAction: "Open a deduction case and route to Sales & Trade Finance",
        reasonCode: "Pricing dispute",
        caseSystem: "PricerX",
        routeTeam: "Sales & Trade Finance",
        slaDays: 5,
        evidence: [
          "Short-paid against invoice 9000846102 by $4,800",
          "Retailer's remittance price is below the PricerX-approved price by the same amount",
        ],
      },
      {
        lineId: "RL-15",
        customerRef: "SH-28866",
        type: "deduction",
        amount: 8_100,
        confidence: 90,
        decision: "Open case",
        recommendedAction: "Open a deduction case and route to Transportation",
        reasonCode: "Short ship",
        caseSystem: "CAS",
        routeTeam: "Transportation",
        slaDays: 7,
        evidence: [
          "Short-paid against invoice 9000846130 by $8,100",
          "Delivery record shows fewer units received than invoiced",
        ],
      },
      {
        lineId: "RL-16",
        customerRef: "SH-28877",
        type: "deduction",
        amount: 3_900,
        confidence: 93,
        decision: "Open case",
        recommendedAction: "Open a deduction case and route to Trade Finance",
        reasonCode: "Promotion deduction",
        caseSystem: "PROMAX",
        routeTeam: "Trade Finance",
        slaDays: 5,
        evidence: [
          "Short-paid against invoice 9000846155 by $3,900",
          "Promotion PR-4012 found active in PROMAX for this customer and period",
        ],
      },
      {
        lineId: "RL-17",
        customerRef: "SH-28888",
        type: "deduction",
        amount: 1_500,
        confidence: 89,
        decision: "Open case",
        recommendedAction: "Open a deduction case and route to Compliance",
        reasonCode: "Compliance chargeback",
        caseSystem: "ServiceNow",
        routeTeam: "Compliance",
        slaDays: 14,
        reviewReason:
          "Routing-guide fine with no violation notice attached — open the case and request the notice before Compliance validates it.",
        evidence: [
          "Short-paid against invoice 9000846188 by $1,500",
          "Retailer cites a routing-guide compliance violation",
        ],
      },
      // ---- Unidentified: 1 line = $7,000 ---------------------------------
      {
        lineId: "RL-18",
        customerRef: "WM-99281",
        type: "unidentified",
        amount: 7_000,
        confidence: 31,
        decision: "On account",
        recommendedAction: "Post on account to Walmart (reason UNID) and chase the remittance",
        evidence: [
          "No open SAP invoice, credit memo or deduction reason matches this amount",
          "Customer reference does not resolve to a known document",
          "Confidence 31% — below the 85% auto-post threshold",
        ],
        candidates: [
          {
            label: "On-account credit 710002401",
            detail:
              "Amount matches to the dollar, but the credit belongs to a different sold-to (Walmart de México) — posting it here would misstate two customers.",
            confidence: 44,
          },
          {
            label: "Open invoice 9000846203",
            detail:
              "Within $150 of an open item, but the invoice date is 41 days outside this remittance's date range and no shipment reference ties them together.",
            confidence: 38,
          },
          {
            label: "Freight deduction reason",
            detail:
              "Amount is plausible for a freight allowance, but no freight & tax variance record exists to support a deduction of this size.",
            confidence: 22,
          },
        ],
      },
    ],
  },
  {
    // ---- Scenario 7 — cash arrives before the remittance ----------------
    paymentId: "PAY-32044",
    customer: "Treasury payer — unmatched",
    receivedDate: "2026-09-24",
    amount: 780_000,
    currency: "USD",
    kind: "unidentified-payer",
    remittanceItemCount: 0,
    erpSystems: ["S/4HANA"],
    status: "Review",
    lines: [],
    unidentifiedPayer: {
      payerName: "Albertsons Treasury Centre",
      bankNarrative: "ALB TRSY CTR // REF 4471… (truncated by bank)",
      matchConfidence: 88,
      candidateInvoices: 23,
      candidateAccounts: [
        {
          account: "0004417",
          soldTo: "Albertsons — Safeway Division",
          openInvoices: 14,
          openValue: 512_000,
          share: 66,
        },
        {
          account: "0004422",
          soldTo: "Albertsons — Acme Markets",
          openInvoices: 9,
          openValue: 268_000,
          share: 34,
        },
      ],
      reasoning: [
        "Payer 'Albertsons Treasury Centre' is not a sold-to in the customer master — it is a paying party linked to the Albertsons group.",
        "Prior payment history shows this treasury centre settling invoices for both the Safeway and Acme divisions over the last six months.",
        "The truncated bank reference 4471 maps to the sold-to prefix 0004417 more closely than any other open account.",
        "Total open AR across the two linked accounts ($780,000) equals the receipt to the dollar.",
      ],
      requestSystem: "ServiceNow",
      matchEngine: "HighRadius",
      parseEngine: "Smart Parse",
      reprocess: {
        remittanceItems: 23,
        clearedValue: 780_000,
        accountsCleared: "Safeway Division & Acme Markets",
      },
    },
  },
  {
    // ---- Scenario 8 — one payment, two entities, two currencies ---------
    paymentId: "PAY-32050",
    customer: "Carrefour Group",
    receivedDate: "2026-09-24",
    amount: 1_050_000,
    currency: "EUR",
    usdEquivalent: 1_134_000,
    kind: "cross-entity",
    remittanceItemCount: 23,
    erpSystems: ["S/4HANA", "ECC"],
    status: "Review",
    lines: [],
    crossEntity: {
      payerGroup: "Carrefour Global Treasury",
      bankEntity: "K-C Europe GmbH · company code DE10",
      legs: [
        {
          entity: "K-C Europe GmbH",
          companyCode: "DE10",
          erp: "S/4HANA",
          currency: "EUR",
          nativeValue: 720_000,
          eurValue: 720_000,
          invoices: 14,
          action: "clear-now",
        },
        {
          entity: "K-C International LLC",
          companyCode: "US20",
          erp: "ECC",
          currency: "USD",
          nativeValue: 351_000,
          eurValue: 325_000,
          invoices: 9,
          action: "approve-transfer",
        },
      ],
      fxDifference: 5_000,
      fxNote:
        "EUR/USD value-date movement plus €1,180 of bank charges — inside the ±0.75% tolerance, so it is treated as an expected FX residual, not a genuine short payment.",
      hierarchy: [
        "Remittance is addressed to 'Carrefour Group', not to a sold-to that actually holds open invoices.",
        "Customer hierarchy confirms Carrefour Group is the parent of both paying accounts — verified against the master, not inferred from the name.",
        "Open items sit under two K-C legal entities: DE10 (billed EUR) and US20 (billed USD).",
      ],
      approvalRoute: "Regional AR Controller",
      matchEngine: "HighRadius",
    },
  },
  {
    paymentId: "PAY-31998",
    customer: "Kroger Co.",
    receivedDate: "2026-09-24",
    amount: 1_120_000,
    remittanceItemCount: 73,
    erpSystems: ["S/4HANA"],
    status: "Cleared",
    postedDate: "2026-09-24",
    lines: [],
  },
  {
    paymentId: "PAY-31984",
    customer: "Costco Wholesale",
    receivedDate: "2026-09-23",
    amount: 660_000,
    remittanceItemCount: 34,
    erpSystems: ["ECC"],
    status: "Cleared",
    postedDate: "2026-09-23",
    lines: [],
  },
  {
    paymentId: "PAY-31972",
    customer: "Target Corp.",
    receivedDate: "2026-09-22",
    amount: 860_000,
    remittanceItemCount: 51,
    erpSystems: ["S/4HANA"],
    status: "Cleared",
    postedDate: "2026-09-22",
    lines: [],
  },
];

export function findCashPayment(paymentId: string): CashPayment | undefined {
  return cashPayments.find((p) => p.paymentId === paymentId);
}

/* ------------------------------------------------------------------ *
 * Programme-level context — the same role PROGRAMME_SCOPE plays for
 * chargebacks. These describe the whole receivables book, not one payment,
 * and are displayed on the queue so the single demo case sits in context.
 * ------------------------------------------------------------------ */

export const CASH_APP_SCOPE =
  "North America retail receivables · 42 paying customers · ~$140M applied a month";

export interface CashAppMetric {
  label: string;
  value: string;
  detail: string;
  /** Direction that is good, for the small trend note. */
  trend?: string;
}

export const cashAppMetrics: CashAppMetric[] = [
  {
    label: "Auto-match rate",
    value: "96%",
    detail: "of remittance lines matched to a SAP document without a human",
    trend: "+4 pts vs last quarter",
  },
  {
    label: "Cash application accuracy",
    value: "99.4%",
    detail: "of applied amounts posted to the correct document, no reversal needed",
    trend: "+0.3 pts vs last quarter",
  },
  {
    label: "Touchless posting",
    value: "87%",
    detail: "of payments posted end-to-end with no manual line edits",
    trend: "+6 pts vs last quarter",
  },
  {
    label: "Avg. time to apply",
    value: "0.4 days",
    detail: "bank receipt to cleared in SAP",
    trend: "down from 1.9 days",
  },
  {
    label: "Unapplied cash",
    value: "$39K",
    detail: "held as residual across the book, aged below",
  },
  {
    label: "Residual rate",
    value: "0.6%",
    detail: "of cash received left as an unidentified residual after posting",
    trend: "down from 1.1%",
  },
];

export interface AgingBucket {
  bucket: string;
  amount: number;
  items: number;
  tone: "ok" | "watch" | "risk";
}

/**
 * Unapplied cash by age. This is book-wide context, not the PAY-32001 residual
 * — the $7,000 from the demo payment is the newest slice of the first bucket.
 */
export const unappliedAging: AgingBucket[] = [
  { bucket: "0–2 days", amount: 12_000, items: 3, tone: "ok" },
  { bucket: "3–7 days", amount: 14_500, items: 4, tone: "watch" },
  { bucket: "8–14 days", amount: 8_200, items: 2, tone: "watch" },
  { bucket: "15+ days", amount: 4_300, items: 1, tone: "risk" },
];
