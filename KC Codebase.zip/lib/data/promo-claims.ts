/**
 * Scenario 1 — Incomplete proof of promotion execution.
 *
 * A retailer short-pays an invoice and books the difference as a trade-promotion
 * deduction: an advertised feature and in-store display campaign. The claim
 * arrives against the RETAILER's internal event number, not our promotion ID,
 * and it bundles many stores, weeks and SKUs into one lump sum.
 *
 * The hard part is not "valid or invalid" — it is PARTIAL. The campaign ran, but
 * the supporting evidence proves execution for fewer stores than were billed,
 * some stores were never in the approved event, some activity falls outside the
 * promotional dates, and some SKUs are not eligible under the agreement. The AI
 * has to match the claim to the right promotion, gather proof of performance
 * from several sources, and split the claim into supported and unsupported
 * amounts a person can approve.
 *
 * Every figure below is a leaf. The selector sums the leaves, so the split can
 * never disagree with the claim it came from:
 *   supported + unsupported + needsInfo === claimed
 *   supportedStores + Σ exception stores === claimedStores
 */

export type PromoLineCategory =
  | "supported"
  | "not-on-event"
  | "out-of-window"
  | "ineligible-sku"
  | "needs-info";

export interface PromoClaimLine {
  lineId: string;
  category: PromoLineCategory;
  label: string;
  /** Dollars claimed on this slice of the deduction. */
  amount: number;
  /** Stores represented by this slice, where the slice is store-based. */
  stores: number;
  /** The single document or feed that settles this slice. */
  evidenceRef: string;
  finding: string;
}

/** One proof-of-performance source the agent gathers and reconciles. */
export interface ProofSource {
  sourceId: string;
  name: string;
  system: string;
  /** "supports" the execution, "partial" cover, or "gap" against the claim. */
  status: "supports" | "partial" | "gap";
  detail: string;
  /** A few words for the compact chip, e.g. "55 not on list". */
  metric?: string;
  /** Exception categories this source is the deciding evidence for. */
  flags?: PromoLineCategory[];
}

export interface PromoClaimCase {
  caseId: string;
  distributorId: string;
  customerName: string;
  /** The invoice the retailer paid short. */
  invoiceId: string;
  invoiceDate: string;
  invoiceAmount: number;
  remittanceId: string;
  receivedDate: string;
  amountPaid: number;
  /** What the retailer wrote on the remittance — an internal event number. */
  retailerEventRef: string;
  customerNote: string;
  routedTo: string;

  /** The promotion the deduction actually belongs to, once matched. */
  promotion: {
    promotionId: string;
    name: string;
    tpmSystem: string;
    windowStart: string;
    windowEnd: string;
    weeks: number;
    approvedStores: number;
    eligibleSkus: { sku: string; productName: string }[];
    tactic: string;
    /** Agreed allowance rate, printed on the agreement. */
    rateBasis: string;
    accrualId: string;
    accruedAmount: number;
  };

  /** Store counts, so the exception list reconciles to the billed footprint. */
  claimedStores: number;
  supportedStores: number;

  proofSources: ProofSource[];
  lines: PromoClaimLine[];

  /** The retailer response, drafted from the split and the exception list. */
  responseLetter: {
    letterRef: string;
    to: string;
    from: string;
    subjectTemplate: string;
    bodyTemplate: string;
  };
}

export const promoClaimCases: PromoClaimCase[] = [
  {
    caseId: "DED-PROMO-001",
    distributorId: "DIST-001",
    customerName: "Walmart Inc.",
    invoiceId: "INV-FC-8841",
    invoiceDate: "2026-04-24",
    invoiceAmount: 1_480_000,
    remittanceId: "RMT-9014",
    receivedDate: "2026-08-18",
    amountPaid: 1_230_000,
    retailerEventRef: "EVT-SPR26-4471",
    customerNote:
      "Feature & display allowance per event EVT-SPR26-4471. Net of promotion.",
    routedTo: "Trade Finance",

    promotion: {
      promotionId: "TPR-2026-0312",
      name: "Spring Family Care Feature & Display",
      tpmSystem: "Trade Promotion Management",
      windowStart: "2026-03-02",
      windowEnd: "2026-04-12",
      weeks: 6,
      approvedStores: 445,
      eligibleSkus: [
        { sku: "A100", productName: "2-Ply Facial Tissue – Cube" },
        { sku: "B200", productName: "Bath Tissue – Standard Roll" },
        { sku: "C300", productName: "Kitchen Paper Towels – Roll" },
      ],
      tactic: "Advertised feature + end-cap display",
      rateBasis: "$500 display allowance per store-event, per approved SKU",
      accrualId: "ACC-TPR-0312",
      accruedAmount: 225_000,
    },

    claimedStores: 500,
    supportedStores: 410,

    proofSources: [
      {
        sourceId: "PS-1",
        name: "Retailer POS / scan data",
        system: "Retailer data exchange",
        status: "partial",
        metric: "420 with scan lift",
        flags: ["not-on-event", "out-of-window"],
        detail:
          "Scan lift recorded in 420 stores across the six weeks. 80 billed stores show no scan activity for the eligible SKUs.",
      },
      {
        sourceId: "PS-2",
        name: "Shipment history",
        system: "SAP",
        status: "supports",
        metric: "Shipped on time",
        detail:
          "Eligible SKUs shipped to the approved store footprint ahead of the event window.",
      },
      {
        sourceId: "PS-3",
        name: "Approved store list",
        system: "Trade Promotion Management",
        status: "gap",
        metric: "55 not on list",
        flags: ["not-on-event"],
        detail:
          "55 billed stores are not on the approved event list for TPR-2026-0312.",
      },
      {
        sourceId: "PS-4",
        name: "Display photographs",
        system: "Retailer backup pack",
        status: "partial",
        metric: "410 with photos",
        detail:
          "Dated display photos returned for 410 stores. Remaining stores have no photo evidence.",
      },
      {
        sourceId: "PS-5",
        name: "Weekly flyer / advertised feature",
        system: "Retailer backup pack",
        status: "partial",
        metric: "25 set up late",
        flags: ["out-of-window"],
        detail:
          "Feature ran weeks 1-6. 25 stores show display setup dated after the 2026-04-12 window close.",
      },
      {
        sourceId: "PS-6",
        name: "Promotion agreement & rate",
        system: "Trade Promotion Management",
        status: "gap",
        metric: "E500 not eligible",
        flags: ["ineligible-sku"],
        detail:
          "Agreement covers 3 eligible SKUs. The claim includes a non-eligible SKU (E500) not on the event.",
      },
    ],

    lines: [
      {
        lineId: "PL-1",
        category: "supported",
        label: "Eligible stores with display photo + scan proof",
        amount: 205_000,
        stores: 410,
        evidenceRef: "PS-4",
        finding:
          "410 stores on the approved list, eligible SKUs, within the 2026-03-02 to 2026-04-12 window, with dated display photos and matching scan lift.",
      },
      {
        lineId: "PL-2",
        category: "not-on-event",
        label: "Stores not on the approved event list",
        amount: 22_000,
        stores: 55,
        evidenceRef: "PS-3",
        finding:
          "55 billed stores are absent from the approved store list for TPR-2026-0312. No allowance was agreed for them.",
      },
      {
        lineId: "PL-3",
        category: "out-of-window",
        label: "Display dated outside the promotional window",
        amount: 12_000,
        stores: 25,
        evidenceRef: "PS-5",
        finding:
          "25 stores set the display after the 2026-04-12 window close. Activity falls outside the agreed dates.",
      },
      {
        lineId: "PL-4",
        category: "ineligible-sku",
        label: "Non-eligible SKU billed to the event",
        amount: 11_000,
        stores: 10,
        evidenceRef: "PS-6",
        finding:
          "SKU E500 (Baby Diapers – Size 3) is not an eligible SKU on TPR-2026-0312 and cannot draw the display allowance.",
      },
    ],

    responseLetter: {
      letterRef: "RL-8841",
      to: "Walmart Inc. — Deduction Management",
      from: "Trade Finance",
      subjectTemplate:
        "Partial approval — {supported} of {claimed} deduction against event {retailerEventRef} (invoice {invoiceId})",
      bodyTemplate: `Dear Deduction Management team,

Remittance {remittanceId}, received {receivedDate}, settled {amountPaid} against invoice {invoiceId} in the amount of {invoiceAmount}. {claimed} was withheld as a feature-and-display allowance under your event {retailerEventRef}.

We matched the deduction to promotion {promotionId} ({promotionName}), which ran for {weeks} weeks from {windowStart} to {windowEnd} across {approvedStores} approved stores. Proof of performance was reconciled against scan data, shipment history, the approved store list, display photographs and the weekly feature.

{supported} is approved. It covers {supportedStores} stores with eligible SKUs, within the promotional window, evidenced by dated display photographs and matching scan lift. A credit note will follow.

{unsupported} is not supported and is billed back:
 - {notOnEventAmount} for {notOnEventStores} stores not on the approved event list;
 - {outOfWindowAmount} for {outOfWindowStores} stores with display dated outside the window;
 - {ineligibleSkuAmount} for a non-eligible SKU billed to the event.

A store-level exception list is attached. We request repayment of {unsupported}, or supporting evidence for the disputed stores, within 30 days.

Yours faithfully,
{from}`,
    },
  },
];

export function findPromoClaimCase(caseId: string): PromoClaimCase | undefined {
  return promoClaimCases.find((c) => c.caseId === caseId);
}
