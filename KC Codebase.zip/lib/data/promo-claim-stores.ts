/**
 * Store- and SKU-level detail behind Scenario 1's $250,000 claim.
 *
 * `promoClaimSplit` only carries four leaf lines (one per exception reason).
 * This file expands the two leaf counts that matter operationally — 500
 * stores billed, 410 approved — into the individual store rows an analyst
 * would actually open and check. It is generated once, deterministically, so
 * the counts can never drift from the split they were built to match:
 *   supported (410) + not-on-event (55) + out-of-window (25) + ineligible-sku (10) = 500
 */

import type { PromoLineCategory } from "./promo-claims";

export interface PromoClaimStoreRow {
  storeId: string;
  city: string;
  state: string;
  sku: string;
  productName: string;
  category: PromoLineCategory;
  reason: string;
  /** Which TPM system this store's proof-of-performance record lives in. */
  source: string;
}

/**
 * The four systems that separately track pieces of retailer promotion
 * activity. No single system has the full picture — that fragmentation is
 * exactly why claims like this one need to be reconciled by hand.
 */
export const PROMO_SOURCE_SYSTEMS = ["Vistex", "Promax", "CAS", "SAP"] as const;

const CITY_STATE_CYCLE: { city: string; state: string }[] = [
  { city: "Bentonville", state: "AR" },
  { city: "Dallas", state: "TX" },
  { city: "Houston", state: "TX" },
  { city: "Atlanta", state: "GA" },
  { city: "Charlotte", state: "NC" },
  { city: "Orlando", state: "FL" },
  { city: "Phoenix", state: "AZ" },
  { city: "Denver", state: "CO" },
  { city: "Columbus", state: "OH" },
  { city: "Indianapolis", state: "IN" },
  { city: "Nashville", state: "TN" },
  { city: "Kansas City", state: "MO" },
  { city: "Sacramento", state: "CA" },
  { city: "Tampa", state: "FL" },
  { city: "St. Louis", state: "MO" },
  { city: "Memphis", state: "TN" },
  { city: "Tulsa", state: "OK" },
  { city: "Louisville", state: "KY" },
  { city: "Richmond", state: "VA" },
  { city: "Raleigh", state: "NC" },
  { city: "Birmingham", state: "AL" },
  { city: "Albuquerque", state: "NM" },
  { city: "Omaha", state: "NE" },
  { city: "Fresno", state: "CA" },
];

const ELIGIBLE_SKU_CYCLE = [
  { sku: "A100", productName: "2-Ply Facial Tissue – Cube" },
  { sku: "B200", productName: "Bath Tissue – Standard Roll" },
  { sku: "C300", productName: "Kitchen Paper Towels – Roll" },
];

const INELIGIBLE_SKU = { sku: "E500", productName: "Baby Diapers – Size 3" };

const CATEGORY_GROUPS: {
  category: PromoLineCategory;
  count: number;
  reason: string;
}[] = [
  {
    category: "supported",
    count: 410,
    reason:
      "On the approved event list, within the promotional window, eligible SKU, with a dated display photo and matching scan lift on file.",
  },
  {
    category: "not-on-event",
    count: 55,
    reason:
      "Store is not on the approved store list for TPR-2026-0312. No allowance was agreed for it.",
  },
  {
    category: "out-of-window",
    count: 25,
    reason:
      "Display was set up after the 2026-04-12 window close. Activity falls outside the agreed dates.",
  },
  {
    category: "ineligible-sku",
    count: 10,
    reason:
      "Billed against SKU E500 (Baby Diapers – Size 3), which is not an eligible SKU on this event.",
  },
];

function buildStoreRows(): PromoClaimStoreRow[] {
  const rows: PromoClaimStoreRow[] = [];
  let n = 1;
  let cityIdx = 0;

  for (const group of CATEGORY_GROUPS) {
    for (let i = 0; i < group.count; i++) {
      const cs = CITY_STATE_CYCLE[cityIdx % CITY_STATE_CYCLE.length];
      cityIdx++;
      const skuInfo =
        group.category === "ineligible-sku"
          ? INELIGIBLE_SKU
          : ELIGIBLE_SKU_CYCLE[n % ELIGIBLE_SKU_CYCLE.length];

      rows.push({
        storeId: `STR-${String(n).padStart(4, "0")}`,
        city: cs.city,
        state: cs.state,
        sku: skuInfo.sku,
        productName: skuInfo.productName,
        category: group.category,
        reason: group.reason,
        source: PROMO_SOURCE_SYSTEMS[n % PROMO_SOURCE_SYSTEMS.length],
      });
      n++;
    }
  }
  return rows;
}

/** Generated once at module load — 500 deterministic rows, never random. */
const GENERATED_STORE_ROWS = buildStoreRows();

export const promoClaimStoreRows: Record<string, PromoClaimStoreRow[]> = {
  "DED-PROMO-001": GENERATED_STORE_ROWS,
};

export function findPromoClaimStoreRows(caseId: string): PromoClaimStoreRow[] {
  return promoClaimStoreRows[caseId] ?? [];
}

/** SKU-level rollup: one row per SKU billed on the claim, stores aggregated. */
export interface PromoClaimSkuRow {
  sku: string;
  productName: string;
  eligible: boolean;
  storesBilled: number;
  storesApproved: number;
}

export function promoClaimSkuBreakdown(caseId: string): PromoClaimSkuRow[] {
  const rows = findPromoClaimStoreRows(caseId);
  const bySku = new Map<string, PromoClaimSkuRow>();

  for (const r of rows) {
    const existing = bySku.get(r.sku);
    if (existing) {
      existing.storesBilled += 1;
      if (r.category === "supported") existing.storesApproved += 1;
    } else {
      bySku.set(r.sku, {
        sku: r.sku,
        productName: r.productName,
        eligible: r.sku !== INELIGIBLE_SKU.sku,
        storesBilled: 1,
        storesApproved: r.category === "supported" ? 1 : 0,
      });
    }
  }

  return Array.from(bySku.values()).sort((a, b) => a.sku.localeCompare(b.sku));
}
