/**
 * The reserve position, the accounting entry that corrects it, and the two
 * ledger accounts it moves.
 *
 * A reserve is money set aside for claims we expect but have not yet paid. If
 * the reserve is short, the shortfall has to be posted before the books close.
 *
 * The true-up amount is NEVER typed. It is the difference between what is on
 * the books and what the AI projects, and both journal lines read it from
 * there - so the entry cannot disagree with the reserve position that
 * justified it.
 */

export interface ReserveModel {
  modelId: string;
  /** What is currently set aside. */
  bookedReserve: number;
  /** What the AI projects is actually needed. */
  projectedRequirement: number;
  /** How close last period's reserve landed to what was really claimed. */
  accuracyPercent: number;
  basis: string;
  basisGloss: string;
  drivers: { label: string; note: string }[];
}

export const reserveModel: ReserveModel = {
  modelId: "RSV-2026-08",
  bookedReserve: 18_000_000,
  projectedRequirement: 22_200_000,
  accuracyPercent: 98.4,
  basis: "ASC 606 variable consideration",
  basisGloss:
    "the accounting rule for revenue expected to be returned: the giveback is recognised when the sale is recognised, not when the claim arrives",
  drivers: [
    {
      label: "Government programme claims",
      note: "Claim volume from government-funded buyers is above plan.",
    },
    {
      label: "Contract updates",
      note: "Price records renegotiated mid-period widen the expected giveback.",
    },
    {
      label: "Wholesaler volume growth",
      note: "Higher channel volume carries a proportionate increase in chargebacks.",
    },
  ],
};

/** The shortfall the entry corrects. Derived, so it can never drift. */
export const reserveTrueUpAmount =
  reserveModel.projectedRequirement - reserveModel.bookedReserve;

export interface JournalLine {
  lineNumber: number;
  glAccount: string;
  /** The account name as the accounting system stores it. */
  accountName: string;
  /** The same account, in language a business reader understands. */
  plainName: string;
  debit?: number;
  credit?: number;
}

export interface JournalEntry {
  entryId: string;
  companyCode: string;
  companyCodeGloss: string;
  ledger: string;
  ledgerGloss: string;
  postingPeriod: string;
  postingPeriodLabel: string;
  documentType: string;
  documentTypeGloss: string;
  /** Assigned by the accounting system, revealed once a person posts. */
  documentNumber: string;
  postingDate: string;
  currency: string;
  headline: string;
  lines: JournalLine[];
}

export const reserveAdjustmentEntry: JournalEntry = {
  entryId: "JE-RSV-2026-08",
  companyCode: "US10",
  companyCodeGloss: "the US operating company",
  ledger: "0L",
  ledgerGloss: "the principal ledger",
  postingPeriod: "2026-08",
  postingPeriodLabel: "August 2026 close",
  documentType: "SA",
  documentTypeGloss: "a manual adjustment, not a customer or supplier document",
  documentNumber: "1900008472",
  postingDate: "2026-08-31",
  currency: "USD",
  headline: "Increase the chargeback reserve to the projected requirement",
  lines: [
    {
      lineNumber: 10,
      glAccount: "510450",
      accountName: "Chargeback expense / gross-to-net contra revenue",
      plainName: "Cost of the chargeback programme",
      debit: reserveTrueUpAmount,
    },
    {
      lineNumber: 20,
      glAccount: "229150",
      accountName: "Chargeback reserve liability",
      plainName: "Amounts expected to be credited back",
      credit: reserveTrueUpAmount,
    },
  ],
};

/** Where each account stood before the entry. */
export const ledgerOpeningBalances: Record<string, number> = {
  "229150": reserveModel.bookedReserve,
  "510450": 0,
};

/** The controls that have to hold before and after a posting. */
export interface PostingControl {
  id: string;
  label: string;
  detail: string;
}

export const postingControls: PostingControl[] = [
  {
    id: "balanced",
    label: "The entry balances before it posts",
    detail: "Debits and credits are equal, checked from the lines themselves.",
  },
  {
    id: "approved",
    label: "A person approves before anything is released",
    detail: "Prepared by the analyst and released only on approval.",
  },
  {
    id: "evidence",
    label: "Source claims are attached",
    detail: "The evidence pack links the entry back to the source claims.",
  },
  {
    id: "reversal",
    label: "Reversing it needs a reason and an approval",
    detail: "No entry can be reversed without a recorded reason.",
  },
];

/** Reason codes a reversal request must pick from. */
export const reversalReasonCodes = [
  "Posted to the wrong period",
  "Claim evidence later withdrawn",
  "Reserve model corrected",
  "Duplicate posting",
];

/**
 * Postings above this amount need a second approver. Separate from the
 * write-off limit in lib/data/provisions.ts, which governs a different
 * control on a different reserve.
 */
export const journalPostingSecondApproverThreshold = 1_000_000;

export const journalApprovers = {
  preparedBy: { name: "L. Chen", role: "Controller" },
  approvedBy: { name: "M. Ellsworth", role: "Chief Financial Officer" },
};
