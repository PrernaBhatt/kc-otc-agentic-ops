/**
 * Invoice-to-cash clock for the scenario orders (PRD §10.2). The order run
 * ends at the booked appointment; the invoice is created at POD and the clock
 * runs on the payment terms from there.
 */
export interface InvoiceToCash {
  orderId: string;
  invoiceId: string;
  amountUsd: number;
  poDate: string;
  invoiceDate: string;
  termsDays: number;
  dueDate: string;
}

const DAY_MS = 86_400_000;

function daysBetween(from: string, to: string) {
  return Math.round((Date.parse(`${to}T00:00:00Z`) - Date.parse(`${from}T00:00:00Z`)) / DAY_MS);
}

export const INVOICE_TO_CASH: Record<string, InvoiceToCash> = {
  "SO-710260": {
    orderId: "SO-710260",
    invoiceId: "INV-710260",
    amountUsd: 340_000,
    poDate: "2026-08-20",
    invoiceDate: "2026-08-29",
    termsDays: 30,
    dueDate: "2026-09-28",
  },
  "SO-710249": {
    orderId: "SO-710249",
    invoiceId: "INV-710249",
    amountUsd: 220_000,
    poDate: "2026-08-14",
    invoiceDate: "2026-08-28",
    termsDays: 30,
    dueDate: "2026-09-27",
  },
};

for (const c of Object.values(INVOICE_TO_CASH)) {
  if (daysBetween(c.invoiceDate, c.dueDate) !== c.termsDays) {
    throw new Error(`[invoice-to-cash tie-out] ${c.orderId} due date does not match Net ${c.termsDays}`);
  }
}

export function invoiceToCashFor(orderId: string) {
  const c = INVOICE_TO_CASH[orderId];
  if (!c) return null;
  const toInvoice = daysBetween(c.poDate, c.invoiceDate);
  const total = daysBetween(c.poDate, c.dueDate);
  return { ...c, toInvoiceDays: toInvoice, totalDays: total };
}

/** Portfolio invoice-to-cash and right-first-time figures for the dashboard (PRD §10.3). */
export const I2C_KPIS = {
  invoiceToCashDays: 33,
  invoiceToCashTarget: 30,
  invoiceToCashBest: 28,
  invoiceToCashTrend: [38, 37, 36, 35, 34, 33],
  invoicesIssued: 4_210,
  invoicesDisputed: 101,
  /** Disputes that are not trade promotions: shortage, damage, pricing, compliance, freight. */
  invoicesDisputedNonTrade: 74,
  invoicesReissued: 0,
  rightFirstTimeTarget: 98,
};

export const rightFirstTimePct = (() => {
  const pct = Math.round(((I2C_KPIS.invoicesIssued - I2C_KPIS.invoicesDisputed) / I2C_KPIS.invoicesIssued) * 1000) / 10;
  if (pct !== 97.6) throw new Error("[i2c tie-out] right-first-time rate does not tie to 97.6%");
  if (I2C_KPIS.invoiceToCashTrend.at(-1) !== I2C_KPIS.invoiceToCashDays) {
    throw new Error("[i2c tie-out] trend does not end at the current invoice-to-cash days");
  }
  return pct;
})();
