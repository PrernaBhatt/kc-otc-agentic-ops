/**
 * The second deduction case: a short payment that is PARTLY valid.
 *
 * DED-CB-001 traces a deduction back to a claim we rejected — all of it is
 * recoverable. This one is the harder and more common shape: the distributor
 * withheld against chargebacks, and part of that is genuinely owed to them
 * while part has already been credited and is being taken twice.
 *
 * The AI's job here is to SEPARATE, not to trace. Accepting the whole thing
 * concedes money we do not owe; rejecting the whole thing disputes money we
 * do. Neither is available to an analyst who cannot reconcile the deduction
 * against the claims and the credits at once.
 *
 * Nothing here touches the chargeback flow. It has its own invoice, its own
 * remittance and its own claims, so the two cases can be walked in either
 * order without one changing the other.
 */

export interface ShortPayComponent {
  componentId: string;
  label: string;
  amount: number;
  /** Valid components are conceded; invalid ones are recovered. */
  valid: boolean;
  /** The document that settles it, one way or the other. */
  evidenceRef: string;
  finding: string;
}

export interface ShortPayCase {
  caseId: string;
  distributorId: string;
  customerName: string;
  invoiceId: string;
  invoiceDate: string;
  invoiceAmount: number;
  remittanceId: string;
  receivedDate: string;
  amountPaid: number;
  /** The customer's own words on the remittance. */
  customerNote: string;
  components: ShortPayComponent[];
  routedTo: string;
  /** The credit already issued, which is what makes part of this a duplicate. */
  creditMemo: {
    creditMemoId: string;
    issuedOn: string;
    amount: number;
    againstClaimId: string;
    clearedOn: string;
  };
  approvedClaim: {
    claimId: string;
    approvedOn: string;
    amount: number;
    units: number;
    unitCredit: number;
  };
  disputeLetter: {
    letterRef: string;
    to: string;
    from: string;
    subjectTemplate: string;
    bodyTemplate: string;
    attachments: { id: string; label: string }[];
  };
}

export const shortPayCases: ShortPayCase[] = [
  {
    caseId: "DED-SP-002",
    distributorId: "DIST-001",
    customerName: "Walmart Inc.",
    invoiceId: "INV-CH-4520",
    invoiceDate: "2026-04-30",
    invoiceAmount: 500_000,
    remittanceId: "RMT-7802",
    receivedDate: "2026-08-19",
    amountPaid: 460_000,
    customerNote: "Net of chargebacks per remittance detail.",
    routedTo: "Trade Finance",
    components: [
      {
        componentId: "SPC-1",
        label: "Approved chargeback CB-89012",
        amount: 25_000,
        valid: true,
        evidenceRef: "CB-89012",
        finding:
          "Approved on 2026-04-18 and not yet credited. The distributor is entitled to it.",
      },
      {
        componentId: "SPC-2",
        label: "Chargeback CB-88940, already credited",
        amount: 15_000,
        valid: false,
        evidenceRef: "CM-3301",
        finding:
          "Credit memo CM-3301 settled this claim on 2026-04-02. Taking it again claims the same money twice.",
      },
    ],
    creditMemo: {
      creditMemoId: "CM-3301",
      issuedOn: "2026-04-02",
      amount: 15_000,
      againstClaimId: "CB-88940",
      clearedOn: "2026-04-07",
    },
    approvedClaim: {
      claimId: "CB-89012",
      approvedOn: "2026-04-18",
      amount: 25_000,
      units: 1_000,
      unitCredit: 25,
    },
    disputeLetter: {
      letterRef: "DL-4502",
      to: "Walmart Inc. — Accounts Payable",
      from: "Trade Finance",
      subjectTemplate:
        "Repayment requested — {recoverAmount} of the {shortPay} withheld on invoice {invoiceId}",
      bodyTemplate: `Dear Accounts Payable team,

Remittance {remittanceId}, received {receivedDate}, settled {amountPaid} against invoice {invoiceId} in the amount of {invoiceAmount}. {shortPay} was withheld against chargebacks.

{acceptAmount} of that is accepted. It relates to claim {approvedClaimId}, approved on {approvedOn} and not yet credited, and a credit note will be issued.

{recoverAmount} is not due. It relates to claim {creditClaimId}, which was settled by credit memo {creditMemoId} on {creditIssuedOn} and cleared on {creditClearedOn}. The credit has already been given, and deducting the same amount from this payment claims it a second time.

We request repayment of {recoverAmount} within 30 days. The credit memo and the remittance that cleared it are attached.

Yours faithfully,
{from}`,
      attachments: [
        { id: "SPA-1", label: "Invoice INV-CH-4520" },
        { id: "SPA-2", label: "Remittance RMT-7802" },
        { id: "SPA-3", label: "Credit memo CM-3301" },
        { id: "SPA-4", label: "Approved claim CB-89012" },
      ],
    },
  },
];

export function findShortPayCase(caseId: string): ShortPayCase | undefined {
  return shortPayCases.find((c) => c.caseId === caseId);
}
