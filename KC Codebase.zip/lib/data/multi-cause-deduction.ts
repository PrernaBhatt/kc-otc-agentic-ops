/**
 * Scenario 9 — one short payment, three root causes.
 *
 * A retailer pays $1,460,000 against $1,600,000 of open invoices. The $140,000
 * short is not one generic residual: the AI decomposes it into an existing
 * credit already issued in SAP, a promotion allowance evidenced in the trade
 * system (Vistex, with Promax/CAS as alternates), and a freight claim evidenced
 * in SAP + FourKites. Supported value ($1.46M cash + $35K credit) is applied
 * immediately; the two disputable causes leave as evidence-backed cases routed
 * to their owners.
 */

export type CauseKind = "credit" | "promotion" | "freight";

export type CauseDisposition = "apply-now" | "route";

export interface RootCauseEvidence {
  /** The system this line was pulled from, rendered with SystemMark. */
  system: string;
  label: string;
  detail: string;
}

export interface RootCause {
  id: string;
  kind: CauseKind;
  /** Short reason-code style title for the cause card. */
  title: string;
  amount: number;
  confidence: number;
  /** Systems of record for this cause; the first is the primary source. */
  systems: string[];
  owner: string;
  disposition: CauseDisposition;
  /** One-line summary shown on the split card, before evidence is gathered. */
  summary: string;
  /** What the evidence establishes, shown after the evidence step. */
  finding: string;
  evidence: RootCauseEvidence[];
}

export interface MultiCauseDeduction {
  caseId: string;
  customerId: string;
  customerName: string;
  invoiceBundle: string;
  invoiceCount: number;
  invoicesOpen: number;
  cashReceived: number;
  shortPay: number;
  remittanceRef: string;
  receivedDate: string;
  customerNote: string;
  causes: RootCause[];
}

export const MULTI_CAUSE_DEDUCTION: MultiCauseDeduction = {
  caseId: "DED-RC-009",
  customerId: "CUST-014",
  customerName: "Kroger Co.",
  invoiceBundle: "September remittance, 12 invoices",
  invoiceCount: 12,
  invoicesOpen: 1_600_000,
  cashReceived: 1_460_000,
  shortPay: 140_000,
  remittanceRef: "RA-KR-4471",
  receivedDate: "2026-09-22",
  customerNote: "Payment net of allowances and prior credits per statement.",
  causes: [
    {
      id: "RC-CREDIT",
      kind: "credit",
      title: "Credit already issued",
      amount: 35_000,
      confidence: 0.97,
      systems: ["SAP"],
      owner: "Cash Application",
      disposition: "apply-now",
      summary:
        "Kroger deducted $35,000 — a matching credit already exists in SAP under a different reference.",
      finding:
        "The real credit is CM-88213 in SAP, open for $35,000. Apply it — don't cut a new one.",
      evidence: [
        {
          system: "SAP",
          label: "Credit memo CM-88213",
          detail: "Open, $35,000, issued 2026-08-30 to Kroger Co. — never applied.",
        },
        {
          system: "SAP",
          label: "Referenced credit CM-88123",
          detail: "No such document. Two digits transposed from the live credit.",
        },
        {
          system: "SAP",
          label: "Customer account CUST-014",
          detail: "No second credit of this value open — issuing a new one would pay twice.",
        },
      ],
    },
    {
      id: "RC-PROMO",
      kind: "promotion",
      title: "Promotion allowance",
      amount: 70_000,
      confidence: 0.86,
      systems: ["Vistex", "Promax", "CAS"],
      owner: "Trade Marketing",
      disposition: "route",
      summary:
        "Kroger deducted $70,000 as a feature-and-display allowance.",
      finding:
        "Matched to Vistex promotion VX-Q3-2214 with fund remaining and proof of performance on file. Trade to confirm eligibility before a credit is cut.",
      evidence: [
        {
          system: "Vistex",
          label: "Promotion VX-Q3-2214",
          detail: "Feature-and-display, ran 2026-08-04 to 08-24. $92,400 accrued fund remaining.",
        },
        {
          system: "Vistex",
          label: "Proof of performance",
          detail: "Retailer circular scan and store-count report attached to the promotion.",
        },
        {
          system: "Promax",
          label: "Plan alignment",
          detail: "Same plan mirrored in Promax; CAS carries the post-audit backup pack.",
        },
      ],
    },
    {
      id: "RC-FREIGHT",
      kind: "freight",
      title: "Freight / delivery claim",
      amount: 35_000,
      confidence: 0.9,
      systems: ["SAP", "FourKites"],
      owner: "Logistics",
      disposition: "route",
      summary:
        "Kroger deducted $35,000 for a late, short delivery. Carrier liability is not yet confirmed.",
      finding:
        "SAP and FourKites confirm a late arrival, three pallets short on the POD. Logistics to confirm carrier liability before it's conceded.",
      evidence: [
        {
          system: "SAP",
          label: "Delivery SHP-55120",
          detail: "12 pallets shipped against order; POD signed for 9 received.",
        },
        {
          system: "FourKites",
          label: "Shipment tracking",
          detail: "Arrived 2026-08-19, two days past the delivery window; one temperature excursion logged.",
        },
        {
          system: "SAP",
          label: "Proof of delivery",
          detail: "Receiver signature short three pallets — matches the $35,000 claimed.",
        },
      ],
    },
  ],
};

/** Cash + the existing credit, applied immediately. */
export function multiCauseApplied(d: MultiCauseDeduction): number {
  const credit = d.causes
    .filter((c) => c.disposition === "apply-now")
    .reduce((sum, c) => sum + c.amount, 0);
  return d.cashReceived + credit;
}

/** The two disputable causes that leave as routed cases. */
export function multiCauseRouted(d: MultiCauseDeduction): RootCause[] {
  return d.causes.filter((c) => c.disposition === "route");
}
