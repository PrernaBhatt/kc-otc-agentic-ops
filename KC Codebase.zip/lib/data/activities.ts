import type { AgentActivity } from "./types";

export const agentActivities: AgentActivity[] = [
  {
    id: "ACT-001",
    agentName: "OTC Orchestrator",
    agentType: "orchestrator",
    status: "complete",
    message: "Initiated credit hold workflow for SO-710245",
    timestamp: "2026-08-15T08:30:15Z",
  },
  {
    id: "ACT-002",
    agentName: "Credit Risk Agent",
    agentType: "credit",
    status: "complete",
    message: "Calculated risk score: 0.68 | Exposure ratio: 97%",
    timestamp: "2026-08-15T08:30:18Z",
  },
  {
    id: "ACT-003",
    agentName: "Pricing & Policy Agent",
    agentType: "pricing",
    status: "complete",
    message: "Pricing validated ✓ | Tax compliant ✓ | Contract terms OK",
    timestamp: "2026-08-15T08:30:20Z",
  },
  {
    id: "ACT-004",
    agentName: "Customer LTV Agent",
    agentType: "ltv",
    status: "complete",
    message: "LTV Score: 0.82 | Relationship Tier: Gold | Low churn risk",
    timestamp: "2026-08-15T08:30:22Z",
  },
  {
    id: "ACT-005",
    agentName: "OTC Orchestrator",
    agentType: "orchestrator",
    status: "processing",
    message: "Generating decision options (Golden Trio)...",
    timestamp: "2026-08-15T08:30:25Z",
  },
];
