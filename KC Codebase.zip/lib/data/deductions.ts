export type DeductionStatus = "Open" | "In Progress" | "Resolved";

export interface DeductionCase {
  deductionId: string;
  customerId: string;
  customerName: string;
  invoiceId: string;
  amount: number;
  source: "Short payment" | "Debit memo";
  sourceReference: string;
  reasonCode:
    | "Freight damage"
    | "Pricing"
    | "Shortage"
    | "Promotion allowance"
    | "Tax"
    | "Compliance chargeback"
    /**
     * The customer took money for a wholesale chargeback claim we rejected.
     * Distinct from "Compliance chargeback", which is a customer penalty.
     */
    | "Unauthorised chargeback";
  reasonConfidence: number;
  status: DeductionStatus;
  validity: "Under review" | "Valid" | "Partially valid" | "Invalid";
  routedTo: string;
  evidence: { id: string; label: string; available: boolean }[];
  rootCauseFinding: string;
  aiRecommendation: string;
  resolutionOptions: string[];
  /** Which resolution options the AI recommends (highlighted for the human). */
  recommendedOptions?: string[];
  /**
   * Present when the AI recommends splitting the claim: the supported portion
   * (credit memo) and the unsupported portion (rebill/recover). Clicking
   * "Rebill the customer" opens a dial to adjust this split before deciding.
   */
  splitResolution?: {
    supportedAmount: number;
    unsupportedAmount: number;
    supportedLabel: string;
    unsupportedLabel: string;
  };
  resolution?: string;

  /* ---- Channel deductions only. Optional, so the two cases above are
     unaffected and every page that reads them keeps working. ---- */

  /** The rejected chargeback claim this deduction is retaliation for. */
  linkedClaimId?: string;
  /** Which resolution option the human picked at the recovery gate. */
  chosenRecovery?: string;
  /** Readings the AI considered and ruled out, shown at the classify stage. */
  rejectedReadings?: { label: string; why: string }[];
  /**
   * Outbound dispute correspondence. The body is a token template - the
   * numbers are substituted from the records at render time so the letter,
   * the screen and the document can never disagree.
   */
  disputeLetter?: {
    letterRef: string;
    to: string;
    toEmail: string;
    from: string;
    fromEmail: string;
    subjectTemplate: string;
    bodyTemplate: string;
    attachments: { id: string; label: string; docKey: string }[];
  };
  disputeStatus?: "Not drafted" | "Draft ready" | "Sent";
  disputeSentDate?: string;
}

export const deductions: DeductionCase[] = [
  {
    deductionId: "DED-001",
    customerId: "CUST-003",
    customerName: "Woolworths Group",
    invoiceId: "INV-12347",
    amount: 3000,
    source: "Short payment",
    sourceReference: "Receipt RCPT-9003 paid $39,000 against a $42,000 invoice",
    reasonCode: "Freight damage",
    reasonConfidence: 0.94,
    status: "Open",
    validity: "Invalid",
    routedTo: "Customer Service",
    evidence: [
      { id: "EV-1", label: "Sales order SO-710247 — $45,000 ordered", available: true },
      { id: "EV-2", label: "Invoice INV-12347 — issued at $42,000", available: true },
      { id: "EV-3", label: "Delivery record SHP-002", available: true },
      { id: "EV-4", label: "Customer claim CLM-301 with photos", available: true },
    ],
    rootCauseFinding:
      "Claim CLM-301 covers the damage on delayed shipment SHP-002 — the same damage already allowed for when the invoice was issued. INV-12347 went out at $42,000 against the $45,000 order, and that $3,000 allowance has been written off. This deduction claims the same damage a second time.",
    aiRecommendation:
      "The damage allowance was already granted at invoicing and written off, so nothing further is owed to the customer. Recommend rebilling the $3,000 deducted, with the order and the invoice attached to show the allowance was already applied.",
    resolutionOptions: [
      "Issue credit memo",
      "Rebill the customer",
      "Request repayment",
      "Write off",
      "Internal chargeback",
    ],
    recommendedOptions: ["Rebill the customer"],
  },
  {
    deductionId: "DED-002",
    customerId: "CUST-001",
    customerName: "Walmart Inc.",
    invoiceId: "INV-12342",
    amount: 8200,
    source: "Debit memo",
    sourceReference: "Customer debit memo DM-2201",
    reasonCode: "Promotion allowance",
    reasonConfidence: 0.88,
    status: "In Progress",
    validity: "Partially valid",
    routedTo: "Sales",
    evidence: [
      { id: "EV-1", label: "Invoice INV-12342", available: true },
      { id: "EV-2", label: "Debit memo DM-2201", available: true },
      { id: "EV-3", label: "Promotion agreement Q4-2025", available: true },
      { id: "EV-4", label: "Promotion performance report", available: true },
    ],
    rootCauseFinding:
      "Promotion agreement supports $6,000 of the claimed allowance. The remaining $2,200 falls outside the agreed promotion window.",
    aiRecommendation:
      "Recommend a split resolution: credit memo for the $6,000 supported by the agreement, and rebill the customer for the $2,200 claimed outside the window.",
    resolutionOptions: [
      "Issue credit memo",
      "Rebill the customer",
      "Request repayment",
      "Write off",
      "Internal chargeback",
    ],
    recommendedOptions: ["Issue credit memo", "Rebill the customer"],
    splitResolution: {
      supportedAmount: 6000,
      unsupportedAmount: 2200,
      supportedLabel: "Supported by the Q4 promotion agreement",
      unsupportedLabel: "Claimed outside the promotion window",
    },
  },
];
