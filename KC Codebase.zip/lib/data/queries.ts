export type QueryScope =
  | "Order status"
  | "Shipment tracking"
  | "Billing query"
  | "Pricing query"
  | "Returns / claims"
  | "Credit inquiry"
  | "Master data query";

export interface CustomerQuery {
  queryId: string;
  customerId: string;
  customerName: string;
  channel: "Email" | "Portal" | "Phone";
  receivedAt: string;
  subject: string;
  body: string;
  scope: QueryScope;
  scopeConfidence: number;
  owner: string;
  responseTargetHours: number;
  hoursRemaining: number;
  status: "New" | "Draft ready" | "Sent";
  draftReply: string;
}

/**
 * Seed metric for the Query Hub header: share of customer queries answered
 * within their response-time target this month.
 */
export const onTimeResponseRatePercent = 96;

export const customerQueries: CustomerQuery[] = [
  {
    queryId: "QRY-101",
    customerId: "CUST-002",
    customerName: "Tesco PLC",
    channel: "Portal",
    receivedAt: "2026-08-20 08:12",
    subject: "When will order SO-710246 ship?",
    body: "We need a firm delivery date for order SO-710246 to plan our production line changeover.",
    scope: "Order status",
    scopeConfidence: 0.97,
    owner: "Order Management Team",
    responseTargetHours: 4,
    hoursRemaining: 2.5,
    status: "Draft ready",
    draftReply:
      "Your order SO-710246 is allocated and the shipment is booked with the carrier. It is promised for delivery on May 24. We will send tracking as soon as it is picked up.",
  },
  {
    queryId: "QRY-102",
    customerId: "CUST-003",
    customerName: "Woolworths Group",
    channel: "Email",
    receivedAt: "2026-08-20 07:48",
    subject: "Where is our delivery for SO-710247?",
    body: "The shipment was promised for May 16 and has not arrived.",
    scope: "Shipment tracking",
    scopeConfidence: 0.96,
    owner: "Logistics Team",
    responseTargetHours: 4,
    hoursRemaining: 1.75,
    status: "Draft ready",
    draftReply:
      "Your shipment was held at a transfer hub due to carrier capacity and is running 5 days late. The revised delivery date is May 21 and we are monitoring it hourly. We apologize for the delay.",
  },
  {
    queryId: "QRY-103",
    customerId: "CUST-002",
    customerName: "Tesco PLC",
    channel: "Email",
    receivedAt: "2026-08-19 16:20",
    subject: "Please resend invoice INV-12346",
    body: "Our accounts payable team needs a copy of invoice INV-12346 with the remittance details.",
    scope: "Billing query",
    scopeConfidence: 0.98,
    owner: "Billing Analyst",
    responseTargetHours: 8,
    hoursRemaining: 5,
    status: "Draft ready",
    draftReply:
      "A copy of invoice INV-12346 for $180,000 (due Jun 7) is attached, including payment instructions. Let us know if your team needs anything else.",
  },
  {
    queryId: "QRY-104",
    customerId: "CUST-001",
    customerName: "Walmart Inc.",
    channel: "Portal",
    receivedAt: "2026-08-19 14:05",
    subject: "Contract price for Feminine Care Pads - Ultra Thin",
    body: "Please confirm our contract price for Feminine Care Pads - Ultra Thin before we place our next order.",
    scope: "Pricing query",
    scopeConfidence: 0.95,
    owner: "Commercial Team",
    responseTargetHours: 8,
    hoursRemaining: 6.5,
    status: "Draft ready",
    draftReply:
      "Your contract price for Feminine Care Pads - Ultra Thin is $110 per unit under your current agreement. Volume discounts apply above 1,000 units per order.",
  },
  {
    queryId: "QRY-105",
    customerId: "CUST-003",
    customerName: "Woolworths Group",
    channel: "Email",
    receivedAt: "2026-08-20 09:02",
    subject: "Damage claim CLM-301 status",
    body: "Following up on our claim for 8 damaged units on the recent delivery.",
    scope: "Returns / claims",
    scopeConfidence: 0.94,
    owner: "Customer Service",
    responseTargetHours: 8,
    hoursRemaining: 7,
    status: "Draft ready",
    draftReply:
      "Thank you for the photos supporting claim CLM-301. The damage on this delivery was already allowed for when we invoiced you: order SO-710247 was $45,000 and invoice INV-12347 was issued at $42,000, a $3,000 allowance we have absorbed. Because that credit was already applied, the $3,000 deducted from your payment will be rebilled — the order and the invoice are attached so you can see both figures.",
  },
  {
    queryId: "QRY-106",
    customerId: "CUST-001",
    customerName: "Walmart Inc.",
    channel: "Phone",
    receivedAt: "2026-08-20 08:40",
    subject: "How much credit room do we have?",
    body: "We want to place a large order and need to know our available credit.",
    scope: "Credit inquiry",
    scopeConfidence: 0.92,
    owner: "Credit Control Team",
    responseTargetHours: 4,
    hoursRemaining: 3,
    status: "Draft ready",
    draftReply:
      "Your credit limit is $500,000 with $485,000 currently in use, leaving $15,000 available. Early payment of open invoice INV-12345 would free up more room — happy to help arrange it.",
  },
  {
    queryId: "QRY-107",
    customerId: "CUST-002",
    customerName: "Tesco PLC",
    channel: "Portal",
    receivedAt: "2026-08-18 11:30",
    subject: "Update our delivery address",
    body: "Our EMEA receiving warehouse has moved. Please update the delivery address on our account.",
    scope: "Master data query",
    scopeConfidence: 0.97,
    owner: "Master Data Team",
    responseTargetHours: 24,
    hoursRemaining: 18,
    status: "Draft ready",
    draftReply:
      "We have drafted the address change for your EMEA warehouse. Once you confirm the new address details below, it will apply to all open and future orders.",
  },
];
