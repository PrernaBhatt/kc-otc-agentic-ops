/**
 * Scenario 4 — wrong fund, insufficient accrual and settlement mismatch.
 *
 * A retailer submits a VALID $180,000 promotion claim. Nobody disputes that the
 * promotion happened. The claim references a single fund, but it actually spans
 * two overlapping events sitting on two different funds. The referenced primary
 * fund has only $140,000 of available accrual; the remaining $40,000 belongs to
 * a second eligible fund. The question is not approve-or-reject — it is how to
 * ALLOCATE, approve, settle and reconcile the claim across the two funds without
 * overspending a budget or misstating the accrual.
 *
 * This is deliberately different from Scenarios 1–3, where the answer was a
 * partial approval and a clawback. Here the whole $180,000 is approved and paid;
 * the work is splitting it correctly across funds, routing the budget exception
 * for trade-finance review, and confirming the downstream postings reconcile.
 *
 * Every figure is a leaf. The selector sums the allocations, so the split can
 * never disagree with the claim:
 *   Σ(fund allocations) === claimed
 * and each fund's allocation is capped at, and reconciled against, its own
 * available accrual.
 */

/** How a claim line is allocated to a fund. */
export interface FundAllocation {
  allocationId: string;
  fundId: string;
  fundName: string;
  eventId: string;
  eventName: string;
  spendType: string;
  /** The dollars of this claim charged to this fund. */
  allocated: number;
  /** Accrual available in the fund before this claim. */
  available: number;
  /** Accrued for this event before this claim. */
  accruedForEvent: number;
  /** True when the fund the retailer referenced could not cover the claim. */
  isReferenced: boolean;
  note: string;
}

/** One promotion event the claim actually spans. */
export interface FundEvent {
  eventId: string;
  name: string;
  fundId: string;
  periodStart: string;
  periodEnd: string;
  mechanic: string;
  skuGroup: string;
  plannedSpend: number;
  accrued: number;
  priorClaims: number;
  note: string;
}

/** A trade-promotion fund (checkbook line). */
export interface TradeFund {
  fundId: string;
  name: string;
  tpmSystem: string;
  fiscalYear: string;
  /** Total accrual originally booked to the fund. */
  accrualBooked: number;
  /** Consumed by earlier settled claims. */
  priorConsumed: number;
  note: string;
}

/** One downstream record the settlement has to update, with a control check. */
export interface SettlementControl {
  controlId: string;
  label: string;
  system: string;
  /** The value this control should carry after settlement. */
  expected: number;
  note: string;
}

export interface FundClaimCase {
  caseId: string;
  distributorId: string;
  customerName: string;
  invoiceId: string;
  invoiceDate: string;
  invoiceAmount: number;
  remittanceId: string;
  receivedDate: string;
  amountPaid: number;

  claimRef: string;
  reasonCode: string;
  /** The single fund/event the retailer's paperwork points at. */
  referencedFundId: string;
  referencedEventId: string;
  customerNote: string;
  routedTo: string;

  /** Materiality: budget overrides above this need trade-finance review. */
  materialityThreshold: number;

  funds: TradeFund[];
  events: FundEvent[];
  allocations: FundAllocation[];
  controls: SettlementControl[];

  responseLetter: {
    letterRef: string;
    to: string;
    from: string;
    subjectTemplate: string;
    bodyTemplate: string;
  };
}

export const fundClaimCases: FundClaimCase[] = [
  {
    caseId: "DED-FUND-001",
    distributorId: "DIST-001",
    customerName: "Walmart Inc.",
    invoiceId: "INV-TP-9120",
    invoiceDate: "2026-08-04",
    invoiceAmount: 1_180_000,
    remittanceId: "RMT-9612",
    receivedDate: "2026-08-16",
    amountPaid: 1_000_000,

    claimRef: "TP-2026-0655",
    reasonCode: "Promotion settlement — feature & display",
    referencedFundId: "FUND-Q3-FAMILY",
    referencedEventId: "EVT-BTS-FEATURE",
    customerNote:
      "Promotion settlement for back-to-school feature and display, per plan TP-2026-0655. Single claim, $180,000.",
    routedTo: "Trade Finance",

    // Materiality: a fund shortfall / cross-fund move above $25,000 must be
    // reviewed by Trade Finance rather than auto-approved.
    materialityThreshold: 25_000,

    funds: [
      {
        fundId: "FUND-Q3-FAMILY",
        name: "Q3 Family Care — Feature & Display",
        tpmSystem: "Vistex",
        fiscalYear: "FY26",
        accrualBooked: 620_000,
        priorConsumed: 480_000,
        // available = 620,000 - 480,000 = 140,000
        note: "The fund the retailer referenced. Earlier back-to-school claims have already drawn it down to $140,000 available.",
      },
      {
        fundId: "FUND-Q3-BABY",
        name: "Q3 Baby Care — Shopper Marketing",
        tpmSystem: "Vistex",
        fiscalYear: "FY26",
        accrualBooked: 300_000,
        priorConsumed: 110_000,
        // available = 300,000 - 110,000 = 190,000
        note: "A second eligible fund. The display ran across baby-care SKUs too, so part of the spend legitimately belongs here.",
      },
    ],

    events: [
      {
        eventId: "EVT-BTS-FEATURE",
        name: "Back-to-School Feature — Family Care",
        fundId: "FUND-Q3-FAMILY",
        periodStart: "2026-07-06",
        periodEnd: "2026-08-02",
        mechanic: "Advertised feature",
        skuGroup: "Family Care (facial tissue, bath tissue, towels)",
        plannedSpend: 150_000,
        accrued: 150_000,
        priorClaims: 10_000,
        // available for this event on the fund ≈ 140,000
        note: "The event the claim references. Feature ran on family-care SKUs; $140,000 of accrual remains after an earlier $10,000 claim.",
      },
      {
        eventId: "EVT-BTS-DISPLAY",
        name: "Back-to-School Display — Baby Care",
        fundId: "FUND-Q3-BABY",
        periodStart: "2026-07-13",
        periodEnd: "2026-08-09",
        mechanic: "In-store display",
        skuGroup: "Baby Care (diapers, wipes, training pants)",
        plannedSpend: 60_000,
        accrued: 60_000,
        priorClaims: 0,
        note: "Overlapping baby-care display, funded from the baby-care shopper-marketing fund. Not referenced by the claim, but the spend belongs here.",
      },
    ],

    // Σ allocated = 140,000 + 40,000 = 180,000 = claimed.
    // Referenced fund is capped at its available 140,000; the overflow 40,000
    // moves to the eligible secondary fund.
    allocations: [
      {
        allocationId: "ALLOC-1",
        fundId: "FUND-Q3-FAMILY",
        fundName: "Q3 Family Care — Feature & Display",
        eventId: "EVT-BTS-FEATURE",
        eventName: "Back-to-School Feature — Family Care",
        spendType: "Advertised feature",
        allocated: 140_000,
        available: 140_000,
        accruedForEvent: 140_000,
        isReferenced: true,
        note: "Fully covered by the referenced fund's remaining $140,000.",
      },
      {
        allocationId: "ALLOC-2",
        fundId: "FUND-Q3-BABY",
        fundName: "Q3 Baby Care — Shopper Marketing",
        eventId: "EVT-BTS-DISPLAY",
        eventName: "Back-to-School Display — Baby Care",
        spendType: "In-store display",
        allocated: 40_000,
        available: 190_000,
        accruedForEvent: 60_000,
        isReferenced: false,
        note: "Not in the referenced fund. Moved to baby-care's fund, which has room.",
      },
    ],

    controls: [
      {
        controlId: "CTRL-1",
        label: "Credit memo issued to customer",
        system: "SAP AR",
        expected: 180_000,
        note: "One credit memo for the full approved claim, clearing the deduction.",
      },
      {
        controlId: "CTRL-2",
        label: "Trade-promotion checkbook updated",
        system: "Vistex",
        expected: 180_000,
        note: "Both funds' available-to-spend balances reduced by their allocation.",
      },
      {
        controlId: "CTRL-3",
        label: "FI posting — trade spend",
        system: "SAP FI",
        expected: 180_000,
        note: "Actual promotional expense recognised against the two funds; accrual released to match.",
      },
      {
        controlId: "CTRL-4",
        label: "Receivable dispute closed",
        system: "SAP Dispute Mgmt",
        expected: 0,
        note: "Deduction fully settled by the credit memo; no residual open dispute.",
      },
    ],

    responseLetter: {
      letterRef: "RL-9120",
      to: "Walmart Inc. — Trade Finance",
      from: "Trade Finance",
      subjectTemplate:
        "Promotion settlement {claimRef} — {claimed} approved, allocated across two funds",
      bodyTemplate: `Dear Trade Finance team,

Remittance {remittanceId}, received {receivedDate}, withheld {claimed} against invoice {invoiceId} under your reference {claimRef}, for the back-to-school feature and display.

The promotion is valid and approved in full at {claimed}. In settling it we found the claim spans two overlapping events, funded separately:

 - {primaryAllocated} — family-care feature, charged to the fund you referenced ({primaryFund}), which is drawn down in full.
 - {secondaryAllocated} — baby-care display, charged to its own shopper-marketing fund ({secondaryFund}), where the spend legitimately belongs.

Splitting the claim this way keeps both fund budgets whole and matches the accrual to where the spend actually occurred. A single credit memo for {claimed} clears the deduction; nothing further is due from you.

Yours faithfully,
{from}`,
    },
  },
];

export function findFundClaimCase(caseId: string): FundClaimCase | undefined {
  return fundClaimCases.find((c) => c.caseId === caseId);
}
