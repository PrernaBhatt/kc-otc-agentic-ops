/**
 * Contract prices, claim windows, and the reported-price basis.
 *
 * A contract price record says: for this contract, this product, between these
 * dates, the agreed price is X. Validating a chargeback means finding the ONE
 * record in force for the project on the claim, on the date of the claim -
 * not the newest record, and not the cheapest.
 *
 * The list price is NEVER stored here. It lives once, on the product, in
 * lib/data/products.ts.
 */

import { monthlyAllocationCapUnits } from "./inventory";

export interface ContractPriceRecord {
  priceRecordId: string;
  contractId: string;
  rosterId: string | null;
  sku: string;
  contractPrice: number;
  effectiveFrom: string;
  effectiveTo: string | null;
  approvedBy: string;
  /** The signed record the AI cites as evidence that this price is real. */
  approvalRef: string;
}

/**
 * Five records for the incontinence briefs. PR-4488 is not yet in force and PR-4455 has
 * expired: both exist so the effective-date logic has something real to reject.
 * PR-4310 is the record the wholesaler's claim leans on - a genuine price, on a
 * roster the project is not a member of.
 */
export const contractPrices: ContractPriceRecord[] = [
  {
    priceRecordId: "PR-4455",
    contractId: "CTR-NLK-2026",
    rosterId: "ROSTER-NLK",
    sku: "SKU-K110",
    contractPrice: 110,
    effectiveFrom: "2025-01-01",
    effectiveTo: "2025-12-31",
    approvedBy: "Contract Compliance",
    approvalRef: "Signed price record PR-4455",
  },
  {
    priceRecordId: "PR-4471",
    contractId: "CTR-NLK-2026",
    rosterId: "ROSTER-NLK",
    sku: "SKU-K110",
    contractPrice: 100,
    effectiveFrom: "2026-01-01",
    effectiveTo: null,
    approvedBy: "Contract Compliance",
    approvalRef: "Signed price record PR-4471",
  },
  {
    priceRecordId: "PR-4488",
    contractId: "CTR-NLK-2026",
    rosterId: "ROSTER-NLK",
    sku: "SKU-K110",
    contractPrice: 98,
    effectiveFrom: "2026-07-01",
    effectiveTo: null,
    approvedBy: "Contract Compliance",
    approvalRef: "Signed price record PR-4488",
  },
  {
    priceRecordId: "PR-4310",
    contractId: "CTR-NBA-2201",
    rosterId: "ROSTER-NBA",
    sku: "SKU-K110",
    contractPrice: 60,
    effectiveFrom: "2025-07-01",
    effectiveTo: null,
    approvedBy: "Contract Compliance",
    approvalRef: "Signed price record PR-4310",
  },
  {
    priceRecordId: "PR-4620",
    contractId: "CTR-NBA-2201",
    rosterId: "ROSTER-NBA",
    sku: "SKU-K220",
    contractPrice: 60,
    effectiveFrom: "2025-07-01",
    effectiveTo: null,
    approvedBy: "Contract Compliance",
    approvalRef: "Signed price record PR-4620",
  },
  {
    priceRecordId: "PR-4705",
    contractId: "CTR-MW-2205",
    rosterId: "ROSTER-MW",
    sku: "SKU-K330",
    contractPrice: 45,
    effectiveFrom: "2025-03-01",
    effectiveTo: null,
    approvedBy: "Contract Compliance",
    approvalRef: "Signed price record PR-4705",
  },
];

/** Every price record for a product, oldest first — the price-list document. */
export function priceRecordsFor(sku: string): ContractPriceRecord[] {
  return contractPrices
    .filter((p) => p.sku === sku)
    .slice()
    .sort((a, b) => a.effectiveFrom.localeCompare(b.effectiveFrom));
}

/** The one record in force for a contract and product on a given date. */
export function effectivePriceRecord(
  sku: string,
  contractId: string,
  onDate: string
): ContractPriceRecord | undefined {
  return contractPrices.find(
    (p) =>
      p.sku === sku &&
      p.contractId === contractId &&
      p.effectiveFrom <= onDate &&
      (p.effectiveTo === null || p.effectiveTo >= onDate)
  );
}

/** The window a claim covers. Claims are submitted for a period, not a day. */
export interface ClaimPeriod {
  periodId: string;
  from: string;
  to: string;
  label: string;
}

export const claimPeriods: ClaimPeriod[] = [
  // Earlier windows for the same wholesaler and project. They exist so the
  // duplicate screen has real prior claims to compare against: same parties,
  // same product, different quarters.
  {
    periodId: "CP-2025AUGOCT",
    from: "2025-08-01",
    to: "2025-10-31",
    label: "August to October 2025",
  },
  {
    periodId: "CP-2025NOVJAN",
    from: "2025-11-01",
    to: "2026-01-31",
    label: "November 2025 to January 2026",
  },
  {
    periodId: "CP-2026FEBAPR",
    from: "2026-02-01",
    to: "2026-04-30",
    label: "February to April 2026",
  },
];

export function findClaimPeriod(periodId: string): ClaimPeriod | undefined {
  return claimPeriods.find((p) => p.periodId === periodId);
}

/** Whole months in a claim window, used for the allocation ceiling. */
export function periodMonths(period: ClaimPeriod): number {
  const from = new Date(period.from + "T00:00:00Z");
  const to = new Date(period.to + "T00:00:00Z");
  return (
    (to.getUTCFullYear() - from.getUTCFullYear()) * 12 +
    (to.getUTCMonth() - from.getUTCMonth()) +
    1
  );
}

/**
 * The most units that could physically have reached one wholesaler in a claim
 * window, from the monthly allocation cap in lib/data/inventory.ts. This is an
 * UPPER BOUND only - it says nothing about how much of the cap was used.
 */
export function allocationCeilingUnits(period: ClaimPeriod): number {
  return periodMonths(period) * monthlyAllocationCapUnits;
}


