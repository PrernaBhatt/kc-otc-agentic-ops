/**
 * Demo clock anchor. Every "days past due" / aging calculation derives from
 * this fixed business date so the demo is deterministic.
 */
export const TODAY = "2026-08-20";

/**
 * The date the account, escalation and audit views read as "today". The
 * order scenarios keep TODAY (they replay an August pipeline); disputes,
 * escalations and audit history run to this later date.
 */
export const RUN_DATE = "2026-11-05";

export function daysBetween(fromIso: string, toIso: string = TODAY): number {
  const from = new Date(fromIso + "T00:00:00Z").getTime();
  const to = new Date(toIso + "T00:00:00Z").getTime();
  return Math.round((to - from) / 86400000);
}

/** Days past due for an invoice due date; negative = not yet due. */
export function daysPastDue(dueDate: string): number {
  return daysBetween(dueDate, TODAY);
}

/** An ISO date `days` after the demo's business date. */
export function daysAfterToday(days: number): string {
  const d = new Date(TODAY + "T00:00:00Z");
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}
