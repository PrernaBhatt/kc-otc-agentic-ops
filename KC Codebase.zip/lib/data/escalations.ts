/**
 * Tracked escalations from a customer owner to Commercial or Supply chain.
 * Four are already open when the demo starts; the rest are raised by runs
 * (billing dispute, Target pricing, non-trade batch) from the templates below.
 */

export type EscalationTeam = "Commercial" | "Supply chain";
export type EscalationStatus = "Raised" | "Acknowledged" | "Actioned" | "Closed";

export const ESCALATION_STATUSES: EscalationStatus[] = [
  "Raised",
  "Acknowledged",
  "Actioned",
  "Closed",
];

export interface EscalationNudge {
  at: string;
  kind: "auto" | "manual" | "auto-escalated";
  note: string;
  by: string;
}

export interface EscalationStep {
  status: EscalationStatus;
  at?: string;
  by?: string;
}

export interface Escalation {
  id: string;
  accountIds: string[];
  team: EscalationTeam;
  unit: string;
  subject: string;
  /** Null when the amount is derived from a case selector at load. */
  amountUsd: number | null;
  raisedOn: string;
  raisedBy: string;
  slaDays: number;
  status: EscalationStatus;
  chain: EscalationStep[];
  nudges: EscalationNudge[];
  sourceCaseId: string;
  sourceModule: string;
}

export const seededEscalations: Escalation[] = [
  {
    id: "ESC-2601",
    accountIds: ["CUST-001"],
    team: "Supply chain",
    unit: "DC operations",
    subject: "OTIF fine appeals need receiving evidence",
    amountUsd: 19_000,
    raisedOn: "2026-10-22",
    raisedBy: "Rachel Ortiz",
    slaDays: 15,
    status: "Acknowledged",
    chain: [
      { status: "Raised", at: "2026-10-22", by: "Rachel Ortiz" },
      { status: "Acknowledged", at: "2026-10-24", by: "DC operations, Bentonville" },
      { status: "Actioned" },
      { status: "Closed" },
    ],
    nudges: [
      { at: "2026-10-29", kind: "auto", note: "Day 7 reminder sent", by: "Escalation Tracking Agent" },
    ],
    sourceCaseId: "CHB-WMT-OTIF",
    sourceModule: "Deductions",
  },
  {
    id: "ESC-2604",
    accountIds: ["CUST-002"],
    team: "Commercial",
    unit: "Key Account UK",
    subject: "Rebate tier dispute on amended agreement",
    amountUsd: null,
    raisedOn: "2026-10-27",
    raisedBy: "Oliver Shaw",
    slaDays: 15,
    status: "Raised",
    chain: [
      { status: "Raised", at: "2026-10-27", by: "Oliver Shaw" },
      { status: "Acknowledged" },
      { status: "Actioned" },
      { status: "Closed" },
    ],
    nudges: [
      { at: "2026-11-03", kind: "auto", note: "Day 7 reminder sent", by: "Escalation Tracking Agent" },
    ],
    sourceCaseId: "DED-REBATE-001",
    sourceModule: "Deductions",
  },
  {
    id: "ESC-2607",
    accountIds: ["CUST-004"],
    team: "Supply chain",
    unit: "Transportation",
    subject: "Three pallets short on receipt",
    amountUsd: 35_000,
    raisedOn: "2026-10-30",
    raisedBy: "Aisha Grant",
    slaDays: 10,
    status: "Actioned",
    chain: [
      { status: "Raised", at: "2026-10-30", by: "Aisha Grant" },
      { status: "Acknowledged", at: "2026-10-31", by: "Transportation, Cincinnati" },
      { status: "Actioned", at: "2026-11-04", by: "Carrier claim CC-40917 filed" },
      { status: "Closed" },
    ],
    nudges: [],
    sourceCaseId: "DED-RC-009",
    sourceModule: "Deductions",
  },
  {
    id: "ESC-2611",
    accountIds: ["CUST-003"],
    team: "Commercial",
    unit: "Key Account AU",
    subject: "Trade claims awaiting proof of performance",
    amountUsd: 418_500,
    raisedOn: "2026-09-19",
    raisedBy: "Mia Kelly",
    slaDays: 30,
    status: "Acknowledged",
    chain: [
      { status: "Raised", at: "2026-09-19", by: "Mia Kelly" },
      { status: "Acknowledged", at: "2026-09-23", by: "Key Account AU" },
      { status: "Actioned" },
      { status: "Closed" },
    ],
    nudges: [
      { at: "2026-10-04", kind: "auto", note: "Day 15 reminder sent", by: "Escalation Tracking Agent" },
      { at: "2026-10-14", kind: "auto", note: "Day 25 reminder sent", by: "Escalation Tracking Agent" },
      {
        at: "2026-10-20",
        kind: "auto-escalated",
        note: "SLA missed · escalated to Commercial Director, AU",
        by: "Escalation Tracking Agent",
      },
    ],
    sourceCaseId: "WOW-TRADE-14",
    sourceModule: "Deductions",
  },
];

/** Escalations a run raises when it reaches its upstream / signal step. */
export type RunEscalationId = "ESC-2621" | "ESC-2622" | "ESC-2625" | "ESC-2631";

export const runEscalationTemplates: Record<
  RunEscalationId,
  Omit<Escalation, "raisedOn" | "status" | "chain" | "nudges">
> = {
  "ESC-2621": {
    id: "ESC-2621",
    accountIds: ["CUST-005"],
    team: "Commercial",
    unit: "Revenue Management",
    subject: "Price file and promotion end date not on Costco item file",
    amountUsd: 150_000,
    raisedBy: "Marcus Hale",
    slaDays: 10,
    sourceCaseId: "DC-710269",
    sourceModule: "Billing",
  },
  "ESC-2622": {
    id: "ESC-2622",
    accountIds: ["CUST-005"],
    team: "Supply chain",
    unit: "Transportation",
    subject: "Lane freight above Costco cap",
    amountUsd: 28_000,
    raisedBy: "Marcus Hale",
    slaDays: 10,
    sourceCaseId: "DC-710269",
    sourceModule: "Billing",
  },
  "ESC-2625": {
    id: "ESC-2625",
    accountIds: ["CUST-006"],
    team: "Commercial",
    unit: "Revenue Management",
    subject: "Buyer price file one revision behind",
    amountUsd: 740,
    raisedBy: "Jim Novak",
    slaDays: 10,
    sourceCaseId: "SO-710249",
    sourceModule: "Order Management",
  },
  "ESC-2631": {
    id: "ESC-2631",
    accountIds: ["CUST-001", "CUST-004", "CUST-006", "CUST-005"],
    team: "Supply chain",
    unit: "DC operations",
    subject: "Ontario DC shortage cluster · 86 valid claims",
    amountUsd: 98_200,
    raisedBy: "Dana Whitfield",
    slaDays: 10,
    sourceCaseId: "NT-2026-W44",
    sourceModule: "Deductions",
  },
};
