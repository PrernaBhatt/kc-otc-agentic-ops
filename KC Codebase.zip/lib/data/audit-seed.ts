/**
 * Audit history from the weeks before the demo: four entries per account, so
 * the Audit trail page reads like a working ledger before any run is played.
 * Session entries (runs, gates) are appended after these.
 */

import { signatureHash, type AuditEntry } from "../audit";

type Seed = Omit<AuditEntry, "entryId" | "signature"> & {
  signer?: { name: string; role: string };
};

const OWNER = "Customer account owner";

const seeds: Seed[] = [
  // Walmart
  { at: "2026-10-06T14:12:00Z", caseId: "DED-PROMO-0981", accountId: "CUST-001", module: "Deductions", actor: { kind: "agent", name: "Promotion Validation Agent", role: "Agent" }, action: "Matched proof of performance to Vistex event", controlRefs: ["1.7.3"], amountUsd: 64_200, evidence: ["Vistex event VX-Q3-2190", "Store scan data"], system: "Vistex" },
  { at: "2026-10-06T15:40:00Z", caseId: "DED-PROMO-0981", accountId: "CUST-001", module: "Deductions", actor: { kind: "person", name: "Rachel Ortiz", role: OWNER }, action: "Approved promotion claim", controlRefs: ["1.7.3"], amountUsd: 64_200, decision: "Approved", evidence: ["Proof of performance", "Promotion agreement"], system: "SAP FSCM", signer: { name: "Rachel Ortiz", role: OWNER } },
  { at: "2026-10-14T09:05:00Z", caseId: "DED-FUND-0955", accountId: "CUST-001", module: "Deductions", actor: { kind: "agent", name: "Fund Allocation Agent", role: "Agent" }, action: "Drafted accrual reclass across two funds", controlRefs: ["1.7.2"], amountUsd: 31_500, evidence: ["Fund balance FB-Q3", "Accrual entry JE-30112"], system: "SAP S/4HANA" },
  { at: "2026-10-14T11:22:00Z", caseId: "DED-FUND-0955", accountId: "CUST-001", module: "Deductions", actor: { kind: "person", name: "Rachel Ortiz", role: OWNER }, action: "Approved fund reclass", controlRefs: ["1.7.2"], amountUsd: 31_500, decision: "Approved", evidence: ["Fund balance", "Accrual entry"], system: "SAP S/4HANA", signer: { name: "Rachel Ortiz", role: OWNER } },
  // Costco
  { at: "2026-10-08T10:30:00Z", caseId: "DC-709914", accountId: "CUST-005", module: "Billing", actor: { kind: "agent", name: "Dispute Investigation Agent", role: "Agent" }, action: "Classified freight short-pay as valid under vendor agreement", controlRefs: ["1.4.3"], amountUsd: 6_400, evidence: ["Costco vendor agreement §7", "TMS settlement"], system: "SAP FSCM" },
  { at: "2026-10-08T13:02:00Z", caseId: "DC-709914", accountId: "CUST-005", module: "Billing", actor: { kind: "person", name: "Marcus Hale", role: OWNER }, action: "Approved credit note", controlRefs: ["1.4.3"], amountUsd: 6_400, decision: "Credit note", evidence: ["Credit memo request", "Root-cause evidence"], system: "SAP FSCM", signer: { name: "Marcus Hale", role: OWNER } },
  { at: "2026-10-21T08:48:00Z", caseId: "DC-710102", accountId: "CUST-005", module: "Billing", actor: { kind: "agent", name: "Dispute Resolution Agent", role: "Agent" }, action: "Drafted charge-back with PricerX backup", controlRefs: ["1.4.4"], amountUsd: 12_750, evidence: ["PricerX PXN-22610", "EDI 832 ack"], system: "SAP FSCM" },
  { at: "2026-10-21T10:15:00Z", caseId: "DC-710102", accountId: "CUST-005", module: "Billing", actor: { kind: "person", name: "Marcus Hale", role: OWNER }, action: "Approved charge-back", controlRefs: ["1.4.4"], amountUsd: 12_750, decision: "Charge-back", evidence: ["Charge-back notice", "Contract evidence"], system: "SAP FSCM", signer: { name: "Marcus Hale", role: OWNER } },
  // Target
  { at: "2026-10-09T16:20:00Z", caseId: "DED-TGT-4410", accountId: "CUST-006", module: "Deductions", actor: { kind: "agent", name: "Deduction Classification Agent", role: "Agent" }, action: "Classified compliance fine as non-trade", controlRefs: [], amountUsd: 2_300, evidence: ["Target vendor manual §4.2"], system: "SAP FSCM" },
  { at: "2026-10-09T17:05:00Z", caseId: "DED-TGT-4410", accountId: "CUST-006", module: "Deductions", actor: { kind: "person", name: "Jim Novak", role: OWNER }, action: "Approved charge-back of compliance fine", controlRefs: ["1.4.4"], amountUsd: 2_300, decision: "Charge-back", evidence: ["ASN timestamp", "Carrier appointment log", "Charge-back notice CB-44102"], system: "SAP FSCM", signer: { name: "Jim Novak", role: OWNER } },
  { at: "2026-10-23T12:40:00Z", caseId: "DED-TGT-4502", accountId: "CUST-006", module: "Deductions", actor: { kind: "agent", name: "Promotion Validation Agent", role: "Agent" }, action: "Confirmed promotion dates in TPM", controlRefs: ["1.7.1"], amountUsd: 18_900, evidence: ["Vistex event VX-Q3-2231"], system: "Vistex" },
  { at: "2026-10-23T14:18:00Z", caseId: "DED-TGT-4502", accountId: "CUST-006", module: "Deductions", actor: { kind: "person", name: "Jim Novak", role: OWNER }, action: "Approved promotion claim", controlRefs: ["1.7.3"], amountUsd: 18_900, decision: "Approved", evidence: ["Proof of performance", "Promotion agreement"], system: "SAP FSCM", signer: { name: "Jim Novak", role: OWNER } },
  // Kroger
  { at: "2026-10-12T09:30:00Z", caseId: "DED-DUP-0874", accountId: "CUST-004", module: "Deductions", actor: { kind: "agent", name: "Duplicate Screening Agent", role: "Agent" }, action: "Matched claim to prior settlement", controlRefs: ["1.7.5"], amountUsd: 22_100, evidence: ["Prior settlement CM-87710", "Claim KR-55102"], system: "SAP FSCM" },
  { at: "2026-10-12T11:02:00Z", caseId: "DED-DUP-0874", accountId: "CUST-004", module: "Deductions", actor: { kind: "person", name: "Aisha Grant", role: OWNER }, action: "Rejected duplicate claim", controlRefs: ["1.7.5"], amountUsd: 22_100, decision: "Rejected", evidence: ["Duplicate screen result", "Prior settlement"], system: "SAP FSCM", signer: { name: "Aisha Grant", role: OWNER } },
  { at: "2026-10-28T15:12:00Z", caseId: "DED-KR-4720", accountId: "CUST-004", module: "Deductions", actor: { kind: "agent", name: "Evidence Matching Agent", role: "Agent" }, action: "Matched shortage to signed POD", controlRefs: [], amountUsd: 4_800, evidence: ["POD SHP-54980"], system: "SAP S/4HANA" },
  { at: "2026-10-28T16:40:00Z", caseId: "DED-KR-4720", accountId: "CUST-004", module: "Deductions", actor: { kind: "person", name: "Aisha Grant", role: OWNER }, action: "Approved credit note for shortage", controlRefs: ["1.4.3"], amountUsd: 4_800, decision: "Credit note", evidence: ["Credit memo request", "POD"], system: "SAP FSCM", signer: { name: "Aisha Grant", role: OWNER } },
  // Tesco
  { at: "2026-10-15T10:10:00Z", caseId: "DED-REB-0611", accountId: "CUST-002", module: "Deductions", actor: { kind: "agent", name: "Rebate Validation Agent", role: "Agent" }, action: "Recomputed tier against volume statement", controlRefs: ["1.7.4"], amountUsd: 48_000, evidence: ["Rebate agreement RA-TES-2026", "Volume statement Q3"], system: "SAP S/4HANA" },
  { at: "2026-10-15T12:35:00Z", caseId: "DED-REB-0611", accountId: "CUST-002", module: "Deductions", actor: { kind: "person", name: "Oliver Shaw", role: OWNER }, action: "Approved rebate at validated tier", controlRefs: ["1.7.4"], amountUsd: 48_000, decision: "Approved in part", evidence: ["Rebate agreement", "Volume statement"], system: "SAP FSCM", signer: { name: "Oliver Shaw", role: OWNER } },
  { at: "2026-10-27T09:00:00Z", caseId: "DED-REBATE-001", accountId: "CUST-002", module: "Deductions", actor: { kind: "agent", name: "Escalation Tracking Agent", role: "Agent" }, action: "Raised ESC-2604 to Key Account UK", controlRefs: [], evidence: ["Amended agreement draft"], system: "SAP FSCM" },
  { at: "2026-10-30T14:25:00Z", caseId: "DED-TES-3390", accountId: "CUST-002", module: "Deductions", actor: { kind: "person", name: "Oliver Shaw", role: OWNER }, action: "Approved credit note for damaged goods", controlRefs: ["1.4.3"], amountUsd: 3_150, decision: "Credit note", evidence: ["Credit memo request", "Carrier damage report"], system: "SAP FSCM", signer: { name: "Oliver Shaw", role: OWNER } },
  // Woolworths
  { at: "2026-09-19T08:30:00Z", caseId: "WOW-TRADE-14", accountId: "CUST-003", module: "Deductions", actor: { kind: "agent", name: "Escalation Tracking Agent", role: "Agent" }, action: "Raised ESC-2611 to Key Account AU", controlRefs: ["1.7.3"], amountUsd: 418_500, evidence: ["14 open trade claims"], system: "SAP FSCM" },
  { at: "2026-10-20T08:30:00Z", caseId: "WOW-TRADE-14", accountId: "CUST-003", module: "Deductions", actor: { kind: "agent", name: "Escalation Tracking Agent", role: "Agent" }, action: "SLA missed · escalated to Commercial Director, AU", controlRefs: ["1.7.3"], amountUsd: 418_500, evidence: ["ESC-2611 reminder log"], system: "SAP FSCM" },
  { at: "2026-10-17T11:45:00Z", caseId: "DED-WOW-2087", accountId: "CUST-003", module: "Deductions", actor: { kind: "agent", name: "Promotion Validation Agent", role: "Agent" }, action: "Confirmed promotion terms in TPM", controlRefs: ["1.7.1"], amountUsd: 26_400, evidence: ["CAS deal CAS-AU-7712"], system: "CAS" },
  { at: "2026-10-17T13:30:00Z", caseId: "DED-WOW-2087", accountId: "CUST-003", module: "Deductions", actor: { kind: "person", name: "Mia Kelly", role: OWNER }, action: "Approved promotion claim", controlRefs: ["1.7.3"], amountUsd: 26_400, decision: "Approved", evidence: ["Proof of performance", "Promotion agreement"], system: "SAP FSCM", signer: { name: "Mia Kelly", role: OWNER } },
];

export const auditSeed: AuditEntry[] = seeds.map(({ signer, ...s }, i) => ({
  ...s,
  entryId: `AUD-${String(40100 + i)}`,
  signature: signer
    ? {
        method: "typed" as const,
        signer: signer.name,
        role: signer.role,
        signedAt: s.at,
        hash: signatureHash(signer.name, s.at, s.caseId),
        typed: signer.name,
      }
    : undefined,
}));
