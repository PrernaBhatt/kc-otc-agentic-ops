export interface Customer {
  customerId: string;
  name: string;
  segment: string;
  region: string;
  creditRating: string;
  creditLimit: number;
  currentExposure: number;
  relationshipTier: string;
  churnRiskScore: number;
  ltvScore: number;
}

export interface OrderLine {
  orderLineId: string;
  sku: string;
  productName: string;
  qty: number;
  unitPrice: number;
  lineValue: number;
  loopLineFlag: boolean;
  priceValidated: boolean;
  taxValidated: boolean;
}

export type OrderStatus = "Hold" | "Processing" | "Blocked" | "Fulfilled";

export interface Order {
  orderId: string;
  customerId: string;
  customerName: string;
  orderDate: string;
  totalValue: number;
  status: OrderStatus;
  holdReason: string | null;
  loopOrderFlag: boolean;
  decisionId: string | null;
  lineItems: OrderLine[];
}

export type InvoiceStatus = "Pending" | "Sent" | "Overdue" | "Paid";

export interface Invoice {
  invoiceId: string;
  orderId: string;
  customerId: string;
  customerName: string;
  invoiceDate: string;
  dueDate: string;
  amount: number;
  status: InvoiceStatus;
}

export interface DecisionOption {
  id: string;
  name: string;
  type: "Balanced" | "Conservative" | "Aggressive";
  action: string;
  conditions: string[];
  riskDelta: number;
  ltvImpact: number;
  cashFlowEffect: number;
  confidence: number;
}

export interface Decision {
  decisionId: string;
  orderId: string;
  selectedOption: string;
  riskScore: number;
  ltvScore: number;
  propensityScore: number;
  exposureDelta: number;
  guardrailsApplied: string[];
  approvedBy: string | null;
  approvedAt: string | null;
  options: DecisionOption[];
}

export interface ExceptionRecord {
  id: string;
  type: string;
  orderId: string;
  customerId: string;
  customerName: string;
  description: string;
  severity: "High" | "Medium" | "Low";
  status: "Open" | "In Progress" | "Resolved";
  createdAt: string;
  assignedTo: string;
}

export interface AgentActivity {
  id: string;
  agentName: string;
  agentType: string;
  status: "complete" | "processing" | "pending";
  message: string;
  timestamp: string;
}

export interface OrderVolumePoint {
  month: string;
  orders: number;
  automated: number;
  manual: number;
}

export interface ExceptionBreakdownPoint {
  name: string;
  value: number;
  color: string;
}

export interface DsoPoint {
  month: string;
  dso: number;
  target: number;
}

export interface AgentPerformancePoint {
  agent: string;
  processed: number;
  success: number;
}
