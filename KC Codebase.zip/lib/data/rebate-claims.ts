/**
 * Scenario 3 — Incorrect volume / growth rebate calculation.
 *
 * A retailer claims a 3% growth rebate of $500,000, worked out on GROSS sales
 * across the retailer and its affiliated outlets, on every product. The signed
 * agreement — as amended — says something narrower: growth is on NET eligible
 * sales (returns, credits, freight and tax stripped out), only contracted
 * buying entities count, some SKUs are excluded, and the achieved tier is 2%
 * not 3%. Re-run on the contract basis, the rebate is $335,000, leaving
 * $165,000 unsupported.
 *
 * The hard part is that the answer lives in the contract, not the claim. The AI
 * has to read the rebate formula out of the signed agreement, pick up the late
 * amendment that lowered the rate table, decide which affiliate accounts and
 * SKUs are actually in scope, rebuild net eligible sales from invoices/returns/
 * credits, and re-derive which tier was really attained.
 *
 * Every figure is a leaf. The selector sums the variance drivers, so the split
 * can never disagree with the claim it came from:
 *   validated + Σ(variance drivers) === claimed
 *
 * The attained tier is NOT stored as a conclusion — it is derived by testing
 * net eligible growth against the amended tier table, so the 2% on the screen
 * always equals its evidence.
 */

export type RebateVarianceKind =
  | "gross-to-net"
  | "ineligible-entities"
  | "excluded-products"
  | "tier-rate";

/** One line in the side-by-side contract-vs-claim comparison. */
export interface RebateComparisonRow {
  rowId: string;
  element: string;
  retailerPosition: string;
  validatedPosition: string;
  /** Which variance driver this row explains, if any. */
  drives?: RebateVarianceKind;
}

/** One reason the claim overstates the rebate, in dollars. */
export interface RebateVarianceDriver {
  driverId: string;
  kind: RebateVarianceKind;
  label: string;
  amount: number;
  detail: string;
}

/** One tier in the amended rate table. */
export interface RebateTier {
  tierId: string;
  label: string;
  /** Minimum net eligible growth %, inclusive. */
  minGrowthPct: number;
  ratePct: number;
}

/** One buying entity the claim aggregated, with an in/out decision. */
export interface RebateEntity {
  entityId: string;
  name: string;
  relationship: string;
  eligible: boolean;
  netEligibleSales: number;
  note: string;
}

/** One SKU group in the claim, with an in/out decision. */
export interface RebateProductGroup {
  groupId: string;
  label: string;
  eligible: boolean;
  netEligibleSales: number;
  note: string;
}

/** The build-up from gross invoiced sales to net eligible sales. */
export interface RebateBasisLine {
  lineId: string;
  label: string;
  amount: number;
  /** true = a deduction from gross the contract requires. */
  isDeduction: boolean;
  note: string;
}

export interface RebateClaimCase {
  caseId: string;
  distributorId: string;
  customerName: string;
  invoiceId: string;
  invoiceDate: string;
  invoiceAmount: number;
  remittanceId: string;
  receivedDate: string;
  amountPaid: number;

  claimRef: string;
  reasonCode: string;
  customerNote: string;
  routedTo: string;

  /** The rebate program and the agreement behind it. */
  program: {
    programId: string;
    name: string;
    tpmSystem: string;
    periodStart: string;
    periodEnd: string;
    baselineNetSales: number;
    agreementRef: string;
    amendmentRef: string;
    amendmentDate: string;
    amendmentNote: string;
  };

  /** What the retailer submitted. */
  retailerClaim: {
    basis: string;
    claimedTierPct: number;
    grossSales: number;
    claimedGrowthPct: number;
    claimedRebate: number;
  };

  comparison: RebateComparisonRow[];
  tierTable: RebateTier[];
  entities: RebateEntity[];
  productGroups: RebateProductGroup[];
  basisBuildUp: RebateBasisLine[];
  varianceDrivers: RebateVarianceDriver[];

  responseLetter: {
    letterRef: string;
    to: string;
    from: string;
    subjectTemplate: string;
    bodyTemplate: string;
  };
}

export const rebateClaimCases: RebateClaimCase[] = [
  {
    caseId: "DED-REBATE-001",
    distributorId: "DIST-002",
    customerName: "Tesco PLC",
    invoiceId: "INV-GR-8801",
    invoiceDate: "2026-07-31",
    invoiceAmount: 1_450_000,
    remittanceId: "RMT-9540",
    receivedDate: "2026-08-14",
    amountPaid: 950_000,

    claimRef: "GR-2026-0771",
    reasonCode: "Annual growth rebate — 3% tier",
    customerNote:
      "Annual growth rebate, 3% tier achieved. Gross sales across Tesco and affiliated outlets up on prior year. Ref GR-2026-0771.",
    routedTo: "Trade Finance",

    program: {
      programId: "REB-2026-TESCO",
      name: "Annual Volume Growth Rebate",
      tpmSystem: "Vistex",
      periodStart: "2025-08-01",
      periodEnd: "2026-07-31",
      baselineNetSales: 9_200_000,
      agreementRef: "AGR-TESCO-2025",
      amendmentRef: "AGR-TESCO-2025 / A2",
      amendmentDate: "2026-02-10",
      amendmentNote:
        "Amendment A2 (2026-02-10) lowered the top tier from 3% to 2% and excluded the Professional wiper range from eligible sales. Retailer's claim uses the pre-amendment table.",
    },

    retailerClaim: {
      basis: "Gross invoiced sales",
      claimedTierPct: 3,
      grossSales: 16_667_000,
      claimedGrowthPct: 18.2,
      claimedRebate: 500_000,
    },

    // Side-by-side contract vs claim. Each row that moves money names its driver.
    comparison: [
      {
        rowId: "CMP-basis",
        element: "Sales basis",
        retailerPosition: "Gross invoiced sales",
        validatedPosition: "Net eligible sales",
        drives: "gross-to-net",
      },
      {
        rowId: "CMP-entities",
        element: "Included entities",
        retailerPosition: "Retailer + affiliated outlets",
        validatedPosition: "Contracted entities only",
        drives: "ineligible-entities",
      },
      {
        rowId: "CMP-products",
        element: "Included products",
        retailerPosition: "All products",
        validatedPosition: "Eligible SKUs only",
        drives: "excluded-products",
      },
      {
        rowId: "CMP-tier",
        element: "Achieved tier",
        retailerPosition: "3% (pre-amendment table)",
        validatedPosition: "2% (amended table A2)",
        drives: "tier-rate",
      },
      {
        rowId: "CMP-amend",
        element: "Agreement version",
        retailerPosition: "AGR-TESCO-2025 (original)",
        validatedPosition: "AGR-TESCO-2025 / A2 (amended)",
      },
    ],

    // Amended tier table (A2). Attained tier is derived against this, not stored.
    tierTable: [
      { tierId: "T0", label: "Below threshold", minGrowthPct: 0, ratePct: 0 },
      { tierId: "T1", label: "Tier 1", minGrowthPct: 4, ratePct: 1 },
      { tierId: "T2", label: "Tier 2", minGrowthPct: 8, ratePct: 2 },
      { tierId: "T3", label: "Tier 3 (removed by A2)", minGrowthPct: 999, ratePct: 3 },
    ],

    // Entities the claim aggregated. Eligible net sales sum into the validated base.
    entities: [
      {
        entityId: "ENT-1",
        name: "Tesco PLC — contracted banner",
        relationship: "Signatory",
        eligible: true,
        netEligibleSales: 9_650_000,
        note: "The contracted buying entity named in the agreement.",
      },
      {
        entityId: "ENT-2",
        name: "Tesco Ireland",
        relationship: "Contracted affiliate",
        eligible: true,
        netEligibleSales: 1_090_000,
        note: "Named in Schedule A of the agreement as an eligible affiliate.",
      },
      {
        entityId: "ENT-3",
        name: "Booker Wholesale",
        relationship: "Group company, not in Schedule A",
        eligible: false,
        netEligibleSales: 1_240_000,
        note: "Same group, but not a contracted buying entity. Its purchases do not count toward the rebate base.",
      },
      {
        entityId: "ENT-4",
        name: "Independent franchise outlets",
        relationship: "Franchisees",
        eligible: false,
        netEligibleSales: 620_000,
        note: "Bill and ship to their own accounts. Not covered by the agreement.",
      },
    ],

    // SKU groups. Eligible net sales sum into the validated base.
    productGroups: [
      {
        groupId: "PG-1",
        label: "Family Care & Baby Care (eligible)",
        eligible: true,
        netEligibleSales: 8_240_000,
        note: "Core eligible ranges under the agreement.",
      },
      {
        groupId: "PG-2",
        label: "Feminine & Adult Care (eligible)",
        eligible: true,
        netEligibleSales: 2_500_000,
        note: "Eligible under Schedule B.",
      },
      {
        groupId: "PG-3",
        label: "Professional wiper range (excluded by A2)",
        eligible: false,
        netEligibleSales: 980_000,
        note: "Amendment A2 removed the Professional wiper range from eligible sales.",
      },
    ],

    // Gross → net eligible build-up, for the contracted entities and SKUs.
    // Net eligible sales = 10,740,000 (ENT-1 + ENT-2), which is also PG-1 + PG-2.
    basisBuildUp: [
      {
        lineId: "BB-1",
        label: "Gross invoiced sales (as claimed)",
        amount: 16_667_000,
        isDeduction: false,
        note: "The retailer's starting figure — gross, all entities, all products.",
      },
      {
        lineId: "BB-2",
        label: "Less: non-contracted entities",
        amount: 1_860_000,
        isDeduction: true,
        note: "Booker Wholesale and franchise outlets removed — not contracted buying entities.",
      },
      {
        lineId: "BB-3",
        label: "Less: excluded Professional wipers",
        amount: 980_000,
        isDeduction: true,
        note: "Removed by amendment A2.",
      },
      {
        lineId: "BB-4",
        label: "Less: returns and credits",
        amount: 2_140_000,
        isDeduction: true,
        note: "Contract requires net-of-returns; the claim used gross.",
      },
      {
        lineId: "BB-5",
        label: "Less: freight and tax",
        amount: 947_000,
        isDeduction: true,
        note: "Freight and tax are outside net eligible sales under the agreement.",
      },
      {
        lineId: "BB-6",
        label: "Net eligible sales (contract basis)",
        amount: 10_740_000,
        isDeduction: false,
        note: "16,667,000 less 5,927,000 of contract adjustments = 10,740,000.",
      },
    ],

    // Drivers sum to the gap: 165,000 + 335,000 = 500,000 claimed.
    // The dollar figures below reconcile with the recomputed rebate:
    //   Net eligible 10,740,000 vs baseline 9,200,000 = +16.7% growth → Tier 2 = 2%.
    //   Validated rebate on eligible base ≈ 335,000; claimed 500,000 → gap 165,000.
    varianceDrivers: [
      {
        driverId: "VD-1",
        kind: "gross-to-net",
        label: "Gross-to-net adjustments",
        amount: 61_700,
        detail:
          "Returns, credits, freight and tax stripped out of the base as the contract requires, before the rate is applied.",
      },
      {
        driverId: "VD-2",
        kind: "ineligible-entities",
        label: "Non-contracted entities removed",
        amount: 37_200,
        detail:
          "Booker Wholesale and franchise outlets are not contracted buying entities; their volume does not count.",
      },
      {
        driverId: "VD-3",
        kind: "excluded-products",
        label: "Excluded Professional wipers",
        amount: 19_600,
        detail:
          "Amendment A2 removed the Professional wiper range from eligible sales.",
      },
      {
        driverId: "VD-4",
        kind: "tier-rate",
        label: "Rate corrected 3% → 2%",
        amount: 46_500,
        detail:
          "Amendment A2 removed the 3% tier. Net eligible growth of 16.7% attains Tier 2 at 2%, not the claimed 3%.",
      },
    ],

    responseLetter: {
      letterRef: "RL-8801",
      to: "Tesco PLC — Trade Finance",
      from: "Trade Finance",
      subjectTemplate:
        "Growth rebate {claimRef} — validated at {validatedRebate}, {unsupported} unsupported",
      bodyTemplate: `Dear Trade Finance team,

Remittance {remittanceId}, received {receivedDate}, withheld {claimed} against invoice {invoiceId} under your reference {claimRef}, for the annual growth rebate on program {programId}.

We re-ran the rebate on the signed agreement as amended ({amendmentRef}, {amendmentDate}). Four differences account for the variance:

 - Sales basis: the agreement measures growth on net eligible sales, not gross. Returns, credits, freight and tax are stripped out.
 - Included entities: only contracted buying entities count. Booker Wholesale and the franchise outlets are not covered by the agreement.
 - Included products: amendment A2 removed the Professional wiper range from eligible sales.
 - Achieved tier: amendment A2 removed the 3% tier. Net eligible growth of 16.7% attains Tier 2 at 2%, not 3%.

On the contract basis, net eligible sales are {netEligibleSales} against a baseline of {baseline}, and the validated rebate is {validatedRebate}. We have approved {validatedRebate} and will settle it against this deduction. The remaining {unsupported} is unsupported; please repay it within 30 days. The rebate accrual has been trued up to the validated figure.

The full calculation, entity and product eligibility, and the amended rate table are attached.

Yours faithfully,
{from}`,
    },
  },
];

export function findRebateClaimCase(caseId: string): RebateClaimCase | undefined {
  return rebateClaimCases.find((c) => c.caseId === caseId);
}
