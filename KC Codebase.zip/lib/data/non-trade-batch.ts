/**
 * Non-trade batch NT-2026-W44: one week of low-value deduction claims from
 * EDI 820 and the customer portals. Agents judge them by policy; only the
 * exceptions go to a person. Totals tie out in `non-trade-selectors.ts`.
 */

export type NonTradeCategory = "shortage" | "damage" | "pricing" | "compliance" | "freight";
export type NonTradeOutcome = "valid" | "invalid" | "exception";

export interface CountValue {
  count: number;
  usd: number;
}

export interface NonTradeCategoryRow {
  key: NonTradeCategory;
  label: string;
  rule: string;
  evidence: string;
  total: CountValue;
  valid: CountValue;
  invalid: CountValue;
  exception: CountValue;
}

export interface NonTradeSource {
  accountId: string;
  customer: string;
  channel: string;
  claims: number;
  usd: number;
}

export interface SplitOutClaim {
  id: string;
  category: NonTradeCategory;
  accountId: string;
  customer: string;
  reasonCode: string;
  title: string;
  usd: number;
  ageDays: number;
  recommendation: "credit" | "charge-back";
  controlRef: string;
  /** Only the featured exception carries its full workup. */
  detail?: {
    finding: string;
    evidence: { label: string; system: string; detail: string }[];
    rationale: string;
  };
}

export const NON_TRADE_BATCH = {
  batchId: "NT-2026-W44",
  week: "2026-10-26 – 2026-11-01",
  postedOn: "2026-11-05",
  policyRef: "NT-POL-2026.3",
  lead: "Dana Whitfield",
  coSignAccountId: "CUST-001",
  escalationId: "ESC-2631" as const,
  mergedEscalationId: "ESC-2601",
  sources: [
    { accountId: "CUST-001", customer: "Walmart", channel: "EDI 820 + Retail Link", claims: 128, usd: 214_600 },
    { accountId: "CUST-004", customer: "Kroger", channel: "EDI 820", claims: 74, usd: 98_300 },
    { accountId: "CUST-006", customer: "Target", channel: "Partners Online", claims: 62, usd: 87_900 },
    { accountId: "CUST-005", customer: "Costco", channel: "EDI 820", claims: 48, usd: 85_600 },
  ] satisfies NonTradeSource[],
  categories: [
    {
      key: "shortage",
      label: "Shortage",
      rule: "Receipt quantity vs ASN and signed POD",
      evidence: "POD, ASN timestamp",
      total: { count: 118, usd: 142_600 },
      valid: { count: 86, usd: 98_200 },
      invalid: { count: 28, usd: 38_900 },
      exception: { count: 4, usd: 5_500 },
    },
    {
      key: "damage",
      label: "Damage",
      rule: "Carrier exception on the bill of lading",
      evidence: "Carrier claim, BOL",
      total: { count: 64, usd: 78_300 },
      valid: { count: 51, usd: 56_100 },
      invalid: { count: 11, usd: 18_700 },
      exception: { count: 2, usd: 3_500 },
    },
    {
      key: "pricing",
      label: "Pricing",
      rule: "Unit price gap within $2.00 tolerance",
      evidence: "Contract price, invoice line",
      total: { count: 52, usd: 31_200 },
      valid: { count: 40, usd: 24_000 },
      invalid: { count: 12, usd: 7_200 },
      exception: { count: 0, usd: 0 },
    },
    {
      key: "compliance",
      label: "Compliance",
      rule: "Fine matches the retailer manual and our ASN",
      evidence: "Vendor manual, ASN, appointment log",
      total: { count: 61, usd: 183_000 },
      valid: { count: 19, usd: 12_600 },
      invalid: { count: 38, usd: 151_400 },
      exception: { count: 4, usd: 19_000 },
    },
    {
      key: "freight",
      label: "Freight",
      rule: "Lane rate vs customer freight cap",
      evidence: "TMS settlement, freight agreement",
      total: { count: 17, usd: 51_300 },
      valid: { count: 8, usd: 7_500 },
      invalid: { count: 7, usd: 35_400 },
      exception: { count: 2, usd: 8_400 },
    },
  ] satisfies NonTradeCategoryRow[],
  /** Valid shortages at one DC become the supply-chain signal. */
  signal: {
    title: "Ontario DC shortage cluster",
    validShortages: 86,
    usd: 98_200,
  },
};

export const SPLIT_OUT_CLAIMS: SplitOutClaim[] = [
  {
    id: "NT-W44-0117",
    category: "compliance",
    accountId: "CUST-001",
    customer: "Walmart",
    reasonCode: "OTIF fine",
    title: "OTIF fine on DC 6094 delivery",
    usd: 9_800,
    ageDays: 6,
    recommendation: "charge-back",
    controlRef: "1.4.4",
    detail: {
      finding: "Walmart moved the receiving appointment from 10-27 to 10-29 after our truck was booked. The delivery arrived on the original slot.",
      evidence: [
        { label: "Appointment log APT-6094-1027", system: "Retail Link", detail: "Rescheduled by Walmart DC 6094 on 10-26 18:40" },
        { label: "ASN 856-77120", system: "SAP S/4HANA", detail: "Shipped 10-25, ETA 10-27 06:00" },
        { label: "Signed POD SHP-61204", system: "SAP TM", detail: "Arrived 10-27 05:52, gate check-in stamped" },
        { label: "Walmart OTIF policy §3.4", system: "SharePoint", detail: "Supplier not liable when the retailer moves the slot" },
      ],
      rationale: "The late receipt was caused by Walmart's own reschedule, so the fine is invalid under §3.4. Charge back the full amount.",
    },
  },
  { id: "NT-W44-0124", category: "compliance", accountId: "CUST-001", customer: "Walmart", reasonCode: "OTIF fine", title: "OTIF fine, split shipment DC 7035", usd: 4_200, ageDays: 6, recommendation: "charge-back", controlRef: "1.4.4" },
  { id: "NT-W44-0131", category: "compliance", accountId: "CUST-001", customer: "Walmart", reasonCode: "Label non-compliance", title: "Pallet label fine, missing GS1 barcode", usd: 3_100, ageDays: 5, recommendation: "credit", controlRef: "1.4.3" },
  { id: "NT-W44-0139", category: "compliance", accountId: "CUST-001", customer: "Walmart", reasonCode: "ASN timing", title: "ASN sent after departure", usd: 1_900, ageDays: 5, recommendation: "credit", controlRef: "1.4.3" },
  { id: "NT-W44-0042", category: "shortage", accountId: "CUST-004", customer: "Kroger", reasonCode: "Shortage", title: "Short 14 cases, POD unsigned", usd: 1_850, ageDays: 7, recommendation: "credit", controlRef: "1.4.3" },
  { id: "NT-W44-0058", category: "shortage", accountId: "CUST-006", customer: "Target", reasonCode: "Shortage", title: "Short 9 cases, ASN shows full load", usd: 1_400, ageDays: 6, recommendation: "charge-back", controlRef: "1.4.4" },
  { id: "NT-W44-0063", category: "shortage", accountId: "CUST-005", customer: "Costco", reasonCode: "Shortage", title: "Short 1 pallet, depot transfer", usd: 1_250, ageDays: 6, recommendation: "credit", controlRef: "1.4.3" },
  { id: "NT-W44-0071", category: "shortage", accountId: "CUST-001", customer: "Walmart", reasonCode: "Shortage", title: "Short 8 cases, recount pending", usd: 1_000, ageDays: 5, recommendation: "credit", controlRef: "1.4.3" },
  { id: "NT-W44-0088", category: "damage", accountId: "CUST-004", customer: "Kroger", reasonCode: "Concealed damage", title: "Crushed cases found after receipt", usd: 2_100, ageDays: 7, recommendation: "credit", controlRef: "1.4.3" },
  { id: "NT-W44-0094", category: "damage", accountId: "CUST-006", customer: "Target", reasonCode: "Damage", title: "Water damage, no carrier note", usd: 1_400, ageDays: 4, recommendation: "charge-back", controlRef: "1.4.4" },
  { id: "NT-W44-0102", category: "freight", accountId: "CUST-005", customer: "Costco", reasonCode: "Freight", title: "Fuel surcharge above Costco cap", usd: 5_200, ageDays: 6, recommendation: "credit", controlRef: "1.4.3" },
  { id: "NT-W44-0109", category: "freight", accountId: "CUST-004", customer: "Kroger", reasonCode: "Freight", title: "Detention billed on a live unload", usd: 3_200, ageDays: 4, recommendation: "charge-back", controlRef: "1.4.4" },
];

export const FEATURED_SPLIT_OUT_ID = "NT-W44-0117";
