export interface Product {
  sku: string;
  name: string;
  category: string;
  unitPrice: number;
  regulated: boolean;
  lotControlled: boolean;
  allocationControlled: boolean;
  /** Monthly allocation limit in units when allocation-controlled */
  monthlyAllocationUnits?: number;
}

/**
 * Mixed catalog: consumer paper lines (existing orders) plus regulated
 * personal-care consumables (regulatory use cases). Regulated items drive the
 * Regulatory Check stage, quality-hold exceptions, and allocation rules.
 */
export const products: Product[] = [
  { sku: "SKU-A100", name: "2-Ply Facial Tissue - Cube", category: "Family Care", unitPrice: 45, regulated: false, lotControlled: false, allocationControlled: false },
  { sku: "SKU-B200", name: "Bath Tissue - Standard Roll", category: "Family Care", unitPrice: 125, regulated: false, lotControlled: false, allocationControlled: false },
  { sku: "SKU-B210", name: "Bathroom Tissue - Ultra Soft", category: "Family Care", unitPrice: 140, regulated: false, lotControlled: false, allocationControlled: false },
  { sku: "SKU-C300", name: "Kitchen Paper Towels - Roll", category: "Family Care", unitPrice: 550, regulated: false, lotControlled: false, allocationControlled: false },
  { sku: "SKU-D400", name: "Baby Wipes - Refill", category: "Baby & Child Care", unitPrice: 25, regulated: false, lotControlled: false, allocationControlled: false },
  { sku: "SKU-E500", name: "Baby Diapers - Size 3", category: "Baby & Child Care", unitPrice: 100, regulated: false, lotControlled: false, allocationControlled: false },
  { sku: "SKU-F600", name: "Training Pants - 4T", category: "Baby & Child Care", unitPrice: 180, regulated: false, lotControlled: false, allocationControlled: false },
  { sku: "SKU-G700", name: "Hard Roll Towels - White", category: "Professional", unitPrice: 200, regulated: false, lotControlled: false, allocationControlled: false },
  { sku: "SKU-H800", name: "Disinfecting Wet Wipes - Bucket", category: "Professional", unitPrice: 562.5, regulated: false, lotControlled: false, allocationControlled: false },
  { sku: "SKU-I900", name: "Industrial Wipers - Jumbo Roll", category: "Professional", unitPrice: 550, regulated: false, lotControlled: false, allocationControlled: false },
  { sku: "SKU-K110", name: "Adult Incontinence Briefs - Heavy", category: "Adult Care", unitPrice: 150, regulated: true, lotControlled: true, allocationControlled: true, monthlyAllocationUnits: 5000 },
  { sku: "SKU-K220", name: "Feminine Care Pads - Ultra Thin", category: "Feminine Care", unitPrice: 110, regulated: true, lotControlled: true, allocationControlled: false },
  { sku: "SKU-K330", name: "Surgical Face Masks - ASTM Level 2", category: "Professional", unitPrice: 85, regulated: true, lotControlled: true, allocationControlled: true, monthlyAllocationUnits: 10000 },
  { sku: "SKU-K440", name: "Adult Protective Underwear - Max", category: "Adult Care", unitPrice: 60, regulated: true, lotControlled: false, allocationControlled: false },
];

export function findProduct(sku: string): Product | undefined {
  return products.find((p) => p.sku === sku);
}
