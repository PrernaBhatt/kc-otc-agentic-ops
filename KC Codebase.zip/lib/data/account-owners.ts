/**
 * One owner per customer account (K-C's North America model). Agents do the
 * work behind the owner; the owner signs every gate on their account, and the
 * Controller co-signs anything above the owner's delegated limit.
 */

export type Region = "North America" | "EMEA" | "APAC";

export interface Person {
  ownerId: string;
  name: string;
  initials: string;
  role: string;
}

export interface AccountOwnerRecord {
  accountId: string;
  accountName: string;
  shortName: string;
  region: Region;
  owner: Person;
  backupOwnerId: string;
  delegatedLimits: { creditNoteUsd: number; chargeBackUsd: number };
  /** Work items this week: handled by agents vs. by the owner. */
  workload: { agents: number; owner: number };
  /** Agents active on the account right now. */
  agentsActive: number;
  /** Average age of open trade claims, by month (Woolworths only). */
  tradeClaimAgeTrend?: { month: string; days: number }[];
}

const LIMITS = { creditNoteUsd: 50_000, chargeBackUsd: 100_000 };
const OWNER_ROLE = "Customer account owner";

export const CONTROLLER: Person = {
  ownerId: "OWN-CTRL",
  name: "L. Chen",
  initials: "LC",
  role: "Controller",
};

export const DEDUCTIONS_LEAD: Person = {
  ownerId: "OWN-DED",
  name: "Dana Whitfield",
  initials: "DW",
  role: "Credit & Deductions Lead, NA",
};

/** Signs the logistics gates: premium freight and delivery plan changes. */
export const TRANSPORT_LEAD: Person = {
  ownerId: "OWN-TRN",
  name: "Priya Raman",
  initials: "PR",
  role: "Transportation Manager, NA",
};

/** Premium freight the Transportation Manager can approve alone, per shipment. */
export const PREMIUM_FREIGHT_LIMIT_USD = 2_500;

export const accountOwners: AccountOwnerRecord[] = [
  {
    accountId: "CUST-001",
    accountName: "Walmart Inc.",
    shortName: "Walmart",
    region: "North America",
    owner: { ownerId: "OWN-RO", name: "Rachel Ortiz", initials: "RO", role: OWNER_ROLE },
    backupOwnerId: "OWN-AG",
    delegatedLimits: LIMITS,
    workload: { agents: 398, owner: 14 },
    agentsActive: 7,
  },
  {
    accountId: "CUST-005",
    accountName: "Costco Wholesale Corp.",
    shortName: "Costco",
    region: "North America",
    owner: { ownerId: "OWN-MH", name: "Marcus Hale", initials: "MH", role: OWNER_ROLE },
    backupOwnerId: "OWN-JN",
    delegatedLimits: LIMITS,
    workload: { agents: 277, owner: 9 },
    agentsActive: 6,
  },
  {
    accountId: "CUST-006",
    accountName: "Target Corporation",
    shortName: "Target",
    region: "North America",
    owner: { ownerId: "OWN-JN", name: "Jim Novak", initials: "JN", role: OWNER_ROLE },
    backupOwnerId: "OWN-MH",
    delegatedLimits: LIMITS,
    workload: { agents: 192, owner: 6 },
    agentsActive: 5,
  },
  {
    accountId: "CUST-004",
    accountName: "Kroger Co.",
    shortName: "Kroger",
    region: "North America",
    owner: { ownerId: "OWN-AG", name: "Aisha Grant", initials: "AG", role: OWNER_ROLE },
    backupOwnerId: "OWN-RO",
    delegatedLimits: LIMITS,
    workload: { agents: 170, owner: 6 },
    agentsActive: 5,
  },
  {
    accountId: "CUST-002",
    accountName: "Tesco PLC",
    shortName: "Tesco",
    region: "EMEA",
    owner: { ownerId: "OWN-OS", name: "Oliver Shaw", initials: "OS", role: OWNER_ROLE },
    backupOwnerId: "OWN-MK",
    delegatedLimits: LIMITS,
    workload: { agents: 119, owner: 5 },
    agentsActive: 4,
  },
  {
    accountId: "CUST-003",
    accountName: "Woolworths Group",
    shortName: "Woolworths",
    region: "APAC",
    owner: { ownerId: "OWN-MK", name: "Mia Kelly", initials: "MK", role: OWNER_ROLE },
    backupOwnerId: "OWN-OS",
    delegatedLimits: LIMITS,
    workload: { agents: 80, owner: 8 },
    agentsActive: 4,
    tradeClaimAgeTrend: [
      { month: "Jul", days: 21 },
      { month: "Aug", days: 29 },
      { month: "Sep", days: 36 },
      { month: "Oct", days: 44 },
    ],
  },
];

/** Finds an account by id, full name, or any name that contains its short name. */
export function findAccount(nameOrId: string): AccountOwnerRecord | undefined {
  const key = nameOrId.toLowerCase();
  return accountOwners.find(
    (a) =>
      a.accountId.toLowerCase() === key ||
      a.accountName.toLowerCase() === key ||
      key.includes(a.shortName.toLowerCase())
  );
}

export function findPerson(ownerId: string): Person | undefined {
  if (ownerId === CONTROLLER.ownerId) return CONTROLLER;
  if (ownerId === DEDUCTIONS_LEAD.ownerId) return DEDUCTIONS_LEAD;
  if (ownerId === TRANSPORT_LEAD.ownerId) return TRANSPORT_LEAD;
  return accountOwners.find((a) => a.owner.ownerId === ownerId)?.owner;
}
