/**
 * OTIF at risk: the shipments the agents predict will miss their window, and
 * the three that need a decision today. Times are local to the receiving
 * site, "YYYY-MM-DD HH:MM". Derived figures live in lib/shipment-selectors.ts.
 */

export type RiskLane = "pre" | "post";
export type RiskLevel = "high" | "medium" | "low";
export type ShipmentRunKind = "appointment" | "premium" | "milkrun";
/** The point in the order thread where the agent caught the risk. */
export type DetectedAt = "Appointment" | "Carrier tender" | "Picking" | "Loading" | "Departure" | "In transit";

export interface RiskTrack {
  axisFrom: string;
  axisTo: string;
  windowFrom: string;
  windowTo: string;
  /** Predicted arrival, or the first bookable slot when none exists in the window. */
  eta: string;
  windowLabel: string;
  etaLabel: string;
}

export interface RiskRow {
  caseId: string;
  lane: RiskLane;
  level: RiskLevel;
  customer: string;
  accountId: string;
  shipTo: string;
  orderRef: string;
  valueUsd: number;
  signal: string;
  system: string;
  detectedAt: DetectedAt;
  /** Orders on the shipment; a milk run carries one per stop. */
  orders: number;
  track: RiskTrack;
  run?: ShipmentRunKind;
  watch?: { agent: string; nextCheck: string };
  resolvedLabel?: string;
}

export const RISK_ROWS: RiskRow[] = [
  {
    caseId: "SHP-58201",
    lane: "pre",
    level: "high",
    customer: "Walmart",
    accountId: "CUST-001",
    shipTo: "RDC 6094, Buckeye, AZ",
    orderRef: "SO-710264",
    valueUsd: 126_400,
    signal: "No receiving slot inside the OTIF window",
    system: "Walmart delivery scheduling portal",
    detectedAt: "Appointment",
    orders: 1,
    track: {
      axisFrom: "2026-08-24 00:00",
      axisTo: "2026-08-28 00:00",
      windowFrom: "2026-08-24 00:00",
      windowTo: "2026-08-27 00:00",
      eta: "2026-08-27 06:00",
      windowLabel: "Mon 08-24 → MABD Wed 08-26",
      etaLabel: "First slot Thu 06:00",
    },
    run: "appointment",
    resolvedLabel: "Tue 22:00 slot · TMS replanned",
  },
  {
    caseId: "SHP-58207",
    lane: "pre",
    level: "high",
    customer: "Kroger",
    accountId: "CUST-004",
    shipTo: "DC 024, Forest Park, GA",
    orderRef: "SO-710265",
    valueUsd: 98_800,
    signal: "Tender rejected; TMS replan lands a day late",
    system: "SAP TM",
    detectedAt: "Carrier tender",
    orders: 1,
    track: {
      axisFrom: "2026-08-25 12:00",
      axisTo: "2026-08-27 12:00",
      windowFrom: "2026-08-26 08:00",
      windowTo: "2026-08-26 09:00",
      eta: "2026-08-27 06:00",
      windowLabel: "Wed 08:00–09:00",
      etaLabel: "ETA Thu 06:00",
    },
    run: "premium",
    resolvedLabel: "Team expedite · ETA Wed 06:00",
  },
  {
    caseId: "SHP-58214",
    lane: "pre",
    level: "medium",
    customer: "Target",
    accountId: "CUST-006",
    shipTo: "DC T-3809, Midway, GA",
    orderRef: "SO-710268",
    valueUsd: 71_300,
    signal: "Pick wave 2 is 40 min behind plan at DC-DAL",
    system: "SAP EWM",
    detectedAt: "Picking",
    orders: 1,
    track: {
      axisFrom: "2026-08-21 10:00",
      axisTo: "2026-08-21 18:00",
      windowFrom: "2026-08-21 14:00",
      windowTo: "2026-08-21 16:00",
      eta: "2026-08-21 15:20",
      windowLabel: "Fri 14:00–16:00",
      etaLabel: "ETA 15:20",
    },
    watch: { agent: "Freight Planning Agent", nextCheck: "11:30" },
  },
  {
    caseId: "SHP-58219",
    lane: "pre",
    level: "low",
    customer: "Costco",
    accountId: "CUST-005",
    shipTo: "Depot C-207, Tracy, CA",
    orderRef: "SO-710269",
    valueUsd: 64_900,
    signal: "18 of 26 pallets staged; load closes 14:00",
    system: "SAP EWM",
    detectedAt: "Loading",
    orders: 1,
    track: {
      axisFrom: "2026-08-22 04:00",
      axisTo: "2026-08-22 10:00",
      windowFrom: "2026-08-22 06:00",
      windowTo: "2026-08-22 08:00",
      eta: "2026-08-22 06:40",
      windowLabel: "Sat 06:00–08:00",
      etaLabel: "ETA 06:40",
    },
    watch: { agent: "Freight Planning Agent", nextCheck: "12:00" },
  },
  {
    caseId: "MR-58212",
    lane: "post",
    level: "high",
    customer: "Target · Kroger · Costco",
    accountId: "Multiple",
    shipTo: "Milk run, 3 stops from DC-ONT",
    orderRef: "3 orders",
    valueUsd: 171_400,
    signal: "Left DC-ONT 1 h 45 late; all 3 stops at risk",
    system: "FourKites",
    detectedAt: "Departure",
    orders: 3,
    track: {
      axisFrom: "2026-08-20 06:00",
      axisTo: "2026-08-20 12:00",
      windowFrom: "2026-08-20 07:00",
      windowTo: "2026-08-20 08:00",
      eta: "2026-08-20 08:30",
      windowLabel: "Stop 1 · 07:00–08:00",
      etaLabel: "ETA 08:30",
    },
    run: "milkrun",
    resolvedLabel: "Rerouted · 3 misses → 1",
  },
  {
    caseId: "SHP-58196",
    lane: "post",
    level: "medium",
    customer: "Walmart",
    accountId: "CUST-001",
    shipTo: "DC 7035, Fontana, CA",
    orderRef: "SO-710255",
    valueUsd: 88_700,
    signal: "I-10 slowdown and an HOS break; ETA 14:30, still in window",
    system: "FourKites",
    detectedAt: "In transit",
    orders: 1,
    track: {
      axisFrom: "2026-08-20 11:00",
      axisTo: "2026-08-20 17:00",
      windowFrom: "2026-08-20 13:00",
      windowTo: "2026-08-20 15:00",
      eta: "2026-08-20 14:30",
      windowLabel: "Today 13:00–15:00",
      etaLabel: "ETA 14:30",
    },
    watch: { agent: "Track and Trace Agent", nextCheck: "10:45" },
  },
  {
    caseId: "SHP-58203",
    lane: "post",
    level: "low",
    customer: "Kroger",
    accountId: "CUST-004",
    shipTo: "DC 018, Portland, OR",
    orderRef: "SO-710257",
    valueUsd: 52_300,
    signal: "No GPS ping for 25 min; last position on plan",
    system: "FourKites",
    detectedAt: "In transit",
    orders: 1,
    track: {
      axisFrom: "2026-08-20 14:00",
      axisTo: "2026-08-20 20:00",
      windowFrom: "2026-08-20 16:00",
      windowTo: "2026-08-20 18:00",
      eta: "2026-08-20 16:30",
      windowLabel: "Today 16:00–18:00",
      etaLabel: "ETA 16:30",
    },
    watch: { agent: "Track and Trace Agent", nextCheck: "10:30" },
  },
];

/* ------------------------------------------------------------------ *
 * Run A · no receiving slot inside the OTIF window
 * ------------------------------------------------------------------ */

export interface CalendarDay {
  date: string;
  slots: { time: string; state: "full" | "open" }[];
}

export const APPOINTMENT_CASE = {
  caseId: "SHP-58201",
  orderId: "SO-710264",
  poNumber: "PO-WMT-77140",
  accountId: "CUST-001",
  customer: "Walmart Inc.",
  valueUsd: 126_400,
  shipTo: "Walmart RDC 6094, Buckeye, AZ",
  tmsPlan: {
    loadId: "LD-ONT-260824-0912",
    route: "DC-ONT Ontario, CA → Walmart RDC 6094, Buckeye, AZ · 352 mi",
    load: "24 pallets · 17,200 lb · 53' dry van",
    carrier: "Blue Line Freight · BLFT",
    pickup: "2026-08-24 05:00",
    eta: "2026-08-26 12:30",
    rateUsd: 1_960,
  },
  otifWindow: {
    from: "2026-08-24",
    mabd: "2026-08-26",
    label: "Mon 08-24 → MABD Wed 08-26",
    rule: "Walmart OTIF: arrive on or before the must-arrive-by date",
  },
  portal: "Walmart delivery scheduling portal",
  calendar: [
    { date: "Mon 2026-08-24", slots: [{ time: "06:00", state: "full" }, { time: "10:00", state: "full" }, { time: "14:00", state: "full" }, { time: "18:00", state: "full" }, { time: "22:00", state: "full" }] },
    { date: "Tue 2026-08-25", slots: [{ time: "06:00", state: "full" }, { time: "10:00", state: "full" }, { time: "14:00", state: "full" }, { time: "18:00", state: "full" }, { time: "22:00", state: "full" }] },
    { date: "Wed 2026-08-26", slots: [{ time: "06:00", state: "full" }, { time: "10:00", state: "full" }, { time: "14:00", state: "full" }, { time: "18:00", state: "full" }, { time: "22:00", state: "full" }] },
    { date: "Thu 2026-08-27", slots: [{ time: "06:00", state: "open" }, { time: "10:00", state: "full" }, { time: "14:00", state: "open" }, { time: "18:00", state: "full" }, { time: "22:00", state: "open" }] },
  ] as CalendarDay[],
  buyer: { name: "Kelly Brooks", role: "Sr. Buyer, Walmart", email: "kelly.brooks@walmart.com" },
  requestSentAt: "2026-08-20 08:41",
  reply: {
    from: "Luis Ortega",
    role: "Inbound Scheduler, Walmart RDC 6094",
    at: "2026-08-20 09:12",
    text: "We opened door 31 for a night slot. Receiving is confirmed Tue 08-25, 22:00–23:00, appointment WMT-6094-338172.",
  },
  appointment: {
    id: "WMT-6094-338172",
    door: "Door 31",
    day: "2026-08-25",
    from: "22:00",
    to: "23:00",
    label: "Tue 2026-08-25 · 22:00–23:00",
  },
  replan: {
    id: "RP-58201",
    pickup: "2026-08-25 14:00",
    eta: "2026-08-25 21:30",
    acceptedAt: "2026-08-20 09:14",
  },
};

/**
 * The RDC 6094 receiving calendar as the scheduling portal exports it: the
 * PDF attached to the slot request. Slot states come from
 * APPOINTMENT_CASE.calendar; this adds the dock capacity behind each slot.
 */
export const RDC_6094_SNAPSHOT = {
  fileName: "RDC-6094-calendar-snapshot.pdf",
  docNo: "DSC-6094-260820-0839",
  generatedAt: "2026-08-20 08:39",
  generatedBy: "K-C Order Management · supplier user",
  timezone: "MST (UTC−7)",
  facility: {
    number: "6094",
    name: "Buckeye Regional Distribution Center",
    type: "Grocery RDC · dry",
    address: "Buckeye, AZ 85326",
    hours: "24 h · 7 days",
    unload: "Live unload · palletized",
  },
  supplier: { name: "K-C", number: "0184720" },
  slotMinutes: 60,
  slotDoors: {
    "06:00": { doors: "D12–D15", capacity: 4 },
    "10:00": { doors: "D12–D15", capacity: 4 },
    "14:00": { doors: "D16–D19", capacity: 4 },
    "18:00": { doors: "D20–D22", capacity: 3 },
    "22:00": { doors: "D29–D30", capacity: 2 },
  } as Record<string, { doors: string; capacity: number }>,
  /** Unbooked doors per open slot, keyed `${calendar date} ${time}`. */
  openDoors: {
    "Thu 2026-08-27 06:00": 1,
    "Thu 2026-08-27 14:00": 2,
    "Thu 2026-08-27 22:00": 1,
  } as Record<string, number>,
};

/* ------------------------------------------------------------------ *
 * Run B · pre-shipment premium freight
 * ------------------------------------------------------------------ */

export interface FreightOption {
  id: "keep" | "team" | "dc-atl";
  label: string;
  carrier: string;
  pickup: string;
  eta: string;
  rateUsd: number;
  /** Pallets delivered of the order. */
  pallets: number;
  recommended?: boolean;
}

export const PREMIUM_CASE = {
  caseId: "SHP-58207",
  orderId: "SO-710265",
  poNumber: "PO-KRG-55102",
  accountId: "CUST-004",
  customer: "Kroger Co.",
  valueUsd: 98_800,
  shipTo: "Kroger DC 024, Forest Park, GA",
  route: "DC-DAL Dallas, TX → Kroger DC 024, Forest Park, GA · 781 mi",
  load: "22 pallets · 16,800 lb · 53' dry van",
  pallets: 22,
  rejection: {
    carrier: "Blue Line Freight · BLFT",
    at: "2026-08-20 07:40",
    reason: "No driver for the Mon 14:00 pickup",
  },
  appointment: {
    id: "APPT-KRG-024-1187",
    from: "2026-08-26 08:00",
    to: "2026-08-26 09:00",
    label: "Wed 2026-08-26 · 08:00–09:00",
  },
  fineRatePct: 3,
  options: [
    { id: "keep", label: "Keep the TMS replan", carrier: "Pacific Coast Carriers · PCCR solo", pickup: "2026-08-25 10:00", eta: "2026-08-27 06:00", rateUsd: 2_240, pallets: 22 },
    { id: "team", label: "Team-driver expedite", carrier: "Summit Logistics · SMLG team", pickup: "2026-08-25 16:00", eta: "2026-08-26 06:00", rateUsd: 3_980, pallets: 22, recommended: true },
    { id: "dc-atl", label: "Ship from DC-ATL", carrier: "Summit Logistics · SMLG", pickup: "2026-08-25 09:00", eta: "2026-08-25 14:00", rateUsd: 1_150, pallets: 16 },
  ] as FreightOption[],
  plan: {
    id: "PFP-58207",
    costCenter: "CC-NA-LOG-410",
    reason: "Carrier tender rejected",
  },
};

/* ------------------------------------------------------------------ *
 * Run C · post-shipment milk run, track and trace
 * ------------------------------------------------------------------ */

export type StopId = "T" | "K" | "C";

export interface MilkRunStop {
  id: StopId;
  accountId: string;
  customer: string;
  site: string;
  orderId: string;
  valueUsd: number;
  windowFrom: string;
  windowTo: string;
  appointmentId: string;
}

export interface RouteOption {
  id: "r1" | "r2" | "r3";
  order: StopId[];
}

export const MILK_RUN_CASE = {
  caseId: "MR-58212",
  date: "2026-08-20",
  loadId: "LD-ONT-260820-0102",
  carrier: "Blue Line Freight · BLFT",
  equipment: "53' dry van · tractor 4471",
  origin: "DC-ONT Ontario, CA",
  plannedDepart: "06:20",
  actualDepart: "08:05",
  delayReason: "Late loading at DC-ONT door 7",
  unloadMin: 45,
  stops: [
    { id: "T", accountId: "CUST-006", customer: "Target", site: "Target DC T-0553, Fontana, CA", orderId: "SO-710281", valueUsd: 58_200, windowFrom: "07:00", windowTo: "08:00", appointmentId: "APPT-T0553-77562" },
    { id: "K", accountId: "CUST-004", customer: "Kroger", site: "Kroger DC, Riverside, CA", orderId: "SO-710282", valueUsd: 49_600, windowFrom: "08:30", windowTo: "09:30", appointmentId: "APPT-KRG-RIV-4410" },
    { id: "C", accountId: "CUST-005", customer: "Costco", site: "Costco Depot #C-114, City of Industry, CA", orderId: "SO-710283", valueUsd: 63_600, windowFrom: "10:00", windowTo: "11:00", appointmentId: "APPT-C114-58290" },
  ] as MilkRunStop[],
  /** Drive minutes between points; DC is the origin. Symmetric. */
  driveMin: { "DC-T": 25, "DC-K": 35, "T-K": 30, "K-C": 50, "C-T": 45, "T-C": 45 } as Record<string, number>,
  /** FourKites gives a predictive ETA for the next stop only; later stops are status only. */
  fourKitesPeta: { T: "08:30" } as Partial<Record<StopId, string>>,
  feed: [
    { at: "05:10", event: "Load tendered and accepted", detail: "Blue Line Freight · BLFT" },
    { at: "08:05", event: "Departed DC-ONT", detail: "Planned 06:20 · late loading at door 7" },
    { at: "08:18", event: "In transit, I-10 W near Fontana", detail: "Speed 48 mph · on route" },
  ],
  routes: [
    { id: "r1", order: ["T", "K", "C"] },
    { id: "r2", order: ["K", "C", "T"] },
    { id: "r3", order: ["K", "T", "C"] },
  ] as RouteOption[],
  reslot: {
    stop: "T" as StopId,
    window: "12:00–13:00",
    to: "Inbound Receiving, Target DC T-0553",
    email: "t0553.receiving@target.com",
  },
};
