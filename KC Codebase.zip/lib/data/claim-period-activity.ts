/**
 * What we actually invoiced and delivered to each wholesaler, for each end
 * customer, during a claim window.
 *
 * This is our own record, and it is the answer to "how many units can this
 * claim possibly be for". The supported unit count is SUMMED from these rows -
 * it is never typed anywhere.
 *
 * ACT-4712 falls after the claim window closes. It is included in the file on
 * purpose: the volume stage has to show a row it excluded, and why.
 */

export interface ClaimPeriodActivityRow {
  activityId: string;
  distributorId: string;
  endCustomerId: string;
  sku: string;
  invoiceRef: string;
  invoiceDate: string;
  units: number;
  deliveryRef: string;
  deliveredDate: string;
  podSignedBy: string;
}

export const claimPeriodActivity: ClaimPeriodActivityRow[] = [
  // Walmart Inc. -> Regional Medical Center — North Campus, incontinence briefs.
  // Five rows inside February-April 2026 total 12,000 units.
  {
    activityId: "ACT-4411",
    distributorId: "DIST-001",
    endCustomerId: "END-NLK-ENDO",
    sku: "SKU-K110",
    invoiceRef: "INV-CB-4411",
    invoiceDate: "2026-02-06",
    units: 2_500,
    deliveryRef: "SHP-CB-2211",
    deliveredDate: "2026-02-11",
    podSignedBy: "R. Okafor",
  },
  {
    activityId: "ACT-4478",
    distributorId: "DIST-001",
    endCustomerId: "END-NLK-ENDO",
    sku: "SKU-K110",
    invoiceRef: "INV-CB-4478",
    invoiceDate: "2026-02-27",
    units: 2_000,
    deliveryRef: "SHP-CB-2276",
    deliveredDate: "2026-03-04",
    podSignedBy: "R. Okafor",
  },
  {
    activityId: "ACT-4530",
    distributorId: "DIST-001",
    endCustomerId: "END-NLK-ENDO",
    sku: "SKU-K110",
    invoiceRef: "INV-CB-4530",
    invoiceDate: "2026-03-13",
    units: 3_000,
    deliveryRef: "SHP-CB-2338",
    deliveredDate: "2026-03-18",
    podSignedBy: "T. Nakamura",
  },
  {
    activityId: "ACT-4602",
    distributorId: "DIST-001",
    endCustomerId: "END-NLK-ENDO",
    sku: "SKU-K110",
    invoiceRef: "INV-CB-4602",
    invoiceDate: "2026-04-02",
    units: 2_500,
    deliveryRef: "SHP-CB-2401",
    deliveredDate: "2026-04-07",
    podSignedBy: "R. Okafor",
  },
  {
    activityId: "ACT-4655",
    distributorId: "DIST-001",
    endCustomerId: "END-NLK-ENDO",
    sku: "SKU-K110",
    invoiceRef: "INV-CB-4655",
    invoiceDate: "2026-04-24",
    units: 2_000,
    deliveryRef: "SHP-CB-2460",
    deliveredDate: "2026-04-29",
    podSignedBy: "T. Nakamura",
  },
  {
    activityId: "ACT-4566",
    distributorId: "DIST-001",
    endCustomerId: "END-CEDAR",
    sku: "SKU-K220",
    invoiceRef: "INV-CB-4566",
    invoiceDate: "2026-03-27",
    units: 2_000,
    deliveryRef: "SHP-CB-2372",
    deliveredDate: "2026-04-01",
    podSignedBy: "M. Whitfield",
  },

  // Kroger Co. -> Madison Community Hospital, feminine care pads. Backs CB-88892 (15,500 units).
  {
    activityId: "ACT-4425",
    distributorId: "DIST-004",
    endCustomerId: "END-FAIRMONT",
    sku: "SKU-K330",
    invoiceRef: "INV-CB-4425",
    invoiceDate: "2026-02-10",
    units: 8_000,
    deliveryRef: "SHP-CB-2225",
    deliveredDate: "2026-02-16",
    podSignedBy: "D. Ferreira",
  },
  {
    activityId: "ACT-4618",
    distributorId: "DIST-004",
    endCustomerId: "END-FAIRMONT",
    sku: "SKU-K330",
    invoiceRef: "INV-CB-4618",
    invoiceDate: "2026-04-08",
    units: 7_500,
    deliveryRef: "SHP-CB-2418",
    deliveredDate: "2026-04-14",
    podSignedBy: "D. Ferreira",
  },
];

/** Every row for a wholesaler, project and product, oldest first. */
export function activityFor(
  distributorId: string,
  endCustomerId: string,
  sku: string
): ClaimPeriodActivityRow[] {
  return claimPeriodActivity
    .filter(
      (r) =>
        r.distributorId === distributorId &&
        r.endCustomerId === endCustomerId &&
        r.sku === sku
    )
    .slice()
    .sort((a, b) => a.invoiceDate.localeCompare(b.invoiceDate));
}
