/**
 * Wholesaler chargeback claims awaiting validation.
 *
 * A claim says: "we sold your product on at a contracted price, pay us the
 * difference". The record here holds ONLY what the wholesaler submitted plus
 * the AI's findings. Every monetary figure is derived in
 * lib/chargeback-selectors.ts from the product price, the contract price
 * records and our own invoice history - none of it is stored on the claim.
 *
 * Note on the word "chargeback": here it means the wholesale trade kind. The
 * Exceptions page uses "Compliance chargeback" for something different - a
 * customer penalty. The two never appear on the same screen.
 */

import { daysAfterToday } from "./clock";

export interface ChargebackClaimLine {
  lineId: string;
  sku: string;
  productName: string;
  claimedUnits: number;
  /** The price the wholesaler says it sold at. The only place this appears. */
  claimedContractPrice: number;
  citedContractId: string;
  citedRosterId: string;
  endCustomerId: string;
}

/**
 * One dimension of the claim exception score.
 *
 * `score` is EXCEPTION SEVERITY for this claim as submitted, 0-100. It is not
 * a rating of the wholesaler - Walmart Inc. is a Gold-tier account on every
 * other page, and both things are true at once.
 */
export interface RiskDimensionScore {
  key: "eligibility" | "pricing" | "duplicate" | "quantity";
  label: string;
  weight: number;
  score: number;
  finding: string;
  /** Which stage produced this finding, so the score can link back to it. */
  stageId: string;
}

/**
 * The weights every claim is scored on. They sum to 1.00 - if a dimension is
 * ever added or removed, the composite moves, which is the point.
 */
export const claimRiskWeights: { key: RiskDimensionScore["key"]; weight: number }[] = [
  { key: "eligibility", weight: 0.3 },
  { key: "pricing", weight: 0.3 },
  { key: "quantity", weight: 0.25 },
  { key: "duplicate", weight: 0.15 },
];

export type ClaimStatus = "Open" | "Decided" | "Settled";

export interface ChargebackClaim {
  claimId: string;
  distributorId: string;
  submittedDate: string;
  periodId: string;
  status: ClaimStatus;
  lines: ChargebackClaimLine[];
  dimensions: RiskDimensionScore[];
  /**
   * A confirmed duplicate is a veto, not a weighted input. Scoring a duplicate
   * through the weights would return a low number for a claim that must be
   * rejected outright, because duplication only carries 15% of the weight.
   */
  duplicateVeto: boolean;
  duplicateOfClaimId?: string;
  /** The AI's own match score against the settled claim. Seeded, not counted. */
  matchConfidence?: number;
  /**
   * How far the evidence supports the recommendation, 0-1. Distinct from the
   * weighted exception score: one measures the strength of the assessment, the
   * other the severity of the claim.
   */
  aiConfidence: number;
  /** Stage id -> the one line the AI says when that stage opens. */
  routing: string;
}

export const chargebackClaims: ChargebackClaim[] = [
  {
    claimId: "CB-88971",
    distributorId: "DIST-001",
    submittedDate: "2026-08-11",
    periodId: "CP-2026FEBAPR",
    status: "Open",
    duplicateVeto: false,
    aiConfidence: 0.96,
    routing: "Contract Compliance",
    lines: [
      {
        lineId: "CBL-88971-1",
        sku: "SKU-K110",
        productName: "Adult Incontinence Briefs - Heavy",
        claimedUnits: 20_000,
        claimedContractPrice: 60,
        citedContractId: "CTR-NBA-2201",
        citedRosterId: "ROSTER-NBA",
        endCustomerId: "END-NLK-ENDO",
      },
    ],
    dimensions: [
      {
        key: "eligibility",
        label: "Project eligibility under the cited contract",
        weight: 0.3,
        score: 0,
        finding:
          "Regional Medical Center — North Campus is on the roster attached to the contract this claim cites, effective 2025-12-01.",
        stageId: "customer_check",
      },
      {
        key: "pricing",
        label: "Claimed price against the approved price record",
        weight: 0.3,
        score: 0,
        finding:
          "Claimed at $60.00, the price this project is entitled to under the contract cited.",
        stageId: "price_check",
      },
      {
        key: "duplicate",
        label: "Integrity of the submission",
        weight: 0.15,
        score: 0,
        finding:
          "No settled counterpart. The payment this claim covers is distinct from every claim already settled.",
        stageId: "duplicate_check",
      },
      {
        key: "quantity",
        label: "Units supported by invoice and delivery",
        weight: 0.25,
        score: 100,
        finding:
          "8,000 of the 20,000 units claimed have no invoice or delivery record.",
        stageId: "volume_check",
      },
    ],
  },
  /**
   * The second flow: a claim that IS a duplicate. It short-circuits to three
   * steps, because once a claim has been settled, pricing and volume cannot
   * change the outcome. Kept beside CB-88971 so the demo shows both readings
   * of the duplicate screen — one that clears, one that stops.
   */
  {
    claimId: "CB-88960",
    distributorId: "DIST-001",
    submittedDate: "2026-08-11",
    periodId: "CP-2026FEBAPR",
    status: "Open",
    duplicateVeto: true,
    duplicateOfClaimId: "CB-88940",
    matchConfidence: 0.99,
    aiConfidence: 0.99,
    routing: "Contract Compliance",
    lines: [
      {
        lineId: "CBL-88960-1",
        sku: "SKU-K220",
        productName: "Feminine Care Pads - Ultra Thin",
        claimedUnits: 5_000,
        claimedContractPrice: 60,
        citedContractId: "CTR-NBA-2201",
        citedRosterId: "ROSTER-NBA",
        endCustomerId: "END-CEDAR",
      },
    ],
    dimensions: [],
  },
];

export function findClaim(claimId: string): ChargebackClaim | undefined {
  return chargebackClaims.find((c) => c.claimId === claimId);
}

/** A claim we have already paid. The comparison set for duplicate screening. */
export interface SettledClaim {
  /** The invoices that supported it. Shown against the claim under review. */
  invoiceRefs?: string[];
  claimId: string;
  distributorId: string;
  endCustomerId: string;
  sku: string;
  periodId: string;
  units: number;
  settledAmount: number;
  settledDate: string;
  settlementRef: string;
}

export const settledClaims: SettledClaim[] = [
  /* Same wholesaler, same project, same product as CB-88971, in the two
     quarters before it. These are what the duplicate screen compares against:
     the parties are meant to repeat, so the screen has to prove the PAYMENT is
     different rather than flag the customer as a repeat claimant. */
  {
    claimId: "CB-88604",
    distributorId: "DIST-001",
    endCustomerId: "END-NLK-ENDO",
    sku: "SKU-K110",
    periodId: "CP-2025NOVJAN",
    units: 9_000,
    settledAmount: 360_000,
    invoiceRefs: ["INV-CB-4188", "INV-CB-4241", "INV-CB-4302"],
    settledDate: "2026-02-14",
    settlementRef: "STL-69880",
  },
  {
    claimId: "CB-88450",
    distributorId: "DIST-001",
    endCustomerId: "END-NLK-ENDO",
    sku: "SKU-K110",
    periodId: "CP-2025AUGOCT",
    units: 7_500,
    settledAmount: 300_000,
    invoiceRefs: ["INV-CB-3960", "INV-CB-4021"],
    settledDate: "2025-11-19",
    settlementRef: "STL-69512",
  },
  {
    claimId: "CB-88940",
    distributorId: "DIST-001",
    endCustomerId: "END-CEDAR",
    sku: "SKU-K220",
    periodId: "CP-2026FEBAPR",
    units: 5_000,
    settledAmount: 125_000,
    // Twelve days before the demo date, so the duplicate finding stays true.
    settledDate: daysAfterToday(-12),
    settlementRef: "STL-70412",
  },
  {
    claimId: "CB-88815",
    distributorId: "DIST-004",
    endCustomerId: "END-FAIRMONT",
    sku: "SKU-K330",
    periodId: "CP-2026FEBAPR",
    units: 10_250,
    settledAmount: 410_000,
    settledDate: "2026-04-22",
    settlementRef: "STL-70288",
  },
  {
    claimId: "CB-88702",
    distributorId: "DIST-001",
    endCustomerId: "END-PRAIRIE",
    sku: "SKU-K440",
    periodId: "CP-2026FEBAPR",
    units: 12_000,
    settledAmount: 180_000,
    settledDate: "2026-03-30",
    settlementRef: "STL-70105",
  },
];

export function findSettledClaim(claimId: string): SettledClaim | undefined {
  return settledClaims.find((c) => c.claimId === claimId);
}
