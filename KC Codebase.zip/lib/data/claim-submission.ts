/**
 * The file the wholesaler actually sends us.
 *
 * In the US wholesale channel a chargeback is claimed on an EDI 844 - Product
 * Transfer Account Adjustment. It is NOT an invoice (the wholesaler does not
 * bill us; we bill them) and it is NOT an order (the goods shipped months
 * ago). It is a list of RESALE lines: for each sale the wholesaler made to the
 * end customer under a contract, the wholesaler's own invoice to that customer,
 * the date, the units, the price they say they charged, and the difference
 * they want back.
 *
 * We answer it with an EDI 849. The wholesaler's periodic EDI 867 resale report
 * is the supporting data behind it.
 *
 * Every figure the claim asserts is derived from these lines - the total units
 * and the total claimed on the intake panel are sums over this array, asserted
 * at runtime in lib/chargeback-selectors.ts rather than typed a second time.
 *
 * `supportedByInvoiceRef` is NOT part of what the wholesaler sent. It is our
 * annotation, established by the invoice trace at the volume stage: the
 * shipment of ours that could have supplied the units on that resale line.
 * `null` means no shipment of ours accounts for it. The intake panel shows the
 * lines without this column, because at intake nothing has been tested.
 */

export interface ClaimSubmissionLine {
  lineRef: string;
  /** The wholesaler's own invoice to the end customer. */
  resaleRef: string;
  resaleDate: string;
  units: number;
  /** The price the wholesaler says it charged the end customer. */
  resalePrice: number;
  supportedByInvoiceRef: string | null;
}

export interface ClaimSubmission {
  claimId: string;
  /** The EDI 844 transmission this claim arrived on. */
  submissionRef: string;
  transmissionType: string;
  receivedOn: string;
  lines: ClaimSubmissionLine[];
}

/**
 * Eight resale lines across the February-to-April window. Five follow a
 * shipment of ours by a few days, which is how a genuine resale looks. Three
 * follow nothing.
 */
export const claimSubmissions: ClaimSubmission[] = [
  {
    claimId: "CB-88971",
    submissionRef: "SUB-844-20260506-0117",
    transmissionType: "EDI 844 — Product Transfer Account Adjustment",
    receivedOn: "2026-08-06",
    lines: [
      {
        lineRef: "L-01",
        resaleRef: "WD-77201",
        resaleDate: "2026-02-10",
        units: 2_500,
        resalePrice: 60,
        supportedByInvoiceRef: "INV-CB-4411",
      },
      {
        lineRef: "L-02",
        resaleRef: "WD-77388",
        resaleDate: "2026-02-24",
        units: 3_000,
        resalePrice: 60,
        supportedByInvoiceRef: null,
      },
      {
        lineRef: "L-03",
        resaleRef: "WD-77455",
        resaleDate: "2026-03-02",
        units: 2_000,
        resalePrice: 60,
        supportedByInvoiceRef: "INV-CB-4478",
      },
      {
        lineRef: "L-04",
        resaleRef: "WD-77596",
        resaleDate: "2026-03-18",
        units: 3_000,
        resalePrice: 60,
        supportedByInvoiceRef: "INV-CB-4530",
      },
      {
        lineRef: "L-05",
        resaleRef: "WD-77690",
        resaleDate: "2026-03-25",
        units: 2_500,
        resalePrice: 60,
        supportedByInvoiceRef: null,
      },
      {
        lineRef: "L-06",
        resaleRef: "WD-77802",
        resaleDate: "2026-04-07",
        units: 2_500,
        resalePrice: 60,
        supportedByInvoiceRef: "INV-CB-4602",
      },
      {
        lineRef: "L-07",
        resaleRef: "WD-77921",
        resaleDate: "2026-04-15",
        units: 2_500,
        resalePrice: 60,
        supportedByInvoiceRef: null,
      },
      {
        lineRef: "L-08",
        resaleRef: "WD-78014",
        resaleDate: "2026-04-28",
        units: 2_000,
        resalePrice: 60,
        supportedByInvoiceRef: "INV-CB-4655",
      },
    ],
  },
];

export function findClaimSubmission(
  claimId: string
): ClaimSubmission | undefined {
  return claimSubmissions.find((s) => s.claimId === claimId);
}
