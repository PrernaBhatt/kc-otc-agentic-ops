/**
 * Pure math for the Costco invoice dispute. Every amount the run, the cause
 * board, the settlement and the documents show is derived here, and the
 * tie-outs below must hold or the selector throws.
 */

import {
  findBillingDisputeCase,
  type BillingDisputeCase,
  type DisputeCause,
} from "./data/billing-disputes";

export interface DisputeCauseAmount extends DisputeCause {
  amount: number;
}

export interface BillingDisputeFigures {
  case: BillingDisputeCase;
  merchandise: number;
  invoiceTotal: number;
  paid: number;
  shortPaid: number;
  causes: DisputeCauseAmount[];
  chargeBack: number;
  credit: number;
  cleared: number;
}

function assertTie(label: string, a: number, b: number) {
  if (Math.round(a) !== Math.round(b)) {
    throw new Error(`[billing dispute] ${label}: ${a} !== ${b}`);
  }
}

export function billingDispute(caseId: string): BillingDisputeFigures | null {
  const c = findBillingDisputeCase(caseId);
  if (!c) return null;

  const merchandise = c.sapUnitPrice * c.qty;
  const invoiceTotal = merchandise + c.freightBilled + c.taxBilled;
  const promo = c.promotionUnitAllowance * c.qty;
  const paid = c.poUnitPrice * c.qty - promo + c.freightCapPerLoad;
  const shortPaid = invoiceTotal - paid;

  const amountFor: Record<DisputeCause["key"], number> = {
    price: (c.sapUnitPrice - c.poUnitPrice) * c.qty,
    promotion: promo,
    freight: c.freightBilled - c.freightCapPerLoad,
    tax: c.taxBilled,
  };
  const causes = c.causes.map((cause) => ({ ...cause, amount: amountFor[cause.key] }));
  const chargeBack = causes.filter((x) => x.verdict === "kc").reduce((s, x) => s + x.amount, 0);
  const credit = causes.filter((x) => x.verdict === "customer").reduce((s, x) => s + x.amount, 0);
  const cleared = paid + credit;

  assertTie("short = sum of causes", shortPaid, causes.reduce((s, x) => s + x.amount, 0));
  assertTie("short = charge-back + credit", shortPaid, chargeBack + credit);
  assertTie("invoice = cleared + charge-back", invoiceTotal, cleared + chargeBack);

  return { case: c, merchandise, invoiceTotal, paid, shortPaid, causes, chargeBack, credit, cleared };
}
