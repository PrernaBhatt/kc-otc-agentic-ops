/**
 * The reconciliation behind the second deduction case.
 *
 * Every figure the screen shows is a sum over the components, so the split can
 * never disagree with the short pay it came from. The relationships are
 * asserted rather than assumed: a deduction that does not reconcile is the one
 * thing this case must never render quietly.
 */

import { findShortPayCase, type ShortPayCase } from "./data/short-pay";
import type { ClaimEdit } from "./claim-edit";

export interface ShortPaySplit {
  case: ShortPayCase;
  invoiceAmount: number;
  amountPaid: number;
  shortPay: number;
  /** What the distributor is entitled to keep. */
  acceptAmount: number;
  /** What has already been credited and must come back. */
  recoverAmount: number;
  /** invoice - paid === shortPay, and accept + recover === shortPay. */
  reconciles: boolean;
  recoverPercent: number;
}

export function shortPaySplit(
  caseId: string,
  edit?: ClaimEdit
): ShortPaySplit | null {
  const c = findShortPayCase(caseId);
  if (!c) return null;

  const shortPay = c.invoiceAmount - c.amountPaid;
  const baseAccept = c.components
    .filter((x) => x.valid)
    .reduce((sum, x) => sum + x.amount, 0);

  // A reviewer can move how much of the short pay is accepted as a valid
  // gross-to-net cost; the remainder is recovered.
  const acceptAmount =
    edit?.approvedAmount != null
      ? Math.max(0, Math.min(Math.round(edit.approvedAmount), shortPay))
      : baseAccept;
  const recoverAmount = shortPay - acceptAmount;

  const reconciles = acceptAmount + recoverAmount === shortPay;

  if (process.env.NODE_ENV !== "production" && !edit) {
    if (!reconciles)
      console.error(
        `[short pay] ${caseId}: the components do not sum to the amount withheld`,
        { shortPay, acceptAmount, recoverAmount }
      );
    if (recoverAmount !== c.creditMemo.amount)
      console.error(
        `[short pay] ${caseId}: the recoverable amount and the credit memo disagree`,
        { recoverAmount, creditMemo: c.creditMemo.amount }
      );
    if (acceptAmount !== c.approvedClaim.amount)
      console.error(
        `[short pay] ${caseId}: the accepted amount and the approved claim disagree`,
        { acceptAmount, approvedClaim: c.approvedClaim.amount }
      );
  }

  return {
    case: c,
    invoiceAmount: c.invoiceAmount,
    amountPaid: c.amountPaid,
    shortPay,
    acceptAmount,
    recoverAmount,
    reconciles,
    recoverPercent: shortPay === 0 ? 0 : recoverAmount / shortPay,
  };
}

/* ------------------------------------------------------------------ *
 * What it does to the books
 * ------------------------------------------------------------------ */

export interface ShortPayAccounting {
  /** Only the valid part is a gross-to-net cost. */
  gtnImpact: number;
  reserveUtilised: number;
  /** The invalid part never becomes an expense; it stays collectible. */
  recoveryRequired: number;
  receivableStillCollectible: number;
  lines: {
    lineNumber: number;
    glAccount: string;
    accountName: string;
    plainName: string;
    debit?: number;
    credit?: number;
  }[];
}

/**
 * The point of the whole case: not every deduction is a gross-to-net cost.
 *
 * The valid quarter draws down the reserve exactly as a settlement does. The
 * duplicate touches gross-to-net not at all — it is a receivable that is still
 * collectible, and treating it as an expense is precisely the leakage this
 * case exists to stop.
 */
export function shortPayAccounting(
  caseId: string,
  edit?: ClaimEdit
): ShortPayAccounting | null {
  const split = shortPaySplit(caseId, edit);
  if (!split) return null;

  return {
    gtnImpact: split.acceptAmount,
    reserveUtilised: split.acceptAmount,
    recoveryRequired: split.recoverAmount,
    receivableStillCollectible: split.recoverAmount,
    lines: [
      {
        lineNumber: 10,
        glAccount: "229150",
        accountName: "Chargeback reserve liability",
        plainName: "Money set aside for chargebacks",
        debit: split.acceptAmount,
      },
      {
        lineNumber: 20,
        glAccount: "121500",
        accountName: "Deduction clearing — wholesale channel",
        plainName: `Owed by ${split.case.customerName}`,
        credit: split.acceptAmount,
      },
    ],
  };
}

/* ------------------------------------------------------------------ *
 * The letter
 * ------------------------------------------------------------------ */

export function renderShortPayLetter(
  caseId: string,
  edit?: ClaimEdit
): { subject: string; body: string } | null {
  const split = shortPaySplit(caseId, edit);
  if (!split) return null;
  const c = split.case;

  const usd = (n: number) => `$${n.toLocaleString("en-US")}`;
  const tokens: Record<string, string> = {
    invoiceId: c.invoiceId,
    invoiceAmount: usd(c.invoiceAmount),
    remittanceId: c.remittanceId,
    receivedDate: c.receivedDate,
    amountPaid: usd(c.amountPaid),
    shortPay: usd(split.shortPay),
    acceptAmount: usd(split.acceptAmount),
    recoverAmount: usd(split.recoverAmount),
    approvedClaimId: c.approvedClaim.claimId,
    approvedOn: c.approvedClaim.approvedOn,
    creditClaimId: c.creditMemo.againstClaimId,
    creditMemoId: c.creditMemo.creditMemoId,
    creditIssuedOn: c.creditMemo.issuedOn,
    creditClearedOn: c.creditMemo.clearedOn,
    from: c.disputeLetter.from,
  };

  const fill = (t: string) =>
    t.replace(/\{(\w+)\}/g, (whole, key: string) => tokens[key] ?? whole);

  return {
    subject: fill(c.disputeLetter.subjectTemplate),
    body: fill(c.disputeLetter.bodyTemplate),
  };
}
