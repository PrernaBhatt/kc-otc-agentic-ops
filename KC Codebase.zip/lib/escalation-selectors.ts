import { RUN_DATE, daysBetween } from "./data/clock";
import {
  runEscalationTemplates,
  seededEscalations,
  type Escalation,
  type RunEscalationId,
} from "./data/escalations";
import { rebateClaimAssessment } from "./rebate-claim-selectors";

/** Seeded escalations with any case-derived amounts resolved. */
export function initialEscalations(): Escalation[] {
  return seededEscalations.map((e) =>
    e.id === "ESC-2604" && e.amountUsd === null
      ? { ...e, amountUsd: rebateClaimAssessment(e.sourceCaseId)?.unsupported ?? 0 }
      : e
  );
}

export function buildRunEscalation(id: RunEscalationId): Escalation {
  const t = runEscalationTemplates[id];
  return {
    ...t,
    raisedOn: RUN_DATE,
    status: "Raised",
    chain: [
      { status: "Raised", at: RUN_DATE, by: t.raisedBy },
      { status: "Acknowledged" },
      { status: "Actioned" },
      { status: "Closed" },
    ],
    nudges: [],
  };
}

export function escalationAgeDays(e: Escalation): number {
  return daysBetween(e.raisedOn, RUN_DATE);
}

export function isEscalationOverdue(e: Escalation): boolean {
  return e.status !== "Closed" && escalationAgeDays(e) > e.slaDays;
}

export type AgeBucket = "0–15" | "16–30" | "31+";
export const AGE_BUCKETS: AgeBucket[] = ["0–15", "16–30", "31+"];

export function ageBucket(e: Escalation): AgeBucket {
  const d = escalationAgeDays(e);
  return d <= 15 ? "0–15" : d <= 30 ? "16–30" : "31+";
}
