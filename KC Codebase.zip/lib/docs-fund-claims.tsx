/**
 * Source documents for Scenario 4 — fund allocation and settlement.
 *
 * Same rule as the other doc builders: every field is read from the same
 * record the screen reads, so a document can never disagree with the
 * assessment that opened it.
 */

import type { SourceDoc } from "@/components/modals/source-doc-preview";
import { findFundClaimCase } from "./data/fund-claims";
import {
  fundClaimAssessment,
  renderFundClaimLetter,
} from "./fund-claim-selectors";

const ISSUER = "Order to Cash Workspace";
const usd = (n: number) => `$${n.toLocaleString("en-US")}`;

/* ------------------------------------------------------------------ *
 * The promotion claim, as the retailer sent it
 * ------------------------------------------------------------------ */

export function buildFundDeductionDoc(caseId: string): SourceDoc {
  const c = findFundClaimCase(caseId)!;
  const claimed = c.invoiceAmount - c.amountPaid;
  const refEvent = c.events.find((e) => e.eventId === c.referencedEventId);

  return {
    docId: `fund-deduction-${caseId}`,
    title: `Promotion claim ${caseId}`,
    docLabel: "Deduction backup",
    reference: c.claimRef,
    issuer: c.customerName,
    meta: [
      { label: "Invoice", value: c.invoiceId },
      { label: "Received", value: c.receivedDate },
      { label: "Reason code", value: c.reasonCode },
      { label: "Fund referenced", value: c.referencedFundId },
    ],
    columns: [
      { key: "item", label: "As claimed" },
      { key: "value", label: "Value", align: "right" },
    ],
    rows: [
      { id: "plan", cells: { item: "Promotion plan", value: c.claimRef } },
      {
        id: "event",
        cells: { item: "Event referenced", value: refEvent?.name ?? c.referencedEventId },
      },
      {
        id: "fund",
        cells: { item: "Fund referenced", value: c.referencedFundId },
      },
      { id: "amount", cells: { item: "Claim amount", value: usd(claimed) } },
    ],
    totals: [{ label: "Promotion claimed", value: usd(claimed), emphasis: true }],
    footnote: `Remittance note: "${c.customerNote}"`,
    highlightRowIds: ["fund", "event"],
    highlightNote:
      "The claim points at a single fund and event, but the spend actually spans two overlapping events on two funds.",
    aiSummary: `${c.customerName} withheld ${usd(claimed)} for a valid back-to-school promotion under ${c.claimRef}. The paperwork references one fund (${c.referencedFundId}), but the feature and display ran across two events funded separately — so the claim has to be allocated, not simply charged to the first fund.`,
  };
}

/* ------------------------------------------------------------------ *
 * A single promotion event, as its own record — the claim spans two
 * events, and each is independently verifiable, so each gets its own
 * 1:1 file rather than a shared summary.
 * ------------------------------------------------------------------ */

export function buildEventDoc(caseId: string, eventId: string): SourceDoc {
  const c = findFundClaimCase(caseId)!;
  const e = c.events.find((x) => x.eventId === eventId) ?? c.events[0];
  const referenced = e.eventId === c.referencedEventId;
  const fund = c.funds.find((f) => f.fundId === e.fundId);

  return {
    docId: `fund-event-${caseId}-${e.eventId}`,
    title: `Promotion event — ${e.name}`,
    docLabel: "Event record",
    reference: e.eventId,
    issuer: ISSUER,
    meta: [
      { label: "Mechanic", value: e.mechanic },
      { label: "SKU group", value: e.skuGroup },
      { label: "Ran", value: `${e.periodStart} to ${e.periodEnd}` },
      { label: "Fund", value: fund?.name ?? e.fundId },
    ],
    columns: [
      { key: "item", label: "Item" },
      { key: "value", label: "Value", align: "right" },
    ],
    rows: [
      { id: "planned", cells: { item: "Planned spend", value: usd(e.plannedSpend) } },
      { id: "accrued", cells: { item: "Accrued", value: usd(e.accrued) } },
      { id: "prior", cells: { item: "Prior claims against this event", value: usd(e.priorClaims) } },
      {
        id: "referenced",
        cells: { item: "Referenced by this claim", value: referenced ? "Yes" : "No — found by matching" },
      },
    ],
    totals: [{ label: "Accrued", value: usd(e.accrued), emphasis: true }],
    footnote: e.note,
    highlightRowIds: ["referenced"],
    highlightNote: referenced
      ? "This is the event the retailer's paperwork named."
      : "The claim's paperwork did not name this event — it was found by matching the spend period and SKUs, not by reference.",
    aiSummary: referenced
      ? `${e.name} ran ${e.periodStart} to ${e.periodEnd} on ${e.skuGroup}, funded from ${fund?.name ?? e.fundId}. This is the event the claim explicitly references.`
      : `${e.name} ran ${e.periodStart} to ${e.periodEnd} on ${e.skuGroup}, funded from ${fund?.name ?? e.fundId}. The claim's paperwork never names this event, but the overlapping dates and SKUs tie it to the same claim.`,
  };
}

/* ------------------------------------------------------------------ *
 * A single trade fund, as its own checkbook line
 * ------------------------------------------------------------------ */

export function buildFundDoc(caseId: string, fundId: string): SourceDoc {
  const a = fundClaimAssessment(caseId)!;
  const c = a.case;
  const f = a.fundsAfter.find((x) => x.fund.fundId === fundId) ?? a.fundsAfter[0];
  const referenced = f.fund.fundId === c.referencedFundId;

  return {
    docId: `fund-single-${caseId}-${f.fund.fundId}`,
    title: `Fund — ${f.fund.name}`,
    docLabel: "Checkbook line",
    reference: f.fund.fundId,
    issuer: ISSUER,
    meta: [
      { label: "TPM system", value: f.fund.tpmSystem },
      { label: "Fiscal year", value: f.fund.fiscalYear },
      { label: "Referenced by claim", value: referenced ? "Yes" : "No" },
      { label: "Available before", value: usd(f.availableBefore) },
    ],
    columns: [
      { key: "item", label: "Item" },
      { key: "value", label: "Value", align: "right" },
    ],
    rows: [
      { id: "booked", cells: { item: "Accrual booked", value: usd(f.fund.accrualBooked) } },
      { id: "prior", cells: { item: "Consumed by earlier claims", value: usd(f.fund.priorConsumed) } },
      { id: "before", cells: { item: "Available before this claim", value: usd(f.availableBefore) } },
      { id: "alloc", cells: { item: "Allocated to this claim", value: f.allocated > 0 ? `−${usd(f.allocated)}` : "—" } },
      { id: "after", cells: { item: "Available after", value: usd(f.availableAfter) } },
    ],
    totals: [{ label: "Available after", value: usd(f.availableAfter), emphasis: true }],
    footnote: f.fund.note,
    highlightRowIds: f.allocated > 0 ? ["alloc"] : [],
    highlightNote: f.fund.note,
    aiSummary: `${f.fund.name} had ${usd(f.availableBefore)} available before this claim (${usd(f.fund.accrualBooked)} booked, ${usd(f.fund.priorConsumed)} already consumed). This claim allocates ${f.allocated > 0 ? usd(f.allocated) : "nothing"} to it, leaving ${usd(f.availableAfter)}.`,
  };
}

/* ------------------------------------------------------------------ *
 * A single allocation line, as its own record
 * ------------------------------------------------------------------ */

export function buildAllocationLineDoc(caseId: string, allocationId: string): SourceDoc {
  const a = fundClaimAssessment(caseId)!;
  const al = a.allocations.find((x) => x.allocationId === allocationId) ?? a.allocations[0];

  return {
    docId: `fund-allocline-${caseId}-${al.allocationId}`,
    title: `Allocation line — ${al.eventName}`,
    docLabel: "Allocation line",
    reference: al.allocationId,
    issuer: ISSUER,
    meta: [
      { label: "Fund", value: al.fundName },
      { label: "Event", value: al.eventName },
      { label: "Spend type", value: al.spendType },
      { label: "Referenced fund", value: al.isReferenced ? "Yes" : "No — reallocated" },
    ],
    columns: [
      { key: "item", label: "Item" },
      { key: "value", label: "Value", align: "right" },
    ],
    rows: [
      { id: "allocated", cells: { item: "Allocated", value: usd(al.allocated) } },
      { id: "available", cells: { item: "Fund available", value: usd(al.available) } },
      { id: "accrued", cells: { item: "Accrued for this event", value: usd(al.accruedForEvent) } },
    ],
    totals: [{ label: "Allocated", value: usd(al.allocated), emphasis: true }],
    footnote: al.note,
    highlightRowIds: al.isReferenced ? [] : ["allocated"],
    highlightNote: al.note,
    aiSummary: al.isReferenced
      ? `${usd(al.allocated)} of the claim settles against ${al.fundName}, the fund the retailer's paperwork referenced, for the ${al.eventName} event.`
      : `${usd(al.allocated)} of the claim moves to ${al.fundName} for the ${al.eventName} event — the portion the retailer's single reference missed, now correctly allocated.`,
  };
}

/* ------------------------------------------------------------------ *
 * A single settlement control, as its own record
 * ------------------------------------------------------------------ */

export function buildControlLineDoc(caseId: string, controlId: string): SourceDoc {
  const c = findFundClaimCase(caseId)!;
  const ctrl = c.controls.find((x) => x.controlId === controlId) ?? c.controls[0];

  return {
    docId: `fund-controlline-${caseId}-${ctrl.controlId}`,
    title: `Settlement control — ${ctrl.label}`,
    docLabel: "Control record",
    reference: ctrl.controlId,
    issuer: ISSUER,
    meta: [
      { label: "System", value: ctrl.system },
      { label: "Expected value", value: usd(ctrl.expected) },
      { label: "Case", value: c.caseId },
      { label: "Claim ref", value: c.claimRef },
    ],
    columns: [
      { key: "item", label: "Item" },
      { key: "value", label: "", align: "left" },
    ],
    rows: [
      { id: "system", cells: { item: "System of record", value: ctrl.system } },
      { id: "expected", cells: { item: "Expected value", value: usd(ctrl.expected) } },
      { id: "note", cells: { item: "Finding", value: ctrl.note } },
    ],
    totals: [{ label: "Expected value", value: usd(ctrl.expected), emphasis: true }],
    footnote: ctrl.note,
    highlightRowIds: ["note"],
    highlightNote: ctrl.note,
    aiSummary: `${ctrl.label} in ${ctrl.system} should carry ${usd(ctrl.expected)} once settlement posts. ${ctrl.note}`,
  };
}

/* ------------------------------------------------------------------ *
 * The two funds — checkbook view
 * ------------------------------------------------------------------ */

export function buildFundCheckbookDoc(caseId: string): SourceDoc {
  const a = fundClaimAssessment(caseId)!;

  return {
    docId: `fund-checkbook-${caseId}`,
    title: `Trade-promotion checkbook — ${a.case.claimRef}`,
    docLabel: "Fund checkbook",
    reference: a.case.referencedFundId,
    issuer: ISSUER,
    meta: [
      { label: "Claim", value: usd(a.claimed) },
      { label: "Referenced fund available", value: usd(a.referencedAvailable) },
      { label: "Overflow to move", value: usd(a.overflow) },
      { label: "Funds used", value: String(a.fundsAfter.filter((f) => f.allocated > 0).length) },
    ],
    columns: [
      { key: "fund", label: "Fund" },
      { key: "before", label: "Available before", align: "right" },
      { key: "alloc", label: "This claim", align: "right" },
      { key: "after", label: "Available after", align: "right" },
    ],
    rows: a.fundsAfter.map((f) => ({
      id: f.fund.fundId,
      cells: {
        fund: f.fund.name,
        before: usd(f.availableBefore),
        alloc: f.allocated > 0 ? `−${usd(f.allocated)}` : "—",
        after: usd(f.availableAfter),
      },
    })),
    totals: [
      { label: "Total allocated", value: usd(a.allocatedTotal), emphasis: true },
    ],
    noteList: a.fundsAfter.map((f) => ({ label: f.fund.name, detail: f.fund.note })),
    highlightRowIds: [a.case.referencedFundId],
    highlightNote: `The referenced fund had only ${usd(a.referencedAvailable)} left, so ${usd(a.overflow)} of the valid claim moves to the eligible second fund. No budget is overspent.`,
    aiSummary: `The referenced fund held ${usd(a.referencedAvailable)} against a ${usd(a.claimed)} claim. Rather than overspend it, ${usd(a.referencedAllocated)} stays on it and ${usd(a.overflow)} moves to the second eligible fund, which has ample accrual. Both funds stay solvent.`,
  };
}

/* ------------------------------------------------------------------ *
 * The allocation across events / funds
 * ------------------------------------------------------------------ */

export function buildAllocationDoc(caseId: string): SourceDoc {
  const a = fundClaimAssessment(caseId)!;

  return {
    docId: `fund-allocation-${caseId}`,
    title: `Claim allocation — ${caseId}`,
    docLabel: "Allocation proposal",
    reference: a.case.claimRef,
    issuer: ISSUER,
    meta: [
      { label: "Claimed", value: usd(a.claimed) },
      { label: "Allocated", value: usd(a.allocatedTotal) },
      { label: "Fully funded", value: a.fullyFunded ? "Yes" : "No" },
      { label: "Reconciles", value: a.reconciles ? "Yes" : "No" },
    ],
    columns: [
      { key: "event", label: "Event" },
      { key: "fund", label: "Fund" },
      { key: "type", label: "Spend type" },
      { key: "alloc", label: "Allocated", align: "right" },
    ],
    rows: a.allocations.map((al) => ({
      id: al.allocationId,
      cells: {
        event: al.eventName,
        fund: al.fundName,
        type: al.spendType,
        alloc: usd(al.allocated),
      },
    })),
    totals: [
      { label: "Total allocated", value: usd(a.allocatedTotal), emphasis: true },
    ],
    noteList: a.allocations.map((al) => ({ label: al.eventName, detail: al.note })),
    highlightRowIds: a.allocations.filter((al) => !al.isReferenced).map((al) => al.allocationId),
    highlightNote:
      "The highlighted line is the portion that moves to a second fund — the part the retailer's single reference missed.",
    aiSummary: `The claim splits across two events: ${a.allocations.map((al) => `${usd(al.allocated)} to ${al.fundName}`).join(", ")}. The allocations sum to ${usd(a.allocatedTotal)}, matching the claim exactly.`,
  };
}

/* ------------------------------------------------------------------ *
 * Post-settlement controls
 * ------------------------------------------------------------------ */

export function buildControlsDoc(caseId: string): SourceDoc {
  const a = fundClaimAssessment(caseId)!;
  const c = a.case;

  return {
    docId: `fund-controls-${caseId}`,
    title: `Settlement controls — ${caseId}`,
    docLabel: "Post-settlement controls",
    reference: c.remittanceId,
    issuer: ISSUER,
    meta: [
      { label: "Claim", value: usd(a.claimed) },
      { label: "Credit memo", value: usd(a.claimed) },
      { label: "Controls", value: String(c.controls.length) },
      { label: "Open dispute", value: "$0" },
    ],
    columns: [
      { key: "control", label: "Control" },
      { key: "system", label: "System" },
      { key: "expected", label: "Value", align: "right" },
    ],
    rows: c.controls.map((ctrl) => ({
      id: ctrl.controlId,
      cells: {
        control: ctrl.label,
        system: ctrl.system,
        expected: usd(ctrl.expected),
      },
    })),
    noteList: c.controls.map((ctrl) => ({ label: ctrl.label, detail: ctrl.note })),
    highlightRowIds: c.controls.map((ctrl) => ctrl.controlId),
    highlightNote:
      "One approved claim touches four records — credit memo, checkbook, FI posting and the dispute case. All four have to reconcile before the case closes.",
    aiSummary: `Settlement updates four records: a ${usd(a.claimed)} credit memo, the checkbook across both funds, the FI trade-spend posting, and closure of the receivable dispute. All four tie back to the same ${usd(a.claimed)}.`,
  };
}

/* ------------------------------------------------------------------ *
 * The retailer response letter, as a document
 * ------------------------------------------------------------------ */

export function buildFundLetterDoc(caseId: string, sent: boolean): SourceDoc {
  const a = fundClaimAssessment(caseId)!;
  const c = a.case;
  const letter = renderFundClaimLetter(caseId)!;

  return {
    docId: `fund-letter-${caseId}`,
    title: `Retailer response ${c.responseLetter.letterRef}`,
    docLabel: "Deduction response letter",
    reference: c.responseLetter.letterRef,
    issuer: ISSUER,
    meta: [
      { label: "To", value: c.responseLetter.to },
      { label: "From", value: c.responseLetter.from },
      { label: "Status", value: sent ? "Issued" : "Draft — not yet sent" },
      { label: "Approved", value: usd(a.claimed) },
    ],
    columns: [
      { key: "item", label: "Correspondence" },
      { key: "value", label: "", align: "left" },
    ],
    rows: [
      { id: "subject", cells: { item: "Subject", value: letter.subject } },
      { id: "body", cells: { item: "Body", value: letter.body } },
    ],
    highlightRowIds: ["body"],
    highlightNote: sent
      ? "Issued to the retailer confirming full approval and the two-fund allocation."
      : "Drafted from the allocation. A person approves it before it is sent.",
    aiSummary: `The response confirms the promotion is approved in full at ${usd(a.claimed)} and explains the two-fund split, with one credit memo clearing the deduction and nothing further due.`,
  };
}
