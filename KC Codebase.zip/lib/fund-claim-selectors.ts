/**
 * The reconciliation behind Scenario 4 — fund allocation and settlement.
 *
 * Invariants the screen leans on, none of them stored as a conclusion:
 *   1. Σ(fund allocations) === claimed
 *      If the allocations do not sum to the amount withheld, the split is not
 *      auditable and must not claim to be.
 *   2. each allocation <= that fund's available accrual
 *      The referenced fund is capped at what it actually has; the overflow is
 *      what must move to another fund.
 *   3. budgetExceptionValue = the amount that could not sit on the referenced
 *      fund = claimed - referencedFundAvailable. Above the materiality
 *      threshold it routes to trade-finance review rather than auto-approval.
 */

import {
  findFundClaimCase,
  type FundClaimCase,
  type FundAllocation,
  type TradeFund,
} from "./data/fund-claims";
import type { ClaimEdit } from "./claim-edit";

export interface FundClaimAssessment {
  case: FundClaimCase;
  /** The whole amount withheld on the invoice. */
  claimed: number;
  /** Sum of the allocations — must equal claimed. */
  allocatedTotal: number;
  /** The referenced fund and what it had available. */
  referencedFund: TradeFund;
  referencedAvailable: number;
  /** What the referenced fund could actually absorb (capped at its available). */
  referencedAllocated: number;
  /** What had to move to a second fund because the first could not cover it. */
  overflow: number;
  /** True when the whole claim is covered across funds without overspend. */
  fullyFunded: boolean;
  /** Σ allocated === claimed. */
  reconciles: boolean;
  /** The dollars that could not sit on the referenced fund. */
  budgetExceptionValue: number;
  /** True when that exception is material enough to need review. */
  needsTradeFinanceReview: boolean;
  allocations: FundAllocation[];
  /** Available-to-spend in each fund AFTER this settlement. */
  fundsAfter: {
    fund: TradeFund;
    availableBefore: number;
    allocated: number;
    availableAfter: number;
  }[];
}

export function fundClaimAssessment(
  caseId: string,
  edit?: ClaimEdit
): FundClaimAssessment | null {
  const c = findFundClaimCase(caseId);
  if (!c) return null;

  const claimed = c.invoiceAmount - c.amountPaid;

  const availableOf = (f: TradeFund) => f.accrualBooked - f.priorConsumed;

  const referencedFund = c.funds.find((f) => f.fundId === c.referencedFundId)!;
  const referencedAvailable = availableOf(referencedFund);

  // A reviewer can move the split between the referenced fund and the second
  // fund. The whole claim is still approved — only where the spend lands moves.
  let allocations = c.allocations;
  if (edit?.primaryAllocated != null) {
    const primaryVal = Math.max(0, Math.min(Math.round(edit.primaryAllocated), claimed));
    allocations = c.allocations.map((a) =>
      a.isReferenced
        ? { ...a, allocated: primaryVal }
        : { ...a, allocated: claimed - primaryVal }
    );
  }

  const allocatedTotal = allocations.reduce((s, a) => s + a.allocated, 0);
  const referencedAllocated = allocations
    .filter((a) => a.fundId === c.referencedFundId)
    .reduce((s, a) => s + a.allocated, 0);
  const overflow = allocatedTotal - referencedAllocated;

  const reconciles = allocatedTotal === claimed;
  // Every allocation must fit inside the fund it lands on.
  const fullyFunded = allocations.every((a) => a.allocated <= a.available);

  // The exception is the part of the claim the referenced fund could not hold.
  const budgetExceptionValue = Math.max(0, claimed - referencedAvailable);
  const needsTradeFinanceReview =
    budgetExceptionValue > c.materialityThreshold;

  const fundsAfter = c.funds.map((fund) => {
    const availableBefore = availableOf(fund);
    const allocated = allocations
      .filter((a) => a.fundId === fund.fundId)
      .reduce((s, a) => s + a.allocated, 0);
    return {
      fund,
      availableBefore,
      allocated,
      availableAfter: availableBefore - allocated,
    };
  });

  if (process.env.NODE_ENV !== "production" && !edit) {
    if (allocatedTotal !== claimed)
      console.error(
        `[fund claim] ${caseId}: allocations do not sum to the amount withheld`,
        { claimed, allocatedTotal }
      );
  }

  return {
    case: c,
    claimed,
    allocatedTotal,
    referencedFund,
    referencedAvailable,
    referencedAllocated,
    overflow,
    fullyFunded,
    reconciles,
    budgetExceptionValue,
    needsTradeFinanceReview,
    allocations,
    fundsAfter,
  };
}

/* ------------------------------------------------------------------ *
 * What it does to the books
 * ------------------------------------------------------------------ */

export interface FundClaimAccounting {
  /** The whole valid claim is a genuine trade cost. */
  gtnImpact: number;
  /** Nothing is clawed back — the claim is valid and paid in full. */
  recoveryRequired: number;
  lines: {
    lineNumber: number;
    glAccount: string;
    accountName: string;
    plainName: string;
    debit?: number;
    credit?: number;
  }[];
}

/**
 * Full approval, split across two funds. The whole $180,000 is a genuine
 * trade-spend cost and settles against the deduction with one credit memo.
 * The expense and accrual release land on the two funds in proportion to the
 * allocation, so each fund's actual spend matches where the promotion ran.
 */
export function fundClaimAccounting(
  caseId: string,
  edit?: ClaimEdit
): FundClaimAccounting | null {
  const a = fundClaimAssessment(caseId, edit);
  if (!a) return null;

  const lines = a.allocations.map((al, i) => ({
    lineNumber: (i + 1) * 10,
    glAccount: al.isReferenced ? "455100" : "455150",
    accountName: `Trade spend — ${al.spendType.toLowerCase()}`,
    plainName: `${al.eventName} settled to ${al.fundName}`,
    debit: al.allocated,
  }));

  return {
    gtnImpact: a.claimed,
    recoveryRequired: 0,
    lines: [
      ...lines,
      {
        lineNumber: (a.allocations.length + 1) * 10,
        glAccount: "121500",
        accountName: "Deduction clearing — retail channel",
        plainName: "Deduction cleared by credit memo",
        credit: a.claimed,
      },
    ],
  };
}

/* ------------------------------------------------------------------ *
 * The retailer response
 * ------------------------------------------------------------------ */

export function renderFundClaimLetter(
  caseId: string,
  edit?: ClaimEdit
): { subject: string; body: string } | null {
  const a = fundClaimAssessment(caseId, edit);
  if (!a) return null;
  const c = a.case;
  const usd = (n: number) => `$${n.toLocaleString("en-US")}`;

  const primary = a.allocations.find((x) => x.isReferenced)!;
  const secondary = a.allocations.find((x) => !x.isReferenced)!;

  const tokens: Record<string, string> = {
    remittanceId: c.remittanceId,
    receivedDate: c.receivedDate,
    claimed: usd(a.claimed),
    invoiceId: c.invoiceId,
    claimRef: c.claimRef,
    primaryAllocated: usd(primary.allocated),
    primaryFund: primary.fundName,
    secondaryAllocated: usd(secondary.allocated),
    secondaryFund: secondary.fundName,
    from: c.responseLetter.from,
  };

  const fill = (t: string) =>
    t.replace(/\{(\w+)\}/g, (whole, key: string) => tokens[key] ?? whole);

  return {
    subject: fill(c.responseLetter.subjectTemplate),
    body: fill(c.responseLetter.bodyTemplate),
  };
}
