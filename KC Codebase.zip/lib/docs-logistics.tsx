import type { SourceDoc } from "@/components/modals/source-doc-preview";
import { TRANSPORT_LEAD } from "@/lib/data/account-owners";
import { TMS_SYSTEM } from "@/lib/data/order-logistics";
import { APPOINTMENT_CASE, MILK_RUN_CASE, PREMIUM_CASE } from "@/lib/data/shipment-risk";
import { formatUsd } from "@/lib/format";
import {
  fmtHm,
  milkRunSummary,
  optionOutcome,
  premiumFreight,
  recommendedRoute,
  routeResults,
  shortStamp,
} from "@/lib/shipment-selectors";

/**
 * The documents behind every logistics step: the TMS plans the agents read,
 * the retailer calendars, and what they write (replans, the premium freight
 * plan, the OTIF notice). IDs and figures match the run screens exactly.
 */

const TMS_ISSUER = `${TMS_SYSTEM} · Transportation Management`;

/* ---------------- Happy path ---------------- */

export function buildAppointmentConfirmationDoc(input: {
  orderId: string;
  appointmentId: string;
  portal: string;
  shipTo: string;
  dock: string;
  window: string;
  otifWindow: string;
  carrier: string;
  loadId: string;
  poNumber: string;
}): SourceDoc {
  return {
    docId: `appt-${input.appointmentId}`,
    title: `Appointment ${input.appointmentId}`,
    docLabel: "Receiving appointment confirmation",
    reference: input.appointmentId,
    issuer: input.portal,
    meta: [
      { label: "Ship-to", value: input.shipTo },
      { label: "Dock", value: input.dock },
      { label: "Window", value: input.window },
      { label: "OTIF window", value: input.otifWindow },
      { label: "PO", value: input.poNumber },
      { label: "Sales order", value: input.orderId },
      { label: "Carrier", value: input.carrier },
      { label: "TMS load", value: input.loadId },
    ],
    columns: [
      { key: "check", label: "Check" },
      { key: "result", label: "Result" },
    ],
    rows: [
      { id: "window", cells: { check: "Slot inside the OTIF window", result: "Pass" } },
      { id: "eta", cells: { check: "Slot after the TMS expected delivery", result: "Pass" } },
      { id: "calendar", cells: { check: "Retailer calendar blocked for this load", result: "Blocked" } },
    ],
    highlightRowIds: ["window"],
    highlightNote: "The slot sits inside the customer's OTIF window.",
  };
}

/* ---------------- Run A ---------------- */

const a = APPOINTMENT_CASE;

export function buildRunATmsPlanDoc(): SourceDoc {
  return {
    docId: `tms-${a.tmsPlan.loadId}`,
    title: `TMS load ${a.tmsPlan.loadId}`,
    docLabel: "Shipment plan",
    reference: a.tmsPlan.loadId,
    issuer: TMS_ISSUER,
    skin: "sap",
    meta: [
      { label: "Sales order", value: a.orderId },
      { label: "Customer PO", value: a.poNumber },
      { label: "Route", value: a.tmsPlan.route },
      { label: "Load", value: a.tmsPlan.load },
      { label: "Carrier", value: a.tmsPlan.carrier },
      { label: "Rate", value: formatUsd(a.tmsPlan.rateUsd) },
    ],
    columns: [
      { key: "event", label: "Event" },
      { key: "at", label: "Planned" },
    ],
    rows: [
      { id: "pickup", cells: { event: "Pickup at DC-ONT", at: shortStamp(a.tmsPlan.pickup) } },
      { id: "eta", cells: { event: `Expected delivery at ${a.shipTo}`, at: shortStamp(a.tmsPlan.eta) } },
    ],
    highlightRowIds: ["eta"],
    highlightNote: "The agent books the receiving slot against this expected delivery.",
  };
}

export function buildRunACalendarDoc(): SourceDoc {
  return {
    docId: `cal-${a.caseId}`,
    title: `${a.portal} · RDC 6094`,
    docLabel: "Receiving calendar snapshot",
    reference: a.caseId,
    issuer: a.portal,
    meta: [
      { label: "Site", value: a.shipTo },
      { label: "OTIF window", value: a.otifWindow.label },
      { label: "Rule", value: a.otifWindow.rule },
      { label: "Read at", value: a.requestSentAt },
    ],
    columns: [
      { key: "day", label: "Day" },
      { key: "open", label: "Open slots" },
      { key: "window", label: "In window" },
    ],
    rows: a.calendar.map((d) => {
      const open = d.slots.filter((s) => s.state === "open").map((s) => s.time);
      const inWindow = d.date.split(" ")[1] <= a.otifWindow.mabd;
      return {
        id: d.date,
        cells: { day: d.date, open: open.length ? open.join(", ") : "None", window: inWindow ? "Yes" : "After MABD" },
      };
    }),
    highlightRowIds: a.calendar.filter((d) => d.date.split(" ")[1] <= a.otifWindow.mabd).map((d) => d.date),
    highlightNote: "No open slot from Monday to the MABD on Wednesday.",
  };
}

export function buildRunAConfirmationDoc(): SourceDoc {
  return {
    docId: `appt-${a.appointment.id}`,
    title: `Appointment ${a.appointment.id}`,
    docLabel: "DC slot confirmation",
    reference: a.appointment.id,
    issuer: a.reply.role,
    meta: [
      { label: "From", value: `${a.reply.from}, ${a.reply.role}` },
      { label: "Received", value: a.reply.at },
      { label: "Window", value: a.appointment.label },
      { label: "Door", value: a.appointment.door },
      { label: "PO", value: a.poNumber },
    ],
    columns: [{ key: "text", label: "Message" }],
    rows: [{ id: "reply", cells: { text: a.reply.text } }],
    highlightRowIds: ["reply"],
  };
}

export function buildRunAReplanDoc(): SourceDoc {
  return {
    docId: `replan-${a.replan.id}`,
    title: `TMS replan ${a.replan.id}`,
    docLabel: "Load replan",
    reference: a.replan.id,
    issuer: TMS_ISSUER,
    skin: "sap",
    meta: [
      { label: "Load", value: a.tmsPlan.loadId },
      { label: "Reason", value: `Receiving slot ${a.appointment.id}` },
      { label: "Accepted", value: a.replan.acceptedAt },
    ],
    columns: [
      { key: "field", label: "Field" },
      { key: "was", label: "Was" },
      { key: "now", label: "Now" },
    ],
    rows: [
      { id: "pickup", cells: { field: "Pickup", was: shortStamp(a.tmsPlan.pickup), now: shortStamp(a.replan.pickup) } },
      { id: "eta", cells: { field: "Expected delivery", was: shortStamp(a.tmsPlan.eta), now: shortStamp(a.replan.eta) } },
      { id: "appt", cells: { field: "Appointment", was: "None", now: `${a.appointment.id} · ${a.appointment.door}` } },
      { id: "rate", cells: { field: "Rate", was: formatUsd(a.tmsPlan.rateUsd), now: formatUsd(a.tmsPlan.rateUsd) } },
    ],
    highlightRowIds: ["eta"],
    highlightNote: "Pickup moves to Tue 08-25 so the truck arrives for the slot; rate unchanged.",
  };
}

/* ---------------- Run B ---------------- */

const b = PREMIUM_CASE;

export function buildRunBTmsPlanDoc(): SourceDoc {
  const keep = b.options.find((o) => o.id === "keep")!;
  return {
    docId: `tms-${b.caseId}`,
    title: `TMS plan · ${b.orderId}`,
    docLabel: "Shipment plan after tender rejection",
    reference: b.caseId,
    issuer: TMS_ISSUER,
    skin: "sap",
    meta: [
      { label: "Route", value: b.route },
      { label: "Load", value: b.load },
      { label: "Tender rejected", value: `${b.rejection.carrier} · ${b.rejection.at}` },
      { label: "Reason", value: b.rejection.reason },
      { label: "Appointment", value: `${b.appointment.id} · ${b.appointment.label}` },
    ],
    columns: [
      { key: "field", label: "Field" },
      { key: "value", label: "TMS replan" },
    ],
    rows: [
      { id: "carrier", cells: { field: "Carrier", value: keep.carrier } },
      { id: "pickup", cells: { field: "Pickup", value: shortStamp(keep.pickup) } },
      { id: "eta", cells: { field: "Expected delivery", value: shortStamp(keep.eta) } },
      { id: "rate", cells: { field: "Rate", value: formatUsd(keep.rateUsd) } },
    ],
    highlightRowIds: ["eta"],
    highlightNote: "The replanned arrival is after the Wednesday appointment.",
  };
}

export function buildRunBOptionsDoc(): SourceDoc {
  return {
    docId: `options-${b.caseId}`,
    title: `Freight options · ${b.caseId}`,
    docLabel: "Freight options compared",
    reference: b.caseId,
    issuer: TMS_ISSUER,
    skin: "sap",
    meta: [
      { label: "Order value", value: formatUsd(b.valueUsd) },
      { label: "OTIF fine", value: `${b.fineRatePct}% of order value · ${formatUsd(premiumFreight.fineUsd)}` },
    ],
    columns: [
      { key: "option", label: "Option" },
      { key: "eta", label: "ETA" },
      { key: "rate", label: "Rate", align: "right" },
      { key: "otif", label: "OTIF" },
    ],
    rows: b.options.map((o) => {
      const r = optionOutcome(o.id);
      return {
        id: o.id,
        cells: {
          option: `${o.label} · ${o.carrier}`,
          eta: shortStamp(o.eta),
          rate: formatUsd(o.rateUsd),
          otif: r.pass ? "Pass" : !r.inFull ? `Short ${b.pallets - o.pallets} pallets` : `Late ${r.lateDays} day`,
        },
      };
    }),
    highlightRowIds: ["team"],
    highlightNote: "The only option that arrives on time and in full.",
  };
}

export function buildPremiumPlanDoc(signedBy?: string): SourceDoc {
  const team = b.options.find((o) => o.id === "team")!;
  return {
    docId: `pfp-${b.plan.id}`,
    title: `Premium freight plan ${b.plan.id}`,
    docLabel: "Premium freight plan",
    reference: b.plan.id,
    issuer: TMS_ISSUER,
    skin: "sap",
    meta: [
      { label: "Sales order", value: b.orderId },
      { label: "Customer", value: b.customer },
      { label: "Carrier", value: team.carrier },
      { label: "Pickup", value: shortStamp(team.pickup) },
      { label: "ETA", value: shortStamp(team.eta) },
      { label: "Reason", value: b.plan.reason },
      { label: "Cost center", value: b.plan.costCenter },
    ],
    columns: [
      { key: "item", label: "Item" },
      { key: "amount", label: "Amount", align: "right" },
    ],
    rows: [
      { id: "rate", cells: { item: "Expedite rate", amount: formatUsd(premiumFreight.rateUsd) } },
      { id: "base", cells: { item: "TMS replan rate", amount: formatUsd(premiumFreight.baseUsd) } },
      { id: "premium", cells: { item: "Premium freight", amount: formatUsd(premiumFreight.premiumUsd) } },
      { id: "fine", cells: { item: "OTIF fine avoided", amount: formatUsd(premiumFreight.fineUsd) } },
    ],
    totals: [{ label: "Net benefit", value: formatUsd(premiumFreight.netUsd), emphasis: true }],
    signature: [
      { label: "Approved by", value: signedBy ? `${signedBy}, ${TRANSPORT_LEAD.role}` : undefined },
    ],
    highlightRowIds: ["premium"],
    highlightNote: "Inside the $2,500 premium freight limit.",
  };
}

/* ---------------- Run C ---------------- */

const m = MILK_RUN_CASE;

export function buildTrackingReportDoc(): SourceDoc {
  const first = routeResults[0].timeline;
  return {
    docId: `fk-${m.caseId}`,
    title: `FourKites tracking · ${m.loadId}`,
    docLabel: "Tracking report",
    reference: m.loadId,
    issuer: "FourKites",
    meta: [
      { label: "Carrier", value: m.carrier },
      { label: "Equipment", value: m.equipment },
      { label: "Planned departure", value: m.plannedDepart },
      { label: "Actual departure", value: `${m.actualDepart} · ${m.delayReason}` },
    ],
    columns: [
      { key: "stop", label: "Stop" },
      { key: "window", label: "Window" },
      { key: "eta", label: "ETA" },
      { key: "source", label: "Source" },
    ],
    rows: first.map((t) => ({
      id: t.stop.id,
      cells: {
        stop: t.stop.site,
        window: `${t.stop.windowFrom}–${t.stop.windowTo}`,
        eta: fmtHm(t.arrive),
        source: m.fourKitesPeta[t.stop.id] ? "FourKites PETA" : "Agent ETA",
      },
    })),
    highlightRowIds: first.filter((t) => t.miss).map((t) => t.stop.id),
    highlightNote: "Every stop now arrives after its window closes.",
  };
}

export function buildRouteOptionsDoc(): SourceDoc {
  return {
    docId: `routes-${m.caseId}`,
    title: `Route options · ${m.caseId}`,
    docLabel: "Milk run route options",
    reference: m.caseId,
    issuer: "Track and Trace Agent",
    meta: [
      { label: "Departed", value: m.actualDepart },
      { label: "Unload per stop", value: `${m.unloadMin} min` },
    ],
    columns: [
      { key: "route", label: "Stop order" },
      { key: "arrivals", label: "Arrivals" },
      { key: "misses", label: "OTIF misses", align: "right" },
    ],
    rows: routeResults.map((r) => ({
      id: r.id,
      cells: {
        route: r.order.map((id) => m.stops.find((s) => s.id === id)!.customer).join(" → "),
        arrivals: r.timeline.map((t) => fmtHm(t.arrive)).join(" · "),
        misses: String(r.misses),
      },
    })),
    highlightRowIds: [recommendedRoute.id],
    highlightNote: "Fewest stops outside their window.",
  };
}

export function buildOtifNoticeDoc(): SourceDoc {
  const stop = m.stops.find((s) => s.id === m.reslot.stop)!;
  return {
    docId: `notice-${m.caseId}`,
    title: `Late arrival notice · ${stop.appointmentId}`,
    docLabel: "Late arrival notice",
    reference: stop.appointmentId,
    issuer: "Customer Service · Order Management",
    meta: [
      { label: "To", value: m.reslot.to },
      { label: "Sales order", value: stop.orderId },
      { label: "Booked window", value: `${stop.windowFrom}–${stop.windowTo}` },
      { label: "New arrival", value: milkRunSummary.newArrival },
      { label: "Requested slot", value: m.reslot.window },
    ],
    columns: [{ key: "text", label: "Reason" }],
    rows: [{ id: "reason", cells: { text: `${m.delayReason}; the milk run was resequenced to keep two of three stops on time.` } }],
    highlightRowIds: ["reason"],
  };
}
