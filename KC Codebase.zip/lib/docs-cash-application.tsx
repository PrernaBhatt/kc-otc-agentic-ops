/**
 * Source documents for the Cash Application page.
 *
 * Same rule as lib/docs-chargebacks.tsx: every field is read from the same
 * records the screen reads (lib/data/cash-application.ts + its selectors), so a
 * preview can never disagree with the screen that opened it.
 */

import type { SourceDoc } from "@/components/modals/source-doc-preview";
import { formatUsd } from "./chargeback-selectors";
import { paymentResolution } from "./cash-application-selectors";
import type { CashPayment, RemittanceLine } from "./data/cash-application";

const ISSUER = "Order to Cash Workspace";

/* ------------------------------------------------------------------ *
 * The bank lockbox statement — where the cash actually landed
 * ------------------------------------------------------------------ */

export function buildLockboxDoc(payment: CashPayment): SourceDoc {
  return {
    docId: `lockbox-${payment.paymentId}`,
    title: `Lockbox credit ${payment.paymentId}`,
    docLabel: "Bank lockbox statement",
    reference: payment.paymentId,
    issuer: "JPMorgan Chase — Wholesale Lockbox",
    docDate: payment.receivedDate,
    meta: [
      { label: "Deposit date", value: payment.receivedDate },
      { label: "Originator", value: payment.customer },
      { label: "Method", value: "ACH CCD+ with addenda" },
      { label: "Lockbox", value: "70114 — Consumer & Professional" },
    ],
    columns: [
      { key: "item", label: "Bank record" },
      { key: "value", label: "Value", align: "right" },
    ],
    rows: [
      {
        id: "amount",
        cells: { item: "Credit amount", value: formatUsd(payment.amount) },
      },
      {
        id: "trace",
        cells: { item: "ACH trace number", value: "021000021-4471902" },
      },
      {
        id: "addenda",
        cells: {
          item: "Remittance addenda records",
          value: `${payment.remittanceItemCount} line items`,
        },
      },
      {
        id: "currency",
        cells: { item: "Currency", value: "USD" },
      },
    ],
    totals: [
      { label: "Posted to bank GL", value: formatUsd(payment.amount), emphasis: true },
    ],
    highlightRowIds: ["amount"],
    highlightNote:
      "The cash is real and already in the bank — cash application decides which receivables it clears, never whether the money arrived.",
    footnote:
      "A lockbox credit lands as a single amount. The matching work is splitting it back into the invoices, credits and deductions it was meant to pay.",
  };
}

/* ------------------------------------------------------------------ *
 * The remittance advice — how the customer says the payment breaks down
 * ------------------------------------------------------------------ */

export function buildRemittanceDoc(payment: CashPayment): SourceDoc {
  const r = paymentResolution(payment);
  const sampleLines = payment.lines.filter((l) => !l.isAggregate);
  const aggregate = payment.lines.find((l) => l.isAggregate);

  const rows = sampleLines.map((line) => ({
    id: line.lineId,
    cells: {
      ref: line.customerRef,
      type: typeWord(line),
      value: formatUsd(line.amount),
    },
  }));

  if (aggregate) {
    rows.push({
      id: aggregate.lineId,
      cells: {
        ref: `+ ${(aggregate.aggregateCount ?? 0).toLocaleString("en-US")} more invoices`,
        type: "Invoice",
        value: formatUsd(aggregate.amount),
      },
    });
  }

  return {
    docId: `remittance-${payment.paymentId}`,
    title: `Remittance advice — ${payment.customer}`,
    docLabel: "Customer remittance advice",
    reference: payment.paymentId,
    issuer: `${payment.customer} — Accounts Payable`,
    docDate: payment.receivedDate,
    meta: [
      { label: "Payer", value: payment.customer },
      { label: "Payment reference", value: payment.paymentId },
      { label: "Lines on advice", value: `${payment.remittanceItemCount}` },
      { label: "Stated total", value: formatUsd(payment.amount) },
    ],
    columns: [
      { key: "ref", label: "Customer reference" },
      { key: "type", label: "Applied as" },
      { key: "value", label: "Amount", align: "right" },
    ],
    rows,
    totals: [
      { label: "Invoices", value: formatUsd(r.matched) },
      { label: "Credits", value: formatUsd(r.credits) },
      { label: "Deductions", value: `(${formatUsd(r.deductions)})` },
      { label: "Unidentified", value: formatUsd(r.unidentified) },
      { label: "Remittance total", value: formatUsd(payment.amount), emphasis: true },
    ],
    highlightRowIds: sampleLines
      .filter((l) => l.type === "deduction" || l.type === "unidentified")
      .map((l) => l.lineId),
    highlightNote:
      "The customer's own reference numbers don't map to SAP document numbers — which is why every line still has to be matched, not just trusted.",
    footnote:
      "Retailers pay net of deductions and cite their own PO and store numbers. The remittance is a claim about how to apply the cash, not an instruction SAP can post directly.",
  };
}

/* ------------------------------------------------------------------ *
 * A single matched SAP open item — the evidence behind one cleared line
 * ------------------------------------------------------------------ */

export function buildSapOpenItemDoc(line: RemittanceLine): SourceDoc {
  return {
    docId: `sap-openitem-${line.lineId}`,
    title: `SAP open item ${line.sapDocument}`,
    docLabel: `SAP FI open item ${line.sapDocument}`,
    reference: line.sapDocument,
    issuer: "SAP S/4HANA — Accounts Receivable (FBL5N)",
    skin: "sap",
    meta: [
      { label: "Document number", value: line.sapDocument ?? "—" },
      { label: "Document type", value: line.type === "credit" ? "Credit memo (DG)" : "Invoice (RV)" },
      { label: "Open amount", value: formatUsd(line.amount) },
      { label: "Clearing status", value: "Open — awaiting incoming payment" },
    ],
    columns: [
      { key: "field", label: "Field" },
      { key: "value", label: "Value", align: "right" },
    ],
    rows: [
      { id: "cust", cells: { field: "Customer reference on remittance", value: line.customerRef } },
      { id: "amt", cells: { field: "Amount", value: formatUsd(line.amount) } },
      {
        id: "strat",
        cells: { field: "AI match strategy", value: matchStrategyLabel(line) },
      },
      {
        id: "conf",
        cells: { field: "Match confidence", value: `${line.confidence}%` },
      },
    ],
    totals: [
      { label: "Clears against this document", value: formatUsd(line.amount), emphasis: true },
    ],
    highlightRowIds: ["strat", "conf"],
    highlightNote:
      "The remittance never carried this SAP number. The AI resolved it by amount, customer, date and shipment — then a person confirms before it clears.",
    footnote:
      "Clearing this open item is what turns a bank credit into a settled receivable in SAP.",
  };
}

/* ------------------------------------------------------------------ *
 * The deduction case register — the system-of-record ledger the run
 * writes every short-pay into, so nothing becomes a silent write-off
 * ------------------------------------------------------------------ */

export function buildDeductionRegisterDoc(payment: CashPayment): SourceDoc {
  const deductions = payment.lines.filter((l) => l.type === "deduction");
  const total = deductions.reduce((s, l) => s + l.amount, 0);

  const rows = deductions.map((line) => ({
    id: line.lineId,
    cells: {
      case: deductionCaseId(line),
      reason: line.reasonCode ?? "—",
      route: line.routeTeam ?? "—",
      system: line.caseSystem ?? "—",
      due: slaDueLabel(payment.receivedDate, line.slaDays),
      amount: formatUsd(line.amount),
    },
  }));

  return {
    docId: `ded-register-${payment.paymentId}`,
    title: `Deduction case register — ${payment.paymentId}`,
    docLabel: "Deduction case register (system of record)",
    reference: payment.paymentId,
    issuer: "Order to Cash Workspace — Dispute & Deduction Management",
    docDate: payment.receivedDate,
    meta: [
      { label: "Opened from payment", value: payment.paymentId },
      { label: "Customer", value: payment.customer },
      { label: "Cases created", value: `${deductions.length}` },
      { label: "Routed to", value: `${new Set(deductions.map((l) => l.caseSystem)).size} systems` },
    ],
    columns: [
      { key: "case", label: "Case" },
      { key: "reason", label: "Reason" },
      { key: "route", label: "Owner" },
      { key: "system", label: "System" },
      { key: "due", label: "SLA due" },
      { key: "amount", label: "Amount", align: "right" },
    ],
    rows,
    totals: [
      { label: "Total under case", value: formatUsd(total), emphasis: true },
      { label: "Written off", value: "$0" },
    ],
    highlightRowIds: rows.map((r) => r.id),
    highlightNote:
      "Every short-paid line is a tracked case with an owner and an SLA — not a write-off. The register is the source of truth these amounts are reconciled against.",
    footnote:
      "Deductions leave cash application as open cases in their routed system. Finance can trace each dollar to a case, its evidence and its SLA until it is settled or recovered.",
  };
}

export function deductionCaseId(line: RemittanceLine): string {
  return `DED-${line.lineId.replace("RL-", "")}${(line.customerRef ?? "").replace(/\D/g, "").slice(-3)}`;
}

/** Add N business days to an ISO date and return a readable due-date label. */
export function slaDueLabel(fromIso: string, slaDays?: number): string {
  if (!slaDays) return "—";
  const d = new Date(fromIso + "T00:00:00");
  let added = 0;
  while (added < slaDays) {
    d.setDate(d.getDate() + 1);
    const day = d.getDay();
    if (day !== 0 && day !== 6) added += 1;
  }
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

/* ------------------------------------------------------------------ *
 * The SAP FI posting document — the balanced journal the run creates
 * ------------------------------------------------------------------ */

export function buildPostingDoc(payment: CashPayment): SourceDoc {
  const r = paymentResolution(payment);
  const docNo = "1400028871";

  return {
    docId: `posting-${payment.paymentId}`,
    title: `SAP posting document ${docNo}`,
    docLabel: `SAP FI document ${docNo}`,
    reference: docNo,
    issuer: "SAP S/4HANA — Financial Accounting (FB05)",
    skin: "sap",
    docDate: payment.receivedDate,
    meta: [
      { label: "Posting date", value: payment.receivedDate },
      { label: "Document type", value: "DZ — customer payment" },
      { label: "Company code", value: "3000" },
      { label: "Reference", value: payment.paymentId },
    ],
    columns: [
      { key: "pk", label: "PK" },
      { key: "account", label: "Account" },
      { key: "debit", label: "Debit", align: "right" },
      { key: "credit", label: "Credit", align: "right" },
    ],
    rows: [
      {
        id: "bank",
        cells: {
          pk: "40",
          account: "113100 · Bank clearing",
          debit: formatUsd(payment.amount),
          credit: "—",
        },
      },
      {
        id: "ar",
        cells: {
          pk: "15",
          account: "140000 · AR — invoices cleared",
          debit: "—",
          credit: formatUsd(r.matched),
        },
      },
      {
        id: "credits",
        cells: {
          pk: "15",
          account: "140000 · AR — credit memos applied",
          debit: "—",
          credit: formatUsd(r.credits),
        },
      },
      {
        id: "ded",
        cells: {
          pk: "40",
          account: "195000 · Deductions clearing (cases open)",
          debit: formatUsd(r.deductions),
          credit: "—",
        },
      },
      {
        id: "residual",
        cells: {
          pk: "40",
          account: "196000 · Payment on account — Walmart (UNID)",
          debit: formatUsd(r.unidentified),
          credit: "—",
        },
      },
    ],
    totals: [
      { label: "Total debits", value: formatUsd(payment.amount) },
      { label: "Total credits", value: formatUsd(payment.amount) },
      { label: "Document balance", value: "$0", emphasis: true },
    ],
    highlightRowIds: ["ded", "residual"],
    highlightNote:
      "Deductions post to a clearing account with their cases still open, and the unidentified $7,000 sits on account to Walmart under reason UNID — neither is written off, so the document balances without hiding anything.",
    footnote:
      "A DZ document only posts when debits equal credits. Every dollar of the bank credit lands on an account, and nothing is forced to zero.",
  };
}

/* ------------------------------------------------------------------ *
 * Helpers
 * ------------------------------------------------------------------ */

function typeWord(line: RemittanceLine): string {
  switch (line.type) {
    case "invoice":
      return "Invoice";
    case "credit":
      return "Credit";
    case "deduction":
      return `Deduction — ${line.reasonCode ?? "reason cited"}`;
    case "unidentified":
      return "Unidentified";
  }
}

export function matchStrategyLabel(line: RemittanceLine): string {
  switch (line.matchStrategy) {
    case "reference":
      return "PO / reference match";
    case "amount-date":
      return "Amount + date + customer";
    case "combined-shipment":
      return "Combined by shipment";
    case "credit-memo":
      return "Credit memo lookup";
    default:
      return "Amount + customer";
  }
}
