/**
 * A reviewer's manual override of a claim decision, taken at the approve gate.
 *
 * Every claim run derives its downstream figures — the credit/debit posting,
 * the gross-to-net impact and the retailer letter — from one split of the
 * amount withheld. This override replaces that split with the reviewer's own,
 * and because the selectors read it, the email and the postings recompute from
 * the same number. Nothing here is stored as a conclusion; it is a single
 * input the pure selectors fold back in.
 */
export interface ClaimEdit {
  /**
   * The portion approved as a genuine trade cost (drives gross-to-net); the
   * remainder is recovered / billed back. Used by the growth-rebate, promo-claim
   * and short-pay runs, where the decision is an approve/recover split.
   */
  approvedAmount?: number;
  /**
   * Fund allocation only: the dollars sitting on the referenced (primary) fund.
   * The remainder overflows to the second eligible fund. The whole claim is
   * still approved — this only moves where the spend lands.
   */
  primaryAllocated?: number;
}
