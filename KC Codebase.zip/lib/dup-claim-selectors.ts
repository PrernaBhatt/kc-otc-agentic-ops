/**
 * The reconciliation behind Scenario 2 — duplicate / resubmitted claim.
 *
 * Two invariants the screen leans on, neither of them stored:
 *   1. previouslySettled + previouslyRejected === claimed
 *      A duplicate is only a duplicate if every dollar of the new claim maps to
 *      value already settled or already rejected. If the parts do not add back
 *      to the claim, the case is not a clean duplicate and must not say it is.
 *   2. confidence = Σ(matchScore × weight) / Σ(weight)
 *      The 96% on the screen is derived from the match signals, so it can never
 *      drift from the evidence beneath it.
 */

import {
  findDupClaimCase,
  type DupClaimCase,
  type DupClaimComponent,
  type DupComponentCategory,
} from "./data/dup-claims";

export interface DupClaimAssessment {
  case: DupClaimCase;
  /** The whole amount re-deducted. */
  claimed: number;
  /** Already given commercial value by a credit memo. */
  previouslySettled: number;
  /** Already rejected with a recorded reason. */
  previouslyRejected: number;
  /** Everything is duplicate here, but the model allows a genuinely new part. */
  genuinelyNew: number;
  /** What we decline and ask back. */
  duplicateValue: number;
  /** 0-1, derived from the weighted match signals. */
  duplicateConfidence: number;
  /** previouslySettled + previouslyRejected + genuinelyNew === claimed. */
  reconciles: boolean;
  byCategory: Record<DupComponentCategory, DupClaimComponent[]>;
}

const EMPTY_GROUPS = (): Record<DupComponentCategory, DupClaimComponent[]> => ({
  "previously-settled": [],
  "previously-rejected": [],
});

const sumBy = (
  items: DupClaimComponent[],
  pred: (c: DupClaimComponent) => boolean
) => items.filter(pred).reduce((s, c) => s + c.amount, 0);

export function dupClaimAssessment(caseId: string): DupClaimAssessment | null {
  const c = findDupClaimCase(caseId);
  if (!c) return null;

  const claimed = c.invoiceAmount - c.amountPaid;

  const previouslySettled = sumBy(
    c.components,
    (x) => x.category === "previously-settled"
  );
  const previouslyRejected = sumBy(
    c.components,
    (x) => x.category === "previously-rejected"
  );
  const duplicateValue = previouslySettled + previouslyRejected;
  const genuinelyNew = claimed - duplicateValue;

  const byCategory = c.components.reduce((acc, x) => {
    acc[x.category].push(x);
    return acc;
  }, EMPTY_GROUPS());

  const totalWeight = c.signals.reduce((s, x) => s + x.weight, 0);
  const scored = c.signals.reduce((s, x) => s + x.matchScore * x.weight, 0);
  const duplicateConfidence = totalWeight === 0 ? 0 : scored / totalWeight;

  const reconciles = previouslySettled + previouslyRejected + genuinelyNew === claimed;

  if (process.env.NODE_ENV !== "production") {
    if (duplicateValue !== claimed)
      console.error(
        `[dup claim] ${caseId}: settled + rejected does not equal the amount re-deducted`,
        { claimed, previouslySettled, previouslyRejected }
      );
  }

  return {
    case: c,
    claimed,
    previouslySettled,
    previouslyRejected,
    genuinelyNew,
    duplicateValue,
    duplicateConfidence,
    reconciles,
    byCategory,
  };
}

/* ------------------------------------------------------------------ *
 * What it does to the books
 * ------------------------------------------------------------------ */

export interface DupClaimAccounting {
  /** Nothing new is a trade cost — the original event was already expensed. */
  gtnImpact: number;
  /** The full claim is declined and the receivable stands. */
  recoveryRequired: number;
  receivableStillCollectible: number;
  /** Double payment stopped by rejecting the duplicate. */
  doublePaymentAvoided: number;
  lines: {
    lineNumber: number;
    glAccount: string;
    accountName: string;
    plainName: string;
    debit?: number;
    credit?: number;
  }[];
}

/**
 * A duplicate reject touches gross-to-net not at all. The supported part was
 * already expensed when credit memo CM-KR-4471 was issued last year, and the
 * rejected part never was. So the entry simply reinstates the receivable the
 * retailer tried to withhold; expensing any of it again is exactly the leakage
 * this case exists to stop.
 */
export function dupClaimAccounting(caseId: string): DupClaimAccounting | null {
  const a = dupClaimAssessment(caseId);
  if (!a) return null;
  const settled = a.byCategory["previously-settled"][0];

  return {
    gtnImpact: 0,
    recoveryRequired: a.claimed,
    receivableStillCollectible: a.claimed,
    doublePaymentAvoided: a.previouslySettled,
    lines: [
      {
        lineNumber: 10,
        glAccount: "121500",
        accountName: "Deduction clearing — retail channel",
        plainName: `Receivable reinstated — ${a.case.customerName}`,
        debit: a.claimed,
      },
      {
        lineNumber: 20,
        glAccount: "229300",
        accountName: "Trade promotion accrual",
        plainName: `No draw — already settled on ${settled?.priorRef ?? a.case.originalClaimRef}`,
        credit: a.claimed,
      },
    ],
  };
}

/* ------------------------------------------------------------------ *
 * The retailer response
 * ------------------------------------------------------------------ */

export function renderDupClaimLetter(
  caseId: string
): { subject: string; body: string } | null {
  const a = dupClaimAssessment(caseId);
  if (!a) return null;
  const c = a.case;
  const p = c.promotion;
  const settled = a.byCategory["previously-settled"][0];
  const rejected = a.byCategory["previously-rejected"][0];

  const usd = (n: number) => `$${n.toLocaleString("en-US")}`;

  const tokens: Record<string, string> = {
    remittanceId: c.remittanceId,
    receivedDate: c.receivedDate,
    claimed: usd(a.claimed),
    invoiceId: c.invoiceId,
    resubmittedClaimRef: c.resubmittedClaimRef,
    resubmittedReasonCode: c.resubmittedReasonCode,
    promotionId: p.promotionId,
    promotionName: p.name,
    windowStart: p.windowStart,
    windowEnd: p.windowEnd,
    originalClaimRef: c.originalClaimRef,
    settled: usd(a.previouslySettled),
    settledRef: settled?.priorRef ?? "",
    settledDate: settled?.priorDate ?? "",
    rejected: usd(a.previouslyRejected),
    rejectedRef: rejected?.priorRef ?? "",
    rejectedDate: rejected?.priorDate ?? "",
    from: c.responseLetter.from,
  };

  const fill = (t: string) =>
    t.replace(/\{(\w+)\}/g, (whole, key: string) => tokens[key] ?? whole);

  return {
    subject: fill(c.responseLetter.subjectTemplate),
    body: fill(c.responseLetter.bodyTemplate),
  };
}

export const DUP_CATEGORY_LABEL: Record<DupComponentCategory, string> = {
  "previously-settled": "Previously settled",
  "previously-rejected": "Previously rejected",
};

export const LINEAGE_KIND_LABEL: Record<string, string> = {
  promotion: "Promotion",
  claim: "Original claim",
  credit: "Credit memo",
  rejection: "Rejection",
  resubmission: "Resubmission",
};
