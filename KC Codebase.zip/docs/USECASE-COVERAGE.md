# Use-Case Coverage Matrix

Target: 100% of the gap slide (S1–S7) and the Cash & Collections Excel
(E1–E6, 48 detailed activities). Status values: `planned` → `built` → `verified`.

## Gap slide

| # | Use case | Mount | Status |
|---|----------|-------|--------|
| S1 | Distributor PO Received | Order Management → Capture stage panel (inbound PO doc, channel chip) | built |
| S2 | AI PO Understanding | Order Management → Capture panel (extraction fields: product, customer, minimum quantity, contract) | built |
| S3 | Regulatory & Product Checks | Order Management Regulatory stage + Exceptions "Quality Hold" + Review Order Hold HITL card | built |
| S4 | Pricing & Commercial Validation | Order Management → Pricing stage panel (contract price tie-out, discount approval, payment terms) | built |
| S5 | Fulfillment Process | Order Management fulfillment tracker + extended fulfillment flow (carrier milestones) | built |
| S6 | Proof of Delivery & Billing | Billing → four-document reconciliation + POD doc + tax/completeness checklist | built |
| S7 | Customer Query Management Hub | Co-Pilot → Query Hub tab (7 scopes, AI classification, owner, response target, approve & send) | built |

## Excel processes (8 activities each)

| # | Process | Mount | Activities covered | Status |
|---|---------|-------|--------------------|--------|
| E1 | Cash Application | Transactions → Cash Application tab | 1 receive bank file · 2 capture remittance · 3 identify customer · 4 match rules · 5 post & clear · 6 route exceptions · 7 resolve unapplied · 8 reconcile | built |
| E2 | Deductions & Disputes | Exceptions → Deduction cases | 1 auto-create case · 2 reason coding · 3 collect documents · 4 root cause · 5 validate · 6 route by reason/value · 7 resolve (credit memo/rebill/repay/write-off) · 8 prevent recurrence | built |
| E3 | Collections | Collections → Priority Worklist + existing workbench | 1 refresh aging/segment · 2 prioritize worklist · 3 reminders/dunning · 4 contact & promise · 5 track promises · 6 escalate · 7 credit hold/payment plan · 8 forecast update | built |
| E4 | Bad Debt Provision | Collections → Bad Debt Provision tab | 1 extract balances · 2 segment by risk/age · 3 loss rates · 4 specific reserves · 5 required vs booked · 6 record adjustment · 7 controller approval · 8 write-off authority | built |
| E5 | Revenue Recognition | Billing → Revenue Recognition tab | 1 identify contract · 2 obligations · 3 transaction price · 4 allocation · 5 recognize on delivery · 6 accruals · 7 cut-off · 8 reconcile & explain | built |
| E6 | Period-End Close | Dashboard → Period-End Close checklist | 1 billing completeness · 2 unapplied cash · 3 subledger vs ledger · 4 deductions review · 5 provision finalized · 6 revenue cut-off · 7 approvals & lock · 8 publish reporting | built |

## K-C feedback round (PRD `docs/prd/01-kc-feedback-prd.md`)

| # | Feedback | Mount | Trade / non-trade | Owner | SOX | Status |
|---|----------|-------|-------------------|-------|-----|--------|
| 1 | Billing: invoice not reissued, gap settles in FSCM dispute | Billing → SO-710269 dispute run (7 stages) | n/a | Marcus Hale · Costco | 1.4.3, 1.4.4 (Controller co-sign) | built |
| 2 | Target bills at K-C contract price | Order Management → SO-710249 pricing hold | n/a | Jim Novak · Target | 1.4.1 | built |
| 3 | Costco touchless shortened; invoice-to-cash | Order Management → SO-710260 (9 stages, ends on Appointment) + Dashboard KPIs | n/a | Marcus Hale · Costco | n/a | built |
| 4 | Deductions split by value / volume | Deductions → Trade (Walmart fund) · Non-trade (batch NT-2026-W44) | Trade + Non-trade | Account owner per claim | 1.7.2 (trade), 1.4.5 (non-trade) | built |
| 5 | One owner per account, escalations tracked | Accounts page + owner chips on every module | both | 6 account owners | n/a | built |
| 6 | SOX control refs and exportable audit | Control tags on every gate + Audit trail (CSV / PDF) | both | Signer per gate | 1.4.x, 1.7.x | built |

## K-C OM round (PRD `docs/prd/02-kc-om-otif-prd.md`)

| # | Enhancement | Mount | Owner | SOX | Status |
|---|-------------|-------|-------|-----|--------|
| 1 | Appointment scheduling | Order run last stage "Appointment" (SO-710260 Costco, SO-710249 Target) + Shipments → Run A SHP-58201 Walmart (no slot → buyer → DC slot → TMS replan, 5 stages) | Appointment Scheduling Agent | n/a | built |
| 2 | Track and trace | Shipments → Run C MR-58212 milk run (FourKites PETA + agent ETA → cascade → 3 routes → approve → dispatch & notify) | Priya Raman · Transportation | 1.2.2 | built |
| 3 | OM Command Center metrics | Dashboard row 1: OTIF A > S > D · Perfect order · Order validation accuracy · Order-to-invoice | n/a | n/a | built |
| 4 | OTIF at risk (predictive) | Dashboard row 2 + Shipments board (4 pre / 3 post) → Run B SHP-58207 Kroger premium freight (gate) | Priya Raman · Transportation | 1.2.1 | built |

## Cross-cutting

| Item | Mount | Status |
|------|-------|--------|
| SourceDocPreview modal (yellow highlights + typed AI summary) on every surface | components/modals/source-doc-preview.tsx | built |
| New agent workflow cards (Cash Application, Deduction, Regulatory Check, Query Triage, Provision agents) | Agent Activity | built |
| Numbers co-move (store + selectors; no hardcoded numbers in components) | lib/store.tsx + lib/selectors.ts | built |

## Ten-stage workflow re-cut

Status as of the cross-cutting wiring pass (checked against files on disk;
"in progress" = data/doc layer landed, view surface still being mounted by
its owning agent).

| Item | Mount | Status |
|------|-------|--------|
| 10-stage pipeline (po_intake → collections stage ids) | Order Management → pipeline re-cut | in progress (view still on previous stage ids at last check) |
| Inventory allocation workspace (Gap 3) | Order Management fulfillment stage; data in lib/data/inventory.ts + buildStockLedgerDoc | in progress (ledger doc built and opened from the master card; workspace surface pending) |
| PO anomaly highlighting (Gap 1Δ) | Order Management → PO Understanding attention row; data in lib/data/pipeline-orders.ts (anomalyPo) | in progress (anomaly PO doc built and opened from the master card; pipeline row pending) |
| Reconciliation mismatch case (Gap 6Δ) | Billing reconciliation | in progress (no mismatch-case surface on disk yet) |
| Short-pay closing loop (Gap 10) | Exceptions deduction card resolved-state line + Collections worklist "Deduction resolved" flag (lib/selectors.ts) | built |
| Billing stage source docs + HITL invoicing | components/mounts/billing/stage-panels.tsx (buildBillingReportDoc + store issueInvoice approve flow) | built |
| End-to-end master card (10 stages, one document per stage) | Agent Activity → components/agents/end-to-end-workflow-card.tsx | built |
