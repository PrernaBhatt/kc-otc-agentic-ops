# Canonical Data Notes — deliberate fixes vs the compiled demo

The compiled demo hardcoded numbers per component; several conflicted. The
canonical layer (lib/data + lib/selectors + lib/store) fixes these. Every fix
below is intentional (Phase 2), not a porting error.

1. **Duplicate SO-710248** — the compiled Review Order Hold view had an inline
   second order "SO-710248 / TechCorp Industries / $185,000 / Hold" while the
   central store had "SO-710248 / Global Manufacturing Inc. / $275,000 /
   Fulfilled". Fix: the hold-review card becomes **SO-710252 / TechCorp
   Industries** (new id) so both stories coexist without colliding.
   (TechCorp Industries is added as CUST-004 with matching credit data.)
2. **INV-12347 "Overdue" with future due date** — status said Overdue but the
   due date (2025-02-04) is after the demo date (2025-01-20). Fix: due date
   moved to 2024-12-21 (30 days late at the demo date) so aging, dunning and
   the provision all compute honestly.
3. **Aging ladder** — three older invoices (INV-12341/42/43) extend the AR
   book so collections, aging and provisioning have a real ladder. The
   Transactions "Invoices" tab labels itself "recent invoices" and the aging
   report covers the full book; the two sets are explicitly labeled.
4. **Demo clock** — all "days late" math anchors to TODAY = 2025-01-20
   (lib/data/clock.ts), never the wall clock, so the demo is deterministic.
5. **Dashboard status cards** ("20 Auto-completed / 9 Credit Evaluation / 10
   Invoices processed") were hardcoded; they remain seeded constants until a
   run-log entity backs them — documented as period-to-date counters, not
   derivable from the 4 visible orders.
6. **KPI tiles** (Credit Holds 12, DSO 38, etc.) are period-level metrics fed
   by the trend series, not counts of the handful of demo records; the KPI
   drilldowns label them as month-to-date so the difference is explicit.
7. **Payment propensity 75% (ABC Traders)** appears in both the dunning
   workbench and the credit decision — now sourced from one map in
   lib/selectors.ts (`paymentPropensity`).
8. **Canonical order book extended to 8 orders** — SO-710249 (Global
   Manufacturing Inc., $77,760, the order behind the Pricing Mismatch
   exception EXC-003) and the three billing-stage orders SO-710270 (ABC
   Traders, $125,000), SO-710271 (Global Manufacturing Inc., $340,000) and
   SO-710272 (TechPro Solutions, $275,000) are now first-class records in
   lib/data/orders.ts. The Transactions order count derives to 8 from that
   one list — it is never hardcoded.
9. **Billing shipments** — SHP-010/011/012 (`billingShipments` in
   lib/data/shipments.ts) are delivered shipments with signed proof of
   delivery for SO-710270/71/72. `allShipments` (= shipments +
   billingShipments) is the single source for "delivered", so the eligible
   billing report derives "delivered but not invoiced" by joining shipments
   to orders and reading invoice status from the store.
10. **Anomaly purchase order** — PO-GMI-8843 (`anomalyPo` in
    lib/data/pipeline-orders.ts) carries a unit price 8% above contract
    ($194.40 vs $180.00) on SO-710249 — deliberately the SAME 8% gap as the
    existing Pricing Mismatch exception EXC-003, so the PO Understanding
    "Attention" row and the exception tell one story with one number.
11. **Brand scrub** — the compiled demo's product name "Industrial Tape 3M™"
    is anonymized to "Industrial Tape" (lib/data/orders.ts). Grep-verified:
    no real-brand strings remain in lib/, components/, or app/.
