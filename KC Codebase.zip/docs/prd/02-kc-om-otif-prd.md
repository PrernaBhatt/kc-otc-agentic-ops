# K-C Agentic OTC · OM Command Center + Appointment / Track & Trace / OTIF at risk — 修改计划

> 输入：K-C 这轮 4 条 enhancement（Appointment scheduling、Track and Trace、OM Command Center 指标、OTIF at risk 预测场景）。
> 已核对的现状：`order-management-view.tsx`（`SIM_STAGES` 9 段，末段 `handoff` 只读 TMS）、`order-evidence.tsx`（`TmsCarrierCard` / `RetailerAppointmentCard` / `dockDays` 还在，只是 run 里不用了）、`logistics-handoff-panel.tsx`、`dashboard-view.tsx` + `kpi-grid.tsx`（8 tile，OTIF 已被 #3 换掉）、`lib/data/{kpis,invoice-to-cash,shipments,sox-controls,account-owners}.ts`、共享 run 壳（`use-staged-run`、`RunStageCard`、`StageProgressRail`、`RunAgentLog`、`GateSignoffModal`、`FillFields`、`TickList`、`PostingChecks`、`EmailDraftDialog`、`FloatingTip`）、`scripts/tieout.mts`。
> Build 时第一步把本计划存成 `docs/prd/02-kc-om-otif-prd.md`。

---

## 0 · 一页结论

| # | 需求 | 现状 | 改成什么 | 落在哪 |
|---|---|---|---|---|
| 1 | Appointment scheduling | 末段 "Logistics handoff" 只读 3 个 TMS 事实，标 "Outside GBS scope" | Happy path：末段换成 **Appointment**：读 TMS 计划（route / load / carrier / 预计到货）→ 查零售商日历 → 校验 **OTIF window** → 订位、锁日历。异常（没有窗口内的空位 → 发给客户采购 → DC 回复给位 → 锁日历 → 和 TMS 预计到货不一致 → **推 TMS 重排 load**）单独做成 **Run A** | Order run（Costco / Target）+ 新 Shipments 页 Run A |
| 2 | Track and Trace | 没有 | **Run C**：读 FourKites feed（有 predictive ETA 就用，只有当前状态就 agent 自己预测 ETA）→ milk run 首站延误的连锁影响 → 3 种路线比较，**建议 OTIF miss 最少的路线** → 人签 → 下发新顺序 + **通知受影响客户**防拒收 | 新 Shipments 页 Run C |
| 3 | OM Command Center 指标 | Dashboard 是 8 个财务 tile | Dashboard（落地页）标题改 **OM Command Center**，最上面一排 4 张卡：**OTIF（A > S > D）**、**Perfect order（5 个子项）**、**Order validation accuracy**、**Order-to-invoice cycle time**；旧 8 tile 往下挪保留 | `dashboard-view.tsx` |
| 4 | OTIF at risk（预测） | 没有 | Dashboard 第二排 **OTIF at risk** 看板：Pre-shipment / Post-shipment 两条道。Pre-shipment 里 TMS 计划赶不上 → **Run B：premium freight plan → 审批 gate**；Post-shipment → Run C | Dashboard 看板 + Shipments 页 |

新 nav：Order Management 下加子项 **Shipments**（和 Review Order Hold 并列）。新 run 3 个，happy path 改 1 段，stage 数不变（9）。

---

## 1 · 和旧规则的冲突（按新需求覆盖）

- 旧 #3（PRD 01 §10）："Fulfilment/shipping 在 GBS 范围外、只读 TMS；Dashboard 去掉 OTIF"。这次客户明确要 appointment、track & trace、OTIF A/S/D，**以新需求为准**。
- 保留旧 #3 的精神：**TMS 负责 route / load / carrier 选择**，agent 不比价，只读 TMS 计划拿到预计到货日；agent 做的是**订位、OTIF 校验、推重排、追踪、通知**。
- Costco touchless 仍是 9 段（用 Appointment 替换 Handoff，不加段）；Track & trace 只在 Run C 演，happy path 不加长。
- Invoice-to-cash / Right-first-time 两个 KPI 保留（在下方旧 tile 行里）。
- Build 收尾时更新 memory `kc-otc-demo.md` 这条规则。

---

## 2 · 信息架构 Before → After

```
Dashboard  → 标题 "OM Command Center"（nav 仍叫 Dashboard）
  Row 1  OM KPI 卡 ×4（新）
  Row 2  OTIF at risk 看板（新）
  Row 3  旧 8 tile（不动）  → 下面 charts / agent 卡 / close checklist / analytics chat 不动
Order Management
  ├ Review Order Hold
  └ Shipments                ← 新（ViewId "shipments"）
```

- `ViewId` 加 `"shipments"`；`sidebar.tsx` Order Management children 加 `{ id: "shipments", label: "Shipments", icon: Truck }`；`app/page.tsx` view switch 加 case。
- 看板行点击 → `requestNav({ view: "shipments", caseId })`（沿用 `pendingCaseId`），Shipments 页直接打开该 run。

---

## 3 · Dashboard → OM Command Center

### 3.1 Row 1 · 4 张 KPI 卡（`components/views/dashboard/om-kpi-cards.tsx`，新）

`grid md:grid-cols-2 xl:grid-cols-4 items-stretch`，每卡 `flex h-full flex-col`，脚注 `mt-auto`。每卡 = eyebrow + count-up 主数字 + 目标 chip（On target / Below target）+ mini-visual + 来源脚注 + 点开 `KpiDetailModal`（复用）。**mini-visual 每一段都有 hover + `FloatingTip`**。进场 `animate-enter` 依次错开；条形从 0 长到值（reduced-motion 直接出）。

| 卡 | 主数字 | mini-visual | hover tip 内容 | 脚注 |
|---|---|---|---|---|
| OTIF | D 89.6%（target 92） | 三根递减柱 **A 96.8 → S 93.4 → D 89.6**，柱间标 "−3.4 pts at ship"、"−3.8 pts in transit" | 每根：订单数 / 4,210 + 一句定义；每个落差：前 3 个原因 | SAP ECC · TMS · FourKites |
| Perfect order | 85.6%（target 90） | 5 行细条：In full 98.0 · On time 91.2 · Dispute free 97.6 · Docs correct 99.0 · Paid in full 96.0 | 每行：通过 / 失败订单数 | SAP ECC · FSCM |
| Order validation accuracy | 99.1%（target 99.0） | 分段条 Correct 4,341 · False hold 27 · Missed 12 + 6 月 sparkline | 每段：数量 + 含义 | Validation agents |
| Order-to-invoice | 6.4 days（target 6.0） | 5 段相位条：Entry & validation 0.2 · Allocation & confirmation 0.6 · Planning & appointment 2.1 · Transit & POD 3.0 · POD to invoice 0.5 | 每段：天数 + 占比 | SAP ECC · TMS |

`data-kpi="otif|perfect-order|validation-accuracy|order-to-invoice"`。

### 3.2 Row 2 · OTIF at risk 看板（`components/mounts/shipments/otif-risk-board.tsx`，新，Dashboard 和 Shipments 页共用）

- 头部：eyebrow "Predictive" + "7 shipments at risk · 3 need action" + 风险分段条（High / Medium / Low，可 hover）。
- 两列等高：**Pre-shipment（4）**、**Post-shipment（3）**。每行 = shipment ID（mono）+ 客户 / ship-to + 风险 chip + 一句信号 + **ETA-vs-window 小轨道**（灰底 = OTIF window，点 = 预测 ETA，窗外标红）+ 系统 badge（TMS / FourKites / 零售商 portal）+ 右侧动作：`Open` 按钮（3 个可跑）或 "Watching"（agent 头像 + 下次检查时间）。
- run 跑完后该行变绿："Resolved · …"（store `resolvedShipments`）。
- 进场：列 `enter-up`，行依次 `enter-fade`；ETA 点从窗口起点滑到预测位置。`data-risk-lane`、`data-risk-row`。

### 3.3 其他

- `analytics-chat.tsx`：OTIF 那条回复改成 A/S/D 三个数（删掉 "agents read them from TMS at handoff"）。

---

## 4 · Order run happy path：Handoff → Appointment（Costco SO-710260、Target SO-710249）

### 4.1 `SIM_STAGES`

```
Before: … atp → confirmed → handoff
After:  … atp → confirmed → appointment   （仍 9 段；macro fulfillment）
```

- `appointment`：label "Appointment"，agent "Appointment Scheduling Agent"，agentType `delivery`。
- 同步改：`STEP_SHORT_LABEL`、`STEP_SUMMARY`（"TMS plan read · slot booked inside the OTIF window"）、`STAGE_SUMMARY.fulfillment`、`FULFILLMENT_STEP_IDS`、`GENERIC_FULFILLMENT_LOG`、`fulfillmentStepLog`；`issueInvoice` 保持在末段结束时调（I2C clock 不变）。

### 4.2 Stage body（新 `mounts/order-management/appointment-stage-panel.tsx`，替换 `logistics-handoff-panel.tsx`）

AI reasoning 3 行（`appointmentReasoning` 重写）：
1. "TMS planned the load: Blue Line Freight, pickup 2026-08-28 16:00, expected delivery 2026-08-29."
2. "Checking the Costco receiving calendar for an open slot inside the OTIF window…"
3. "Sat 06:00–08:00 is open and inside the window. Booking it and blocking the calendar."

两张卡（输入 = tick，输出 = 左到右自动填）：
- **TMS shipment plan**（输入）：`TickList` 4 行 Route · Load · Carrier · Expected delivery，system "TMS"。
- **Retailer appointment**（升级 `RetailerAppointmentCard`）：日历上叠 **OTIF window 色带**，窗外 slot 变淡；phase 2 灰掉已被占用的，phase 3 选中 slot + `Pass` chip "Inside OTIF window"；下面 `FillFields` 打出 Appointment ID / Dock / Window / PO / Carrier / Calendar "Blocked"，最后落 stamp "Booked"。证据入口打开 `buildAppointmentConfirmationDoc`。

### 4.3 连带修改（`order-evidence.tsx`）

- `OrderEvidence` 加 `tmsPlan { loadId, route, load, pickup, eta }`、`otifWindow { from, to, rule }`（数据放 `lib/data/order-logistics.ts`，组件只读）。
- `handoffFacts` → `tmsPlanFacts`；`evidenceLogs.handoff` → `appointment`（"Read TMS plan … Booked APPT-C114-58213 Sat 06:00–08:00, inside the OTIF window."）；`steps` 末行 "Logistics handoff" → "Appointment booked"；`evidenceArtifacts` 同步。
- **客户确认（EDI 855 / 邮件）发生在订位之前**：去掉其中 appointment / carrier 两行和对应 match 行，换成 "Requested delivery 2026-08-29"。
- `FulfillmentEvidence`（列表卡展开）改成 Allocation + TMS plan + Appointment，与 run 一致；`TmsCarrierCard`、`carrierReasoning` 不再使用则删除。
- `run-complete-modal.tsx`（OM 版）：文案 "PO to booked delivery slot"；I2C clock 写 "Invoice at POD on the booked appointment"。删除 `logistics-handoff-panel.tsx`。

---

## 5 · 新页 Shipments + 3 个 run

### 5.1 页面（`components/views/shipments-view.tsx`，新）

- 页头 "Shipments" + 过滤 chip（All · Pre-shipment · Post-shipment · Needs action）+ 搜索；下面就是 `OtifRiskBoard`（page 变体）。
- 点 `Open` → 该 case 的 run 替换看板（同 Deductions 的 `openCaseId` 模式），`Back to Shipments`。
- 3 个 run 都用共享壳：`useStagedRun` + `StageProgressRail` + `RunStageCard` + 右侧 `RunAgentLog` + `RunCompleteModal`，Enter 推进，不显示 Continue 提示；每步写 `appendAudit`（module "Order Management"）。

### 5.2 Run A · 没有窗口内的空位（Walmart SHP-58201 · SO-710264 · $126,400）— 5 段，无签字 gate

| 段 | Agent | 读（tick） | 写（自动填）/ 动作 | 动画 |
|---|---|---|---|---|
| S1 TMS plan | Appointment Scheduling Agent | TMS：DC-ONT → RDC 6094 Buckeye AZ · 352 mi；24 pallets；Blue Line Freight；pickup Mon 08-24 05:00；ETA Wed 08-26 12:30 | — | 逐行 tick |
| S2 Calendar | 同上 | Walmart delivery scheduling portal：Mon–Wed（OTIF window 08-24 → MABD 08-26）全满；Thu 08-27 有空但在窗外 | 结果 chip **Flag** "No slot inside the OTIF window" | slot 逐格翻成 full；Thu 的空位标 "After MABD" |
| S3 Ask buyer（hold） | Communication Agent | — | `EmailDraftDialog` 自动打开，agent 逐行写给 **Kelly Brooks, Sr. Buyer — Walmart**，请她安排 RDC 6094 的收货位；人点 Send 才过 | 草稿逐行打出 |
| S4 Slot confirmed | Appointment Scheduling Agent | 回复卡片到达（thinking dots → reply）："RDC 6094 receiving confirmed Tue 08-25 22:00–23:00, door 31" | `Pass` "Inside OTIF window"；`FillFields` 锁日历：WMT-6094-338172 · door 31 · Tue 22:00–23:00 · Blocked | 回复淡入，字段左到右填 |
| S5 TMS replan | Freight Planning Agent | slot（Tue 22:00）≠ TMS ETA（Mon 12:30） | **Staged change table**（新共享组件）：Pickup Mon 05:00 → Tue 14:00；ETA Mon 12:30 → Tue 21:30；Appointment — → WMT-6094-338172；Rate unchanged；每行 spinner → check，footer "Replan RP-58201 accepted by TMS" | 红删旧值、绿出新值 |

完成卡：`Slot booked inside window · TMS replanned · 0 cost change`。看板该行变 "Resolved · Tue 22:00 slot"。

### 5.3 Run B · Pre-shipment premium freight（Kroger SHP-58207 · SO-710265 · $98,800）— S1 S2 S3 G1 S4

| 段 | Agent | 内容 | 动画 |
|---|---|---|---|
| S1 Signal | Freight Planning Agent | 读：TMS 计划 DC-DAL → Kroger DC 024 Forest Park GA · 781 mi；原承运商拒单；TMS 重排后 pickup Tue 08-25 10:00 solo，ETA **Thu 08-27 06:00**；预约 APPT-KRG-024-1187 Wed 08-26 08:00–09:00 → `Flag` "Misses the window by 1 day" | tick + ETA 轨道点滑出窗口 |
| S2 Options | 同上 | 3 个选项只读对比（选择在 gate 里点）：A Keep TMS plan $2,240 · Miss · fine risk $2,964（3% of $98,800）；**B Team-driver expedite（Summit Logistics）$3,980 · ETA Wed 06:00 · Pass**；C Source from DC-ATL · short 6 pallets · in-full Flag | 行逐条判 Pass / Flag，推荐行最后亮 |
| S3 Freight plan | 同上 | 写 **Premium freight plan PFP-58207**：carrier SMLG team、pickup Tue 16:00、ETA Wed 06:00、rate $3,980、base $2,240、premium **$1,740**、fine avoided $2,964、net $1,224、reason "Carrier tender rejected" | 空白模板左到右填，stamp 最后落 |
| G1 Approval | Priya Raman · Transportation Manager, NA | `GateSignoffModal`：controls **1.2.1**；证据 = TMS plan、tender rejection、options、PFP-58207；选项 A/B/C 在这里点（默认 B）；限额行 "$1,740 within $2,500 limit"；签名后 Confirm 才亮 | modal-in，证据逐行 tick |
| S4 Tender | Freight Planning Agent | Staged change table：Carrier PCCR → SMLG；Pickup Tue 10:00 → Tue 16:00；ETA Thu 06:00 → Wed 06:00；Rate $2,240 → $3,980；Accrual — → $1,740 CC-NA-LOG-410；Appointment unchanged `Pass` | 同 5.2 |

### 5.4 Run C · Post-shipment track & trace，milk run（MR-58212 · 3 stops · $171,400）— S1 S2 S3 G1 S4

数据（2026-08-20）：计划 06:20 出 DC-ONT；窗口 Target T-0553 07:00–08:00 · Kroger Riverside 08:30–09:30 · Costco C-114 10:00–11:00；卸货 45 min；车程 DC→T 25、T→K 30、K→C 50、DC→K 35、C→T 45、K→T 30、T→C 45。实际：L1 装车延误，**08:05 才出发**。

| 段 | Agent | 内容 | 动画 |
|---|---|---|---|
| S1 Track | Track and Trace Agent | FourKites feed：Departed origin 08:05；Stop 1 **predictive ETA 08:30（FourKites）**；Stop 2 / 3 **status only** → agent 预测（车程 + 平均卸货）09:45 / 11:20，每行标来源 chip "FourKites PETA" / "Agent ETA" | 里程碑逐行 tick，ETA 值左到右填 |
| S2 Cascade | 同上 | 当前顺序 T→K→C：3 站全部窗外（+30 / +15 / +20 min）→ `Flag` ×3 "3 OTIF misses" | 三站时间轴，窗外段变红 |
| S3 Routes | 同上 | 3 条路线只读对比：① T→K→C 3 misses；② **K→C→T 1 miss（Target 11:45）**；③ K→T→C 2 misses。推荐 ②，并给 Target 申请 12:00–13:00 re-slot | 每条路线 lane 动画出站点 + Pass/Flag |
| G1 Route approval | Priya Raman | `GateSignoffModal` controls **1.2.2**；选项 ①②③ 在这里点（默认 ②） | 同上 |
| S4 Dispatch & notify（hold） | Track and Trace Agent + Communication Agent | Staged change table：stop 顺序、三站新 ETA、Target appointment re-slot 请求；然后 `EmailDraftDialog` 自动打开给 Target 收货 + Jim Novak cc："Load for T-0553 arrives 11:45, outside 07:00–08:00. Requesting 12:00–13:00 to avoid rejection." 人点 Send 结束 | 表格逐行 → 邮件逐行写 |

完成卡：`3 misses → 1 · customer notified before arrival`。

### 5.5 每步的文档（`lib/docs-logistics.tsx`，新，`SourceDoc` builder）

TMS shipment plan · Retailer calendar snapshot · Buyer slot request · DC slot confirmation · TMS replan RP-58201 · Freight options · Premium freight plan PFP-58207（签后带签名）· FourKites tracking report · Route options · OTIF-miss notice · Appointment confirmation（happy path）。每个 run step 的证据入口打开对应文档，ID / 数字与屏幕一致。

---

## 6 · 数据与 tie-out（全部在 `lib/data/**`，selector 里 assert，`tieout.mts` 引入）

新文件：`lib/data/om-kpis.ts`、`lib/data/order-logistics.ts`、`lib/data/shipment-risk.ts`（看板 7 行 + 3 个 case）、`lib/shipment-selectors.ts`。

```
基数        N = 4,210 订单（= I2C_KPIS.invoicesIssued）
OTIF A      4,075 = 96.8%    未就绪 135 = 缺货 92 + 质量 hold 43
OTIF S      3,932 = 93.4%    A→S 143 = 拒单 61 + load 规划 48 + 拣货晚 34
OTIF D      3,772 = 89.6%    S→D 160 = 在途延误 88 + 错过预约 47 + 收货拒收 25
            assert A ≥ S ≥ D
Perfect     in full 4,126 (98.0) · on time 3,840 (91.2) · dispute free 4,109 (97.6 = 4,210 − 101 disputed)
            · docs 4,168 (99.0) · paid in full 4,042 (96.0)
            on-time ∪ in-full 失败 438 = 370 + 84 − 16 → 对上 OTIF D 3,772
            perfect 3,602 = 85.6% ；assert 3,602 ≤ min(各子项) 且 ≥ N − Σ失败
Validation  4,380 validated；correct 4,341 = 99.1%；27 false hold + 12 missed = 39
Order→inv   6.4 d = 0.2 + 0.6 + 2.1 + 3.0 + 0.5；trend 末值 = 6.4
Risk board  7 行 = pre 4 + post 3；need action 3；High 价值 396,600 = 126,400 + 98,800 + 171,400
Run A       slot Tue 22:00 在 window(08-24→08-26) 内；新 ETA 21:30 < slot；旧 ETA 日期 ≠ slot 日期 → replan
Run B       premium 1,740 = 3,980 − 2,240；fine 2,964 = 3% × 98,800；net 1,224 = 2,964 − 1,740；1,740 ≤ 2,500
Run C       每站 arr = 上站 dep + 车程；dep = max(arr, 窗口开) + 45；
            ① 08:30 / 09:45 / 11:20 → 3 miss；② K 08:40 · C 10:15 · T 11:45 → 1 miss；③ 08:40 / 09:55 / 11:25 → 2 miss
            推荐 = miss 最少；loads 58,200 + 49,600 + 63,600 = 171,400
Happy path  Costco APPT-C114-58213 Sat 08-29 06:00 在 window 内；Target APPT-T0553-77410 Fri 08-28 09:00 在 window 内
```

`tieout.mts` 改：§14.5 仍 9 段，但必须含 `appointment`、不含 `handoff` / `carrier`；新增上面全部等式；banned copy 加 "Outside GBS scope"、"Logistics handoff"。

---

## 7 · 共享改动

| 改动 | 文件 |
|---|---|
| 新 control family **1.2 Order fulfilment**：1.2.1 Premium freight approved within delegated limit；1.2.2 Delivery plan changes approved and the customer notified | `lib/data/sox-controls.ts`（`ControlFamily` 扩展）、`mounts/audit/audit-table.tsx` 过滤项、`audit-kpis.tsx` 脚注 |
| 新 persona `TRANSPORT_LEAD` Priya Raman · Transportation Manager, NA · premium freight 限额 $2,500 | `lib/data/account-owners.ts` |
| Store：`resolvedShipments: Record<caseId, string>` + `resolveShipment()` | `lib/store.tsx` |
| 新共享 **StagedChangeTable**（code · label · 红删旧值 · 绿新值 · tag · spinner→check · footer），样式取自 `settlement-split.tsx`，原组件不动 | `components/shared/staged-change-table.tsx` |
| FourKites 换真 logo（官网 favicon 下载到 `public/brand/systems/fourkites.png`），`system-badge.tsx` 去掉 "4K" 字母块 | system-badge |
| 3 个新 agent（Appointment Scheduling、Freight Planning、Track and Trace）进 Agent Activity | `lib/data/agent-workforce.ts` |

---

## 8 · 文件清单

新（≈ 14）：`views/shipments-view.tsx`、`views/appointment-slot-run.tsx`、`views/premium-freight-run.tsx`、`views/milk-run-reroute-run.tsx`、`views/dashboard/om-kpi-cards.tsx`、`mounts/shipments/{otif-risk-board,eta-window-track,fourkites-feed,route-options,freight-options,reply-card}.tsx`、`mounts/order-management/appointment-stage-panel.tsx`、`shared/staged-change-table.tsx`、`lib/docs-logistics.tsx`、`lib/data/{om-kpis,order-logistics,shipment-risk}.ts`、`lib/shipment-selectors.ts`、`public/brand/systems/fourkites.png`、`docs/prd/02-kc-om-otif-prd.md`。

改（≈ 14）：`order-management-view.tsx`、`order-evidence.tsx`、OM `run-complete-modal.tsx`、`dashboard-view.tsx`、`analytics-chat.tsx`、`sidebar.tsx`、`app/page.tsx`、`lib/store.tsx`、`sox-controls.ts`、`account-owners.ts`、`agent-workforce.ts`、`system-badge.tsx`、`audit-table.tsx` / `audit-kpis.tsx`、`scripts/tieout.mts`、narrative（`agentic-otc-narrative-short.md`、`-v2.md`）、`docs/USECASE-COVERAGE.md`。

删：`mounts/order-management/logistics-handoff-panel.tsx`（先去掉引用再删）。

---

## 9 · Build 顺序

1. **P0 底座**：PRD 存档 → 数据文件 + selectors + tie-out 等式 → control 1.2.x、`TRANSPORT_LEAD`、store slice、StagedChangeTable、FourKites logo、`docs-logistics.tsx`。
2. **P1 Happy path**：`appointment` 段 + 面板 + evidence / 确认邮件 / 完成卡连带修改，删 handoff 面板。
3. **P2 Dashboard**：OM KPI 卡 ×4 + OTIF at risk 看板。
4. **P3 Shipments 页 + nav + Run A**。
5. **P4 Run B**（gate 1.2.1）。
6. **P5 Run C**（gate 1.2.2）。
7. **P6 收尾**：analytics chat、narrative、USECASE-COVERAGE、memory 更新；`tsc --noEmit` + `pnpm build`（含 tie-out）通过。

## 10 · 验收

- `tsc` 0 错；`pnpm build` 通过；`tieout.mts` 全过（含 §6 新等式和新 banned copy）。
- 结构：order run 9 段含 `appointment`；Run A 5 段无 gate；Run B / C 各 5 段含 1 个 gate，gate 都带 `controls`。
- 规则自查：同行卡等高；每块文案 ≤ 2 句；读 = tick、写 = 左到右填、产出不打勾；KPI 每段有 hover tip；金额 / 日期只在 `lib/data`；不加 Continue 提示。

## 11 · 默认假设（不阻塞，review 时可改）

| # | 问题 | 默认 |
|---|---|---|
| Q1 | OTIF / Perfect order 等数值 | §6 的数字（D 89.6%、perfect 85.6%、validation 99.1%、6.4 天） |
| Q2 | 物流审批的签字人 | 新 persona Priya Raman（Transportation Manager），premium freight 限额 $2,500 |
| Q3 | 物流 gate 挂哪个 control | 新 family 1.2（1.2.1 / 1.2.2），拿到 K-C 清单后只改 `sox-controls.ts` |
| Q4 | 三个异常场景的客户 | Run A Walmart（MABD 规则最严）、Run B Kroger、Run C Target / Kroger / Costco 同车 milk run |
| Q5 | Happy path 要不要也演 track & trace | 不加段，只在 Run C 演 |
| Q6 | 旧财务 8 tile | 保留在 OM 卡下面 |

---

## v2 · One order thread (built Nov 2026)

The client describes one order lifecycle; v2 connects the four islands into it (plan: visionary-solution).

| Area | Before | After |
|---|---|---|
| Order run | 9 stages, ends at Appointment | Target 11 / Costco 9: … Confirmation → Shipment plan → Appointment → Track & deliver (POD, invoice) |
| OTIF rule | Slot "inside window" only | Per-customer `otifPolicy` (Walmart MABD day, others requested day); off-rule slots flagged Early / Late · OTIF miss |
| Walmart SO-710264 | Only on the risk board | In the OM pipeline as "Appointment hold"; Resolve opens Run A with the order-thread chips |
| Shipments page | Same 7-row board as the Dashboard | **Track & Trace**: 24 loads, filters, search, pager, detail rail with milestones and Agent ETA |
| ETA | Fixed drive + unload | Prediction: p50 = last ping + drive at lane p50 + traffic + dwell; 80% band; OTIF risk = P(arrive after window) |
| Command Center | Board without a forecast | 7-day OTIF D forecast on the board (88.0% → 88.4%, target 92%), "Detected at" chips, "vs Jul" deltas, `OmKpiDetail` per KPI |

Forecast note: the board holds 9 orders (5 high-risk, 4 on watch). Resolving all three runs saves 4 of 980 orders, so the forecast moves 0.4 pts; the 113 baseline misses come from lane history and stay. The plan's 87.9 → 89.4 would need 15 recovered orders, which the board does not contain.

Tie-out (`scripts/tieout.mts`): stage counts and thread order, predicted stop risk 99 / 97 / 96, 24 loads = 9 + 8 + 7, every risk row is a load, forecast 88.0 → 88.4 with 4 recovered, KPI deltas, trends end in Aug.
