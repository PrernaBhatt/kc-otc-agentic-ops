# Agentic Order to Cash · K-C 反馈改版 PRD

> 阶段：**只写 PRD，不写代码**。覆盖 K-C / Kenvue Q&A 后的 6 条反馈（#1–#6），按约定的顺序落地：**P0 底座 → #1 → #6 → #4 → #5 → #2 → #3 → 收尾**。
> 已读过的现有实现：`app/page.tsx`、`components/layout/sidebar.tsx`、`components/views/{billing-hold-run,deductions-view,order-management-view,fund-claim-run}.tsx`、`components/mounts/{billing-hold,order-management,deductions,exceptions,shared}/*`、`lib/data/{billing-holds,pipeline-orders,customers,promo-claims,dup-claims,rebate-claims,fund-claims,short-pay,multi-cause-deduction,channel-deductions,deductions,journal-entries,provisions}.ts`、`lib/store.tsx`、`lib/docs*.tsx`、`data/agentic-otc-narrative.md`。
> 复用调研过的 repo：`siemens-control-tower`（最新，Cases list → rail、Control Tower、approval chain、KPI tip、typed text）、`agentic-control-tower`（Audit 页 + export）、`agentic-chargeback-demo`（本 repo 的前身，deduction / dispute 组件已在本 repo）、`agentic-customer-order-z1`、`mb-hr-concierge`。

---

## 0 · 一页结论

| # | 反馈 | 现状（代码里核对过） | 改成什么 | 新页面 | 新 run | 新组件 | 改动组件 |
|---|---|---|---|---|---|---|---|
| 1 | Billing 不重开发票 | `billing-hold-run` 7 步：Hold → Root cause → Freight & tax → Routing → **Correction（把发票从 $1,105,000 改到 $1,293,000）** → Release → Notify；narrative 写 "recovers $188,000" | 原发票 INV-710269 不动。Costco 少付 $188,000 → **FSCM dispute case** 挂在原发票上 → 4 个原因逐条判：K-C 对 = **charge-back**，Costco 对 = **credit note** → 原因**回传 Pricing / Master data** | 0 | 1（替换） | 7 | 3 |
| 6 | 审批挂 SOX 编号 + audit 导出 | 全仓库没有 "SOX"；审批只看 materiality（Billing $5,000、Fund $25,000）；"AI Agent Audit Trail" 只展示不导出；只有 Billing 有签名 | 每个审批 gate 挂 **SOX control ref**（Billing 1.4.x、Trade 1.7.x），全部要签名；新 **Audit trail** 页，可筛选、可导出 **CSV + A4 PDF** | 1 | 0 | 6 | 6 |
| 4 | Deductions 分 trade / non-trade | 实际有 7 类 case（promo、dup、rebate、fund、short-pay、multi-cause、channel），但没有 trade / non-trade 维度；narrative 只演 Walmart fund | Deductions 页分两条道：**Trade（按金额，逐案）** / **Non-trade（按量，批处理）**；新增 non-trade 批处理 run | 0（页内两 tab） | 1 | 7 | 4 |
| 5 | 一个客户一个 owner | 没有 owner 概念；`routedTo` 只有 "Trade Finance / Sales / Customer Service"；没有 escalation 追踪 | 新 **Accounts** 页：每个客户一个 owner，agents 在 owner 身后干活；**升级到 Commercial / Supply chain 有追踪（SLA、账龄、状态链）**；所有 gate 的签字人 = 该客户 owner | 1 | 0 | 7 | 8 |
| 2 | Target 按 K-C 合同价开票 | `pricing-hold-card` 推荐 "proceed at PO pricing"，理由 "10 of 12 similar holds" | 价差 $740 超阈值 → 推荐**按合同价 CTR-TGG-2026 开票（$220,000）**，**通知买方**，**记录差异**；删掉 10/12 先例 | 0 | 0 | 1 | 4 |
| 3 | Costco touchless 缩短 | `SIM_STAGES` 里 carrier、appointment 两步 + POD macro 各有卡片和推理 | Carrier + Appointment + POD 合成 **1 步 "Logistics handoff"**（只读 TMS 事实，不推理）；收尾改讲 **invoice-to-cash**；Dashboard 的 Order Cycle Time / OTIF 换成 Invoice-to-Cash / Right-first-time invoices | 0 | 0 | 2 | 4 |
| | **合计** | | | **2** | **2** | **30** | **≈ 25** |

新增 nav：**Accounts**、**Audit trail**。Deductions、Billing 不新增 nav，页内改。

---

## 1 · 改动顺序（为什么这样排）

| 阶段 | 内容 | 依赖 / 理由 |
|---|---|---|
| **P0 底座** | owner 名册、SOX control 名册、audit store、escalation store、`ControlTag`、`OwnerChip`、`GateSignoffModal`、`download` | #1、#2、#4 的 gate 一出生就要带 owner + SOX + 签名 + 写 audit；先做底座，避免每条反馈各改一遍再回头补 |
| **P1 · #1** | Billing → FSCM dispute | 影响最大：现在的 "$188,000 recovered" 和两家客户都说的规则正面冲突，是最容易在下次演示里被挑出来的错 |
| **P2 · #6** | Audit trail 页 + 给所有现存 gate 补 SOX tag 和签名 | P1 新 gate 已经带 tag，这里补齐老 gate（credit review、promo、dup、rebate、fund、short-pay、multi-cause、Target）并把 audit 页做出来 |
| **P3 · #4** | Deductions 两条道 + non-trade 批处理 run | 需要 P2 的 control 1.4.5 / 1.7.x；批处理产生的 escalation 要喂给 P4 |
| **P4 · #5** | Accounts 页 + 全模块 owner 化 + escalation 追踪 | 要等 P1、P3 产生真实的 escalation，Accounts 页才有活数据 |
| **P5 · #2** | Target 按合同价 | 改动最小（一张卡 + 一封邮件 + 一个 gate），放后面不阻塞 |
| **P6 · #3** | Costco 缩短 + I2C KPI | 纯删减 + 两个 KPI 替换，最后做 |
| **P7 收尾** | narrative、`USECASE-COVERAGE.md`、tie-out、build | — |

---

## 2 · Strict rules（本轮全部适用）

| # | 规则 | 怎么落地 / 怎么验 |
|---|---|---|
| R1 | **Look & feel 冻结** | 只用 `app/globals.css` 现有 token（`--primary #1e6da6`、`--accent #17608f`、gray 100/200、`--radius 12px`）、现有字体（Helvetica Neue / Inter + Geist Mono）、现有动效（`animate-enter`、`enter-up`、`enter-fade`、`modal-in`、`slide-in-right`、`step-halo`、`step-pop`、`step-check-draw`、`shimmer`、`caret-blink`）。从 siemens / control-tower 搬来的组件**全部换皮**：去掉 superellipse、petrol、Teams 色，改成本 repo 的 Card / Badge / Button |
| R2 | **同行等高** | `grid items-stretch` + 子项 `flex h-full flex-col` + `mt-auto`；不用固定高度 / `min-h-*`；表格数字右对齐 `tabular-nums` |
| R3 | **文案预算** | 每块最多两句；标题下不加解释性 caption；不写 slogan 三连 |
| R4 | **卡片要 enterprise-rich** | 每张卡 ≥ 3 项：eyebrow、带单位的数字、状态 chip、小图、系统 badge、证据入口、来源脚注 |
| R5 | **进场动画 + AI 像 AI** | 页面根、卡片网格、每张卡都进场；agent 读 = 逐行 tick；agent 写 = 空白模板**从左到右**逐字填（`TypedText` 预留未打的部分，右对齐金额不往左长）；产出**永远不打勾**；检查结果用 Pass / Flag chip；每个动画有 reduced-motion 版本 |
| R6 | **数字只在 data 文件** | 所有金额、日期、编号放 `lib/data/**`，组件从 selector 读；§12 列出所有 tie-out 等式，selector 里 assert |
| R7 | **推进方式不变** | 沿用现有 Enter / Continue 一次推进一步；gate 停住等人签 |
| R8 | **每个人的决定都签名** | 所有 gate 用 `GateSignoffModal`（手绘 / 输入两种），签之前 Confirm 灰掉；签名写进 audit |
| R9 | **系统图标用真 logo** | 新出现的系统（SAP FSCM、SAP MDG、TMS、Vertex / Avalara）放 `public/brand/systems`，不用字母方块 |
| R10 | **只 build，不开浏览器** | 验收 = `tsc --noEmit` + `pnpm build` + tie-out 脚本通过（§14） |

---

## 3 · 信息架构 Before → After

```
Before                                   After
Dashboard                                Dashboard            (2 个 KPI 换掉，#3)
Order Management                         Accounts             ← 新 (#5)
  └ Review Order Hold                    Order Management
Billing                                    └ Review Order Hold
Deductions                               Billing              (SO-710269 变成 Invoice dispute，#1)
Chargebacks                              Deductions           (Trade | Non-trade 两 tab，#4)
Collections                              Chargebacks
Cash Application                         Collections
Transactions                             Cash Application
Exceptions                               Transactions
Co-Pilot                                 Exceptions
Agent Activity                           Co-Pilot
                                         Agent Activity
                                         Audit trail          ← 新 (#6)
```

- `ViewId` 加 `"accounts" | "audit"`；`sidebar.tsx` NAV 里 Accounts 放在 Dashboard 后，Audit trail 放 Agent Activity 后（图标：`Users`、`ShieldCheck`）。
- Nav 文案 ≤ 3 词，无符号。
- `app/page.tsx` 的 view switch 加两个 case；`RUN_STAGE_LABELS` 加 `accounts`。

---

## 4 · P0 底座（所有反馈共用）

### 4.1 新数据

| 文件 | 内容 |
|---|---|
| `lib/data/account-owners.ts` | 每个客户一个 owner（§8.2 名册），含 `ownerId, name, role: "Customer account owner", region, backupOwnerId, delegatedLimits { creditNoteUsd: 50_000, chargeBackUsd: 100_000 }`；Controller `L. Chen`（沿用 `journal-entries.ts` / `provisions.ts` 里已有的人）做超限 co-sign |
| `lib/data/sox-controls.ts` | Control 名册（§6.2）：`ref, family: "1.4 Billing" \| "1.7 Trade promotion", name, owner, evidenceRequired[], threshold?` |
| `lib/data/escalations.ts` | 预置 escalation（§8.4）+ 类型：`id, accountId, team: "Commercial" \| "Supply chain", unit, subject, amountUsd, raisedOn, slaDays, status: "Raised" \| "Acknowledged" \| "Actioned" \| "Closed", chain[], nudges[], sourceCaseId` |
| `lib/data/audit-seed.ts` | 24 条历史 audit 记录（6 个客户 × 4），让 Audit 页在没跑 run 之前也有内容 |

### 4.2 Store 扩展（`lib/store.tsx`）

| 新 slice | 动作 | 谁调用 |
|---|---|---|
| `auditLog: AuditEntry[]` | `appendAudit(entry)` | 每个 agent step 完成、每个 gate 签字 |
| `escalations: Escalation[]` | `raiseEscalation`、`advanceEscalation`、`nudgeEscalation` | #1 S5、#2 gate 后、#4 批处理 S4、Accounts 页按钮 |
| `signatures: Record<gateId, Signature>` | `signGate(gateId, sig)` | `GateSignoffModal` |

`AuditEntry`：`entryId, at (ISO), caseId, accountId, module, actor { kind: "agent" \| "person", name, role }, action, controlRef?, amountUsd?, decision?, evidence: docId[], signature? { method: "drawn" \| "typed", signer, signedAt, hash }, system`。

### 4.3 新共享组件

| 组件 | 位置 | 内容 | 功能 | 动画 | 来源 |
|---|---|---|---|---|---|
| `ControlTag` | `components/shared/control-tag.tsx` | chip "SOX 1.4.3"，hover tip：control 名、owner、要的证据 | 点击跳 Audit trail 并按该 control 过滤 | 跟随父卡进场；tip 用 floating tip | 新；tip 借 siemens `dashboard/kpi-tip.tsx` 的 `FloatingTip`（换皮） |
| `OwnerChip` | `components/shared/owner-chip.tsx` | 头像首字母 + 名字 + "Costco owner" | 点击跳 Accounts 并选中该客户 | — | 新 |
| `GateSignoffModal` | `components/shared/gate-signoff-modal.tsx` | 头部：标题 + `ControlTag`(可多个) + `OwnerChip`；证据清单（逐行 tick 进来）；选项（只读回显 agent 的推荐，选择在这里点）；materiality 行 + 委托限额行；超限时出现 **Approval chain**（owner → Controller）；签名区 | 签名前 Confirm 灰；签完写 `signatures` + `auditLog`；非 owner 打开看到灰的 + "Decides: Marcus Hale" | `modal-in`；证据逐行 tick；chain 节点依次点亮 | **泛化现有** `billing-hold/correction-signoff-modal.tsx` + `signature-pad.tsx`；chain 借 siemens `run/approval-chain.tsx` |
| `ApprovalChain` | `components/shared/approval-chain.tsx` | 节点：已过 / 进行中 / 等待 | 用在 gate co-sign、escalation 状态链 | 节点依次 `step-pop` | siemens `run/approval-chain.tsx` 换皮 |
| `TypedText` / `CountUp` | `components/shared/typed-text.tsx`、`count-up.tsx` | — | 左到右逐字填；数字 count-up | reduced-motion 直接出 | 本 repo 有就复用，没有从 siemens `components/ai/*` 搬 |
| `download` | `lib/download.ts` | `downloadBlob(blob, filename)` | CSV / PDF 导出共用，用完 revoke | — | `agentic-control-tower/src/lib/download.ts` 原样 |

---

## 5 · P1 · #1 Billing：发票不重开，差额走 FSCM dispute

### 5.1 Before → After

| | Before | After |
|---|---|---|
| 起点 | 发货后、开票前，发票被 hold | 发票 **INV-710269 已经按 K-C 价开出**（$1,293,000，perfect invoice），Costco 按自己 PO 付款 $1,105,000 |
| 处理对象 | 一张被 hold 的发票 | 一个挂在**原发票**上的 **FSCM dispute case DC-710269**（$188,000） |
| 结果 | 签字把发票改成 $1,293,000、重新 release | 4 个原因逐条判：**K-C 对 → charge-back $150,000**；**Costco 对 → credit note $38,000**；原发票**不动**（9 月已关账） |
| 新增 | — | **Fix upstream** 步：price / promotion → Pricing；freight / tax → Master data（MDG change request）+ 升级到 Commercial / Supply chain |
| 叙事 | "K-C recovers $188,000" | "K-C charges back $150,000, credits $38,000 where Costco was right, and fixes the four causes upstream. No invoice is reissued." |

### 5.2 页面 / 入口

- Billing 页 SO-710269 那一行：标签从 "Invoice held" 改为 **"Invoice dispute"**，副信息 `$188,000 short-paid · DC-710269`，带 `OwnerChip`（Marcus Hale）。
- 点开进入新的 `BillingDisputeRun`（`components/views/billing-dispute-run.tsx`），**替换** `billing-hold-run.tsx`（旧文件删除；`resolvedBillingHolds` → `resolvedBillingDisputes`）。
- Accounts → Costco 的 rail 里 "Open work · Billing" 也能直达这个 run。

### 5.3 Run 脚本（6 步 + 1 gate，和现在一样 7 段 stage rail）

| # | id | Rail label | Agent | 读（逐行 tick） | 写（空白逐字填） | SOX |
|---|---|---|---|---|---|---|
| S1 | `capture` | Short-pay | Cash Application Agent | EDI 820 remittance **RMT-CWC-1016**（4 条 deduction 行 + Costco reason code）；INV-710269 open item | **FSCM dispute case DC-710269**（客户、原发票、disputed $188,000、4 个 reason code、coordinator = Marcus Hale、status "New"）；INV-710269 上的 residual item | — |
| S2 | `cause` | Root cause | Dispute Investigation Agent | SAP PR00 + PricerX PXN-22841；Vistex VISTEX-EVT-33920；TMS 运费结算 + Costco vendor agreement 运费条款；税引擎 + 转售免税证书 | **Cause board**：4 行（price / promotion / freight / tax），每行金额 + 判定 chip（"K-C right" / "Costco right"）+ 证据入口 | 1.7.1 作为证据 tag 挂在 promotion 行 |
| S3 | `settle` | Settlement | Dispute Resolution Agent | Cause board 判定；owner 委托限额 | **Credit memo request CMR-710269 $38,000**；**Charge-back notice CHB-710269 $150,000**；settlement split bar | — |
| G1 | `sign` | Sign-off | **Marcus Hale**（owner）→ **L. Chen**（Controller co-sign，因 charge-back > $100,000） | — | 签名 | **1.4.3**（credit note）、**1.4.4**（charge-back） |
| S4 | `post` | Post in FSCM | FSCM Posting Agent | 已签决定 | CM-710269 过账到 INV-710269；CHB-710269 作为 residual 留在 Costco 账上 → Collections；DC-710269 status → "Resolved · partially credited"；**原发票锁 chip**："INV-710269 · Sep period closed · not reissued" | — |
| S5 | `upstream` | Fix upstream | Root Cause Agent | Cause board | Pricing 任务 **PRC-TSK-3307**（price）、**PRC-TSK-3308**（promotion end date）；**MDG-CR-58120**（ship-to 运费条件）、**MDG-CR-58121**（税分类）；escalation **ESC-2621**（Commercial · Revenue Management）、**ESC-2622**（Supply chain · Transportation） | 1.4.1、1.4.2 挂在产出上（状态 "Submitted · awaits approval in MDG"） |
| S6 | `notify` | Notify Costco | Correspondence Agent | DC-710269、CM-710269、CHB-710269 | **Dispute response letter LTR-710269**，逐行起草；附件：credit memo、charge-back backup（PricerX note、Vistex 过期、POD） | — |

Stage rail summary 文案（每条一句）：
- S1 "Short-paid $188,000 on INV-710269 · dispute case opened"
- S2 "Four causes checked · K-C right on two, Costco on two"
- S3 "Charge-back and credit note drafted"
- G1 "Signed by Marcus Hale and L. Chen"
- S4 "Posted in FSCM · original invoice unchanged"
- S5 "Causes sent to Pricing and Master data"
- S6 "Costco notified with backup"

（以上数字全部来自 selector，文案模板里用 `{token}`。）

### 5.4 四个原因怎么判（§12.1 有 tie-out）

| 原因 | 金额 | 判定 | 证据 | 回传到 |
|---|---|---|---|---|
| Price | $95,000（$31.00 − $28.625）× 40,000 | **K-C right** → charge-back | PricerX PXN-22841 2026-08-29 批准 $31.00；EDI 832 价格目录 2026-08-30 已发、Costco 997 已回；PO-88213 用的是旧 item file | **Pricing** PRC-TSK-3307：确认 Costco 买方已更新 item file；升级 Commercial · Revenue Management |
| Promotion | $55,000（$1.375 × 40,000） | **K-C right** → charge-back | Vistex Q2 Volume Growth Rebate 2026-06-30 到期；交货 2026-09-18 | **Pricing / Trade** PRC-TSK-3308：促销结束日写进 Costco deal sheet；同一条 ESC-2621 |
| Freight | $28,000（$43,000 − $15,000） | **Costco right** → credit note | Costco vendor agreement 运费上限 $15,000 / load；SAP ship-to 运费条件却是 "actual pass-through" | **Master data** MDG-CR-58120：ship-to 改为封顶条件；升级 Supply chain · Transportation（该线路运费超上限 $28,000，K-C 自担） |
| Tax | $10,000 | **Costco right** → credit note | Costco CA DC 转售免税证书 CERT-CA-77120（有效至 2027-06-30）；SAP 客户税分类却是 "taxable" | **Master data** MDG-CR-58121：税分类改为 exempt（GBS 内部任务，不升级） |

### 5.5 组件（新 7 · 改 3）

| 组件 | 新/改 | 内容 | 功能 | 动画 |
|---|---|---|---|---|
| `billing-dispute-run.tsx` | 新（替换 hold run） | Run 外壳：头部（case ID、`OwnerChip`、"Agents working for Marcus" 一行 agent icon）、stage rail、当前 stage 面板、agent 执行日志 | 沿用 hold run 的推进、日志、`RunCompleteModal` | 沿用 |
| `mounts/billing-dispute/remittance-820-panel.tsx` | 新 | 左：820 段落（BPR / RMR / ADX 行）；右：FSCM dispute case 屏 | 每行 ADX 点开看 Costco reason code | 左逐行 tick；右 case 屏空白→逐字填，status chip 最后落 |
| `mounts/billing-dispute/cause-board.tsx` | 新 | 4 行：原因、金额（右对齐）、K-C 值 vs Costco 值、判定 chip、证据按钮、系统 logo | 证据按钮开对应 SourceDoc | 系统查询沿用 hold run 的 "query each system in turn"；判定 chip 在事实之后 reveal（事实立即出，判断才动画） |
| `mounts/billing-dispute/settlement-split.tsx` | 新 | 一根 $188,000 的横条分成 $150,000（charge-back）/ $38,000（credit note），下方两张文档卡（CMR、CHB），两卡等高 | 卡上 "Open ↗" 开文档 | 横条从左往右长；文档卡空白→逐字填 |
| `mounts/billing-dispute/original-invoice-lock.tsx` | 新 | 锁 icon + "INV-710269 · Sep period closed · not reissued" + 原值 $1,293,000 | hover tip 说明税务规则（一句） | `enter-fade` |
| `mounts/billing-dispute/upstream-fix-panel.tsx` | 新 | 两组：Pricing（2 个任务卡）、Master data（2 个 MDG CR 卡）；下面 2 条 escalation 行（团队、SLA、`ApprovalChain`） | 卡片 "Open ↗"；escalation 行点开跳 Accounts | 卡片逐张进场，内容逐字填；escalation 写入 store 时 chain 第一个节点 pop |
| `lib/docs-billing-dispute.tsx` | 新 | SourceDoc builders：820 remittance、FSCM dispute case、credit memo request、charge-back notice、MDG CR ×2、pricing task ×2、dispute response letter（A4） | 被各 stage 证据按钮调用 | — |
| `mounts/chargebacks/price-bridge.tsx` | 改 | 加 `verdict` 维度，让同一 bridge 能显示 "K-C right / Costco right" | — | — |
| `mounts/deductions/dispute-letter-composer.tsx` | 改 | 支持 credit + charge-back 两段内容和附件列表 | S6 复用 | 逐行起草（沿用） |
| `lib/data/billing-holds.ts` → `billing-disputes.ts` | 改 | 保留所有价格 / 促销 / 运费 / 税字段；新增 `invoiceId, invoiceDate, remittanceId, remittanceDate, disputeCaseId, verdicts, upstream[], periodClosedOn` | `billing-dispute-selectors.ts` 计算 split 并 assert | — |

删除：`billing-hold/sap-correction-proposal.tsx`、`release-checks.tsx`（不再有"改发票""release"）。`correction-signoff-modal.tsx` 的能力并入 `GateSignoffModal`。

### 5.6 `data-*` 验收钩子

`data-dispute-case="DC-710269"`、`data-invoice-reissued="false"`、`data-cause="price|promotion|freight|tax"` + `data-verdict="kc|customer"`、`data-settlement-credit="38000"`、`data-settlement-chargeback="150000"`、`data-upstream="PRC-TSK-3307|…"`、`data-control-ref`。

---

## 6 · P2 · #6 SOX control ref + 可导出的 audit trail

### 6.1 Before → After

| | Before | After |
|---|---|---|
| 审批依据 | 只有 materiality（$5,000 / $25,000） | materiality **+ SOX control ref + 委托限额**，超限有 co-sign chain |
| 签名 | 只有 Billing | **所有 gate** |
| 留痕 | 每个 run 页面里一段 "AI Agent Audit Trail"，只能看 | 全局 **Audit trail** 页；每条带 control、签名、证据；**CSV + A4 PDF 导出**；每个 run 完成卡也有 "Export audit" |

### 6.2 Control 名册（提议，见 Q1）

| Ref | Family | Control | 挂在哪个 gate / 产出 |
|---|---|---|---|
| 1.4.1 | Billing | Price exceptions approved before the invoice is created | #2 Target gate；#1 S5 pricing 任务 |
| 1.4.2 | Billing | Customer master changes (price, freight, tax) authorised | #1 S5 MDG CR |
| 1.4.3 | Billing | Credit notes approved within delegated limit | #1 G1；#4 non-trade 批处理（valid 部分） |
| 1.4.4 | Billing | Invalid deductions charged back with evidence | #1 G1；#4 批处理（invalid 部分）；non-trade 例外 |
| 1.4.5 | Billing | Non-trade deductions resolved within approved tolerance | #4 non-trade 批处理 G1 |
| 1.7.1 | Trade promotion | Promotion terms and dates authorised in TPM | #1 S2 证据；trade promo case |
| 1.7.2 | Trade promotion | Fund allocation and accrual reclass approved | Walmart fund claim DED-FUND-001 |
| 1.7.3 | Trade promotion | Claim settled only with proof of performance | Walmart promo DED-PROMO-001 |
| 1.7.4 | Trade promotion | Rebate tier validated against contract | Tesco rebate DED-REBATE-001 |
| 1.7.5 | Trade promotion | Duplicate claim screened before settlement | Kroger dup DED-DUP-001 |

Credit review hold（Review Order Hold）不在 1.4 / 1.7 范围 → 先不挂 tag，见 Q5。

### 6.3 给现存 gate 补齐（改 6 处）

| Gate | 文件 | 改动 |
|---|---|---|
| Promo claim 部分批准 | `promo-claim-run.tsx` | 换 `GateSignoffModal`，tag 1.7.3，签字人 Rachel Ortiz |
| Dup claim 拒付 | `dup-claim-run.tsx` | tag 1.7.5，签字人 Aisha Grant |
| Rebate 部分认可 | `rebate-claim-run.tsx` | tag 1.7.4，签字人 Oliver Shaw |
| Fund 分配 | `fund-claim-run.tsx` | tag 1.7.2，materiality $25,000 保留，签字人 Rachel Ortiz |
| Short-pay / multi-cause | `short-pay-run.tsx`、`multi-cause-deduction-run.tsx` | 按每条线的 class 挂 1.4.3 / 1.4.4 / 1.7.3 |
| Target 价格 | `pricing-hold-card.tsx` | 见 §9，tag 1.4.1 |

### 6.4 新页面：Audit trail（`components/views/audit-view.tsx`）

布局（从上到下）：

1. **页头**：标题 "Audit trail"，右侧 `Export` 按钮。不加 caption。
2. **KPI 行（4 张，等高，每张有小图 + hover tip）**
   - Entries：总数 + 按天的 sparkline
   - By people / by agents：split bar
   - Controls evidenced：`x / 10` + 每个 control 一格的格子条（有记录的亮）
   - Signed decisions：数 + "0 unsigned" chip
3. **筛选条**：Control family（All / 1.4 Billing / 1.7 Trade）、Control（下拉）、Account、Actor（Agent / Person）、Module、日期范围、搜索框。
4. **左表 + 右 380px rail**（借 siemens `case/cases-list.tsx` 的 filter / search / pager + rail 模式，换皮）
   - 表列：Time · Case · Account · Actor · Action · Control · Amount（右对齐）· Signed
   - Rail：这条记录的完整内容：control 名 + 要求的证据 vs 实际附的证据（逐项 Pass / Flag chip）、签名图 + hash、系统、跳回 case 的按钮
5. **Export dialog**（`audit-export-dialog.tsx`）：范围（当前筛选 / 当前 case / 全部）、格式（CSV / PDF）、文件名预览 `audit-trail_<scope>_<yyyymmdd>.csv|pdf`；按钮 "Export"
   - **CSV**：列 = entryId, at, caseId, account, module, actorKind, actor, role, action, controlRef, controlName, amountUsd, decision, evidence (分号分隔), signer, signedAt, signatureHash, system
   - **PDF（A4，600 × 849 版式，签名在页脚）**：抬头 band（Audit trail export、scope、生成时间、导出人）→ control 汇总表（control、条数、已签、例外）→ 明细表 → 页脚签名块。用 **`jspdf` + `jspdf-autotable`**（新依赖，P2 开工前先装）

| 组件 | 新/改 | 动画 |
|---|---|---|
| `views/audit-view.tsx` | 新 | 页根 `animate-enter`；KPI 卡 stagger；表行 stagger（只首屏） |
| `mounts/audit/audit-kpis.tsx` | 新 | 数字 count-up；图 hover tip |
| `mounts/audit/audit-table.tsx` | 新 | 新写入的行 `enter-fade` + 一次 `step-halo` |
| `mounts/audit/audit-rail.tsx` | 新 | `slide-in-right`；证据 chip 逐个出 |
| `mounts/audit/audit-export-dialog.tsx` | 新 | `modal-in`；导出成功 toast "Exported 38 entries" |
| `lib/docs-audit.tsx` | 新 | A4 报告的 SourceDoc 版本（在 app 内预览 = 导出的同一份内容） |
| `mounts/shared/run-complete-modal.tsx` | 改 | 加 "Export audit" 按钮（范围 = 该 case） |
| 各 run 里的 "AI Agent Audit Trail" 区块 | 改 | 每行加 `ControlTag`（有就显示）和签名 icon；数据改读 `auditLog` |

`data-*`：`data-audit-entry`、`data-control-ref`、`data-signed="true"`、`data-export-format="csv|pdf"`、`data-export-count`。

---

## 7 · P3 · #4 Deductions 分 Trade（价值）/ Non-trade（量）

### 7.1 Before → After

| | Before | After |
|---|---|---|
| 结构 | 一个队列，7 类 case 按场景排 | 页顶两张 lane 卡 + **Trade / Non-trade 两个 tab** |
| Trade | 混在队列里 | 逐案调查，人签字，SOX 1.7.x；按金额排序 |
| Non-trade | 只有 multi-cause 里的一条 shortage | **批处理**：一批几百条低额 claim，agent 按规则判，只把例外拆给人；SOX 1.4.3 / 1.4.4 / 1.4.5 |
| 叙事 | 只演 Walmart fund | 演 Walmart fund（trade）**+ 一批 non-trade** |

### 7.2 分类（加字段 `deductionClass: "trade" | "non-trade"`）

| Case | 客户 | Class | Tab |
|---|---|---|---|
| DED-PROMO-001 promo proof | Walmart | trade | Trade |
| DED-DUP-001 duplicate claim | Kroger | trade | Trade |
| DED-REBATE-001 growth rebate | Tesco | trade | Trade |
| DED-FUND-001 fund allocation | Walmart | trade | Trade |
| DED-SP-002 short-pay | Walmart | non-trade | Non-trade |
| DED-RC-009 multi-cause | Kroger | **mixed**：按 cause 行拆，promotion 行 = trade，credit / shortage 行 = non-trade | Non-trade（行内 chip "1 trade line routed"） |
| channel 未授权 chargeback | Walmart | non-trade | Non-trade |
| `deductions.ts` 旧 reason code | — | Promotion allowance = trade；Freight damage / Shortage / Pricing / Tax / Compliance chargeback / Unauthorised chargeback = non-trade | — |

### 7.3 页面结构（`deductions-view.tsx` 改）

1. **Lane 卡 ×2（等高）** — `components/views/deductions/lane-summary.tsx`
   - **Trade · by value**：eyebrow "Trade"；大数 = 本 demo 内 trade 未结金额（selector 加总 4 个 trade case）；小图 = 按 claim 类型的金额横条；chip "SOX 1.7.x"；脚注 "K-C Q&A: trade promotion ≈ $2.4B spend"
   - **Non-trade · by volume**：eyebrow "Non-trade"；大数 = 本批 claim 数 312；小图 = 5 类数量 donut；chip "SOX 1.4.x"；脚注 "K-C Q&A: ≈ 74% of 786K claims by count"
   - 两卡点击 = 切 tab
2. **Tab 条** — `deduction-lane-tabs.tsx`：`Trade (4)` / `Non-trade (312 + 3)`；URL 不变，状态存 store（从 Accounts 跳过来能指定 tab）
3. **Trade tab**：现有队列卡片，只保留 trade case，按金额降序；每卡加 `OwnerChip` + `ControlTag`；"Owner: Trade Finance" 换成客户 owner
4. **Non-trade tab**：
   - 顶部 **批处理卡** `NT-2026-W44`（312 claims · $486,400 · 5 类 · 状态 chip），按钮 "Open batch" → `NonTradeBatchRun`
   - 下面 **"Split out for a person"** 列表：批处理拆出的 12 条 + 原有 DED-SP-002、DED-RC-009、channel chargeback；左表右 rail（同 Audit 的 list → rail 模式）

### 7.4 新 run：`NonTradeBatchRun`（5 段：S1 S2 S3 G1 S4）

| # | id | Label | Agent | 读（tick） | 写（fill） | SOX |
|---|---|---|---|---|---|---|
| S1 | `capture` | Capture | Cash Application Agent | 本周 EDI 820 / 客户 portal 的 deduction 行（Walmart、Kroger、Target、Costco），逐客户 tick，计数 count-up 到 312 | Batch 头：NT-2026-W44、312 claims、$486,400 | — |
| S2 | `classify` | Classify | Deduction Classification Agent | reason code → 类别规则表 | **类别量图**：Shortage 118 · Damage 64 · Pricing 52 · Compliance 61 · Freight 17（柱子按顺序长） | — |
| S3 | `validate` | Validate | Evidence Matching Agent | POD / 签收单、承运商索赔、ASN 时间戳、合规规则手册、价格容差 | **Batch matrix**（类别 × Valid / Invalid / Exception，§12.3），格子逐个 count-up | — |
| G1 | `policy` | Policy sign-off | **Credit & Deductions Lead（NA）**，Walmart 部分由 Rachel Ortiz 会签 | — | 签名；摘要：auto-credit 204 条 $198,400、charge-back 96 条 $251,600、拆出 12 条 $36,400 | **1.4.5**（批处理政策）+ 1.4.3 + 1.4.4 |
| S4 | `post` | Post & signal | FSCM Posting Agent | 已签决定 | 204 个 credit memo、96 个 charge-back、12 个 dispute case 分给 owner（FSCM 汇总屏逐字填）；**ESC-2631**（Supply chain · DC operations："Ontario DC shortage cluster · 86 valid claims"）；Walmart compliance 例外并入已有 ESC-2601 | — |

完成卡："312 claims · 300 closed by policy · 12 with owners · 1 signal to supply chain"（来自 selector）。

### 7.5 组件（新 7 · 改 4）

| 组件 | 新/改 | 内容 / 功能 | 动画 |
|---|---|---|---|
| `views/deductions/lane-summary.tsx` | 新 | 两张 lane 卡（见 7.3） | 卡 stagger；大数 count-up；图 hover tip |
| `views/deductions/deduction-lane-tabs.tsx` | 新 | 两 tab + 计数 | 下划线滑动 |
| `views/non-trade-batch-run.tsx` | 新 | 5 段 run 外壳（复用 `shared/stage-progress-rail`、`run-stage-row`） | 沿用 |
| `mounts/non-trade/category-volume-chart.tsx` | 新 | 5 类数量柱 + 金额标签（recharts，`charts` skill 规范） | 柱从 0 长；hover tip |
| `mounts/non-trade/batch-matrix.tsx` | 新 | 5 × 3 表 + 合计行列，数字右对齐 | 格子逐个 count-up，合计最后出 |
| `mounts/non-trade/split-out-list.tsx` | 新 | 例外列表（filter：类别 / 客户；search；pager） + rail（证据、建议、`GateSignoffModal` 入口：Accept as credit / Charge back） | 行 stagger；rail `slide-in-right` |
| `lib/data/non-trade-batch.ts` + `non-trade-selectors.ts` | 新 | 312 条的类别 × 结果汇总 + 12 条例外明细 | selector assert §12.3 |
| `deductions-view.tsx` | 改 | 队列拆成两 tab；行加 owner / control | — |
| `mounts/exceptions/deduction-cases.tsx` | 改 | 加 class chip | — |
| `mounts/exceptions/deduction-split-modal.tsx` | 改 | 拆分时每行标 trade / non-trade | — |
| `multi-cause-deduction-run.tsx` | 改 | cause 行加 class chip，trade 行显示 "routed to Trade lane" | — |

12 条例外里给一条完整内容（其余只要列表行）：**Walmart OTIF fine $9,800**，Walmart 自己改了收货预约，所以延迟不是 K-C 造成；推荐 charge-back，tag 1.4.4，签字人 Rachel Ortiz。

`data-*`：`data-lane="trade|non-trade"`、`data-deduction-class`、`data-batch="NT-2026-W44"`、`data-batch-total="486400"`、`data-matrix-cell="shortage:valid"`。

---

## 8 · P4 · #5 一个客户一个 owner，agents 在后面，escalation 有追踪

### 8.1 Before → After

| | Before | After |
|---|---|---|
| 组织方式 | 按模块（Order / Billing / Deductions …） | 模块页保留，但每条工作都挂**客户 owner**；新 **Accounts** 页按客户看全部工作 |
| 谁签字 | "Jim"、"Trade Finance"、"Contract Compliance" | 该客户的 owner；超限 Controller co-sign |
| 路由 | "Route to Sales / Trade Finance / Transportation" 按钮，点完就没了 | **Escalate to Commercial / Supply chain**：生成 escalation，有 SLA、账龄、状态链、自动提醒，Accounts 页可追 |

### 8.2 Owner 名册（见 Q4）

| 客户 | 区域 | Owner | 本周工作量（agents / owner） |
|---|---|---|---|
| Walmart Inc. | North America | Rachel Ortiz | 412（398 / 14） |
| Costco Wholesale Corp. | North America | Marcus Hale | 286（277 / 9） |
| Target Corporation | North America | Jim Novak（沿用 "Jim"） | 198（192 / 6） |
| Kroger Co. | North America | Aisha Grant | 176（170 / 6） |
| Tesco PLC | EMEA | Oliver Shaw | 124（119 / 5） |
| Woolworths Group | APAC | Mia Kelly | 88（80 / 8） |
| **合计** | | | **1,284（1,236 / 48）** |

### 8.3 新页面：Accounts（`components/views/accounts-view.tsx`）

1. **KPI 行（4 张，等高，每张真小图 + hover tip）**
   - **Owner coverage**："6 / 6 accounts"，按区域分段条（NA 4 · EMEA 1 · APAC 1）
   - **Handled by agents**："96%"（1,236 / 1,284），每个客户一根 agents / owner split 条
   - **Open escalations**：按团队 split（Commercial / Supply chain），数字随 run 实时变
   - **Escalation age**：分桶柱（0–15 / 16–30 / 31+ 天）+ SLA 虚线；31+ 桶红色
2. **客户列表（左）**：列 = Account · Region · Owner · Open work（Orders / Billing / Deductions 三个小计数）· At risk $（右对齐）· Escalations（chip，逾期红）· Oldest（天）· Agents active。筛选：Region、"Overdue escalation"；搜索；pager（按 20+ 客户设计，不做横向卡片条）。
3. **Rail（右 380px）** — 选中客户：
   - **Owner 卡**：名字、角色、区域、backup owner、委托限额（credit note $50,000、charge-back $100,000）
   - **Agents behind the owner**：每个 agent 一行（icon、名字、正在处理什么、本周件数、最后一次动作时间），复用 `components/agents/agent-workforce.tsx` 的行样式
   - **Open work by module**：Orders / Billing / Deductions（Trade、Non-trade 分开）/ Collections / Cash application，每行可直达对应 case 或 tab
   - **Escalations**：每条 = 团队 + 单位、主题、金额、raised 日期、账龄 / SLA 进度条、`ApprovalChain`（Raised → Acknowledged → Actioned → Closed）、提醒记录；按钮 **Nudge**（写 nudge + audit，toast "Nudge sent to Revenue Management"）
   - 底部 "Audit for this account" → Audit trail 预筛该客户
4. **Woolworths 默认展开时的样子（GPO 举的澳洲例子）**：ESC-2611 "14 trade claims awaiting proof of performance · $418,500 · Commercial (Key Account, AU) · 47 days / SLA 30 · Overdue"；chain 停在 Acknowledged；提醒记录：day 15、day 25 自动提醒，day 31（2026-10-20）自动升级到 Commercial Director；旁边一条小折线 "Average trade claim age"：Jul 21 → Aug 29 → Sep 36 → Oct 44 天。

### 8.4 预置 escalation + run 生成的 escalation

| ID | 客户 | 团队 · 单位 | 主题 | 金额 | Raised | SLA | 来源 |
|---|---|---|---|---|---|---|---|
| ESC-2601 | Walmart | Supply chain · DC operations | OTIF fine appeals need receiving evidence | $19,000 | 2026-10-22 | 15 | 预置（#4 S4 合并进来） |
| ESC-2604 | Tesco | Commercial · Key Account UK | Rebate tier dispute on amended agreement | = rebate `unsupported`（selector） | 2026-10-27 | 15 | 预置 |
| ESC-2607 | Kroger | Supply chain · Transportation | Three pallets short on receipt | $35,000（DED-RC-009 shortage 行） | 2026-10-30 | 10 | 预置 |
| ESC-2611 | Woolworths | Commercial · Key Account AU | Trade claims awaiting proof of performance | $418,500 | 2026-09-19 | 30 | 预置（逾期） |
| ESC-2621 | Costco | Commercial · Revenue Management | Price file and promotion end date not on Costco item file | $150,000 | run 时 | 10 | #1 S5 |
| ESC-2622 | Costco | Supply chain · Transportation | Lane freight above Costco cap | $28,000 | run 时 | 10 | #1 S5 |
| ESC-2625 | Target | Commercial · Revenue Management | Buyer price file one revision behind | $740 | run 时 | 10 | #2 gate 后 |
| ESC-2631 | Walmart / Kroger / Target / Costco | Supply chain · DC operations | Ontario DC shortage cluster | $98,200（shortage valid） | run 时 | 10 | #4 S4 |

### 8.5 模块页 owner 化（改 8 处）

| 文件 | 改动 |
|---|---|
| `order-management-view.tsx` | 订单行 + run 头部加 `OwnerChip`；Target gate 签字人 Jim Novak |
| `billing-view.tsx` | 行加 owner 列 |
| `deductions-view.tsx` | `routedTo` 显示改成 owner；原 "Trade Finance" 变成 escalation 目标 |
| `chargebacks-view.tsx`、`collections-view.tsx`、`cash-application-view.tsx` | 行加 owner 列（只显示，不改流程） |
| `exceptions-view.tsx` | 每条例外显示 owner + 有无 escalation |
| `components/agents/agent-workforce.tsx` | 支持按客户过滤（Accounts rail 用） |

### 8.6 新组件（7）

`views/accounts-view.tsx`、`mounts/accounts/accounts-kpis.tsx`、`account-list.tsx`、`account-rail.tsx`、`agents-behind-owner.tsx`、`open-work-by-module.tsx`、`escalation-tracker.tsx`。
动画：页根进场；KPI stagger + count-up；列表行 stagger（首屏）；rail `slide-in-right`；新 escalation 写入时该行 `step-halo` 一次、chain 节点 `step-pop`。

`data-*`：`data-account`、`data-owner`、`data-escalation-id`、`data-escalation-status`、`data-overdue="true"`。

---

## 9 · P5 · #2 Target：按 K-C 合同价开票

### 9.1 Before → After

| | Before | After |
|---|---|---|
| 推荐 | "Resolve the hold and proceed with PO pricing while recording the discrepancy." | "Bill at contract price CTR-TGG-2026, notify the buyer and record the discrepancy." |
| 理由 | 10 of 12 similar holds released at PO price | 价差 $740 超过 $250 容差（Q2）；perfect-invoice 规则：开票前价格必须对 |
| 按钮 | Accept & release | **Sign & bill at contract**（`GateSignoffModal`，SOX 1.4.1，签字人 Jim Novak） |
| 结果 | 按 PO 价 $220,740 继续 | SAP 订单按 PR00 合同价重定价 **$220,000**；差异记录 **DISC-2049**；确认邮件里告诉买方按合同价开票并请更新 price file；ESC-2625 |

### 9.2 卡片内容（`pricing-hold-card.tsx` 改）

- 4 行价格对比（保留）：SKU、qty、contract、PO、variance（右对齐，合计 $740）
- 新增一行 **Policy**："Gap $740 > $250 tolerance · bill at K-C price"（tolerance 从 data 读）
- 删掉 "Historical cases 12 / 10" 区块，换成 **"If billed at PO price"** 小框："Target would deduct $740 after invoice"（一句，说明为什么不能按 PO 价开）
- Agent recommendation 改为上面的新句子
- Gate 签完后，卡片下方逐字填两张小产出卡：**SAP order repriced**（4 行新价、合计 $220,000）、**Discrepancy record DISC-2049**（PO、合同、差额、原因 "buyer price file one revision behind"、control 1.4.1）

### 9.3 其他改动

| 文件 | 改动 |
|---|---|
| `lib/data/pipeline-orders.ts` | `pricingHoldCase`：删 `historicalCases`；加 `tolerancePerOrderUsd: 250`、`billedAtContractTotal`（selector 算）、`discrepancyRecordId: "DISC-2049"`；`recommendation` 换文案；`approver` → owner 名册；`extraction` 里 "PO placed on hold" note 不变 |
| `order-management-view.tsx` | `PRICING_RECOMMENDATION_LOG`、`PRICING_RELEASE_LOG`、Co-Pilot 回复（"Proceeding with PO pricing…"）、1614 行附近的 "released at PO pricing" 全部改成按合同价 |
| 确认回复弹窗（buyer email thread） | 加一段（≤ 2 句）："We will invoice PO-TGG-8843 at your contract prices, $220,000. Please update your price file to revision CTR-TGG-2026." |
| `lib/data/exceptions.ts` | "4 PO lines priced above contract — total variance $740." 保留，状态文案改为 "Billed at contract price" |

新组件 1：`mounts/order-management/contract-price-outputs.tsx`（两张产出卡）。
`data-*`：`data-price-decision="contract"`、`data-billed-total="220000"`、`data-discrepancy="DISC-2049"`。

---

## 10 · P6 · #3 Costco touchless 缩短 + 讲 invoice-to-cash

### 10.1 Before → After（`SIM_STAGES`）

```
Before: capture → validation → pricing → moq → credit → regulatory → atp → carrier → appointment → confirmed → [POD macro]
After:  capture → validation → pricing → moq → credit → regulatory → atp → confirmed → handoff
```

- `carrier`、`appointment` 两个 stage 删除；POD macro 删除。
- 新 stage **`handoff` · "Logistics handoff"**（macro `fulfillment`）：一张卡读 TMS 三个事实，**不推理、不比价**：Carrier "Blue Line Freight"、Appointment ID、POD 时间。三行逐行 tick，结尾 chip "Outside GBS scope · read only"。
- 宏观 rail：PO Intake · PO Validation · Regulatory Checks · Fulfillment（4 段）。
- **Target SO-710249 共用同一 `SIM_STAGES`**，一起变短（Inland Empire Express 排除那段也删）。
- `carrierReasoning`、`appointmentReasoning`、`MACRO_SUMMARY.fulfillment`、`STAGE_DONE_LOG.carrier/appointment`、`FULFILLMENT_STEP_IDS` 一起清理；`PodEmailModal` / `PodEmailNotice` 不再在订单 run 里弹（组件保留给 Billing 证据用）。

### 10.2 收尾讲 invoice-to-cash

- `RunCompleteModal`（order management 版）加一块 **Invoice-to-cash clock**：`Invoice INV-710260 created at POD 2026-08-29 · Net 30 · cash expected 2026-09-28`，下面一根时间轴（PO → invoice → due），invoice 之后那段高亮。
- 文案："4 min · 0 touches"保留。

### 10.3 Dashboard KPI 替换（`dashboard/kpi-grid.tsx` + `lib/data/kpis.ts`）

| 换掉 | 换成 | 值（见 Q7） | breakdown 行 |
|---|---|---|---|
| Order Cycle Time | **Invoice-to-Cash** | 33 days（target 30） | Current / Target / Best / Trend |
| OTIF | **Right-first-time invoices** | 97.6% | Invoices / Disputed / Reissued 0 / Target |

### 10.4 组件

新 2：`mounts/order-management/logistics-handoff-panel.tsx`、`mounts/order-management/invoice-to-cash-clock.tsx`。
改 4：`order-management-view.tsx`、`mounts/order-management/stage-rail.tsx`、`mounts/order-management/run-complete-modal.tsx`、`dashboard/kpi-grid.tsx`。
`data-*`：`data-stage="handoff"`、`data-stage-count`（Costco run 的 stage 数 = 9）、`data-i2c-days`。

---

## 11 · P7 收尾：narrative 和文档

`data/agentic-otc-narrative.md` 按新流程重写（同样的 "[操作]" 标注格式）：

| 段 | 改动 |
|---|---|
| Dashboard | OTIF / cycle time 换成 invoice-to-cash、right-first-time invoices；加一句去 **Accounts**：一个客户一个 owner |
| SO-710260 Costco | 删掉 Ridgeway / Blue Line 那段；"Logistics hands off; the agent reads carrier, appointment and proof of delivery in one step." 结尾讲 invoice-to-cash clock |
| SO-710249 Target | 换成按合同价、Jim 签字（SOX 1.4.1）、买方收到通知 |
| Billing SO-710269 | 全段重写：short-pay → dispute case → 四原因 → charge-back $150,000 / credit note $38,000 → 签字（1.4.3 / 1.4.4，Controller co-sign）→ 原发票不动 → 回传 Pricing / Master data → 通知 Costco |
| Deductions | 先 Trade 演 Walmart fund（签字 1.7.2），再切 Non-trade 开 NT-2026-W44 批处理 |
| 新段 Accounts | Costco 刚生成的两条 escalation；Woolworths 逾期那条 |
| 新段 Audit trail | 按 1.4.x 过滤 → 导出 PDF |
| Closing | 去掉 "recovered" 说法 |

同时更新 `docs/USECASE-COVERAGE.md`，加 trade / non-trade、owner、SOX 三列。

---

## 12 · Figures 与 tie-out（selector 里 assert）

### 12.1 Billing dispute SO-710269

```
invoice      1,293,000 = 40,000 × 31.00 (1,240,000) + freight 43,000 + tax 10,000
paid         1,105,000 = 40,000 × 28.625 (1,145,000) − promo 55,000 + freight 15,000
short          188,000 = 1,293,000 − 1,105,000 = price 95,000 + promo 55,000 + freight 28,000 + tax 10,000
charge-back    150,000 = price 95,000 + promo 55,000          (K-C right)
credit note     38,000 = freight 28,000 + tax 10,000          (Costco right)
cleared      1,143,000 = paid 1,105,000 + credit 38,000
check        1,293,000 = cleared 1,143,000 + charge-back 150,000
co-sign      charge-back 150,000 > owner limit 100,000 → Controller；credit 38,000 ≤ 50,000 → owner alone
```
日期：invoice 2026-09-18（= delivery），due 2026-10-18（Net 30），remittance 2026-10-16，Sep period closed 2026-10-06。

### 12.2 Target SO-710249

```
PO total        220,740 = 18,200 + 42,180 + 50,200 + 110,160
contract total  220,000 = 18,000 + 42,000 + 50,000 + 110,000
variance            740 = 200 + 180 + 200 + 160 > tolerance 250
```

### 12.3 Non-trade batch NT-2026-W44

| 类别 | 条数 / $ | Valid → credit | Invalid → charge-back | Exception → owner |
|---|---|---|---|---|
| Shortage | 118 / 142,600 | 86 / 98,200 | 28 / 38,900 | 4 / 5,500 |
| Damage | 64 / 78,300 | 51 / 56,100 | 11 / 18,700 | 2 / 3,500 |
| Pricing | 52 / 31,200 | 40 / 24,000 | 12 / 7,200 | 0 / 0 |
| Compliance | 61 / 183,000 | 19 / 12,600 | 38 / 151,400 | 4 / 19,000 |
| Freight | 17 / 51,300 | 8 / 7,500 | 7 / 35,400 | 2 / 8,400 |
| **合计** | **312 / 486,400** | **204 / 198,400** | **96 / 251,600** | **12 / 36,400** |

每行、每列都要 assert（行和 = 类别合计，列和 = 结果合计，总和 = 312 / 486,400）。

### 12.4 Accounts

```
items   1,284 = 412 + 286 + 198 + 176 + 124 + 88
agents  1,236 = 398 + 277 + 192 + 170 + 119 + 80
owner      48 = 14 + 9 + 6 + 6 + 5 + 8
share     96% = round(1,236 / 1,284)
Woolworths ESC-2611: raised 2026-09-19, age 47 on 2026-11-05, SLA 30, auto-escalated day 31 = 2026-10-20
```

### 12.5 外部引用（只做脚注，标 "K-C Q&A"）

trade promotion ≈ $2.4B；786K claims；non-trade ≈ 74% by count；NA order management 99% automation、98.8% EDI；19 SOX controls。

---

## 13 · 复用地图

| 来源 repo | 组件 / 文件 | 用在 | 改什么 |
|---|---|---|---|
| 本 repo | `billing-hold/correction-signoff-modal.tsx`、`signature-pad.tsx` | `GateSignoffModal` | 泛化成任意 gate；加 control、限额、chain |
| 本 repo | `chargebacks/price-bridge.tsx`、`ai-stage-narration.tsx` | #1 cause board | 加 verdict 维度 |
| 本 repo | `deductions/dispute-letter-composer.tsx` | #1 S6 | 支持 credit + charge-back 两段 |
| 本 repo | `shared/stage-progress-rail.tsx`、`run-stage-row.tsx`、`run-complete-modal.tsx`、`use-follow-latest.ts` | 两个新 run | 无 / 加 export 按钮 |
| 本 repo | `components/agents/agent-workforce.tsx` | Accounts rail | 按客户过滤 |
| 本 repo | `lib/docs*.tsx` 的 SourceDoc 体系 | 所有新文档 | 新 builder 文件 |
| `siemens-control-tower` | `case/cases-list.tsx`（FilterChip、Pager）、`case/case-rail.tsx` | Accounts、Audit、Non-trade 例外 | 换皮（去 superellipse / petrol） |
| `siemens-control-tower` | `run/approval-chain.tsx` | co-sign、escalation 状态 | 换皮 |
| `siemens-control-tower` | `dashboard/kpi-tip.tsx`（`FloatingTip`、`useTipAnchor`） | 所有新 KPI 图、`ControlTag` | 换皮 |
| `siemens-control-tower` | `ai/typed-text.tsx`、`count-up.tsx`、`thinking-dots.tsx` | 逐字填、count-up | 本 repo 没有才搬 |
| `siemens-control-tower` | `control/change-log.tsx`、`case/case-audit.tsx` | Audit 表的行结构参考 | 只借结构 |
| `agentic-control-tower` | `routes/audit/AuditRoute.tsx`（页头 stats + Export） | Audit trail 页 | 改成本 repo 的 Card / Button |
| `agentic-control-tower` | `lib/download.ts`、`documents/PdfExportButton.tsx` | 导出 | download 原样；PDF 改成动态生成 |

---

## 14 · 验收（只 build）

1. `pnpm exec tsc --noEmit` 0 错。
2. `pnpm build` 通过。
3. tie-out：`scripts/tieout.mts` 引入所有 selector，跑 §12 全部等式；`package.json` 加 `"tieout"`，build 前跑。
4. grep 检查（脚本里做）：
   - 代码里不再有 "proceed with PO pricing"、"recovers $188,000"、"Ridgeway"、"reissue"（除 `data-invoice-reissued="false"`）
   - 每个 gate 组件都有 `ControlTag`（Review Order Hold 除外，Q5）
   - `.tsx` 里没有手写金额 / 日期（只在 `lib/data/**`）
5. 结构检查：Costco / Target run 的 stage 数 = 9；billing dispute rail 7 段；non-trade run 5 段。

---

## 15 · 待确认（已给默认值，不阻塞开工）

| # | 问题 | 默认 |
|---|---|---|
| Q1 | K-C 19 个 SOX control 的真实编号和名称 | 用 §6.2 的 1.4.1–1.4.5、1.7.1–1.7.5；拿到 K-C 清单后只改 `sox-controls.ts` |
| Q2 | 价差容差是多少 | $250 / order |
| Q3 | SO-710269 四个原因谁对 | price、promotion K-C 对；freight、tax Costco 对（这样 credit note 和 charge-back 都能演到） |
| Q4 | Owner 名字 | §8.2 名册 |
| Q5 | Review Order Hold（credit）挂什么 control | 不挂（不在 1.4 / 1.7） |
| Q6 | Blue Line vs Ridgeway 的推理要不要留在别处 | 全删 |
| Q7 | Invoice-to-Cash、Right-first-time 的值 | 33 days、97.6% |

---

## 16 · 反馈覆盖矩阵

| 反馈原文要求 | PRD 位置 | 验收钩子 |
|---|---|---|
| #1 Remove the invoice reissue | §5.1、§5.5（删 correction / release） | `data-invoice-reissued="false"`；grep 无 "reissue" |
| #1 Difference settled as an FSCM dispute against the original invoice | §5.3 S1、S4 | `data-dispute-case="DC-710269"` |
| #1 Credit note if customer is right, charge-back if not | §5.3 S3、§5.4、§12.1 | `data-verdict`、`data-settlement-*` |
| #1 Keep root-cause breakdown (price, promotion, freight, tax) | §5.3 S2、`cause-board` | `data-cause` ×4 |
| #1 Step that sends the cause back to pricing or master data | §5.3 S5、`upstream-fix-panel` | `data-upstream` |
| #1 Narration no longer "recovered $188,000" | §11 | grep |
| #2 Bill at K-C contract price | §9.1–9.2 | `data-price-decision="contract"`、`data-billed-total` |
| #2 Notify the buyer | §9.3 确认邮件 | 邮件内容 |
| #2 Record the discrepancy | §9.2 DISC-2049 | `data-discrepancy` |
| #2 Price gap above threshold | §9.2 policy 行、Q2 | tolerance 来自 data |
| #2 Remove "10 of 12" precedent | §9.2、§9.3 | grep |
| #3 Carrier, appointment, POD → one step | §10.1 | `data-stage="handoff"`、stage 数 9 |
| #3 Invoice-to-cash is the managed metric | §10.2、§10.3 | `data-i2c-days` |
| #4 Split into trade (value) and non-trade (volume) | §7.2–7.4 | `data-lane`、`data-deduction-class` |
| #4 Trade = highest $, non-trade = 74% of count | §7.3 lane 卡、§12.5 | 脚注 |
| #5 One owner per customer account | §8.2–8.3、§8.5 | `data-owner` |
| #5 Agents working behind the owner | §8.3 rail "Agents behind the owner"、run 头部 | rail 内容 |
| #5 Tracked escalation to commercial and supply chain | §8.3–8.4、`escalation-tracker` | `data-escalation-*` |
| #5 Ageing example (Australia, commercial prioritises revenue) | §8.3 第 4 点 ESC-2611 | `data-overdue="true"` |
| #6 Tag each approval with SOX control ref (billing 1.4.x, trade 1.7.x) | §6.2–6.3 | `data-control-ref` |
| #6 Audit trail can be exported | §6.4 | `data-export-format` |
| #6 Proof of performance / authorisations for trade | §6.2 1.7.3、gate 证据清单 | rail 证据 chip |
