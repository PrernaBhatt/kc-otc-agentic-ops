# Porting Conventions (Phase 1 — 1:1 parity)

You are porting a minified React component back to clean TypeScript. The minified
reference slices live in `reference/extract/*.js`. The live reference app runs at
http://localhost:8080 (compiled original).

## Absolute rules
1. **1:1 parity**: every visible string, number, className, chart prop, and timing
   constant must match the reference slice exactly. Do not improve, rename, or
   redesign anything in Phase 1.
2. Minified symbol map (same in every slice):
   - `q.jsx/q.jsxs` = JSX; `G.useState/G.useEffect/...` = React hooks
   - `eJ(...)` = `cn(...)` from `@/lib/utils`
   - `ap/am/ah/ag/av` = Card/CardHeader/CardTitle/CardDescription/CardContent from `@/components/ui/card`
   - `e1` = Button, `e2` = Input, `ar` = Badge, `AT` = Label, `Ay` = Progress, textarea = Textarea
   - `Q("IconName",[...])` = lucide-react icon factory → `import { IconName } from "lucide-react"`.
     Icon variable → name mapping is visible at each `Q("Name")` call site in the slices.
   - Recharts minified names map by usage/props: AreaChart/Area, PieChart/Pie/Cell,
     LineChart/Line, BarChart/Bar, XAxis (dataKey), YAxis, CartesianGrid
     (strokeDasharray "3 3"), Tooltip (contentStyle), ResponsiveContainer
     (width "100%" height 200), Legend.
   - `a$` = AgentIcon (`@/components/agents/agent-icon`), `aF` = Spinner, `aV` = AnimatedProgress,
     `aU` = status chip helper — all in `@/components/agents/`.
   - `EC` = DrilldownModal (`@/components/modals/drilldown-modal`), `aS` = KpiDetailModal.
   - `Eq` = AgentActivityFeed, `EW` = agent color map, `AB` = AgentWorkflowCard.
3. Data comes from `@/lib/data` (already contains: customers, orders, invoices,
   creditDecision, exceptions, kpis, agentActivities, orderVolumeTrend,
   exceptionBreakdown, dsoTrend, agentPerformance + all types). If your slice has
   its own inline dataset (pipeline stages, billing items, chat scripts, workflow
   steps, drilldown rows, extra hold order), transcribe it into a module-level
   `const` **inside your component file** for Phase 1 — exact values.
4. All view/flow components are client components: start file with `"use client";`.
5. Styling: Tailwind classes copied verbatim from the slice, including
   `bg-[var(--success)]`-style arbitrary values. Do NOT substitute tokens.
6. Timing constants copied exactly (500ms login, 2000ms workflow steps,
   200/400/500ms progress intervals).
7. TypeScript: no `any` unless unavoidable; import types from `@/lib/data`.
8. Files must compile: `cd /Users/kyle/Desktop/agentic-otc-demo && npx tsc --noEmit`
   must pass for your files. Run it before finishing. (Others may be editing
   sibling files — only fix errors in YOUR files.)

## Component contracts (do not change signatures)
- `DashboardView({ onNavigate }: { onNavigate: (view: ViewId, orderId?: string) => void })`
- `CreditReviewView({ focusOrderId, onNavigateToFulfillment, onBack }: { focusOrderId?: string; onNavigateToFulfillment: () => void; onBack?: () => void })`
- `OrderManagementView()` — no props
- `TransactionsView({ onProcessOrder }: { onProcessOrder: (orderId: string) => void })`
- `ExceptionsView({ onResolveWithAI, completedOrderIds }: { onResolveWithAI: (orderId: string) => void; completedOrderIds: string[] })`
- `CopilotView()`, `BillingView()`, `CollectionsView()` — no props
- `AgentWorkflowCard({ type, activeStep, showDetails }: { type: "order" | "billing"; activeStep: number; showDetails?: boolean })`
- `AgentActivityFeed({ activities }: { activities: AgentActivity[] })`
- `FulfillmentFlow({ orderId, onBack, onComplete }: { orderId?: string; onBack: () => void; onComplete: (orderId?: string) => void })`
- `OrderProcessingFlow({ order, onBack, onComplete }: { order: Order; onBack: () => void; onComplete: (orderId: string) => void })`
- `ViewId` type: import from `@/components/layout/sidebar`.
- Charts: `OrderTrendChart()`, `ExceptionBreakdownChart()`, `DsoTrendChart()`, `AgentPerformanceChart()` — no props, data imported from `@/lib/data`.
- `DrilldownModal({ title, data, onClose }: { title: string; data: Record<string, string | number>[]; onClose: () => void })` — auto-generates table from `Object.keys(data[0])`.
- `AgentIcon({ type, className }: { type: string; className?: string })` — 14 hand-drawn SVG types.

## Verification for each ported view
Compare against http://localhost:8080 (login prefilled, click Sign In, navigate to
your view). Your rendered text content must match the reference's text content.
