# Phase 3 Mount Conventions (read before writing any code)

You are ADDING use-case surfaces to an existing, verified demo. Rules:

## Hard rules
1. **Strictly additive.** Never remove or reword existing UI, data, flows, or
   timings. New tabs/sections/panels sit beside what exists.
2. **No hardcoded numbers.** Every number comes from `@/lib/data`,
   `@/lib/selectors`, or the store `useOtcStore()` (`@/lib/store`). If you need
   a number that doesn't exist, derive it or add a clearly named seed constant
   in `lib/data` (NOT inline in the component).
3. **Numbers co-move.** Interactions call store actions (`applyReceipt`,
   `resolveDeduction`, `approveProvision`, `releaseRegulatoryHold`,
   `markOrderBilled`, `sendQueryReply`, `capturePtp`) so every dependent
   surface updates. Read state from the store, not module consts, wherever the
   value can change.
4. **Human-in-the-loop.** AI recommends; the human clicks every decision.
   Copy style: "AI recommends… / Approve / Choose another option". Never "AI
   applied/approved X".
5. **Source documents everywhere.** Every new card/panel that shows derived
   numbers gets a `SourceDocTrigger` (from
   `@/components/modals/source-doc-preview`) opening the matching builder from
   `@/lib/docs` (buildInboundPoDoc, buildSalesOrderDoc, buildBankStatementDoc,
   buildRemittanceDoc, buildInvoiceDoc, buildPodDoc, buildRecallNoticeDoc,
   buildAgingReportDoc, buildProvisionDoc, buildContractDoc,
   buildRevRecScheduleDoc, buildClaimDoc). Yellow-highlighted rows + one-shot
   typed AI summary are built into the modal.
6. **Plain business language.** No jargon, no unexplained acronyms: say
   "bank statement file" not MT940/BAI2; "electronic remittance" not EDI 820;
   "minimum order quantity" spelled out on first use per surface. No math
   symbols in labels.
7. **Layout invariants.** Cards in a horizontal row: `flex h-full flex-col`
   with action footer on `mt-auto`. Buttons `whitespace-nowrap`. Row gaps
   `gap-4`/`gap-6` like the surrounding view. KPI-style tiles max 3-4 per new
   section; tables 5-7 rows. No text below `text-xs`, and `text-xs` only for
   captions/badges like the existing views.
8. **Match house style.** Reuse Card/Badge/Button/Table from
   `@/components/ui/*`, AgentIcon/Spinner/AnimatedProgress from
   `@/components/agents/*`, gradient headers and badge patterns exactly like
   the view you are editing. Icons from lucide-react.
9. New subcomponents live in `components/mounts/<area>/*.tsx`; the view file
   imports them. Keep the view file's existing structure readable.
10. Do NOT edit shared docs (USECASE-COVERAGE.md), lib/store.tsx, lib/docs.tsx,
    lib/selectors.ts, or another agent's view. If something is missing, note it
    in your final report instead of hacking around it.
11. After writing: `cd /Users/kyle/Desktop/agentic-otc-demo && npx tsc --noEmit`
    must pass for your files; fix only your own errors.

## Demo storyline anchors (use these, do not invent new ids)
- Regulated order: SO-710262 (ABC Traders, $92,500; pen-needle line on
  quality-held lot LOT-88412; substitute lot LOT-88907). PO: PO-ABC-3321.
- Clean inbound PO: PO-GMI-7788 → SO-710260.
- Shipments: SHP-001 delivered (SO-710248, proof of delivery signed);
  SHP-002 delayed 5 days (SO-710247); SHP-003 planning (SO-710246, promised
  Jan 24).
- Receipts: RCPT-9001 applied; RCPT-9002 exact-match proposal ($180,000 →
  INV-12346); RCPT-9003 short-pay ($38,500 vs $42,000 → deduction DED-001);
  RCPT-9004 unidentified ($25,000).
- Deductions: DED-001 (freight damage, TechPro), DED-002 (promotion
  allowance, ABC, debit memo DM-2201).
- Promises to pay: PTP-001 open ($85,000 GMI by Jan 28), PTP-002 honored.
- Provision: required reserve derived; existing allowance $42,500; Controller
  approval pending.
- Revenue: OBL-001 recognized ($275,000, delivered), OBL-002 deferred
  ($340,000, promised Jan 24), OBL-003 service obligation ($2,750).
- Queries: QRY-101..107 across the 7 scopes.
- Demo date: TODAY = 2025-01-20 (lib/data/clock.ts).

## 12. DENSITY RULE (overriding design principle — the #1 rule)
The user repeatedly rejects dense/cluttered layouts. Simplicity beats
completeness. HARD LIMITS, not guidelines:

**Default state of ANY item = ONE collapsed row.** A row is: label + at most 3
chips/values + one primary action + a chevron. Nothing else is visible until
the user clicks. This applies to every list item, case, tie-out, order,
invoice, deduction, checklist row — everything.

**Per screen, collapsed, you may show at most:**
- ONE heading + ONE sentence of subtext.
- ONE list of one-line rows (5–8 rows), OR 3–4 KPI tiles. Not both stacked.
- NO second stacked section of cards. If you need a second grouping, use a TAB.

**BANNED (these are what "too dense/ugly" means — never ship them):**
- More than one multi-card grid on a screen at once.
- A card taller than ~3 lines in its default (unexpanded) state.
- Repeating the same big block twice on one screen (e.g. two full tie-outs).
  Show a one-line summary row per case; the big block only appears on expand.
- Walls of chips/validation badges shown before any click.
- Stacking: header → cards → tie-out rows → banner → chips, all visible.

**Method:** design the collapsed row first. Put EVERYTHING else behind a click.
When unsure, cut it or move it to a tab. Re-screenshot at thumbnail size — if it
reads as a wall, it fails. Match the ORIGINAL compiled demo's calm density.
