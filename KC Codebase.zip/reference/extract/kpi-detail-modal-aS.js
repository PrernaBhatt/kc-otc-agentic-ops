: "d8bk6v"
}]]);

function aS({
    kpi: e,
    onClose: t
}) {
    return (0, q.jsx)("div", {
                className: "fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4",
                children: (0, q.jsxs)("div", {
                            className: "bg-gradient-to-br from-white via-gray-50 to-gray-100 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 rounded-2xl shadow-2xl max-w-md w-full border border-gray-200 dark:border-gray-700",
                            children: [(0, q.jsxs)("div", {
                                        className: "flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-primary/10 to-primary/5",
                                        children: [(0, q.jsxs)("h3", {
                                            className: "font-bold text-lg text-foreground",
                                            children: [e.label, " Details"]
                                        }), (0, q.jsx)("button", {
                                            onClick: t,
                                            className: "p-2 hover:bg-white/50 dark:hover:bg-black/30 rounded-lg transition-all",
                                            children: (0, q.jsx)(ak, {
                                                className: "h-5 w-5"
                                            })
                                        })]
                                    }), (0, q.jsxs)("div", {
                                            className: "p-6",
                                            children: [(0, q.jsx)("div", {
                                                        className: "text-4xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent mb-6",
                                                        children: e.value
                                                    }), (0, q.jsx)("div", {
                                                            className: "space-y-3",
                                                            children: e.details.map((e, t) => (0, q.jsxs)("div", {
                                                                            className: "flex items-center justify-between py-3 px-4 rounded-lg bg-white/60 dark:bg-black/20 border border-gray-200 dark:border-gray-700 hover:shadow-md transition-all",
                                                                            children: [(0, q.jsx)("span", {
                                                                                        className: "text-sm font-medium text-muted-foreground",
                                                                                        children: e.metric
                                                                                    }), (0, q.jsxs)("div", {
                                                                                            className: "flex items-center gap-3",
                                                                                            children: [(0, q.jsx)("span", {
                                                                                                        className: "font-semibold text-foreground",
                                                                                                        children: e.value
                                                                                                    }), (0, q.jsx)("span", {
                                                                                                            className: eJ("text-xs px-3 py-1 rounded-full font-medium", "Good" === e.status ? "bg-gradient-to-r from-green-100 to-emerald-100 text-green-700 dark:from-green-900 dark:to-emerald-900 dark:text-green-300" : "Warning" === e.status ? "bg-gradient-to-r from-yellow-100 to-amber-100 text-yellow-700 dark:from-yellow-900 dark:to-ambe