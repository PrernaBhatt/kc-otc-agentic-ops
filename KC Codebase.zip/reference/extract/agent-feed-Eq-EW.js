function Eq({
    activities: e
}) {
    return (0, q.jsxs)(ap, {
        children: [(0, q.jsx)(am, {
            className: "pb-3",
            children: (0, q.jsxs)(ah, {
                className: "text-lg flex items-center gap-2",
                children: [(0, q.jsx)(a$, {
                    type: "orchestrator",
                    size: "sm",
                    className: "text-primary"
                }), "Agent Activity Feed"]
            })
        }), (0, q.jsx)(av, {
            children: (0, q.jsx)("div", {
                className: "space-y-4",
                children: e.map((t, r) => {
                    let n = EW[t.agentType] || EW.orchestrator;
                    return (0, q.jsxs)("div", {
                        className: "flex gap-3",
                        children: [(0, q.jsxs)("div", {
                            className: "relative flex flex-col items-center",
                            children: [(0, q.jsx)("div", {
                                className: eJ("flex h-10 w-10 items-center justify-center rounded-full", n.color),
                                children: "processing" === t.status ? (0, q.jsx)(aF, {
                                    size: "sm",
                                    className: "text-white"
                                }) : (0, q.jsx)(a$, {
                                    type: t.agentType,
                                    size: "sm",
                                    className: "text-white"
                                })
                            }), r < e.length - 1 && (0, q.jsx)("div", {
                                className: "w-0.5 flex-1 bg-border mt-2"
                            })]
                        }), (0, q.jsxs)("div", {
                            className: "flex-1 pb-4",
                            children: [(0, q.jsxs)("div", {
                                className: "flex items-center gap-2 mb-1",
                                children: [(0, q.jsx)("span", {
                                    className: "font-medium text-sm",
                                    children: t.agentName
                                }), (0, q.jsxs)(ar, {
                                    variant: "complete" === t.status ? "default" : "processing" === t.status ? "secondary" : "destructive",
                                    className: eJ("text-xs", "complete" === t.status && "bg-[var(--success)] text-white", "processing" === t.status && "bg-[var(--info)] text-white"),
                                    children: ["processing" === t.status && (0, q.jsx)(aF, {
                                        size: "sm",
                                        className: "mr-1"
                                    }), "complete" === t.status && (0, q.jsx)(aB, {
                                        className: "h-3 w-3 mr-1"
                                    }), "error" === t.status && (0, q.jsx)(as, {
                                        className: "h-3 w-3 mr-1"
                                    }), t.status]
                                })]
                            }), (0, q.jsx)("p", {
                                className: "text-sm text-muted-foreground",
                                children: t.message
                            }), (0, q.jsx)("span", {
                                className: "text-xs text-muted-foreground/70",
                                children: new Date(t.timestamp).toLocaleTimeString()
                            })]
                        })]
                    }, t.id)
                })
            })
        })]
    })
}
let EG = Q("Sparkles", [
        ["path", {
            d: "M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z",
            key: "4pj2yx"
        }],
        ["path", {
            d: "M20 3v4",
            key: "1olli1"
        }],
        ["path", {
            d: "M22 5h-4",
            key: "1gvqau"
        }],
        ["path", {
            d: "M4 17v2",
            key: "vumght"
        }],
        ["path", {
            d: "M5 18H3",
            key: "zchphs"
        }]
    ]),
    EY = Q("ArrowRight", [
        ["path", {
            d: "M5 12h14",
            key: "1ays0h"
        }],
        ["path", {
            d: "m12 5 7 7-7 7",
            key: "xquz4c"
        }]
    ]);

function EZ({
    decision: e,
    onApprove: t
}) {
    let [r, n] = (0, G.useState)(null), [i, a] = (0, G.useState)(!1), o = async () => {
        r && (a(!0), await new Promise(e => setTimeout(e, 1500)), t(r), a(!1))
    };
    return (0, q.jsxs)(ap, {
        className: "border-primary/20 bg-card",
        children: [(0, q.jsxs)(am, {
            className: "pb-4",
            children: [(0, q.jsxs)("div", {
                className: "flex items-center justify-between",
                children: [(0, q.jsxs)("div", {
                    className: "flex items-center gap-2",
                    children: [(0, q.jsx)(EG, {
                        className: "h-5 w-5 text-primary"
                    }), (0, q.jsx)(ah, {
                        className: "text-lg",
                        children: "AI Decision Options"
                    })]
                }), (0, q.jsx)(ar, {
                    variant: "outline",
                    className: "text-primary border-primary",
                    children: "Golden Trio"
                })]
            }), (0, q.jsx)(ag, {
                children: "Select an option to release order SO-710245. Human approval required."
            })]
        }), (0, q.jsxs)(av, {
            className: "space-y-4",
            children: [(0, q.jsxs)("div", {
                className: "grid grid-cols-3 gap-4 p-4 bg-muted/50 rounded-lg",
                children: [(0, q.jsxs)("div", {
                    className: "text-center",
                    children: [(0, q.jsxs)("div", {
                        className: "flex items-center justify-center gap-1 text-muted-foreground text-sm mb-1",
                        children: [(0, q.jsx)(ad, {
                            className: "h-4 w-4"
                        }), "Risk Score"]
                    }), (0, q.jsxs)("div", {
                        className: "text-2xl font-bold text-foreground",
                        children: [(100 * e.riskScore).toFixed(0), "%"]
                    })]
                }), (0, q.jsxs)("div", {
                    className: "text-center",
                    children: [(0, q.jsxs)("div", {
                        className: "flex items-center justify-center gap-1 text-muted-foreground text-sm mb-1",
                        children: [(0, q.jsx)(ay, {
                            className: "h-4 w-4"
                        }), "LTV Score"]
                    }), (0, q.jsxs)("div", {
                        className: "text-2xl font-bold text-foreground",
                        children: [(100 * e.ltvScore).toFixed(0), "%"]
                    })]
                }), (0, q.jsxs)("div", {
                    className: "text-center",
                    children: [(0, q.jsxs)("div", {
                        className: "flex items-center justify-center gap-1 text-muted-foreground text-sm mb-1",
                        children: [(0, q.jsx)(au, {
                            className: "h-4 w-4"
                        }), "Propensity"]
                    }), (0, q.jsxs)("div", {
                        className: "text-2xl font-bold text-foreground",
                        children: [(100 * e.propensityScore).toFixed(0), "%"]
                    })]
                })]
            }), (0, q.jsx)("div", {
                className: "space-y-3",
                children: e.options.map(e => (0, q.jsxs)("div", {
                    className: eJ("p-4 border rounded-lg cursor-pointer transition-all", r === e.id ? "border-primary bg-primary/5 ring-2 ring-primary/20" : "border-border hover:border-primary/50"),
                    onClick: () => n(e.id),
                    children: [(0, q.jsxs)("div", {
                        className: "flex items-start justify-between mb-3",
                        children: [(0, q.jsxs)("div", {
                            children: [(0, q.jsxs)("div", {
                                className: "flex items-center gap-2 mb-1",
                                children: [(0, q.jsx)("span", {
                                    className: "font-semibold text-foreground",
                                    children: e.name
                                }), (0, q.jsx)(ar, {
                                    className: (e => {
                                        switch (e) {
                                            case "Aggressive":
                                                return "bg-[var(--success)] text-white";
                                            case "Balanced":
                                                return "bg-[var(--info)] text-white";
                                            case "Conservative":
                                                return "bg-[var(--warning)] text-[var(--warning-foreground)]";
                                            default:
                                                return "bg-muted text-muted-foreground"
                                        }
                                    })(e.type),
                                    children: e.type
                                })]
                            }), (0, q.jsx)("div", {
                                className: "flex flex-wrap gap-2",
                                children: e.conditions.map((e, t) => (0, q.jsx)(ar, {
                                    variant: "outline",
                                    className: "text-xs",
                                    children: e
                                }, t))
                            })]
                        }), (0, q.jsxs)("div", {
                            className: "text-right",
                            children: [(0, q.jsx)("div", {
                                className: "text-sm text-muted-foreground",
                                children: "Confidence"
                            }), (0, q.jsxs)("div", {
                                className: "text-lg font-bold text-foreground",
                                children: [(100 * e.confidence).toFixed(0), "%"]
                            })]
                        })]
                    }), (0, q.jsxs)("div", {
                        className: "grid grid-cols-3 gap-3 mt-3 pt-3 border-t",
                        children: [(0, q.jsxs)("div", {
                            children: [(0, q.jsx)("div", {
                                className: "text-xs text-muted-foreground",
                                children: "Residual Risk"
                            }), (0, q.jsxs)("div", {
                                className: "font-semibold text-foreground text-base mt-0.5",
                                children: [(100 * e.riskDelta).toFixed(0), "%"]
                            })]
                        }), (0, q.jsxs)("div", {
                            children: [(0, q.jsx)("div", {
                                className: "text-xs text-muted-foreground",
                                children: "LTV Impact"
                            }), (0, q.jsxs)("div", {
                                className: eJ("font-semibold text-base mt-0.5", e.ltvImpact > 0 ? "text-[var(--success)]" : "text-primary"),
                                children: [e.ltvImpact > 0 ? "+" : "", (100 * e.ltvImpact).toFixed(0), "%"]
                            })]
                        }), (0, q.jsxs)("div", {
                            children: [(0, q.jsx)("div", {
                                className: "text-xs text-muted-foreground",
                                children: "Cash Exposure"
                            }), (0, q.jsx)("div", {
                                className: "font-semibold text-foreground text-base mt-0.5",
                                children: e.cashFlowEffect > 0 ? `$${e.cashFlowEffect.toLocaleString()}` : "-"
                            })]
                        })]
                    })]
                }, e.id))
            }), (0, q.jsxs)("div", {
                className: "p-3 bg-[var(--success)]/10 rounded-lg",
                children: [(0, q.jsxs)("div", {
                    className: "flex items-center gap-2 text-sm font-medium text-[var(--success)] mb-2",
                    children: [(0, q.jsx)(aB, {
                        className: "h-4 w-4"
                    }), "Guardrails Applied"]
                }), (0, q.jsx)("div", {
                    className: "flex flex-wrap gap-2",
                    children: e.guardrailsApplied.map((e, t) => (0, q.jsx)(ar, {
                        variant: "secondary",
                        className: "bg-[var(--success)]/20 text-[var(--success)]",
                        children: e
                    }, t))
                })]
            }), (0, q.jsx)(e1, {
                className: "w-full",
                size: "lg",
                disabled: !r || i,
                onClick: o,
                children: i ? (0, q.jsx)(q.Fragment, {
                    children: "Processing Approval..."
                }) : (0, q.jsxs)(q.Fragment, {
                    children: [(0, q.jsx)(Ez, {
                        className: "h-4 w-4 mr-2"
                    }), "Approve as Credit Manager", (0, q.jsx)(EY, {
                        className: "h-4 w-4 ml-2"
                    })]
                })
            })]
        })]
    })
}
let EX = Q("TriangleAlert", [
        ["path", {
            d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
            key: "wmoenq"
        }],
        ["path", {
            d: "M12 9v4",
            key: "juzpu7"
        }],
        ["path", {
            d: "M12 17h.01",
            key: "p32p05"
        }]
    ]),
    EQ = Q("Clock", [
        ["circle", {
            cx: "12",
            cy: "12",
            r: "10",
            key: "1mglay"
        }],
        ["polyline", {
            points: "12 6 12 12 16 14",
            key: "68esgv"
        }]
    ]),
    EJ = Q("ChevronDown", [
        ["path", {
            d: "m6 9 6 6 6-6",
            key: "qrunsl"
        }]
    ]),
    E0 = Q("ChevronUp", [
        ["path", {
            d: "m18 15-6-6-6 6",
            key: "153udz"
        }]
    ]),
    E1 = Q("Play", [
        ["polygon", {
            points: "6 3 20 12 6 21 6 3",
            key: "1oa8hb"
        }]
    ]);

function E2({
    order: e,
    onClick: t,
    isCompleted: r = !1,
    isExpanded: n = !1
}) {
    let [i, a] = (0, G.useState)(n), o = (e => {
        switch (e) {
            case "Hold":
                return {
                    color: "bg-primary text-primary-foreground", icon: EX
                };
            case "Blocked":
                return {
                    color: "bg-[var(--warning)] text-[var(--warning-foreground)]", icon: EX
                };
            case "Processing":
                return {
                    color: "bg-[var(--info)] text-white", icon: EQ
                };
            case "Released":
            case "Fulfilled":
                return {
                    color: "bg-[var(--success)] text-white", icon: aB
                };
            default:
                return {
                    color: "bg-muted text-muted-foreground", icon: aa
                }
        }
    })(e.status), s = o.icon;
    return (0, q.jsxs)(ap, {
        className: eJ("transition-all", "Hold" === e.status && "border-primary/50", "Blocked" === e.status && "border-[var(--warning)]/50", r && "opacity-60"),
        children: [(0, q.jsxs)(am, {
            className: "pb-3",
            children: [(0, q.jsxs)("div", {
                className: "flex items-start justify-between",
                children: [(0, q.jsxs)("div", {
                    children: [(0, q.jsxs)("div", {
                        className: "flex items-center gap-2 mb-1",
                        children: [(0, q.jsx)(ah, {
                            className: "text-base font-semibold",
                            children: e.orderId
                        }), r ? (0, q.jsxs)(ar, {
                            className: "bg-[var(--success)] text-white",
                            children: [(0, q.jsx)(aB, {
                                className: "h-3 w-3 mr-1"
                            }), "Complete"]
                        }) : (0, q.jsxs)(ar, {
                            className: o.color,
                            children: [(0, q.jsx)(s, {
                                className: "h-3 w-3 mr-1"
                            }), e.status]
                        }), e.loopOrderFlag && (0, q.jsx)(ar, {
                            variant: "outline",
                            className: "border-[var(--success)] text-[var(--success)]",
                            children: "Loop Order"
                        })]
                    }), (0, q.jsx)("p", {
                        className: "text-sm text-muted-foreground",
                        children: e.customerName
                    })]
                }), (0, q.jsxs)("div", {
                    className: "text-right",
                    children: [(0, q.jsxs)("div", {
                        className: "text-lg font-bold text-foreground",
                        children: ["$", e.totalValue.toLocaleString()]
                    }), (0, q.jsx)("div", {
                        className: "text-xs text-muted-foreground",
                        children: e.orderDate
                    })]
                })]
            }), e.holdReason && (0, q.jsxs)("div", {
                className: "flex items-center gap-2 mt-2 p-2 bg-primary/10 rounded-md",
                children: [(0, q.jsx)(EX, {
                    className: "h-4 w-4 text-primary"
                }), (0, q.jsxs)("span", {
                    className: "text-sm text-primary font-medium",
                    children: ["Hold Reason: ", e.holdReason]
                })]
            })]
        }), i && (0, q.jsx)(av, {
            className: "pt-0",
            children: (0, q.jsxs)("div", {
                className: "border-t pt-3",
                children: [(0, q.jsxs)("div", {
                    className: "text-sm font-medium mb-2 text-foreground",
                    children: ["Line Items (", e.lineItems.length, ")"]
                }), (0, q.jsx)("div", {
                    className: "space-y-2",
                    children: e.lineItems.map(e => (0, q.jsxs)("div", {
                        className: "flex items-center justify-between p-2 bg-muted/50 rounded-md text-sm",
                        children: [(0, q.jsxs)("div", {
                            className: "flex items-center gap-3",
                            children: [(0, q.jsx)("span", {
                                className: "font-mono text-xs text-muted-foreground",
                                children: e.sku
                            }), (0, q.jsx)("span", {
                                className: "text-foreground",
                                children: e.productName
                            }), e.loopLineFlag && (0, q.jsx)(ar, {
                                variant: "outline",
                                className: "text-xs border-[var(--success)] text-[var(--success)]",
                                children: "Loop"
                            })]
                        }), (0, q.jsxs)("div", {
                            className: "flex items-center gap-4",
                            children: [(0, q.jsxs)("span", {
                                className: "text-muted-foreground",
                                children: ["Qty: ", e.qty]
                            }), (0, q.jsxs)("span", {
                                className: "font-medium text-foreground",
                                children: ["$", e.lineValue.toLocaleString()]
                            }), e.priceValidated && (0, q.jsx)(aB, {
                                className: "h-4 w-4 text-[var(--success)]"
                            })]
                        })]
                    }, e.orderLineId))
                })]
            })
        }), (0, q.jsxs)("div", {
            className: "px-6 pb-4 flex items-center justify-between",
            children: [(0, q.jsx)(e1, {
                variant: "ghost",
                size: "sm",
                onClick: () => a(!i),
                children: i ? (0, q.jsxs)(q.Fragment, {
                    children: [(0, q.jsx)(E0, {
                        className: "h-4 w-4 mr-1"
                    }), "Collapse"]
                }) : (0, q.jsxs)(q.Fragment, {
                    children: [(0, q.jsx)(EJ, {
                        className: "h-4 w-4 mr-1"
                    }), "View Lines"]
                })
            }), t && (0, q.jsxs)(e1, {
                variant: "default",
                size: "sm",
                onClick: t,
                className: "bg-primary hover:bg-primary/90",
                disabled: r,
                children: [(0, q.jsx)(E1, {
                    className: "h-4 w-4 mr-1"
                }), r ? "Completed" : "Process Order"]
            })]
        })]
    })
}