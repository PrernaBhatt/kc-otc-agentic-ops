function AR({
    onLogin: e
}) {
    let [t, r] = (0, G.useState)("agenticuser"), [n, i] = (0, G.useState)("otcworkspace"), [a, o] = (0, G.useState)(""), [s, l] = (0, G.useState)(!1);
    return (0, q.jsxs)("div", {
        className: "relative min-h-screen w-full overflow-hidden bg-black flex",
        children: [(0, q.jsx)("div", {
            className: "relative z-10 flex min-h-screen w-full md:w-[30%] items-center justify-center px-4 py-8 bg-black",
            children: (0, q.jsxs)("div", {
                className: "w-full max-w-md",
                children: [(0, q.jsxs)("div", {
                    className: "rounded-xl border border-[#ff0000]/20 bg-black/80 backdrop-blur-sm shadow-2xl shadow-[#ff0000]/10",
                    children: [(0, q.jsxs)("div", {
                        className: "p-8 space-y-6",
                        children: [(0, q.jsxs)("div", {
                            className: "text-center space-y-2",
                            children: [(0, q.jsx)("h1", {
                                className: "text-3xl font-bold text-white",
                                children: "Welcome Back"
                            }), (0, q.jsx)("p", {
                                className: "text-slate-300",
                                children: "Sign in to access your OTC Workspace"
                            })]
                        }), (0, q.jsxs)("form", {
                            onSubmit: r => {
                                r.preventDefault(), o(""), l(!0), setTimeout(() => {
                                    (t === "agenticuser" || t === "") && (n === "otcworkspace" || n === "") ? e(): (o("Invalid username or password"), l(!1))
                                }, 500)
                            },
                            className: "space-y-5",
                            children: [(0, q.jsxs)("div", {
                                className: "space-y-2",
                                children: [(0, q.jsx)(AT, {
                                    htmlFor: "username",
                                    className: "text-slate-200 text-sm font-medium",
                                    children: "Username"
                                }), (0, q.jsxs)("div", {
                                    className: "relative",
                                    children: [(0, q.jsx)(Ez, {
                                        className: "absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400"
                                    }), (0, q.jsx)(e2, {
                                        id: "username",
                                        type: "text",
                                        placeholder: "Enter your username",
                                        value: t,
                                        onChange: e => r(e.target.value),
                                        className: "pl-10 bg-zinc-900/50 border-zinc-800 text-white placeholder:text-slate-500 focus:border-[#ff0000] focus:ring-[#ff0000]/20 h-11",
                                        required: !0
                                    })]
                                })]
                            }), (0, q.jsxs)("div", {
                                className: "space-y-2",
                                children: [(0, q.jsx)(AT, {
                                    htmlFor: "password",
                                    className: "text-slate-200 text-sm font-medium",
                                    children: "Password"
                                }), (0, q.jsxs)("div", {
                                    className: "relative",
                                    children: [(0, q.jsx)(A_, {
                                        className: "absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400"
                                    }), (0, q.jsx)(e2, {
                                        id: "password",
                                        type: "password",
                                        placeholder: "Enter your password",
                                        value: n,
                                        onChange: e => i(e.target.value),
                                        className: "pl-10 bg-zinc-900/50 border-zinc-800 text-white placeholder:text-slate-500 focus:border-[#ff0000] focus:ring-[#ff0000]/20 h-11",
                                        required: !0
                                    })]
                                })]
                            }), a && (0, q.jsxs)("div", {
                                className: "flex items-center gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20",
                                children: [(0, q.jsx)(as, {
                                    className: "h-4 w-4 text-red-400 flex-shrink-0"
                                }), (0, q.jsx)("p", {
                                    className: "text-sm text-red-400",
                                    children: a
                                })]
                            }), (0, q.jsx)(e1, {
                                type: "submit",
                                disabled: s,
                                className: "w-full h-11 bg-[#ff0000] hover:bg-[#cc0000] text-white font-medium transition-colors",
                                children: s ? "Signing in..." : "Sign In"
                            })]
                        })]
                    }), (0, q.jsx)("div", {
                        className: "px-8 py-4 border-t border-white/5 bg-black/60",
                        children: (0, q.jsx)("p", {
                            className: "text-center text-xs text-slate-400",
                            children: "Agentic AI Order-to-Cash Workspace"
                        })
                    })]
                }), (0, q.jsx)("p", {
                    className: "mt-6 text-center text-sm text-slate-400",
                    children: "Powered by TCS Manufacturing AI Axis on AWS"
                })]
            })
        }), (0, q.jsxs)("div", {
            className: "hidden md:block relative w-[70%] min-h-screen",
            children: [(0, q.jsx)(AD.default, {
                src: "/images/logistics-bg.jpg",
                alt: "Futuristic warehouse with AI automation",
                fill: !0,
                className: "object-cover",
                priority: !0
            }), (0, q.jsx)("div", {
                className: "absolute inset-0 bg-gradient-to-r from-black via-black/60 to-transparent"
            })]
        })]
    })
}
let