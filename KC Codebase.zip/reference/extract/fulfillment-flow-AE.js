function AE({
    orderData: e,
    onBack: t,
    onComplete: r,
    orderId: n
}) {
    let [i, a] = (0, G.useState)(0), [o, s] = (0, G.useState)([]), [l, c] = (0, G.useState)([]), [u, d] = (0, G.useState)(!1), f = (0, G.useRef)(null), p = (0, G.useRef)(null), m = [{
        id: 0,
        name: "ATP Check",
        agent: "ATP Agent",
        icon: (0, q.jsx)(AS, {
            className: "h-5 w-5"
        }),
        status: "pending",
        details: ["Checking warehouse inventory for SKU-8472", "Available quantity: 1,500 units", "Reserved for order: 1,200 units", "Allocation confirmed"],
        systemIntegrations: ["SAP ERP - Warehouse Module", "Inventory Management System"]
    }, {
        id: 1,
        name: "Order Release",
        agent: "Order Management Agent",
        icon: (0, q.jsx)(aa, {
            className: "h-5 w-5"
        }),
        status: "pending",
        details: ["Release order SO-710245 from credit hold", "Update order status to 'Released'", "Generate picking list", "Send to warehouse fulfillment queue"],
        systemIntegrations: ["SAP SD Module", "Order Management System"]
    }, {
        id: 2,
        name: "Shipment Planning",
        agent: "Logistics Agent",
        icon: (0, q.jsx)(AP, {
            className: "h-5 w-5"
        }),
        status: "pending",
        details: ["Calculate optimal shipping route", "Schedule carrier: FedEx Ground", "Estimated delivery: 3-5 business days", "Create shipment document"],
        systemIntegrations: ["TMS - Transportation Management", "Carrier Integration API"]
    }, {
        id: 3,
        name: "Documentation",
        agent: "Document Agent",
        icon: (0, q.jsx)(aw, {
            className: "h-5 w-5"
        }),
        status: "pending",
        details: ["Generate commercial invoice", "Create packing list", "Prepare shipping labels", "Send documents to customer portal"],
        systemIntegrations: ["Document Management System", "Customer Portal API"]
    }, {
        id: 4,
        name: "Payment Setup",
        agent: "Dunning Agent",
        icon: (0, q.jsx)(au, {
            className: "h-5 w-5"
        }),
        status: "pending",
        details: ["Set up proactive payment reminders", "Schedule early nudges (T-7, T-3, T-1)", "Configure promise-to-pay capture", "Activate monitoring for on-time payment"],
        systemIntegrations: ["Payment Gateway", "Dunning Platform", "Email Service"]
    }], [h, g] = (0, G.useState)(m);
    (0, G.useEffect)(() => {
        p.current && (p.current.scrollTop = p.current.scrollHeight)
    }, [l]), (0, G.useEffect)(() => {
        f.current && (f.current.scrollTop = f.current.scrollHeight)
    }, [o]), (0, G.useEffect)(() => {
        if (i >= m.length) return void setTimeout(() => {
            d(!0);
            let e = {
                id: `audit-dunning-${Date.now()}`,
                timestamp: new Date().toISOString(),
                agent: "Proactive Dunning Agent",
                action: "Early Payment Nudge Strategy Activated",
                reasoning: "To keep future processing touchless and avoid new holds, customer will receive proactive reminders to pay on time. This prevents credit issues and maintains smooth order flow.",
                integration: "Dunning Platform + Email Service",
                status: "success"
            };
            c(t => [...t, e]), r && setTimeout(() => r(n), 2e3)
        }, 1e3);
        g(e => e.map((e, t) => ({
            ...e,
            status: t === i ? "running" : t < i ? "complete" : "pending"
        })));
        let e = {
            id: `audit-start-${i}-${Date.now()}`,
            timestamp: new Date().toISOString(),
            agent: m[i].agent,
            action: `Starting ${m[i].name}`,
            reasoning: `Initiating ${m[i].name} to progress order fulfillment`,
            integration: m[i].systemIntegrations[0],
            status: "running"
        };
        c(t => [...t, e]), setTimeout(() => {
            s(e => [...e, i])
        }, 500), m[i].details.forEach((e, t) => {
            setTimeout(() => {
                let r = {
                    id: `audit-detail-${i}-${t}-${Date.now()}`,
                    timestamp: new Date().toISOString(),
                    agent: m[i].agent,
                    action: e,
                    reasoning: `Executing step ${t+1} of ${m[i].name} process`,
                    integration: m[i].systemIntegrations[t % m[i].systemIntegrations.length],
                    status: "running"
                };
                c(e => [...e, r])
            }, 1e3 + 800 * t)
        }), setTimeout(() => {
            g(e => e.map((e, t) => ({
                ...e,
                status: t === i ? "complete" : e.status
            })));
            let e = {
                id: `audit-complete-${i}-${Date.now()}`,
                timestamp: new Date().toISOString(),
                agent: m[i].agent,
                action: `${m[i].name} Completed Successfully`,
                reasoning: "All checks passed. Order progressing to next stage.",
                status: "success"
            };
            c(t => [...t, e]), a(e => e + 1)
        }, 1e3 + 800 * m[i].details.length + 500)
    }, [i]);
    let v = (i + 1) / m.length * 100;
    return (0, q.jsxs)("div", {
        className: "min-h-screen bg-background",
        children: [(0, q.jsx)("div", {
            className: "bg-card border-b sticky top-0 z-10",
            children: (0, q.jsxs)("div", {
                className: "px-6 py-4",
                children: [(0, q.jsxs)("div", {
                    className: "flex items-center justify-between mb-3",
                    children: [(0, q.jsxs)(e1, {
                        variant: "ghost",
                        size: "sm",
                        onClick: t,
                        className: "gap-2",
                        children: [(0, q.jsx)(Ak, {
                            className: "h-4 w-4"
                        }), "Back to Dashboard"]
                    }), (0, q.jsxs)(ar, {
                        variant: "secondary",
                        className: "gap-1",
                        children: [(0, q.jsx)(EQ, {
                            className: "h-3 w-3"
                        }), "Started ", new Date().toLocaleTimeString()]
                    })]
                }), (0, q.jsxs)("div", {
                    className: "space-y-3",
                    children: [(0, q.jsxs)("div", {
                        children: [(0, q.jsx)("h1", {
                            className: "text-lg font-bold text-foreground",
                            children: "Fulfillment Progress"
                        }), (0, q.jsx)("p", {
                            className: "text-sm text-muted-foreground",
                            children: "Order SO-710245 - ABC Traders"
                        })]
                    }), (0, q.jsxs)("div", {
                        className: "grid grid-cols-4 gap-4",
                        children: [(0, q.jsxs)("div", {
                            className: "bg-muted/30 rounded-lg p-3",
                            children: [(0, q.jsx)("div", {
                                className: "text-xs text-muted-foreground mb-1",
                                children: "Order Value"
                            }), (0, q.jsx)("div", {
                                className: "text-sm font-semibold",
                                children: "$125,000"
                            })]
                        }), (0, q.jsxs)("div", {
                            className: "bg-muted/30 rounded-lg p-3",
                            children: [(0, q.jsx)("div", {
                                className: "text-xs text-muted-foreground mb-1",
                                children: "Decision"
                            }), (0, q.jsx)("div", {
                                className: "text-sm font-semibold text-green-600",
                                children: "Conditional Release (20% prepay)"
                            })]
                        }), (0, q.jsxs)("div", {
                            className: "bg-muted/30 rounded-lg p-3",
                            children: [(0, q.jsx)("div", {
                                className: "text-xs text-muted-foreground mb-1",
                                children: "Credit Manager"
                            }), (0, q.jsx)("div", {
                                className: "text-sm font-semibold",
                                children: "Approved"
                            })]
                        }), (0, q.jsxs)("div", {
                            className: "bg-muted/30 rounded-lg p-3",
                            children: [(0, q.jsx)("div", {
                                className: "text-xs text-muted-foreground mb-1",
                                children: "Status"
                            }), (0, q.jsx)("div", {
                                className: "text-sm font-semibold text-blue-600",
                                children: "Processing"
                            })]
                        })]
                    }), (0, q.jsxs)("div", {
                        children: [(0, q.jsxs)("div", {
                            className: "flex justify-between text-xs text-muted-foreground mb-2",
                            children: [(0, q.jsx)("span", {
                                children: "Overall Progress"
                            }), (0, q.jsxs)("span", {
                                children: [Math.round(v), "%"]
                            })]
                        }), (0, q.jsx)(Ay, {
                            value: v,
                            className: "h-2"
                        })]
                    })]
                })]
            })
        }), (0, q.jsxs)("div", {
            className: "flex h-[calc(100vh-280px)]",
            children: [(0, q.jsxs)("div", {
                className: "flex-1 p-6 flex flex-col min-w-0",
                children: [(0, q.jsx)("div", {
                    className: "mb-6 bg-card rounded-lg border p-4",
                    children: (0, q.jsx)("div", {
                        className: "flex items-center justify-between gap-2",
                        children: h.map((e, t) => (0, q.jsxs)("div", {
                            className: "flex items-center flex-1",
                            children: [(0, q.jsxs)("div", {
                                className: "flex flex-col items-center gap-2",
                                children: [(0, q.jsx)("div", {
                                    className: eJ("w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all", "complete" === e.status && "bg-green-500 border-green-500 text-white", "running" === e.status && "bg-blue-500 border-blue-500 text-white animate-pulse", "pending" === e.status && "bg-muted border-muted-foreground/20 text-muted-foreground"),
                                    children: "complete" === e.status ? (0, q.jsx)(aB, {
                                        className: "h-5 w-5"
                                    }) : e.icon
                                }), (0, q.jsxs)("div", {
                                    className: "text-center",
                                    children: [(0, q.jsx)("div", {
                                        className: "text-xs font-medium whitespace-nowrap",
                                        children: e.name
                                    }), (0, q.jsx)("div", {
                                        className: "text-xs text-muted-foreground",
                                        children: e.agent
                                    })]
                                })]
                            }), t < h.length - 1 && (0, q.jsx)("div", {
                                className: eJ("flex-1 h-0.5 mx-2 transition-all", "complete" === e.status ? "bg-green-500" : "bg-muted")
                            })]
                        }, e.id))
                    })
                }), (0, q.jsxs)("div", {
                    ref: f,
                    className: "flex-1 overflow-y-auto space-y-4 min-h-0",
                    children: [o.map(e => (0, q.jsxs)(ap, {
                        className: eJ("animate-in fade-in slide-in-from-bottom-4 duration-500", "border-l-4 border-l-blue-500"),
                        children: [(0, q.jsx)(am, {
                            children: (0, q.jsxs)("div", {
                                className: "flex items-start justify-between",
                                children: [(0, q.jsxs)("div", {
                                    className: "flex items-center gap-3",
                                    children: [(0, q.jsx)("div", {
                                        className: "w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center",
                                        children: h[e].icon
                                    }), (0, q.jsxs)("div", {
                                        children: [(0, q.jsx)(ah, {
                                            className: "text-base",
                                            children: h[e].name
                                        }), (0, q.jsx)(ag, {
                                            className: "text-xs",
                                            children: h[e].agent
                                        })]
                                    })]
                                }), "complete" === h[e].status && (0, q.jsxs)(ar, {
                                    variant: "secondary",
                                    className: "bg-green-100 text-green-700",
                                    children: [(0, q.jsx)(aB, {
                                        className: "h-3 w-3 mr-1"
                                    }), "Complete"]
                                }), "running" === h[e].status && (0, q.jsxs)(ar, {
                                    variant: "secondary",
                                    className: "bg-blue-100 text-blue-700",
                                    children: [(0, q.jsx)(EQ, {
                                        className: "h-3 w-3 mr-1"
                                    }), "Running"]
                                })]
                            })
                        }), (0, q.jsxs)(av, {
                            className: "space-y-3",
                            children: [(0, q.jsx)("div", {
                                className: "grid grid-cols-2 gap-x-4 gap-y-2",
                                children: h[e].details.map((e, t) => (0, q.jsxs)("div", {
                                    className: "flex items-start gap-2 text-sm",
                                    children: [(0, q.jsx)(aB, {
                                        className: "h-4 w-4 text-green-500 shrink-0 mt-0.5"
                                    }), (0, q.jsx)("span", {
                                        className: "text-muted-foreground",
                                        children: e
                                    })]
                                }, t))
                            }), (0, q.jsxs)("div", {
                                className: "pt-3 border-t",
                                children: [(0, q.jsx)("div", {
                                    className: "text-xs font-medium text-muted-foreground mb-2",
                                    children: "System Integrations"
                                }), (0, q.jsx)("div", {
                                    className: "flex flex-wrap gap-2",
                                    children: h[e].systemIntegrations.map((e, t) => (0, q.jsxs)(ar, {
                                        variant: "outline",
                                        className: "text-xs",
                                        children: [(0, q.jsx)(aO, {
                                            className: "h-3 w-3 mr-1"
                                        }), e]
                                    }, t))
                                })]
                            })]
                        })]
                    }, e)), u && (0, q.jsxs)(ap, {
                        className: "animate-in fade-in slide-in-from-bottom-4 duration-500 border-l-4 border-l-orange-500",
                        children: [(0, q.jsx)(am, {
                            children: (0, q.jsxs)("div", {
                                className: "flex items-center gap-3",
                                children: [(0, q.jsx)("div", {
                                    className: "w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center",
                                    children: (0, q.jsx)(J, {
                                        className: "h-5 w-5 text-orange-600"
                                    })
                                }), (0, q.jsxs)("div", {
                                    children: [(0, q.jsx)(ah, {
                                        className: "text-base",
                                        children: "Proactive Dunning Strategy Activated"
                                    }), (0, q.jsx)(ag, {
                                        className: "text-xs",
                                        children: "Smart Payment Reminders"
                                    })]
                                })]
                            })
                        }), (0, q.jsxs)(av, {
                            className: "space-y-4",
                            children: [(0, q.jsx)("div", {
                                className: "bg-orange-50 border border-orange-200 rounded-lg p-4",
                                children: (0, q.jsxs)("div", {
                                    className: "flex items-start gap-3",
                                    children: [(0, q.jsx)(as, {
                                        className: "h-5 w-5 text-orange-600 shrink-0"
                                    }), (0, q.jsxs)("div", {
                                        children: [(0, q.jsx)("div", {
                                            className: "font-medium text-sm text-orange-900 mb-1",
                                            children: "Early Payment Nudge Message"
                                        }), (0, q.jsx)("p", {
                                            className: "text-sm text-orange-800",
                                            children: "To keep future processing touchless and avoid new holds, please ensure timely payment for this order. Our proactive system will send friendly reminders at key milestones to help you stay on track."
                                        })]
                                    })]
                                })
                            }), (0, q.jsxs)("div", {
                                className: "space-y-3",
                                children: [(0, q.jsx)("div", {
                                    className: "text-xs font-medium text-muted-foreground",
                                    children: "Scheduled Nudges"
                                }), (0, q.jsxs)("div", {
                                    className: "space-y-2",
                                    children: [(0, q.jsxs)("div", {
                                        className: "flex items-center gap-3 text-sm",
                                        children: [(0, q.jsx)(Ax, {
                                            className: "h-4 w-4 text-blue-500"
                                        }), (0, q.jsx)("span", {
                                            className: "flex-1",
                                            children: "Email reminder 7 days before due date"
                                        }), (0, q.jsx)(ar, {
                                            variant: "outline",
                                            className: "text-xs",
                                            children: "Scheduled"
                                        })]
                                    }), (0, q.jsxs)("div", {
                                        className: "flex items-center gap-3 text-sm",
                                        children: [(0, q.jsx)(al, {
                                            className: "h-4 w-4 text-green-500"
                                        }), (0, q.jsx)("span", {
                                            className: "flex-1",
                                            children: "SMS reminder 3 days before due date"
                                        }), (0, q.jsx)(ar, {
                                            variant: "outline",
                                            className: "text-xs",
                                            children: "Scheduled"
                                        })]
                                    }), (0, q.jsxs)("div", {
                                        className: "flex items-center gap-3 text-sm",
                                        children: [(0, q.jsx)(J, {
                                            className: "h-4 w-4 text-orange-500"
                                        }), (0, q.jsx)("span", {
                                            className: "flex-1",
                                            children: "Portal notification 1 day before due date"
                                        }), (0, q.jsx)(ar, {
                                            variant: "outline",
                                            className: "text-xs",
                                            children: "Scheduled"
                                        })]
                                    })]
                                })]
                            }), (0, q.jsxs)("div", {
                                className: "pt-3 border-t",
                                children: [(0, q.jsx)("div", {
                                    className: "text-xs font-medium text-muted-foreground mb-2",
                                    children: "Benefits"
                                }), (0, q.jsxs)("div", {
                                    className: "grid grid-cols-2 gap-2",
                                    children: [(0, q.jsxs)("div", {
                                        className: "bg-muted/30 rounded p-2",
                                        children: [(0, q.jsx)("div", {
                                            className: "text-xs text-muted-foreground",
                                            children: "Reduces Late Payments"
                                        }), (0, q.jsx)("div", {
                                            className: "text-sm font-semibold",
                                            children: "-35%"
                                        })]
                                    }), (0, q.jsxs)("div", {
                                        className: "bg-muted/30 rounded p-2",
                                        children: [(0, q.jsx)("div", {
                                            className: "text-xs text-muted-foreground",
                                            children: "Prevents Credit Holds"
                                        }), (0, q.jsx)("div", {
                                            className: "text-sm font-semibold",
                                            children: "-60%"
                                        })]
                                    })]
                                })]
                            })]
                        })]
                    })]
                })]
            }), (0, q.jsxs)("div", {
                className: "w-96 border-l bg-muted/10 flex flex-col",
                children: [(0, q.jsxs)("div", {
                    className: "p-4 border-b bg-card",
                    children: [(0, q.jsx)("h3", {
                        className: "font-semibold text-sm",
                        children: "AI Agent Audit Trail"
                    }), (0, q.jsx)("p", {
                        className: "text-xs text-muted-foreground mt-1",
                        children: "Real-time reasoning and actions"
                    })]
                }), (0, q.jsx)("div", {
                    ref: p,
                    className: "flex-1 overflow-y-auto p-4 space-y-3 min-h-0",
                    children: l.map(e => (0, q.jsxs)("div", {
                        className: eJ("bg-card rounded-lg p-3 border-l-2 animate-in fade-in slide-in-from-right-2 duration-300", "success" === e.status && "border-l-green-500", "running" === e.status && "border-l-blue-500", "pending" === e.status && "border-l-gray-300"),
                        children: [(0, q.jsxs)("div", {
                            className: "flex items-start justify-between gap-2 mb-2",
                            children: [(0, q.jsxs)("div", {
                                className: "flex items-center gap-2",
                                children: [(0, q.jsx)(EL, {
                                    className: "h-4 w-4 text-blue-600"
                                }), (0, q.jsx)("span", {
                                    className: "text-xs font-medium",
                                    children: e.agent
                                })]
                            }), (0, q.jsx)("span", {
                                className: "text-xs text-muted-foreground",
                                children: new Date(e.timestamp).toLocaleTimeString()
                            })]
                        }), (0, q.jsx)("div", {
                            className: "text-xs font-medium mb-1",
                            children: e.action
                        }), (0, q.jsx)("div", {
                            className: "text-xs text-muted-foreground mb-2",
                            children: e.reasoning
                        }), e.integration && (0, q.jsxs)(ar, {
                            variant: "outline",
                            className: "text-xs",
                            children: [(0, q.jsx)(aO, {
                                className: "h-3 w-3 mr-1"
                            }), e.integration]
                        })]
                    }, e.id))
                })]
            })]
        })]
    })
}