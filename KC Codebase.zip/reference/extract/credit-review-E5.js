function E5({
    onNavigateToFulfillment: e,
    focusOrderId: t,
    onBack: r
}) {
    let [n, i] = (0, G.useState)({}), [a, o] = (0, G.useState)({}), s = aA.filter(e => "Hold" === e.status), l = {
        orderId: "SO-710248",
        customerName: "TechCorp Industries",
        totalValue: 185e3,
        status: "Hold",
        loopOrderFlag: !0,
        orderDate: "2024-02-10",
        holdReason: "Credit Limit Exceeded",
        lineItems: [{
            orderLineId: "LN-9012",
            sku: "SKU-9012",
            productName: "Industrial Components",
            qty: 300,
            unitPrice: 450,
            lineValue: 135e3,
            loopLineFlag: !1,
            priceValidated: !0
        }, {
            orderLineId: "LN-3456",
            sku: "SKU-3456",
            productName: "Assembly Parts",
            qty: 100,
            unitPrice: 500,
            lineValue: 5e4,
            loopLineFlag: !0,
            priceValidated: !0
        }]
    }, c = t ? [...s, l].filter(e => e.orderId === t) : [...s, l], u = {
        orderId: "SO-710248",
        riskScore: .58,
        ltvScore: .71,
        propensityScore: .64,
        options: [{
            id: "split",
            name: "Split Shipment Release",
            type: "Balanced",
            confidence: .82,
            conditions: ["Release 50% now", "Balance on payment", "Insurance required"],
            riskDelta: -.15,
            ltvImpact: .08,
            cashFlowEffect: 92500
        }, {
            id: "conditional",
            name: "Full Conditional Release",
            type: "Aggressive",
            confidence: .76,
            conditions: ["30-day payment plan", "COD on future orders"],
            riskDelta: .08,
            ltvImpact: .12,
            cashFlowEffect: 185e3
        }, {
            id: "hold",
            name: "Maintain Hold",
            type: "Conservative",
            confidence: .89,
            conditions: ["Payment upfront", "No release"],
            riskDelta: -.25,
            ltvImpact: -.18,
            cashFlowEffect: 0
        }],
        guardrailsApplied: ["Credit Limit Check", "Payment History Review", "Industry Risk Assessment"]
    };
    return (0, q.jsxs)("div", {
        className: "space-y-6 pb-8",
        children: [(0, q.jsxs)("div", {
            className: "flex items-center justify-between",
            children: [(0, q.jsxs)("div", {
                className: "flex items-center gap-3",
                children: [r && (0, q.jsxs)(e1, {
                    variant: "outline",
                    size: "sm",
                    onClick: r,
                    className: "gap-1.5",
                    children: [(0, q.jsx)(EY, {
                        className: "h-4 w-4 rotate-180"
                    }), "Back to Exceptions"]
                }), (0, q.jsxs)("div", {
                    children: [(0, q.jsx)("h1", {
                        className: "text-lg font-bold text-foreground",
                        children: "Review Order Hold"
                    }), (0, q.jsx)("p", {
                        className: "text-muted-foreground",
                        children: t ? `Reviewing credit hold for ${t} — select a release option to proceed` : "Review and approve AI-recommended decisions for credit holds"
                    })]
                })]
            }), (0, q.jsx)("div", {
                className: "flex items-center gap-2",
                children: (0, q.jsxs)(ar, {
                    variant: "outline",
                    className: "gap-1",
                    children: [(0, q.jsx)(a$, {
                        type: "credit",
                        size: "sm"
                    }), c.filter(e => !n[e.orderId]).length, " Pending Review"]
                })
            })]
        }), (0, q.jsxs)("div", {
            className: "grid lg:grid-cols-3 gap-6",
            children: [(0, q.jsx)("div", {
                className: "lg:col-span-2 space-y-6",
                children: c.map((t, r) => {
                    let s = "SO-710248" === t.orderId ? u : aI,
                        l = n[t.orderId];
                    return (0, q.jsxs)("div", {
                        className: "space-y-6",
                        children: [!l && (0, q.jsx)(ap, {
                            className: "border-primary/50 bg-primary/5",
                            children: (0, q.jsx)(av, {
                                className: "p-4",
                                children: (0, q.jsxs)("div", {
                                    className: "flex items-center gap-3",
                                    children: [(0, q.jsx)("div", {
                                        className: "h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0",
                                        children: (0, q.jsx)(EX, {
                                            className: "h-5 w-5 text-primary"
                                        })
                                    }), (0, q.jsxs)("div", {
                                        className: "flex-1 min-w-0",
                                        children: [(0, q.jsx)("div", {
                                            className: "font-semibold text-foreground",
                                            children: "Credit Hold Detected"
                                        }), (0, q.jsxs)("div", {
                                            className: "text-sm text-muted-foreground",
                                            children: ["Order ", t.orderId, " requires approval. AI agents have curated decision options."]
                                        })]
                                    }), (0, q.jsxs)(ar, {
                                        className: "bg-primary text-primary-foreground gap-1 flex-shrink-0",
                                        children: [(0, q.jsx)(aF, {
                                            size: "sm"
                                        }), "Action Required"]
                                    })]
                                })
                            })
                        }), l && (0, q.jsx)(ap, {
                            className: "border-[var(--success)]/50 bg-[var(--success)]/5",
                            children: (0, q.jsxs)(av, {
                                className: "p-4",
                                children: [(0, q.jsxs)("div", {
                                    className: "flex items-center gap-3 mb-4",
                                    children: [(0, q.jsx)("div", {
                                        className: "h-10 w-10 rounded-full bg-[var(--success)]/10 flex items-center justify-center flex-shrink-0",
                                        children: (0, q.jsx)(aB, {
                                            className: "h-5 w-5 text-[var(--success)]"
                                        })
                                    }), (0, q.jsxs)("div", {
                                        className: "flex-1 min-w-0",
                                        children: [(0, q.jsx)("div", {
                                            className: "font-semibold text-foreground",
                                            children: "Order Released Successfully"
                                        }), (0, q.jsxs)("div", {
                                            className: "text-sm text-muted-foreground",
                                            children: ["Decision approved: ", a[t.orderId], ". Ready to proceed with fulfillment."]
                                        })]
                                    }), (0, q.jsx)(ar, {
                                        className: "bg-[var(--success)] text-white flex-shrink-0",
                                        children: "Released"
                                    })]
                                }), e && (0, q.jsxs)(e1, {
                                    onClick: () => e(t.orderId),
                                    className: "w-full bg-[var(--success)] hover:bg-[var(--success)]/90",
                                    size: "lg",
                                    children: ["View Fulfillment Progress", (0, q.jsx)(EY, {
                                        className: "h-4 w-4 ml-2"
                                    })]
                                })]
                            })
                        }), (0, q.jsx)(E2, {
                            order: {
                                ...t,
                                status: l ? "Released" : t.status
                            },
                            isExpanded: !0
                        }), !l && (0, q.jsx)(EZ, {
                            decision: s,
                            onApprove: e => {
                                var r;
                                return r = t.orderId, void(i({
                                    ...n,
                                    [r]: !0
                                }), o({
                                    ...a,
                                    [r]: e
                                }))
                            }
                        }), r < c.length - 1 && (0, q.jsx)("div", {
                            className: "border-t pt-6"
                        })]
                    }, t.orderId)
                })
            }), (0, q.jsx)("div", {
                className: "space-y-6",
                children: (0, q.jsx)(Eq, {
                    activities: a_
                })
            })]
        })]
    })
}

function E3({
    className: e,
    ...t
}) {
    return (0, q.jsx)("div", {
        "data-slot": "table-container",
        className: "relative w-full overflow-x-auto",
        children: (0, q.jsx)("table", {
            "data-slot": "table",
            className: eJ("w-full caption-bottom text-sm", e),
            ...t
        })
    })
}

function E4({
    className: e,
    ...t
}) {
    return (0, q.jsx)("thead", {
        "data-slot": "table-header",
        className: eJ("[&_tr]:border-b", e),
        ...t
    })
}

function E8({
    className: e,
    ...t
}) {
    return (0, q.jsx)("tbody", {
        "data-slot": "table-body",
        className: eJ("[&_tr:last-child]:border-0", e),
        ...t
    })
}

function E6({
    className: e,
    ...t
}) {
    return (0, q.jsx)("tr", {
        "data-slot": "table-row",
        className: eJ("hover:bg-muted/50 data-[state=selected]:bg-muted border-b transition-colors", e),
        ...t
    })
}

function E7({
    className: e,
    ...t
}) {
    return (0, q.jsx)("th", {
        "data-slot": "table-head",
        className: eJ("text-foreground h-10 px-2 text-left align-middle font-medium whitespace-nowrap [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]", e),
        ...t
    })
}

function E9({
    className: e,
    ...t
}) {
    return (0, q.jsx)("td", {
        "data-slot": "table-cell",
        className: eJ("p-2 align-middle whitespace-nowrap [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]", e),
        ...t
    })
}
let Ae = Q("Filter", [
        ["polygon", {
            points: "22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3",
            key: "1yg77f"
        }]
    ]),
    At = Q("Download", [
        ["path", {
            d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",
            key: "ih7n3h"
        }],
        ["polyline", {
            points: "7 10 12 15 17 10",
            key: "2ggqvy"
        }],
        ["line", {
            x1: "12",
            x2: "12",
            y1: "15",
            y2: "3",
            key: "1vk2je"
        }]
    ]),
    Ar = Q("Eye", [
        ["path", {
            d: "M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",
            key: "1nclc0"
        }],
        ["circle", {
            cx: "12",
            cy: "12",
            r: "3",
            key: "1v7zrd"
        }]
    ]);