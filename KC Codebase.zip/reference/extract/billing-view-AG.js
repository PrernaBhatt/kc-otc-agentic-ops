function AG() {
    let [e, t] = (0, G.useState)(""), [r, n] = (0, G.useState)(Aq), [i, a] = (0, G.useState)(null), [o, s] = (0, G.useState)(0), [l, c] = (0, G.useState)([]), [u, d] = (0, G.useState)({
        open: !1,
        messages: [],
        input: ""
    }), f = (0, G.useRef)(null), p = (0, G.useRef)(null);
    (0, G.useEffect)(() => {
        f.current && (f.current.scrollTop = f.current.scrollHeight)
    }, [l]), (0, G.useEffect)(() => {
        p.current && p.current.scrollIntoView({
            behavior: "smooth"
        })
    }, [u.messages]);
    let m = () => {
            let e = u.input.trim();
            if (!e) return;
            let t = [...u.messages, {
                role: "user",
                text: e
            }];
            d(e => ({
                ...e,
                messages: t,
                input: ""
            }));
            let n = e.toLowerCase();
            setTimeout(() => {
                let t = "",
                    a = !1,
                    s = AW[o]?.label || "unknown";
                if (n.includes("approve") || n.includes("confirm") || n.includes("proceed")) t = `Billing for ${i?.orderId||"this order"} has been approved. Continuing pipeline.`, a = !0;
                else if (n.includes("status") || n.includes("where") || n.includes("stage")) t = `${i?.orderId||"Order"} is currently at: ${s} (step ${o+1} of ${AW.length}).`;
                else if (n.match(/so-\d+/i)) {
                    let n = e.match(/SO-\d+/i),
                        i = n ? n[0].toUpperCase() : "",
                        a = r.find(e => e.orderId === i);
                    t = a ? `${i} is at billing stage: ${a.status}.` : `${i} is not in the billing pipeline.`
                } else t = `Billing agent monitoring ${i?.orderId||"this order"}. Current stage: ${s}. Type 'approve' to confirm or ask about a specific order.`;
                d(e => ({
                    ...e,
                    messages: [...e.messages, {
                        role: "agent",
                        text: t,
                        isApproval: a
                    }]
                }))
            }, 600)
        },
        h = e => AW.findIndex(t => t.id === e),
        g = (e, t = "info") => {
            c(r => [...r, {
                timestamp: new Date().toISOString(),
                message: e,
                type: t
            }])
        };
    return ((0, G.useEffect)(() => {
        i && (async () => {
            if (o >= AW.length - 1) {
                g("Billing process completed successfully", "success"), setTimeout(() => {
                    n(e => e.map(e => e.billingId === i.billingId ? {
                        ...e,
                        status: "completed"
                    } : e)), a(null), t("")
                }, 2e3);
                return
            }
            await new Promise(e => setTimeout(e, 3e3));
            let e = AW[o + 1],
                r = {
                    ...i,
                    status: e.id
                };
            switch (e.id) {
                case "delivery_validation":
                    r.deliveryValidated = !0, g("Report Extraction Agent: Delivery validated against SO", "success");
                    break;
                case "po_validation":
                    r.poValidated = !0, g("PO Validation Agent: All PO conditions met", "success");
                    break;
                case "contract_validation":
                    r.contractValidated = !0, g("Contract Validation Agent: Pricing and terms verified", "success");
                    break;
                case "document_check":
                    r.documentsComplete = !0, g("Document Extraction Agent: All critical documents available", "success");
                    break;
                case "billing_generation":
                    r.invoiceGenerated = !0, g("Billing Generation Agent: Invoice created successfully", "success");
                    break;
                case "invoice_delivery":
                    r.invoiceDelivered = !0, g("Invoice Delivery Agent: Invoice delivered via preferred channel", "success")
            }
            a(r), n(e => e.map(e => e.billingId === r.billingId ? r : e)), s(e => e + 1)
        })()
    }, [o, i]), e && i) ? (0, q.jsxs)("div", {
        className: "space-y-4",
        children: [(0, q.jsxs)("div", {
            className: "flex items-center justify-between",
            children: [(0, q.jsxs)(e1, {
                variant: "outline",
                size: "sm",
                onClick: () => {
                    t(""), a(null)
                },
                className: "gap-1.5",
                children: [(0, q.jsx)(Ak, {
                    className: "h-4 w-4"
                }), " Back to Pipeline"]
            }), (0, q.jsxs)("div", {
                className: "flex items-center gap-3",
                children: [(0, q.jsx)("span", {
                    className: "font-semibold text-base",
                    children: i.orderId
                }), (0, q.jsxs)("span", {
                    className: "text-sm text-muted-foreground",
                    children: [i.customerName, " · $", i.amount.toLocaleString()]
                })]
            })]
        }), (0, q.jsxs)(ap, {
            className: "p-4",
            children: [(0, q.jsx)("div", {
                className: "flex items-center justify-between mb-3",
                children: AW.map((e, t) => {
                    let r = e.icon,
                        n = t === o,
                        i = t < o,
                        a = t > o;
                    return (0, q.jsxs)("div", {
                        className: "flex items-center flex-1",
                        children: [(0, q.jsxs)("div", {
                            className: "flex flex-col items-center gap-2",
                            children: [(0, q.jsx)("div", {
                                className: ["w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all", i ? "bg-green-500 border-green-500 text-white" : "", n ? "bg-blue-500 border-blue-500 text-white animate-pulse" : "", a ? "bg-gray-200 border-gray-300 text-gray-500" : ""].join(" "),
                                children: n ? (0, q.jsx)(EB, {
                                    className: "w-5 h-5 animate-spin"
                                }) : (0, q.jsx)(r, {
                                    className: "w-5 h-5"
                                })
                            }), (0, q.jsx)("span", {
                                className: ["text-xs font-medium text-center max-w-[80px]", n ? "text-blue-600" : i ? "text-green-600" : "text-gray-500"].join(" "),
                                children: e.label
                            })]
                        }), t < AW.length - 1 && (0, q.jsx)("div", {
                            className: ["flex-1 h-0.5 mx-2", i ? "bg-green-500" : "bg-gray-300"].join(" ")
                        })]
                    }, e.id)
                })
            }), (0, q.jsx)(Ay, {
                value: o / (AW.length - 1) * 100,
                className: "h-2"
            })]
        }), (0, q.jsxs)("div", {
            className: "grid lg:grid-cols-3 gap-4",
            children: [(0, q.jsxs)("div", {
                className: "lg:col-span-2 space-y-4",
                children: [o >= 1 && (0, q.jsx)(ap, {
                    className: "p-6",
                    children: (0, q.jsxs)("div", {
                        className: "flex items-start gap-4",
                        children: [(0, q.jsx)(a$, {
                            type: "extraction",
                            size: "lg"
                        }), (0, q.jsxs)("div", {
                            className: "flex-1",
                            children: [(0, q.jsxs)("div", {
                                className: "flex items-center justify-between mb-3",
                                children: [(0, q.jsx)("h3", {
                                    className: "font-semibold text-foreground",
                                    children: "Report Extraction Agent"
                                }), i.deliveryValidated ? (0, q.jsxs)(ar, {
                                    variant: "outline",
                                    className: "bg-green-50 text-green-700 border-green-300",
                                    children: [(0, q.jsx)(aB, {
                                        className: "w-3 h-3 mr-1"
                                    }), "Passed"]
                                }) : (0, q.jsxs)(ar, {
                                    variant: "outline",
                                    className: "bg-blue-50 text-blue-700 border-blue-300",
                                    children: [(0, q.jsx)(EB, {
                                        className: "w-3 h-3 mr-1 animate-spin"
                                    }), "Running"]
                                })]
                            }), (0, q.jsxs)("div", {
                                className: "space-y-2 text-sm",
                                children: [(0, q.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [(0, q.jsx)(aB, {
                                        className: "w-4 h-4 text-green-600"
                                    }), (0, q.jsx)("span", {
                                        children: "Proof of Delivery extracted"
                                    })]
                                }), (0, q.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [(0, q.jsx)(aB, {
                                        className: "w-4 h-4 text-green-600"
                                    }), (0, q.jsx)("span", {
                                        children: "SO vs Delivered Order matched"
                                    })]
                                }), (0, q.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [(0, q.jsx)(aB, {
                                        className: "w-4 h-4 text-green-600"
                                    }), (0, q.jsx)("span", {
                                        children: "Product codes and quantities validated"
                                    })]
                                })]
                            })]
                        })]
                    })
                }), o >= 2 && (0, q.jsx)(ap, {
                    className: "p-6",
                    children: (0, q.jsxs)("div", {
                        className: "flex items-start gap-4",
                        children: [(0, q.jsx)(a$, {
                            type: "po",
                            size: "lg"
                        }), (0, q.jsxs)("div", {
                            className: "flex-1",
                            children: [(0, q.jsxs)("div", {
                                className: "flex items-center justify-between mb-3",
                                children: [(0, q.jsx)("h3", {
                                    className: "font-semibold text-foreground",
                                    children: "PO Validation Agent"
                                }), i.poValidated ? (0, q.jsxs)(ar, {
                                    variant: "outline",
                                    className: "bg-green-50 text-green-700 border-green-300",
                                    children: [(0, q.jsx)(aB, {
                                        className: "w-3 h-3 mr-1"
                                    }), "Passed"]
                                }) : (0, q.jsxs)(ar, {
                                    variant: "outline",
                                    className: "bg-blue-50 text-blue-700 border-blue-300",
                                    children: [(0, q.jsx)(EB, {
                                        className: "w-3 h-3 mr-1 animate-spin"
                                    }), "Running"]
                                })]
                            }), (0, q.jsxs)("div", {
                                className: "grid grid-cols-2 gap-2 text-sm",
                                children: [(0, q.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [(0, q.jsx)(aB, {
                                        className: "w-4 h-4 text-green-600"
                                    }), (0, q.jsx)("span", {
                                        children: "Customer details verified"
                                    })]
                                }), (0, q.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [(0, q.jsx)(aB, {
                                        className: "w-4 h-4 text-green-600"
                                    }), (0, q.jsx)("span", {
                                        children: "Bill-to / Ship-to validated"
                                    })]
                                }), (0, q.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [(0, q.jsx)(aB, {
                                        className: "w-4 h-4 text-green-600"
                                    }), (0, q.jsx)("span", {
                                        children: "Product inclusion checked"
                                    })]
                                }), (0, q.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [(0, q.jsx)(aB, {
                                        className: "w-4 h-4 text-green-600"
                                    }), (0, q.jsx)("span", {
                                        children: "Quantity and unit price matched"
                                    })]
                                }), (0, q.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [(0, q.jsx)(aB, {
                                        className: "w-4 h-4 text-green-600"
                                    }), (0, q.jsx)("span", {
                                        children: "Tax % validated"
                                    })]
                                }), (0, q.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [(0, q.jsx)(aB, {
                                        className: "w-4 h-4 text-green-600"
                                    }), (0, q.jsx)("span", {
                                        children: "Payment terms confirmed"
                                    })]
                                })]
                            })]
                        })]
                    })
                }), o >= 3 && (0, q.jsx)(ap, {
                    className: "p-6",
                    children: (0, q.jsxs)("div", {
                        className: "flex items-start gap-4",
                        children: [(0, q.jsx)(a$, {
                            type: "contract",
                            size: "lg"
                        }), (0, q.jsxs)("div", {
                            className: "flex-1",
                            children: [(0, q.jsxs)("div", {
                                className: "flex items-center justify-between mb-3",
                                children: [(0, q.jsx)("h3", {
                                    className: "font-semibold text-foreground",
                                    children: "Contract Validation Agent"
                                }), i.contractValidated ? (0, q.jsxs)(ar, {
                                    variant: "outline",
                                    className: "bg-green-50 text-green-700 border-green-300",
                                    children: [(0, q.jsx)(aB, {
                                        className: "w-3 h-3 mr-1"
                                    }), "Passed"]
                                }) : (0, q.jsxs)(ar, {
                                    variant: "outline",
                                    className: "bg-blue-50 text-blue-700 border-blue-300",
                                    children: [(0, q.jsx)(EB, {
                                        className: "w-3 h-3 mr-1 animate-spin"
                                    }), "Running"]
                                })]
                            }), (0, q.jsxs)("div", {
                                className: "space-y-2 text-sm",
                                children: [(0, q.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [(0, q.jsx)(aB, {
                                        className: "w-4 h-4 text-green-600"
                                    }), (0, q.jsx)("span", {
                                        children: "Pricing elements validated"
                                    })]
                                }), (0, q.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [(0, q.jsx)(aB, {
                                        className: "w-4 h-4 text-green-600"
                                    }), (0, q.jsx)("span", {
                                        children: "Discounts applied (promotions, rebates)"
                                    })]
                                }), (0, q.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [(0, q.jsx)(aB, {
                                        className: "w-4 h-4 text-green-600"
                                    }), (0, q.jsx)("span", {
                                        children: "Contract validity confirmed"
                                    })]
                                }), (0, q.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [(0, q.jsx)(aB, {
                                        className: "w-4 h-4 text-green-600"
                                    }), (0, q.jsx)("span", {
                                        children: "SO rates match contract terms"
                                    })]
                                })]
                            })]
                        })]
                    })
                }), o >= 4 && (0, q.jsx)(ap, {
                    className: "p-6",
                    children: (0, q.jsxs)("div", {
                        className: "flex items-start gap-4",
                        children: [(0, q.jsx)(a$, {
                            type: "document",
                            size: "lg"
                        }), (0, q.jsxs)("div", {
                            className: "flex-1",
                            children: [(0, q.jsxs)("div", {
                                className: "flex items-center justify-between mb-3",
                                children: [(0, q.jsx)("h3", {
                                    className: "font-semibold text-foreground",
                                    children: "Document Extraction Agent"
                                }), i.documentsComplete ? (0, q.jsxs)(ar, {
                                    variant: "outline",
                                    className: "bg-green-50 text-green-700 border-green-300",
                                    children: [(0, q.jsx)(aB, {
                                        className: "w-3 h-3 mr-1"
                                    }), "Complete"]
                                }) : (0, q.jsxs)(ar, {
                                    variant: "outline",
                                    className: "bg-blue-50 text-blue-700 border-blue-300",
                                    children: [(0, q.jsx)(EB, {
                                        className: "w-3 h-3 mr-1 animate-spin"
                                    }), "Checking"]
                                })]
                            }), (0, q.jsxs)("div", {
                                className: "space-y-2 text-sm",
                                children: [(0, q.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [(0, q.jsx)(aB, {
                                        className: "w-4 h-4 text-green-600"
                                    }), (0, q.jsx)("span", {
                                        children: "Purchase Order"
                                    })]
                                }), (0, q.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [(0, q.jsx)(aB, {
                                        className: "w-4 h-4 text-green-600"
                                    }), (0, q.jsx)("span", {
                                        children: "Proof of Delivery"
                                    })]
                                }), (0, q.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [(0, q.jsx)(aB, {
                                        className: "w-4 h-4 text-green-600"
                                    }), (0, q.jsx)("span", {
                                        children: "Exception Approvals"
                                    })]
                                })]
                            })]
                        })]
                    })
                }), o >= 5 && (0, q.jsx)(ap, {
                    className: "p-6",
                    children: (0, q.jsxs)("div", {
                        className: "flex items-start gap-4",
                        children: [(0, q.jsx)(a$, {
                            type: "invoice",
                            size: "lg"
                        }), (0, q.jsxs)("div", {
                            className: "flex-1",
                            children: [(0, q.jsxs)("div", {
                                className: "flex items-center justify-between mb-3",
                                children: [(0, q.jsx)("h3", {
                                    className: "font-semibold text-foreground",
                                    children: "Billing Generation Agent"
                                }), i.invoiceGenerated ? (0, q.jsxs)(ar, {
                                    variant: "outline",
                                    className: "bg-green-50 text-green-700 border-green-300",
                                    children: [(0, q.jsx)(aB, {
                                        className: "w-3 h-3 mr-1"
                                    }), "Generated"]
                                }) : (0, q.jsxs)(ar, {
                                    variant: "outline",
                                    className: "bg-blue-50 text-blue-700 border-blue-300",
                                    children: [(0, q.jsx)(EB, {
                                        className: "w-3 h-3 mr-1 animate-spin"
                                    }), "Generating"]
                                })]
                            }), (0, q.jsx)("div", {
                                className: "space-y-3 text-sm",
                                children: (0, q.jsxs)("div", {
                                    className: "p-3 bg-gray-50 rounded border",
                                    children: [(0, q.jsxs)("div", {
                                        className: "flex justify-between mb-1",
                                        children: [(0, q.jsx)("span", {
                                            className: "text-muted-foreground",
                                            children: "Invoice Number:"
                                        }), (0, q.jsxs)("span", {
                                            className: "font-medium",
                                            children: ["INV-", i.billingId.split("-")[1]]
                                        })]
                                    }), (0, q.jsxs)("div", {
                                        className: "flex justify-between mb-1",
                                        children: [(0, q.jsx)("span", {
                                            className: "text-muted-foreground",
                                            children: "Order ID:"
                                        }), (0, q.jsx)("span", {
                                            className: "font-medium",
                                            children: i.orderId
                                        })]
                                    }), (0, q.jsxs)("div", {
                                        className: "flex justify-between mb-1",
                                        children: [(0, q.jsx)("span", {
                                            className: "text-muted-foreground",
                                            children: "Customer:"
                                        }), (0, q.jsx)("span", {
                                            className: "font-medium",
                                            children: i.customerName
                                        })]
                                    }), (0, q.jsxs)("div", {
                                        className: "flex justify-between pt-2 border-t mt-2",
                                        children: [(0, q.jsx)("span", {
                                            className: "text-muted-foreground font-semibold",
                                            children: "Amount:"
                                        }), (0, q.jsxs)("span", {
                                            className: "font-bold text-lg",
                                            children: ["$", i.amount.toLocaleString()]
                                        })]
                                    })]
                                })
                            })]
                        })]
                    })
                }), o >= 6 && (0, q.jsx)(ap, {
                    className: "p-6",
                    children: (0, q.jsxs)("div", {
                        className: "flex items-start gap-4",
                        children: [(0, q.jsx)(a$, {
                            type: "delivery",
                            size: "lg"
                        }), (0, q.jsxs)("div", {
                            className: "flex-1",
                            children: [(0, q.jsxs)("div", {
                                className: "flex items-center justify-between mb-3",
                                children: [(0, q.jsx)("h3", {
                                    className: "font-semibold text-foreground",
                                    children: "Invoice Delivery Agent"
                                }), i.invoiceDelivered ? (0, q.jsxs)(ar, {
                                    variant: "outline",
                                    className: "bg-green-50 text-green-700 border-green-300",
                                    children: [(0, q.jsx)(aB, {
                                        className: "w-3 h-3 mr-1"
                                    }), "Delivered"]
                                }) : (0, q.jsxs)(ar, {
                                    variant: "outline",
                                    className: "bg-blue-50 text-blue-700 border-blue-300",
                                    children: [(0, q.jsx)(EB, {
                                        className: "w-3 h-3 mr-1 animate-spin"
                                    }), "Delivering"]
                                })]
                            }), (0, q.jsxs)("div", {
                                className: "space-y-2 text-sm",
                                children: [(0, q.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [(0, q.jsx)(aB, {
                                        className: "w-4 h-4 text-green-600"
                                    }), (0, q.jsx)("span", {
                                        children: "Preferred delivery channel identified"
                                    })]
                                }), (0, q.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [(0, q.jsx)(aB, {
                                        className: "w-4 h-4 text-green-600"
                                    }), (0, q.jsx)("span", {
                                        children: "Invoice uploaded to customer portal"
                                    })]
                                }), (0, q.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [(0, q.jsx)(aB, {
                                        className: "w-4 h-4 text-green-600"
                                    }), (0, q.jsx)("span", {
                                        children: "Supporting documents attached"
                                    })]
                                }), (0, q.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [(0, q.jsx)(aB, {
                                        className: "w-4 h-4 text-green-600"
                                    }), (0, q.jsx)("span", {
                                        children: "Email notification sent"
                                    })]
                                })]
                            })]
                        })]
                    })
                })]
            }), (0, q.jsx)("div", {
                className: "lg:col-span-1",
                children: (0, q.jsxs)(ap, {
                    children: [(0, q.jsxs)("div", {
                        className: "p-4 pb-2 border-b",
                        children: [(0, q.jsxs)("h3", {
                            className: "font-semibold text-sm flex items-center gap-2",
                            children: [(0, q.jsx)(EQ, {
                                className: "w-4 h-4 text-muted-foreground"
                            }), "AI Agent Audit Trail"]
                        }), (0, q.jsx)("p", {
                            className: "text-xs text-muted-foreground mt-0.5",
                            children: "Real-time billing orchestration log"
                        })]
                    }), (0, q.jsxs)("div", {
                        ref: f,
                        className: "max-h-[600px] overflow-y-auto p-3 space-y-2",
                        children: [0 === l.length && (0, q.jsx)("p", {
                            className: "text-xs text-muted-foreground italic",
                            children: "Waiting for processing to begin..."
                        }), l.map((e, t) => (0, q.jsxs)("div", {
                            className: "text-xs border-l-2 border-blue-400 pl-3 py-1 animate-in fade-in slide-in-from-bottom-2 duration-300",
                            children: [(0, q.jsx)("div", {
                                className: "text-muted-foreground text-[10px]",
                                children: new Date(e.timestamp).toLocaleTimeString()
                            }), (0, q.jsx)("div", {
                                className: "success" === e.type ? "text-[var(--success)] font-medium" : "text-foreground",
                                children: e.message
                            })]
                        }, t))]
                    })]
                })
            })]
        }), (0, q.jsxs)("div", {
            className: "fixed bottom-6 right-6 z-50 flex flex-col items-end gap-2",
            children: [u.open && (0, q.jsxs)("div", {
                className: "w-80 rounded-xl shadow-2xl border border-border bg-background flex flex-col overflow-hidden",
                style: {
                    height: "400px"
                },
                children: [(0, q.jsxs)("div", {
                    className: "flex items-center justify-between px-4 py-3 bg-gradient-to-r from-primary to-primary/80 text-primary-foreground",
                    children: [(0, q.jsx)("span", {
                        className: "text-sm font-semibold",
                        children: "Billing Agent"
                    }), (0, q.jsx)("button", {
                        onClick: () => d(e => ({
                            ...e,
                            open: !1
                        })),
                        className: "opacity-70 hover:opacity-100",
                        children: (0, q.jsx)(ak, {
                            className: "h-4 w-4"
                        })
                    })]
                }), (0, q.jsxs)("div", {
                    className: "flex-1 overflow-y-auto p-3 space-y-2",
                    children: [0 === u.messages.length && (0, q.jsx)("p", {
                        className: "text-xs text-muted-foreground italic text-center mt-4",
                        children: "Ask about billing status or type 'approve' to confirm a step."
                    }), u.messages.map((e, t) => (0, q.jsx)("div", {
                        className: `flex ${"user"===e.role?"justify-end":"justify-start"}`,
                        children: (0, q.jsxs)("div", {
                            className: `max-w-[85%] rounded-lg px-3 py-2 text-xs ${"user"===e.role?"bg-primary text-primary-foreground":e.isApproval?"bg-green-50 border border-green-200 text-green-800":"bg-muted text-foreground"}`,
                            children: [e.isApproval && (0, q.jsx)(A$, {
                                className: "h-3 w-3 inline mr-1 text-green-600"
                            }), e.text]
                        })
                    }, t)), (0, q.jsx)("div", {
                        ref: p
                    })]
                }), (0, q.jsxs)("div", {
                    className: "flex items-center gap-2 px-3 py-2 border-t",
                    children: [(0, q.jsx)(e2, {
                        value: u.input,
                        onChange: e => d(t => ({
                            ...t,
                            input: e.target.value
                        })),
                        onKeyDown: e => "Enter" === e.key && m(),
                        placeholder: "Type order number or 'approve'...",
                        className: "h-7 text-xs flex-1 bg-muted/40 border-muted"
                    }), (0, q.jsx)(e1, {
                        size: "sm",
                        variant: "ghost",
                        onClick: m,
                        className: "h-7 w-7 p-0 text-muted-foreground hover:text-foreground",
                        children: (0, q.jsx)(ER, {
                            className: "h-3 w-3"
                        })
                    })]
                })]
            }), (0, q.jsx)("button", {
                onClick: () => d(e => ({
                    ...e,
                    open: !e.open
                })),
                className: "h-11 w-11 rounded-full bg-primary text-primary-foreground shadow-lg flex items-center justify-center hover:bg-primary/90 transition-all",
                children: u.open ? (0, q.jsx)(ak, {
                    className: "h-5 w-5"
                }) : (0, q.jsx)(ED, {
                    className: "h-5 w-5"
                })
            })]
        })]
    }) : (0, q.jsxs)("div", {
        className: "space-y-6",
        children: [(0, q.jsxs)("div", {
            children: [(0, q.jsx)("h2", {
                className: "text-lg font-bold text-foreground",
                children: "Billing Pipeline"
            }), (0, q.jsx)("p", {
                className: "text-sm text-muted-foreground",
                children: "AI-powered billing orchestration with intelligent validation"
            })]
        }), (0, q.jsx)("div", {
            className: "space-y-4",
            children: r.map(e => {
                let n = h(e.status),
                    i = (n + 1) / AW.length * 100;
                return (0, q.jsxs)(ap, {
                    className: "p-6",
                    children: [(0, q.jsxs)("div", {
                        className: "flex items-center justify-between mb-4",
                        children: [(0, q.jsxs)("div", {
                            children: [(0, q.jsxs)("div", {
                                className: "flex items-center gap-3 mb-2",
                                children: [(0, q.jsx)("h3", {
                                    className: "font-semibold text-foreground",
                                    children: e.orderId
                                }), (0, q.jsx)(ar, {
                                    variant: "outline",
                                    className: "completed" === e.status ? "bg-green-50 text-green-700 border-green-300" : "bg-blue-50 text-blue-700 border-blue-300",
                                    children: "completed" === e.status ? "Completed" : AW[n]?.label
                                })]
                            }), (0, q.jsx)("div", {
                                className: "text-sm text-muted-foreground",
                                children: e.customerName
                            }), (0, q.jsxs)("div", {
                                className: "text-sm font-semibold text-foreground",
                                children: ["$", e.amount.toLocaleString()]
                            })]
                        }), "completed" !== e.status && (0, q.jsxs)(e1, {
                            onClick: () => {
                                var n;
                                let i;
                                return n = e.billingId, d({
                                    open: !1,
                                    messages: [],
                                    input: ""
                                }), void((i = r.find(e => e.billingId === n)) && (a(i), t(n), s(h(i.status)), c([{
                                    timestamp: new Date().toISOString(),
                                    message: `Started billing process for ${i.orderId}`,
                                    type: "info"
                                }])))
                            },
                            className: "bg-primary",
                            children: [(0, q.jsx)(ao, {
                                className: "w-4 h-4 mr-2"
                            }), "Process"]
                        })]
                    }), (0, q.jsxs)("div", {
                        className: "space-y-3",
                        children: [(0, q.jsxs)("div", {
                            className: "flex items-center justify-between text-xs text-muted-foreground mb-1",
                            children: [(0, q.jsx)("span", {
                                children: "Progress"
                            }), (0, q.jsxs)("span", {
                                children: [Math.round(i), "%"]
                            })]
                        }), (0, q.jsx)(Ay, {
                            value: i,
                            className: "h-2"
                        }), (0, q.jsx)("div", {
                            className: "flex gap-2 flex-wrap",
                            children: AW.map((e, t) => {
                                let r = e.icon,
                                    i = t < n,
                                    a = t === n;
                                return (0, q.jsxs)("div", {
                                    className: ["flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition-all", i ? "bg-green-50 text-green-700 border-green-300" : "", a ? "bg-blue-50 text-blue-700 border-blue-300 ring-2 ring-blue-200" : "", t > n ? "bg-gray-50 text-gray-500 border-gray-200" : ""].join(" "),
                                    children: [(0, q.jsx)(r, {
                                        className: "w-3.5 h-3.5"
                                    }), (0, q.jsx)("span", {
                                        children: e.label
                                    }), i && (0, q.jsx)(aB, {
                                        className: "w-3.5 h-3.5"
                                    }), a && (0, q.jsx)(EB, {
                                        className: "w-3.5 h-3.5 animate-spin"
                                    })]
                                }, e.id)
                            })
                        })]
                    })]
                }, e.billingId)
            })
        })]
    })
}