function e1({
    className: e,
    variant: t,
    size: r,
    asChild: n = !1,
    ...i
}) {
    let a = n ? eo : "button";
    return (0, q.jsx)(a, {
        "data-slot": "button",
        className: eJ(e0({
            variant: t,
            size: r,
            className: e
        })),
        ...i
    })
}

function e2({
    className: e,
    type: t,
    ...r
}) {
    return (0, q.jsx)("input", {
        type: t,
        "data-slot": "input",
        className: eJ("file:text-foreground placeholder:text-muted-foreground selection:bg-primary selection:text-primary-foreground dark:bg-input/30 border-input h-9 w-full min-w-0 rounded-md border bg-transparent px-3 py-1 text-base shadow-xs transition-[color,box-shadow] outline-none file:inline-flex file:h-7 file:border-0 file:bg-transparent file:text-sm file:font-medium disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", "focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]", "aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive", e),
        ...r
    })
}

function e5(e, t, {
    checkForDefaultPrevented: r = !0
} = {}) {
    return function(n) {
        if (e?.(n), !1 === r || !n.defaultPrevented) return t?.(n)
    }
}

function e3(e, t = []) {
    let r = [],
        n = () => {
            let t = r.map(e => G.createContext(e));
            return function(r) {
                let n = r?.[e] || t;
                return G.useMemo(() => ({
                    [`__scope${e}`]: {
                        ...r,
                        [e]: n
                    }
                }), [r, n])
            }
        };
    return n.scopeName = e, [function(t, n) {
        let i = G.createContext(n),
            a = r.length;
        r = [...r, n];
        let o = t => {
            let {
                scope: r,
                children: n,
                ...o
            } = t, s = r?.[e]?.[a] || i, l = G.useMemo(() => o, Object.values(o));
            return (0, q.jsx)(s.Provider, {
                value: l,
                children: n
            })
        };
        return o.displayName = t + "Provider", [o, function(r, o) {
            let s = o?.[e]?.[a] || i,
                l = G.useContext(s);
            if (l) return l;
            if (void 0 !== n) return n;
            throw Error(`\`${r}\` must be used within \`${t}\``)
        }]
    }, function(...e) {
        let t = e[0];
        if (1 === e.length) return t;
        let r = () => {
            let r = e.map(e => ({
                useScope: e(),
                scopeName: e.scopeName
            }));
            return function(e) {
                let n = r.reduce((t, {
                    useScope: r,
                    scopeName: n
                }) => {
                    let i = r(e)[`__scope${n}`];
                    return {
                        ...t,
                        ...i
                    }
                }, {});
                return G.useMemo(() => ({
                    [`__scope${t.scopeName}`]: n
                }), [n])
            }
        };
        return r.scopeName = t.scopeName, r
    }(n, ...t)]
}

function e4(e) {
    let t = G.useRef(e);
    return G.useEffect(() => {
        t.current = e
    }), G.useMemo(() => (...e) => t.current?.(...e), [])
}

function e8({
    prop: e,
    defaultProp: t,
    onChange: r = () => {}
}) {
    let [n, i] = function({
        defaultProp: e,
        onChange: t
    }) {
        let r = G.useState(e),
            [n] = r,
            i = G.useRef(n),
            a = e4(t);
        return G.useEffect(() => {
            i.current !== n && (a(n), i.current = n)
        }, [n, i, a]), r
    }({
        defaultProp: t,
        onChange: r
    }), a = void 0 !== e, o = a ? e : n, s = e4(r);
    return [o, G.useCallback(t => {
        if (a) {
            let r = "function" == typeof t ? t(e) : t;
            r !== e && s(r)
        } else i(t)
    }, [a, e, i, s])]
}
var e6 = e.i(74080),
    e7 = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "span", "svg", "ul"].reduce((e, t) => {
        let r = G.forwardRef((e, r) => {
            let {
                asChild: n,
                ...i
            } = e, a = n ? eo : t;
            return "undefined" != typeof window && (window[Symbol.for("radix-ui")] = !0), (0, q.jsx)(a, {
                ...i,
                ref: r
            })
        });
        return r.displayName = `Primitive.${t}`, {
            ...e,
            [t]: r
        }
    }, {});

function e9(e, t) {
    e && e6.flushSync(() => e.dispatchEvent(t))
}

function te(e) {
    let t = e + "CollectionProvider",
        [r, n] = e3(t),
        [i, a] = r(t, {
            collectionRef: {
                current: null
            },
            itemMap: new Map
        }),
        o = e => {
            let {
                scope: t,
                children: r
            } = e, n = G.default.useRef(null), a = G.default.useRef(new Map).current;
            return (0, q.jsx)(i, {
                scope: t,
                itemMap: a,
                collectionRef: n,
                children: r
            })
        };
    o.displayName = t;
    let s = e + "CollectionSlot",
        l = G.default.forwardRef((e, t) => {
            let {
                scope: r,
                children: n
            } = e, i = ea(t, a(s, r).collectionRef);
            return (0, q.jsx)(eo, {
                ref: i,
                children: n
            })
        });
    l.displayName = s;
    let c = e + "CollectionItemSlot",
        u = "data-radix-collection-item",
        d = G.default.forwardRef((e, t) => {
            let {
                scope: r,
                children: n,
                ...i
            } = e, o = G.default.useRef(null), s = ea(t, o), l = a(c, r);
            return G.default.useEffect(() => (l.itemMap.set(o, {
                ref: o,
                ...i
            }), () => void l.itemMap.delete(o))), (0, q.jsx)(eo, {
                ...{
                    [u]: ""
                },
                ref: s,
                children: n
            })
        });
    return d.displayName = c, [{
        Provider: o,
        Slot: l,
        ItemSlot: d
    }, function(t) {
        let r = a(e + "CollectionConsumer", t);
        return G.default.useCallback(() => {
            let e = r.collectionRef.current;
            if (!e) return [];
            let t = Array.from(e.querySelectorAll(`[${u}]`));
            return Array.from(r.itemMap.values()).sort((e, r) => t.indexOf(e.ref.current) - t.indexOf(r.ref.current))
        }, [r.collectionRef, r.itemMap])
    }, n]
}
var tt = G.createContext(void 0);

function tr(e) {
    let t = G.useContext(tt);
    return e || t || "ltr"
}
var tn = "dismissableLayer.update",
    ti = G.createContext({
        layers: new Set,
        layersWithOutsidePointerEventsDisabled: new Set,
        branches: new Set
    }),
    ta = G.forwardRef((e, t) => {
        let {
            disableOutsidePointerEvents: r = !1,
            onEscapeKeyDown: n,
            onPointerDownOutside: i,
            onFocusOutside: a,
            onInteractOutside: o,
            onDismiss: s,
            ...l
        } = e, c = G.useContext(ti), [u, d] = G.useState(null), f = u?.ownerDocument ?? globalThis?.document, [, m] = G.useState({}), h = ea(t, e => d(e)), g = Array.from(c.layers), [v] = [...c.layersWithOutsidePointerEventsDisabled].slice(-1), y = g.indexOf(v), x = u ? g.indexOf(u) : -1, b = c.layersWithOutsidePointerEventsDisabled.size > 0, w = x >= y, j = function(e, t = globalThis?.document) {
            let r = e4(e),
                n = G.useRef(!1),
                i = G.useRef(() => {});
            return G.useEffect(() => {
                let e = e => {
                        if (e.target && !n.current) {
                            let n = function() {
                                    ts("dismissableLayer.pointerDownOutside", r, a, {
                                        discrete: !0
                                    })
                                },
                                a = {
                                    originalEvent: e
                                };
                            "touch" === e.pointerType ? (t.removeEventListener("click", i.current), i.current = n, t.addEventListener("click", i.current, {
                                once: !0
                            })) : n()
                        } else t.removeEventListener("click", i.current);
                        n.current = !1
                    },
                    a = window.setTimeout(() => {
                        t.addEventListener("pointerdown", e)
                    }, 0);
                return () => {
                    window.clearTimeout(a), t.removeEventListener("pointerdown", e), t.removeEventListener("click", i.current)
                }
            }, [t, r]), {
                onPointerDownCapture: () => n.current = !0
            }
        }(e => {
            let t = e.target,
                r = [...c.branches].some(e => e.contains(t));
            w && !r && (i?.(e), o?.(e), e.defaultPrevented || s?.())
        }, f), O = function(e, t = globalThis?.document) {
            let r = e4(e),
                n = G.useRef(!1);
            return G.useEffect(() => {
                let e = e => {
                    e.target && !n.current && ts("dismissableLayer.focusOutside", r, {
                        originalEvent: e
                    }, {
                        discrete: !1
                    })
                };
                return t.addEventListener("focusin", e), () => t.removeEventListener("focusin", e)
            }, [t, r]), {
                onFocusCapture: () => n.current = !0,
                onBlurCapture: () => n.current = !1
            }
        }(e => {
            let t = e.target;
            ![...c.branches].some(e => e.contains(t)) && (a?.(e), o?.(e), e.defaultPrevented || s?.())
        }, f);
        return ! function(e, t = globalThis?.document) {
            let r = e4(e);
            G.useEffect(() => {
                let e = e => {
                    "Escape" === e.key && r(e)
                };
                return t.addEventListener("keydown", e, {
                    capture: !0
                }), () => t.removeEventListener("keydown", e, {
                    capture: !0
                })
            }, [r, t])
        }(e => {
            x === c.layers.size - 1 && (n?.(e), !e.defaultPrevented && s && (e.preventDefault(), s()))
        }, f), G.useEffect(() => {
            if (u) return r && (0 === c.layersWithOutsidePointerEventsDisabled.size && (p = f.body.style.pointerEvents, f.body.style.pointerEvents = "none"), c.layersWithOutsidePointerEventsDisabled.add(u)), c.layers.add(u), to(), () => {
                r && 1 === c.layersWithOutsidePointerEventsDisabled.size && (f.body.style.pointerEvents = p)
            }
        }, [u, f, r, c]), G.useEffect(() => () => {
            u && (c.layers.delete(u), c.layersWithOutsidePointerEventsDisabled.delete(u), to())
        }, [u, c]), G.useEffect(() => {
            let e = () => m({});
            return document.addEventListener(tn, e), () => document.removeEventListener(tn, e)
        }, []), (0, q.jsx)(e7.div, {
            ...l,
            ref: h,
            style: {
                pointerEvents: b ? w ? "auto" : "none" : void 0,
                ...e.style
            },
            onFocusCapture: e5(e.onFocusCapture, O.onFocusCapture),
            onBlurCapture: e5(e.onBlurCapture, O.onBlurCapture),
            onPointerDownCapture: e5(e.onPointerDownCapture, j.onPointerDownCapture)
        })
    });

function to() {
    let e = new CustomEvent(tn);
    document.dispatchEvent(e)
}

function ts(e, t, r, {
    discrete: n
}) {
    let i = r.originalEvent.target,
        a = new CustomEvent(e, {
            bubbles: !1,
            cancelable: !0,
            detail: r
        });
    t && i.addEventListener(e, t, {
        once: !0
    }), n ? e9(i, a) : i.dispatchEvent(a)
}
ta.displayName = "DismissableLayer", G.forwardRef((e, t) => {
    let r = G.useContext(ti),
        n = G.useRef(null),
        i = ea(t, n);
    return G.useEffect(() => {
        let e = n.current;
        if (e) return r.branches.add(e), () => {
            r.branches.delete(e)
        }
    }, [r.branches]), (0, q.jsx)(e7.div, {
        ...e,
        ref: i
    })
}).displayName = "DismissableLayerBranch";
var tl = 0;

function tc() {
    let e = document.createElement("span");
    return e.setAttribute("data-radix-focus-guard", ""), e.tabIndex = 0, e.style.outline = "none", e.style.opacity = "0", e.style.position = "fixed", e.style.pointerEvents = "none", e
}
var tu = "focusScope.autoFocusOnMount",
    td = "focusScope.autoFocusOnUnmount",
    tf = {
        bubbles: !1,
        cancelable: !0
    },
    tp = G.forwardRef((e, t) => {
        let {
            loop: r = !1,
            trapped: n = !1,
            onMountAutoFocus: i,
            onUnmountAutoFocus: a,
            ...o
        } = e, [s, l] = G.useState(null), c = e4(i), u = e4(a), d = G.useRef(null), f = ea(t, e => l(e)), p = G.useRef({
            paused: !1,
            pause() {
                this.paused = !0
            },
            resume() {
                this.paused = !1
            }
        }).current;
        G.useEffect(() => {
            if (n) {
                let e = function(e) {
                        if (p.paused || !s) return;
                        let t = e.target;
                        s.contains(t) ? d.current = t : tg(d.current, {
                            select: !0
                        })
                    },
                    t = function(e) {
                        if (p.paused || !s) return;
                        let t = e.relatedTarget;
                        null !== t && (s.contains(t) || tg(d.current, {
                            select: !0
                        }))
                    };
                document.addEventListener("focusin", e), document.addEventListener("focusout", t);
                let r = new MutationObserver(function(e) {
                    if (document.activeElement === document.body)
                        for (let t of e) t.removedNodes.length > 0 && tg(s)
                });
                return s && r.observe(s, {
                    childList: !0,
                    subtree: !0
                }), () => {
                    document.removeEventListener("focusin", e), document.removeEventListener("focusout", t), r.disconnect()
                }
            }
        }, [n, s, p.paused]), G.useEffect(() => {
            if (s) {
                tv.add(p);
                let e = document.activeElement;
                if (!s.contains(e)) {
                    let t = new CustomEvent(tu, tf);
                    s.addEventListener(tu, c), s.dispatchEvent(t), t.defaultPrevented || (function(e, {
                        select: t = !1
                    } = {}) {
                        let r = document.activeElement;
                        for (let n of e)
                            if (tg(n, {
                                    select: t
                                }), document.activeElement !== r) return
                    }(tm(s).filter(e => "A" !== e.tagName), {
                        select: !0
                    }), document.activeElement === e && tg(s))
                }
                return () => {
                    s.removeEventListener(tu, c), setTimeout(() => {
                        let t = new CustomEvent(td, tf);
                        s.addEventListener(td, u), s.dispatchEvent(t), t.defaultPrevented || tg(e ?? document.body, {
                            select: !0
                        }), s.removeEventListener(td, u), tv.remove(p)
                    }, 0)
                }
            }
        }, [s, c, u, p]);
        let m = G.useCallback(e => {
            if (!r && !n || p.paused) return;
            let t = "Tab" === e.key && !e.altKey && !e.ctrlKey && !e.metaKey,
                i = document.activeElement;
            if (t && i) {
                var a;
                let t, n = e.currentTarget,
                    [o, s] = [th(t = tm(a = n), a), th(t.reverse(), a)];
                o && s ? e.shiftKey || i !== s ? e.shiftKey && i === o && (e.preventDefault(), r && tg(s, {
                    select: !0
                })) : (e.preventDefault(), r && tg(o, {
                    select: !0
                })) : i === n && e.preventDefault()
            }
        }, [r, n, p.paused]);
        return (0, q.jsx)(e7.div, {
            tabIndex: -1,
            ...o,
            ref: f,
            onKeyDown: m
        })
    });

function tm(e) {
    let t = [],
        r = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
            acceptNode: e => {
                let t = "INPUT" === e.tagName && "hidden" === e.type;
                return e.disabled || e.hidden || t ? NodeFilter.FILTER_SKIP : e.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP
            }
        });
    for (; r.nextNode();) t.push(r.currentNode);
    return t
}

function th(e, t) {
    for (let r of e)
        if (! function(e, {
                upTo: t
            }) {
                if ("hidden" === getComputedStyle(e).visibility) return !0;
                for (; e && (void 0 === t || e !== t);) {
                    if ("none" === getComputedStyle(e).display) return !0;
                    e = e.parentElement
                }
                return !1
            }(r, {
                upTo: t
            })) return r
}

function tg(e, {
    select: t = !1
} = {}) {
    if (e && e.focus) {
        var r;
        let n = document.activeElement;
        e.focus({
            preventScroll: !0
        }), e !== n && (r = e) instanceof HTMLInputElement && "select" in r && t && e.select()
    }
}
tp.displayName = "FocusScope";
var tv = (r = [], {
    add(e) {
        let t = r[0];
        e !== t && t?.pause(), (r = ty(r, e)).unshift(e)
    },
    remove(e) {
        r = ty(r, e), r[0]?.resume()
    }
});

function ty(e, t) {
    let r = [...e],
        n = r.indexOf(t);
    return -1 !== n && r.splice(n, 1), r
}
var tx = globalThis?.document ? G.useLayoutEffect : () => {},
    tb = G["useId".toString()] || (() => void 0),
    tw = 0;

function tj(e) {
    let [t, r] = G.useState(tb());
    return tx(() => {
        e || r(e => e ?? String(tw++))
    }, [e]), e || (t ? `radix-${t}` : "")
}
let tO = ["top", "right", "bottom", "left"],
    tN = Math.min,
    tk = Math.max,
    tS = Math.round,
    tP = Math.floor,
    tE = e => ({
        x: e,
        y: e
    }),
    tA = {
        left: "right",
        right: "left",
        bottom: "top",
        top: "bottom"
    };

function tC(e, t) {
    return "function" == typeof e ? e(t) : e
}

function tI(e) {
    return e.split("-")[0]
}

function tM(e) {
    return e.split("-")[1]
}

function tT(e) {
    return "x" === e ? "y" : "x"
}

function t_(e) {
    return "y" === e ? "height" : "width"
}

function tD(e) {
    let t = e[0];
    return "t" === t || "b" === t ? "y" : "x"
}

function tR(e) {
    return e.includes("start") ? e.replace("start", "end") : e.replace("end", "start")
}
let tL = ["left", "right"],
    tz = ["right", "left"],
    tB = ["top", "bottom"],
    t$ = ["bottom", "top"];

function tF(e) {
    let t = tI(e);
    return tA[t] + e.slice(t.length)
}

function tV(e) {
    return "number" != typeof e ? {
        top: 0,
        right: 0,
        bottom: 0,
        left: 0,
        ...e
    } : {
        top: e,
        right: e,
        bottom: e,
        left: e
    }
}

function tU(e) {
    let {
        x: t,
        y: r,
        width: n,
        height: i
    } = e;
    return {
        width: n,
        height: i,
        top: r,
        left: t,
        right: t + n,
        bottom: r + i,
        x: t,
        y: r
    }
}

function tK(e, t, r) {
    let n, {
            reference: i,
            floating: a
        } = e,
        o = tD(t),
        s = tT(tD(t)),
        l = t_(s),
        c = tI(t),
        u = "y" === o,
        d = i.x + i.width / 2 - a.width / 2,
        f = i.y + i.height / 2 - a.height / 2,
        p = i[l] / 2 - a[l] / 2;
    switch (c) {
        case "top":
            n = {
                x: d,
                y: i.y - a.height
            };
            break;
        case "bottom":
            n = {
                x: d,
                y: i.y + i.height
            };
            break;
        case "right":
            n = {
                x: i.x + i.width,
                y: f
            };
            break;
        case "left":
            n = {
                x: i.x - a.width,
                y: f
            };
            break;
        default:
            n = {
                x: i.x,
                y: i.y
            }
    }
    switch (tM(t)) {
        case "start":
            n[s] -= p * (r && u ? -1 : 1);
            break;
        case "end":
            n[s] += p * (r && u ? -1 : 1)
    }
    return n
}
async function tH(e, t) {
        var r;
        void 0 === t && (t = {});
        let {
            x: n,
            y: i,
            platform: a,
            rects: o,
            elements: s,
            strategy: l
        } = e, {
            boundary: c = "clippingAncestors",
            rootBoundary: u = "viewport",
            elementContext: d = "floating",
            altBoundary: f = !1,
            padding: p = 0
        } = tC(t, e), m = tV(p), h = s[f ? "floating" === d ? "reference" : "floating" : d], g = tU(await a.getClippingRect({
                element: null == (r = await (null == a.isElement ? void 0 : a.isElement(h))) || r ? h : h.contextElement || await (null == a.getDocumentElement ? void 0 : a.getDocumentElement(s.floating)),
                boundary: c,
                rootBoundary: u,
                strategy: l
            })), v = "floating" === d ? {
                x: n,
                y: i,
                width: o.floating.width,
                height: o.floating.height
            } : o.reference, y = await (null == a.getOffsetParent ? void 0 : a.getOffse