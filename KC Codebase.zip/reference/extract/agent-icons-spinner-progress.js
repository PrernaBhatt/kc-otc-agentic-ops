}, {
    agent: "Validation",
    processed: 324,
    success: 318
}, {
    agent: "Billing",
    processed: 198,
    success: 195
}, {
    agent: "Collections",
    processed: 87,
    success: 82
}], aB = Q("CircleCheck", [
    ["circle", {
        cx: "12",
        cy: "12",
        r: "10",
        key: "1mglay"
    }],
    ["path", {
        d: "m9 12 2 2 4-4",
        key: "dzmm74"
    }]
]);

function a$({
    type: e,
    size: t = "md",
    animated: r = !1,
    className: n
}) {
    let i = eJ({
            sm: "w-6 h-6",
            md: "w-8 h-8",
            lg: "w-12 h-12"
        } [t], r && "animate-pulse", n),
        a = {
            orchestrator: (0, q.jsxs)("svg", {
                className: i,
                viewBox: "0 0 48 48",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: [(0, q.jsx)("circle", {
                    cx: "24",
                    cy: "24",
                    r: "20",
                    fill: "currentColor",
                    fillOpacity: "0.1",
                    stroke: "currentColor",
                    strokeWidth: "2"
                }), (0, q.jsx)("circle", {
                    cx: "24",
                    cy: "14",
                    r: "4",
                    fill: "currentColor"
                }), (0, q.jsx)("circle", {
                    cx: "14",
                    cy: "30",
                    r: "4",
                    fill: "currentColor"
                }), (0, q.jsx)("circle", {
                    cx: "34",
                    cy: "30",
                    r: "4",
                    fill: "currentColor"
                }), (0, q.jsx)("path", {
                    d: "M24 18V22M18 28L21 25M30 28L27 25",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round"
                }), (0, q.jsx)("circle", {
                    cx: "24",
                    cy: "24",
                    r: "3",
                    fill: "currentColor"
                })]
            }),
            credit: (0, q.jsxs)("svg", {
                className: i,
                viewBox: "0 0 48 48",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: [(0, q.jsx)("rect", {
                    x: "6",
                    y: "12",
                    width: "36",
                    height: "24",
                    rx: "4",
                    fill: "currentColor",
                    fillOpacity: "0.1",
                    stroke: "currentColor",
                    strokeWidth: "2"
                }), (0, q.jsx)("rect", {
                    x: "6",
                    y: "18",
                    width: "36",
                    height: "6",
                    fill: "currentColor"
                }), (0, q.jsx)("circle", {
                    cx: "34",
                    cy: "28",
                    r: "4",
                    fill: "currentColor",
                    fillOpacity: "0.5"
                }), (0, q.jsx)("circle", {
                    cx: "30",
                    cy: "28",
                    r: "4",
                    fill: "currentColor"
                })]
            }),
            pricing: (0, q.jsxs)("svg", {
                className: i,
                viewBox: "0 0 48 48",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: [(0, q.jsx)("circle", {
                    cx: "24",
                    cy: "24",
                    r: "18",
                    fill: "currentColor",
                    fillOpacity: "0.1",
                    stroke: "currentColor",
                    strokeWidth: "2"
                }), (0, q.jsx)("text", {
                    x: "24",
                    y: "30",
                    textAnchor: "middle",
                    fill: "currentColor",
                    fontSize: "18",
                    fontWeight: "bold",
                    children: "$"
                })]
            }),
            ltv: (0, q.jsxs)("svg", {
                className: i,
                viewBox: "0 0 48 48",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: [(0, q.jsx)("rect", {
                    x: "8",
                    y: "8",
                    width: "32",
                    height: "32",
                    rx: "4",
                    fill: "currentColor",
                    fillOpacity: "0.1",
                    stroke: "currentColor",
                    strokeWidth: "2"
                }), (0, q.jsx)("path", {
                    d: "M14 32L20 24L26 28L34 16",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }), (0, q.jsx)("circle", {
                    cx: "34",
                    cy: "16",
                    r: "3",
                    fill: "currentColor"
                })]
            }),
            dunning: (0, q.jsxs)("svg", {
                className: i,
                viewBox: "0 0 48 48",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: [(0, q.jsx)("path", {
                    d: "M8 12H40V36C40 38.2091 38.2091 40 36 40H12C9.79086 40 8 38.2091 8 36V12Z",
                    fill: "currentColor",
                    fillOpacity: "0.1",
                    stroke: "currentColor",
                    strokeWidth: "2"
                }), (0, q.jsx)("path", {
                    d: "M8 12L24 24L40 12",
                    stroke: "currentColor",
                    strokeWidth: "2"
                }), (0, q.jsx)("circle", {
                    cx: "36",
                    cy: "12",
                    r: "6",
                    fill: "#ef4444",
                    stroke: "white",
                    strokeWidth: "2"
                }), (0, q.jsx)("text", {
                    x: "36",
                    y: "15",
                    textAnchor: "middle",
                    fill: "white",
                    fontSize: "8",
                    fontWeight: "bold",
                    children: "!"
                })]
            }),
            validation: (0, q.jsxs)("svg", {
                className: i,
                viewBox: "0 0 48 48",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: [(0, q.jsx)("rect", {
                    x: "8",
                    y: "8",
                    width: "32",
                    height: "32",
                    rx: "4",
                    fill: "currentColor",
                    fillOpacity: "0.1",
                    stroke: "currentColor",
                    strokeWidth: "2"
                }), (0, q.jsx)("path", {
                    d: "M16 24L22 30L32 18",
                    stroke: "currentColor",
                    strokeWidth: "3",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                })]
            }),
            billing: (0, q.jsxs)("svg", {
                className: i,
                viewBox: "0 0 48 48",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: [(0, q.jsx)("rect", {
                    x: "10",
                    y: "6",
                    width: "28",
                    height: "36",
                    rx: "2",
                    fill: "currentColor",
                    fillOpacity: "0.1",
                    stroke: "currentColor",
                    strokeWidth: "2"
                }), (0, q.jsx)("line", {
                    x1: "16",
                    y1: "14",
                    x2: "32",
                    y2: "14",
                    stroke: "currentColor",
                    strokeWidth: "2"
                }), (0, q.jsx)("line", {
                    x1: "16",
                    y1: "22",
                    x2: "32",
                    y2: "22",
                    stroke: "currentColor",
                    strokeWidth: "2"
                }), (0, q.jsx)("line", {
                    x1: "16",
                    y1: "30",
                    x2: "26",
                    y2: "30",
                    stroke: "currentColor",
                    strokeWidth: "2"
                }), (0, q.jsx)("rect", {
                    x: "26",
                    y: "32",
                    width: "10",
                    height: "6",
                    rx: "1",
                    fill: "currentColor"
                })]
            }),
            atp: (0, q.jsxs)("svg", {
                className: i,
                viewBox: "0 0 48 48",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: [(0, q.jsx)("rect", {
                    x: "6",
                    y: "20",
                    width: "36",
                    height: "22",
                    rx: "2",
                    fill: "currentColor",
                    fillOpacity: "0.1",
                    stroke: "currentColor",
                    strokeWidth: "2"
                }), (0, q.jsx)("path", {
                    d: "M14 20V12C14 9.79086 15.7909 8 18 8H30C32.2091 8 34 9.79086 34 12V20",
                    stroke: "currentColor",
                    strokeWidth: "2"
                }), (0, q.jsx)("rect", {
                    x: "12",
                    y: "26",
                    width: "8",
                    height: "8",
                    rx: "1",
                    fill: "currentColor"
                }), (0, q.jsx)("rect", {
                    x: "24",
                    y: "26",
                    width: "8",
                    height: "8",
                    rx: "1",
                    fill: "currentColor"
                })]
            }),
            extraction: (0, q.jsxs)("svg", {
                className: i,
                viewBox: "0 0 48 48",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: [(0, q.jsx)("rect", {
                    x: "8",
                    y: "6",
                    width: "24",
                    height: "32",
                    rx: "2",
                    fill: "currentColor",
                    fillOpacity: "0.1",
                    stroke: "currentColor",
                    strokeWidth: "2"
                }), (0, q.jsx)("path", {
                    d: "M32 18L40 24L32 30V18Z",
                    fill: "currentColor"
                }), (0, q.jsx)("line", {
                    x1: "14",
                    y1: "14",
                    x2: "26",
                    y2: "14",
                    stroke: "currentColor",
                    strokeWidth: "2"
                }), (0, q.jsx)("line", {
                    x1: "14",
                    y1: "22",
                    x2: "26",
                    y2: "22",
                    stroke: "currentColor",
                    strokeWidth: "2"
                })]
            }),
            po: (0, q.jsxs)("svg", {
                className: i,
                viewBox: "0 0 48 48",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: [(0, q.jsx)("rect", {
                    x: "6",
                    y: "8",
                    width: "28",
                    height: "32",
                    rx: "2",
                    fill: "currentColor",
                    fillOpacity: "0.1",
                    stroke: "currentColor",
                    strokeWidth: "2"
                }), (0, q.jsx)("rect", {
                    x: "22",
                    y: "20",
                    width: "20",
                    height: "20",
                    rx: "2",
                    fill: "currentColor",
                    fillOpacity: "0.2",
                    stroke: "currentColor",
                    strokeWidth: "2"
                }), (0, q.jsx)("path", {
                    d: "M28 30L32 34L40 26",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round"
                })]
            }),
            contract: (0, q.jsxs)("svg", {
                className: i,
                viewBox: "0 0 48 48",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: [(0, q.jsx)("rect", {
                    x: "8",
                    y: "6",
                    width: "32",
                    height: "36",
                    rx: "2",
                    fill: "currentColor",
                    fillOpacity: "0.1",
                    stroke: "currentColor",
                    strokeWidth: "2"
                }), (0, q.jsx)("path", {
                    d: "M16 32C20 28 28 28 32 32",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round"
                }), (0, q.jsx)("circle", {
                    cx: "24",
                    cy: "18",
                    r: "6",
                    fill: "currentColor",
                    fillOpacity: "0.3",
                    stroke: "currentColor",
                    strokeWidth: "2"
                })]
            }),
            document: (0, q.jsxs)("svg", {
                className: i,
                viewBox: "0 0 48 48",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: [(0, q.jsx)("path", {
                    d: "M10 8H30L38 16V40C38 41.1046 37.1046 42 36 42H10C8.89543 42 8 41.1046 8 40V10C8 8.89543 8.89543 8 10 8Z",
                    fill: "currentColor",
                    fillOpacity: "0.1",
                    stroke: "currentColor",
                    strokeWidth: "2"
                }), (0, q.jsx)("path", {
                    d: "M30 8V16H38",
                    stroke: "currentColor",
                    strokeWidth: "2"
                }), (0, q.jsx)("line", {
                    x1: "14",
                    y1: "24",
                    x2: "32",
                    y2: "24",
                    stroke: "currentColor",
                    strokeWidth: "2"
                }), (0, q.jsx)("line", {
                    x1: "14",
                    y1: "32",
                    x2: "28",
                    y2: "32",
                    stroke: "currentColor",
                    strokeWidth: "2"
                })]
            }),
            invoice: (0, q.jsxs)("svg", {
                className: i,
                viewBox: "0 0 48 48",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: [(0, q.jsx)("rect", {
                    x: "8",
                    y: "4",
                    width: "32",
                    height: "40",
                    rx: "2",
                    fill: "currentColor",
                    fillOpacity: "0.1",
                    stroke: "currentColor",
                    strokeWidth: "2"
                }), (0, q.jsx)("line", {
                    x1: "14",
                    y1: "12",
                    x2: "34",
                    y2: "12",
                    stroke: "currentColor",
                    strokeWidth: "2"
                }), (0, q.jsx)("line", {
                    x1: "14",
                    y1: "20",
                    x2: "28",
                    y2: "20",
                    stroke: "currentColor",
                    strokeWidth: "1.5"
                }), (0, q.jsx)("line", {
                    x1: "14",
                    y1: "26",
                    x2: "28",
                    y2: "26",
                    stroke: "currentColor",
                    strokeWidth: "1.5"
                }), (0, q.jsx)("rect", {
                    x: "24",
                    y: "32",
                    width: "10",
                    height: "8",
                    rx: "1",
                    fill: "currentColor"
                }), (0, q.jsx)("text", {
                    x: "29",
                    y: "38",
                    textAnchor: "middle",
                    fill: "white",
                    fontSize: "6",
                    fontWeight: "bold",
                    children: "$"
                })]
            }),
            delivery: (0, q.jsxs)("svg", {
                className: i,
                viewBox: "0 0 48 48",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: [(0, q.jsx)("rect", {
                    x: "4",
                    y: "14",
                    width: "28",
                    height: "20",
                    rx: "2",
                    fill: "currentColor",
                    fillOpacity: "0.1",
                    stroke: "currentColor",
                    strokeWidth: "2"
                }), (0, q.jsx)("path", {
                    d: "M32 18H40L44 26V34H32V18Z",
                    fill: "currentColor",
                    fillOpacity: "0.2",
                    stroke: "currentColor",
                    strokeWidth: "2"
                }), (0, q.jsx)("circle", {
                    cx: "14",
                    cy: "38",
                    r: "4",
                    fill: "currentColor"
                }), (0, q.jsx)("circle", {
                    cx: "38",
                    cy: "38",
                    r: "4",
                    fill: "currentColor"
                })]
            })
        };
    return a[e] || a.orchestrator
}

function aF({
    size: e = "md",
    className: t
}) {
    return (0, q.jsxs)("svg", {
        className: eJ({
            sm: "w-4 h-4",
            md: "w-6 h-6",
            lg: "w-8 h-8"
        } [e], "animate-spin", t),
        viewBox: "0 0 24 24",
        fill: "none",
        children: [(0, q.jsx)("circle", {
            className: "opacity-25",
            cx: "12",
            cy: "12",
            r: "10",
            stroke: "currentColor",
            strokeWidth: "4"
        }), (0, q.jsx)("path", {
            className: "opacity-75",
            fill: "currentColor",
            d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
        })]
    })
}

function aV({
    progress: e,
    label: t,
    showPercent: r = !0,
    color: n = "primary",
    animated: i = !0
}) {
    return (0, q.jsxs)("div", {
        className: "w-full",
        children: [(t || r) && (0, q.jsxs)("div", {
            className: "flex justify-between items-center mb-1",
            children: [t && (0, q.jsx)("span", {
                className: "text-sm text-muted-foreground",
                children: t
            }), r && (0, q.jsxs)("span", {
                className: "text-sm font-medium",
                children: [Math.round(e), "%"]
            })]
        }), (0, q.jsx)("div", {
            className: "h-2 bg-muted rounded-full overflow-hidden",
            children: (0, q.jsx)("div", {
                className: eJ("h-full rounded-full transition-all duration-500", {
                    primary: "bg-primary",
                    success: "bg-[var(--success)]",
                    warning: "bg-[var(--warning)]",
                    info: "bg-[var(--info)]"
                } [n], i && "relative overflow-hidden"),
                style: {
                    width: `${e}%`
                },
                children: i && e < 100 && (0, q.jsx)("div", {
                    className: "absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-shimmer"
                })
            })
        })]
    })
}

function aU({
    status: e,
    message: t
}) {
    let r = {
        idle: {
            color: "text-muted-foreground",
            bg: "bg-muted",
            label: "Idle"
        },
        processing: {
            color: "text-[var(--info)]",
            bg: "bg-[var(--info)]/10",
            label: "Processing"
        },
        complete: {
            color: "text-[var(--success)]",
            bg: "bg-[var(--success)]/10",
            label: "Complete"
        },
        error: {
            color: "text-primary",
            bg: "bg-primary/10",
            label: "Error"
        }
    } [e];
    return (0, q.jsxs)("div", {
        className: eJ("flex items-center gap-2 px-3 py-1.5 rounded-full", r.bg),
        children: ["processing" === e && (0, q.jsx)(aF, {
            size: "sm",
            className: r.color
        }), "complete" === e && (0, q.jsx)("svg", {
            className: eJ("w-4 h-4", r.color),
            viewBox: "0 0 20 20",
            fill: "currentColor",
            children: (0, q.jsx)("path", {
                fillRule: "evenodd",
                d: "M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z",
                clipRule: "evenodd"
            })
        }), "error" === e && (0, q.jsx)("svg", {
            className: eJ("w-4 h-4", r.color),
            viewBox: "0 0 20 20",
            fill: "currentColor",
            children: (0, q.jsx)("path", {
                fillRule: "evenodd",
                d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z",
                clipRule: "evenodd"
            })
        }), "idle" === e && (0, q.jsx)("div", {
            className: eJ("w-2 h-2 rounded-full", r.color.replace("text-", "bg-"))
        }), (0, q.jsx)("span", {
            className: eJ("text-sm font-medium", r.color),
            children: t || r.label
        })]
    })
}
e.i(47167);
var aK = Symbol.for("immer-nothing"),
    aH = Symbol.for("immer-draftable"),
    aW = Symbol.for("immer-state");

function aq(e) {
    throw Error(`[Immer] minified error nr: ${e}. Full error at: https://bit.ly/3cXEKWf`)
}
var aG = Object,
    aY = aG.getPrototypeOf,
    aZ = "constructor",
    aX = "prototype",
    aQ = "configurable",
    aJ = "enumerable",
    a0 = "writable",
    a1 = "value",
    a2 = e => !!e && !!e[aW];

function a5(e) {
    return !!e && (a8(e) || or(e) || !!e[aH] || !!e[aZ]?.[aH] || on(e) || oi(e))
}
var a3 = aG[aX][aZ].toString(),
    a4 = new WeakMap;

function a8(e) {
    if (!e || !oa(e)) return !1;
    let t = aY(e);
    if (null === t || t === aG[aX]) return !0;
    let r = aG.hasOwnProperty.call(t, aZ) && t[aZ];
    if (r === Object) return !0;
    if (!oo(r)) return !1;
    let n = a4.get(r);
    return void 0 === n && (n = Function.toString.call(r), a4.set(r, n)), n === a3
}

function a6(e, t, r = !0) {
    0 === a7(e) ? (r ? Reflect.ownKeys(e) : aG.keys(e)).forEach(r => {
        t(r, e[r], e)
    }) : e.forEach((r, n) => t(n, r, e))
}

function a7(e) {
    let t = e[aW];
    return t ? t.type_ : or(e) ? 1 : on(e) ? 2 : 3 * !!oi(e)
}
var a9 = (e, t, r = a7(e)) => 2 === r ? e.has(t) : aG[aX].hasOwnProperty.call(e, t),
    oe = (e, t, r = a7(e)) => 2 === r ? e.get(t) : e[t],
    ot = (e, t, r, n = a7(e)) => {
        2 === n ? e.set(t, r) : 3 === n ? e.add(r) : e[t] = r
    },
    or = Array.isArray,
    on = e => e instanceof Map,
    oi = e => e instanceof Set,
    oa = e => "object" == typeof e,
    oo = e => "function" == typeof e,
    os = e => e.modified_ ? e.copy_ : e.base_;

function ol(e, t) {
    if (on(e)) return new Map(e);
    if (oi(e)) return new Set(e);
    if (or(e)) return Array[aX].slice.call(e);
    let r = a8(e);
    if (!0 !== t && ("class_only" !== t || r)) {
        let t = aY(e);
        if (null !== t && r) return {
            ...e
        };
        let n = aG.create(t);
        return aG.assign(n, e)
    } {
        let t = aG.getOwnPropertyDescriptors(e);
        delete t[aW];
        let r = Reflect.ownKeys(t);
        for (let n = 0; n < r.length; n++) {
            let i = r[n],
                a = t[i];
            !1 === a[a0] && (a[a0] = !0, a[aQ] = !0), (a.get || a.set) && (t[i] = {
                [aQ]: !0,
                [a0]: !0,
                [aJ]: a[aJ],
                [a1]: e[i]
            })
        }
        return aG.create(aY(e), t)
    }
}

function oc(e, t = !1) {
    return od(e) || a2(e) || !a5(e) || (a7(e) > 1 && aG.defineProperties(e, {
        set: ou,
        add: ou,
        clear: ou,
        delete: ou
    }), aG.freeze(e), t && a6(e, (e, t) => {
        oc(t, !0)
    }, !1)), e
}
var ou = {
    [a1]: function() {
        aq(2)
    }
};

function od(e) {
    return !(null !== e && oa(e)) || aG.isFrozen(e)
}
var of = "MapSet", op = "Patches", om = "ArrayMethods", oh = {};

function og(e) {
    let t = oh[e];
    return t || aq(0, e), t
}
var ov = e => !!oh[e];

function oy(e, t) {
    t && (e.patchPlugin_ = og(op), e.patches_ = [], e.inversePatches_ = [], e.patchListener_ = t)
}

function ox(e) {
    ob(e), e.drafts_.forEach(oj), e.drafts_ = null
}

function ob(e) {
    e === h && (h = e.parent_)
}
var ow = e => h = {
    drafts_: [],
    parent_: h,
    immer_: e,
    canAutoFreeze_: !0,
    unfinalizedDrafts_: 0,
    handledSet_: new Set,
    processedForPatches_: new Set,
    mapSetPlugin_: ov(of) ? og(of) : void 0,
    arrayMethodsPlugin_: ov(om) ? og(om) : void 0
};

function oj(e) {
    let t = e[aW];
    0 === t.type_ || 1 === t.type_ ? t.revoke_() : t.revoked_ = !0
}

function oO(e, t) {
    t.unfinalizedDrafts_ = t.drafts_.length;
    let r = t.drafts_[0];
    if (void 0 !== e && e !== r) {
        r[aW].modified_ && (ox(t), aq(4)), a5(e) && (e = oN(t, e));
        let {
            patchPlugin_: n
        } = t;
        n && n.generateReplacementPatches_(r[aW].base_, e, t)
    } else e = oN(t, r);
    return function(e, t, r = !1) {
        !e.parent_ && e.immer_.autoFreeze_ && e.canAutoFreeze_ && oc(t, r)
    }(t, e, !0), ox(t), t.patches_ && t.patchListener_(t.patches_, t.inversePatches_), e !== aK ? e : void 0
}

function oN(e, t) {
    if (od(t)) return t;
    let r = t[aW];
    if (!r) return oC(t, e.handledSet_, e);
    if (!oS(r, e)) return t;
    if (!r.modified_) return r.base_;
    if (!r.finalized_) {
        let {
            callbacks_: t
        } = r;
        if (t)
            for (; t.leng