function EC({
    title: e,
    data: t,
    onClose: r
}) {
    return (0, q.jsx)("div", {
        className: "fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4",
        children: (0, q.jsxs)("div", {
            className: "bg-gradient-to-br from-white via-gray-50 to-gray-100 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 rounded-2xl shadow-2xl max-w-2xl w-full max-h-[80vh] overflow-hidden border border-gray-200 dark:border-gray-700",
            children: [(0, q.jsxs)("div", {
                className: "flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-primary/10 to-primary/5",
                children: [(0, q.jsx)("h3", {
                    className: "font-bold text-lg text-foreground",
                    children: e
                }), (0, q.jsx)("button", {
                    onClick: r,
                    className: "p-2 hover:bg-white/50 dark:hover:bg-black/30 rounded-lg transition-all",
                    children: (0, q.jsx)(ak, {
                        className: "h-5 w-5"
                    })
                })]
            }), (0, q.jsx)("div", {
                className: "p-6 overflow-auto max-h-[60vh]",
                children: (0, q.jsxs)("table", {
                    className: "w-full text-sm",
                    children: [(0, q.jsx)("thead", {
                        children: (0, q.jsx)("tr", {
                            className: "border-b border-gray-200 dark:border-gray-700",
                            children: Object.keys(t[0] || {}).map(e => (0, q.jsx)("th", {
                                className: "text-left p-3 font-semibold text-muted-foreground bg-gray-50 dark:bg-gray-800/50",
                                children: e.charAt(0).toUpperCase() + e.slice(1)
                            }, e))
                        })
                    }), (0, q.jsx)("tbody", {
                        children: t.map((e, t) => (0, q.jsx)("tr", {
                            className: "border-b border-gray-100 dark:border-gray-800 hover:bg-gradient-to-r hover:from-primary/5 hover:to-transparent transition-all",
                            children: Object.values(e).map((e, t) => (0, q.jsx)("td", {
                                className: "p-3 text-foreground font-medium",
                                children: "number" == typeof e ? e.toLocaleString() : String(e)
                            }, t))
                        }, t))
                    })]
                })
            })]
        })
    })
}

function EI() {
    let [e, t] = (0, G.useState)(!1);
    return (0, q.jsxs)(q.Fragment, {
        children: [(0, q.jsxs)(ap, {
            className: "bg-gradient-to-br from-white via-gray-50 to-white dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 shadow-md border-gray-200 dark:border-gray-700",
            children: [(0, q.jsx)(am, {
                className: "pb-2",
                children: (0, q.jsxs)("div", {
                    className: "flex items-center justify-between",
                    children: [(0, q.jsx)(ah, {
                        className: "text-sm font-semibold",
                        children: "Order Processing Trend"
                    }), (0, q.jsxs)("button", {
                        onClick: () => t(!0),
                        className: "text-xs text-primary flex items-center hover:underline",
                        children: ["Drill Down ", (0, q.jsx)(i8, {
                            className: "h-3 w-3"
                        })]
                    })]
                })
            }), (0, q.jsxs)(av, {
                children: [(0, q.jsx)(uN, {
                    width: "100%",
                    height: 200,
                    children: (0, q.jsxs)(EA, {
                        data: aD,
                        children: [(0, q.jsx)(k9, {
                            strokeDasharray: "3 3",
                            stroke: "#e5e7eb"
                        }), (0, q.jsx)(k_, {
                            dataKey: "month",
                            tick: {
                                fontSize: 11
                            },
                            stroke: "#9ca3af"
                        }), (0, q.jsx)(kH, {
                            tick: {
                                fontSize: 11
                            },
                            stroke: "#9ca3af"
                        }), (0, q.jsx)(ST, {
                            contentStyle: {
                                backgroundColor: "white",
                                border: "1px solid #e5e7eb",
                                borderRadius: "8px",
                                fontSize: "12px"
                            }
                        }), (0, q.jsx)(EP, {
                            type: "monotone",
                            dataKey: "automated",
                            stackId: "1",
                            stroke: "#22c55e",
                            fill: "#22c55e",
                            fillOpacity: .6,
                            name: "Automated"
                        }), (0, q.jsx)(EP, {
                            type: "monotone",
                            dataKey: "manual",
                            stackId: "1",
                            stroke: "#f59e0b",
                            fill: "#f59e0b",
                            fillOpacity: .6,
                            name: "Manual"
                        })]
                    })
                }), (0, q.jsxs)("div", {
                    className: "flex items-center justify-center gap-4 mt-2 text-xs",
                    children: [(0, q.jsxs)("div", {
                        className: "flex items-center gap-1",
                        children: [(0, q.jsx)("div", {
                            className: "w-3 h-3 rounded bg-[#22c55e]"
                        }), (0, q.jsx)("span", {
                            className: "text-muted-foreground",
                            children: "Automated"
                        })]
                    }), (0, q.jsxs)("div", {
                        className: "flex items-center gap-1",
                        children: [(0, q.jsx)("div", {
                            className: "w-3 h-3 rounded bg-[#f59e0b]"
                        }), (0, q.jsx)("span", {
                            className: "text-muted-foreground",
                            children: "Manual"
                        })]
                    })]
                })]
            })]
        }), e && (0, q.jsx)(EC, {
            title: "Order Processing Details",
            data: aD.map(e => ({
                Month: e.month,
                "Total Orders": e.orders,
                Automated: e.automated,
                Manual: e.manual,
                "Automation %": `${(e.automated/e.orders*100).toFixed(1)}%`
            })),
            onClose: () => t(!1)
        })]
    })
}

function EM() {
    let [e, t] = (0, G.useState)(!1), r = aR.reduce((e, t) => e + t.value, 0);
    return (0, q.jsxs)(q.Fragment, {
        children: [(0, q.jsxs)(ap, {
            className: "bg-gradient-to-br from-white via-gray-50 to-white dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 shadow-md border-gray-200 dark:border-gray-700",
            children: [(0, q.jsx)(am, {
                className: "pb-2",
                children: (0, q.jsxs)("div", {
                    className: "flex items-center justify-between",
                    children: [(0, q.jsx)(ah, {
                        className: "text-sm font-semibold",
                        children: "Exception Breakdown"
                    }), (0, q.jsxs)("button", {
                        onClick: () => t(!0),
                        className: "text-xs text-primary flex items-center hover:underline",
                        children: ["Drill Down ", (0, q.jsx)(i8, {
                            className: "h-3 w-3"
                        })]
                    })]
                })
            }), (0, q.jsxs)(av, {
                children: [(0, q.jsx)(uN, {
                    width: "100%",
                    height: 200,
                    children: (0, q.jsxs)(SK, {
                        children: [(0, q.jsx)(Py, {
                            isAnimationActive: !0,
                            animationDuration: 1000,
                            animationBegin: 0,
                            data: aR,
                            cx: "50%",
                            cy: "50%",
                            innerRadius: 50,
                            outerRadius: 75,
                            paddingAngle: 2,
                            dataKey: "value",
                            children: aR.map((e, t) => (0, q.jsx)(wd, {
                                fill: e.color
                            }, `cell-${t}`))
                        }), (0, q.jsx)(ST, {
                            contentStyle: {
                                backgroundColor: "white",
                                border: "1px solid #e5e7eb",
                                borderRadius: "8px",
                                fontSize: "12px"
                            },
                            formatter: e => [`${e} (${(e/r*100).toFixed(0)}%)`, ""]
                        })]
                    })
                }), (0, q.jsx)("div", {
                    className: "flex flex-wrap justify-center gap-2 mt-2",
                    children: aR.map(e => (0, q.jsxs)("div", {
                        className: "flex items-center gap-1 text-xs",
                        children: [(0, q.jsx)("div", {
                            className: "w-2 h-2 rounded-full",
                            style: {
                                backgroundColor: e.color
                            }
                        }), (0, q.jsx)("span", {
                            className: "text-muted-foreground",
                            children: e.name
                        })]
                    }, e.name))
                })]
            })]
        }), e && (0, q.jsx)(EC, {
            title: "Exception Details",
            data: aR.map(e => ({
                Type: e.name,
                Count: e.value,
                Percentage: `${(e.value/r*100).toFixed(1)}%`,
                Status: e.value > 20 ? "High" : e.value > 15 ? "Medium" : "Low"
            })),
            onClose: () => t(!1)
        })]
    })
}

function ET() {
    let [e, t] = (0, G.useState)(!1), r = aL[aL.length - 1], n = aL[aL.length - 2], i = r.dso - n.dso;
    return (0, q.jsxs)(q.Fragment, {
        children: [(0, q.jsxs)(ap, {
            className: "bg-gradient-to-br from-white via-gray-50 to-white dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 shadow-md border-gray-200 dark:border-gray-700",
            children: [(0, q.jsx)(am, {
                className: "pb-2",
                children: (0, q.jsxs)("div", {
                    className: "flex items-center justify-between",
                    children: [(0, q.jsxs)("div", {
                        className: "flex items-center gap-2",
                        children: [(0, q.jsx)(ah, {
                            className: "text-sm font-semibold",
                            children: "DSO Trend"
                        }), (0, q.jsxs)(ar, {
                            variant: "outline",
                            className: i < 0 ? "text-[var(--success)]" : "text-primary",
                            children: [i < 0 ? (0, q.jsx)(ax, {
                                className: "h-3 w-3 mr-1"
                            }) : (0, q.jsx)(ay, {
                                className: "h-3 w-3 mr-1"
                            }), Math.abs(i), " days"]
                        })]
                    }), (0, q.jsxs)("button", {
                        onClick: () => t(!0),
                        className: "text-xs text-primary flex items-center hover:underline",
                        children: ["Drill Down ", (0, q.jsx)(i8, {
                            className: "h-3 w-3"
                        })]
                    })]
                })
            }), (0, q.jsx)(av, {
                children: (0, q.jsx)(uN, {
                    width: "100%",
                    height: 200,
                    children: (0, q.jsxs)(Pb, {
                        data: aL,
                        children: [(0, q.jsx)(k9, {
                            strokeDasharray: "3 3",
                            stroke: "#e5e7eb"
                        }), (0, q.jsx)(k_, {
                            dataKey: "month",
                            tick: {
                                fontSize: 11
                            },
                            stroke: "#9ca3af"
                        }), (0, q.jsx)(kH, {
                            domain: [30, 50],
                            tick: {
                                fontSize: 11
                            },
                            stroke: "#9ca3af"
                        }), (0, q.jsx)(ST, {
                            contentStyle: {
                                backgroundColor: "white",
                                border: "1px solid #e5e7eb",
                                borderRadius: "8px",
                                fontSize: "12px"
                            }
                        }), (0, q.jsx)(P6, {
                            type: "monotone",
                            dataKey: "dso",
                            stroke: "#ef4444",
                            strokeWidth: 2,
                            dot: {
                                fill: "#ef4444",
                                strokeWidth: 2
                            },
                            name: "Actual DSO"
                        }), (0, q.jsx)(P6, {
                            type: "monotone",
                            dataKey: "target",
                            stroke: "#22c55e",
                            strokeWidth: 2,
                            strokeDasharray: "5 5",
                            dot: !1,
                            name: "Target"
                        })]
                    })
                })
            })]
        }), e && (0, q.jsx)(EC, {
            title: "DSO Analysis",
            data: aL.map(e => ({
                Month: e.month,
                "Actual DSO": `${e.dso} days`,
                Target: `${e.target} days`,
                Variance: `${e.dso-e.target} days`,
                Status: e.dso <= e.target ? "On Target" : "Above Target"
            })),
            onClose: () => t(!1)
        })]
    })
}

function E_() {
    let [e, t] = (0, G.useState)(!1);
    return (0, q.jsxs)(q.Fragment, {
        children: [(0, q.jsxs)(ap, {
            className: "bg-gradient-to-br from-white via-gray-50 to-white dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 shadow-md border-gray-200 dark:border-gray-700",
            children: [(0, q.jsx)(am, {
                className: "pb-2",
                children: (0, q.jsxs)("div", {
                    className: "flex items-center justify-between",
                    children: [(0, q.jsx)(ah, {
                        className: "text-sm font-semibold",
                        children: "AI Agent Performance"
                    }), (0, q.jsxs)("button", {
                        onClick: () => t(!0),
                        className: "text-xs text-primary flex items-center hover:underline",
                        children: ["Drill Down ", (0, q.jsx)(i8, {
                            className: "h-3 w-3"
                        })]
                    })]
                })
            }), (0, q.jsx)(av, {
                children: (0, q.jsx)(uN, {
                    width: "100%",
                    height: 200,
                    children: (0, q.jsxs)(wo, {
                        data: az,
                        layout: "vertical",
                        children: [(0, q.jsx)(k9, {
                            strokeDasharray: "3 3",
                            stroke: "#e5e7eb"
                        }), (0, q.jsx)(k_, {
                            type: "number",
                            tick: {
                                fontSize: 11
                            },
                            stroke: "#9ca3af"
                        }), (0, q.jsx)(kH, {
                            dataKey: "agent",
                            type: "category",
                            tick: {
                                fontSize: 10
                            },
                            width: 70,
                            stroke: "#9ca3af"
                        }), (0, q.jsx)(ST, {
                            contentStyle: {
                                backgroundColor: "white",
                                border: "1px solid #e5e7eb",
                                borderRadius: "8px",
                                fontSize: "12px"
                            }
                        }), (0, q.jsx)(ke, {
                            dataKey: "processed",
                            fill: "#e5e7eb",
                            name: "Processed",
                            radius: [0, 4, 4, 0]
                        }), (0, q.jsx)(ke, {
                            dataKey: "success",
                            fill: "#22c55e",
                            name: "Successful",
                            radius: [0, 4, 4, 0]
                        })]
                    })
                })
            })]
        }), e && (0, q.jsx)(EC, {
            title: "Agent Performance Details",
            data: az.map(e => ({
                Agent: e.agent,
                Processed: e.processed,
                Successful: e.success,
                "Success Rate": `${(e.success/e.processed*100).toFixed(1)}%`,
                Failed: e.processed - e.success
            })),
            onClose: () => t(!1)
        })]
    })
}
let ED = Q("MessageCircle", [
        ["path", {
            d: "M7.9 20A9 9 0 1 0 4 16.1L2 22Z",
            key: "vv11sd"
        }]
    ]),
    ER = Q("Send", [
        ["path", {
            d: "M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z",
            key: "1ffxy3"
        }],
        ["path", {
            d: "m21.854 2.147-10.94 10.939",
            key: "12cjpa"
        }]
    ]),
    EL = Q("Bot", [
        ["path", {
            d: "M12 8V4H8",
            key: "hb8ula"
        }],
        ["rect", {
            width: "16",
            height: "12",
            x: "4",
            y: "8",
            rx: "2",
            key: "enze0r"
        }],
        ["path", {
            d: "M2 14h2",
            key: "vft8re"
        }],
        ["path", {
            d: "M20 14h2",
            key: "4cs60a"
        }],
        ["path", {
            d: "M15 13v2",
            key: "1xurst"
        }],
        ["path", {
            d: "M9 13v2",
            key: "rq6x2g"
        }]
    ]),
    Ez = Q("User", [
        ["path", {
            d: "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",
            key: "975kel"
        }],
        ["circle", {
            cx: "12",
            cy: "7",
            r: "4",
            key: "17ys0d"
        }]
    ]),
    EB = Q("LoaderCircle", [
        ["path", {
            d: "M21 12a9 9 0 1 1-6.219-8.56",
            key: "13zald"
        }]
    ]),
    E$ = Q("Minimize2", [
        ["polyline", {
            points: "4 14 10 14 10 20",
            key: "11kfnr"
        }],
        ["polyline", {
            points: "20 10 14 10 14 4",
            key: "rlmsce"
        }],
        ["line", {
            x1: "14",
            x2: "21",
            y1: "10",
            y2: "3",
            key: "o5lafz"
        }],
        ["line", {
            x1: "3",
            x2: "10",
            y1: "21",
            y2: "14",
            key: "1atl0r"
        }]
    ]),
    EF = Q("Maximize2", [
        ["polyline", {
            points: "15 3 21 3 21 9",
            key: "mznyad"
        }],
        ["polyline", {
            points: "9 21 3 21 3 15",
            key: "1avn1i"
        }],
        ["line", {
            x1: "21",
            x2: "14",
            y1: "3",
            y2: "10",
            key: "ota7mn"
        }],
        ["line", {
            x1: "3",
            x2: "10",
            y1: "21",
            y2: "14",
            key: "1atl0r"
        }]
    ]),
    EV = Q("ExternalLink", [
        ["path", {
            d: "M15 3h6v6",
            key: "1q9fwt"
        }],
        ["path", {
            d: "M10 14 21 3",
            key: "gplh6r"
        }],
        ["path", {
            d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",
            key: "a6xqqp"
        }]
    ]),
    EU = ["What is the current DSO?", "Show me orders on hold", "Where is SO-710245 stuck?", "What's the automation rate?"];