function Ai({
    onResolveException: e,
    onResolveWithAI: t,
    completedOrderIds: r = []
}) {
    let [n, i] = (0, G.useState)(null), [a, o] = (0, G.useState)({}), [s, l] = (0, G.useState)([]);
    (0, G.useEffect)(() => {
        let e = setInterval(() => {
            o(e => {
                let t = {
                    ...e
                };
                return Object.keys(t).forEach(e => {
                    t[e] < 100 && (t[e] = Math.min(t[e] + 20 * Math.random(), 100), t[e] >= 100 && l(t => [...t, e]))
                }), t
            })
        }, 400);
        return () => clearInterval(e)
    }, []);
    let c = e => {
            switch (e) {
                case "Credit Hold":
                    return "credit";
                case "Delivery Delay":
                    return "atp";
                case "Pricing Mismatch":
                    return "pricing";
                case "Document Missing":
                    return "document";
                default:
                    return "validation"
            }
        },
        u = [...s, ...r],
        d = aM.filter(e => "Open" === e.status && !u.includes(e.id) && !u.includes(e.orderId)),
        f = aM.filter(e => "In Progress" === e.status || void 0 !== a[e.id]);
    return (0, q.jsxs)("div", {
        className: "space-y-6",
        children: [(0, q.jsxs)("div", {
            className: "flex items-center justify-between",
            children: [(0, q.jsxs)("div", {
                children: [(0, q.jsx)("h2", {
                    className: "text-lg font-bold text-foreground",
                    children: "Exceptions"
                }), (0, q.jsx)("p", {
                    className: "text-muted-foreground",
                    children: "Manage and resolve order exceptions with AI assistance"
                })]
            }), (0, q.jsxs)("div", {
                className: "flex gap-2",
                children: [(0, q.jsxs)(ar, {
                    variant: "outline",
                    className: "text-primary border-primary gap-1",
                    children: [(0, q.jsx)(a$, {
                        type: "validation",
                        size: "sm"
                    }), d.length, " Open"]
                }), (0, q.jsxs)(ar, {
                    variant: "outline",
                    className: "text-[var(--warning)] border-[var(--warning)] gap-1",
                    children: [(0, q.jsx)(aF, {
                        size: "sm"
                    }), f.length, " In Progress"]
                })]
            })]
        }), (0, q.jsx)("div", {
            className: "grid grid-cols-4 gap-4",
            children: ["Credit Hold", "Delivery Delay", "Pricing Mismatch", "Document Missing"].map(e => {
                let t = aM.filter(t => t.type === e && !s.includes(t.id)).length,
                    r = c(e);
                return (0, q.jsx)(ap, {
                    className: "bg-card",
                    children: (0, q.jsx)(av, {
                        className: "p-4",
                        children: (0, q.jsxs)("div", {
                            className: "flex items-center gap-3",
                            children: [(0, q.jsx)("div", {
                                className: eJ("p-2 rounded-lg", t > 0 ? "bg-primary/10" : "bg-muted"),
                                children: (0, q.jsx)(a$, {
                                    type: r,
                                    size: "sm",
                                    className: t > 0 ? "text-primary" : "text-muted-foreground"
                                })
                            }), (0, q.jsxs)("div", {
                                children: [(0, q.jsx)("div", {
                                    className: "text-2xl font-bold",
                                    children: t
                                }), (0, q.jsx)("div", {
                                    className: "text-xs text-muted-foreground",
                                    children: e
                                })]
                            })]
                        })
                    })
                }, e)
            })
        }), (0, q.jsxs)("div", {
            className: "grid lg:grid-cols-3 gap-6",
            children: [(0, q.jsx)("div", {
                className: "lg:col-span-2 space-y-4",
                children: aM.map(e => {
                    let t = c(e.type),
                        o = void 0 !== a[e.id] && a[e.id] < 100,
                        l = s.includes(e.id) || r.includes(e.orderId),
                        u = a[e.id] || 0;
                    return (0, q.jsx)(ap, {
                        className: eJ("cursor-pointer transition-all hover:shadow-md", n?.id === e.id && "ring-2 ring-primary", o && "bg-[var(--info)]/5", l && "bg-[var(--success)]/5 opacity-75"),
                        onClick: () => i(e),
                        children: (0, q.jsx)(av, {
                            className: "p-4",
                            children: (0, q.jsxs)("div", {
                                className: "flex items-start gap-4",
                                children: [(0, q.jsx)("div", {
                                    className: eJ("flex h-10 w-10 items-center justify-center rounded-lg", l ? "bg-[var(--success)]/10 text-[var(--success)]" : "High" === e.severity ? "bg-primary/10 text-primary" : "Medium" === e.severity ? "bg-[var(--warning)]/10 text-[var(--warning)]" : "bg-[var(--info)]/10 text-[var(--info)]"),
                                    children: o ? (0, q.jsx)(aF, {
                                        size: "sm"
                                    }) : l ? (0, q.jsx)(aB, {
                                        className: "h-5 w-5"
                                    }) : (0, q.jsx)(a$, {
                                        type: t,
                                        size: "sm"
                                    })
                                }), (0, q.jsxs)("div", {
                                    className: "flex-1",
                                    children: [(0, q.jsxs)("div", {
                                        className: "flex items-center gap-2 mb-1",
                                        children: [(0, q.jsx)("span", {
                                            className: "font-semibold text-foreground",
                                            children: e.type
                                        }), !l && (0, q.jsx)(ar, {
                                            className: (e => {
                                                switch (e) {
                                                    case "High":
                                                        return "bg-primary text-primary-foreground";
                                                    case "Medium":
                                                        return "bg-[var(--warning)] text-[var(--warning-foreground)]";
                                                    case "Low":
                                                        return "bg-[var(--info)] text-white";
                                                    default:
                                                        return "bg-muted text-muted-foreground"
                                                }
                                            })(e.severity),
                                            children: e.severity
                                        }), (0, q.jsx)(ar, {
                                            variant: "outline",
                                            className: l ? "bg-[var(--success)]/10 text-[var(--success)]" : (e => {
                                                switch (e) {
                                                    case "Open":
                                                        return "bg-primary/10 text-primary border-primary/20";
                                                    case "In Progress":
                                                        return "bg-[var(--warning)]/10 text-[var(--warning)] border-[var(--warning)]/20";
                                                    case "Resolved":
                                                        return "bg-[var(--success)]/10 text-[var(--success)] border-[var(--success)]/20";
                                                    default:
                                                        return "bg-muted text-muted-foreground"
                                                }
                                            })(e.status),
                                            children: l ? "Resolved" : e.status
                                        })]
                                    }), (0, q.jsx)("p", {
                                        className: "text-sm text-muted-foreground mb-2",
                                        children: e.description
                                    }), o && (0, q.jsx)("div", {
                                        className: "mb-2",
                                        children: (0, q.jsx)(aV, {
                                            progress: u,
                                            label: "AI Agent Processing...",
                                            color: "info"
                                        })
                                    }), (0, q.jsxs)("div", {
                                        className: "flex items-center gap-4 text-xs text-muted-foreground",
                                        children: [(0, q.jsx)("span", {
                                            className: "font-mono",
                                            children: e.orderId
                                        }), (0, q.jsx)("span", {
                                            children: e.customerName
                                        }), (0, q.jsxs)("span", {
                                            className: "flex items-center gap-1",
                                            children: [(0, q.jsx)(Ez, {
                                                className: "h-3 w-3"
                                            }), e.assignedTo]
                                        })]
                                    })]
                                }), (0, q.jsx)(EY, {
                                    className: "h-5 w-5 text-muted-foreground"
                                })]
                            })
                        })
                    }, e.id)
                })
            }), (0, q.jsx)("div", {
                children: n ? (0, q.jsxs)(ap, {
                    className: "sticky top-24",
                    children: [(0, q.jsx)(am, {
                        children: (0, q.jsxs)(ah, {
                            className: "text-lg flex items-center gap-2",
                            children: [(0, q.jsx)(a$, {
                                type: c(n.type),
                                size: "sm",
                                className: "text-primary"
                            }), "Exception Details"]
                        })
                    }), (0, q.jsxs)(av, {
                        className: "space-y-4",
                        children: [(0, q.jsxs)("div", {
                            children: [(0, q.jsx)("div", {
                                className: "text-sm text-muted-foreground",
                                children: "Type"
                            }), (0, q.jsx)("div", {
                                className: "font-medium text-foreground",
                                children: n.type
                            })]
                        }), (0, q.jsxs)("div", {
                            children: [(0, q.jsx)("div", {
                                className: "text-sm text-muted-foreground",
                                children: "Order"
                            }), (0, q.jsx)("div", {
                                className: "font-mono text-foreground",
                                children: n.orderId
                            })]
                        }), (0, q.jsxs)("div", {
                            children: [(0, q.jsx)("div", {
                                className: "text-sm text-muted-foreground",
                                children: "Customer"
                            }), (0, q.jsx)("div", {
                                className: "text-foreground",
                                children: n.customerName
                            })]
                        }), (0, q.jsxs)("div", {
                            children: [(0, q.jsx)("div", {
                                className: "text-sm text-muted-foreground",
                                children: "Description"
                            }), (0, q.jsx)("div", {
                                className: "text-sm text-foreground",
                                children: n.description
                            })]
                        }), (0, q.jsxs)("div", {
                            children: [(0, q.jsx)("div", {
                                className: "text-sm text-muted-foreground",
                                children: "Assigned To"
                            }), (0, q.jsxs)("div", {
                                className: "flex items-center gap-2",
                                children: [(0, q.jsx)("div", {
                                    className: "h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center",
                                    children: (0, q.jsx)(Ez, {
                                        className: "h-3 w-3 text-primary"
                                    })
                                }), (0, q.jsx)("span", {
                                    className: "text-foreground",
                                    children: n.assignedTo
                                })]
                            })]
                        }), (0, q.jsxs)("div", {
                            children: [(0, q.jsx)("div", {
                                className: "text-sm text-muted-foreground",
                                children: "Created"
                            }), (0, q.jsxs)("div", {
                                className: "flex items-center gap-1 text-foreground",
                                children: [(0, q.jsx)(EQ, {
                                    className: "h-4 w-4 text-muted-foreground"
                                }), new Date(n.createdAt).toLocaleString()]
                            })]
                        }), (0, q.jsxs)("div", {
                            className: "p-3 bg-muted/50 rounded-lg",
                            children: [(0, q.jsxs)("div", {
                                className: "flex items-center gap-2 mb-2",
                                children: [(0, q.jsx)(a$, {
                                    type: "orchestrator",
                                    size: "sm",
                                    className: "text-primary"
                                }), (0, q.jsx)("span", {
                                    className: "text-sm font-medium",
                                    children: "AI Recommendation"
                                })]
                            }), (0, q.jsx)("p", {
                                className: "text-xs text-muted-foreground",
                                children: (e => {
                                    switch (e.type) {
                                        case "Credit Hold":
                                            return `Based on ${e.customerName}'s payment history (92% on-time) and current exposure ratio of 97%, recommend conditional release with 20% prepayment and accelerated dunning schedule.`;
                                        case "Delivery Delay":
                                            return "Carrier capacity issue detected. Recommend switching to alternate carrier (FedEx Priority) with 2-day delivery guarantee. Customer notification template ready for approval.";
                                        case "Pricing Mismatch":
                                            return "Contract price variance of 8% detected. Historical analysis shows this customer received promotional pricing in Q3. Recommend honoring contract rate and flagging for renewal review.";
                                        case "Document Missing":
                                            return "POD not received within SLA. Carrier API shows delivery confirmed. Recommend auto-generating POD from GPS/signature data and triggering billing release.";
                                        case "ATP Failure":
                                            return "Inventory shortfall of 150 units. Safety stock available at alternate DC. Recommend inter-warehouse transfer with 3-day lead time to fulfill order.";
                                        default:
                                            return "AI analysis in progress. Gathering additional context from related systems."
                                    }
                                })(n)
                            })]
                        }), (0, q.jsxs)("div", {
                            className: "pt-4 space-y-2",
                            children: [r.includes(n.orderId) || s.includes(n.id) ? (0, q.jsxs)("div", {
                                className: "w-full flex items-center justify-center gap-2 py-2 rounded-md bg-[var(--success)]/10 text-[var(--success)] text-sm font-medium",
                                children: [(0, q.jsx)(aB, {
                                    className: "h-4 w-4"
                                }), "Processed & Complete"]
                            }) : "SO-710245" === n.orderId && t ? (0, q.jsxs)(e1, {
                                className: "w-full",
                                onClick: () => t(n.orderId),
                                children: [(0, q.jsx)(E1, {
                                    className: "h-4 w-4 mr-2"
                                }), "Resolve with AI"]
                            }) : (0, q.jsx)(e1, {
                                className: "w-full",
                                onClick: () => {
                                    var e;
                                    return e = n.id, void o(t => ({
                                        ...t,
                                        [e]: 0
                                    }))
                                },
                                disabled: void 0 !== a[n.id],
                                children: void 0 !== a[n.id] && a[n.id] < 100 ? (0, q.jsxs)(q.Fragment, {
                                    children: [(0, q.jsx)(aF, {
                                        size: "sm",
                                        className: "mr-2"
                                    }), "AI Processing..."]
                                }) : (0, q.jsxs)(q.Fragment, {
                                    children: [(0, q.jsx)(E1, {
                                        className: "h-4 w-4 mr-2"
                                    }), "Resolve with AI"]
                                })
                            }), (0, q.jsx)(e1, {
                                variant: "outline",
                                className: "w-full bg-transparent",
                                children: "Reassign"
                            })]
                        })]
                    })]
                }) : (0, q.jsx)(ap, {
                    className: "sticky top-24",
                    children: (0, q.jsxs)(av, {
                        className: "p-8 text-center text-muted-foreground",
                        children: [(0, q.jsx)(a$, {
                            type: "validation",
                            size: "lg",
                            className: "mx-auto mb-4 opacity-50"
                        }), (0, q.jsx)("p", {
                            children: "Select an exception to view details"
                        })]
                    })
                })
            })]
        })]
    })
}
var Aa = "Progress",
    [Ao, As] = e3(Aa),
    [Al, Ac] = Ao(Aa),
    Au = G.forwardRef((e, t) => {
        var r, n;
        let {
            __scopeProgress: i,
            value: a = null,
            max: o,
            getValueLabel: s = Ap,
            ...l
        } = e;
        (o || 0 === o) && !Ag(o) && console.error((r = `${o}`, `Invalid prop \`max\` of value \`${r}\` supplied to \`Progress\`. Only numbers greater than 0 are valid max values. Defaulting to \`100\`.`));
        let c = Ag(o) ? o : 100;
        null === a || Av(a, c) || console.error((n = `${a}`, `Invalid prop \`value\` of value \`${n}\` supplied to \`Progress\`. The \`value\` prop must be:
  - a positive number
  - less than the value passed to \`max\` (or 100 if no \`max\` prop is set)
  - \`null\` or \`undefined\` if the progress is indeterminate.

Defaulting to \`null\`.`));
        let u = Av(a, c) ? a : null,
            d = Ah(u) ? s(u, c) : void 0;
        return (0, q.jsx)(Al, {
            scope: i,
            value: u,
            max: c,
            children: (0, q.jsx)(e7.div, {
                "aria-valuemax": c,
                "aria-valuemin": 0,
                "aria-valuenow": Ah(u) ? u : void 0,
                "aria-valuetext": d,
                role: "progressbar",
                "data-state": Am(u, c),
                "data-value": u ?? void 0,
                "data-max": c,
                ...l,
                ref: t
            })
        })
    });
Au.displayName = Aa;
var Ad = "ProgressIndicator",
    Af = G.forwardRef((e, t) => {
        let {
            __scopeProgress: r,
            ...n
        } = e, i = Ac(Ad, r);
        return (0, q.jsx)(e7.div, {
            "data-state": Am(i.value, i.max),
            "data-value": i.value ?? void 0,
            "data-max": i.max,
            ...n,
            ref: t
        })
    });

function Ap(e, t) {
    return `${Math.round(e/t*100)}%`
}

function Am(e, t) {
    return null == e ? "indeterminate" : e === t ? "complete" : "loading"
}

function Ah(e) {
    return "number" == typeof e
}

function Ag(e) {
    return Ah(e) && !isNaN(e) && e > 0
}

function Av(e, t) {
    return Ah(e) && !isNaN(e) && e <= t && e >= 0
}

function Ay({
    className: e,
    value: t,
    ...r
}) {
    return (0, q.jsx)(Au, {
        "data-slot": "progress",
        className: eJ("bg-primary/20 relative h-2 w-full overflow-hidden rounded-full", e),
        ...r,
        children: (0, q.jsx)(Af, {
            "data-slot": "progress-indicator",
            className: "bg-primary h-full w-full flex-1 transition-all",
            style: {
                transform: `translateX(-${100-(t||0)}%)`
            }
        })
    })
}
Af.displayName = Ad;
let Ax = Q("Mail", [
        ["rect", {
            width: "20",
            height: "16",
            x: "2",
            y: "4",
            rx: "2",
            key: "18n3k1"
        }],
        ["path", {
            d: "m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",
            key: "1ocrg3"
        }]
    ]),
    Ab = Q("Phone", [
        ["path", {
            d: "M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z",
            key: "foiqr5"
        }]
    ]),
    Aw = Q("Calendar", [
        ["path", {
            d: "M8 2v4",
            key: "1cmpym"
        }],
        ["path", {
            d: "M16 2v4",
            key: "4m81vk"
        }],
        ["rect", {
            width: "18",
            height: "18",
            x: "3",
            y: "4",
            rx: "2",
            key: "1hopcy"
        }],
        ["path", {
            d: "M3 10h18",
            key: "8toen8"
        }]
    ]);