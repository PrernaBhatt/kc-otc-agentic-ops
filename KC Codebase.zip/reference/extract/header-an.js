function an({
    onLogout: e
}) {
    return (0, q.jsx)("header", {
        className: "sticky top-0 z-50 w-full border-b bg-[var(--header-bg)] border-[var(--header-bg)]",
        children: (0, q.jsxs)("div", {
            className: "flex h-14 items-center justify-between px-6",
            children: [(0, q.jsx)("div", {
                className: "flex items-center gap-4",
                children: (0, q.jsxs)("div", {
                    className: "flex items-center gap-3",
                    children: [(0, q.jsx)("div", {
                        className: "flex h-8 w-8 items-center justify-center rounded bg-red-600",
                        children: (0, q.jsx)("img", {
                            src: "https://cdn-icons-png.flaticon.com/512/4961/4961818.png",
                            alt: "App",
                            width: 20,
                            height: 20
                        })
                    }), (0, q.jsxs)("div", {
                        className: "flex items-center gap-2",
                        children: [(0, q.jsx)("span", {
                            className: "text-base font-semibold text-[var(--header-foreground)]",
                            children: "OTC Workspace"
                        }), (0, q.jsx)(ar, {
                            variant: "outline",
                            className: "bg-[var(--header-bg)] text-[var(--header-foreground)] border-[var(--header-foreground)]/30 text-xs",
                            children: "v2.4.1"
                        })]
                    })]
                })
            }), (0, q.jsxs)("div", {
                className: "flex items-center gap-3",
                children: [(0, q.jsxs)("div", {
                    className: "relative hidden md:block",
                    children: [(0, q.jsx)(ee, {
                        className: "absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--header-foreground)]/50"
                    }), (0, q.jsx)(e2, {
                        placeholder: "Search requests, SKUs, vendors...",
                        className: "w-96 pl-10 bg-[var(--header-bg)] border-[var(--header-foreground)]/20 text-[var(--header-foreground)] placeholder:text-[var(--header-foreground)]/50"
                    })]
                }), (0, q.jsxs)(e1, {
                    variant: "ghost",
                    size: "icon",
                    className: "relative text-[var(--header-foreground)] hover:bg-[var(--header-foreground)]/10",
                    children: [(0, q.jsx)(J, {
                        className: "h-5 w-5"
                    }), (0, q.jsx)("span", {
                        className: "absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[9px] font-medium text-primary-foreground",
                        children: "4"
                    })]
                }), (0, q.jsx)(e1, {
                    variant: "ghost",
                    size: "icon",
                    className: "text-[var(--header-foreground)] hover:bg-[var(--header-foreground)]/10",
                    children: (0, q.jsx)(et, {
                        className: "h-5 w-5"
                    })
                }), (0, q.jsx)(e1, {
                    variant: "ghost",
                    size: "icon",
                    onClick: e,
                    className: "text-[var(--header-foreground)] hover:bg-[var(--header-foreground)]/10",
                    children: (0, q.jsx)(er, {
                        className: "h-5 w-5"
                    })
                }), (0, q.jsxs)(i6, {
                    children: [(0, q.jsx)(i7, {
                        asChild: !0,
                        children: (0, q.jsx)(e1, {
                            variant: "ghost",
                            className: "flex items-center gap-2 text-[var(--header-foreground)] hover:bg-[var(--header-foreground)]/10 h-8 px-2",
                            children: (0, q.jsx)("div", {
                                className: "flex h-7 w-7 items-center justify-center rounded-full bg-primary text-primary-foreground text-sm font-semibold",
                                children: "A"
                            })
                        })
                    }), (0, q.jsxs)(i9, {
                        align: "end",
                        children: [(0, q.jsx)(ae, {
                            children: "Profile"
                        }), (0, q.jsx)(ae, {
                            children: "Preferences"
                        }), (0, q.jsx)(ae, {
                            onClick: e,
                            children: "Sign Out"
                        })]
                    })]
                })]
            })]
        })
    })
}
let ai = Q("LayoutDashboard", [
        ["rect", {
            width: "7",
            height: "9",
            x: "3",
            y: "3",
            rx: "1",
            key: "10lvy0"
        }],
        ["rect", {
            width: "7",
            height: "5",
            x: "14",
            y: "3",
            rx: "1",
            key: "16une8"
        }],
        ["rect", {
            width: "7",
            height: "9",
            x: "14",
            y: "12",
            rx: "1",
            key: "1hutg5"
        }],
        ["rect", {
            width: "7",
            height: "5",
            x: "3",
            y: "16",
            rx: "1",
            key: "ldoo1y"
        }]
    ]),
    aa = Q("Package", [
        ["path", {
            d: "M11 21.73a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73z",
            key: "1a0edw"
        }],
        ["path", {
            d: "M12 22V12",
            key: "d0xqtd"
        }],
        ["path", {
            d: "m3.3 7 7.703 4.734a2 2 0 0 0 1.994 0L20.7 7",
            key: "yx3hmr"
        }],
        ["path", {
            d: "m7.5 4.27 9 5.15",
            key: "1c824w"
        }]
    ]),
    ao = Q("FileText", [
        ["path", {
            d: "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",
            key: "1rqfz7"
        }],
        ["path", {
            d: "M14 2v4a2 2 0 0 0 2 2h4",
            key: "tnqrlb"
        }],
        ["path", {
            d: "M10 9H8",
            key: "b1mrlr"
        }],
        ["path", {
            d: "M16 13H8",
            key: "t4e002"
        }],
        ["path", {
            d: "M16 17H8",
            key: "z1uh3a"
        }]
    ]),
    as = Q("CircleAlert", [
        ["circle", {
            cx: "12",
            cy: "12",
            r: "10",
            key: "1mglay"
        }],
        ["line", {
            x1: "12",
            x2: "12",
            y1: "8",
            y2: "12",
            key: "1pkeuh"
        }],
        ["line", {
            x1: "12",
            x2: "12.01",
            y1: "16",
            y2: "16",
            key: "4dfq90"
        }]
    ]),
    al = Q("MessageSquare", [
        ["path", {
            d: "M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z",
            key: "1lielz"
        }]
    ]),
    ac = Q("Activity", [
        ["path", {
            d: "M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2",
            key: "169zse"
        }]
    ]),
    au = Q("DollarSign", [
            ["line", {
                    x1: "12",
                    x2: "12",
                    y1: "2",
                    y2: "22",