function AI({
    order: e,
    onBack: t,
    onComplete: r
}) {
    let [n, i] = (0, G.useState)(0), [a, o] = (0, G.useState)(!0), [s, l] = (0, G.useState)([]), [c, u] = (0, G.useState)([]), d = (0, G.useRef)(null), f = (0, G.useRef)(null), [p, m] = (0, G.useState)([{
        id: 1,
        name: "Order Data Validation",
        persona: "Order Entry Associate",
        description: "Autonomous agent validates customer details, order items, and business rules",
        status: "pending",
        details: {
            checks: ["Customer ID verified in master data", "Item SKUs validated in catalog", "Quantities within allowed limits", "Delivery date validated", "Payment terms checked"],
            outputs: ["Customer status: Active", "Credit limit: $500,000", "Current exposure: $485,000", "Order total: $125,000", "All items sellable"]
        }
    }, {
        id: 2,
        name: "Pricing Agent",
        persona: "Commercial Team",
        description: "Apply pricing rules, discounts, rebates, and tax calculations",
        status: "pending",
        details: {
            checks: ["Base price from contract", "Volume discounts applied", "Currency conversion rules", "Tax calculations (GST/VAT)", "Promotional offers validated"],
            outputs: ["Prices match contract terms", "5% volume discount applied", "All items priced correctly", "Tax validation complete", "Total with tax: $125,000"]
        }
    }, {
        id: 3,
        name: "Credit Risk Evaluation",
        persona: "Credit Control Team",
        description: "Evaluate credit exposure and determine if order can be approved",
        status: "pending",
        details: {
            checks: ["Outstanding receivables: $350,000", "Open sales orders: $135,000", "New order value: $125,000", "Total exposure: $610,000", "Credit limit: $500,000"],
            outputs: ["Credit exposure exceeds limit", "Exceeded by: $110,000", "Risk score: 0.68 (Medium-High)", "Order placed on CREDIT HOLD", "Notification sent to Credit Team"]
        }
    }, {
        id: 4,
        name: "MOQ Validation",
        persona: "Order Management Team",
        description: "Check minimum order quantity requirements for cost efficiency",
        status: "pending",
        details: {
            checks: ["Line 1: 500 units (MOQ: 100) ✓", "Line 2: 200 units (MOQ: 50) ✓", "Line 3: 50 units (MOQ: 10) ✓", "Line 4: 1000 units (MOQ: 500) ✓", "Line 5: 250 units (MOQ: 100) ✓"],
            outputs: ["All line items meet MOQ", "No MOQ blocks detected", "Validation passed"]
        }
    }, {
        id: 5,
        name: "Human-in-the-Loop Decision",
        persona: "Credit Control Team",
        description: "Credit team reviews AI recommendations and makes final decision",
        status: "pending",
        details: {
            policies: ["Option A: Conditional Release (20% prepayment)", "Option B: Split Shipment (50/50 with COD)", "Option C: Hard Hold (Full prepayment)"],
            outputs: ["AI Recommendation: Option A", "LTV Score: 0.82 (High value customer)", "Churn Risk: Low (0.15)", "Relationship Tier: Gold", "Awaiting human approval"]
        }
    }, {
        id: 6,
        name: "Available-to-Promise (ATP)",
        persona: "Inventory Planner",
        description: "Check inventory availability and schedule fulfillment",
        status: "pending",
        details: {
            checks: ["Query real-time stock levels", "Check reserved vs available stock", "Calculate ATP for requested date", "Determine best fulfillment warehouse", "Plan replenishment if needed"],
            outputs: ["All items available in stock", "Warehouse: Distribution Center 1", "Estimated ship date: Jan 18, 2025", "Delivery date: Jan 22, 2025", "Order ready for fulfillment"]
        }
    }]);
    (0, G.useEffect)(() => {
        d.current && setTimeout(() => {
            d.current?.scrollTo({
                top: d.current.scrollHeight,
                behavior: "smooth"
            })
        }, 100)
    }, [s]), (0, G.useEffect)(() => {
        f.current && setTimeout(() => {
            f.current?.scrollTo({
                top: f.current.scrollHeight,
                behavior: "smooth"
            })
        }, 100)
    }, [c]), (0, G.useEffect)(() => {
        if (!a) return;
        let e = setTimeout(() => {
            if (n < p.length) {
                l(e => [...new Set([...e, n])]), m(e => e.map((e, t) => ({
                    ...e,
                    status: t === n ? "processing" : t < n ? "complete" : e.status
                })));
                let e = p[n];
                u(t => [...t, {
                    timestamp: new Date().toLocaleTimeString(),
                    step: e.name,
                    action: `Started ${e.name}`,
                    status: "success"
                }]), setTimeout(() => {
                    m(e => e.map((e, t) => ({
                        ...e,
                        status: t === n ? 2 === n ? "blocked" : "complete" : t < n ? "complete" : e.status
                    }))), u(t => [...t, {
                        timestamp: new Date().toLocaleTimeString(),
                        step: e.name,
                        action: 2 === n ? "Credit Hold Applied - Awaiting Decision" : `Completed ${e.name}`,
                        status: 2 === n ? "warning" : "success"
                    }]), 2 === n ? o(!1) : n < p.length - 1 ? i(e => e + 1) : o(!1)
                }, 3500)
            }
        }, 0 === n ? 800 : 4500);
        return () => clearTimeout(e)
    }, [n, a, p]);
    let h = () => {
        u(e => [...e, {
            timestamp: new Date().toLocaleTimeString(),
            step: "Credit Control",
            action: "Human approved Option A: Conditional Release",
            status: "success"
        }]), m(e => e.map((e, t) => ({
            ...e,
            status: 2 === t ? "complete" : e.status
        }))), i(3), o(!0)
    };
    return (0, q.jsxs)("div", {
        className: "space-y-6",
        children: [(0, q.jsxs)("div", {
            className: "flex items-center justify-between",
            children: [(0, q.jsxs)("div", {
                className: "flex items-center gap-4",
                children: [(0, q.jsxs)(e1, {
                    variant: "ghost",
                    size: "sm",
                    onClick: () => {
                        r(e.orderId), t()
                    },
                    className: "gap-2",
                    children: [(0, q.jsx)(AC, {
                        className: "h-4 w-4"
                    }), "Back to Orders"]
                }), (0, q.jsxs)("div", {
                    children: [(0, q.jsx)("h2", {
                        className: "text-2xl font-bold text-foreground",
                        children: "Order Processing Flow"
                    }), (0, q.jsxs)("p", {
                        className: "text-muted-foreground",
                        children: ["Order ", e.orderId, " • ", e.customerName]
                    })]
                })]
            }), (0, q.jsx)(ar, {
                variant: "Hold" === e.status ? "destructive" : "default",
                className: "text-sm",
                children: e.status
            })]
        }), (0, q.jsx)(ap, {
            className: "p-6 bg-card",
            children: (0, q.jsx)("div", {
                className: "flex items-center justify-between",
                children: p.map((e, t) => (0, q.jsxs)("div", {
                    className: "flex items-center flex-1",
                    children: [(0, q.jsxs)("div", {
                        className: "flex flex-col items-center gap-2",
                        children: [(0, q.jsx)("div", {
                            className: `w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all ${"complete"===e.status?"bg-green-500 border-green-500 text-white":"processing"===e.status?"bg-blue-500 border-blue-500 text-white animate-pulse":"blocked"===e.status?"bg-amber-500 border-amber-500 text-white":"bg-background border-border text-muted-foreground"}`,
                            children: "complete" === e.status ? (0, q.jsx)(i4, {
                                className: "h-5 w-5"
                            }) : "processing" === e.status ? (0, q.jsx)(EQ, {
                                className: "h-5 w-5"
                            }) : "blocked" === e.status ? (0, q.jsx)(as, {
                                className: "h-5 w-5"
                            }) : (0, q.jsx)("span", {
                                children: e.id
                            })
                        }), (0, q.jsxs)("div", {
                            className: "text-xs text-center max-w-[100px]",
                            children: [(0, q.jsx)("div", {
                                className: "font-medium",
                                children: e.name
                            }), (0, q.jsx)("div", {
                                className: "text-muted-foreground text-[10px]",
                                children: e.persona
                            })]
                        })]
                    }), t < p.length - 1 && (0, q.jsx)("div", {
                        className: `flex-1 h-0.5 mx-2 transition-all ${"complete"===p[t+1].status||"processing"===p[t+1].status||"blocked"===p[t+1].status?"bg-green-500":"bg-border"}`
                    })]
                }, e.id))
            })
        }), (0, q.jsxs)("div", {
            className: "grid grid-cols-3 gap-6",
            children: [(0, q.jsx)("div", {
                className: "col-span-2 flex flex-col",
                children: (0, q.jsx)("div", {
                    ref: d,
                    className: "flex-1 overflow-y-auto pr-2 space-y-4 max-h-[600px]",
                    children: p.map((e, t) => s.includes(t) ? (0, q.jsxs)(ap, {
                        className: `p-6 transition-all animate-in fade-in slide-in-from-bottom-4 duration-500 ${"processing"===e.status?"border-blue-500 border-2 shadow-lg":"blocked"===e.status?"border-amber-500 border-2 shadow-lg":"complete"===e.status?"border-green-500 border":"opacity-60"}`,
                        children: [(0, q.jsxs)("div", {
                            className: "flex items-start justify-between mb-4",
                            children: [(0, q.jsxs)("div", {
                                className: "flex items-center gap-3",
                                children: [(0, q.jsx)("div", {
                                    className: `w-8 h-8 rounded-full flex items-center justify-center ${"complete"===e.status?"bg-green-100 text-green-700":"processing"===e.status?"bg-blue-100 text-blue-700":"blocked"===e.status?"bg-amber-100 text-amber-700":"bg-gray-100 text-gray-700"}`,
                                    children: "complete" === e.status ? (0, q.jsx)(aB, {
                                        className: "h-4 w-4"
                                    }) : "processing" === e.status ? (0, q.jsx)(EQ, {
                                        className: "h-4 w-4 animate-spin"
                                    }) : "blocked" === e.status ? (0, q.jsx)(as, {
                                        className: "h-4 w-4"
                                    }) : (0, q.jsx)("span", {
                                        className: "text-xs font-semibold",
                                        children: e.id
                                    })
                                }), (0, q.jsxs)("div", {
                                    children: [(0, q.jsx)("h3", {
                                        className: "font-semibold text-foreground",
                                        children: e.name
                                    }), (0, q.jsx)("p", {
                                        className: "text-sm text-muted-foreground",
                                        children: e.persona
                                    })]
                                })]
                            }), (0, q.jsx)(ar, {
                                variant: "complete" === e.status ? "default" : "processing" === e.status ? "secondary" : "blocked" === e.status ? "destructive" : "outline",
                                children: e.status
                            })]
                        }), (0, q.jsx)("p", {
                            className: "text-sm text-muted-foreground mb-4",
                            children: e.description
                        }), e.details && (0, q.jsxs)("div", {
                            className: "space-y-3",
                            children: [e.details.checks && (0, q.jsxs)("div", {
                                children: [(0, q.jsx)("h4", {
                                    className: "text-sm font-medium mb-2",
                                    children: "Validation Checks"
                                }), (0, q.jsx)("ul", {
                                    className: "space-y-1",
                                    children: e.details.checks.map((e, t) => (0, q.jsxs)("li", {
                                        className: "text-sm text-muted-foreground flex items-start gap-2",
                                        children: [(0, q.jsx)("span", {
                                            className: "text-green-600 mt-0.5",
                                            children: "✓"
                                        }), e]
                                    }, t))
                                })]
                            }), e.details.outputs && (0, q.jsxs)("div", {
                                children: [(0, q.jsx)("h4", {
                                    className: "text-sm font-medium mb-2",
                                    children: "Outputs"
                                }), (0, q.jsx)("ul", {
                                    className: "space-y-1",
                                    children: e.details.outputs.map((e, t) => (0, q.jsxs)("li", {
                                        className: `text-sm flex items-start gap-2 ${e.includes("HOLD")||e.includes("exceeds")?"text-amber-600 font-medium":"text-muted-foreground"}`,
                                        children: [e.includes("HOLD") || e.includes("exceeds") ? (0, q.jsx)(as, {
                                            className: "h-4 w-4 mt-0.5 flex-shrink-0"
                                        }) : (0, q.jsx)("span", {
                                            className: "text-blue-600 mt-0.5",
                                            children: "→"
                                        }), e]
                                    }, t))
                                })]
                            }), e.details.policies && (0, q.jsxs)("div", {
                                children: [(0, q.jsx)("h4", {
                                    className: "text-sm font-medium mb-2",
                                    children: "Decision Options (Golden Trio)"
                                }), (0, q.jsx)("ul", {
                                    className: "space-y-1",
                                    children: e.details.policies.map((e, t) => (0, q.jsxs)("li", {
                                        className: "text-sm text-muted-foreground flex items-start gap-2",
                                        children: [(0, q.jsx)("span", {
                                            className: "text-blue-600 mt-0.5",
                                            children: "•"
                                        }), e]
                                    }, t))
                                })]
                            })]
                        }), "blocked" === e.status && 3 === e.id && (0, q.jsx)("div", {
                            className: "mt-4 pt-4 border-t",
                            children: (0, q.jsx)(e1, {
                                onClick: h,
                                className: "w-full bg-primary hover:bg-primary/90",
                                children: "Approve Option A: Conditional Release"
                            })
                        })]
                    }, e.id) : null)
                })
            }), (0, q.jsx)("div", {
                className: "col-span-1",
                children: (0, q.jsxs)(ap, {
                    className: "p-4 h-[600px] flex flex-col",
                    children: [(0, q.jsx)("h3", {
                        className: "font-semibold mb-4 text-foreground",
                        children: "Audit Trail"
                    }), (0, q.jsx)("div", {
                        ref: f,
                        className: "flex-1 overflow-y-auto space-y-3",
                        children: c.map((e, t) => (0, q.jsx)("div", {
                            className: "border-l-2 border-border pl-3 pb-3 last:pb-0",
                            children: (0, q.jsxs)("div", {
                                className: "flex items-start gap-2",
                                children: [(0, q.jsx)("div", {
                                    className: `w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 ${"success"===e.status?"bg-green-100 text-green-700":"warning"===e.status?"bg-amber-100 text-amber-700":"bg-red-100 text-red-700"}`,
                                    children: "success" === e.status ? (0, q.jsx)(aB, {
                                        className: "h-3 w-3"
                                    }) : "warning" === e.status ? (0, q.jsx)(as, {
                                        className: "h-3 w-3"
                                    }) : (0, q.jsx)(AN, {
                                        className: "h-3 w-3"
                                    })
                                }), (0, q.jsxs)("div", {
                                    className: "flex-1 min-w-0",
                                    children: [(0, q.jsx)("p", {
                                        className: "text-xs text-muted-foreground",
                                        children: e.timestamp
                                    }), (0, q.jsx)("p", {
                                        className: "text-xs font-medium text-foreground",
                                        children: e.step
                                    }), (0, q.jsx)("p", {
                                        className: "text-xs text-muted-foreground mt-0.5",
                                        children: e.action
                                    })]
                                })]
                            })
                        }, t))
                    })]
                })
            })]
        })]
    })
}
var AM = G.forwardRef((e, t) => (0, q.jsx)(e7.label, {
    ...e,
    ref: t,
    onMouseDown: t => {
        t.target.closest("button, input, select, textarea") || (e.onMouseDown?.(t), !t.defaultPrevented && t.detail > 1 && t.preventDefault())
    }
}));

function AT({
    className: e,
    ...t
}) {
    return (0, q.jsx)(AM, {
        "data-slot": "label",
        className: eJ("flex items-center gap-2 text-sm leading-none font-medium select-none group-data-[disabled=true]:pointer-events-none group-data-[disabled=true]:opacity-50 peer-disabled:cursor-not-allowed peer-disabled:opacity-50", e),
        ...t
    })
}
AM.displayName = "Label";
let A_ = Q("Lock", [
    ["rect", {
        width: "18",
        height: "11",
        x: "3",
        y: "11",
        rx: "2",
        ry: "2",
        key: "1w4ew1"
    }],
    ["path", {
        d: "M7 11V7a5 5 0 0 1 10 0v4",
        key: "fwvmzm"
    }]
]);
var AD = e.i(57688);