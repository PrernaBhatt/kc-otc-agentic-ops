aE = [{
        customerId: "CUST-001",
        name: "ABC Traders",
        segment: "Enterprise",
        region: "North America",
        creditRating: "BB",
        creditLimit: 5e5,
        currentExposure: 485e3,
        relationshipTier: "Gold",
        churnRiskScore: .15,
        ltvScore: .82
    }, {
        customerId: "CUST-002",
        name: "Global Manufacturing Inc.",
        segment: "Strategic",
        region: "EMEA",
        creditRating: "A",
        creditLimit: 1e6,
        currentExposure: 65e4,
        relationshipTier: "Platinum",
        churnRiskScore: .08,
        ltvScore: .94
    }, {
        customerId: "CUST-003",
        name: "TechPro Solutions",
        segment: "Mid-Market",
        region: "APAC",
        creditRating: "BBB",
        creditLimit: 25e4,
        currentExposure: 18e4,
        relationshipTier: "Silver",
        churnRiskScore: .22,
        ltvScore: .71
    }], aA = [{
        orderId: "SO-710245",
        customerId: "CUST-001",
        customerName: "ABC Traders",
        orderDate: "2025-01-15",
        totalValue: 125e3,
        status: "Hold",
        holdReason: "Credit",
        loopOrderFlag: !0,
        decisionId: "DEC-001",
        lineItems: [{
            orderLineId: "OL-001",
            sku: "SKU-A100",
            productName: "Industrial Tape 3M™",
            qty: 500,
            unitPrice: 45,
            lineValue: 22500,
            loopLineFlag: !0,
            priceValidated: !0,
            taxValidated: !0
        }, {
            orderLineId: "OL-002",
            sku: "SKU-B200",
            productName: "Safety Equipment Kit",
            qty: 200,
            unitPrice: 125,
            lineValue: 25e3,
            loopLineFlag: !0,
            priceValidated: !0,
            taxValidated: !0
        }, {
            orderLineId: "OL-003",
            sku: "SKU-C300",
            productName: "Filtration System",
            qty: 50,
            unitPrice: 550,
            lineValue: 27500,
            loopLineFlag: !0,
            priceValidated: !0,
            taxValidated: !0
        }, {
            orderLineId: "OL-004",
            sku: "SKU-D400",
            productName: "Adhesive Solution",
            qty: 1e3,
            unitPrice: 25,
            lineValue: 25e3,
            loopLineFlag: !0,
            priceValidated: !0,
            taxValidated: !0
        }, {
            orderLineId: "OL-005",
            sku: "SKU-E500",
            productName: "Protective Films",
            qty: 250,
            unitPrice: 100,
            lineValue: 25e3,
            loopLineFlag: !0,
            priceValidated: !0,
            taxValidated: !0
        }]
    }, {
        orderId: "SO-710246",
        customerId: "CUST-002",
        customerName: "Global Manufacturing Inc.",
        orderDate: "2025-01-15",
        totalValue: 34e4,
        status: "Processing",
        holdReason: null,
        loopOrderFlag: !0,
        decisionId: null,
        lineItems: [{
            orderLineId: "OL-006",
            sku: "SKU-F600",
            productName: "Abrasives Bundle",
            qty: 1e3,
            unitPrice: 180,
            lineValue: 18e4,
            loopLineFlag: !0,
            priceValidated: !0,
            taxValidated: !0
        }, {
            orderLineId: "OL-007",
            sku: "SKU-G700",
            productName: "PPE Supplies",
            qty: 800,
            unitPrice: 200,
            lineValue: 16e4,
            loopLineFlag: !0,
            priceValidated: !0,
            taxValidated: !0
        }]
    }, {
        orderId: "SO-710247",
        customerId: "CUST-003",
        customerName: "TechPro Solutions",
        orderDate: "2025-01-14",
        totalValue: 45e3,
        status: "Blocked",
        holdReason: "Delivery",
        loopOrderFlag: !1,
        decisionId: null,
        lineItems: [{
            orderLineId: "OL-008",
            sku: "SKU-H800",
            productName: "Electronic Components",
            qty: 80,
            unitPrice: 562.5,
            lineValue: 45e3,
            loopLineFlag: !1,
            priceValidated: !0,
            taxValidated: !0
        }]
    }, {
        orderId: "SO-710248",
        customerId: "CUST-002",
        customerName: "Global Manufacturing Inc.",
        orderDate: "2025-01-14",
        totalValue: 275e3,
        status: "Fulfilled",
        holdReason: null,
        loopOrderFlag: !0,
        decisionId: null,
        lineItems: [{
            orderLineId: "OL-009",
            sku: "SKU-I900",
            productName: "Specialty Films",
            qty: 500,
            unitPrice: 550,
            lineValue: 275e3,
            loopLineFlag: !0,
            priceValidated: !0,
            taxValidated: !0
        }]
    }], aC = [{
        invoiceId: "INV-12345",
        orderId: "SO-710240",
        customerId: "CUST-001",
        customerName: "ABC Traders",
        invoiceDate: "2025-01-10",
        dueDate: "2025-02-09",
        amount: 95e3,
        status: "Pending"
    }, {
        invoiceId: "INV-12346",
        orderId: "SO-710241",
        customerId: "CUST-002",
        customerName: "Global Manufacturing Inc.",
        invoiceDate: "2025-01-08",
        dueDate: "2025-02-07",
        amount: 18e4,
        status: "Sent"
    }, {
        invoiceId: "INV-12347",
        orderId: "SO-710242",
        customerId: "CUST-003",
        customerName: "TechPro Solutions",
        invoiceDate: "2025-01-05",
        dueDate: "2025-02-04",
        amount: 42e3,
        status: "Overdue"
    }, {
        invoiceId: "INV-12348",
        orderId: "SO-710243",
        customerId: "CUST-001",
        customerName: "ABC Traders",
        invoiceDate: "2025-01-12",
        dueDate: "2025-02-11",
        amount: 67500,
        status: "Paid"
    }], aI = {
        decisionId: "DEC-001",
        orderId: "SO-710245",
        selectedOption: "",
        riskScore: .68,
        ltvScore: .82,
        propensityScore: .75,
        exposureDelta: 125e3,
        guardrailsApplied: ["Max Exposure Delta OK", "Credit Policy Compliant", "Customer Tier Eligible"],
        approvedBy: null,
        approvedAt: null,
        options: [{
            id: "OPT-A",
            name: "Option A: Conditional Release",
            type: "Balanced",
            action: "conditional_release",
            conditions: ["Partial prepayment (20%)", "Accelerated dunning", "Weekly monitoring"],
            riskDelta: .53,
            ltvImpact: .08,
            cashFlowEffect: 1e5,
            confidence: .87
        }, {
            id: "OPT-B",
            name: "Option B: Split Shipment",
            type: "Conservative",
            action: "split_shipment",
            conditions: ["50/50 split delivery", "First shipment COD", "Balance on Net-15"],
            riskDelta: .43,
            ltvImpact: .02,
            cashFlowEffect: 62500,
            confidence: .79
        }, {
            id: "OPT-C",
            name: "Option C: Hard Hold",
            type: "Conservative",
            action: "hard_hold",
            conditions: ["Full prepayment required", "Manual credit review", "Escalate to Credit Manager"],
            riskDelta: .33,
            ltvImpact: -.12,
            cashFlowEffect: 0,
            confidence: .92
        }]
    }, aM = [{
        id: "EXC-001",
        type: "Credit Hold",
        orderId: "SO-710245",
        customerId: "CUST-001",
        customerName: "ABC Traders",
        description: "Credit exposure exceeds limit by $110K. Rating dropped to BB.",
        severity: "High",
        status: "Open",
        createdAt: "2025-01-15T08:30:00Z",
        assignedTo: "Credit Manager"
    }, {
        id: "EXC-002",
        type: "Delivery Delay",
        orderId: "SO-710247",
        customerId: "CUST-003",
        customerName: "TechPro Solutions",
        description: "Shipment delayed by 5 days due to carrier capacity constraints.",
        severity: "Medium",
        status: "Open",
        createdAt: "2025-01-14T14:22:00Z",
        assignedTo: "Logistics Manager"
    }, {
        id: "EXC-003",
        type: "Pricing Mismatch",
        orderId: "SO-710249",
        customerId: "CUST-002",
        customerName: "Global Manufacturing Inc.",
        description: "Contract price differs from applied price by 8%.",
        severity: "Medium",
        status: "In Progress",
        createdAt: "2025-01-14T11:15:00Z",
        assignedTo: "Commercial Team"
    }, {
        id: "EXC-004",
        type: "Document Missing",
        orderId: "SO-710250",
        customerId: "CUST-001",
        customerName: "ABC Traders",
        description: "Proof of delivery document not received.",
        severity: "Low",
        status: "Open",
        createdAt: "2025-01-13T16:45:00Z",
        assignedTo: "Billing Analyst"
    }], aT = {
        loopOrdersPercent: 94.2,
        loopLinesPercent: 96.8,
        creditHoldCount: 12,
        avgHoldDuration: 4.2,
        dsoValue: 38,
        dsoDelta: -2.5,
        otif: 87.3,
        promiseHonoredPercent: 91.5,
        exceptionsCount: 24,
        exceptionsReduction: 15,
        orderCycleTime: 2.3,
        invoiceAccuracy: 98.5,
        collectionEffectiveness: 94.2,
        perfectOrderRate: 91.8,
        orderFillRate: 96.4,
        billingCycleTime: 1.8,
        disputeRate: 2.1,
        automationRate: 89,
        touchlessOrderRate: 78.5,
        revenueAtRisk: 485e3
    }, a_ = [{
        id: "ACT-001",
        agentName: "OTC Orchestrator",
        agentType: "orchestrator",
        status: "complete",
        message: "Initiated credit hold workflow for SO-710245",
        timestamp: "2025-01-15T08:30:15Z"
    }, {
        id: "ACT-002",
        agentName: "Credit Risk Agent",
        agentType: "credit",
        status: "complete",
        message: "Calculated risk score: 0.68 | Exposure ratio: 97%",
        timestamp: "2025-01-15T08:30:18Z"
    }, {
        id: "ACT-003",
        agentName: "Pricing & Policy Agent",
        agentType: "pricing",
        status: "complete",
        message: "Pricing validated ✓ | Tax compliant ✓ | Contract terms OK",
        timestamp: "2025-01-15T08:30:20Z"
    }, {
        id: "ACT-004",
        agentName: "Customer LTV Agent",
        agentType: "ltv",
        status: "complete",
        message: "LTV Score: 0.82 | Relationship Tier: Gold | Low churn risk",
        timestamp: "2025-01-15T08:30:22Z"
    }, {
        id: "ACT-005",
        agentName: "OTC Orchestrator",
        agentType: "orchestrator",
        status: "processing",
        message: "Generating decision options (Golden Trio)...",
        timestamp: "2025-01-15T08:30:25Z"
    }], aD = [{
        month: "Aug",
        orders: 245,
        automated: 198,
        manual: 47
    }, {
        month: "Sep",
        orders: 267,
        automated: 221,
        manual: 46
    }, {
        month: "Oct",
        orders: 289,
        automated: 248,
        manual: 41
    }, {
        month: "Nov",
        orders: 312,
        automated: 275,
        manual: 37
    }, {
        month: "Dec",
        orders: 298,
        automated: 268,
        manual: 30
    }, {
        month: "Jan",
        orders: 324,
        automated: 295,
        manual: 29
    }], aR = [{
        name: "Credit Hold",
        value: 35,
        color: "#ef4444"
    }, {
        name: "Pricing Mismatch",
        value: 22,
        color: "#f59e0b"
    }, {
        name: "Document Missing",
        value: 18,
        color: "#3b82f6"
    }, {
        name: "Delivery Delay",
        value: 15,
        color: "#8b5cf6"
    }, {
        name: "ATP Failure",
        value: 10,
        color: "#6b7280"
    }], aL = [{
        month: "Aug",
        dso: 45,
        target: 40
    }, {
        month: "Sep",
        dso: 43,
        target: 40
    }, {
        month: "Oct",
        dso: 41,
        target: 40
    }, {
        month: "Nov",
        dso: 40,
        target: 40
    }, {
        month: "Dec",
        dso: 39,
        target: 40
    }, {
        month: "Jan",
        dso: 38,
        target: 40
    }], az = [{
            agent: "Credit Risk",
            processed: 156,
            success: 149
        }, {
            agent: "Pricing",
            processed: 289,
            success: 285