key: "7eqyqh"
}], ["path", {
d: "M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6",
key: "1b0p4s"
}]]), ad = Q("Shield", [
    ["path", {
        d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
        key: "oel41y"
    }]
]);

function af({
    activeView: e,
    onViewChange: t
}) {
    let r = [{
        id: "dashboard",
        label: "Dashboard",
        icon: ai
    }, {
        id: "credit-review",
        label: "Review Order Hold",
        icon: ad
    }, {
        id: "orders",
        label: "Order Management",
        icon: aa
    }, {
        id: "transactions",
        label: "Transactions",
        icon: ao
    }, {
        id: "exceptions",
        label: "Exceptions",
        icon: as
    }, {
        id: "copilot",
        label: "Co-Pilot",
        icon: al
    }, {
        id: "agents",
        label: "Agent Activity",
        icon: ac
    }, {
        id: "billing",
        label: "Billing",
        icon: ao
    }, {
        id: "collections",
        label: "Collections",
        icon: au
    }];
    return (0, q.jsx)("aside", {
        className: "sticky top-14 h-[calc(100vh-3.5rem)] w-60 flex-shrink-0 border-r bg-[var(--sidebar)] overflow-y-auto",
        children: (0, q.jsx)("div", {
            className: "flex flex-col h-full py-4 px-3",
            children: (0, q.jsx)("nav", {
                className: "space-y-1",
                children: r.map(r => {
                    let n = r.icon;
                    return (0, q.jsxs)(e1, {
                        variant: "ghost",
                        className: eJ("w-full justify-start gap-3 rounded-lg font-medium text-left overflow-hidden", e === r.id ? "bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground" : "text-[var(--sidebar-foreground)] hover:bg-[var(--sidebar-accent)]"),
                        onClick: () => t(r.id),
                        children: [(0, q.jsx)(n, {
                            className: "h-4 w-4 flex-shrink-0"
                        }), (0, q.jsx)("span", {
                            className: "text-sm truncate",
                            children: r.label
                        })]
                    }, r.id)
                })
            })
        })
    })
}

function ap({
    className: e,
    ...t
}) {
    return (0, q.jsx)("div", {
        "data-slot": "card",
        className: eJ("bg-card text-card-foreground flex flex-col gap-6 rounded-xl border py-6 shadow-sm", e),
        ...t
    })
}

function am({
    className: e,
    ...t
}) {
    return (0, q.jsx)("div", {
        "data-slot": "card-header",
        className: eJ("@container/card-header grid auto-rows-min grid-rows-[auto_auto] items-start gap-2 px-6 has-data-[slot=card-action]:grid-cols-[1fr_auto] [.border-b]:pb-6", e),
        ...t
    })
}

function ah({
    className: e,
    ...t
}) {
    return (0, q.jsx)("div", {
        "data-slot": "card-title",
        className: eJ("leading-none font-semibold", e),
        ...t
    })
}

function ag({
    className: e,
    ...t
}) {
    return (0, q.jsx)("div", {
        "data-slot": "card-description",
        className: eJ("text-muted-foreground text-sm", e),
        ...t
    })
}

function av({
    className: e,
    ...t
}) {
    return (0, q.jsx)("div", {
        "data-slot": "card-content",
        className: eJ("px-6", e),
        ...t
    })
}
let ay = Q("TrendingUp", [
        ["polyline", {
            points: "22 7 13.5 15.5 8.5 10.5 2 17",
            key: "126l90"
        }],
        ["polyline", {
            points: "16 7 22 7 22 13",
            key: "kwv8wd"
        }]
    ]),
    ax = Q("TrendingDown", [
        ["polyline", {
            points: "22 17 13.5 8.5 8.5 13.5 2 7",
            key: "1r2t7k"
        }],
        ["polyline", {
            points: "16 17 22 17 22 11",
            key: "11uiuu"
        }]
    ]),
    ab = Q("Target", [
        ["circle", {
            cx: "12",
            cy: "12",
            r: "10",
            key: "1mglay"
        }],
        ["circle", {
            cx: "12",
            cy: "12",
            r: "6",
            key: "1vlfrh"
        }],
        ["circle", {
            cx: "12",
            cy: "12",
            r: "2",
            key: "1c9p78"
        }]
    ]),
    aw = Q("FileCheck", [
        ["path", {
            d: "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",
            key: "1rqfz7"
        }],
        ["path", {
            d: "M14 2v4a2 2 0 0 0 2 2h4",
            key: "tnqrlb"
        }],
        ["path", {
            d: "m9 15 2 2 4-4",
            key: "1grp1n"
        }]
    ]),
    aj = Q("Percent", [
        ["line", {
            x1: "19",
            x2: "5",
            y1: "5",
            y2: "19",
            key: "1x9vlm"
        }],
        ["circle", {
            cx: "6.5",
            cy: "6.5",
            r: "2.5",
            key: "4mh3h7"
        }],
        ["circle", {
            cx: "17.5",
            cy: "17.5",
            r: "2.5",
            key: "1mdrzq"
        }]
    ]),
    aO = Q("Zap", [
        ["path", {
            d: "M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",
            key: "1xq2db"
        }]
    ]),
    aN = Q("Timer", [
        ["line", {
            x1: "10",
            x2: "14",
            y1: "2",
            y2: "2",
            key: "14vaq8"
        }],
        ["line", {
            x1: "12",
            x2: "15",
            y1: "14",
            y2: "11",
            key: "17fdiu"
        }],
        ["circle", {
            cx: "12",
            cy: "14",
            r: "8",
            key: "1e1u0o"
        }]
    ]),
    ak = Q("X", [
            ["path", {
                d: "M18 6 6 18",
                key: "1bl5f8"
            }],
            ["path", {
                    d: "m6 6 12 12",
                    key