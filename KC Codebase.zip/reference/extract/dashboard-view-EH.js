function EH({
    onNavigate: e
}) {
    let [t, r] = (0, G.useState)(0);
    return (0, G.useEffect)(() => {
        let e = setInterval(() => {
            r(e => e >= 89 ? 89 : e + 5 * Math.random())
        }, 200);
        return () => clearInterval(e)
    }, []), (0, q.jsxs)("div", {
        className: "space-y-4 pb-8",
        children: [(0, q.jsxs)("div", {
            className: "flex items-center justify-between",
            children: [(0, q.jsxs)("div", {
                children: [(0, q.jsx)("h1", {
                    className: "text-lg font-bold text-foreground",
                    children: "Dashboard Overview"
                }), (0, q.jsx)("p", {
                    className: "text-sm text-muted-foreground",
                    children: "Real-time insights into OTC operations automation"
                })]
            }), (0, q.jsxs)("div", {
                className: "flex items-center gap-2",
                children: [(0, q.jsxs)(ar, {
                    variant: "outline",
                    className: "gap-1 text-xs",
                    children: [(0, q.jsx)(a$, {
                        type: "orchestrator",
                        size: "sm"
                    }), "Policy-as-Code"]
                }), (0, q.jsxs)(ar, {
                    variant: "outline",
                    className: "gap-1 text-xs",
                    children: [(0, q.jsx)(a$, {
                        type: "validation",
                        size: "sm"
                    }), "Guardrails Active"]
                })]
            })]
        }), (0, q.jsx)(aP, {
            data: aT
        }), (0, q.jsxs)("div", {
            className: "grid md:grid-cols-2 lg:grid-cols-4 gap-4",
            children: [(0, q.jsx)(EI, {}), (0, q.jsx)(EM, {}), (0, q.jsx)(ET, {}), (0, q.jsx)(E_, {})]
        }), (0, q.jsxs)("div", {
            className: "grid md:grid-cols-3 gap-4",
            children: [(0, q.jsxs)(ap, {
                className: "bg-card shadow-sm",
                children: [(0, q.jsx)(am, {
                    className: "pb-2",
                    children: (0, q.jsxs)(ah, {
                        className: "text-sm font-semibold flex items-center gap-2",
                        children: [(0, q.jsx)(a$, {
                            type: "validation",
                            size: "sm",
                            className: "text-primary"
                        }), "Order Validation"]
                    })
                }), (0, q.jsxs)(av, {
                    children: [(0, q.jsxs)("div", {
                        className: "flex items-end justify-between mb-2",
                        children: [(0, q.jsxs)("div", {
                            children: [(0, q.jsx)("div", {
                                className: "text-2xl font-bold text-foreground",
                                children: "20"
                            }), (0, q.jsx)("div", {
                                className: "text-xs text-muted-foreground",
                                children: "Auto-completed"
                            })]
                        }), (0, q.jsx)("div", {
                            className: "text-[var(--success)]",
                            children: (0, q.jsx)(aB, {
                                className: "h-8 w-8 stroke-[1.5]"
                            })
                        })]
                    }), (0, q.jsx)(aV, {
                        progress: 89,
                        label: "Automation Rate",
                        color: "success"
                    })]
                })]
            }), (0, q.jsxs)(ap, {
                className: "bg-card shadow-sm",
                children: [(0, q.jsx)(am, {
                    className: "pb-2",
                    children: (0, q.jsxs)(ah, {
                        className: "text-sm font-semibold flex items-center gap-2",
                        children: [(0, q.jsx)(a$, {
                            type: "credit",
                            size: "sm",
                            className: "text-[var(--warning)]"
                        }), "Credit Evaluation"]
                    })
                }), (0, q.jsxs)(av, {
                    children: [(0, q.jsxs)("div", {
                        className: "flex items-end justify-between mb-2",
                        children: [(0, q.jsxs)("div", {
                            children: [(0, q.jsx)("div", {
                                className: "text-2xl font-bold text-foreground",
                                children: "9"
                            }), (0, q.jsx)("div", {
                                className: "text-xs text-primary",
                                children: "3 high priority"
                            })]
                        }), (0, q.jsx)(aF, {
                            size: "lg",
                            className: "text-[var(--info)]"
                        })]
                    }), (0, q.jsx)(aV, {
                        progress: 65,
                        label: "Processing",
                        color: "info"
                    })]
                })]
            }), (0, q.jsxs)(ap, {
                className: "bg-card shadow-sm",
                children: [(0, q.jsx)(am, {
                    className: "pb-2",
                    children: (0, q.jsxs)(ah, {
                        className: "text-sm font-semibold flex items-center gap-2",
                        children: [(0, q.jsx)(a$, {
                            type: "billing",
                            size: "sm",
                            className: "text-[var(--success)]"
                        }), "Billing & Invoicing"]
                    })
                }), (0, q.jsxs)(av, {
                    children: [(0, q.jsxs)("div", {
                        className: "flex items-end justify-between mb-2",
                        children: [(0, q.jsxs)("div", {
                            children: [(0, q.jsx)("div", {
                                className: "text-2xl font-bold text-foreground",
                                children: "10"
                            }), (0, q.jsx)("div", {
                                className: "text-xs text-muted-foreground",
                                children: "Invoices processed"
                            })]
                        }), (0, q.jsx)("div", {
                            className: "text-[var(--success)]",
                            children: (0, q.jsx)(aB, {
                                className: "h-8 w-8 stroke-[1.5]"
                            })
                        })]
                    }), (0, q.jsx)(aV, {
                        progress: 100,
                        label: "Complete",
                        color: "success",
                        animated: !1
                    })]
                })]
            })]
        }), (0, q.jsx)(EK, {
            onNavigate: e
        })]
    })
}
let EW = {
    orchestrator: {
        color: "bg-primary text-primary-foreground"
    },
    credit: {
        color: "bg-[var(--info)] text-white"
    },
    pricing: {
        color: "bg-[var(--success)] text-white"
    },
    ltv: {
        color: "bg-purple-500 text-white"
    },
    dunning: {
        color: "bg-[var(--warning)] text-[var(--warning-foreground)]"
    },
    validation: {
        color: "bg-[var(--success)] text-white"
    },
    billing: {
        color: "bg-teal-500 text-white"
    },
    atp: {
        color: "bg-cyan-500 text-white"
    }
};