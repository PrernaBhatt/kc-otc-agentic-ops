function AY() {
    let [e, t] = (0, G.useState)(!1), [r, n] = (0, G.useState)("dashboard"), [i, a] = (0, G.useState)(null), [o, s] = (0, G.useState)(new Set), [l, c] = (0, G.useState)(!1), [u, d] = (0, G.useState)(null), [f, p] = (0, G.useState)("exceptions"), [m, h] = (0, G.useState)([]), g = () => {
        a(null)
    }, v = e => {
        s(t => new Set(t).add(e))
    }, y = e => {
        a(e)
    }, x = e => {
        u ? p("fulfillment") : c(!0)
    }, b = () => {
        c(!1), n("dashboard")
    }, w = e => {
        d(e), p("credit-review")
    }, j = () => {
        d(null), p("exceptions")
    }, O = e => {
        e && h(t => [...t, e]), d(null), p("exceptions")
    }, N = () => {
        t(!1), n("dashboard"), a(null), s(new Set), c(!1)
    }, k = e => {
        n(e), a(null), c(!1), "exceptions" !== e && (d(null), p("exceptions"))
    }, S = (e, t) => {
        n(e), t && a(t)
    };
    return e ? l ? (0, q.jsxs)("div", {
        className: "min-h-screen bg-background",
        children: [(0, q.jsx)(an, {
            onLogout: N
        }), (0, q.jsxs)("div", {
            className: "flex",
            children: [(0, q.jsx)(af, {
                activeView: r,
                onViewChange: k
            }), (0, q.jsx)("main", {
                className: "flex-1",
                children: (0, q.jsx)(AE, {
                    onBack: b,
                    onComplete: () => b()
                })
            })]
        })]
    }) : (0, q.jsxs)("div", {
        className: "min-h-screen bg-background",
        children: [(0, q.jsx)(an, {
            onLogout: N
        }), (0, q.jsxs)("div", {
            className: "flex",
            children: [(0, q.jsx)(af, {
                activeView: r,
                onViewChange: k
            }), (0, q.jsx)("main", {
                className: "flex-1 p-8",
                children: (() => {
                    if ("exceptions" === r && u) {
                        if ("credit-review" === f) return (0, q.jsx)(E5, {
                            focusOrderId: u,
                            onNavigateToFulfillment: x,
                            onBack: j
                        });
                        if ("fulfillment" === f) return (0, q.jsx)(AE, {
                            orderId: u,
                            onBack: j,
                            onComplete: O
                        })
                    }
                    if (i) {
                        let e = aA.find(e => e.orderId === i);
                        if (e) return (0, q.jsx)(AI, {
                            order: e,
                            onBack: g,
                            onComplete: v
                        })
                    }
                    switch (r) {
                        case "dashboard":
                            return (0, q.jsx)(EH, {
                                onNavigate: S
                            });
                        case "credit-review":
                            return (0, q.jsx)(E5, {
                                onNavigateToFulfillment: x
                            });
                        case "orders":
                            return (0, q.jsx)(AH, {});
                        case "transactions":
                            return (0, q.jsx)(An, {
                                onProcessOrder: y
                            });
                        case "exceptions":
                            return (0, q.jsx)(Ai, {
                                onResolveWithAI: w,
                                completedOrderIds: m
                            });
                        case "copilot":
                            return (0, q.jsx)(AA, {});
                        case "agents":
                            return (0, q.jsxs)("div", {
                                className: "space-y-6",
                                children: [(0, q.jsxs)("div", {
                                    children: [(0, q.jsx)("h2", {
                                        className: "text-2xl font-bold text-foreground",
                                        children: "Agent Activity"
                                    }), (0, q.jsx)("p", {
                                        className: "text-muted-foreground",
                                        children: "Real-time AI agent orchestration monitoring"
                                    })]
                                }), (0, q.jsxs)("div", {
                                    className: "grid lg:grid-cols-2 gap-6",
                                    children: [(0, q.jsx)(AB, {
                                        type: "order",
                                        activeStep: 3,
                                        showDetails: !0
                                    }), (0, q.jsx)(AB, {
                                        type: "billing",
                                        activeStep: 2,
                                        showDetails: !0
                                    })]
                                }), (0, q.jsx)("div", {
                                    className: "max-w-2xl",
                                    children: (0, q.jsx)(Eq, {
                                        activities: a_
                                    })
                                })]
                            });
                        case "billing":
                            return (0, q.jsx)(AG, {});
                        case "collections":
                            return (0, q.jsx)(Aj, {});
                        default:
                            return (0, q.jsx)(EH, {})
                    }
                })()
            })]
        })]
    }) : (0, q.jsx)(AR, {
        onLogin: () => {
            t(!0)
        }
    })
}
e.s(["default", () => AY], 31713)
}]);