function EK({
    onNavigate: e
}) {
    let [t, r] = (0, G.useState)(!1), [n, i] = (0, G.useState)(!1), [a, o] = (0, G.useState)([{
        id: "1",
        role: "assistant",
        content: "Hello! I'm your OTC Analytics Assistant. I can help you understand KPIs, track orders, and analyze performance metrics. What would you like to know?",
        timestamp: new Date
    }]), [s, l] = (0, G.useState)(""), [c, u] = (0, G.useState)(!1), d = (0, G.useRef)(null);
    (0, G.useEffect)(() => {
        d.current?.scrollIntoView({
            behavior: "smooth"
        })
    }, [a]);
    let f = () => {
        if (!s.trim()) return;
        let e = {
            id: Date.now().toString(),
            role: "user",
            content: s,
            timestamp: new Date
        };
        o(t => [...t, e]), l(""), u(!0), setTimeout(() => {
            let {
                content: e,
                actionLink: t
            } = function(e) {
                let t = e.toLowerCase();
                if (t.includes("dso") || t.includes("days sales outstanding")) return {
                    content: `Current DSO is **${aT.dsoValue} days**, which is ${Math.abs(aT.dsoDelta)} days ${aT.dsoDelta<0?"below":"above"} target. This represents a ${aT.dsoDelta<0?"positive":"concerning"} trend. The DSO has been steadily improving over the past 6 months due to proactive collection efforts and automated dunning.`
                };
                if (t.includes("hold") || t.includes("held") || t.includes("stuck") || t.includes("status")) {
                    let e = aA.filter(e => "Hold" === e.status || "Blocked" === e.status);
                    if (t.includes("so-") || t.includes("order")) {
                        let e = t.match(/so-?\d+/i);
                        if (e) {
                            let t = e[0].toUpperCase().replace(/SO-?/, "SO-"),
                                r = aA.find(e => e.orderId === t);
                            if (r) {
                                let e, t = "";
                                return "Hold" === r.status ? (t = `

**Why is it stuck?**
${r.holdReason} Hold - Customer ${r.customerName} has exceeded their credit limit. Current exposure is near maximum threshold.

**AI Recommendation:**
The Credit Risk Agent has analyzed this case and generated 3 decision options (Golden Trio) for review. You can approve a conditional release, split shipment, or require prepayment.`, e = {
                                    text: "Review Credit Hold Decision",
                                    view: "credit-review",
                                    orderId: r.orderId
                                }) : "Blocked" === r.status ? (t = `

**Why is it stuck?**
${r.holdReason} Delay - Shipment is blocked due to logistics constraints. Estimated delay: 5 days.

**AI Recommendation:**
The Logistics Agent suggests rerouting through alternate carrier or splitting delivery to meet partial fulfillment.`, e = {
                                    text: "View in Exceptions",
                                    view: "exceptions",
                                    orderId: r.orderId
                                }) : t = `

**Current Status:**
Order is progressing normally through the pipeline. No action required.`, {
                                    content: `**${r.orderId}** for ${r.customerName}:

• Status: **${r.status}**
• Value: **$${r.totalValue.toLocaleString()}**
• Order Date: ${r.orderDate}${t}`,
                                    actionLink: e
                                }
                            }
                        }
                    }
                    return {
                        content: `Currently **${e.length} orders** are on hold:

${e.map(e=>`• **${e.orderId}** - ${e.customerName} ($${e.totalValue.toLocaleString()}) - ${e.holdReason} Hold`).join("\n")}

You can review these in the "Review Order Hold" section for AI-recommended actions.`
                    }
                }
                if (t.includes("automation") || t.includes("touchless") || t.includes("automated")) return {
                    content: `Current automation metrics:

• **Automation Rate**: ${aT.automationRate}%
• **Touchless Order Rate**: ${aT.touchlessOrderRate}%
• **Loop Orders**: ${aT.loopOrdersPercent}%
• **Loop Lines**: ${aT.loopLinesPercent}%

The AI agents are processing ${aT.automationRate}% of transactions without human intervention.`
                };
                if (t.includes("otif") || t.includes("on time") || t.includes("in full")) return {
                    content: `**OTIF (On-Time In-Full)** is currently at **${aT.otif}%**. This is trending upward by +2.1% compared to last month. Key drivers:

• Improved ATP accuracy
• Proactive shipment tracking
• Automated carrier selection`
                };
                if (t.includes("credit")) return {
                    content: `Credit metrics overview:

• **Active Credit Holds**: ${aT.creditHoldCount}
• **Avg Hold Duration**: ${aT.avgHoldDuration} hours
• **Collection Effectiveness**: ${aT.collectionEffectiveness}%

The Credit Risk Agent is actively monitoring ${aT.creditHoldCount} accounts with elevated exposure.`
                };
                if (t.includes("exception")) {
                    let e = aM.reduce((e, t) => (e[t.type] = (e[t.type] || 0) + 1, e), {});
                    return {
                        content: `Current exceptions breakdown:

${Object.entries(e).map(([e,t])=>`• **${e}**: ${t}`).join("\n")}

Total: **${aM.length}** active exceptions. High severity items should be prioritized in the Exceptions view.`
                    }
                }
                return t.includes("revenue") || t.includes("risk") || t.includes("exposure") ? {
                    content: `**Revenue at Risk**: $${aT.revenueAtRisk.toLocaleString()}

This includes:
• Orders on credit hold
• Disputed invoices
• Overdue receivables

The AI agents are actively working to reduce this exposure through proactive collections and credit management.`
                } : t.includes("invoice") || t.includes("billing") ? {
                    content: `Billing metrics:

• **Invoice Accuracy**: ${aT.invoiceAccuracy}%
• **Billing Cycle Time**: ${aT.billingCycleTime} days
• **Dispute Rate**: ${aT.disputeRate}%

The Billing Agent is maintaining high accuracy while reducing cycle time.`
                } : t.includes("cycle") || t.includes("time") || t.includes("processing") ? {
                    content: `Order processing metrics:

• **Order Cycle Time**: ${aT.orderCycleTime} days
• **Order Fill Rate**: ${aT.orderFillRate}%
• **Perfect Order Rate**: ${aT.perfectOrderRate}%

Cycle time has improved 15% this quarter due to AI-driven automation.`
                } : t.includes("kpi") || t.includes("performance") || t.includes("metrics") || t.includes("summary") ? {
                    content: `**OTC Performance Summary**:

📊 **Efficiency**
• Automation Rate: ${aT.automationRate}%
• Order Cycle Time: ${aT.orderCycleTime} days

💰 **Financial**
• DSO: ${aT.dsoValue} days
• Revenue at Risk: $${aT.revenueAtRisk.toLocaleString()}

✅ **Quality**
• OTIF: ${aT.otif}%
• Invoice Accuracy: ${aT.invoiceAccuracy}%
• Perfect Order Rate: ${aT.perfectOrderRate}%`
                } : {
                    content: `I can help you with OTC metrics and order status. Try asking about:

• DSO and collection metrics
• Order holds and status
• Automation rates
• OTIF performance
• Specific orders (e.g., "Where is SO-710245?")

What would you like to know?`
                }
            }(s), r = {
                id: (Date.now() + 1).toString(),
                role: "assistant",
                content: e,
                timestamp: new Date,
                actionLink: t
            };
            o(e => [...e, r]), u(!1)
        }, 800)
    };
    return t ? (0, q.jsxs)(ap, {
        className: `fixed bottom-6 right-6 z-50 shadow-2xl transition-all border-2 border-gray-200 dark:border-gray-700 ${n?"w-[500px] h-14":"w-[600px] h-[700px]"} flex flex-col bg-gradient-to-br from-white via-gray-50 to-white dark:from-gray-900 dark:via-gray-800 dark:to-gray-900`,
        children: [(0, q.jsxs)("div", {
            className: "flex items-center justify-between p-3 border-b bg-gradient-to-r from-primary to-primary/80 text-primary-foreground rounded-t-lg shadow-lg",
            children: [(0, q.jsxs)("div", {
                className: "flex items-center gap-2",
                children: [(0, q.jsx)(a$, {
                    type: "orchestrator",
                    size: "sm",
                    className: "text-primary-foreground"
                }), (0, q.jsx)("span", {
                    className: "font-semibold text-sm",
                    children: "OTC Analytics Assistant"
                }), (0, q.jsx)(ar, {
                    variant: "secondary",
                    className: "text-xs",
                    children: "AI"
                })]
            }), (0, q.jsxs)("div", {
                className: "flex items-center gap-1",
                children: [(0, q.jsx)("button", {
                    onClick: () => i(!n),
                    className: "p-1 hover:bg-primary-foreground/20 rounded",
                    children: n ? (0, q.jsx)(EF, {
                        className: "h-4 w-4"
                    }) : (0, q.jsx)(E$, {
                        className: "h-4 w-4"
                    })
                }), (0, q.jsx)("button", {
                    onClick: () => r(!1),
                    className: "p-1 hover:bg-primary-foreground/20 rounded",
                    children: (0, q.jsx)(ak, {
                        className: "h-4 w-4"
                    })
                })]
            })]
        }), !n && (0, q.jsxs)(q.Fragment, {
            children: [(0, q.jsxs)("div", {
                className: "flex-1 overflow-y-auto p-4 space-y-4 min-h-0 bg-gradient-to-b from-transparent to-gray-50/50 dark:to-gray-900/50",
                children: [a.map(t => (0, q.jsxs)("div", {
                    className: `flex gap-2 ${"user"===t.role?"justify-end":"justify-start"}`,
                    children: ["assistant" === t.role && (0, q.jsx)("div", {
                        className: "w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0",
                        children: (0, q.jsx)(EL, {
                            className: "h-4 w-4 text-primary"
                        })
                    }), (0, q.jsxs)("div", {
                        className: "flex flex-col gap-2 max-w-[85%]",
                        children: [(0, q.jsx)("div", {
                            className: `rounded-lg px-4 py-3 text-sm ${"user"===t.role?"bg-primary text-primary-foreground":"bg-muted text-foreground"}`,
                            children: (0, q.jsx)("div", {
                                className: "whitespace-pre-wrap leading-relaxed",
                                children: t.content.split("**").map((e, t) => t % 2 == 1 ? (0, q.jsx)("strong", {
                                    children: e
                                }, t) : e)
                            })
                        }), t.actionLink && e && (0, q.jsxs)(e1, {
                            onClick: () => e(t.actionLink.view, t.actionLink.orderId),
                            size: "sm",
                            variant: "outline",
                            className: "w-fit gap-2 bg-primary/5 hover:bg-primary/10 border-primary/20",
                            children: [(0, q.jsx)(EV, {
                                className: "h-3 w-3"
                            }), t.actionLink.text]
                        })]
                    }), "user" === t.role && (0, q.jsx)("div", {
                        className: "w-8 h-8 rounded-full bg-muted flex items-center justify-center flex-shrink-0",
                        children: (0, q.jsx)(Ez, {
                            className: "h-4 w-4 text-muted-foreground"
                        })
                    })]
                }, t.id)), c && (0, q.jsxs)("div", {
                    className: "flex gap-2 items-center",
                    children: [(0, q.jsx)("div", {
                        className: "w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center",
                        children: (0, q.jsx)(EL, {
                            className: "h-4 w-4 text-primary"
                        })
                    }), (0, q.jsx)("div", {
                        className: "bg-muted rounded-lg px-4 py-3",
                        children: (0, q.jsx)(EB, {
                            className: "h-4 w-4 animate-spin text-muted-foreground"
                        })
                    })]
                }), (0, q.jsx)("div", {
                    ref: d
                })]
            }), a.length <= 2 && (0, q.jsxs)("div", {
                className: "px-3 pb-2 bg-gradient-to-t from-white/80 dark:from-gray-900/80",
                children: [(0, q.jsx)("p", {
                    className: "text-xs text-muted-foreground mb-2 font-medium",
                    children: "Suggested questions:"
                }), (0, q.jsx)("div", {
                    className: "flex flex-wrap gap-1",
                    children: EU.map(e => (0, q.jsx)("button", {
                        onClick: () => {
                            l(e), setTimeout(() => f(), 100)
                        },
                        className: "text-xs bg-gradient-to-r from-gray-100 to-gray-200 dark:from-gray-800 dark:to-gray-700 hover:from-primary/10 hover:to-primary/20 px-2 py-1 rounded-full text-foreground transition-all hover:shadow-md",
                        children: e
                    }, e))
                })]
            }), (0, q.jsx)("div", {
                className: "p-3 border-t bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm",
                children: (0, q.jsxs)("div", {
                    className: "flex gap-2",
                    children: [(0, q.jsx)(e2, {
                        value: s,
                        onChange: e => l(e.target.value),
                        onKeyDown: e => "Enter" === e.key && f(),
                        placeholder: "Ask about KPIs, orders...",
                        className: "flex-1 text-sm"
                    }), (0, q.jsx)(e1, {
                        onClick: f,
                        size: "sm",
                        className: "px-3",
                        children: (0, q.jsx)(ER, {
                            className: "h-4 w-4"
                        })
                    })]
                })
            })]
        })]
    }) : (0, q.jsx)("button", {
        onClick: () => r(!0),
        className: "fixed bottom-6 right-6 z-50 bg-gradient-to-r from-primary to-primary/80 text-primary-foreground rounded-full p-4 shadow-2xl hover:shadow-primary/50 hover:scale-110 transition-all duration-300",
        children: (0, q.jsx)(ED, {
            className: "h-6 w-6"
        })
    })
}