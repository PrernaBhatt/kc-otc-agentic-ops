function An({
    onProcessOrder: e
}) {
    let [t, r] = (0, G.useState)("orders"), [n, i] = (0, G.useState)(""), [a, o] = (0, G.useState)({}), s = aA.filter(e => e.orderId.toLowerCase().includes(n.toLowerCase()) || e.customerName.toLowerCase().includes(n.toLowerCase())), l = aC.filter(e => e.invoiceId.toLowerCase().includes(n.toLowerCase()) || e.customerName.toLowerCase().includes(n.toLowerCase()));
    return (0, G.useEffect)(() => {
        let e = setInterval(() => {
            o(e => {
                let t = {
                    ...e
                };
                return Object.keys(t).forEach(e => {
                    t[e] < 100 && (t[e] = Math.min(t[e] + 15 * Math.random(), 100))
                }), t
            })
        }, 500);
        return () => clearInterval(e)
    }, []), (0, q.jsxs)("div", {
        className: "space-y-6",
        children: [(0, q.jsxs)("div", {
            className: "flex items-center justify-between",
            children: [(0, q.jsxs)("div", {
                children: [(0, q.jsx)("h2", {
                    className: "text-lg font-bold text-foreground",
                    children: "Transactions"
                }), (0, q.jsx)("p", {
                    className: "text-muted-foreground",
                    children: "Monitor and process sales orders and invoices"
                })]
            }), (0, q.jsxs)(e1, {
                variant: "outline",
                children: [(0, q.jsx)(At, {
                    className: "h-4 w-4 mr-2"
                }), "Export"]
            })]
        }), (0, q.jsxs)("div", {
            className: "grid grid-cols-4 gap-4",
            children: [(0, q.jsx)(ap, {
                className: "bg-card",
                children: (0, q.jsx)(av, {
                    className: "p-4",
                    children: (0, q.jsxs)("div", {
                        className: "flex items-center gap-3",
                        children: [(0, q.jsx)("div", {
                            className: "p-2 rounded-lg bg-primary/10",
                            children: (0, q.jsx)(a$, {
                                type: "validation",
                                size: "sm",
                                className: "text-primary"
                            })
                        }), (0, q.jsxs)("div", {
                            children: [(0, q.jsx)("div", {
                                className: "text-2xl font-bold",
                                children: aA.length
                            }), (0, q.jsx)("div", {
                                className: "text-xs text-muted-foreground",
                                children: "Total Orders"
                            })]
                        })]
                    })
                })
            }), (0, q.jsx)(ap, {
                className: "bg-card",
                children: (0, q.jsx)(av, {
                    className: "p-4",
                    children: (0, q.jsxs)("div", {
                        className: "flex items-center gap-3",
                        children: [(0, q.jsx)("div", {
                            className: "p-2 rounded-lg bg-[var(--info)]/10",
                            children: (0, q.jsx)(aF, {
                                size: "sm",
                                className: "text-[var(--info)]"
                            })
                        }), (0, q.jsxs)("div", {
                            children: [(0, q.jsx)("div", {
                                className: "text-2xl font-bold",
                                children: aA.filter(e => "Processing" === e.status).length
                            }), (0, q.jsx)("div", {
                                className: "text-xs text-muted-foreground",
                                children: "Processing"
                            })]
                        })]
                    })
                })
            }), (0, q.jsx)(ap, {
                className: "bg-card",
                children: (0, q.jsx)(av, {
                    className: "p-4",
                    children: (0, q.jsxs)("div", {
                        className: "flex items-center gap-3",
                        children: [(0, q.jsx)("div", {
                            className: "p-2 rounded-lg bg-[var(--warning)]/10",
                            children: (0, q.jsx)(a$, {
                                type: "credit",
                                size: "sm",
                                className: "text-[var(--warning)]"
                            })
                        }), (0, q.jsxs)("div", {
                            children: [(0, q.jsx)("div", {
                                className: "text-2xl font-bold",
                                children: aA.filter(e => "Hold" === e.status || "Blocked" === e.status).length
                            }), (0, q.jsx)("div", {
                                className: "text-xs text-muted-foreground",
                                children: "Exceptions"
                            })]
                        })]
                    })
                })
            }), (0, q.jsx)(ap, {
                className: "bg-card",
                children: (0, q.jsx)(av, {
                    className: "p-4",
                    children: (0, q.jsxs)("div", {
                        className: "flex items-center gap-3",
                        children: [(0, q.jsx)("div", {
                            className: "p-2 rounded-lg bg-[var(--success)]/10",
                            children: (0, q.jsx)(a$, {
                                type: "atp",
                                size: "sm",
                                className: "text-[var(--success)]"
                            })
                        }), (0, q.jsxs)("div", {
                            children: [(0, q.jsx)("div", {
                                className: "text-2xl font-bold",
                                children: aA.filter(e => "Fulfilled" === e.status).length
                            }), (0, q.jsx)("div", {
                                className: "text-xs text-muted-foreground",
                                children: "Fulfilled"
                            })]
                        })]
                    })
                })
            })]
        }), (0, q.jsxs)("div", {
            className: "flex gap-2",
            children: [(0, q.jsxs)(e1, {
                variant: "orders" === t ? "default" : "outline",
                onClick: () => r("orders"),
                children: [(0, q.jsx)(a$, {
                    type: "validation",
                    size: "sm",
                    className: "mr-2"
                }), "Sales Orders"]
            }), (0, q.jsxs)(e1, {
                variant: "invoices" === t ? "default" : "outline",
                onClick: () => r("invoices"),
                children: [(0, q.jsx)(a$, {
                    type: "invoice",
                    size: "sm",
                    className: "mr-2"
                }), "Invoices"]
            })]
        }), (0, q.jsx)(ap, {
            children: (0, q.jsxs)(av, {
                className: "pt-6",
                children: [(0, q.jsxs)("div", {
                    className: "flex gap-4 mb-4",
                    children: [(0, q.jsxs)("div", {
                        className: "relative flex-1",
                        children: [(0, q.jsx)(ee, {
                            className: "absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground"
                        }), (0, q.jsx)(e2, {
                            placeholder: `Search ${t}...`,
                            className: "pl-10",
                            value: n,
                            onChange: e => i(e.target.value)
                        })]
                    }), (0, q.jsxs)(e1, {
                        variant: "outline",
                        children: [(0, q.jsx)(Ae, {
                            className: "h-4 w-4 mr-2"
                        }), "Filters"]
                    })]
                }), "orders" === t ? (0, q.jsxs)(E3, {
                    children: [(0, q.jsx)(E4, {
                        children: (0, q.jsxs)(E6, {
                            children: [(0, q.jsx)(E7, {
                                children: "Order ID"
                            }), (0, q.jsx)(E7, {
                                children: "Customer"
                            }), (0, q.jsx)(E7, {
                                children: "Date"
                            }), (0, q.jsx)(E7, {
                                children: "Value"
                            }), (0, q.jsx)(E7, {
                                children: "Status"
                            }), (0, q.jsx)(E7, {
                                children: "Agent Status"
                            }), (0, q.jsx)(E7, {
                                className: "text-right",
                                children: "Actions"
                            })]
                        })
                    }), (0, q.jsx)(E8, {
                        children: s.map(t => {
                            let r = void 0 !== a[t.orderId] && a[t.orderId] < 100,
                                n = a[t.orderId] || 0;
                            return (0, q.jsxs)(E6, {
                                className: eJ(r && "bg-[var(--info)]/5"),
                                children: [(0, q.jsx)(E9, {
                                    className: "font-mono font-medium",
                                    children: t.orderId
                                }), (0, q.jsx)(E9, {
                                    children: t.customerName
                                }), (0, q.jsx)(E9, {
                                    children: t.orderDate
                                }), (0, q.jsxs)(E9, {
                                    className: "font-medium",
                                    children: ["$", t.totalValue.toLocaleString()]
                                }), (0, q.jsx)(E9, {
                                    children: (0, q.jsx)(ar, {
                                        className: (e => {
                                            switch (e) {
                                                case "Hold":
                                                    return "bg-primary text-primary-foreground";
                                                case "Blocked":
                                                    return "bg-[var(--warning)] text-[var(--warning-foreground)]";
                                                case "Processing":
                                                    return "bg-[var(--info)] text-white";
                                                case "Released":
                                                case "Fulfilled":
                                                    return "bg-[var(--success)] text-white";
                                                default:
                                                    return "bg-muted text-muted-foreground"
                                            }
                                        })(t.status),
                                        children: t.status
                                    })
                                }), (0, q.jsx)(E9, {
                                    children: r ? (0, q.jsx)("div", {
                                        className: "w-32",
                                        children: (0, q.jsx)(aV, {
                                            progress: n,
                                            showPercent: !1,
                                            color: "info"
                                        })
                                    }) : "Processing" === t.status ? (0, q.jsx)(aU, {
                                        status: "processing",
                                        message: "Validating..."
                                    }) : "Fulfilled" === t.status ? (0, q.jsx)(aU, {
                                        status: "complete",
                                        message: "Complete"
                                    }) : (0, q.jsx)(aU, {
                                        status: "idle",
                                        message: "Pending"
                                    })
                                }), (0, q.jsx)(E9, {
                                    className: "text-right",
                                    children: (0, q.jsxs)("div", {
                                        className: "flex items-center justify-end gap-2",
                                        children: [(0, q.jsx)(e1, {
                                            variant: "ghost",
                                            size: "sm",
                                            children: (0, q.jsx)(Ar, {
                                                className: "h-4 w-4"
                                            })
                                        }), ("Processing" === t.status || "Hold" === t.status) && (0, q.jsxs)(e1, {
                                            variant: "outline",
                                            size: "sm",
                                            onClick: () => {
                                                var r;
                                                return r = t.orderId, void(o(e => ({
                                                    ...e,
                                                    [r]: 0
                                                })), setTimeout(() => {
                                                    e?.(r)
                                                }, 2e3))
                                            },
                                            disabled: r,
                                            children: [r ? (0, q.jsx)(aF, {
                                                size: "sm",
                                                className: "mr-1"
                                            }) : (0, q.jsx)(E1, {
                                                className: "h-4 w-4 mr-1"
                                            }), "Process"]
                                        })]
                                    })
                                })]
                            }, t.orderId)
                        })
                    })]
                }) : (0, q.jsxs)(E3, {
                    children: [(0, q.jsx)(E4, {
                        children: (0, q.jsxs)(E6, {
                            children: [(0, q.jsx)(E7, {
                                children: "Invoice ID"
                            }), (0, q.jsx)(E7, {
                                children: "Customer"
                            }), (0, q.jsx)(E7, {
                                children: "Invoice Date"
                            }), (0, q.jsx)(E7, {
                                children: "Due Date"
                            }), (0, q.jsx)(E7, {
                                children: "Amount"
                            }), (0, q.jsx)(E7, {
                                children: "Status"
                            }), (0, q.jsx)(E7, {
                                className: "text-right",
                                children: "Actions"
                            })]
                        })
                    }), (0, q.jsx)(E8, {
                        children: l.map(e => (0, q.jsxs)(E6, {
                            children: [(0, q.jsx)(E9, {
                                className: "font-mono font-medium",
                                children: e.invoiceId
                            }), (0, q.jsx)(E9, {
                                children: e.customerName
                            }), (0, q.jsx)(E9, {
                                children: e.invoiceDate
                            }), (0, q.jsx)(E9, {
                                children: e.dueDate
                            }), (0, q.jsxs)(E9, {
                                className: "font-medium",
                                children: ["$", e.amount.toLocaleString()]
                            }), (0, q.jsx)(E9, {
                                children: (0, q.jsx)(ar, {
                                    className: (e => {
                                        switch (e) {
                                            case "Paid":
                                                return "bg-[var(--success)] text-white";
                                            case "Sent":
                                                return "bg-[var(--info)] text-white";
                                            case "Pending":
                                                return "bg-[var(--warning)] text-[var(--warning-foreground)]";
                                            case "Overdue":
                                                return "bg-primary text-primary-foreground";
                                            case "Disputed":
                                                return "bg-purple-500 text-white";
                                            default:
                                                return "bg-muted text-muted-foreground"
                                        }
                                    })(e.status),
                                    children: e.status
                                })
                            }), (0, q.jsx)(E9, {
                                className: "text-right",
                                children: (0, q.jsx)(e1, {
                                    variant: "ghost",
                                    size: "sm",
                                    children: (0, q.jsx)(Ar, {
                                        className: "h-4 w-4"
                                    })
                                })
                            })]
                        }, e.invoiceId))
                    })]
                })]
            })
        })]
    })
}