function AA({
    onClose: e
}) {
    let [t, r] = (0, G.useState)([{
        id: "msg-1",
        sender: "agent",
        content: "Hello! I've detected a Credit Hold situation for Order SO-710245 from ABC Traders. Let me walk you through the details.",
        timestamp: "2025-01-15T08:30:15Z",
        type: "info"
    }, {
        id: "msg-2",
        sender: "agent",
        content: "Order Details:\n• Order ID: SO-710245\n• Customer: ABC Traders (CUST-001)\n• Total Value: $125,000\n• Current Credit Exposure: $485K / $500K limit\n• New exposure would be: $610K (exceeds by $110K)",
        timestamp: "2025-01-15T08:30:18Z",
        type: "info"
    }, {
        id: "msg-3",
        sender: "agent",
        content: "I've analyzed the customer profile:\n• Credit Rating: BB (downgraded recently)\n• Relationship Tier: Gold\n• LTV Score: 0.82 (high value customer)\n• Churn Risk: 0.15 (low)\n• Payment History: 87% on-time",
        timestamp: "2025-01-15T08:30:22Z",
        type: "info"
    }, {
        id: "msg-4",
        sender: "agent",
        content: "Based on AI analysis, I've generated three decision options:\n\n**Option A: Conditional Release (Recommended)**\n• Partial prepayment (20% = $25K)\n• Accelerated dunning protocol\n• Weekly credit monitoring\n• Risk Reduction: -15%\n• LTV Impact: +8%\n• Confidence: 87%\n\n**Option B: Split Shipment**\n• 50/50 split delivery\n• First shipment COD ($62.5K)\n• Balance on Net-15\n• Risk Reduction: -25%\n• LTV Impact: +2%\n• Confidence: 79%\n\n**Option C: Hard Hold**\n• Full prepayment required\n• Manual credit review\n• Escalate to Credit Manager\n• Risk Reduction: -35%\n• LTV Impact: -12% (may harm relationship)\n• Confidence: 92%",
        timestamp: "2025-01-15T08:30:25Z",
        type: "decision"
    }, {
        id: "msg-5",
        sender: "agent",
        content: "What would you like to do? I recommend Option A (Conditional Release) as it balances risk mitigation with customer relationship preservation.",
        timestamp: "2025-01-15T08:30:28Z",
        type: "action"
    }]), [n, i] = (0, G.useState)([{
        id: "audit-1",
        action: "Order Validation Started",
        agent: "Validation Agent",
        timestamp: "2025-01-15T08:30:10Z",
        status: "success",
        details: "Customer ID validated, Item SKUs verified"
    }, {
        id: "audit-2",
        action: "Pricing Validation",
        agent: "Pricing Agent",
        timestamp: "2025-01-15T08:30:12Z",
        status: "success",
        details: "Contract pricing applied, Volume discounts calculated"
    }, {
        id: "audit-3",
        action: "Credit Check Triggered",
        agent: "Credit Risk Agent",
        timestamp: "2025-01-15T08:30:15Z",
        status: "success",
        details: "Credit exposure exceeds limit by $110K"
    }, {
        id: "audit-4",
        action: "LTV Analysis Completed",
        agent: "Customer LTV Agent",
        timestamp: "2025-01-15T08:30:20Z",
        status: "success",
        details: "High-value customer identified (LTV: 0.82)"
    }, {
        id: "audit-5",
        action: "Decision Options Generated",
        agent: "OTC Orchestrator",
        timestamp: "2025-01-15T08:30:25Z",
        status: "success",
        details: "Generated 3 decision options (Golden Trio)"
    }, {
        id: "audit-6",
        action: "Awaiting Human Decision",
        agent: "OTC Orchestrator",
        timestamp: "2025-01-15T08:30:28Z",
        status: "pending",
        details: "Human-in-the-loop approval required"
    }]), [a, o] = (0, G.useState)(""), [s, l] = (0, G.useState)(null), [c, u] = (0, G.useState)(!1), [d, f] = (0, G.useState)(!1), p = (0, G.useRef)(null), m = (0, G.useRef)(null);
    (0, G.useEffect)(() => {
        p.current && (p.current.scrollTop = p.current.scrollHeight)
    }, [t]), (0, G.useEffect)(() => {
        m.current && (m.current.scrollTop = m.current.scrollHeight)
    }, [n]);
    let h = () => {
        if (!a.trim()) return;
        let e = {
            id: `msg-human-${Date.now()}`,
            sender: "human",
            content: a,
            timestamp: new Date().toISOString()
        };
        r(t => [...t, e]);
        let t = a.toLowerCase();
        o("");
        let n = {
            id: `audit-msg-${Date.now()}`,
            action: "Human Question/Input",
            agent: "Credit Manager (Human)",
            timestamp: new Date().toISOString(),
            status: "success",
            details: a.substring(0, 50) + (a.length > 50 ? "..." : "")
        };
        i(e => [...e, n]), u(!0), setTimeout(() => {
            let e;
            u(!1), e = t.includes("payment") || t.includes("history") ? {
                id: `msg-agent-${Date.now()}`,
                sender: "agent",
                content: "Here's ABC Traders payment history for the last 12 months:\n\n• Total invoices: 24\n• On-time payments: 21 (87.5%)\n• Average days late: 3.2 days\n• Largest invoice paid: $89,500 (paid early)\n• Recent trend: Payments slowing (last 60 days)\n• Average payment cycle: 32 days vs 30-day terms\n\nThe recent slowdown correlates with their credit rating downgrade. Should I factor this into the recommendation?",
                timestamp: new Date().toISOString(),
                type: "info"
            } : t.includes("risk") || t.includes("exposure") ? {
                id: `msg-agent-${Date.now()}`,
                sender: "agent",
                content: "Current risk analysis:\n\n**Credit Exposure**\n• Current: $485K / $500K (97%)\n• New order: $125K\n• Projected: $610K (122% over limit)\n\n**Risk Factors**\n• Credit rating: BB (downgraded from BBB)\n• Industry sector: Manufacturing (moderate risk)\n• Market volatility: 12% increase\n• Default probability: 8.5%\n\n**Mitigation Options**\n• Conditional release reduces exposure risk by 15%\n• Prepayment creates immediate $25K cash inflow\n• Weekly monitoring enables early intervention\n\nWould you like me to run a stress test scenario?",
                timestamp: new Date().toISOString(),
                type: "info"
            } : t.includes("customer") || t.includes("relationship") ? {
                id: `msg-agent-${Date.now()}`,
                sender: "agent",
                content: "ABC Traders relationship profile:\n\n**Customer Value**\n• Lifetime Value (LTV): 0.82 (Gold tier)\n• Annual revenue: ~$1.2M\n• Customer since: 2019 (6 years)\n• Growth rate: +18% YoY\n• Churn risk: 15% (low)\n\n**Relationship Health**\n• Contact frequency: Weekly\n• Service tickets: 2 (both resolved)\n• NPS score: 8.5/10\n• Key contact: John Martinez (Procurement Director)\n\n**Strategic Importance**\n• Part of major regional expansion\n• Referenced us to 3 new customers\n• Potential for 2x volume next quarter\n\nHard hold could damage this valuable relationship. Option A preserves the partnership while managing risk.",
                timestamp: new Date().toISOString(),
                type: "info"
            } : t.includes("why") || t.includes("recommend") ? {
                id: `msg-agent-${Date.now()}`,
                sender: "agent",
                content: "I recommend Option A (Conditional Release) because:\n\n1. **Risk Mitigation**: 20% prepayment ($25K) reduces exposure immediately\n2. **Relationship Preservation**: Avoids hard rejection that could trigger churn\n3. **LTV Protection**: High-value customer (0.82 LTV score) worth preserving\n4. **Data-Driven**: 87% confidence based on 1,200+ similar cases\n5. **Balanced Approach**: Accelerated dunning provides ongoing monitoring\n6. **Revenue Protection**: Allows order to proceed, maintaining $125K revenue\n\nOption C (Hard Hold) is safer but risks:\n• 12% negative LTV impact\n• Potential customer churn\n• Lost revenue opportunity\n• Damage to 6-year relationship\n\nOption B (Split Shipment) is viable but operationally more complex. Does this clarify my reasoning?",
                timestamp: new Date().toISOString(),
                type: "info"
            } : t.includes("approve") || t.includes("yes") || t.includes("proceed") ? {
                id: `msg-agent-${Date.now()}`,
                sender: "agent",
                content: "Great! Please click one of the 'Approve Option' buttons above to proceed, or let me know if you'd like to modify any terms first.",
                timestamp: new Date().toISOString(),
                type: "action"
            } : {
                id: `msg-agent-${Date.now()}`,
                sender: "agent",
                content: "I understand your question. Let me provide more context:\n\nI have access to:\n• Complete customer history and analytics\n• Real-time credit exposure data\n• Industry benchmarks and trends\n• Similar case outcomes and patterns\n• Policy rules and guardrails\n\nWhat specific aspect would you like me to elaborate on?",
                timestamp: new Date().toISOString(),
                type: "question"
            }, r(t => [...t, e]);
            let n = {
                id: `audit-response-${Date.now()}`,
                action: "AI Response Generated",
                agent: "OTC Orchestrator",
                timestamp: new Date().toISOString(),
                status: "success",
                details: "Contextual response provided"
            };
            i(e => [...e, n])
        }, 1500)
    };
    return d ? (0, q.jsx)(AE, {
        orderData: {
            orderId: "SO-710245",
            customerName: "ABC Traders",
            totalValue: 125e3
        },
        onBack: () => f(!1)
    }) : (0, q.jsxs)("div", {
        className: "grid lg:grid-cols-3 gap-4 h-screen",
        children: [(0, q.jsxs)(ap, {
            className: "lg:col-span-2 flex flex-col overflow-hidden h-full",
            children: [(0, q.jsxs)("div", {
                ref: p,
                className: "flex-1 overflow-y-auto p-4 space-y-4 bg-background min-h-0",
                children: [t.map(e => (0, q.jsxs)("div", {
                    className: eJ("flex gap-3", "human" === e.sender && "flex-row-reverse"),
                    children: [(0, q.jsx)("div", {
                        className: eJ("w-8 h-8 rounded-full flex items-center justify-center shrink-0", "agent" === e.sender ? "bg-primary/10" : "bg-accent"),
                        children: "agent" === e.sender ? (0, q.jsx)(EL, {
                            className: "h-4 w-4 text-primary"
                        }) : (0, q.jsx)(Ez, {
                            className: "h-4 w-4 text-foreground"
                        })
                    }), (0, q.jsxs)("div", {
                        className: eJ("flex-1 space-y-1 max-w-[85%]", "human" === e.sender && "flex flex-col items-end"),
                        children: [(0, q.jsxs)("div", {
                            className: "flex items-center gap-2",
                            children: [(0, q.jsx)("span", {
                                className: "text-sm font-medium",
                                children: "agent" === e.sender ? "AI Agent" : "You"
                            }), (0, q.jsx)("span", {
                                className: "text-xs text-muted-foreground",
                                children: new Date(e.timestamp).toLocaleTimeString()
                            })]
                        }), (0, q.jsx)("div", {
                            className: eJ("rounded-lg p-3 whitespace-pre-wrap text-sm", "agent" === e.sender ? "bg-muted/50 text-foreground" : "bg-primary text-primary-foreground", "decision" === e.type && "border-2 border-primary/20"),
                            children: e.content
                        })]
                    })]
                }, e.id)), c && (0, q.jsxs)("div", {
                    className: "flex gap-3",
                    children: [(0, q.jsx)("div", {
                        className: "w-8 h-8 rounded-full flex items-center justify-center bg-primary/10 shrink-0",
                        children: (0, q.jsx)(EL, {
                            className: "h-4 w-4 text-primary"
                        })
                    }), (0, q.jsxs)("div", {
                        className: "bg-muted/50 rounded-lg p-3 flex gap-1",
                        children: [(0, q.jsx)("span", {
                            className: "w-2 h-2 bg-muted-foreground rounded-full animate-bounce"
                        }), (0, q.jsx)("span", {
                            className: "w-2 h-2 bg-muted-foreground rounded-full animate-bounce [animation-delay:0.2s]"
                        }), (0, q.jsx)("span", {
                            className: "w-2 h-2 bg-muted-foreground rounded-full animate-bounce [animation-delay:0.4s]"
                        })]
                    })]
                })]
            }), (0, q.jsx)("div", {
                className: "border-t bg-muted/20 p-4 shrink-0",
                children: (0, q.jsxs)("div", {
                    className: "flex gap-2",
                    children: [(0, q.jsx)(AO, {
                        value: a,
                        onChange: e => o(e.target.value),
                        onKeyDown: e => {
                            "Enter" !== e.key || e.shiftKey || (e.preventDefault(), h())
                        },
                        placeholder: "Ask the AI agent a question...",
                        className: "min-h-[60px] resize-none"
                    }), (0, q.jsx)(e1, {
                        onClick: h,
                        disabled: !a.trim(),
                        className: "shrink-0",
                        children: (0, q.jsx)(ER, {
                            className: "h-4 w-4"
                        })
                    })]
                })
            })]
        }), (0, q.jsx)(ap, {
            className: "flex flex-col overflow-hidden h-full",
            children: (0, q.jsx)("div", {
                ref: m,
                className: "flex-1 overflow-y-auto p-4 space-y-3 bg-background min-h-0",
                children: n.map(e => (0, q.jsxs)("div", {
                    className: "border-l-2 border-primary/20 pl-3 pb-3",
                    children: [(0, q.jsx)("div", {
                        className: "flex items-start justify-between gap-2 mb-1",
                        children: (0, q.jsxs)("div", {
                            className: "flex items-center gap-2",
                            children: ["success" === e.status && (0, q.jsx)(aB, {
                                className: "h-4 w-4 text-green-600 shrink-0"
                            }), "pending" === e.status && (0, q.jsx)(EQ, {
                                className: "h-4 w-4 text-yellow-600 shrink-0"
                            }), "failed" === e.status && (0, q.jsx)(AN, {
                                className: "h-4 w-4 text-red-600 shrink-0"
                            }), (0, q.jsx)("span", {
                                className: "text-sm font-medium",
                                children: e.action
                            })]
                        })
                    }), (0, q.jsx)("div", {
                        className: "text-xs text-muted-foreground",
                        children: e.agent
                    }), (0, q.jsx)("div", {
                        className: "text-xs text-muted-foreground mt-1",
                        children: e.details
                    }), (0, q.jsx)("div", {
                        className: "text-xs text-muted-foreground/60 mt-1",
                        children: new Date(e.timestamp).toLocaleTimeString()
                    })]
                }, e.id))
            })
        })]
    })
}
let AC = Q("ChevronLeft", [
    ["path", {
        d: "m15 18-6-6 6-6",
        key: "1wnfg3"
    }]
]);