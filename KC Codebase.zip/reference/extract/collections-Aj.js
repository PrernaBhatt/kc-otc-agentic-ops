function Aj() {
    let e = aE[0];
    return (0, q.jsxs)("div", {
        className: "space-y-6",
        children: [(0, q.jsx)("div", {
            className: "flex items-center justify-between",
            children: (0, q.jsxs)("div", {
                children: [(0, q.jsx)("h2", {
                    className: "text-xl font-bold text-foreground",
                    children: "Smart Dunning Workbench"
                }), (0, q.jsx)("p", {
                    className: "text-muted-foreground",
                    children: "Proactive collections with AI-powered nudges"
                })]
            })
        }), (0, q.jsxs)("div", {
            className: "grid lg:grid-cols-3 gap-6",
            children: [(0, q.jsxs)(ap, {
                children: [(0, q.jsx)(am, {
                    children: (0, q.jsxs)(ah, {
                        className: "text-lg flex items-center gap-2",
                        children: [(0, q.jsx)(Ez, {
                            className: "h-5 w-5 text-primary"
                        }), "Customer Segment"]
                    })
                }), (0, q.jsxs)(av, {
                    className: "space-y-4",
                    children: [(0, q.jsxs)("div", {
                        children: [(0, q.jsx)("div", {
                            className: "text-xl font-bold text-foreground",
                            children: e.name
                        }), (0, q.jsx)("div", {
                            className: "text-sm text-muted-foreground",
                            children: e.customerId
                        })]
                    }), (0, q.jsxs)("div", {
                        className: "grid grid-cols-2 gap-4",
                        children: [(0, q.jsxs)("div", {
                            children: [(0, q.jsx)("div", {
                                className: "text-xs text-muted-foreground",
                                children: "Risk Tier"
                            }), (0, q.jsx)(ar, {
                                className: "bg-[var(--warning)] text-[var(--warning-foreground)] mt-1",
                                children: "Medium"
                            })]
                        }), (0, q.jsxs)("div", {
                            children: [(0, q.jsx)("div", {
                                className: "text-xs text-muted-foreground",
                                children: "Relationship"
                            }), (0, q.jsx)(ar, {
                                variant: "outline",
                                className: "border-[var(--success)] text-[var(--success)] mt-1",
                                children: e.relationshipTier
                            })]
                        })]
                    }), (0, q.jsxs)("div", {
                        children: [(0, q.jsxs)("div", {
                            className: "flex justify-between text-sm mb-1",
                            children: [(0, q.jsx)("span", {
                                className: "text-muted-foreground",
                                children: "Payment Propensity"
                            }), (0, q.jsx)("span", {
                                className: "font-medium text-foreground",
                                children: "75%"
                            })]
                        }), (0, q.jsx)(Ay, {
                            value: 75,
                            className: "h-2"
                        })]
                    }), (0, q.jsxs)("div", {
                        children: [(0, q.jsxs)("div", {
                            className: "flex justify-between text-sm mb-1",
                            children: [(0, q.jsx)("span", {
                                className: "text-muted-foreground",
                                children: "LTV Score"
                            }), (0, q.jsxs)("span", {
                                className: "font-medium text-foreground",
                                children: [(100 * e.ltvScore).toFixed(0), "%"]
                            })]
                        }), (0, q.jsx)(Ay, {
                            value: 100 * e.ltvScore,
                            className: "h-2"
                        })]
                    }), (0, q.jsxs)("div", {
                        children: [(0, q.jsxs)("div", {
                            className: "flex justify-between text-sm mb-1",
                            children: [(0, q.jsx)("span", {
                                className: "text-muted-foreground",
                                children: "Churn Risk"
                            }), (0, q.jsxs)("span", {
                                className: "font-medium text-foreground",
                                children: [(100 * e.churnRiskScore).toFixed(0), "%"]
                            })]
                        }), (0, q.jsx)(Ay, {
                            value: 100 * e.churnRiskScore,
                            className: "h-2"
                        })]
                    })]
                })]
            }), (0, q.jsxs)(ap, {
                children: [(0, q.jsx)(am, {
                    children: (0, q.jsxs)(ah, {
                        className: "text-lg flex items-center gap-2",
                        children: [(0, q.jsx)(Aw, {
                            className: "h-5 w-5 text-primary"
                        }), "Treatment Plan"]
                    })
                }), (0, q.jsxs)(av, {
                    className: "space-y-4",
                    children: [(0, q.jsxs)("div", {
                        className: "p-3 bg-primary/10 rounded-lg",
                        children: [(0, q.jsxs)("div", {
                            className: "flex items-center gap-2 mb-2",
                            children: [(0, q.jsx)(ar, {
                                className: "bg-primary text-primary-foreground",
                                children: "Early Nudge"
                            }), (0, q.jsx)(ar, {
                                variant: "outline",
                                children: "Accelerated"
                            })]
                        }), (0, q.jsx)("p", {
                            className: "text-sm text-muted-foreground",
                            children: "Pre-due personalized reminder to maintain touchless order flow"
                        })]
                    }), (0, q.jsxs)("div", {
                        className: "space-y-3",
                        children: [(0, q.jsxs)("div", {
                            className: "flex items-center gap-3 p-2 bg-muted/50 rounded-lg",
                            children: [(0, q.jsx)("div", {
                                className: "h-8 w-8 rounded-full bg-[var(--success)]/10 flex items-center justify-center",
                                children: (0, q.jsx)(aB, {
                                    className: "h-4 w-4 text-[var(--success)]"
                                })
                            }), (0, q.jsxs)("div", {
                                className: "flex-1",
                                children: [(0, q.jsx)("div", {
                                    className: "text-sm font-medium text-foreground",
                                    children: "Initial Reminder"
                                }), (0, q.jsx)("div", {
                                    className: "text-xs text-muted-foreground",
                                    children: "Sent 3 days ago"
                                })]
                            })]
                        }), (0, q.jsxs)("div", {
                            className: "flex items-center gap-3 p-2 bg-[var(--warning)]/10 rounded-lg border border-[var(--warning)]/20",
                            children: [(0, q.jsx)("div", {
                                className: "h-8 w-8 rounded-full bg-[var(--warning)]/20 flex items-center justify-center",
                                children: (0, q.jsx)(EQ, {
                                    className: "h-4 w-4 text-[var(--warning)]"
                                })
                            }), (0, q.jsxs)("div", {
                                className: "flex-1",
                                children: [(0, q.jsx)("div", {
                                    className: "text-sm font-medium text-foreground",
                                    children: "Follow-up Nudge"
                                }), (0, q.jsx)("div", {
                                    className: "text-xs text-muted-foreground",
                                    children: "Scheduled: Today 4:00 PM"
                                })]
                            })]
                        }), (0, q.jsxs)("div", {
                            className: "flex items-center gap-3 p-2 bg-muted/50 rounded-lg opacity-60",
                            children: [(0, q.jsx)("div", {
                                className: "h-8 w-8 rounded-full bg-muted flex items-center justify-center",
                                children: (0, q.jsx)(Ab, {
                                    className: "h-4 w-4 text-muted-foreground"
                                })
                            }), (0, q.jsxs)("div", {
                                className: "flex-1",
                                children: [(0, q.jsx)("div", {
                                    className: "text-sm font-medium text-foreground",
                                    children: "Call if needed"
                                }), (0, q.jsx)("div", {
                                    className: "text-xs text-muted-foreground",
                                    children: "5 days before due"
                                })]
                            })]
                        })]
                    }), (0, q.jsxs)("div", {
                        className: "pt-2",
                        children: [(0, q.jsx)("div", {
                            className: "text-xs text-muted-foreground mb-2",
                            children: "Owner"
                        }), (0, q.jsxs)("div", {
                            className: "flex items-center gap-2",
                            children: [(0, q.jsx)("div", {
                                className: "h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center",
                                children: (0, q.jsx)(Ez, {
                                    className: "h-3 w-3 text-primary"
                                })
                            }), (0, q.jsx)("span", {
                                className: "text-sm text-foreground",
                                children: "Collections Specialist"
                            })]
                        })]
                    })]
                })]
            }), (0, q.jsxs)(ap, {
                children: [(0, q.jsx)(am, {
                    children: (0, q.jsxs)(ah, {
                        className: "text-lg flex items-center gap-2",
                        children: [(0, q.jsx)(Ax, {
                            className: "h-5 w-5 text-primary"
                        }), "Nudge Preview"]
                    })
                }), (0, q.jsxs)(av, {
                    className: "space-y-4",
                    children: [(0, q.jsxs)("div", {
                        className: "flex gap-2",
                        children: [(0, q.jsxs)(e1, {
                            size: "sm",
                            variant: "default",
                            className: "flex-1",
                            children: [(0, q.jsx)(Ax, {
                                className: "h-4 w-4 mr-1"
                            }), "Email"]
                        }), (0, q.jsxs)(e1, {
                            size: "sm",
                            variant: "outline",
                            className: "flex-1 bg-transparent",
                            children: [(0, q.jsx)(al, {
                                className: "h-4 w-4 mr-1"
                            }), "SMS"]
                        }), (0, q.jsxs)(e1, {
                            size: "sm",
                            variant: "outline",
                            className: "flex-1 bg-transparent",
                            children: [(0, q.jsx)(J, {
                                className: "h-4 w-4 mr-1"
                            }), "Portal"]
                        })]
                    }), (0, q.jsxs)("div", {
                        className: "p-4 bg-muted/50 rounded-lg space-y-3",
                        children: [(0, q.jsx)("div", {
                            className: "text-sm font-medium text-foreground",
                            children: "Keep future orders touchless—complete early payment for INV-12345"
                        }), (0, q.jsxs)("div", {
                            className: "text-sm text-muted-foreground leading-relaxed",
                            children: ["Hi Accounts Payable Team,", (0, q.jsx)("br", {}), (0, q.jsx)("br", {}), "Your recent order SO-710245 was released under a conditional approval due to credit limits.", (0, q.jsx)("br", {}), (0, q.jsx)("br", {}), "To keep your future orders fully touchless (no holds), please complete early payment for invoice INV-12345 of ", (0, q.jsx)("strong", {
                                children: "$95,000"
                            }), " by ", (0, q.jsx)("strong", {
                                children: "Feb 9, 2025"
                            }), "."]
                        })]
                    }), (0, q.jsxs)("div", {
                        className: "flex gap-2",
                        children: [(0, q.jsxs)(e1, {
                            className: "flex-1",
                            children: [(0, q.jsx)(ER, {
                                className: "h-4 w-4 mr-2"
                            }), "Pay Now"]
                        }), (0, q.jsx)(e1, {
                            variant: "outline",
                            className: "flex-1 bg-transparent",
                            children: "Request Split Plan"
                        })]
                    }), (0, q.jsxs)("div", {
                        className: "p-3 border rounded-lg",
                        children: [(0, q.jsxs)("div", {
                            className: "flex items-center gap-2 mb-2",
                            children: [(0, q.jsx)("input", {
                                type: "checkbox",
                                className: "rounded border-border"
                            }), (0, q.jsx)("span", {
                                className: "text-sm font-medium text-foreground",
                                children: "Capture Promise to Pay"
                            })]
                        }), (0, q.jsx)("div", {
                            className: "text-xs text-muted-foreground",
                            children: "Record customer's commitment to pay by specific date"
                        })]
                    })]
                })]
            })]
        }), (0, q.jsxs)(ap, {
            children: [(0, q.jsx)(am, {
                children: (0, q.jsx)(ah, {
                    className: "text-lg",
                    children: "Recent Outcomes"
                })
            }), (0, q.jsx)(av, {
                children: (0, q.jsxs)("div", {
                    className: "flex flex-wrap gap-4",
                    children: [(0, q.jsxs)("div", {
                        className: "flex items-center gap-2 p-3 bg-[var(--success)]/10 rounded-lg",
                        children: [(0, q.jsx)(aB, {
                            className: "h-5 w-5 text-[var(--success)]"
                        }), (0, q.jsxs)("div", {
                            children: [(0, q.jsx)("div", {
                                className: "text-sm font-medium text-foreground",
                                children: "INV-12348"
                            }), (0, q.jsx)("div", {
                                className: "text-xs text-[var(--success)]",
                                children: "Paid Early"
                            })]
                        })]
                    }), (0, q.jsxs)("div", {
                        className: "flex items-center gap-2 p-3 bg-[var(--success)]/10 rounded-lg",
                        children: [(0, q.jsx)(aB, {
                            className: "h-5 w-5 text-[var(--success)]"
                        }), (0, q.jsxs)("div", {
                            children: [(0, q.jsx)("div", {
                                className: "text-sm font-medium text-foreground",
                                children: "Promise Honored"
                            }), (0, q.jsx)("div", {
                                className: "text-xs text-[var(--success)]",
                                children: "91.5% adherence"
                            })]
                        })]
                    }), (0, q.jsxs)("div", {
                        className: "flex items-center gap-2 p-3 bg-[var(--info)]/10 rounded-lg",
                        children: [(0, q.jsx)(ay, {
                            className: "h-5 w-5 text-[var(--info)]"
                        }), (0, q.jsxs)("div", {
                            children: [(0, q.jsx)("div", {
                                className: "text-sm font-medium text-foreground",
                                children: "DSO Improvement"
                            }), (0, q.jsx)("div", {
                                className: "text-xs text-[var(--info)]",
                                children: "-2.5 days this month"
                            })]
                        })]
                    })]
                })
            })]
        })]
    })
}

function AO({
    className: e,
    ...t
}) {
    return (0, q.jsx)("textarea", {
        "data-slot": "textarea",
        className: eJ("border-input placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-ring/50 aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive dark:bg-input/30 flex field-sizing-content min-h-16 w-full rounded-md border bg-transparent px-3 py-2 text-base shadow-xs transition-[color,box-shadow] outline-none focus-visible:ring-[3px] disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", e),
        ...t
    })
}
let AN = Q("CircleX", [
    ["circle", {
        cx: "12",
        cy: "12",
        r: "10",
        key: "1mglay"
    }],
    ["path", {
        d: "m15 9-6 6",
        key: "1uzhvr"
    }],
    ["path", {
        d: "m9 9 6 6",
        key: "z0biqf"
    }]
]);
Q("Ban", [
    ["circle", {
        cx: "12",
        cy: "12",
        r: "10",
        key: "1mglay"
    }],
    ["path", {
        d: "m4.9 4.9 14.2 14.2",
        key: "1m5liu"
    }]
]), Q("Info", [
    ["circle", {
        cx: "12",
        cy: "12",
        r: "10",
        key: "1mglay"
    }],
    ["path", {
        d: "M12 16v-4",
        key: "1dtifu"
    }],
    ["path", {
        d: "M12 8h.01",
        key: "e9boi3"
    }]
]);
let Ak = Q("ArrowLeft", [
        ["path", {
            d: "m12 19-7-7 7-7",
            key: "1l729n"
        }],
        ["path", {
            d: "M19 12H5",
            key: "x3x0zl"
        }]
    ]),
    AS = Q("ClipboardCheck", [
        ["rect", {
            width: "8",
            height: "4",
            x: "8",
            y: "2",
            rx: "1",
            ry: "1",
            key: "tgr4d6"
        }],
        ["path", {
            d: "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",
            key: "116196"
        }],
        ["path", {
            d: "m9 14 2 2 4-4",
            key: "df797q"
        }]
    ]),
    AP = Q("Truck", [
        ["path", {
            d: "M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2",
            key: "wrbu53"
        }],
        ["path", {
            d: "M15 18H9",
            key: "1lyqi6"
        }],
        ["path", {
            d: "M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14",
            key: "lysw3i"
        }],
        ["circle", {
            cx: "17",
            cy: "18",
            r: "2",
            key: "332jqn"
        }],
        ["circle", {
            cx: "7",
            cy: "18",
            r: "2",
            key: "19iecd"
        }]
    ]);