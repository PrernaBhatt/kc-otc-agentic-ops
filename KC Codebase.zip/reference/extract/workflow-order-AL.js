AL = [{
    id: 1,
    agent: "Autonomous Order Data Validation Agent",
    agentType: "validation",
    persona: "Order Management Team - Order Entry Associate",
    description: "Detect activity when receiving request via designated channel (Portal, Email, EDI, CSR entry)",
    policies: ["Capture Customer Details", "Capture Order Details", "Capture Additional Info"],
    validations: ["Check mandatory fields (Order ID, Customer ID, Item SKU, Quantity)", "Validate Customer ID exists in ERP and CRM", "Validate Item SKU exists in catalog", "Check Quantity against allowed limits"],
    expectedOutput: "Customer Info validated, Order details verified, Item codes exist in product master"
}, {
    id: 2,
    agent: "Pricing Agent",
    agentType: "pricing",
    persona: "Order Management Team - Commercial Team",
    description: "Apply correct pricing, discounts, rebates, and payment terms based on contractual agreements",
    policies: ["Pricing Rules: Apply base price, currency conversion, tax rules", "Discount Policies: Promotional, seasonal, loyalty-based"],
    validations: ["Apply volume-based discounts correctly", "Ensure currency conversion rules applied", "Validate tax inclusion/exclusion settings", "Detect anomalies in pricing using AI"],
    expectedOutput: "Price per item matches contract, Discounts/promotions applied correctly"
}, {
    id: 3,
    agent: "Validation & Evaluation Agent - Credit Control",
    agentType: "credit",
    persona: "Order Management Team",
    description: "Credit risk evaluation to ensure orders accepted only from customers meeting financial risk criteria",
    policies: ["Customer Credit Limit check", "Outstanding Balance review", "Payment Terms validation"],
    validations: ["Credit Exposure = Outstanding Receivables + Open Sales Orders + New Order Value", "If Credit Exposure ≤ Credit Limit → Approve order", "If Credit Exposure > Credit Limit → Place order on Credit Hold"],
    expectedOutput: "Order Blocked - Credit HOLD (Exposure exceeds limit by $110K)"
}, {
    id: 4,
    agent: "Validation & Evaluation Agent - MOQ",
    agentType: "validation",
    persona: "Order Management Team - Credit Analyst",
    description: "MOQ guarantees order meets minimum quantity for cost efficiency (production, packaging, logistics)",
    policies: ["MOQ validation against product master", "Operational cost control"],
    validations: ["Check ordered quantity against predefined MOQ", "If quantity below MOQ, block order", "Trigger notification for exception handling"],
    expectedOutput: "Order quantity validated against MOQ requirements"
}, {
    id: 5,
    agent: "HITL (Human-in-the-Loop)",
    agentType: "orchestrator",
    persona: "Credit Control Team",
    description: "Human review for unblocking blocked sales orders",
    policies: ["Credit review and limit adjustment", "MOQ exception approval"],
    validations: ["Review customer financial standing", "Decide to increase credit limit or override", "Special customer request evaluation"],
    expectedOutput: "UnBlocking of Sales Order, Agentic workflows for proactive customer updates"
}, {
    id: 6,
    agent: "Available-to-Promise (ATP) Agent",
    agentType: "atp",
    persona: "Sales Order Fulfillment - Inventory Planner",
    description: "Inventory check to ensure product availability and accurate fulfillment",
    policies: ["ATP calculation from ERP", "Warehouse optimization"],
    validations: ["Query Inventory: Check real-time stock levels across warehouses", "ATP Calculation: Current stock, inbound supply, outbound commitments", "Allocation: Based on priority rules (customer tier, SLA, order type)"],
    expectedOutput: "Required quantity available, Stock allocated, Delivery date determined"
}],