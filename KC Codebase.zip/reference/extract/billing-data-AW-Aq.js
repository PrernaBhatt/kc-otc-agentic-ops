AW = [{
    id: "capture",
    label: "Capture",
    icon: ao
}, {
    id: "delivery_validation",
    label: "Delivery Validation",
    icon: AP
}, {
    id: "po_validation",
    label: "PO Validation",
    icon: AS
}, {
    id: "contract_validation",
    label: "Contract Validation",
    icon: Q("FilePenLine", [
        ["path", {
            d: "m18 5-2.414-2.414A2 2 0 0 0 14.172 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2",
            key: "142zxg"
        }],
        ["path", {
            d: "M21.378 12.626a1 1 0 0 0-3.004-3.004l-4.01 4.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z",
            key: "2t3380"
        }],
        ["path", {
            d: "M8 18h1",
            key: "13wk12"
        }]
    ])
}, {
    id: "document_check",
    label: "Document Check",
    icon: Q("FileSearch", [
        ["path", {
            d: "M14 2v4a2 2 0 0 0 2 2h4",
            key: "tnqrlb"
        }],
        ["path", {
            d: "M4.268 21a2 2 0 0 0 1.727 1H18a2 2 0 0 0 2-2V7l-5-5H6a2 2 0 0 0-2 2v3",
            key: "ms7g94"
        }],
        ["path", {
            d: "m9 18-1.5-1.5",
            key: "1j6qii"
        }],
        ["circle", {
            cx: "5",
            cy: "14",
            r: "3",
            key: "ufru5t"
        }]
    ])
}, {
    id: "billing_generation",
    label: "Billing Generation",
    icon: Q("Receipt", [
        ["path", {
            d: "M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z",
            key: "q3az6g"
        }],
        ["path", {
            d: "M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8",
            key: "1h4pet"
        }],
        ["path", {
            d: "M12 17.5v-11",
            key: "1jc1ny"
        }]
    ])
}, {
    id: "invoice_delivery",
    label: "Invoice Delivery",
    icon: Ax
}, {
    id: "completed",
    label: "Completed",
    icon: aB
}], Aq = [{
    billingId: "BIL-001",
    orderId: "SO-710270",
    customerName: "ABC Traders",
    amount: 125e3,
    status: "capture",
    deliveryValidated: !1,
    poValidated: !1,
    contractValidated: !1,
    documentsComplete: !1,
    invoiceGenerated: !1,
    invoiceDelivered: !1
}, {
    billingId: "BIL-002",
    orderId: "SO-710271",
    customerName: "Global Manufacturing Inc.",
    amount: 34e4,
    status: "delivery_validation",
    deliveryValidated: !1,
    poValidated: !1,
    contractValidated: !1,
    documentsComplete: !1,
    invoiceGenerated: !1,
    invoiceDelivered: !1
}, {
    billingId: "BIL-003",
    orderId: "SO-710272",
    customerName: "TechPro Solutions",
    amount: 275e3,
    status: "po_validation",
    deliveryValidated: !0,
    poValidated: !1,
    contractValidated: !1,
    documentsComplete: !1,
    invoiceGenerated: !1,
    invoiceDelivered: !1
}];