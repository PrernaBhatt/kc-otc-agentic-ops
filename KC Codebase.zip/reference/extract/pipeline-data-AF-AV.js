AF = [{
    orderId: "SO-710260",
    customerId: "CUST-002",
    customerName: "Global Manufacturing Inc.",
    orderDate: "2025-01-16",
    totalValue: 34e4,
    status: "Processing",
    holdReason: null,
    loopOrderFlag: !0,
    decisionId: null,
    lineItems: [{
        orderLineId: "OL-106",
        sku: "SKU-F600",
        productName: "Abrasives Bundle",
        qty: 1e3,
        unitPrice: 180,
        lineValue: 18e4,
        loopLineFlag: !0,
        priceValidated: !0,
        taxValidated: !0
    }, {
        orderLineId: "OL-107",
        sku: "SKU-G700",
        productName: "PPE Supplies",
        qty: 800,
        unitPrice: 200,
        lineValue: 16e4,
        loopLineFlag: !0,
        priceValidated: !0,
        taxValidated: !0
    }]
}, {
    orderId: "SO-710261",
    customerId: "CUST-003",
    customerName: "TechPro Solutions",
    orderDate: "2025-01-16",
    totalValue: 45e3,
    status: "Hold",
    holdReason: "Credit",
    loopOrderFlag: !1,
    decisionId: null,
    lineItems: [{
        orderLineId: "OL-108",
        sku: "SKU-H800",
        productName: "Electronic Components",
        qty: 80,
        unitPrice: 562.5,
        lineValue: 45e3,
        loopLineFlag: !1,
        priceValidated: !0,
        taxValidated: !0
    }]
}, {
    orderId: "SO-710262",
    customerId: "CUST-001",
    customerName: "ABC Traders",
    orderDate: "2025-01-15",
    totalValue: 92500,
    status: "Processing",
    holdReason: null,
    loopOrderFlag: !0,
    decisionId: null,
    lineItems: [{
        orderLineId: "OL-109",
        sku: "SKU-A100",
        productName: "Industrial Tape",
        qty: 500,
        unitPrice: 45,
        lineValue: 22500,
        loopLineFlag: !0,
        priceValidated: !0,
        taxValidated: !0
    }, {
        orderLineId: "OL-110",
        sku: "SKU-C300",
        productName: "Filtration System",
        qty: 50,
        unitPrice: 550,
        lineValue: 27500,
        loopLineFlag: !0,
        priceValidated: !0,
        taxValidated: !0
    }, {
        orderLineId: "OL-111",
        sku: "SKU-D400",
        productName: "Adhesive Solution",
        qty: 1e3,
        unitPrice: 42.5,
        lineValue: 42500,
        loopLineFlag: !1,
        priceValidated: !0,
        taxValidated: !0
    }]
}, {
    orderId: "SO-710263",
    customerId: "CUST-002",
    customerName: "Global Manufacturing Inc.",
    orderDate: "2025-01-15",
    totalValue: 185e3,
    status: "Blocked",
    holdReason: "Delivery",
    loopOrderFlag: !0,
    decisionId: null,
    lineItems: [{
        orderLineId: "OL-112",
        sku: "SKU-I900",
        productName: "Specialty Films",
        qty: 200,
        unitPrice: 550,
        lineValue: 11e4,
        loopLineFlag: !0,
        priceValidated: !0,
        taxValidated: !0
    }, {
        orderLineId: "OL-113",
        sku: "SKU-B200",
        productName: "Safety Equipment Kit",
        qty: 300,
        unitPrice: 125,
        lineValue: 75e3,
        loopLineFlag: !0,
        priceValidated: !0,
        taxValidated: !0
    }]
}], AV = [{
    id: "capture",
    label: "Capture",
    agentType: "orchestrator"
}, {
    id: "validation",
    label: "Validation",
    agentType: "validation"
}, {
    id: "pricing",
    label: "Pricing",
    agentType: "pricing"
}, {
    id: "credit",
    label: "Credit",
    agentType: "credit"
}, {
    id: "moq",
    label: "MOQ",
    agentType: "moq"
}, {
    id: "hitl",
    label: "HITL",
    agentType: "orchestrator"
}, {
    id: "atp",
    label: "ATP",
    agentType: "atp"
}, {
    id: "confirmed",
    label: "Confirmed",
    agentType: "orchestrator"
}];

function AU(e, t) {
    return "passed" === t ? (0, q.jsx)(aB, {
        className: "h-4 w-4 text-[var(--success)]"
    }) : "running" === t ? (0, q.jsx)(aF, {
        size: "sm",
        className: "text-[var(--info)]"
    }) : "blocked" === t ? (0, q.jsx)(EX, {
        className: "h-4 w-4 text-primary"
    }) : "needsReview" === t ? (0, q.jsx)(EQ, {
        className: "h-4 w-4 text-[var(--warning)]"
    }) : (0, q.jsx)("div", {
        className: "h-4 w-4 rounded-full border-2 border-muted"
    })
}

function AK(e) {
    return new Promise(t => setTimeout(t, e))
}