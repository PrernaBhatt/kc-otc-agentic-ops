function AH() {
    let [e, t] = (0, G.useState)(null), [r, n] = (0, G.useState)({}), [i, a] = (0, G.useState)({}), [o, s] = (0, G.useState)({}), [l, c] = (0, G.useState)({
        open: !1,
        messages: [],
        input: ""
    }), u = (0, G.useRef)(null), d = (0, G.useRef)(null), f = (0, G.useRef)(null), p = (0, G.useRef)(null);
    (0, G.useEffect)(() => {
        u.current && (u.current.scrollTop = u.current.scrollHeight)
    }, [r]), (0, G.useEffect)(() => {
        f.current && f.current.scrollIntoView({
            behavior: "smooth",
            block: "end"
        })
    }, [r]), (0, G.useEffect)(() => {
        d.current && d.current.scrollIntoView({
            behavior: "smooth"
        })
    }, [l.messages]), (0, G.useEffect)(() => {
        let e = {};
        AF.forEach(t => {
            e[t.orderId] = {
                orderId: t.orderId,
                currentStage: "capture",
                stageStatuses: {
                    capture: "waiting",
                    validation: "waiting",
                    pricing: "waiting",
                    credit: "waiting",
                    moq: "waiting",
                    hitl: "waiting",
                    atp: "waiting",
                    confirmed: "waiting"
                },
                agentLogs: []
            }
        }), n(e)
    }, []);
    let m = (e, t, r, i, a) => {
            n(n => ({
                ...n,
                [e]: {
                    ...n[e],
                    agentLogs: [...n[e].agentLogs, {
                        id: `log-${Date.now()}-${Math.random()}`,
                        timestamp: new Date().toISOString(),
                        agent: r,
                        agentType: t,
                        message: i,
                        status: a
                    }]
                }
            }))
        },
        h = async e => {
            a(t => ({
                ...t,
                [e.orderId]: !0
            }));
            let t = AV.findIndex(t => t.id === (r[e.orderId]?.currentStage ?? "capture"));
            for (let r = t; r < AV.length; r++) {
                let t = AV[r].id,
                    i = AV[r].agentType;
                if (n(r => ({
                        ...r,
                        [e.orderId]: {
                            ...r[e.orderId],
                            currentStage: t,
                            stageStatuses: {
                                ...r[e.orderId].stageStatuses,
                                [t]: "running"
                            }
                        }
                    })), m(e.orderId, i, AV[r].label, `Processing ${t} stage...`, "info"), await AK(1500), "validation" === t) n(t => ({
                    ...t,
                    [e.orderId]: {
                        ...t[e.orderId],
                        validationChecks: [{
                            name: "SKU Validation",
                            result: "PASS",
                            details: "All SKUs found in catalog"
                        }, {
                            name: "Customer Valid",
                            result: "PASS",
                            details: "Customer account active"
                        }, {
                            name: "Tax ID Check",
                            result: "PASS",
                            details: "Tax ID verified"
                        }]
                    }
                }));
                else if ("pricing" === t) n(t => ({
                    ...t,
                    [e.orderId]: {
                        ...t[e.orderId],
                        pricingDetails: {
                            basePrice: .95 * e.totalValue,
                            discounts: [{
                                type: "Volume Discount",
                                amount: .03 * e.totalValue,
                                rule: "PRC-200"
                            }, {
                                type: "Seasonal Rebate",
                                amount: .05 * e.totalValue,
                                rule: "PRC-510"
                            }],
                            taxes: .18 * e.totalValue,
                            total: e.totalValue,
                            anomalyScore: .08
                        }
                    }
                }));
                else if ("credit" === t) {
                    let t = "Hold" === e.status;
                    n(r => ({
                        ...r,
                        [e.orderId]: {
                            ...r[e.orderId],
                            stageStatuses: {
                                ...r[e.orderId].stageStatuses,
                                credit: t ? "blocked" : "passed"
                            },
                            creditDetails: {
                                outstandingReceivables: 25e4,
                                openOrders: 235e3,
                                newOrderValue: e.totalValue,
                                creditExposure: 485e3 + e.totalValue,
                                creditLimit: 5e5,
                                exposureRatio: (485e3 + e.totalValue) / 5e5,
                                decision: t ? "BLOCKED" : "APPROVED",
                                reason: t ? "Exposure exceeds limit by $110K" : void 0
                            }
                        }
                    })), m(e.orderId, "credit", "Credit Agent", t ? `Credit BLOCKED — exposure $${(485e3+e.totalValue).toLocaleString()} exceeds $500,000 limit. Awaiting approval via chat.` : "Credit check APPROVED — exposure within limits.", t ? "warning" : "success"), t && (s(t => ({
                        ...t,
                        [e.orderId]: !0
                    })), await new Promise(e => {
                        p.current = e
                    }), s(t => ({
                        ...t,
                        [e.orderId]: !1
                    }))), await AK(500);
                    continue
                } else "moq" === t ? n(t => ({
                    ...t,
                    [e.orderId]: {
                        ...t[e.orderId],
                        moqDetails: {
                            moq: 50,
                            ordered: 200,
                            status: "MET"
                        }
                    }
                })) : "atp" === t && n(t => ({
                    ...t,
                    [e.orderId]: {
                        ...t[e.orderId],
                        atpDetails: {
                            available: 300,
                            requested: 200,
                            status: "FULFILLED",
                            fulfillmentDate: "2025-01-20"
                        }
                    }
                }));
                n(r => ({
                    ...r,
                    [e.orderId]: {
                        ...r[e.orderId],
                        stageStatuses: {
                            ...r[e.orderId].stageStatuses,
                            [t]: "passed"
                        }
                    }
                })), m(e.orderId, i, AV[r].label, `${t} stage completed successfully`, "success"), await AK(500)
            }
            a(t => ({
                ...t,
                [e.orderId]: !1
            }))
        }, g = () => {
            let t = l.input.trim();
            if (!t) return;
            c(e => ({
                ...e,
                messages: [...e.messages, {
                    role: "user",
                    text: t
                }],
                input: ""
            }));
            let i = t.toLowerCase(),
                a = e?.orderId ?? "",
                u = r[a]?.currentStage ?? "pending";
            setTimeout(() => {
                let e = "",
                    l = !1;
                if (i.includes("approve") || i.includes("release") || i.includes("unblock") || i.includes("override")) o[a] ? (e = `Credit hold for ${a} approved. Resuming pipeline — advancing to MOQ and ATP checks.`, l = !0, n(e => e[a] ? {
                    ...e,
                    [a]: {
                        ...e[a],
                        stageStatuses: {
                            ...e[a].stageStatuses,
                            credit: "passed"
                        },
                        agentLogs: [...e[a].agentLogs, {
                            id: `log-approved-${Date.now()}`,
                            timestamp: new Date().toISOString(),
                            agent: "Credit Manager",
                            agentType: "orchestrator",
                            message: `Credit hold overridden via chat. Order ${a} released.`,
                            status: "success"
                        }]
                    }
                } : e), s(e => ({
                    ...e,
                    [a]: !1
                })), p.current && (p.current(), p.current = null)) : e = `No pending credit hold found for ${a}. Current stage: ${u}.`;
                else if (i.includes("status") || i.includes("where") || i.includes("stuck")) e = o[a] ? `Order ${a} is paused at credit stage awaiting approval. Type 'approve' or 'override' to release.` : `Order ${a} is at stage: ${u}. Pipeline is running.`;
                else {
                    let n = t.match(/SO-\d+/i);
                    if (n) {
                        let t = n[0].toUpperCase(),
                            i = r[t];
                        e = i ? `${t} is at stage: ${i.currentStage}.${o[t]?" Credit hold pending — type 'approve' to release.":""}` : `Order ${t} is not in this pipeline.`
                    } else e = `Monitoring ${a}. Stage: ${u}. Type 'approve' to release a credit hold or ask about any order.`
                }
                c(t => ({
                    ...t,
                    messages: [...t.messages, {
                        role: "agent",
                        text: e,
                        isApproval: l
                    }]
                }))
            }, 600)
        };
    return (0, q.jsxs)("div", {
        className: "space-y-4",
        children: [(0, q.jsxs)("div", {
            children: [(0, q.jsx)("h2", {
                className: "text-lg font-semibold text-foreground mb-1",
                children: "Agentic Order Management"
            }), (0, q.jsx)("p", {
                className: "text-sm text-muted-foreground",
                children: "AI-powered order processing with automated validation and approvals"
            })]
        }), e ? (0, q.jsxs)("div", {
            className: "space-y-4",
            children: [(0, q.jsxs)("div", {
                className: "flex items-center justify-between",
                children: [(0, q.jsxs)(e1, {
                    variant: "outline",
                    size: "sm",
                    onClick: () => t(null),
                    className: "gap-1.5",
                    children: [(0, q.jsx)(AC, {
                        className: "h-4 w-4"
                    }), " Back to Pipeline"]
                }), (0, q.jsxs)("div", {
                    className: "flex items-center gap-3",
                    children: [(0, q.jsx)("span", {
                        className: "font-semibold text-base",
                        children: e.orderId
                    }), (0, q.jsxs)("span", {
                        className: "text-sm text-muted-foreground",
                        children: [e.customerName, " · $", e.totalValue.toLocaleString()]
                    }), (0, q.jsx)(ar, {
                        variant: "outline",
                        className: "text-xs capitalize",
                        children: r[e.orderId]?.currentStage ?? "pending"
                    })]
                })]
            }), (0, q.jsx)(ap, {
                children: (0, q.jsx)(av, {
                    className: "p-4",
                    children: (0, q.jsxs)("div", {
                        className: "relative",
                        children: [(0, q.jsx)("div", {
                            className: "absolute top-5 left-0 right-0 h-0.5 bg-muted"
                        }), (0, q.jsx)("div", {
                            className: "absolute top-5 left-0 h-0.5 bg-[var(--success)] transition-all duration-700",
                            style: {
                                width: `${AV.findIndex(t=>t.id===r[e.orderId]?.currentStage)/(AV.length-1)*100}%`
                            }
                        }), (0, q.jsx)("div", {
                            className: "relative flex justify-between",
                            children: AV.map(t => {
                                let n = r[e.orderId]?.stageStatuses[t.id],
                                    i = r[e.orderId]?.currentStage === t.id;
                                return (0, q.jsxs)("div", {
                                    className: "flex flex-col items-center",
                                    style: {
                                        width: `${100/AV.length}%`
                                    },
                                    children: [(0, q.jsx)("div", {
                                        className: ["relative z-10 h-9 w-9 rounded-full flex items-center justify-center border-2 transition-all", "passed" === n ? "bg-[var(--success)] border-[var(--success)] text-white" : "running" === n ? "bg-[var(--info)] border-[var(--info)] text-white animate-pulse" : "blocked" === n ? "bg-primary border-primary text-primary-foreground" : "bg-background border-muted text-muted-foreground"].join(" "),
                                        children: AU(t.id, n ?? "waiting")
                                    }), (0, q.jsx)("span", {
                                        className: ["text-xs mt-1.5 font-medium text-center", i ? "text-foreground" : "text-muted-foreground"].join(" "),
                                        children: t.label
                                    })]
                                }, t.id)
                            })
                        })]
                    })
                })
            }), (0, q.jsxs)("div", {
                className: "grid grid-cols-1 lg:grid-cols-3 gap-4",
                children: [(0, q.jsxs)("div", {
                    className: "lg:col-span-2 space-y-4",
                    children: [r[e.orderId]?.validationChecks && (0, q.jsxs)(ap, {
                        children: [(0, q.jsx)(am, {
                            className: "pb-2",
                            children: (0, q.jsxs)(ah, {
                                className: "text-sm flex items-center gap-2",
                                children: [(0, q.jsx)(a$, {
                                    type: "validation",
                                    size: "sm"
                                }), " Validation Results"]
                            })
                        }), (0, q.jsx)(av, {
                            className: "space-y-2",
                            children: r[e.orderId].validationChecks?.map((e, t) => (0, q.jsxs)("div", {
                                className: "flex items-center justify-between p-2 bg-muted/50 rounded text-sm",
                                children: [(0, q.jsx)("span", {
                                    children: e.name
                                }), (0, q.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [(0, q.jsx)("span", {
                                        className: "text-xs text-muted-foreground",
                                        children: e.details
                                    }), "PASS" === e.result && (0, q.jsx)(aB, {
                                        className: "h-4 w-4 text-[var(--success)]"
                                    })]
                                })]
                            }, t))
                        })]
                    }), r[e.orderId]?.pricingDetails && (0, q.jsxs)(ap, {
                        children: [(0, q.jsx)(am, {
                            className: "pb-2",
                            children: (0, q.jsxs)(ah, {
                                className: "text-sm flex items-center gap-2",
                                children: [(0, q.jsx)(a$, {
                                    type: "pricing",
                                    size: "sm"
                                }), " Pricing Breakdown"]
                            })
                        }), (0, q.jsxs)(av, {
                            className: "space-y-2 text-sm",
                            children: [(0, q.jsxs)("div", {
                                className: "flex justify-between",
                                children: [(0, q.jsx)("span", {
                                    className: "text-muted-foreground",
                                    children: "Base Price"
                                }), (0, q.jsxs)("span", {
                                    className: "font-medium",
                                    children: ["$", r[e.orderId].pricingDetails?.basePrice.toLocaleString()]
                                })]
                            }), r[e.orderId].pricingDetails?.discounts.map((e, t) => (0, q.jsxs)("div", {
                                className: "flex justify-between",
                                children: [(0, q.jsxs)("span", {
                                    className: "text-[var(--success)]",
                                    children: [e.type, " (", e.rule, ")"]
                                }), (0, q.jsxs)("span", {
                                    className: "text-[var(--success)]",
                                    children: ["-$", e.amount.toLocaleString()]
                                })]
                            }, t)), (0, q.jsxs)("div", {
                                className: "flex justify-between",
                                children: [(0, q.jsx)("span", {
                                    className: "text-muted-foreground",
                                    children: "Taxes"
                                }), (0, q.jsxs)("span", {
                                    className: "font-medium",
                                    children: ["$", r[e.orderId].pricingDetails?.taxes.toLocaleString()]
                                })]
                            }), (0, q.jsxs)("div", {
                                className: "flex justify-between pt-2 border-t font-semibold",
                                children: [(0, q.jsx)("span", {
                                    children: "Total"
                                }), (0, q.jsxs)("span", {
                                    children: ["$", r[e.orderId].pricingDetails?.total.toLocaleString()]
                                })]
                            })]
                        })]
                    }), r[e.orderId]?.creditDetails && (0, q.jsxs)(ap, {
                        className: o[e.orderId] ? "border-primary/50 shadow-md" : "",
                        children: [(0, q.jsx)(am, {
                            className: "pb-2",
                            children: (0, q.jsxs)(ah, {
                                className: "text-sm flex items-center gap-2",
                                children: [(0, q.jsx)(a$, {
                                    type: "credit",
                                    size: "sm"
                                }), " Credit Evaluation", o[e.orderId] && (0, q.jsx)(ar, {
                                    className: "ml-auto bg-primary text-primary-foreground animate-pulse text-xs",
                                    children: "Awaiting Approval"
                                })]
                            })
                        }), (0, q.jsxs)(av, {
                            className: "space-y-3",
                            children: [(0, q.jsxs)("div", {
                                className: "grid grid-cols-2 gap-4 text-sm",
                                children: [(0, q.jsxs)("div", {
                                    children: [(0, q.jsx)("div", {
                                        className: "text-xs text-muted-foreground",
                                        children: "Credit Limit"
                                    }), (0, q.jsxs)("div", {
                                        className: "font-bold",
                                        children: ["$", r[e.orderId].creditDetails?.creditLimit.toLocaleString()]
                                    })]
                                }), (0, q.jsxs)("div", {
                                    children: [(0, q.jsx)("div", {
                                        className: "text-xs text-muted-foreground",
                                        children: "Exposure"
                                    }), (0, q.jsxs)("div", {
                                        className: "font-bold",
                                        children: ["$", r[e.orderId].creditDetails?.creditExposure.toLocaleString()]
                                    })]
                                })]
                            }), (0, q.jsx)(aV, {
                                progress: (r[e.orderId].creditDetails?.exposureRatio ?? 0) * 100,
                                label: "Exposure Ratio",
                                color: (r[e.orderId].creditDetails?.exposureRatio ?? 0) > 1 ? "error" : "info"
                            }), (0, q.jsx)(ar, {
                                className: r[e.orderId].creditDetails?.decision === "APPROVED" ? "bg-[var(--success)] text-white" : "bg-primary text-primary-foreground",
                                children: r[e.orderId].creditDetails?.decision
                            }), r[e.orderId].creditDetails?.reason && (0, q.jsx)("p", {
                                className: "text-xs text-primary",
                                children: r[e.orderId].creditDetails?.reason
                            }), o[e.orderId] && (0, q.jsxs)("div", {
                                className: "mt-2 rounded-md bg-primary/5 border border-primary/20 p-3 text-xs text-primary",
                                children: ["Pipeline paused. Open the chat and type ", (0, q.jsx)("strong", {
                                    children: "approve"
                                }), " or ", (0, q.jsx)("strong", {
                                    children: "override"
                                }), " to release this order."]
                            })]
                        })]
                    }), r[e.orderId]?.moqDetails && (0, q.jsxs)(ap, {
                        children: [(0, q.jsx)(am, {
                            className: "pb-2",
                            children: (0, q.jsxs)(ah, {
                                className: "text-sm flex items-center gap-2",
                                children: [(0, q.jsx)(a$, {
                                    type: "moq",
                                    size: "sm"
                                }), " MOQ Check"]
                            })
                        }), (0, q.jsxs)(av, {
                            className: "space-y-2 text-sm",
                            children: [(0, q.jsxs)("div", {
                                className: "flex justify-between",
                                children: [(0, q.jsx)("span", {
                                    className: "text-muted-foreground",
                                    children: "Minimum Order Qty"
                                }), (0, q.jsx)("span", {
                                    className: "font-medium",
                                    children: r[e.orderId].moqDetails?.moq
                                })]
                            }), (0, q.jsxs)("div", {
                                className: "flex justify-between",
                                children: [(0, q.jsx)("span", {
                                    className: "text-muted-foreground",
                                    children: "Ordered Qty"
                                }), (0, q.jsx)("span", {
                                    className: "font-medium",
                                    children: r[e.orderId].moqDetails?.ordered
                                })]
                            }), (0, q.jsx)(ar, {
                                className: "bg-[var(--success)] text-white",
                                children: r[e.orderId].moqDetails?.status
                            })]
                        })]
                    }), r[e.orderId]?.atpDetails && (0, q.jsxs)(ap, {
                        children: [(0, q.jsx)(am, {
                            className: "pb-2",
                            children: (0, q.jsxs)(ah, {
                                className: "text-sm flex items-center gap-2",
                                children: [(0, q.jsx)(a$, {
                                    type: "atp",
                                    size: "sm"
                                }), " ATP Check"]
                            })
                        }), (0, q.jsxs)(av, {
                            className: "space-y-2 text-sm",
                            children: [(0, q.jsxs)("div", {
                                className: "flex justify-between",
                                children: [(0, q.jsx)("span", {
                                    className: "text-muted-foreground",
                                    children: "Available Stock"
                                }), (0, q.jsx)("span", {
                                    className: "font-medium",
                                    children: r[e.orderId].atpDetails?.available
                                })]
                            }), (0, q.jsxs)("div", {
                                className: "flex justify-between",
                                children: [(0, q.jsx)("span", {
                                    className: "text-muted-foreground",
                                    children: "Requested"
                                }), (0, q.jsx)("span", {
                                    className: "font-medium",
                                    children: r[e.orderId].atpDetails?.requested
                                })]
                            }), (0, q.jsxs)("div", {
                                className: "flex justify-between",
                                children: [(0, q.jsx)("span", {
                                    className: "text-muted-foreground",
                                    children: "Fulfillment Date"
                                }), (0, q.jsx)("span", {
                                    className: "font-medium",
                                    children: r[e.orderId].atpDetails?.fulfillmentDate
                                })]
                            }), (0, q.jsx)(ar, {
                                className: "bg-[var(--success)] text-white",
                                children: r[e.orderId].atpDetails?.status
                            })]
                        })]
                    }), (0, q.jsx)("div", {
                        ref: f
                    })]
                }), (0, q.jsx)("div", {
                    children: (0, q.jsxs)(ap, {
                        children: [(0, q.jsxs)(am, {
                            className: "pb-2",
                            children: [(0, q.jsx)(ah, {
                                className: "text-sm",
                                children: "AI Agent Audit Trail"
                            }), (0, q.jsx)(ag, {
                                className: "text-xs",
                                children: "Real-time agent reasoning log"
                            })]
                        }), (0, q.jsx)(av, {
                            className: "p-3",
                            children: (0, q.jsxs)("div", {
                                ref: u,
                                className: "max-h-[600px] overflow-y-auto space-y-3",
                                children: [r[e.orderId]?.agentLogs.length === 0 && (0, q.jsx)("p", {
                                    className: "text-xs text-muted-foreground italic",
                                    children: "Waiting for processing to begin..."
                                }), r[e.orderId]?.agentLogs.map(e => (0, q.jsxs)("div", {
                                    className: "flex gap-2 text-xs animate-in fade-in slide-in-from-bottom-2 duration-300",
                                    children: [(0, q.jsx)("div", {
                                        className: "flex-shrink-0 mt-0.5",
                                        children: (0, q.jsx)(a$, {
                                            type: e.agentType,
                                            size: "sm"
                                        })
                                    }), (0, q.jsxs)("div", {
                                        className: "flex-1 min-w-0",
                                        children: [(0, q.jsxs)("div", {
                                            className: "flex items-center gap-1.5",
                                            children: [(0, q.jsx)("span", {
                                                className: "font-medium text-foreground",
                                                children: e.agent
                                            }), (0, q.jsx)("span", {
                                                className: "text-muted-foreground",
                                                children: new Date(e.timestamp).toLocaleTimeString()
                                            })]
                                        }), (0, q.jsx)("div", {
                                            className: ["text-xs mt-0.5", "success" === e.status ? "text-[var(--success)]" : "warning" === e.status ? "text-amber-600" : "text-muted-foreground"].join(" "),
                                            children: e.message
                                        })]
                                    })]
                                }, e.id))]
                            })
                        })]
                    })
                })]
            }), (0, q.jsxs)("div", {
                className: "fixed bottom-6 right-6 z-50 flex flex-col items-end gap-2",
                children: [l.open && (0, q.jsxs)("div", {
                    className: "w-80 rounded-xl shadow-2xl border border-border bg-background flex flex-col overflow-hidden",
                    style: {
                        height: "420px"
                    },
                    children: [(0, q.jsxs)("div", {
                        className: "flex items-center justify-between px-4 py-3 bg-primary text-primary-foreground",
                        children: [(0, q.jsx)("span", {
                            className: "text-sm font-semibold",
                            children: "Order Agent"
                        }), (0, q.jsx)("button", {
                            onClick: () => c(e => ({
                                ...e,
                                open: !1
                            })),
                            className: "opacity-70 hover:opacity-100",
                            children: (0, q.jsx)(ak, {
                                className: "h-4 w-4"
                            })
                        })]
                    }), (0, q.jsxs)("div", {
                        className: "flex-1 overflow-y-auto p-3 space-y-2",
                        children: [0 === l.messages.length && (0, q.jsx)("p", {
                            className: "text-xs text-muted-foreground italic text-center mt-4",
                            children: "Ask about order status or type 'approve' to release a hold."
                        }), l.messages.map((e, t) => (0, q.jsx)("div", {
                            className: ["flex", "user" === e.role ? "justify-end" : "justify-start"].join(" "),
                            children: (0, q.jsxs)("div", {
                                className: ["max-w-[85%] rounded-lg px-3 py-2 text-xs", "user" === e.role ? "bg-primary text-primary-foreground" : e.isApproval ? "bg-green-50 border border-green-200 text-green-800" : "bg-muted text-foreground"].join(" "),
                                children: [e.isApproval && (0, q.jsx)(A$, {
                                    className: "h-3 w-3 inline mr-1 text-green-600"
                                }), e.text]
                            })
                        }, t)), (0, q.jsx)("div", {
                            ref: d
                        })]
                    }), (0, q.jsxs)("div", {
                        className: "flex items-center gap-2 px-3 py-2 border-t",
                        children: [(0, q.jsx)(e2, {
                            value: l.input,
                            onChange: e => c(t => ({
                                ...t,
                                input: e.target.value
                            })),
                            onKeyDown: e => {
                                "Enter" === e.key && g()
                            },
                            placeholder: "Type order number or 'approve'...",
                            className: "h-7 text-xs flex-1 bg-muted/40 border-muted"
                        }), (0, q.jsx)(e1, {
                            size: "sm",
                            variant: "ghost",
                            onClick: g,
                            className: "h-7 w-7 p-0 text-muted-foreground hover:text-foreground",
                            children: (0, q.jsx)(ER, {
                                className: "h-3 w-3"
                            })
                        })]
                    })]
                }), (0, q.jsx)("button", {
                    onClick: () => c(e => ({
                        ...e,
                        open: !e.open
                    })),
                    className: "h-11 w-11 rounded-full bg-primary text-primary-foreground shadow-lg flex items-center justify-center hover:bg-primary/90 transition-all",
                    children: l.open ? (0, q.jsx)(ak, {
                        className: "h-5 w-5"
                    }) : (0, q.jsx)(ED, {
                        className: "h-5 w-5"
                    })
                })]
            })]
        }) : (0, q.jsxs)("div", {
            className: "space-y-4",
            children: [(0, q.jsxs)("p", {
                className: "text-sm text-muted-foreground",
                children: [(0, q.jsx)("span", {
                    className: "font-medium text-foreground",
                    children: AF.length
                }), " orders in pipeline"]
            }), AF.map(e => {
                let n = r[e.orderId] ?? {
                        currentStage: "capture",
                        stageStatuses: {}
                    },
                    a = i[e.orderId];
                return (0, q.jsx)(ap, {
                    className: "overflow-hidden hover:shadow-md transition-shadow",
                    children: (0, q.jsx)(av, {
                        className: "p-5",
                        children: (0, q.jsxs)("div", {
                            className: "space-y-4",
                            children: [(0, q.jsxs)("div", {
                                className: "flex items-start justify-between",
                                children: [(0, q.jsxs)("div", {
                                    className: "space-y-0.5",
                                    children: [(0, q.jsxs)("div", {
                                        className: "flex items-center gap-2",
                                        children: [(0, q.jsx)("h3", {
                                            className: "font-semibold text-sm",
                                            children: e.orderId
                                        }), e.loopOrderFlag && (0, q.jsx)(ar, {
                                            variant: "outline",
                                            className: "text-xs bg-blue-50 text-blue-700 border-blue-200",
                                            children: "Loop Order"
                                        }), (0, q.jsx)(ar, {
                                            variant: "outline",
                                            className: ["text-xs", "Hold" === e.status ? "bg-red-50 text-red-700 border-red-200" : "Blocked" === e.status ? "bg-amber-50 text-amber-700 border-amber-200" : "bg-gray-50 text-gray-600 border-gray-200"].join(" "),
                                            children: e.status
                                        })]
                                    }), (0, q.jsx)("p", {
                                        className: "text-xs text-muted-foreground",
                                        children: e.customerName
                                    }), (0, q.jsxs)("p", {
                                        className: "text-sm font-medium",
                                        children: ["$", e.totalValue.toLocaleString()]
                                    })]
                                }), (0, q.jsx)(e1, {
                                    size: "sm",
                                    onClick: () => {
                                        t(e), c({
                                            open: !1,
                                            messages: [],
                                            input: ""
                                        }), h(e)
                                    },
                                    disabled: a || "confirmed" === n.currentStage,
                                    className: "gap-1.5 text-xs h-8",
                                    children: "confirmed" === n.currentStage ? (0, q.jsxs)(q.Fragment, {
                                        children: [(0, q.jsx)(aB, {
                                            className: "h-3.5 w-3.5"
                                        }), " Complete"]
                                    }) : (0, q.jsxs)(q.Fragment, {
                                        children: [(0, q.jsx)(E1, {
                                            className: "h-3.5 w-3.5"
                                        }), " Process"]
                                    })
                                })]
                            }), (0, q.jsxs)("div", {
                                className: "space-y-2",
                                children: [(0, q.jsxs)("div", {
                                    className: "flex justify-between text-xs text-muted-foreground",
                                    children: [(0, q.jsxs)("span", {
                                        children: ["Stage: ", (0, q.jsx)("span", {
                                            className: "font-medium text-foreground capitalize",
                                            children: n.currentStage
                                        })]
                                    }), (0, q.jsxs)("span", {
                                        children: [AV.findIndex(e => e.id === n.currentStage) + 1, " / ", AV.length]
                                    })]
                                }), (0, q.jsx)("div", {
                                    className: "relative h-1.5 bg-muted rounded-full overflow-hidden",
                                    children: (0, q.jsx)("div", {
                                        className: "absolute h-full bg-[var(--success)] transition-all duration-500",
                                        style: {
                                            width: `${(AV.findIndex(e=>e.id===n.currentStage)+1)/AV.length*100}%`
                                        }
                                    })
                                }), (0, q.jsx)("div", {
                                    className: "flex flex-wrap gap-1.5",
                                    children: AV.map(e => {
                                        let t = n.stageStatuses[e.id];
                                        return (0, q.jsxs)("div", {
                                            className: ["flex items-center gap-1 px-2 py-1 rounded text-xs font-medium transition-all", "passed" === t ? "bg-green-100 text-green-700 border border-green-200" : "running" === t ? "bg-blue-100 text-blue-700 border border-blue-200 animate-pulse" : "blocked" === t ? "bg-red-100 text-red-700 border border-red-200" : "bg-gray-100 text-gray-500 border border-gray-200"].join(" "),
                                            children: [AU(e.id, t ?? "waiting"), (0, q.jsx)("span", {
                                                children: e.label
                                            })]
                                        }, e.id)
                                    })
                                })]
                            })]
                        })
                    })
                }, e.orderId)
            })]
        })]
    })
}
let