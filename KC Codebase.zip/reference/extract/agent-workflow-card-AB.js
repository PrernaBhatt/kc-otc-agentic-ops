function AB({
    type: e,
    activeStep: t = 0,
    onStepClick: r,
    showDetails: n = !0
}) {
    let i = "order" === e ? AL : Az,
        [a, o] = (0, G.useState)(-1),
        [s, l] = (0, G.useState)([]);
    return (0, G.useEffect)(() => {
        if (t > 0 && !s.includes(t)) {
            o(t);
            let e = setTimeout(() => {
                l(e => [...e, t]), o(-1)
            }, 2e3);
            return () => clearTimeout(e)
        }
    }, [t, s]), (0, q.jsxs)(ap, {
        className: "bg-card",
        children: [(0, q.jsxs)(am, {
            className: "pb-3",
            children: [(0, q.jsxs)("div", {
                className: "flex items-center justify-between",
                children: [(0, q.jsxs)(ah, {
                    className: "text-lg font-semibold flex items-center gap-2",
                    children: [(0, q.jsx)(a$, {
                        type: "orchestrator",
                        size: "sm",
                        className: "text-primary"
                    }), "order" === e ? "Order Management Workflow" : "Billing Workflow"]
                }), (0, q.jsxs)(ar, {
                    variant: "outline",
                    className: "gap-1",
                    children: [s.length, "/", i.length, " Complete"]
                })]
            }), (0, q.jsx)(aV, {
                progress: s.length / i.length * 100,
                color: s.length === i.length ? "success" : "primary"
            })]
        }), (0, q.jsx)(av, {
            className: "space-y-3",
            children: i.map((e, o) => {
                var l;
                let c = (l = e.id, s.includes(l) ? "complete" : a === l ? "processing" : "idle"),
                    u = t === e.id,
                    d = void 0 !== r;
                return (0, q.jsxs)("div", {
                    className: eJ("relative flex gap-3 p-3 rounded-lg transition-all", u && "bg-primary/5 ring-1 ring-primary/20", "complete" === c && "bg-[var(--success)]/5", "processing" === c && "bg-[var(--info)]/5", d && "cursor-pointer hover:bg-muted/50"),
                    onClick: () => d && r?.(e.id),
                    children: [o < i.length - 1 && (0, q.jsx)("div", {
                        className: eJ("absolute left-[1.65rem] top-14 w-0.5 h-[calc(100%-2rem)]", "complete" === c ? "bg-[var(--success)]" : "bg-muted")
                    }), (0, q.jsx)("div", {
                        className: eJ("relative flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center", "complete" === c && "bg-[var(--success)] text-white", "processing" === c && "bg-[var(--info)] text-white", "idle" === c && "bg-muted text-muted-foreground"),
                        children: "processing" === c ? (0, q.jsx)(aF, {
                            size: "sm",
                            className: "text-white"
                        }) : "complete" === c ? (0, q.jsx)(aB, {
                            className: "w-4 h-4"
                        }) : (0, q.jsx)(a$, {
                            type: e.agentType,
                            size: "sm"
                        })
                    }), (0, q.jsxs)("div", {
                        className: "flex-1 min-w-0",
                        children: [(0, q.jsxs)("div", {
                            className: "flex items-center gap-2 mb-1",
                            children: [(0, q.jsx)("span", {
                                className: "font-medium text-sm text-foreground truncate",
                                children: e.agent
                            }), "processing" === c && (0, q.jsx)(ar, {
                                className: "bg-[var(--info)] text-white text-xs",
                                children: "Processing"
                            })]
                        }), (0, q.jsx)("p", {
                            className: "text-xs text-muted-foreground line-clamp-2",
                            children: e.description
                        }), n && (u || "complete" === c) && (0, q.jsxs)("div", {
                            className: "mt-2 space-y-1",
                            children: [(0, q.jsxs)("div", {
                                className: "text-xs text-muted-foreground",
                                children: [(0, q.jsx)("span", {
                                    className: "font-medium",
                                    children: "Persona:"
                                }), " ", e.persona]
                            }), "complete" === c && (0, q.jsxs)("div", {
                                className: "flex items-center gap-1 text-xs text-[var(--success)]",
                                children: [(0, q.jsx)(aB, {
                                    className: "w-3 h-3"
                                }), e.expectedOutput]
                            })]
                        })]
                    }), (0, q.jsxs)("div", {
                        className: "flex-shrink-0 text-xs text-muted-foreground",
                        children: ["Step ", e.id]
                    })]
                }, e.id)
            })
        })]
    })
}
let A$ = Q("ThumbsUp", [
        ["path", {
            d: "M7 10v12",
            key: "1qc93n"
        }],
        ["path", {
            d: "M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2a3.13 3.13 0 0 1 3 3.88Z",
            key: "emmmcr"
        }]
    ]),