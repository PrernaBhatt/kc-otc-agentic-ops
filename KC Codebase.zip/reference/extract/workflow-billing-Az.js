Az = [{
    id: 1,
    agent: "Report Extraction Agent",
    agentType: "extraction",
    persona: "Billing Analyst",
    description: "Extract eligible billing report based on trigger post order delivery",
    policies: ["Order delivered within PO Limits"],
    validations: ["Validate Proof of delivery vs SO in SAP", "SO line items product code and qty match", "Route order to OM for validation failures"],
    expectedOutput: "Validation Pass - SO vs order delivered matched"
}, {
    id: 2,
    agent: "PO Validation Agent",
    agentType: "po",
    persona: "Billing Analyst",
    description: "Validation of delivered order based on PO",
    policies: ["PO validation with Order Delivered & Sales order"],
    validations: ["Delivered to right customer, Bill-to, Ship-to", "Service/Product included - Quantity, unit price, Total Gross value", "Right tax % considered", "Pay terms and freight charges validated"],
    expectedOutput: "Validation Pass - Scenario meeting required criteria"
}, {
    id: 3,
    agent: "Contract Validation Agent",
    agentType: "contract",
    persona: "Billing Analyst",
    description: "Validation of delivered order based on Contract",
    policies: ["Contract validation with Order Delivered & Sales order"],
    validations: ["Pricing elements based on product categories", "Applicable discounts - Promotions, trade discounts, rebates", "Validity date of pricing agreements"],
    expectedOutput: "Validation Pass - Contract pricing verified"
}, {
    id: 4,
    agent: "Document Extraction Agent",
    agentType: "document",
    persona: "Billing Analyst",
    description: "Verify availability of supporting documents for billing",
    policies: ["Validation of required documents critical for invoice delivery"],
    validations: ["Check PO document availability", "Verify Proof of delivery", "Confirm special exception communications"],
    expectedOutput: "All required documents available"
}, {
    id: 5,
    agent: "Billing Generation Agent",
    agentType: "invoice",
    persona: "Billing Analyst",
    description: "Generate invoice as per guidelines & schedules",
    policies: ["Invoice generation guidelines", "Billing schedule compliance"],
    validations: ["Invoice number generated", "All line items included", "Tax calculations verified"],
    expectedOutput: "Invoice INV-12345 generated successfully"
}, {
    id: 6,
    agent: "Invoice Delivery Agent",
    agentType: "delivery",
    persona: "Billing Analyst",
    description: "Send invoice and supporting documents via agreed delivery mode",
    policies: ["Preferred channel from customer master", "Portal login and upload"],
    validations: ["Send invoice via email/portal", "Upload supporting documents", "Confirm delivery receipt"],
    expectedOutput: "Invoice delivered to customer portal successfully"
}];